/*
 * gen.h - code generation entry points used by the parser.
 */
#ifndef GEN_H
#define GEN_H

#include "comp.h"

typedef struct {
    blk *first, *last;          /* first is the entry block */
} fragment;

/* qualifier triple */
typedef struct {
    int proto, dir, addr;
} qual;

/* arithmetic value */
typedef struct aexpr {
    fragment g;                 /* guard, empty when g.first == NULL */
    stmt    *sh, *st;           /* statements computing the value */
    int      regno;
} aexpr;

void gen_init(cstate *cs);

void frag_and2(cstate *cs, fragment *a, fragment b);
void frag_or2(cstate *cs, fragment *a, fragment b);
void frag_not2(cstate *cs, fragment *a);

stmt *gen_load_a(cstate *cs, int offrel, uint32_t offset, uint32_t size);
fragment gen_ncmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  uint32_t mask, int jtype, int reverse, uint32_t v);
fragment gen_cmp(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v);
fragment gen_cmp_gt(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v);
fragment gen_cmp_ge(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v);
fragment gen_cmp_lt(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v);
fragment gen_cmp_le(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v);
fragment gen_mcmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  uint32_t v, uint32_t mask);
fragment gen_bcmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  const uint8_t *v);
fragment gen_true(cstate *cs);
fragment gen_false(cstate *cs);
fragment gen_false2(cstate *cs);
fragment gen_retblk(cstate *cs, uint32_t v);

fragment gen_linktype(cstate *cs, uint32_t proto);
fragment gen_proto(cstate *cs, uint32_t v, int proto);
fragment gen_proto_abbrev(cstate *cs, int proto);
fragment gen_protochain(cstate *cs, uint32_t v, int proto);
fragment gen_host(cstate *cs, uint32_t addr, uint32_t mask, int proto, int dir, int type);
fragment gen_host6(cstate *cs, const uint8_t *addr, const uint8_t *mask,
                   int proto, int dir, int type);
fragment gen_port_all(cstate *cs, uint32_t port, int ip_proto, int dir);
fragment gen_portrange_all(cstate *cs, uint32_t p1, uint32_t p2, int ip_proto, int dir);

fragment gen_scode(cstate *cs, const char *name, qual q);
fragment gen_mcode(cstate *cs, const char *n1, const char *n2, uint32_t masklen, qual q);
fragment gen_mcode6(cstate *cs, const char *n1, uint32_t masklen, qual q);
fragment gen_ncode(cstate *cs, const char *name, uint32_t v, qual q);
fragment gen_ecode(cstate *cs, const uint8_t *eaddr, qual q);
fragment gen_acode(cstate *cs, const uint8_t *eaddr, qual q);

fragment gen_relation(cstate *cs, int code, aexpr a0, aexpr a1, int reversed);
fragment gen_less(cstate *cs, uint32_t n);
fragment gen_greater(cstate *cs, uint32_t n);
fragment gen_broadcast(cstate *cs, int proto);
fragment gen_multicast(cstate *cs, int proto);
fragment gen_ifindex(cstate *cs, int idx);
fragment gen_inbound(cstate *cs, int dir);
fragment gen_vlan(cstate *cs, uint32_t vid, int has_vid);
fragment gen_mpls(cstate *cs, uint32_t label, int has_label);
fragment gen_pppoed(cstate *cs);
fragment gen_pppoes(cstate *cs, uint32_t sess, int has_sess);
fragment gen_geneve(cstate *cs, uint32_t vni, int has_vni);
fragment gen_p80211_type(cstate *cs, int type, int mask);
fragment gen_p80211_fcdir(cstate *cs, int fcdir);
fragment gen_mac48_check(cstate *cs, const uint8_t *addr, int dir);
fragment gen_mac48_multicast(cstate *cs);

aexpr gen_loadi(cstate *cs, uint32_t v);
aexpr gen_load(cstate *cs, int proto, aexpr idx, uint32_t size);
aexpr gen_loadlen(cstate *cs);
aexpr gen_arth(cstate *cs, int op, aexpr a0, aexpr a1);
aexpr gen_neg(cstate *cs, aexpr a);

void insert_vloffsets(cstate *cs, blk *root);
blk *finish_root(cstate *cs, fragment f);

/* parser entry */
fragment parse_filter(cstate *cs, const char *text);

/* optimizer / emitter */
void bpf_emit_prog(cstate *cs, blk *root, bpf_prog_t *out);
blk *bpf_optimize(cstate *cs, blk *root);

#endif /* GEN_H */
