src/compile.o: src/compile.c src/comp.h src/bpf_defs.h src/gen.h \
 src/jsonio.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
src/jsonio.h:
