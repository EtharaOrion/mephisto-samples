/*
 * names.h - lookups against the pinned tables in etc/.
 */
#ifndef NAMES_H
#define NAMES_H

#include <stdint.h>
#include <stddef.h>

#define ADDR_V4 4
#define ADDR_V6 6

typedef struct {
    int      af;                /* ADDR_V4 or ADDR_V6 */
    uint32_t v4;                /* host byte order */
    uint8_t  v6[16];
} named_addr;

/* /etc/protocols: returns protocol number or -1 */
int nm_proto(const char *name);

/* parse an IPv6 literal of `len` bytes at `s`; 0 on success */
int nm_parse_v6(const char *s, size_t len, uint8_t *out);

/* /etc/services: port for name under "tcp"/"udp"; -1 when absent */
int nm_service(const char *name, const char *proto);

/* /etc/hosts: fills up to max addresses, returns count (v6 first) */
int nm_host(const char *name, named_addr *out, int max);

/* /etc/networks: network number or -1 */
long nm_network(const char *name);

/* /etc/ethers: 6-byte address, returns 0 on success */
int nm_ether(const char *name, uint8_t *out);

#endif /* NAMES_H */
