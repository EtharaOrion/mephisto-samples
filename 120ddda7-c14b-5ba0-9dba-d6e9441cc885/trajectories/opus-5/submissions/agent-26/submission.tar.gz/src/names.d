src/names.o: src/names.c src/names.h
src/names.h:
