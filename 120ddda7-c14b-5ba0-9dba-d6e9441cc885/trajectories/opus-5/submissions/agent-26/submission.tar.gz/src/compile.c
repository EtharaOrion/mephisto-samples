/*
 * compile.c - drives one filter compilation from text to instructions.
 */
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "jsonio.h"

void bpf_prog_init(bpf_prog_t *p)
{
    p->insns = NULL;
    p->len = 0;
    p->cap = 0;
    p->overflow = 0;
}

void bpf_prog_free(bpf_prog_t *p)
{
    free(p->insns);
    p->insns = NULL;
    p->len = 0;
    p->cap = 0;
}

void bpf_prog_reset(bpf_prog_t *p)
{
    p->len = 0;
    p->overflow = 0;
}

void bpf_emit(bpf_prog_t *p, uint16_t code, uint8_t jt, uint8_t jf, uint32_t k)
{
    if (p->len == p->cap) {
        size_t nc = p->cap ? p->cap * 2 : 64;
        p->insns = (bpf_insn_t *)realloc(p->insns, sizeof(bpf_insn_t) * nc);
        p->cap = nc;
    }
    p->insns[p->len].code = code;
    p->insns[p->len].jt = jt;
    p->insns[p->len].jf = jf;
    p->insns[p->len].k = k;
    p->len++;
}

static char errbuf_static[256];

int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err)
{
    cstate cs;
    fragment f;
    blk *root;

    memset(&cs, 0, offsetof(cstate, jb));
    cs.dlt = c->dlt;
    cs.snaplen = c->snaplen;
    cs.netmask = c->netmask;
    cs.optimize = c->optimize;
    cs.arena = NULL;

    bpf_prog_reset(out);

    if (setjmp(cs.jb) != 0) {
        memcpy(errbuf_static, cs.errbuf, strlen(cs.errbuf) + 1);
        *err = errbuf_static;
        cs_arena_free(&cs);
        return -1;
    }

    cs.sent_t = (blk *)cs_alloc(&cs, sizeof(blk));
    cs.sent_f = (blk *)cs_alloc(&cs, sizeof(blk));
    memset(cs.sent_t, 0, offsetof(blk, et));
    memset(cs.sent_f, 0, offsetof(blk, et));

    gen_init(&cs);

    f = parse_filter(&cs, c->filter);
    if (f.first == NULL) {
        /* an empty filter accepts everything */
        f = gen_retblk(&cs, (uint32_t)cs.snaplen);
        root = f.first;
    } else {
        root = finish_root(&cs, f);
    }

    if (cs.optimize && !cs.no_optimize) {
        root = bpf_optimize(&cs, root);
        if (root->code == (BPF_RET | BPF_K) && root->k == 0)
            cs_error(&cs, "expression rejects all packets");
    }

    bpf_emit_prog(&cs, root, out);
    cs_arena_free(&cs);
    return 0;
}
