src/nmdata.o: src/nmdata.c src/names.h
src/names.h:
