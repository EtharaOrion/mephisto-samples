/*
 * filter.h - the compiler's outward-facing entry point.
 */
#ifndef FILTER_H
#define FILTER_H

#include "bpf_defs.h"
#include "jsonio.h"

/* Compile one case. Returns 0 on success; on failure *err points at a static
 * buffer holding the diagnostic. */
int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err);

#endif /* FILTER_H */
