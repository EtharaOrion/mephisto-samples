src/parse.o: src/parse.c src/comp.h src/bpf_defs.h src/gen.h src/names.h \
 src/protos.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
src/names.h:
src/protos.h:
