/*
 * jsonio.c - JSONL reader and writer. Complete and correct; leave it alone.
 *
 * The reader is a real (if small) JSON object scanner rather than a substring
 * search: it walks the object key by key and skips values structurally, so a
 * filter expression containing braces, brackets, colons, commas or escaped
 * quotes cannot be mistaken for record structure.
 */
#include <stdlib.h>
#include <string.h>

#include "jsonio.h"

/* ------------------------------------------------------------------ */
/* scanner                                                            */
/* ------------------------------------------------------------------ */

typedef struct {
    char *p;
} jscan_t;

static void js_ws(jscan_t *s)
{
    while (*s->p == ' ' || *s->p == '\t' || *s->p == '\n' ||
           *s->p == '\r' || *s->p == '\f' || *s->p == '\v')
        s->p++;
}

/* Append one Unicode scalar to buf as UTF-8. */
static void utf8_put(char *buf, size_t *o, unsigned long cp)
{
    if (cp < 0x80) {
        buf[(*o)++] = (char)cp;
    } else if (cp < 0x800) {
        buf[(*o)++] = (char)(0xc0 | (cp >> 6));
        buf[(*o)++] = (char)(0x80 | (cp & 0x3f));
    } else if (cp < 0x10000) {
        buf[(*o)++] = (char)(0xe0 | (cp >> 12));
        buf[(*o)++] = (char)(0x80 | ((cp >> 6) & 0x3f));
        buf[(*o)++] = (char)(0x80 | (cp & 0x3f));
    } else {
        buf[(*o)++] = (char)(0xf0 | (cp >> 18));
        buf[(*o)++] = (char)(0x80 | ((cp >> 12) & 0x3f));
        buf[(*o)++] = (char)(0x80 | ((cp >> 6) & 0x3f));
        buf[(*o)++] = (char)(0x80 | (cp & 0x3f));
    }
}

static int hex4(const char *p, unsigned long *out)
{
    unsigned long v = 0;
    int i;
    for (i = 0; i < 4; i++) {
        char c = p[i];
        v <<= 4;
        if (c >= '0' && c <= '9')      v |= (unsigned long)(c - '0');
        else if (c >= 'a' && c <= 'f') v |= (unsigned long)(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') v |= (unsigned long)(c - 'A' + 10);
        else return -1;
    }
    *out = v;
    return 0;
}

/*
 * Parse a JSON string starting at the opening quote, unescaping it where it
 * stands. Decoding never grows the text - every escape sequence is at least
 * as long as the bytes it stands for - so the result fits in the span it
 * came from, and *out points into the line rather than to a copy.
 *
 * The terminating NUL overwrites either the closing quote or a byte the
 * escapes made spare, so the caller's line is modified.
 */
static int js_string(jscan_t *s, char **out)
{
    char *p = s->p;
    char *w;

    if (*p != '"') return -1;
    p++;
    *out = p;

    /* Unescaped strings are the common case and need no rewriting. */
    while (*p != '"' && *p != '\\' && *p != '\0')
        p++;
    if (*p == '"') {
        *p = '\0';
        s->p = p + 1;
        return 0;
    }

    w = p;
    while (*p != '\0' && *p != '"') {
        if (*p != '\\') {
            *w++ = *p++;
            continue;
        }
        p++;
        switch (*p) {
        case '"':  *w++ = '"';  p++; break;
        case '\\': *w++ = '\\'; p++; break;
        case '/':  *w++ = '/';  p++; break;
        case 'b':  *w++ = '\b'; p++; break;
        case 'f':  *w++ = '\f'; p++; break;
        case 'n':  *w++ = '\n'; p++; break;
        case 'r':  *w++ = '\r'; p++; break;
        case 't':  *w++ = '\t'; p++; break;
        case 'u': {
            unsigned long cp;
            size_t o = 0;

            if (hex4(p + 1, &cp) != 0) return -1;
            p += 5;
            if (cp >= 0xd800 && cp <= 0xdbff && p[0] == '\\' && p[1] == 'u') {
                unsigned long lo;
                if (hex4(p + 2, &lo) == 0 && lo >= 0xdc00 && lo <= 0xdfff) {
                    cp = 0x10000 + ((cp - 0xd800) << 10) + (lo - 0xdc00);
                    p += 6;
                }
            }
            utf8_put(w, &o, cp);
            w += o;
            break;
        }
        default:
            return -1;
        }
    }
    if (*p != '"') return -1;

    s->p = p + 1;
    *w = '\0';
    return 0;
}

/* Numbers in this schema are integral. `is_null` reports a JSON null. */
static int js_number(jscan_t *s, long long *sv, unsigned long long *uv, int *is_null)
{
    char *p = s->p;
    char *end;

    *is_null = 0;
    if (p[0] == 'n' && p[1] == 'u' && p[2] == 'l' && p[3] == 'l') {
        *is_null = 1;
        s->p = p + 4;
        return 0;
    }

    {
        int neg = (*p == '-');
        unsigned long long n = 0;

        end = p + (neg || *p == '+');
        while (*end >= '0' && *end <= '9') {
            n = n * 10u + (unsigned long long)(*end - '0');
            end++;
        }
        if (end == p + (neg || *p == '+')) return -1;
        if (neg) {
            *sv = -(long long)n;
            *uv = (unsigned long long)*sv;
        } else {
            *uv = n;
            *sv = (long long)n;
        }
    }
    /* tolerate (and discard) a fractional or exponent tail */
    while (*end == '.' || *end == 'e' || *end == 'E' || *end == '+' ||
           *end == '-' || (*end >= '0' && *end <= '9'))
        end++;
    s->p = end;
    return 0;
}

static int js_skip_value(jscan_t *s);

static int js_skip_container(jscan_t *s, char open, char close)
{
    if (*s->p != open) return -1;
    s->p++;
    js_ws(s);
    if (*s->p == close) { s->p++; return 0; }
    for (;;) {
        if (open == '{') {
            char *key;

            js_ws(s);
            if (js_string(s, &key) != 0) return -1;
            js_ws(s);
            if (*s->p != ':') return -1;
            s->p++;
        }
        js_ws(s);
        if (js_skip_value(s) != 0) return -1;
        js_ws(s);
        if (*s->p == ',') { s->p++; continue; }
        if (*s->p == close) { s->p++; return 0; }
        return -1;
    }
}

static int js_skip_value(jscan_t *s)
{
    js_ws(s);
    switch (*s->p) {
    case '"': {
        char *tmp;

        return js_string(s, &tmp);
    }
    case '{': return js_skip_container(s, '{', '}');
    case '[': return js_skip_container(s, '[', ']');
    case 't': if (strncmp(s->p, "true", 4)) return -1;  s->p += 4; return 0;
    case 'f': if (strncmp(s->p, "false", 5)) return -1; s->p += 5; return 0;
    case 'n': if (strncmp(s->p, "null", 4)) return -1;  s->p += 4; return 0;
    default: {
        long long sv; unsigned long long uv; int nul;
        return js_number(s, &sv, &uv, &nul);
    }
    }
}

/* ------------------------------------------------------------------ */
/* record parsing                                                     */
/* ------------------------------------------------------------------ */

int bpfc_case_parse(char *line, bpfc_case_t *c)
{
    jscan_t s;
    int have_i = 0, have_dlt = 0;

    c->snaplen  = 262144;
    c->optimize = 1;
    c->netmask  = NETMASK_UNKNOWN;
    c->filter   = NULL;

    s.p = line;
    js_ws(&s);
    if (*s.p != '{') return -1;
    s.p++;
    js_ws(&s);

    if (*s.p == '}') goto finish;

    for (;;) {
        char *key;
        long long sv;
        unsigned long long uv;
        int nul;

        js_ws(&s);
        if (js_string(&s, &key) != 0) return -1;
        js_ws(&s);
        if (*s.p != ':') return -1;
        s.p++;
        js_ws(&s);

        if (!strcmp(key, "filter")) {
            char *val;

            if (*s.p != '"' || js_string(&s, &val) != 0) return -1;
            c->filter = val;
        } else if (!strcmp(key, "i")) {
            if (js_number(&s, &sv, &uv, &nul) != 0) return -1;
            if (!nul) { c->i = sv; have_i = 1; }
        } else if (!strcmp(key, "dlt")) {
            if (js_number(&s, &sv, &uv, &nul) != 0) return -1;
            if (!nul) { c->dlt = (int)sv; have_dlt = 1; }
        } else if (!strcmp(key, "snaplen")) {
            if (js_number(&s, &sv, &uv, &nul) != 0) return -1;
            if (!nul) c->snaplen = (int)sv;
        } else if (!strcmp(key, "optimize")) {
            if (js_number(&s, &sv, &uv, &nul) != 0) return -1;
            if (!nul) c->optimize = (int)sv;
        } else if (!strcmp(key, "netmask")) {
            if (js_number(&s, &sv, &uv, &nul) != 0) return -1;
            c->netmask = nul ? NETMASK_UNKNOWN : (uint32_t)uv;
        } else {
            if (js_skip_value(&s) != 0) return -1;
        }

        js_ws(&s);
        if (*s.p == ',') { s.p++; continue; }
        if (*s.p == '}') { s.p++; break; }
        return -1;
    }

finish:
    if (!have_i || !have_dlt || c->filter == NULL) return -1;
    return 0;
}

/* ------------------------------------------------------------------ */
/* file loading                                                       */
/* ------------------------------------------------------------------ */

/* Slurp a stream into one NUL-terminated buffer, in a single read when the
 * length is known up front. */
static char *read_all(FILE *f, size_t *len_out)
{
    size_t cap = 1 << 16, len = 0;
    char *buf;
    long sz;

    if (fseek(f, 0, SEEK_END) == 0 && (sz = ftell(f)) >= 0 &&
        fseek(f, 0, SEEK_SET) == 0) {
        buf = (char *)malloc((size_t)sz + 1);
        if (buf == NULL) { fprintf(stderr, "bpfc: out of memory\n"); exit(2); }
        len = fread(buf, 1, (size_t)sz, f);
        buf[len] = '\0';
        *len_out = len;
        return buf;
    }

    buf = (char *)malloc(cap);
    if (buf == NULL) { fprintf(stderr, "bpfc: out of memory\n"); exit(2); }
    for (;;) {
        size_t got = fread(buf + len, 1, cap - len - 1, f);

        len += got;
        if (len + 1 < cap)
            break;
        cap *= 2;
        buf = (char *)realloc(buf, cap);
        if (buf == NULL) { fprintf(stderr, "bpfc: out of memory\n"); exit(2); }
    }
    buf[len] = '\0';
    *len_out = len;
    return buf;
}

void bpfc_cases_load(const char *path, bpfc_caseset_t *out)
{
    FILE *f;
    char *p, *end;
    size_t len;

    out->v = NULL;
    out->n = 0;
    out->cap = 0;

    f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "bpfc: cannot open %s\n", path);
        exit(2);
    }
    out->text = read_all(f, &len);
    fclose(f);

    p = out->text;
    end = p + len;
    while (p < end) {
        char *nl = (char *)memchr(p, '\n', (size_t)(end - p));
        char *line = p;

        if (nl != NULL) {
            *nl = '\0';
            p = nl + 1;
        } else {
            p = end;
        }
        if (line[0] == '\0')
            continue;
        if (out->n == out->cap) {
            size_t ncap = out->cap ? out->cap * 2 : 1024;
            bpfc_case_t *nv = realloc(out->v, ncap * sizeof(*nv));

            if (!nv) { fprintf(stderr, "bpfc: out of memory\n"); exit(2); }
            out->v = nv;
            out->cap = ncap;
        }
        if (bpfc_case_parse(line, &out->v[out->n]) == 0)
            out->n++;
    }
}

void bpfc_cases_free(bpfc_caseset_t *cs)
{
    free(cs->v);
    free(cs->text);
    cs->v = NULL;
    cs->text = NULL;
    cs->n = cs->cap = 0;
}

/* ------------------------------------------------------------------ */
/* output                                                             */
/* ------------------------------------------------------------------ */

/*
 * Records are formatted into one buffer and handed to stdio in large
 * pieces: a whole program is thousands of small fields otherwise.
 */
#define OBUF_SZ 262144
#define OBUF_SLACK 512          /* headroom for one field plus its separators */

static char obuf[OBUF_SZ];
static size_t obuf_len;
static FILE *obuf_file;

static void ob_flush(void)
{
    if (obuf_len != 0) {
        fwrite(obuf, 1, obuf_len, obuf_file);
        obuf_len = 0;
    }
}

static void ob_room(size_t n)
{
    if (obuf_len + n > OBUF_SZ)
        ob_flush();
}

static void ob_lit(const char *s, size_t n)
{
    memcpy(obuf + obuf_len, s, n);
    obuf_len += n;
}

#define OB_LIT(s) ob_lit(s, sizeof(s) - 1)

static void ob_uint(unsigned long v)
{
    char tmp[24];
    int n = 0;

    do {
        tmp[n++] = (char)('0' + (v % 10));
        v /= 10;
    } while (v != 0);
    while (n > 0)
        obuf[obuf_len++] = tmp[--n];
}

static void ob_int(long long v)
{
    if (v < 0) {
        obuf[obuf_len++] = '-';
        ob_uint((unsigned long)(-(v + 1)) + 1ul);
    } else {
        ob_uint((unsigned long)v);
    }
}

static void ob_string(const char *s)
{
    const unsigned char *p;

    obuf[obuf_len++] = '"';
    for (p = (const unsigned char *)s; *p != '\0'; p++) {
        ob_room(OBUF_SLACK);
        switch (*p) {
        case '"':  OB_LIT("\\\""); break;
        case '\\': OB_LIT("\\\\"); break;
        case '\n': OB_LIT("\\n");  break;
        case '\r': OB_LIT("\\r");  break;
        case '\t': OB_LIT("\\t");  break;
        case '\b': OB_LIT("\\b");  break;
        case '\f': OB_LIT("\\f");  break;
        default:
            if (*p < 0x20) {
                static const char hex[] = "0123456789abcdef";

                OB_LIT("\\u00");
                obuf[obuf_len++] = hex[*p >> 4];
                obuf[obuf_len++] = hex[*p & 0xf];
            } else {
                obuf[obuf_len++] = (char)*p;
            }
        }
    }
    obuf[obuf_len++] = '"';
}

void json_out_begin(FILE *f)
{
    obuf_file = f;
    obuf_len = 0;
}

void json_out_end(void)
{
    ob_flush();
}

void json_write_string(FILE *f, const char *s)
{
    json_out_begin(f);
    ob_room(OBUF_SLACK);
    ob_string(s);
    ob_flush();
}

void json_write_ok(FILE *f, long long i, const bpf_prog_t *prog)
{
    size_t j;

    (void)f;
    ob_room(OBUF_SLACK);
    OB_LIT("{\"i\":");
    ob_int(i);
    OB_LIT(",\"ok\":true,\"prog\":[");
    for (j = 0; j < prog->len; j++) {
        const bpf_insn_t *ins = &prog->insns[j];

        ob_room(OBUF_SLACK);
        if (j != 0)
            obuf[obuf_len++] = ',';
        obuf[obuf_len++] = '[';
        ob_uint(ins->code);
        obuf[obuf_len++] = ',';
        ob_uint(ins->jt);
        obuf[obuf_len++] = ',';
        ob_uint(ins->jf);
        obuf[obuf_len++] = ',';
        ob_uint((unsigned long)ins->k);
        obuf[obuf_len++] = ']';
    }
    ob_room(OBUF_SLACK);
    OB_LIT("]}\n");
}

void json_write_err(FILE *f, long long i, const char *err)
{
    (void)f;
    ob_room(OBUF_SLACK);
    OB_LIT("{\"i\":");
    ob_int(i);
    OB_LIT(",\"ok\":false,\"err\":");
    ob_string(err);
    ob_room(OBUF_SLACK);
    OB_LIT("}\n");
}
