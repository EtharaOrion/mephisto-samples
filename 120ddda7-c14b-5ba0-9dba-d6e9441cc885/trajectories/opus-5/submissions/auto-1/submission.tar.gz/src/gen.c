/*
 * gen.c - lowering of filter primitives to a graph of basic blocks.
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"
#include "protos.h"

/* ------------------------------------------------------------------ */
/* arena, errors, blocks                                               */

void *cs_alloc(cstate *cs, size_t n)
{
    arena_chunk *c = cs->arena;

    n = (n + 15u) & ~(size_t)15u;
    if (c == NULL || c->used + n > ARENA_CHUNK) {
        size_t extra = n > ARENA_CHUNK ? n - ARENA_CHUNK : 0;
        c = (arena_chunk *)malloc(sizeof(arena_chunk) + extra);
        if (c == NULL)
            abort();
        c->used = 0;
        c->nxt = cs->arena;
        cs->arena = c;
    }
    {
        void *p = c->mem + c->used;
        c->used += n;
        return p;
    }
}

void cs_arena_free(cstate *cs)
{
    arena_chunk *c = cs->arena;

    while (c != NULL) {
        arena_chunk *n = c->nxt;
        free(c);
        c = n;
    }
    cs->arena = NULL;
}

void cs_error(cstate *cs, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    vsnprintf(cs->errbuf, sizeof(cs->errbuf), fmt, ap);
    va_end(ap);
    longjmp(cs->jb, 1);
}

stmt *new_stmt(cstate *cs, uint16_t code)
{
    stmt *s = (stmt *)cs_alloc(cs, sizeof(stmt));

    s->code = code;
    s->k = 0;
    s->nxt = NULL;
    return s;
}

blk *new_blk(cstate *cs, uint16_t code)
{
    blk *b = (blk *)cs_alloc(cs, sizeof(blk));

    memset(b, 0, sizeof(*b));
    b->code = code;
    b->id = cs->nblocks++;
    b->jt = cs->sent_t;
    b->jf = cs->sent_f;
    return b;
}

/* statement list helpers */
static void sl_app(stmt **h, stmt **t, stmt *s)
{
    if (s == NULL)
        return;
    if (*h == NULL) {
        *h = s;
    } else {
        (*t)->nxt = s;
    }
    while (s->nxt != NULL)
        s = s->nxt;
    *t = s;
}

static void blk_app(blk *b, stmt *s)
{
    sl_app(&b->head_s, &b->tail_s, s);
}

/* ------------------------------------------------------------------ */
/* fragments                                                           */

static fragment frag_of(blk *b)
{
    fragment f;

    f.first = b;
    f.last = b;
    b->chain = NULL;
    return f;
}

static void frag_cat(fragment *a, fragment b)
{
    if (a->first == NULL) {
        *a = b;
        return;
    }
    if (b.first == NULL)
        return;
    a->last->chain = b.first;
    a->last = b.last;
}

void frag_and2(cstate *cs, fragment *a, fragment b)
{
    blk *p;

    for (p = a->first; p != NULL; p = p->chain) {
        if (p->jt == cs->sent_t) p->jt = b.first;
        if (p->jf == cs->sent_t) p->jf = b.first;
    }
    frag_cat(a, b);
}

void frag_or2(cstate *cs, fragment *a, fragment b)
{
    blk *p;

    for (p = a->first; p != NULL; p = p->chain) {
        if (p->jt == cs->sent_f) p->jt = b.first;
        if (p->jf == cs->sent_f) p->jf = b.first;
    }
    frag_cat(a, b);
}

void frag_not2(cstate *cs, fragment *a)
{
    blk *p;

    for (p = a->first; p != NULL; p = p->chain) {
        if (p->jt == cs->sent_t)      p->jt = cs->sent_f;
        else if (p->jt == cs->sent_f) p->jt = cs->sent_t;
        if (p->jf == cs->sent_t)      p->jf = cs->sent_f;
        else if (p->jf == cs->sent_f) p->jf = cs->sent_t;
    }
}

/* ------------------------------------------------------------------ */
/* scratch registers                                                   */

static int alloc_reg(cstate *cs)
{
    if (cs->curreg < 0)
        cs_error(cs, "too many registers needed to evaluate expression");
    return cs->curreg--;
}

static void free_reg(cstate *cs, int n)
{
    if (n == cs->curreg + 1)
        cs->curreg = n;
}

/* ------------------------------------------------------------------ */
/* link-layer geometry                                                 */

void gen_init(cstate *cs)
{
    cs->off_linkhdr.cnst = 0;
    cs->off_linkhdr.isvar = 0;
    cs->off_linkhdr.reg = -1;
    cs->off_linkpl.cnst = 0;
    cs->off_linkpl.isvar = 0;
    cs->off_linkpl.reg = -1;
    cs->off_linktype_c = OFF_UNSET;
    cs->off_linktype_var = 0;
    cs->off_nl = 0;
    cs->off_nl_nosnap = 0;
    cs->curreg = BPF_MEMWORDS - 1;
    cs->nblocks = 0;
    cs->label_stack_depth = 0;
    cs->is_geneve = 0;
    cs->no_optimize = 0;

    switch (cs->dlt) {
    case DLT_NULL:
    case DLT_LOOP:
        cs->off_linktype_c = 0;
        cs->off_linkpl.cnst = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_EN10MB:
        cs->off_linktype_c = 12;
        cs->off_linkpl.cnst = 14;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 3;
        break;

    case DLT_PPP:
        cs->off_linktype_c = 2;
        cs->off_linkpl.cnst = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_RAW:
        cs->off_linktype_c = OFF_UNSET;
        cs->off_linkpl.cnst = 0;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_LINUX_SLL:
        cs->off_linktype_c = 14;
        cs->off_linkpl.cnst = 16;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_IEEE802_11:
        cs->off_linktype_c = OFF_UNSET;
        cs->off_linkpl.cnst = 0;
        cs->off_linkpl.isvar = 1;
        cs->off_nl = 8;
        cs->off_nl_nosnap = 3;
        break;

    default:
        cs_error(cs, "unknown data link type %d", cs->dlt);
    }
}

/* ------------------------------------------------------------------ */
/* loads and comparisons                                               */

static stmt *varpart_to_x(cstate *cs, absoff *off)
{
    stmt *s;

    if (!off->isvar)
        return NULL;
    if (off->reg == -1)
        off->reg = alloc_reg(cs);
    s = new_stmt(cs, BPF_LDX | BPF_MEM);
    s->k = (uint32_t)off->reg;
    return s;
}

static stmt *load_absoff(cstate *cs, absoff *off, uint32_t offset, uint32_t size)
{
    stmt *s = varpart_to_x(cs, off);

    if (s != NULL) {
        stmt *s2 = new_stmt(cs, (uint16_t)(BPF_LD | BPF_IND | size));
        s2->k = off->cnst + offset;
        s->nxt = s2;
        return s;
    }
    s = new_stmt(cs, (uint16_t)(BPF_LD | BPF_ABS | size));
    s->k = off->cnst + offset;
    return s;
}

/* X <- IPv4 header length (in bytes), relative to the link payload */
static stmt *loadx_iphdrlen(cstate *cs)
{
    stmt *s, *s2;

    if (cs->off_linkpl.isvar) {
        /* A = payload offset; X = 4*([A]&0xf) is not expressible, so the
         * length is computed the long way round. */
        s = varpart_to_x(cs, &cs->off_linkpl);
        s2 = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
        s2->k = cs->off_linkpl.cnst + cs->off_nl;
        s->nxt = s2;
        s2->nxt = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->nxt->k = 0xf;
        s2->nxt->nxt = new_stmt(cs, BPF_ALU | BPF_LSH | BPF_K);
        s2->nxt->nxt->k = 2;
        s2 = s2->nxt->nxt;
        s2->nxt = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X);
        s2->nxt->nxt = new_stmt(cs, BPF_MISC | BPF_TAX);
        return s;
    }
    s = new_stmt(cs, BPF_LDX | BPF_MSH | BPF_B);
    s->k = cs->off_linkpl.cnst + cs->off_nl;
    return s;
}

stmt *gen_load_a(cstate *cs, int offrel, uint32_t offset, uint32_t size)
{
    stmt *s, *s2;

    switch (offrel) {
    case OR_LINKHDR:
        return load_absoff(cs, &cs->off_linkhdr, offset, size);

    case OR_LINKTYPE:
        if (cs->off_linktype_c == OFF_UNSET)
            cs_error(cs, "internal: no link type offset");
        {
            absoff a;
            a.cnst = cs->off_linktype_c;
            a.isvar = cs->off_linkhdr.isvar;
            a.reg = cs->off_linkhdr.reg;
            s = load_absoff(cs, &a, offset, size);
            cs->off_linkhdr.reg = a.reg;
            return s;
        }

    case OR_LINKPL:
        return load_absoff(cs, &cs->off_linkpl, cs->off_nl + offset, size);

    case OR_LINKPL_NOSNAP:
        return load_absoff(cs, &cs->off_linkpl, cs->off_nl_nosnap + offset, size);

    case OR_TRAN_IPV4:
        s = loadx_iphdrlen(cs);
        s2 = s;
        while (s2->nxt != NULL)
            s2 = s2->nxt;
        s2->nxt = new_stmt(cs, (uint16_t)(BPF_LD | BPF_IND | size));
        s2->nxt->k = cs->off_linkpl.cnst + cs->off_nl + offset;
        return s;

    case OR_TRAN_IPV6:
        return load_absoff(cs, &cs->off_linkpl, cs->off_nl + 40 + offset, size);
    }
    cs_error(cs, "internal: bad offset relation");
    return NULL;
}

fragment gen_ncmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  uint32_t mask, int jtype, int reverse, uint32_t v)
{
    stmt *s = gen_load_a(cs, offrel, offset, size);
    blk *b;
    fragment f;

    if (mask != 0xffffffffu) {
        stmt *s2 = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        stmt *t = s;
        s2->k = mask;
        while (t->nxt != NULL)
            t = t->nxt;
        t->nxt = s2;
    }
    b = new_blk(cs, (uint16_t)(BPF_JMP | jtype | BPF_K));
    b->k = v;
    blk_app(b, s);
    f = frag_of(b);
    if (reverse)
        frag_not2(cs, &f);
    return f;
}

fragment gen_cmp(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JEQ, 0, v);
}

fragment gen_cmp_gt(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGT, 0, v);
}

fragment gen_cmp_ge(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGE, 0, v);
}

fragment gen_cmp_lt(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGE, 1, v);
}

fragment gen_cmp_le(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGT, 1, v);
}

fragment gen_mcmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  uint32_t v, uint32_t mask)
{
    return gen_ncmp(cs, offrel, offset, size, mask, BPF_JEQ, 0, v);
}

fragment gen_bcmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  const uint8_t *v)
{
    fragment f;
    uint32_t done = 0;

    f.first = f.last = NULL;
    while (size - done >= 4) {
        const uint8_t *p = &v[done];
        uint32_t w = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
                     ((uint32_t)p[2] << 8) | p[3];
        fragment t = gen_cmp(cs, offrel, offset + done, BPF_W, w);
        if (f.first == NULL) f = t; else frag_and2(cs, &f, t);
        done += 4;
    }
    while (size - done >= 2) {
        const uint8_t *p = &v[done];
        uint32_t w = ((uint32_t)p[0] << 8) | p[1];
        fragment t = gen_cmp(cs, offrel, offset + done, BPF_H, w);
        if (f.first == NULL) f = t; else frag_and2(cs, &f, t);
        done += 2;
    }
    while (done < size) {
        fragment t = gen_cmp(cs, offrel, offset + done, BPF_B, v[done]);
        if (f.first == NULL) f = t; else frag_and2(cs, &f, t);
        done++;
    }
    return f;
}

/* an always-true / always-false predicate */
static fragment gen_uncond(cstate *cs, int sense)
{
    blk *b;
    stmt *s = new_stmt(cs, BPF_LD | BPF_IMM);

    s->k = (uint32_t)(!sense);
    b = new_blk(cs, BPF_JMP | BPF_JEQ | BPF_K);
    b->k = 0;
    blk_app(b, s);
    return frag_of(b);
}

fragment gen_true(cstate *cs)  { return gen_uncond(cs, 1); }
fragment gen_false(cstate *cs) { return gen_uncond(cs, 0); }

fragment gen_retblk(cstate *cs, uint32_t v)
{
    blk *b = new_blk(cs, BPF_RET | BPF_K);

    b->k = v;
    b->jt = NULL;
    b->jf = NULL;
    return frag_of(b);
}

/* ------------------------------------------------------------------ */
/* link-layer type tests                                               */

#define SKF_AD_OFF          0xfffff000u
#define SKF_AD_PROTOCOL     0
#define SKF_AD_PKTTYPE      4
#define SKF_AD_IFINDEX      8
#define SKF_AD_VLAN_TAG     44
#define SKF_AD_VLAN_TAG_PRESENT 48

static fragment gen_snap(cstate *cs, uint32_t orgcode, uint32_t ptype)
{
    uint8_t snapblock[8];

    snapblock[0] = LLCSAP_SNAP;
    snapblock[1] = LLCSAP_SNAP;
    snapblock[2] = 0x03;
    snapblock[3] = (uint8_t)(orgcode >> 16);
    snapblock[4] = (uint8_t)(orgcode >> 8);
    snapblock[5] = (uint8_t)orgcode;
    snapblock[6] = (uint8_t)(ptype >> 8);
    snapblock[7] = (uint8_t)ptype;
    return gen_bcmp(cs, OR_LINKPL, 0, 8, snapblock);
}

/* 802.2 LLC frame: the ethertype field holds a length */
static fragment gen_is_llc(cstate *cs)
{
    fragment f = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);

    frag_not2(cs, &f);
    return f;
}

static fragment gen_llc_linktype(cstate *cs, uint32_t proto)
{
    switch (proto) {
    case LLCSAP_IP:
    case LLCSAP_ISONS:
    case LLCSAP_NETBEUI:
        return gen_cmp(cs, OR_LINKPL, 0, BPF_H, (proto << 8) | proto);

    case LLCSAP_IPX:
        return gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);

    case ETHERTYPE_ATALK:
        return gen_snap(cs, 0x080007, ETHERTYPE_ATALK);

    default:
        if (proto <= ETHERMTU)
            return gen_cmp(cs, OR_LINKPL, 0, BPF_B, proto);
        return gen_cmp(cs, OR_LINKPL, 6, BPF_H, proto);
    }
}

static fragment gen_check_802_11_data(cstate *cs)
{
    stmt *s;
    blk *b0, *b1;
    fragment f0, f1;

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b0 = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);
    b0->k = 0x08;
    blk_app(b0, s);
    f0 = frag_of(b0);

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b1 = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);
    b1->k = 0x04;
    blk_app(b1, s);
    f1 = frag_of(b1);
    frag_not2(cs, &f1);

    frag_and2(cs, &f1, f0);
    return f1;
}

fragment gen_linktype(cstate *cs, uint32_t proto)
{
    fragment f, f2;

    switch (cs->dlt) {

    case DLT_EN10MB:
        switch (proto) {
        case LLCSAP_ISONS:
        case LLCSAP_IP:
        case LLCSAP_NETBEUI:
            f = gen_is_llc(cs);
            f2 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_H, (proto << 8) | proto);
            frag_and2(cs, &f, f2);
            return f;

        case LLCSAP_IPX:
            f = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, LLCSAP_IPX);
            return f;

        case ETHERTYPE_ATALK:
        case ETHERTYPE_AARP: {
            fragment ethii, llc, snap;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
            llc = gen_is_llc(cs);
            snap = gen_snap(cs, proto == ETHERTYPE_ATALK ? 0x080007u : 0u, proto);
            frag_and2(cs, &llc, snap);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        case ETHERTYPE_IPX: {
            fragment ethii, llc, snap, dsap, raw, grp;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ETHERTYPE_IPX);
            llc = gen_is_llc(cs);
            snap = gen_snap(cs, 0, ETHERTYPE_IPX);
            dsap = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, LLCSAP_IPX);
            raw = gen_cmp(cs, OR_LINKTYPE, 2, BPF_H, 0xffff);
            grp = snap;
            frag_or2(cs, &grp, dsap);
            frag_or2(cs, &grp, raw);
            frag_and2(cs, &llc, grp);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        default:
            if (proto <= ETHERMTU) {
                f = gen_is_llc(cs);
                f2 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, proto);
                frag_and2(cs, &f, f2);
                return f;
            }
            return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
        }

    case DLT_LINUX_SLL:
        switch (proto) {
        case LLCSAP_ISONS:
        case LLCSAP_IP:
        case LLCSAP_NETBEUI:
            f = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            f2 = gen_cmp(cs, OR_LINKPL, 0, BPF_H, (proto << 8) | proto);
            frag_and2(cs, &f, f2);
            return f;

        case LLCSAP_IPX: {
            f = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            f2 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);
            frag_and2(cs, &f, f2);
            return f;
        }

        case ETHERTYPE_IPX: {
            fragment ethii, raw8023, llc, dsap, snap, grp;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ETHERTYPE_IPX);
            raw8023 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_3);
            llc = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            dsap = gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);
            snap = gen_snap(cs, 0, ETHERTYPE_IPX);
            grp = dsap;
            frag_or2(cs, &grp, snap);
            frag_and2(cs, &llc, grp);
            frag_or2(cs, &ethii, raw8023);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        case ETHERTYPE_ATALK:
        case ETHERTYPE_AARP: {
            fragment ethii, llc, snap;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
            llc = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            snap = gen_snap(cs, proto == ETHERTYPE_ATALK ? 0x080007u : 0u, proto);
            frag_and2(cs, &llc, snap);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        default:
            if (proto <= ETHERMTU) {
                f = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
                f2 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, proto);
                frag_and2(cs, &f, f2);
                return f;
            }
            return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
        }

    case DLT_NULL:
    case DLT_LOOP:
        switch (proto) {
        case ETHERTYPE_IP:
            return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, (uint32_t)BSD_AF_INET << 24);
        case ETHERTYPE_IPV6:
            return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, (uint32_t)BSD_AF_INET6 << 24);
        default:
            return gen_false(cs);
        }

    case DLT_PPP:
        switch (proto) {
        case ETHERTYPE_IP:   proto = PPP_IP; break;
        case ETHERTYPE_IPV6: proto = PPP_IPV6; break;
        case LLCSAP_ISONS:   proto = PPP_OSI; break;
        case LLCSAP_8021D:   proto = PPP_BRPDU; break;
        case LLCSAP_IPX:     proto = PPP_IPX; break;
        default: break;
        }
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);

    case DLT_RAW:
        switch (proto) {
        case ETHERTYPE_IP:
            return gen_mcmp(cs, OR_LINKPL, 0, BPF_B, 0x40, 0xf0);
        case ETHERTYPE_IPV6:
            return gen_mcmp(cs, OR_LINKPL, 0, BPF_B, 0x60, 0xf0);
        default:
            return gen_false(cs);
        }

    case DLT_IEEE802_11:
        f = gen_check_802_11_data(cs);
        f2 = gen_llc_linktype(cs, proto);
        frag_and2(cs, &f, f2);
        return f;
    }
    cs_error(cs, "unknown data link type %d", cs->dlt);
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* network-layer protocol tests                                        */

static fragment gen_ipfrag(cstate *cs)
{
    stmt *s = gen_load_a(cs, OR_LINKPL, 6, BPF_H);
    blk *b = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);
    fragment f;

    b->k = 0x1fff;
    blk_app(b, s);
    f = frag_of(b);
    frag_not2(cs, &f);
    return f;
}

fragment gen_proto(cstate *cs, uint32_t v, int proto)
{
    fragment f, f1, f2, f3;

    switch (proto) {
    case PQ_DEFAULT:
        f = gen_proto(cs, v, PQ_IP);
        f1 = gen_proto(cs, v, PQ_IPV6);
        frag_or2(cs, &f, f1);
        return f;

    case PQ_IP:
        f = gen_linktype(cs, ETHERTYPE_IP);
        f1 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, v);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_IPV6:
        f = gen_linktype(cs, ETHERTYPE_IPV6);
        f1 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, v);
        f2 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, IPPROTO_FRAGMENT);
        f3 = gen_cmp(cs, OR_LINKPL, 40, BPF_B, v);
        frag_and2(cs, &f2, f3);
        frag_or2(cs, &f1, f2);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_ISO:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, v);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_LINK:
        return gen_linktype(cs, v);

    case PQ_ARP:
        cs_error(cs, "arp does not encapsulate another protocol");
        break;
    case PQ_RARP:
        cs_error(cs, "rarp does not encapsulate another protocol");
        break;
    case PQ_ATALK:
        cs_error(cs, "atalk encapsulation is not specifiable");
        break;
    case PQ_DECNET:
        cs_error(cs, "decnet encapsulation is not specifiable");
        break;
    default:
        cs_error(cs, "%s proto' is bogus", "'");
        break;
    }
    return gen_false(cs);
}

fragment gen_proto_abbrev(cstate *cs, int proto)
{
    fragment f, f1;

    switch (proto) {
    case PQ_SCTP:  return gen_proto(cs, IPPROTO_SCTP, PQ_DEFAULT);
    case PQ_TCP:   return gen_proto(cs, IPPROTO_TCP, PQ_DEFAULT);
    case PQ_UDP:   return gen_proto(cs, IPPROTO_UDP, PQ_DEFAULT);
    case PQ_ICMP:  return gen_proto(cs, IPPROTO_ICMP, PQ_IP);
    case PQ_IGMP:  return gen_proto(cs, IPPROTO_IGMP, PQ_IP);
    case PQ_IGRP:  return gen_proto(cs, IPPROTO_IGRP, PQ_IP);
    case PQ_PIM:   return gen_proto(cs, IPPROTO_PIM, PQ_DEFAULT);
    case PQ_VRRP:  return gen_proto(cs, IPPROTO_VRRP, PQ_IP);
    case PQ_CARP:  return gen_proto(cs, IPPROTO_CARP, PQ_IP);
    case PQ_AH:    return gen_proto(cs, IPPROTO_AH, PQ_DEFAULT);
    case PQ_ESP:   return gen_proto(cs, IPPROTO_ESP, PQ_DEFAULT);
    case PQ_ICMPV6: return gen_proto(cs, IPPROTO_ICMPV6, PQ_IPV6);

    case PQ_IP:    return gen_linktype(cs, ETHERTYPE_IP);
    case PQ_ARP:   return gen_linktype(cs, ETHERTYPE_ARP);
    case PQ_RARP:  return gen_linktype(cs, ETHERTYPE_REVARP);
    case PQ_ATALK: return gen_linktype(cs, ETHERTYPE_ATALK);
    case PQ_AARP:  return gen_linktype(cs, ETHERTYPE_AARP);
    case PQ_DECNET: return gen_linktype(cs, ETHERTYPE_DN);
    case PQ_LAT:   return gen_linktype(cs, ETHERTYPE_LAT);
    case PQ_SCA:   return gen_linktype(cs, ETHERTYPE_SCA);
    case PQ_MOPDL: return gen_linktype(cs, ETHERTYPE_MOPDL);
    case PQ_MOPRC: return gen_linktype(cs, ETHERTYPE_MOPRC);
    case PQ_IPV6:  return gen_linktype(cs, ETHERTYPE_IPV6);
    case PQ_ISO:   return gen_linktype(cs, LLCSAP_ISONS);
    case PQ_STP:   return gen_linktype(cs, LLCSAP_8021D);
    case PQ_IPX:   return gen_linktype(cs, ETHERTYPE_IPX);
    case PQ_NETBEUI: return gen_linktype(cs, LLCSAP_NETBEUI);

    case PQ_ESIS:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, 0x82);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_ISIS:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, 0x83);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_CLNP:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, 0x81);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_LINK:
        cs_error(cs, "link layer applied in wrong context");
        break;

    case PQ_RADIO:
        cs_error(cs, "radio information not present in capture");
        break;

    default:
        cs_error(cs, "unsupported protocol abbreviation");
    }
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* host / network addresses                                            */

static fragment gen_hostop(cstate *cs, uint32_t addr, uint32_t mask, int dir,
                           uint32_t ll_proto, uint32_t src_off, uint32_t dst_off)
{
    fragment f, fa, fb;
    uint32_t offset;

    switch (dir) {
    case DQ_SRC:
        offset = src_off;
        break;
    case DQ_DST:
        offset = dst_off;
        break;
    case DQ_AND:
        fa = gen_hostop(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_and2(cs, &fa, fb);
        return fa;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_hostop(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_or2(cs, &fa, fb);
        return fa;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    f = gen_linktype(cs, ll_proto);
    fa = gen_mcmp(cs, OR_LINKPL, offset, BPF_W, addr, mask);
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_hostop6(cstate *cs, const uint8_t *addr, const uint8_t *mask,
                            int dir, uint32_t ll_proto, uint32_t src_off, uint32_t dst_off)
{
    fragment f, fa, fb;
    uint32_t offset;
    int i;

    switch (dir) {
    case DQ_SRC:
        offset = src_off;
        break;
    case DQ_DST:
        offset = dst_off;
        break;
    case DQ_AND:
        fa = gen_hostop6(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop6(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_and2(cs, &fa, fb);
        return fa;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_hostop6(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop6(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_or2(cs, &fa, fb);
        return fa;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }

    f.first = f.last = NULL;
    for (i = 0; i < 4; i++) {
        uint32_t a = ((uint32_t)addr[4 * i] << 24) | ((uint32_t)addr[4 * i + 1] << 16) |
                     ((uint32_t)addr[4 * i + 2] << 8) | addr[4 * i + 3];
        uint32_t m = ((uint32_t)mask[4 * i] << 24) | ((uint32_t)mask[4 * i + 1] << 16) |
                     ((uint32_t)mask[4 * i + 2] << 8) | mask[4 * i + 3];
        if (m == 0)
            continue;
        fa = gen_mcmp(cs, OR_LINKPL, offset + (uint32_t)(4 * i), BPF_W, a & m, m);
        if (f.first == NULL) f = fa; else frag_and2(cs, &f, fa);
    }
    fa = gen_linktype(cs, ll_proto);
    if (f.first == NULL)
        return fa;
    frag_and2(cs, &fa, f);
    return fa;
}

static fragment gen_ehostop(cstate *cs, const uint8_t *eaddr, int dir)
{
    fragment f, fa, fb;

    switch (cs->dlt) {
    case DLT_EN10MB:
        break;
    case DLT_IEEE802_11:
        break;
    default:
        cs_error(cs, "ethernet addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel");
    }

    switch (dir) {
    case DQ_SRC:
        return gen_bcmp(cs, OR_LINKHDR, 6, 6, eaddr);
    case DQ_DST:
        return gen_bcmp(cs, OR_LINKHDR, 0, 6, eaddr);
    case DQ_AND:
        fa = gen_ehostop(cs, eaddr, DQ_SRC);
        fb = gen_ehostop(cs, eaddr, DQ_DST);
        frag_and2(cs, &fa, fb);
        return fa;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_ehostop(cs, eaddr, DQ_SRC);
        fb = gen_ehostop(cs, eaddr, DQ_DST);
        frag_or2(cs, &fa, fb);
        return fa;
    }
    f = gen_false(cs);
    return f;
}

fragment gen_host(cstate *cs, uint32_t addr, uint32_t mask, int proto, int dir, int type)
{
    fragment f, f1;
    const char *typestr = (type == AQ_NET) ? "net" : "host";

    switch (proto) {
    case PQ_DEFAULT:
        f = gen_host(cs, addr, mask, PQ_IP, dir, type);
        f1 = gen_host(cs, addr, mask, PQ_ARP, dir, type);
        frag_or2(cs, &f, f1);
        f1 = gen_host(cs, addr, mask, PQ_RARP, dir, type);
        frag_or2(cs, &f, f1);
        return f;

    case PQ_IP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_IP, 12, 16);
    case PQ_ARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_ARP, 14, 24);
    case PQ_RARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_REVARP, 14, 24);
    case PQ_LINK:
        cs_error(cs, "link-layer modifiers applied to %s", typestr);
        break;
    case PQ_IPV6:
        cs_error(cs, "'ip6' modifier applied to ip %s", typestr);
        break;
    default:
        cs_error(cs, "invalid qualifier against IPv4 address");
        break;
    }
    return gen_false(cs);
}

fragment gen_host6(cstate *cs, const uint8_t *addr, const uint8_t *mask,
                   int proto, int dir, int type)
{
    const char *typestr = (type == AQ_NET) ? "net" : "host";

    switch (proto) {
    case PQ_DEFAULT:
    case PQ_IPV6:
        return gen_hostop6(cs, addr, mask, dir, ETHERTYPE_IPV6, 8, 24);
    case PQ_LINK:
        cs_error(cs, "link-layer modifiers applied to ip6 %s", typestr);
        break;
    case PQ_IP:
        cs_error(cs, "'ip' modifier applied to ip6 %s", typestr);
        break;
    default:
        cs_error(cs, "invalid qualifier against IPv6 address");
        break;
    }
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* ports                                                               */

static fragment gen_portatom(cstate *cs, uint32_t off, uint32_t v)
{
    return gen_cmp(cs, OR_TRAN_IPV4, off, BPF_H, v);
}

static fragment gen_portatom6(cstate *cs, uint32_t off, uint32_t v)
{
    return gen_cmp(cs, OR_TRAN_IPV6, off, BPF_H, v);
}

static fragment gen_portop(cstate *cs, uint32_t port, uint32_t proto, int dir)
{
    fragment f, f1, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    f1 = gen_ipfrag(cs);
    frag_and2(cs, &f, f1);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portatom(cs, 0, port);
        break;
    case DQ_DST:
        fa = gen_portatom(cs, 2, port);
        break;
    case DQ_AND:
        fa = gen_portatom(cs, 0, port);
        fb = gen_portatom(cs, 2, port);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portatom(cs, 0, port);
        fb = gen_portatom(cs, 2, port);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_port(cstate *cs, uint32_t port, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portop(cs, port, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portop(cs, port, IPPROTO_SCTP, dir);
        tmp = gen_portop(cs, port, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portop(cs, port, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

static fragment gen_portop6(cstate *cs, uint32_t port, uint32_t proto, int dir)
{
    fragment f, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portatom6(cs, 0, port);
        break;
    case DQ_DST:
        fa = gen_portatom6(cs, 2, port);
        break;
    case DQ_AND:
        fa = gen_portatom6(cs, 0, port);
        fb = gen_portatom6(cs, 2, port);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portatom6(cs, 0, port);
        fb = gen_portatom6(cs, 2, port);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_port6(cstate *cs, uint32_t port, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portop6(cs, port, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portop6(cs, port, IPPROTO_SCTP, dir);
        tmp = gen_portop6(cs, port, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portop6(cs, port, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

static fragment gen_portrangeatom(cstate *cs, uint32_t off, uint32_t v1, uint32_t v2)
{
    fragment f1, f2;

    if (v1 > v2) {
        uint32_t t = v1;
        v1 = v2;
        v2 = t;
    }
    f1 = gen_ncmp(cs, OR_TRAN_IPV4, off, BPF_H, 0xffffffffu, BPF_JGE, 0, v1);
    f2 = gen_ncmp(cs, OR_TRAN_IPV4, off, BPF_H, 0xffffffffu, BPF_JGT, 1, v2);
    frag_and2(cs, &f1, f2);
    return f1;
}

static fragment gen_portrangeatom6(cstate *cs, uint32_t off, uint32_t v1, uint32_t v2)
{
    fragment f1, f2;

    if (v1 > v2) {
        uint32_t t = v1;
        v1 = v2;
        v2 = t;
    }
    f1 = gen_ncmp(cs, OR_TRAN_IPV6, off, BPF_H, 0xffffffffu, BPF_JGE, 0, v1);
    f2 = gen_ncmp(cs, OR_TRAN_IPV6, off, BPF_H, 0xffffffffu, BPF_JGT, 1, v2);
    frag_and2(cs, &f1, f2);
    return f1;
}

static fragment gen_portrangeop(cstate *cs, uint32_t p1, uint32_t p2, uint32_t proto, int dir)
{
    fragment f, f1, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    f1 = gen_ipfrag(cs);
    frag_and2(cs, &f, f1);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portrangeatom(cs, 0, p1, p2);
        break;
    case DQ_DST:
        fa = gen_portrangeatom(cs, 2, p1, p2);
        break;
    case DQ_AND:
        fa = gen_portrangeatom(cs, 0, p1, p2);
        fb = gen_portrangeatom(cs, 2, p1, p2);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portrangeatom(cs, 0, p1, p2);
        fb = gen_portrangeatom(cs, 2, p1, p2);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_portrangeop6(cstate *cs, uint32_t p1, uint32_t p2, uint32_t proto, int dir)
{
    fragment f, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portrangeatom6(cs, 0, p1, p2);
        break;
    case DQ_DST:
        fa = gen_portrangeatom6(cs, 2, p1, p2);
        break;
    case DQ_AND:
        fa = gen_portrangeatom6(cs, 0, p1, p2);
        fb = gen_portrangeatom6(cs, 2, p1, p2);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portrangeatom6(cs, 0, p1, p2);
        fb = gen_portrangeatom6(cs, 2, p1, p2);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_portrange(cstate *cs, uint32_t p1, uint32_t p2, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portrangeop(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portrangeop(cs, p1, p2, IPPROTO_SCTP, dir);
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

static fragment gen_portrange6(cstate *cs, uint32_t p1, uint32_t p2, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portrangeop6(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portrangeop6(cs, p1, p2, IPPROTO_SCTP, dir);
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

fragment gen_port_all(cstate *cs, uint32_t port, int ip_proto, int dir)
{
    fragment f = gen_port6(cs, port, ip_proto, dir);
    fragment f1 = gen_port(cs, port, ip_proto, dir);

    frag_or2(cs, &f, f1);
    return f;
}

fragment gen_portrange_all(cstate *cs, uint32_t p1, uint32_t p2, int ip_proto, int dir)
{
    fragment f = gen_portrange6(cs, p1, p2, ip_proto, dir);
    fragment f1 = gen_portrange(cs, p1, p2, ip_proto, dir);

    frag_or2(cs, &f, f1);
    return f;
}
