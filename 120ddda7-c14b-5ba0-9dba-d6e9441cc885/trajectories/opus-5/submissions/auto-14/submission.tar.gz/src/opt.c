/*
 * opt.c - the block-graph optimizer.
 *
 * The graph is a DAG whose nodes carry a straight-line statement list and a
 * two-way test. Optimization alternates a value-numbering sweep over the
 * blocks (constant folding, redundant load and store removal) with a branch
 * sweep that redirects edges whose outcome is already settled by a test that
 * dominates them. Both run to a fixed point, then structurally identical
 * blocks are merged and the entry block is advanced past anything that no
 * longer decides anything.
 */
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"

#define NOP_CODE 0xffffu
#define VAL_UNKNOWN 0

#define AX_ATOM N_ATOMS

#define HASHSZ 256
#define INTERN_BUCKETS 256
#define JFOLD_BUCKETS 256

typedef struct valnode {
    int             code;
    uint32_t        v0, v1;
    int             val;
    struct valnode *nxt;
} valnode;

typedef struct {
    cstate    *cs;
    blk      **blocks;
    int        n_blocks;
    edge     **edges;
    int        n_edges;
    blk      **levels;
    int        maxlevel;
    int        nodewords, edgewords;
    uint64_t  *dom_space, *edom_space;
    valnode   *vnodes;
    int        nvnodes, maxvnodes;
    struct { int is_const; uint32_t const_val; } *vmap;
    int        curval;
    int        done;
    /*
     * Set by every edge redirection, successor swap and block insertion.
     * Not the same thing as !done: a JSET against no bits redirects an edge
     * without reporting progress, and a folded statement reports progress
     * without touching an edge.
     */
    int        graph_changed;
    int        mark;
    int        natoms;
    int        intern_heads[INTERN_BUCKETS];
    int       *intern_next;
    uint64_t  *jf_masks;        /* one edge bitmap per live fold bucket */
} ostate;

/*
 * Value-number buckets. A bucket whose stamp is not the current one counts
 * as empty, so a round is discarded by bumping the stamp rather than by
 * walking the table.
 */
static struct {
    unsigned  stamp;
    valnode  *head;
} hashtbl[HASHSZ];
static unsigned curstamp;

/* ---------------------------------------------------------------- */
/* bit sets                                                          */

static inline __attribute__((always_inline)) void set_all(uint64_t *s, int words, uint64_t v)
{
    int i;
    for (i = 0; i < words; i++)
        s[i] = v;
}

static inline __attribute__((always_inline)) void set_insert(uint64_t *s, int bit)
{
    s[bit >> 6] |= (uint64_t)1 << (bit & 63);
}

static inline __attribute__((always_inline)) void set_intersect(uint64_t *dst, const uint64_t *src, int words)
{
    int i;
    for (i = 0; i < words; i++)
        dst[i] &= src[i];
}

/* ---------------------------------------------------------------- */
/* graph walking                                                     */

static inline __attribute__((always_inline)) int is_ret(const blk *b)
{
    return BPF_CLASS(b->code) == BPF_RET;
}

/*
 * Preorder walk numbering the reachable blocks. It writes into a buffer that
 * outlives the compile so the count and the numbering can share one walk;
 * the caller sizes the buffer from cs->nblocks, which bounds what is
 * reachable, so nothing here has to check for room.
 */
static blk **dfs_buf;
static int dfs_cap;

static void number_blks(ostate *o, blk *p)
{
    if (p == NULL || p->mark == o->mark)
        return;
    p->mark = o->mark;
    p->id = o->n_blocks;
    dfs_buf[o->n_blocks++] = p;
    if (!is_ret(p)) {
        number_blks(o, p->jt);
        number_blks(o, p->jf);
    }
}

static int dfs_reserve(int n)
{
    blk **nb;

    if (n <= dfs_cap)
        return 1;
    nb = (blk **)realloc(dfs_buf, sizeof(blk *) * (size_t)n);
    if (nb == NULL)
        return 0;
    dfs_buf = nb;
    dfs_cap = n;
    return 1;
}

static void find_levels_r(ostate *o, blk *b)
{
    int level;

    if (b->mark == o->mark)
        return;
    b->mark = o->mark;
    b->link = NULL;

    if (!is_ret(b)) {
        find_levels_r(o, b->jt);
        find_levels_r(o, b->jf);
        level = b->jt->level;
        if (b->jf->level > level)
            level = b->jf->level;
        level++;
    } else {
        level = 0;
    }
    b->level = level;
    b->link = o->levels[level];
    o->levels[level] = b;
}

static void find_levels(ostate *o, blk *root)
{
    memset(o->levels, 0, sizeof(blk *) * (size_t)(o->n_blocks + 1));
    o->mark++;
    find_levels_r(o, root);
    o->maxlevel = root->level;
}

static void find_dom(ostate *o, blk *root)
{
    int i;
    blk *b;

    set_all(o->dom_space, o->nodewords * o->n_blocks, ~(uint64_t)0);
    set_all(root->dom, o->nodewords, 0);

    if (o->nodewords == 1) {
        for (i = o->maxlevel; i >= 0; --i) {
            for (b = o->levels[i]; b != NULL; b = b->link) {
                uint64_t d = b->dom[0] | ((uint64_t)1 << b->id);

                b->dom[0] = d;
                if (is_ret(b))
                    continue;
                b->jt->dom[0] &= d;
                b->jf->dom[0] &= d;
            }
        }
        return;
    }

    for (i = o->maxlevel; i >= 0; --i) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            set_insert(b->dom, b->id);
            if (is_ret(b))
                continue;
            set_intersect(b->jt->dom, b->dom, o->nodewords);
            set_intersect(b->jf->dom, b->dom, o->nodewords);
        }
    }
}

static void find_edom(ostate *o, blk *root)
{
    int i;
    blk *b;

    set_all(o->edom_space, o->edgewords * o->n_edges, ~(uint64_t)0);
    /* Padding bits past n_edges would otherwise be walked by opt_j. */
    if (o->n_edges % 64 != 0) {
        uint64_t m = ((uint64_t)1 << (o->n_edges % 64)) - 1u;
        uint64_t *p = o->edom_space + o->edgewords - 1;
        for (i = 0; i < o->n_edges; i++, p += o->edgewords)
            *p &= m;
    }
    set_all(root->et.edom, o->edgewords, 0);
    set_all(root->ef.edom, o->edgewords, 0);

    if (o->edgewords == 1) {
        for (i = o->maxlevel; i >= 0; --i) {
            for (b = o->levels[i]; b != NULL; b = b->link) {
                uint64_t dt, df;

                if (is_ret(b))
                    continue;
                dt = b->et.edom[0] | ((uint64_t)1 << b->et.id);
                df = b->ef.edom[0] | ((uint64_t)1 << b->ef.id);
                b->et.edom[0] = dt;
                b->ef.edom[0] = df;
                if (!is_ret(b->jt)) {
                    b->jt->et.edom[0] &= dt;
                    b->jt->ef.edom[0] &= dt;
                }
                if (!is_ret(b->jf)) {
                    b->jf->et.edom[0] &= df;
                    b->jf->ef.edom[0] &= df;
                }
            }
        }
        return;
    }

    for (i = o->maxlevel; i >= 0; --i) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            if (is_ret(b))
                continue;
            set_insert(b->et.edom, b->et.id);
            set_insert(b->ef.edom, b->ef.id);
            if (!is_ret(b->jt)) {
                set_intersect(b->jt->et.edom, b->et.edom, o->edgewords);
                set_intersect(b->jt->ef.edom, b->et.edom, o->edgewords);
            }
            if (!is_ret(b->jf)) {
                set_intersect(b->jf->et.edom, b->ef.edom, o->edgewords);
                set_intersect(b->jf->ef.edom, b->ef.edom, o->edgewords);
            }
        }
    }
}


/* ---------------------------------------------------------------- */
/* atoms                                                             */

/*
 * Atom read and written by each opcode. AT_MEM stands for "the scratch slot
 * named by k"; the tables are indexed by the low byte of the opcode.
 */
#define AT_NONE (-1)
#define AT_MEM  (-2)

static signed char use_tab[256], def_tab[256];
static int atom_tabs_built;

static void build_atom_tabs(void)
{
    int c;

    for (c = 0; c < 256; c++) {
        int u = AT_NONE, d = AT_NONE;

        switch (BPF_CLASS(c)) {
        case BPF_LD:
            if (BPF_MODE(c) == BPF_IND)
                u = X_ATOM;
            else if (BPF_MODE(c) == BPF_MEM)
                u = AT_MEM;
            d = A_ATOM;
            break;

        case BPF_LDX:
            if (BPF_MODE(c) == BPF_MEM)
                u = AT_MEM;
            d = X_ATOM;
            break;

        case BPF_ST:
            u = A_ATOM;
            d = AT_MEM;
            break;

        case BPF_STX:
            u = X_ATOM;
            d = AT_MEM;
            break;

        case BPF_JMP:
            u = BPF_SRC(c) == BPF_X ? AX_ATOM : A_ATOM;
            break;

        case BPF_ALU:
            u = BPF_SRC(c) == BPF_X ? AX_ATOM : A_ATOM;
            d = A_ATOM;
            break;

        case BPF_MISC:
            if (BPF_MISCOP(c) == BPF_TXA) {
                u = X_ATOM;
                d = A_ATOM;
            } else {
                u = A_ATOM;
                d = X_ATOM;
            }
            break;

        default:
            break;
        }
        use_tab[c] = (signed char)u;
        def_tab[c] = (signed char)d;
    }
    atom_tabs_built = 1;
}

/* the atom a statement reads, -1 for none, AX_ATOM for both A and X */
static int atomuse(const stmt *s)
{
    int a;

    if (s->code == NOP_CODE)
        return -1;
    a = use_tab[s->code & 0xff];
    return a == AT_MEM ? MEM_ATOM(s->k) : a;
}

/* the atom a statement writes, -1 for none */
static int atomdef(const stmt *s)
{
    int a;

    if (s->code == NOP_CODE)
        return -1;
    a = def_tab[s->code & 0xff];
    return a == AT_MEM ? MEM_ATOM(s->k) : a;
}

static int lowest_bit(uint32_t t)
{
#if defined(__GNUC__)
    return __builtin_ctz(t);
#else
    int bit = 0;

    while ((t >>= 1) != 0)
        bit++;
    return bit;
#endif
}

#define ATOMMASK(n) ((uint32_t)1 << (n))
#define ATOMELEM(d, n) (((d) & ATOMMASK(n)) != 0)

static void compute_local_ud(blk *b)
{
    uint32_t def = 0, use = 0, killed = 0;
    stmt *s;
    int atom;

    for (s = b->head_s; s != NULL; s = s->nxt) {
        atom = atomuse(s);
        if (atom >= 0) {
            if (atom == AX_ATOM) {
                if (!ATOMELEM(def, X_ATOM))
                    use |= ATOMMASK(X_ATOM);
                if (!ATOMELEM(def, A_ATOM))
                    use |= ATOMMASK(A_ATOM);
            } else if (!ATOMELEM(def, atom)) {
                use |= ATOMMASK(atom);
            }
        }
        atom = atomdef(s);
        if (atom >= 0) {
            if (!ATOMELEM(use, atom))
                killed |= ATOMMASK(atom);
            def |= ATOMMASK(atom);
        }
    }
    b->def = def;
    b->use = use;
    b->kill = killed;

    /* the block's own test reads the accumulator after the statements run */
    b->test_use = 0;
    if (!is_ret(b)) {
        b->test_use = ATOMMASK(A_ATOM);
        if (BPF_SRC(b->code) == BPF_X)
            b->test_use |= ATOMMASK(X_ATOM);
    }
    b->out_use = 0;
}

static void find_ud(ostate *o, blk *root)
{
    int i;
    blk *b;

    (void)root;
    for (i = 0; i < o->n_blocks; i++)
        compute_local_ud(o->blocks[i]);

    for (i = 0; i <= o->maxlevel; i++) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            if (!is_ret(b))
                b->out_use = b->jt->in_use | b->jf->in_use;
            b->in_use = b->use |
                        ((b->out_use | b->test_use) & ~b->kill);
        }
    }
}

static void find_inedges(ostate *o, blk *root)
{
    int i;
    blk *b;

    (void)root;
    for (i = 0; i < o->n_blocks; i++)
        o->blocks[i]->in_edges = NULL;

    for (i = o->maxlevel; i >= 0; --i) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            if (is_ret(b))
                continue;
            b->et.nxt = b->jt->in_edges;
            b->jt->in_edges = &b->et;
            b->ef.nxt = b->jf->in_edges;
            b->jf->in_edges = &b->ef;
        }
    }
}

/* ---------------------------------------------------------------- */
/* value numbering                                                   */

static void init_val(ostate *o)
{
    curstamp++;
    o->curval = 0;
    o->nvnodes = 0;
    o->vmap[VAL_UNKNOWN].is_const = 0;
}

static int vn(ostate *o, int code, uint32_t v0, uint32_t v1)
{
    unsigned hash;
    valnode *p;
    int val;

    hash = (unsigned)code * 2654435761u + v0 * 2246822519u + v1 * 3266489917u;
    hash = (hash ^ (hash >> 15)) & (HASHSZ - 1);
    if (hashtbl[hash].stamp == curstamp) {
        for (p = hashtbl[hash].head; p != NULL; p = p->nxt)
            if (p->code == code && p->v0 == v0 && p->v1 == v1)
                return p->val;
    }

    if (o->curval + 1 >= o->maxvnodes || o->nvnodes >= o->maxvnodes)
        return VAL_UNKNOWN;
    val = ++o->curval;
    if (BPF_MODE(code) == BPF_IMM &&
        (BPF_CLASS(code) == BPF_LD || BPF_CLASS(code) == BPF_LDX)) {
        o->vmap[val].const_val = v0;
        o->vmap[val].is_const = 1;
    } else {
        o->vmap[val].is_const = 0;
    }
    p = &o->vnodes[o->nvnodes++];
    p->val = val;
    p->code = code;
    p->v0 = v0;
    p->v1 = v1;
    if (hashtbl[hash].stamp == curstamp) {
        p->nxt = hashtbl[hash].head;
    } else {
        p->nxt = NULL;
        hashtbl[hash].stamp = curstamp;
    }
    hashtbl[hash].head = p;
    return val;
}

static int vconst(ostate *o, uint32_t k)
{
    return vn(o, BPF_LD | BPF_IMM, k, 0);
}

static int is_const(ostate *o, int v)
{
    return v != VAL_UNKNOWN && v < o->maxvnodes && o->vmap[v].is_const;
}

static void vstore(ostate *o, stmt *s, int *valp, int newval, int alter)
{
    if (alter && *valp == newval && newval != VAL_UNKNOWN) {
        s->code = NOP_CODE;
        o->done = 0;
    } else {
        *valp = newval;
    }
}

static uint32_t fold_alu(int op, uint32_t a, uint32_t b, int *ok)
{
    *ok = 1;
    switch (op) {
    case BPF_ADD: return a + b;
    case BPF_SUB: return a - b;
    case BPF_MUL: return a * b;
    case BPF_DIV:
        if (b == 0) { *ok = 0; return 0; }
        return a / b;
    case BPF_AND: return a & b;
    case BPF_OR:  return a | b;
    case BPF_XOR: return a ^ b;
    case BPF_LSH: return b < 32 ? a << b : 0;
    case BPF_RSH: return b < 32 ? a >> b : 0;
    }
    *ok = 0;
    return 0;
}

static void opt_stmt(ostate *o, stmt *s, int val[], int alter)
{
    int op, v, v0, v1, ok;
    uint32_t r;

    if (s->code == NOP_CODE)
        return;

    switch (BPF_CLASS(s->code)) {
    case BPF_LD:
        switch (BPF_MODE(s->code)) {
        case BPF_IMM:
            v = vconst(o, s->k);
            vstore(o, s, &val[A_ATOM], v, alter);
            break;

        case BPF_MEM:
            v = val[MEM_ATOM(s->k)];
            if (alter && is_const(o, v)) {
                s->code = BPF_LD | BPF_IMM;
                s->k = o->vmap[v].const_val;
                o->done = 0;
            }
            vstore(o, s, &val[A_ATOM], v, alter);
            break;

        case BPF_IND:
            v = val[X_ATOM];
            if (alter && is_const(o, v)) {
                s->code = (uint16_t)(BPF_LD | BPF_ABS | BPF_SIZE(s->code));
                s->k += o->vmap[v].const_val;
                v = vn(o, (int)s->code, s->k, 0);
                o->done = 0;
            } else {
                v = vn(o, (int)s->code, s->k, (uint32_t)v);
            }
            vstore(o, s, &val[A_ATOM], v, alter);
            break;

        default:
            v = vn(o, (int)s->code, s->k, 0);
            vstore(o, s, &val[A_ATOM], v, alter);
            break;
        }
        break;

    case BPF_LDX:
        switch (BPF_MODE(s->code)) {
        case BPF_IMM:
            v = vconst(o, s->k);
            vstore(o, s, &val[X_ATOM], v, alter);
            break;

        case BPF_MEM:
            v = val[MEM_ATOM(s->k)];
            if (alter && is_const(o, v)) {
                s->code = BPF_LDX | BPF_IMM;
                s->k = o->vmap[v].const_val;
                o->done = 0;
            }
            vstore(o, s, &val[X_ATOM], v, alter);
            break;

        default:
            v = vn(o, (int)s->code, s->k, 0);
            vstore(o, s, &val[X_ATOM], v, alter);
            break;
        }
        break;

    case BPF_ST:
        vstore(o, s, &val[MEM_ATOM(s->k)], val[A_ATOM], alter);
        break;

    case BPF_STX:
        vstore(o, s, &val[MEM_ATOM(s->k)], val[X_ATOM], alter);
        break;

    case BPF_ALU:
        op = BPF_OP(s->code);
        if (op == BPF_NEG) {
            v = val[A_ATOM];
            if (alter && is_const(o, v)) {
                s->code = BPF_LD | BPF_IMM;
                /* Negate in unsigned: -(int32_t)INT32_MIN is undefined. */
                s->k = (uint32_t)0 - o->vmap[v].const_val;
                val[A_ATOM] = vconst(o, s->k);
                o->done = 0;
            } else {
                val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v, 0);
            }
            break;
        }
        if (BPF_SRC(s->code) == BPF_K) {
            v = val[A_ATOM];
            if (alter && is_const(o, v)) {
                r = fold_alu(op, o->vmap[v].const_val, s->k, &ok);
                if (ok) {
                    s->code = BPF_LD | BPF_IMM;
                    s->k = r;
                    val[A_ATOM] = vconst(o, r);
                    o->done = 0;
                    break;
                }
            }
            val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v, (uint32_t)vconst(o, s->k));
            break;
        }
        v0 = val[A_ATOM];
        v1 = val[X_ATOM];
        if (alter && is_const(o, v0) && is_const(o, v1)) {
            r = fold_alu(op, o->vmap[v0].const_val, o->vmap[v1].const_val, &ok);
            if (ok) {
                s->code = BPF_LD | BPF_IMM;
                s->k = r;
                val[A_ATOM] = vconst(o, r);
                o->done = 0;
                break;
            }
        }
        if (alter && is_const(o, v1)) {
            s->code = (uint16_t)(BPF_ALU | op | BPF_K);
            s->k = o->vmap[v1].const_val;
            o->done = 0;
            val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v0,
                             (uint32_t)vconst(o, s->k));
            break;
        }
        val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v0, (uint32_t)v1);
        break;

    case BPF_MISC:
        if (BPF_MISCOP(s->code) == BPF_TAX)
            vstore(o, s, &val[X_ATOM], val[A_ATOM], alter);
        else
            vstore(o, s, &val[A_ATOM], val[X_ATOM], alter);
        break;
    }
}

static uint32_t test_use_of(const blk *b)
{
    uint32_t m;

    if (is_ret(b))
        return 0;
    m = ATOMMASK(A_ATOM);
    if (BPF_SRC(b->code) == BPF_X)
        m |= ATOMMASK(X_ATOM);
    return m;
}

static void opt_deadstores(ostate *o, blk *b)
{
    stmt *last[N_ATOMS];
    stmt *s;
    int atom;
    uint32_t live = b->out_use | test_use_of(b);
    uint32_t held = 0;

    for (s = b->head_s; s != NULL; s = s->nxt) {
        if (s->code == NOP_CODE)
            continue;
        atom = atomuse(s);
        if (atom >= 0) {
            if (atom == AX_ATOM)
                held &= ~(ATOMMASK(X_ATOM) | ATOMMASK(A_ATOM));
            else
                held &= ~ATOMMASK(atom);
        }
        atom = atomdef(s);
        if (atom >= 0) {
            if (ATOMELEM(held, (unsigned)atom)) {
                last[atom]->code = NOP_CODE;
                o->done = 0;
            }
            last[atom] = s;
            held |= ATOMMASK(atom);
        }
    }
    for (held &= ~live; held != 0; held &= held - 1) {
        atom = lowest_bit(held);
        last[atom]->code = NOP_CODE;
        o->done = 0;
    }
}

/* skip over removed statements */
static stmt *this_op(stmt *s)
{
    while (s != NULL && s->code == NOP_CODE)
        s = s->nxt;
    return s;
}

static void opt_not(ostate *o, blk *b)
{
    blk *t = b->jt;

    b->jt = b->jf;
    b->jf = t;
    o->graph_changed = 1;
}

static void opt_peep(ostate *o, blk *b)
{
    stmt *s, *next, *last;
    int val;

    s = this_op(b->head_s);
    if (s == NULL)
        goto tests;

    last = s;
    for (;;) {
        s = this_op(s);
        if (s == NULL)
            break;
        next = this_op(s->nxt);
        if (next == NULL)
            break;
        last = next;

        /* a store followed by loading it into X is a copy */
        if (s->code == BPF_ST && next->code == (BPF_LDX | BPF_MEM) &&
            s->k == next->k) {
            o->done = 0;
            next->code = BPF_MISC | BPF_TAX;
        }

        /* loading a constant only to copy it into X loads X directly */
        if (s->code == (BPF_LD | BPF_IMM) && next->code == (BPF_MISC | BPF_TAX)) {
            s->code = BPF_LDX | BPF_IMM;
            next->code = BPF_MISC | BPF_TXA;
            o->done = 0;
        }

        /*
         * A constant added into the index register only to index a load
         * belongs in the load's own offset:
         *
         *   ld #k / [ldx] / add x / tax / ld [x + k2]
         * becomes
         *   [ldx] / ld [x + k + k2]
         */
        if (s->code == (BPF_LD | BPF_IMM) && !ATOMELEM(b->out_use, X_ATOM)) {
            stmt *add, *tax, *ild;

            add = next;
            if (add->code == (BPF_LDX | BPF_MSH | BPF_B))
                add = this_op(add->nxt);
            if (add != NULL && add->code == (BPF_ALU | BPF_ADD | BPF_X)) {
                tax = this_op(add->nxt);
                if (tax != NULL && tax->code == (BPF_MISC | BPF_TAX)) {
                    ild = this_op(tax->nxt);
                    if (ild != NULL && BPF_CLASS(ild->code) == BPF_LD &&
                        BPF_MODE(ild->code) == BPF_IND) {
                        ild->k += s->k;
                        s->code = NOP_CODE;
                        add->code = NOP_CODE;
                        tax->code = NOP_CODE;
                        o->done = 0;
                    }
                }
            }
        }

        s = next;
    }

    if (is_ret(b))
        return;

    /*
     * The value left in the accumulator is dead, so the last operation
     * feeding an equality test can often be folded into the test.
     */
    if (b->code == (BPF_JMP | BPF_JEQ | BPF_K) && !ATOMELEM(b->out_use, A_ATOM)) {
        if (last->code == (BPF_ALU | BPF_SUB | BPF_X)) {
            val = b->val[X_ATOM];
            if (is_const(o, val)) {
                b->k += o->vmap[val].const_val;
                last->code = NOP_CODE;
                o->done = 0;
            } else if (b->k == 0) {
                last->code = NOP_CODE;
                b->code = BPF_JMP | BPF_JEQ | BPF_X;
                o->done = 0;
            }
        } else if (last->code == (BPF_ALU | BPF_SUB | BPF_K)) {
            b->k += last->k;
            last->code = NOP_CODE;
            o->done = 0;
        } else if (last->code == (BPF_ALU | BPF_AND | BPF_K) && b->k == 0) {
            b->k = last->k;
            b->code = BPF_JMP | BPF_JSET | BPF_K;
            last->code = NOP_CODE;
            o->done = 0;
            opt_not(o, b);
        }
    }

tests:
    if (is_ret(b))
        return;

    /* a bit test against no bits, or against every bit, is settled */
    if (b->code == (BPF_JMP | BPF_JSET | BPF_K)) {
        if (b->k == 0 && b->jt != b->jf) {
            b->jt = b->jf;
            o->graph_changed = 1;
        }
        if (b->k == 0xffffffffu && b->jf != b->jt) {
            b->jf = b->jt;
            o->graph_changed = 1;
        }
    }

    /* comparing against a known index register compares against a constant */
    val = b->val[X_ATOM];
    if (BPF_SRC(b->code) == BPF_X && is_const(o, val)) {
        b->code = (uint16_t)(b->code & ~BPF_X);
        b->k = o->vmap[val].const_val;
        o->done = 0;
    }

    /* if the accumulator is known the test can be settled outright */
    val = b->val[A_ATOM];
    if (BPF_SRC(b->code) == BPF_K && is_const(o, val)) {
        uint32_t v = o->vmap[val].const_val;
        int taken;

        switch (BPF_OP(b->code)) {
        case BPF_JEQ:  taken = (v == b->k); break;
        case BPF_JGT:  taken = (v > b->k); break;
        case BPF_JGE:  taken = (v >= b->k); break;
        case BPF_JSET: taken = ((v & b->k) != 0); break;
        default: return;
        }
        if (b->jf != b->jt) {
            o->done = 0;
            o->graph_changed = 1;
        }
        if (taken)
            b->jf = b->jt;
        else
            b->jt = b->jf;
    }
}

static void opt_blk(ostate *o, blk *b, int do_stmts)
{
    stmt *s;
    edge *p;
    int i, aval, xval;

    p = b->in_edges;
    if (p == NULL) {
        for (i = 0; i < o->natoms; i++)
            b->val[i] = 0;
    } else {
        const int *pv = p->pred->val;

        for (i = 0; i < o->natoms; i++)
            b->val[i] = pv[i];
        while ((p = p->nxt) != NULL) {
            pv = p->pred->val;
            for (i = 0; i < o->natoms; i++)
                if (b->val[i] != pv[i])
                    b->val[i] = VAL_UNKNOWN;
        }
    }
    aval = b->val[A_ATOM];
    xval = b->val[X_ATOM];
    for (s = b->head_s; s != NULL; s = s->nxt)
        opt_stmt(o, s, b->val, do_stmts);

    /*
     * A block that leaves nothing behind and reloads what was already
     * there does not need its statements at all.
     */
    if (do_stmts &&
        ((b->out_use == 0 &&
          aval != VAL_UNKNOWN && b->val[A_ATOM] == aval &&
          xval != VAL_UNKNOWN && b->val[X_ATOM] == xval) ||
         is_ret(b))) {
        if (b->head_s != NULL) {
            b->head_s = NULL;
            b->tail_s = NULL;
            o->done = 0;
        }
    } else {
        opt_peep(o, b);
        opt_deadstores(o, b);
    }

    if (is_ret(b))
        return;

    if (BPF_SRC(b->code) == BPF_K)
        b->oval = (uint32_t)vconst(o, b->k);
    else
        b->oval = (uint32_t)b->val[X_ATOM];
    b->et.code = (int)b->code;
    b->ef.code = -(int)b->code;
}

/* ---------------------------------------------------------------- */
/* branch optimization                                               */

/*
 * If the test in "child" is already settled by the test the edge came
 * out of, return the successor the child would take.
 */
static blk *fold_edge(blk *child, edge *ep)
{
    int sense;
    int code = ep->code;
    uint32_t aval0, aval1, oval0, oval1;

    if (code < 0) {
        code = -code;
        sense = 0;
    } else {
        sense = 1;
    }

    if (is_ret(child) || (int)child->code != code)
        return NULL;

    aval0 = (uint32_t)child->val[A_ATOM];
    oval0 = child->oval;
    aval1 = (uint32_t)ep->pred->val[A_ATOM];
    oval1 = ep->pred->oval;

    if (aval0 != aval1 || aval0 == VAL_UNKNOWN)
        return NULL;

    if (oval0 == oval1)
        return sense ? child->jt : child->jf;

    if (sense && code == (BPF_JMP | BPF_JEQ | BPF_K))
        return child->jf;

    return NULL;
}

static int use_conflict_set(blk *b, blk *succ, uint32_t use)
{
    for (; use != 0; use &= use - 1) {
        int atom = lowest_bit(use);

        if (b->val[atom] != succ->val[atom])
            return 1;
    }
    return 0;
}

static int use_conflict(blk *b, blk *succ)
{
    return use_conflict_set(b, succ, succ->in_use);
}

static int set_member(const uint64_t *s, int bit)
{
    return (s[bit >> 6] & ((uint64_t)1 << (bit & 63))) != 0;
}

/*
 * fold_edge only ever succeeds against an edge whose test opcode and A value
 * match the child's, so the candidates are bucketed on that pair. Buckets are
 * in ascending edge order, which is the order the dominator set was scanned
 * in, so the edge picked here is the one a full scan would have picked.
 */
static uint32_t jkey(int code, int aval)
{
    return ((uint32_t)code * 2654435761u + (uint32_t)aval * 40503u) %
           JFOLD_BUCKETS;
}

static unsigned it_stamp[INTERN_BUCKETS];
static unsigned it_gen;

static unsigned jf_stamp[JFOLD_BUCKETS];
static int      jf_slot[JFOLD_BUCKETS];
static unsigned jf_gen;

static void build_jfold(ostate *o)
{
    int i, nslots = 0;

    if (++jf_gen == 0) {
        memset(jf_stamp, 0, sizeof(jf_stamp));
        jf_gen = 1;
    }
    for (i = 0; i < o->n_blocks; i++) {
        blk *b = o->blocks[i];
        uint64_t *m;
        uint32_t h;

        if (is_ret(b))
            continue;
        h = jkey((int)b->code, b->val[A_ATOM]);
        if (jf_stamp[h] != jf_gen) {
            jf_stamp[h] = jf_gen;
            jf_slot[h] = nslots++;
            memset(o->jf_masks + (size_t)jf_slot[h] * (size_t)o->edgewords, 0,
                   sizeof(uint64_t) * (size_t)o->edgewords);
        }
        m = o->jf_masks + (size_t)jf_slot[h] * (size_t)o->edgewords;
        m[(2 * i) >> 6] |= (uint64_t)3 << ((2 * i) & 63);
    }
}

static void opt_j(ostate *o, edge *ep)
{
    int k;
    blk *child, *target;

    if (is_ret(*ep->succp))
        return;

    if ((*ep->succp)->jt == (*ep->succp)->jf) {
        /*
         * The successor no longer decides anything, so the edge can go
         * straight where it would have gone.
         */
        if (!use_conflict(ep->pred, (*ep->succp)->jt)) {
            o->done = 0;
            o->graph_changed = 1;
            *ep->succp = (*ep->succp)->jt;
        }
    }

top:
    child = *ep->succp;
    if (is_ret(child) || child->val[A_ATOM] == VAL_UNKNOWN)
        return;
    {
        uint32_t h = jkey((int)child->code, child->val[A_ATOM]);
        const uint64_t *m;
        int w;

        if (jf_stamp[h] != jf_gen)
            return;
        m = o->jf_masks + (size_t)jf_slot[h] * (size_t)o->edgewords;
        for (w = 0; w < o->edgewords; w++) {
            uint64_t bits = m[w] & ep->edom[w];

            while (bits != 0) {
                k = w * 64 + __builtin_ctzll(bits);
                bits &= bits - 1;
                target = fold_edge(child, o->edges[k]);
                if (target != NULL && !use_conflict(ep->pred, target)) {
                    o->done = 0;
                    o->graph_changed = 1;
                    *ep->succp = target;
                    if (!is_ret(target))
                        goto top;
                    return;
                }
            }
        }
    }
}

/*
 * A test repeated further down a chain of alternatives can be hoisted to the
 * front of that chain, which shortens the chain for the packets that match it.
 * "or" chains link through the false branch, "and" chains through the true one.
 */
static void pullup(ostate *o, blk *b, int is_or)
{
    blk **diffp, **samep, *pull;
    edge *ep;
    int val, at_top;

    ep = b->in_edges;
    if (ep == NULL)
        return;

    val = b->in_edges->pred->val[A_ATOM];
    if (val == VAL_UNKNOWN)
        return;
    for (ep = ep->nxt; ep != NULL; ep = ep->nxt)
        if (val != ep->pred->val[A_ATOM])
            return;

    if (b->in_edges->pred->jt == b)
        diffp = &b->in_edges->pred->jt;
    else
        diffp = &b->in_edges->pred->jf;

    at_top = 1;
    for (;;) {
        blk *d = *diffp;

        if (d == NULL || is_ret(d))
            return;
        if (is_or ? (d->jt != b->jt) : (d->jf != b->jf))
            return;
        if (!set_member(d->dom, b->id))
            return;
        if (d->val[A_ATOM] != val)
            break;
        diffp = is_or ? &d->jf : &d->jt;
        at_top = 0;
    }

    samep = is_or ? &(*diffp)->jf : &(*diffp)->jt;
    for (;;) {
        blk *s = *samep;

        if (s == NULL || is_ret(s))
            return;
        if (is_or ? (s->jt != b->jt) : (s->jf != b->jf))
            return;
        if (!set_member(s->dom, b->id))
            return;
        if (s->val[A_ATOM] == val)
            break;
        samep = is_or ? &s->jf : &s->jt;
    }

    pull = *samep;
    if (is_or) {
        *samep = pull->jf;
        pull->jf = *diffp;
    } else {
        *samep = pull->jt;
        pull->jt = *diffp;
    }

    if (at_top) {
        for (ep = b->in_edges; ep != NULL; ep = ep->nxt) {
            if (ep->pred->jt == b)
                ep->pred->jt = pull;
            else
                ep->pred->jf = pull;
        }
    } else {
        *diffp = pull;
    }
    o->done = 0;
    o->graph_changed = 1;
}

static void opt_blks(ostate *o, blk *root, int do_stmts)
{
    int i;
    blk *p;

    init_val(o);
    find_inedges(o, root);

    for (i = o->maxlevel; i >= 0; --i)
        for (p = o->levels[i]; p != NULL; p = p->link)
            opt_blk(o, p, do_stmts);

    if (do_stmts) {
        /*
         * The root's own edges cannot be improved by a dominating test,
         * since nothing dominates them.
         */
        build_jfold(o);
        for (i = 1; i <= o->maxlevel; i++) {
            for (p = o->levels[i]; p != NULL; p = p->link) {
                if (is_ret(p))
                    continue;
                opt_j(o, &p->et);
                opt_j(o, &p->ef);
            }
        }

        find_inedges(o, root);
        for (i = 1; i <= o->maxlevel; i++) {
            for (p = o->levels[i]; p != NULL; p = p->link) {
                pullup(o, p, 1);
                pullup(o, p, 0);
            }
        }
    }
}

/* ---------------------------------------------------------------- */
/* block merging                                                     */

static int eq_stmts(stmt *a, stmt *b)
{
    a = this_op(a);
    b = this_op(b);
    while (a != NULL && b != NULL) {
        if (a->code != b->code || a->k != b->k)
            return 0;
        a = this_op(a->nxt);
        b = this_op(b->nxt);
    }
    return a == b;
}

static int eq_blk(blk *a, blk *b)
{
    if (a->code != b->code || a->k != b->k)
        return 0;
    if (is_ret(a))
        return eq_stmts(a->head_s, b->head_s);
    if (a->jt != b->jt || a->jf != b->jf)
        return 0;
    return eq_stmts(a->head_s, b->head_s);
}

static void mark_code(ostate *o, blk *p)
{
    if (p == NULL || p->mark == o->mark)
        return;
    p->mark = o->mark;
    if (!is_ret(p)) {
        mark_code(o, p->jt);
        mark_code(o, p->jf);
    }
}

static uint32_t blk_hash(blk *p)
{
    uint32_t h = (uint32_t)p->code * 2654435761u + (uint32_t)p->k;
    stmt *s;

    if (!is_ret(p))
        h = h * 31u + (uint32_t)((uintptr_t)p->jt >> 4) +
            (uint32_t)((uintptr_t)p->jf >> 4) * 40503u;
    for (s = this_op(p->head_s); s != NULL; s = this_op(s->nxt))
        h = h * 16777619u + (uint32_t)s->code * 31u + (uint32_t)s->k;
    return h;
}

/*
 * Duplicate blocks are found by hash bucket rather than by an all-pairs scan;
 * bucket lists are kept in ascending block order so the block each duplicate
 * is linked to is the same one the all-pairs scan would have picked.
 */
static void intern_blocks(ostate *o, blk **rootp)
{
    blk *p;
    int i, j, done1;
    int *heads = o->intern_heads, *nxt = o->intern_next;

    for (;;) {
        done1 = 1;
        for (i = 0; i < o->n_blocks; i++)
            o->blocks[i]->link = NULL;

        o->mark++;
        mark_code(o, *rootp);

        if (++it_gen == 0) {
            memset(it_stamp, 0, sizeof(it_stamp));
            it_gen = 1;
        }
        for (i = o->n_blocks - 1; i >= 0; --i) {
            p = o->blocks[i];
            if (p->mark != o->mark)
                continue;
            j = (int)(blk_hash(p) % INTERN_BUCKETS);
            if (it_stamp[j] != it_gen) {
                it_stamp[j] = it_gen;
                nxt[i] = -1;
            } else {
                nxt[i] = heads[j];
            }
            heads[j] = i;
        }

        for (i = o->n_blocks - 1; i >= 0; --i) {
            p = o->blocks[i];
            if (p->mark != o->mark || p->link != NULL)
                continue;
            for (j = nxt[i]; j >= 0; j = nxt[j]) {
                blk *q = o->blocks[j];

                if (q->link != NULL)
                    continue;
                if (eq_blk(p, q)) {
                    q->link = p;
                    done1 = 0;
                }
            }
        }
        for (i = 0; i < o->n_blocks; i++) {
            p = o->blocks[i];
            if (p->mark != o->mark || is_ret(p))
                continue;
            if (p->jt->link != NULL)
                p->jt = p->jt->link;
            if (p->jf->link != NULL)
                p->jf = p->jf->link;
        }
        if ((*rootp)->link != NULL)
            *rootp = (*rootp)->link;
        if (done1)
            break;
    }
}

static void sappend(blk *b, stmt *s)
{
    stmt *t;

    if (s == NULL)
        return;
    for (t = s; t->nxt != NULL; t = t->nxt)
        ;
    t->nxt = b->head_s;
    if (b->head_s == NULL)
        b->tail_s = t;
    b->head_s = s;
}

static void opt_root(blk **rootp)
{
    stmt *s;

    s = (*rootp)->head_s;
    (*rootp)->head_s = NULL;
    (*rootp)->tail_s = NULL;

    while (!is_ret(*rootp) && (*rootp)->jt == (*rootp)->jf)
        *rootp = (*rootp)->jt;

    sappend(*rootp, s);

    if (is_ret(*rootp)) {
        (*rootp)->head_s = NULL;
        (*rootp)->tail_s = NULL;
    }
}

/* drop the statements the optimizer removed */
static void strip_nops(ostate *o)
{
    int i;

    for (i = 0; i < o->n_blocks; i++) {
        blk *b = o->blocks[i];
        stmt *s, *prev = NULL;

        for (s = b->head_s; s != NULL; s = s->nxt) {
            if (s->code == NOP_CODE) {
                if (prev == NULL)
                    b->head_s = s->nxt;
                else
                    prev->nxt = s->nxt;
            } else {
                prev = s;
            }
        }
        b->tail_s = prev;
    }
}

/* ---------------------------------------------------------------- */

blk *bpf_optimize(cstate *cs, blk *root)
{
    ostate o;
    int i, n, pass, lv_valid, ud_valid, dom_valid;

    o.cs = cs;
    o.n_blocks = 0;
    o.nvnodes = 0;
    o.curval = 0;
    o.maxlevel = 0;
    o.done = 1;
    o.mark = 1000000;

    if (!dfs_reserve(cs->nblocks + 1))
        return root;
    o.mark++;
    number_blks(&o, root);
    n = o.n_blocks;
    if (n <= 0)
        return root;
    o.blocks = dfs_buf;

    /*
     * Value tracking only ever touches A, X and the scratch slots the
     * program actually names; nothing below introduces a new slot.
     */
    if (!atom_tabs_built)
        build_atom_tabs();

    o.natoms = 2;
    for (i = 0; i < o.n_blocks; i++) {
        stmt *s;

        for (s = o.blocks[i]->head_s; s != NULL; s = s->nxt) {
            int cls = BPF_CLASS(s->code);

            if (cls == BPF_ST || cls == BPF_STX ||
                ((cls == BPF_LD || cls == BPF_LDX) &&
                 BPF_MODE(s->code) == BPF_MEM)) {
                int a = MEM_ATOM(s->k) + 1;

                if (a > o.natoms)
                    o.natoms = a;
            }
        }
    }
    if (o.natoms > N_ATOMS)
        o.natoms = N_ATOMS;

    o.n_edges = 2 * o.n_blocks;
    o.edges = (edge **)cs_alloc(cs, sizeof(edge *) * (size_t)o.n_edges);
    o.levels = (blk **)cs_alloc(cs, sizeof(blk *) * (size_t)(o.n_blocks + 1));
    o.nodewords = (o.n_blocks + 63) / 64;
    o.edgewords = (o.n_edges + 63) / 64;
    o.dom_space = (uint64_t *)cs_alloc(cs, sizeof(uint64_t) *
                                       (size_t)o.nodewords * (size_t)o.n_blocks);
    o.edom_space = (uint64_t *)cs_alloc(cs, sizeof(uint64_t) *
                                        (size_t)o.edgewords * (size_t)o.n_edges);
    o.maxvnodes = 8 * o.n_blocks + 256;
    o.vnodes = (valnode *)cs_alloc(cs, sizeof(valnode) * (size_t)o.maxvnodes);
    o.vmap = cs_alloc(cs, sizeof(*o.vmap) * (size_t)o.maxvnodes);
    o.intern_next = (int *)cs_alloc(cs, sizeof(int) * (size_t)o.n_blocks);
    o.jf_masks = (uint64_t *)cs_alloc(cs, sizeof(uint64_t) *
                                      (size_t)o.edgewords * (size_t)o.n_blocks);

    for (i = 0; i < o.n_blocks; i++) {
        blk *b = o.blocks[i];

        b->dom = o.dom_space + (size_t)i * (size_t)o.nodewords;
        b->et.id = 2 * i;
        b->ef.id = 2 * i + 1;
        b->et.pred = b;
        b->ef.pred = b;
        b->et.succp = &b->jt;
        b->ef.succp = &b->jf;
        b->et.edom = o.edom_space + (size_t)(2 * i) * (size_t)o.edgewords;
        b->ef.edom = o.edom_space + (size_t)(2 * i + 1) * (size_t)o.edgewords;
        o.edges[2 * i] = &b->et;
        o.edges[2 * i + 1] = &b->ef;
    }

    lv_valid = 0;
    dom_valid = 0;
    ud_valid = 0;
    for (pass = 0; pass < 2; pass++) {
        int do_stmts = pass;
        int guard = 0;

        do {
            o.done = 1;
            /*
             * The levels describe the shape of the graph, so a round that
             * redirected no edge leaves them correct. The use-def sets also
             * depend on the statements, so they survive only a round that
             * changed nothing at all.
             */
            if (!lv_valid)
                find_levels(&o, root);
            if (!ud_valid)
                find_ud(&o, root);
            /*
             * Only the edge sweeps read the dominator sets, and those sets
             * are a function of the graph shape alone, so they survive
             * exactly as long as the levels do.
             */
            if (do_stmts && !dom_valid) {
                find_dom(&o, root);
                find_edom(&o, root);
                dom_valid = 1;
            }
            o.graph_changed = 0;
            opt_blks(&o, root, do_stmts);
            if (o.graph_changed) {
                lv_valid = 0;
                dom_valid = 0;
            } else {
                lv_valid = 1;
            }
            ud_valid = lv_valid && o.done;
        } while (!o.done && ++guard < 100);
    }

    intern_blocks(&o, &root);
    opt_root(&root);
    strip_nops(&o);
    return root;
}
