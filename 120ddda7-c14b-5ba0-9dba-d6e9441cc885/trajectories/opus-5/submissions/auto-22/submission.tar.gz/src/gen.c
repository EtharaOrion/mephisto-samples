/*
 * gen.c - lowering of filter primitives to a graph of basic blocks.
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"
#include "protos.h"

/* ------------------------------------------------------------------ */
/* arena, errors, blocks                                               */

/* Standard-size chunks are recycled rather than returned to the allocator. */
#define ARENA_POOL_MAX 4
static arena_chunk *arena_pool;
static int arena_pool_n;

void *cs_alloc_slow(cstate *cs, size_t n)
{
    arena_chunk *c = cs->arena;

    n = (n + 15u) & ~(size_t)15u;
    if (c == NULL || c->used + n > c->cap) {
        if (n <= ARENA_CHUNK && arena_pool != NULL) {
            c = arena_pool;
            arena_pool = c->nxt;
            arena_pool_n--;
        } else {
            size_t extra = n > ARENA_CHUNK ? n - ARENA_CHUNK : 0;

            c = (arena_chunk *)malloc(sizeof(arena_chunk) + extra);
            if (c == NULL)
                abort();
            c->cap = ARENA_CHUNK + extra;
        }
        c->used = 0;
        c->nxt = cs->arena;
        cs->arena = c;
    }
    {
        void *p = c->mem + c->used;
        c->used += n;
        return p;
    }
}

void cs_arena_free(cstate *cs)
{
    arena_chunk *c = cs->arena;

    while (c != NULL) {
        arena_chunk *n = c->nxt;

        if (c->cap == ARENA_CHUNK && arena_pool_n < ARENA_POOL_MAX) {
            c->nxt = arena_pool;
            arena_pool = c;
            arena_pool_n++;
        } else {
            free(c);
        }
        c = n;
    }
    cs->arena = NULL;
}

_Noreturn void cs_error(cstate *cs, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    vsnprintf(cs->errbuf, sizeof(cs->errbuf), fmt, ap);
    va_end(ap);
    longjmp(cs->jb, 1);
}

stmt *new_stmt(cstate *cs, uint16_t code)
{
    stmt *s = (stmt *)cs_alloc(cs, sizeof(stmt));

    cs->nstmts++;
    s->code = code;
    s->k = 0;
    s->nxt = NULL;
    s->jt = NULL;
    s->jf = NULL;
    s->is_jump = 0;
    s->emit_idx = 0;
    return s;
}

blk *new_blk(cstate *cs, uint16_t code)
{
    blk *b = (blk *)cs_alloc(cs, sizeof(blk));

    /*
     * Everything from the edge pair on is optimizer state, rebuilt for every
     * block the optimizer visits before it reads any of it, so it is left
     * alone here.
     */
    memset(b, 0, offsetof(blk, et));
    b->code = code;
    b->id = cs->nblocks++;
    b->jt = cs->sent_t;
    b->jf = cs->sent_f;
    return b;
}

/* statement list helpers */
static void sl_app(stmt **h, stmt **t, stmt *s)
{
    if (s == NULL)
        return;
    if (*h == NULL) {
        *h = s;
    } else {
        (*t)->nxt = s;
    }
    while (s->nxt != NULL)
        s = s->nxt;
    *t = s;
}

static void blk_app(blk *b, stmt *s)
{
    sl_app(&b->head_s, &b->tail_s, s);
}

/* ------------------------------------------------------------------ */
/* fragments                                                           */

static fragment frag_of(blk *b)
{
    fragment f;

    f.first = b;
    f.last = b;
    b->chain = NULL;
    return f;
}

static void frag_cat(fragment *a, fragment b)
{
    if (a->first == NULL) {
        *a = b;
        return;
    }
    if (b.first == NULL)
        return;
    a->last->chain = b.first;
    a->last = b.last;
}

void frag_and2(cstate *cs, fragment *a, fragment b)
{
    blk *p;

    for (p = a->first; p != NULL; p = p->chain) {
        if (p->jt == cs->sent_t) p->jt = b.first;
        if (p->jf == cs->sent_t) p->jf = b.first;
    }
    frag_cat(a, b);
}

void frag_or2(cstate *cs, fragment *a, fragment b)
{
    blk *p;

    for (p = a->first; p != NULL; p = p->chain) {
        if (p->jt == cs->sent_f) p->jt = b.first;
        if (p->jf == cs->sent_f) p->jf = b.first;
    }
    frag_cat(a, b);
}

void frag_not2(cstate *cs, fragment *a)
{
    blk *p;

    for (p = a->first; p != NULL; p = p->chain) {
        if (p->jt == cs->sent_t)      p->jt = cs->sent_f;
        else if (p->jt == cs->sent_f) p->jt = cs->sent_t;
        if (p->jf == cs->sent_t)      p->jf = cs->sent_f;
        else if (p->jf == cs->sent_f) p->jf = cs->sent_t;
    }
}

/* ------------------------------------------------------------------ */
/* scratch registers                                                   */

static int alloc_reg(cstate *cs)
{
    if (cs->curreg < 0)
        cs_error(cs, "too many registers needed to evaluate expression");
    return cs->curreg--;
}

static void free_reg(cstate *cs, int n)
{
    if (n == cs->curreg + 1)
        cs->curreg = n;
}

/* ------------------------------------------------------------------ */
/* link-layer geometry                                                 */

void gen_init(cstate *cs)
{
    cs->off_linkhdr.cnst = 0;
    cs->off_linkhdr.isvar = 0;
    cs->off_linkhdr.reg = -1;
    cs->off_linkpl.cnst = 0;
    cs->off_linkpl.isvar = 0;
    cs->off_linkpl.reg = -1;
    cs->off_linktype.cnst = OFF_UNSET;
    cs->off_linktype.isvar = 0;
    cs->off_linktype.reg = -1;
    cs->off_nl = 0;
    cs->off_nl_nosnap = 0;
    cs->curreg = BPF_MEMWORDS - 1;
    cs->nblocks = 0;
    cs->label_stack_depth = 0;
    cs->is_geneve = 0;
    cs->no_optimize = 0;

    switch (cs->dlt) {
    case DLT_NULL:
    case DLT_LOOP:
        cs->off_linktype.cnst = 0;
        cs->off_linkpl.cnst = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_EN10MB:
        cs->off_linktype.cnst = 12;
        cs->off_linkpl.cnst = 14;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 3;
        break;

    case DLT_PPP:
        cs->off_linktype.cnst = 2;
        cs->off_linkpl.cnst = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_RAW:
        cs->off_linktype.cnst = OFF_UNSET;
        cs->off_linkpl.cnst = 0;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_LINUX_SLL:
        cs->off_linktype.cnst = 14;
        cs->off_linkpl.cnst = 16;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_IEEE802_11:
        cs->off_linktype.cnst = OFF_UNSET;
        cs->off_linkpl.cnst = 0;
        cs->off_linkpl.isvar = 1;
        cs->off_nl = 8;
        cs->off_nl_nosnap = 3;
        break;

    default:
        cs_error(cs, "unknown data link type %d", cs->dlt);
    }
}

/* ------------------------------------------------------------------ */
/* loads and comparisons                                               */

static stmt *varpart_to_x(cstate *cs, absoff *off)
{
    stmt *s;

    if (!off->isvar)
        return NULL;
    if (off->reg == -1)
        off->reg = alloc_reg(cs);
    s = new_stmt(cs, BPF_LDX | BPF_MEM);
    s->k = (uint32_t)off->reg;
    return s;
}

static stmt *load_absoff(cstate *cs, absoff *off, uint32_t offset, uint32_t size)
{
    stmt *s = varpart_to_x(cs, off);

    if (s != NULL) {
        stmt *s2 = new_stmt(cs, (uint16_t)(BPF_LD | BPF_IND | size));
        s2->k = off->cnst + offset;
        s->nxt = s2;
        return s;
    }
    s = new_stmt(cs, (uint16_t)(BPF_LD | BPF_ABS | size));
    s->k = off->cnst + offset;
    return s;
}

/* X <- IPv4 header length (in bytes), relative to the link payload */
static stmt *loadx_iphdrlen(cstate *cs)
{
    stmt *s, *s2;

    if (cs->off_linkpl.isvar) {
        /* A = payload offset; X = 4*([A]&0xf) is not expressible, so the
         * length is computed the long way round. */
        s = varpart_to_x(cs, &cs->off_linkpl);
        s2 = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
        s2->k = cs->off_linkpl.cnst + cs->off_nl;
        s->nxt = s2;
        s2->nxt = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->nxt->k = 0xf;
        s2->nxt->nxt = new_stmt(cs, BPF_ALU | BPF_LSH | BPF_K);
        s2->nxt->nxt->k = 2;
        s2 = s2->nxt->nxt;
        s2->nxt = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X);
        s2->nxt->nxt = new_stmt(cs, BPF_MISC | BPF_TAX);
        return s;
    }
    s = new_stmt(cs, BPF_LDX | BPF_MSH | BPF_B);
    s->k = cs->off_linkpl.cnst + cs->off_nl;
    return s;
}

stmt *gen_load_a(cstate *cs, int offrel, uint32_t offset, uint32_t size)
{
    stmt *s, *s2;

    switch (offrel) {
    case OR_LINKHDR:
        return load_absoff(cs, &cs->off_linkhdr, offset, size);

    case OR_LINKTYPE:
        if (cs->off_linktype.cnst == OFF_UNSET)
            cs_error(cs, "internal: no link type offset");
        return load_absoff(cs, &cs->off_linktype, offset, size);

    case OR_LINKPL:
        return load_absoff(cs, &cs->off_linkpl, cs->off_nl + offset, size);

    case OR_LLC:
        return load_absoff(cs, &cs->off_linkpl, offset, size);

    case OR_LINKPL_NOSNAP:
        return load_absoff(cs, &cs->off_linkpl, cs->off_nl_nosnap + offset, size);

    case OR_TRAN_IPV4:
        s = loadx_iphdrlen(cs);
        s2 = s;
        while (s2->nxt != NULL)
            s2 = s2->nxt;
        s2->nxt = new_stmt(cs, (uint16_t)(BPF_LD | BPF_IND | size));
        s2->nxt->k = cs->off_linkpl.cnst + cs->off_nl + offset;
        return s;

    case OR_TRAN_IPV6:
        return load_absoff(cs, &cs->off_linkpl, cs->off_nl + 40 + offset, size);
    }
    cs_error(cs, "internal: bad offset relation");
    return NULL;
}

fragment gen_ncmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  uint32_t mask, int jtype, int reverse, uint32_t v)
{
    stmt *s = gen_load_a(cs, offrel, offset, size);
    blk *b;
    fragment f;

    if (mask != 0xffffffffu) {
        stmt *s2 = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        stmt *t = s;
        s2->k = mask;
        while (t->nxt != NULL)
            t = t->nxt;
        t->nxt = s2;
    }
    b = new_blk(cs, (uint16_t)(BPF_JMP | jtype | BPF_K));
    b->k = v;
    blk_app(b, s);
    f = frag_of(b);
    if (reverse)
        frag_not2(cs, &f);
    return f;
}

fragment gen_cmp(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JEQ, 0, v);
}

fragment gen_cmp_gt(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGT, 0, v);
}

fragment gen_cmp_ge(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGE, 0, v);
}

fragment gen_cmp_lt(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGE, 1, v);
}

fragment gen_cmp_le(cstate *cs, int offrel, uint32_t offset, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGT, 1, v);
}

fragment gen_mcmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  uint32_t v, uint32_t mask)
{
    return gen_ncmp(cs, offrel, offset, size, mask, BPF_JEQ, 0, v);
}

fragment gen_bcmp(cstate *cs, int offrel, uint32_t offset, uint32_t size,
                  const uint8_t *v)
{
    fragment f;
    uint32_t done = 0;

    f.first = f.last = NULL;
    while (size - done >= 4) {
        const uint8_t *p = &v[done];
        uint32_t w = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
                     ((uint32_t)p[2] << 8) | p[3];
        fragment t = gen_cmp(cs, offrel, offset + done, BPF_W, w);
        if (f.first == NULL) f = t; else frag_and2(cs, &f, t);
        done += 4;
    }
    while (size - done >= 2) {
        const uint8_t *p = &v[done];
        uint32_t w = ((uint32_t)p[0] << 8) | p[1];
        fragment t = gen_cmp(cs, offrel, offset + done, BPF_H, w);
        if (f.first == NULL) f = t; else frag_and2(cs, &f, t);
        done += 2;
    }
    while (done < size) {
        fragment t = gen_cmp(cs, offrel, offset + done, BPF_B, v[done]);
        if (f.first == NULL) f = t; else frag_and2(cs, &f, t);
        done++;
    }
    return f;
}

/* an always-true / always-false predicate */
static fragment gen_uncond(cstate *cs, int sense)
{
    blk *b;
    stmt *s = new_stmt(cs, BPF_LD | BPF_IMM);

    s->k = (uint32_t)(!sense);
    b = new_blk(cs, BPF_JMP | BPF_JEQ | BPF_K);
    b->k = 0;
    blk_app(b, s);
    return frag_of(b);
}

fragment gen_true(cstate *cs)  { return gen_uncond(cs, 1); }
fragment gen_false(cstate *cs) { return gen_uncond(cs, 0); }

fragment gen_retblk(cstate *cs, uint32_t v)
{
    blk *b = new_blk(cs, BPF_RET | BPF_K);

    b->k = v;
    b->jt = NULL;
    b->jf = NULL;
    return frag_of(b);
}

/* ------------------------------------------------------------------ */
/* link-layer type tests                                               */

#define SKF_AD_OFF          0xfffff000u
#define SKF_AD_PROTOCOL     0
#define SKF_AD_PKTTYPE      4
#define SKF_AD_IFINDEX      8
#define SKF_AD_VLAN_TAG     44
#define SKF_AD_VLAN_TAG_PRESENT 48

static fragment gen_snap(cstate *cs, uint32_t orgcode, uint32_t ptype)
{
    uint8_t snapblock[8];

    snapblock[0] = LLCSAP_SNAP;
    snapblock[1] = LLCSAP_SNAP;
    snapblock[2] = 0x03;
    snapblock[3] = (uint8_t)(orgcode >> 16);
    snapblock[4] = (uint8_t)(orgcode >> 8);
    snapblock[5] = (uint8_t)orgcode;
    snapblock[6] = (uint8_t)(ptype >> 8);
    snapblock[7] = (uint8_t)ptype;
    return gen_bcmp(cs, OR_LLC, 0, 8, snapblock);
}

/* 802.2 LLC frame: the ethertype field holds a length */
static fragment gen_is_llc(cstate *cs)
{
    fragment f = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);

    frag_not2(cs, &f);
    return f;
}

static fragment gen_llc_linktype(cstate *cs, uint32_t proto)
{
    switch (proto) {
    case LLCSAP_IP:
    case LLCSAP_ISONS:
    case LLCSAP_NETBEUI:
        return gen_cmp(cs, OR_LLC, 0, BPF_H, (proto << 8) | proto);

    case LLCSAP_IPX:
        return gen_cmp(cs, OR_LLC, 0, BPF_B, LLCSAP_IPX);

    case ETHERTYPE_ATALK:
        return gen_snap(cs, 0x080007, ETHERTYPE_ATALK);

    default:
        if (proto <= ETHERMTU)
            return gen_cmp(cs, OR_LLC, 0, BPF_B, proto);
        return gen_cmp(cs, OR_LLC, 6, BPF_H, proto);
    }
}

static fragment gen_check_802_11_data(cstate *cs)
{
    stmt *s;
    blk *b0, *b1;
    fragment f0, f1;

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b0 = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);
    b0->k = 0x08;
    blk_app(b0, s);
    f0 = frag_of(b0);

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b1 = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);
    b1->k = 0x04;
    blk_app(b1, s);
    f1 = frag_of(b1);
    frag_not2(cs, &f1);

    frag_and2(cs, &f1, f0);
    return f1;
}

/* inside an MPLS label stack the payload carries no protocol number, so the
 * bottom-of-stack bit plus the IP version nibble stand in for one */
static fragment gen_mpls_linktype(cstate *cs, uint32_t proto)
{
    fragment f, f2;
    uint32_t ver;

    switch (proto) {
    case ETHERTYPE_IP:
        ver = 0x40;
        break;
    case ETHERTYPE_IPV6:
        ver = 0x60;
        break;
    default:
        cs_error(cs, "unsupported protocol after MPLS");
        return gen_false(cs);
    }
    f = gen_mcmp(cs, OR_LINKPL, (uint32_t)-2, BPF_B, 0x01, 0x01);
    f2 = gen_mcmp(cs, OR_LINKPL, 0, BPF_B, ver, 0xf0);
    frag_and2(cs, &f, f2);
    return f;
}

fragment gen_linktype(cstate *cs, uint32_t proto)
{
    fragment f, f2;

    if (cs->label_stack_depth > 0)
        return gen_mpls_linktype(cs, proto);

    switch (cs->dlt) {

    case DLT_EN10MB:
        switch (proto) {
        case LLCSAP_ISONS:
        case LLCSAP_IP:
        case LLCSAP_NETBEUI:
            f = gen_is_llc(cs);
            f2 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_H, (proto << 8) | proto);
            frag_and2(cs, &f, f2);
            return f;

        case LLCSAP_IPX:
            f = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, LLCSAP_IPX);
            return f;

        case ETHERTYPE_ATALK:
        case ETHERTYPE_AARP: {
            fragment ethii, llc, snap;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
            llc = gen_is_llc(cs);
            snap = gen_snap(cs, proto == ETHERTYPE_ATALK ? 0x080007u : 0u, proto);
            frag_and2(cs, &llc, snap);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        case ETHERTYPE_IPX: {
            fragment ethii, llc, snap, dsap, raw, grp;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ETHERTYPE_IPX);
            llc = gen_is_llc(cs);
            snap = gen_snap(cs, 0, ETHERTYPE_IPX);
            dsap = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, LLCSAP_IPX);
            raw = gen_cmp(cs, OR_LINKTYPE, 2, BPF_H, 0xffff);
            grp = snap;
            frag_or2(cs, &grp, dsap);
            frag_or2(cs, &grp, raw);
            frag_and2(cs, &llc, grp);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        default:
            if (proto <= ETHERMTU) {
                f = gen_is_llc(cs);
                f2 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, proto);
                frag_and2(cs, &f, f2);
                return f;
            }
            return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
        }

    case DLT_LINUX_SLL:
        switch (proto) {
        case LLCSAP_ISONS:
        case LLCSAP_IP:
        case LLCSAP_NETBEUI:
            f = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            f2 = gen_cmp(cs, OR_LINKPL, 0, BPF_H, (proto << 8) | proto);
            frag_and2(cs, &f, f2);
            return f;

        case LLCSAP_IPX: {
            f = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            f2 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);
            frag_and2(cs, &f, f2);
            return f;
        }

        case ETHERTYPE_IPX: {
            fragment ethii, raw8023, llc, dsap, snap, grp;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ETHERTYPE_IPX);
            raw8023 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_3);
            llc = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            dsap = gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);
            snap = gen_snap(cs, 0, ETHERTYPE_IPX);
            grp = dsap;
            frag_or2(cs, &grp, snap);
            frag_and2(cs, &llc, grp);
            frag_or2(cs, &ethii, raw8023);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        case ETHERTYPE_ATALK:
        case ETHERTYPE_AARP: {
            fragment ethii, llc, snap;
            ethii = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
            llc = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            snap = gen_snap(cs, proto == ETHERTYPE_ATALK ? 0x080007u : 0u, proto);
            frag_and2(cs, &llc, snap);
            frag_or2(cs, &ethii, llc);
            return ethii;
        }

        default:
            if (proto <= ETHERMTU) {
                f = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
                f2 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, proto);
                frag_and2(cs, &f, f2);
                return f;
            }
            return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);
        }

    case DLT_NULL:
    case DLT_LOOP:
        switch (proto) {
        case ETHERTYPE_IP:
            return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, (uint32_t)BSD_AF_INET << 24);
        case ETHERTYPE_IPV6:
            return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, (uint32_t)BSD_AF_INET6 << 24);
        default:
            return gen_false(cs);
        }

    case DLT_PPP:
        switch (proto) {
        case ETHERTYPE_IP:   proto = PPP_IP; break;
        case ETHERTYPE_IPV6: proto = PPP_IPV6; break;
        case ETHERTYPE_ATALK: proto = PPP_APPLE; break;
        case ETHERTYPE_DN:   proto = PPP_DECNET; break;
        case ETHERTYPE_IPX:  proto = PPP_IPX; break;
        case LLCSAP_ISONS:   proto = PPP_OSI; break;
        case LLCSAP_8021D:   proto = PPP_BRPDU; break;
        case LLCSAP_IPX:     proto = PPP_IPX; break;
        default: break;
        }
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, proto);

    case DLT_RAW:
        switch (proto) {
        case ETHERTYPE_IP:
            return gen_mcmp(cs, OR_LINKPL, 0, BPF_B, 0x40, 0xf0);
        case ETHERTYPE_IPV6:
            return gen_mcmp(cs, OR_LINKPL, 0, BPF_B, 0x60, 0xf0);
        default:
            return gen_false(cs);
        }

    case DLT_IEEE802_11:
        f = gen_check_802_11_data(cs);
        f2 = gen_llc_linktype(cs, proto);
        frag_and2(cs, &f, f2);
        return f;
    }
    cs_error(cs, "unknown data link type %d", cs->dlt);
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* network-layer protocol tests                                        */

static fragment gen_ipfrag(cstate *cs)
{
    stmt *s = gen_load_a(cs, OR_LINKPL, 6, BPF_H);
    blk *b = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);
    fragment f;

    b->k = 0x1fff;
    blk_app(b, s);
    f = frag_of(b);
    frag_not2(cs, &f);
    return f;
}

fragment gen_proto(cstate *cs, uint32_t v, int proto)
{
    fragment f, f1, f2, f3;

    switch (proto) {
    case PQ_DEFAULT:
        f = gen_proto(cs, v, PQ_IP);
        f1 = gen_proto(cs, v, PQ_IPV6);
        frag_or2(cs, &f, f1);
        return f;

    case PQ_IP:
        f = gen_linktype(cs, ETHERTYPE_IP);
        f1 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, v);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_IPV6:
        f = gen_linktype(cs, ETHERTYPE_IPV6);
        f1 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, v);
        f2 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, IPPROTO_FRAGMENT);
        f3 = gen_cmp(cs, OR_LINKPL, 40, BPF_B, v);
        frag_and2(cs, &f2, f3);
        frag_or2(cs, &f1, f2);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_ISO:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, v);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_LINK:
        return gen_linktype(cs, v);

    case PQ_ARP:
        cs_error(cs, "arp does not encapsulate another protocol");
        break;
    case PQ_RARP:
        cs_error(cs, "rarp does not encapsulate another protocol");
        break;
    case PQ_ATALK:
        cs_error(cs, "atalk encapsulation is not specifiable");
        break;
    case PQ_DECNET:
        cs_error(cs, "decnet encapsulation is not specifiable");
        break;
    default:
        cs_error(cs, "%s proto' is bogus", "'");
        break;
    }
    return gen_false(cs);
}

fragment gen_proto_abbrev(cstate *cs, int proto)
{
    fragment f, f1;

    switch (proto) {
    case PQ_SCTP:  return gen_proto(cs, IPPROTO_SCTP, PQ_DEFAULT);
    case PQ_TCP:   return gen_proto(cs, IPPROTO_TCP, PQ_DEFAULT);
    case PQ_UDP:   return gen_proto(cs, IPPROTO_UDP, PQ_DEFAULT);
    case PQ_ICMP:  return gen_proto(cs, IPPROTO_ICMP, PQ_IP);
    case PQ_IGMP:  return gen_proto(cs, IPPROTO_IGMP, PQ_IP);
    case PQ_IGRP:  return gen_proto(cs, IPPROTO_IGRP, PQ_IP);
    case PQ_PIM:   return gen_proto(cs, IPPROTO_PIM, PQ_DEFAULT);
    case PQ_VRRP:  return gen_proto(cs, IPPROTO_VRRP, PQ_IP);
    case PQ_CARP:  return gen_proto(cs, IPPROTO_CARP, PQ_IP);
    case PQ_AH:    return gen_proto(cs, IPPROTO_AH, PQ_DEFAULT);
    case PQ_ESP:   return gen_proto(cs, IPPROTO_ESP, PQ_DEFAULT);
    case PQ_ICMPV6: return gen_proto(cs, IPPROTO_ICMPV6, PQ_IPV6);

    case PQ_IP:    return gen_linktype(cs, ETHERTYPE_IP);
    case PQ_ARP:   return gen_linktype(cs, ETHERTYPE_ARP);
    case PQ_RARP:  return gen_linktype(cs, ETHERTYPE_REVARP);
    case PQ_ATALK: return gen_linktype(cs, ETHERTYPE_ATALK);
    case PQ_AARP:  return gen_linktype(cs, ETHERTYPE_AARP);
    case PQ_DECNET: return gen_linktype(cs, ETHERTYPE_DN);
    case PQ_LAT:   return gen_linktype(cs, ETHERTYPE_LAT);
    case PQ_SCA:   return gen_linktype(cs, ETHERTYPE_SCA);
    case PQ_MOPDL: return gen_linktype(cs, ETHERTYPE_MOPDL);
    case PQ_MOPRC: return gen_linktype(cs, ETHERTYPE_MOPRC);
    case PQ_IPV6:  return gen_linktype(cs, ETHERTYPE_IPV6);
    case PQ_ISO:   return gen_linktype(cs, LLCSAP_ISONS);
    case PQ_STP:   return gen_linktype(cs, LLCSAP_8021D);
    case PQ_IPX:   return gen_linktype(cs, ETHERTYPE_IPX);
    case PQ_NETBEUI: return gen_linktype(cs, LLCSAP_NETBEUI);

    case PQ_ESIS:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, 0x82);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_ISIS:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, 0x83);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_CLNP:
        f = gen_linktype(cs, LLCSAP_ISONS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, 0x81);
        frag_and2(cs, &f, f1);
        return f;

    /*
     * The IS-IS level and PDU-class abbreviations are `isis` narrowed to a
     * set of PDU types. Each set is a union of the individual types rather
     * than a range, because the types a class covers are not contiguous:
     * `lsp` is 18 and 20, and both level sets skip every other value.
     */
    case PQ_ISIS_L1:
    case PQ_ISIS_L2:
    case PQ_ISIS_IIH:
    case PQ_ISIS_LSP:
    case PQ_ISIS_SNP:
    case PQ_ISIS_CSNP:
    case PQ_ISIS_PSNP: {
        static const uint8_t s_l1[]   = { ISIS_L1_LAN_IIH, ISIS_L1_LSP,
                                          ISIS_L1_CSNP, ISIS_L1_PSNP };
        static const uint8_t s_l2[]   = { ISIS_L2_LAN_IIH, ISIS_L2_LSP,
                                          ISIS_L2_CSNP, ISIS_L2_PSNP };
        static const uint8_t s_iih[]  = { ISIS_L1_LAN_IIH, ISIS_L2_LAN_IIH,
                                          ISIS_PTP_IIH };
        static const uint8_t s_lsp[]  = { ISIS_L1_LSP, ISIS_L2_LSP };
        static const uint8_t s_snp[]  = { ISIS_L1_CSNP, ISIS_L2_CSNP,
                                          ISIS_L1_PSNP, ISIS_L2_PSNP };
        static const uint8_t s_csnp[] = { ISIS_L1_CSNP, ISIS_L2_CSNP };
        static const uint8_t s_psnp[] = { ISIS_L1_PSNP, ISIS_L2_PSNP };
        const uint8_t *set;
        unsigned n, i;

        switch (proto) {
        case PQ_ISIS_L1:   set = s_l1;   n = 4; break;
        case PQ_ISIS_L2:   set = s_l2;   n = 4; break;
        case PQ_ISIS_IIH:  set = s_iih;  n = 3; break;
        case PQ_ISIS_LSP:  set = s_lsp;  n = 2; break;
        case PQ_ISIS_SNP:  set = s_snp;  n = 4; break;
        case PQ_ISIS_CSNP: set = s_csnp; n = 2; break;
        default:           set = s_psnp; n = 2; break;
        }

        f = gen_proto_abbrev(cs, PQ_ISIS);
        f1 = gen_cmp(cs, OR_LINKPL_NOSNAP, ISIS_PDU_OFF, BPF_B, set[0]);
        for (i = 1; i < n; i++)
            frag_or2(cs, &f1, gen_cmp(cs, OR_LINKPL_NOSNAP, ISIS_PDU_OFF,
                                      BPF_B, set[i]));
        frag_and2(cs, &f, f1);
        return f;
    }

    case PQ_LINK:
        cs_error(cs, "link layer applied in wrong context");
        break;

    case PQ_RADIO:
        cs_error(cs, "radio information not present in capture");
        break;

    default:
        cs_error(cs, "unsupported protocol abbreviation");
    }
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* host / network addresses                                            */

static fragment gen_hostop(cstate *cs, uint32_t addr, uint32_t mask, int dir,
                           uint32_t ll_proto, uint32_t src_off, uint32_t dst_off)
{
    fragment f, fa, fb;
    uint32_t offset;

    switch (dir) {
    case DQ_SRC:
        offset = src_off;
        break;
    case DQ_DST:
        offset = dst_off;
        break;
    case DQ_AND:
        fa = gen_hostop(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_and2(cs, &fa, fb);
        return fa;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_hostop(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_or2(cs, &fa, fb);
        return fa;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    f = gen_linktype(cs, ll_proto);
    fa = gen_mcmp(cs, OR_LINKPL, offset, BPF_W, addr, mask);
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_hostop6(cstate *cs, const uint8_t *addr, const uint8_t *mask,
                            int dir, uint32_t ll_proto, uint32_t src_off, uint32_t dst_off)
{
    fragment f, fa, fb;
    uint32_t offset;
    int i;

    switch (dir) {
    case DQ_SRC:
        offset = src_off;
        break;
    case DQ_DST:
        offset = dst_off;
        break;
    case DQ_AND:
        fa = gen_hostop6(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop6(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_and2(cs, &fa, fb);
        return fa;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_hostop6(cs, addr, mask, DQ_SRC, ll_proto, src_off, dst_off);
        fb = gen_hostop6(cs, addr, mask, DQ_DST, ll_proto, src_off, dst_off);
        frag_or2(cs, &fa, fb);
        return fa;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }

    f.first = f.last = NULL;
    for (i = 0; i < 4; i++) {
        uint32_t a = ((uint32_t)addr[4 * i] << 24) | ((uint32_t)addr[4 * i + 1] << 16) |
                     ((uint32_t)addr[4 * i + 2] << 8) | addr[4 * i + 3];
        uint32_t m = ((uint32_t)mask[4 * i] << 24) | ((uint32_t)mask[4 * i + 1] << 16) |
                     ((uint32_t)mask[4 * i + 2] << 8) | mask[4 * i + 3];
        fa = gen_mcmp(cs, OR_LINKPL, offset + (uint32_t)(4 * i), BPF_W, a & m, m);
        if (f.first == NULL) f = fa; else frag_and2(cs, &f, fa);
    }
    fa = gen_linktype(cs, ll_proto);
    if (f.first == NULL)
        return fa;
    frag_and2(cs, &fa, f);
    return fa;
}

static fragment gen_ehostop(cstate *cs, const uint8_t *eaddr, int dir)
{
    fragment f, fa, fb;

    switch (cs->dlt) {
    case DLT_EN10MB:
        break;
    case DLT_IEEE802_11:
        return gen_mac48_check(cs, eaddr, dir);
    default:
        cs_error(cs, "ethernet addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel");
    }

    switch (dir) {
    case DQ_SRC:
        return gen_bcmp(cs, OR_LINKHDR, 6, 6, eaddr);
    case DQ_DST:
        return gen_bcmp(cs, OR_LINKHDR, 0, 6, eaddr);
    case DQ_AND:
        fa = gen_ehostop(cs, eaddr, DQ_SRC);
        fb = gen_ehostop(cs, eaddr, DQ_DST);
        frag_and2(cs, &fa, fb);
        return fa;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_ehostop(cs, eaddr, DQ_SRC);
        fb = gen_ehostop(cs, eaddr, DQ_DST);
        frag_or2(cs, &fa, fb);
        return fa;
    }
    f = gen_false(cs);
    return f;
}

fragment gen_host(cstate *cs, uint32_t addr, uint32_t mask, int proto, int dir, int type)
{
    fragment f, f1;
    const char *typestr = (type == AQ_NET) ? "net" : "host";

    switch (proto) {
    case PQ_DEFAULT:
        f = gen_host(cs, addr, mask, PQ_IP, dir, type);
        f1 = gen_host(cs, addr, mask, PQ_ARP, dir, type);
        frag_or2(cs, &f, f1);
        f1 = gen_host(cs, addr, mask, PQ_RARP, dir, type);
        frag_or2(cs, &f, f1);
        return f;

    case PQ_IP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_IP, 12, 16);
    case PQ_ARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_ARP, 14, 24);
    case PQ_RARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_REVARP, 14, 24);
    case PQ_LINK:
        cs_error(cs, "link-layer modifiers applied to %s", typestr);
        break;
    case PQ_IPV6:
        cs_error(cs, "'ip6' modifier applied to ip %s", typestr);
        break;
    default:
        cs_error(cs, "invalid qualifier against IPv4 address");
        break;
    }
    return gen_false(cs);
}

fragment gen_host6(cstate *cs, const uint8_t *addr, const uint8_t *mask,
                   int proto, int dir, int type)
{
    const char *typestr = (type == AQ_NET) ? "net" : "host";

    switch (proto) {
    case PQ_DEFAULT:
    case PQ_IPV6:
        return gen_hostop6(cs, addr, mask, dir, ETHERTYPE_IPV6, 8, 24);
    case PQ_LINK:
        cs_error(cs, "link-layer modifiers applied to ip6 %s", typestr);
        break;
    case PQ_IP:
        cs_error(cs, "'ip' modifier applied to ip6 %s", typestr);
        break;
    default:
        cs_error(cs, "invalid qualifier against IPv6 address");
        break;
    }
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* ports                                                               */

static fragment gen_portatom(cstate *cs, uint32_t off, uint32_t v)
{
    return gen_cmp(cs, OR_TRAN_IPV4, off, BPF_H, v);
}

static fragment gen_portatom6(cstate *cs, uint32_t off, uint32_t v)
{
    return gen_cmp(cs, OR_TRAN_IPV6, off, BPF_H, v);
}

static fragment gen_portop(cstate *cs, uint32_t port, uint32_t proto, int dir)
{
    fragment f, f1, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    f1 = gen_ipfrag(cs);
    frag_and2(cs, &f, f1);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portatom(cs, 0, port);
        break;
    case DQ_DST:
        fa = gen_portatom(cs, 2, port);
        break;
    case DQ_AND:
        fa = gen_portatom(cs, 0, port);
        fb = gen_portatom(cs, 2, port);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portatom(cs, 0, port);
        fb = gen_portatom(cs, 2, port);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_port(cstate *cs, uint32_t port, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portop(cs, port, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portop(cs, port, IPPROTO_SCTP, dir);
        tmp = gen_portop(cs, port, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portop(cs, port, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

static fragment gen_portop6(cstate *cs, uint32_t port, uint32_t proto, int dir)
{
    fragment f, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portatom6(cs, 0, port);
        break;
    case DQ_DST:
        fa = gen_portatom6(cs, 2, port);
        break;
    case DQ_AND:
        fa = gen_portatom6(cs, 0, port);
        fb = gen_portatom6(cs, 2, port);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portatom6(cs, 0, port);
        fb = gen_portatom6(cs, 2, port);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_port6(cstate *cs, uint32_t port, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portop6(cs, port, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portop6(cs, port, IPPROTO_SCTP, dir);
        tmp = gen_portop6(cs, port, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portop6(cs, port, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

static fragment gen_portrangeatom(cstate *cs, uint32_t off, uint32_t v1, uint32_t v2)
{
    fragment f1, f2;

    if (v1 > v2) {
        uint32_t t = v1;
        v1 = v2;
        v2 = t;
    }
    if (v1 == 0)
        f1 = gen_ncmp(cs, OR_TRAN_IPV4, off, BPF_H, 0xffffffffu, BPF_JGE, 0, v1);
    else
        f1 = gen_ncmp(cs, OR_TRAN_IPV4, off, BPF_H, 0xffffffffu, BPF_JGT, 0, v1 - 1);
    f2 = gen_ncmp(cs, OR_TRAN_IPV4, off, BPF_H, 0xffffffffu, BPF_JGT, 1, v2);
    frag_and2(cs, &f1, f2);
    return f1;
}

static fragment gen_portrangeatom6(cstate *cs, uint32_t off, uint32_t v1, uint32_t v2)
{
    fragment f1, f2;

    if (v1 > v2) {
        uint32_t t = v1;
        v1 = v2;
        v2 = t;
    }
    if (v1 == 0)
        f1 = gen_ncmp(cs, OR_TRAN_IPV6, off, BPF_H, 0xffffffffu, BPF_JGE, 0, v1);
    else
        f1 = gen_ncmp(cs, OR_TRAN_IPV6, off, BPF_H, 0xffffffffu, BPF_JGT, 0, v1 - 1);
    f2 = gen_ncmp(cs, OR_TRAN_IPV6, off, BPF_H, 0xffffffffu, BPF_JGT, 1, v2);
    frag_and2(cs, &f1, f2);
    return f1;
}

static fragment gen_portrangeop(cstate *cs, uint32_t p1, uint32_t p2, uint32_t proto, int dir)
{
    fragment f, f1, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    f1 = gen_ipfrag(cs);
    frag_and2(cs, &f, f1);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portrangeatom(cs, 0, p1, p2);
        break;
    case DQ_DST:
        fa = gen_portrangeatom(cs, 2, p1, p2);
        break;
    case DQ_AND:
        fa = gen_portrangeatom(cs, 0, p1, p2);
        fb = gen_portrangeatom(cs, 2, p1, p2);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portrangeatom(cs, 0, p1, p2);
        fb = gen_portrangeatom(cs, 2, p1, p2);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_portrangeop6(cstate *cs, uint32_t p1, uint32_t p2, uint32_t proto, int dir)
{
    fragment f, fa, fb;

    f = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case DQ_SRC:
        fa = gen_portrangeatom6(cs, 0, p1, p2);
        break;
    case DQ_DST:
        fa = gen_portrangeatom6(cs, 2, p1, p2);
        break;
    case DQ_AND:
        fa = gen_portrangeatom6(cs, 0, p1, p2);
        fb = gen_portrangeatom6(cs, 2, p1, p2);
        frag_and2(cs, &fa, fb);
        break;
    case DQ_DEFAULT:
    case DQ_OR:
        fa = gen_portrangeatom6(cs, 0, p1, p2);
        fb = gen_portrangeatom6(cs, 2, p1, p2);
        frag_or2(cs, &fa, fb);
        break;
    default:
        cs_error(cs, "direction not supported on linktype");
        return gen_false(cs);
    }
    frag_and2(cs, &f, fa);
    return f;
}

static fragment gen_portrange(cstate *cs, uint32_t p1, uint32_t p2, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portrangeop(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portrangeop(cs, p1, p2, IPPROTO_SCTP, dir);
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

static fragment gen_portrange6(cstate *cs, uint32_t p1, uint32_t p2, int ip_proto, int dir)
{
    fragment f, f1, tmp;

    f = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        f1 = gen_portrangeop6(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    case PROTO_UNDEF:
        f1 = gen_portrangeop6(cs, p1, p2, IPPROTO_SCTP, dir);
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_TCP, dir);
        frag_or2(cs, &f1, tmp);
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_UDP, dir);
        frag_or2(cs, &f1, tmp);
        break;
    default:
        return gen_false(cs);
    }
    frag_and2(cs, &f, f1);
    return f;
}

fragment gen_port_all(cstate *cs, uint32_t port, int ip_proto, int dir)
{
    fragment f = gen_port6(cs, port, ip_proto, dir);
    fragment f1 = gen_port(cs, port, ip_proto, dir);

    frag_or2(cs, &f, f1);
    return f;
}

fragment gen_portrange_all(cstate *cs, uint32_t p1, uint32_t p2, int ip_proto, int dir)
{
    fragment f = gen_portrange6(cs, p1, p2, ip_proto, dir);
    fragment f1 = gen_portrange(cs, p1, p2, ip_proto, dir);

    frag_or2(cs, &f, f1);
    return f;
}

/* ------------------------------------------------------------------ */
/* arithmetic                                                          */

static stmt *xfer_to_x(cstate *cs, aexpr *a)
{
    stmt *s = new_stmt(cs, BPF_LDX | BPF_MEM);

    s->k = (uint32_t)a->regno;
    return s;
}

static stmt *xfer_to_a(cstate *cs, aexpr *a)
{
    stmt *s = new_stmt(cs, BPF_LD | BPF_MEM);

    s->k = (uint32_t)a->regno;
    return s;
}

aexpr gen_loadi(cstate *cs, uint32_t v)
{
    aexpr a;
    stmt *s, *s2;
    int reg = alloc_reg(cs);

    s = new_stmt(cs, BPF_LD | BPF_IMM);
    s->k = v;
    s2 = new_stmt(cs, BPF_ST);
    s2->k = (uint32_t)reg;
    s->nxt = s2;

    a.g.first = a.g.last = NULL;
    a.sh = s;
    a.st = s2;
    a.regno = reg;
    return a;
}

aexpr gen_loadlen(cstate *cs)
{
    aexpr a;
    stmt *s, *s2;
    int reg = alloc_reg(cs);

    s = new_stmt(cs, BPF_LD | BPF_LEN | BPF_W);
    s2 = new_stmt(cs, BPF_ST);
    s2->k = (uint32_t)reg;
    s->nxt = s2;

    a.g.first = a.g.last = NULL;
    a.sh = s;
    a.st = s2;
    a.regno = reg;
    return a;
}

aexpr gen_load(cstate *cs, int proto, aexpr idx, uint32_t size)
{
    aexpr a;
    stmt *sh = NULL, *st = NULL;
    uint32_t size_code;
    int regno = alloc_reg(cs);
    fragment guard;

    free_reg(cs, idx.regno);
    guard.first = guard.last = NULL;

    switch (size) {
    case 1: size_code = BPF_B; break;
    case 2: size_code = BPF_H; break;
    case 4: size_code = BPF_W; break;
    default:
        cs_error(cs, "data size must be 1, 2, or 4");
        return idx;
    }

    switch (proto) {
    case PQ_LINK:
        if (cs->off_linkhdr.isvar) {
            sl_app(&sh, &st, varpart_to_x(cs, &cs->off_linkhdr));
            sl_app(&sh, &st, xfer_to_a(cs, &idx));
            sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
            sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
        } else {
            sl_app(&sh, &st, xfer_to_x(cs, &idx));
        }
        {
            stmt *s = new_stmt(cs, (uint16_t)(BPF_LD | BPF_IND | size_code));
            s->k = cs->off_linkhdr.cnst;
            sl_app(&sh, &st, s);
        }
        break;

    case PQ_IP:
    case PQ_ARP:
    case PQ_RARP:
    case PQ_ATALK:
    case PQ_DECNET:
    case PQ_SCA:
    case PQ_LAT:
    case PQ_MOPRC:
    case PQ_MOPDL:
    case PQ_IPV6:
    case PQ_ISO:
    case PQ_ESIS:
    case PQ_ISIS:
    case PQ_CLNP:
    case PQ_STP:
    case PQ_IPX:
    case PQ_NETBEUI:
    case PQ_AARP:
        switch (proto) {
        case PQ_IP:     guard = gen_linktype(cs, ETHERTYPE_IP); break;
        case PQ_ARP:    guard = gen_linktype(cs, ETHERTYPE_ARP); break;
        case PQ_RARP:   guard = gen_linktype(cs, ETHERTYPE_REVARP); break;
        case PQ_ATALK:  guard = gen_linktype(cs, ETHERTYPE_ATALK); break;
        case PQ_AARP:   guard = gen_linktype(cs, ETHERTYPE_AARP); break;
        case PQ_DECNET: guard = gen_linktype(cs, ETHERTYPE_DN); break;
        case PQ_SCA:    guard = gen_linktype(cs, ETHERTYPE_SCA); break;
        case PQ_LAT:    guard = gen_linktype(cs, ETHERTYPE_LAT); break;
        case PQ_MOPRC:  guard = gen_linktype(cs, ETHERTYPE_MOPRC); break;
        case PQ_MOPDL:  guard = gen_linktype(cs, ETHERTYPE_MOPDL); break;
        case PQ_IPV6:   guard = gen_linktype(cs, ETHERTYPE_IPV6); break;
        case PQ_ISO:    guard = gen_linktype(cs, LLCSAP_ISONS); break;
        case PQ_STP:    guard = gen_linktype(cs, LLCSAP_8021D); break;
        case PQ_IPX:    guard = gen_linktype(cs, ETHERTYPE_IPX); break;
        case PQ_NETBEUI: guard = gen_linktype(cs, LLCSAP_NETBEUI); break;
        default:        guard = gen_proto_abbrev(cs, proto); break;
        }
        if (cs->off_linkpl.isvar) {
            sl_app(&sh, &st, varpart_to_x(cs, &cs->off_linkpl));
            sl_app(&sh, &st, xfer_to_a(cs, &idx));
            sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
            sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
        } else {
            sl_app(&sh, &st, xfer_to_x(cs, &idx));
        }
        {
            stmt *s = new_stmt(cs, (uint16_t)(BPF_LD | BPF_IND | size_code));
            s->k = cs->off_linkpl.cnst + cs->off_nl;
            sl_app(&sh, &st, s);
        }
        break;

    case PQ_SCTP:
    case PQ_TCP:
    case PQ_UDP:
    case PQ_ICMP:
    case PQ_IGMP:
    case PQ_IGRP:
    case PQ_PIM:
    case PQ_VRRP:
    case PQ_CARP:
    case PQ_ICMPV6:
    case PQ_AH:
    case PQ_ESP: {
        fragment g2, g3;

        guard = gen_linktype(cs, ETHERTYPE_IP);
        g2 = gen_proto_abbrev(cs, proto);
        frag_and2(cs, &guard, g2);
        g3 = gen_ipfrag(cs);
        frag_and2(cs, &guard, g3);

        sl_app(&sh, &st, loadx_iphdrlen(cs));
        sl_app(&sh, &st, xfer_to_a(cs, &idx));
        sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
        sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
        {
            stmt *s = new_stmt(cs, (uint16_t)(BPF_LD | BPF_IND | size_code));
            s->k = cs->off_linkpl.cnst + cs->off_nl;
            sl_app(&sh, &st, s);
        }
        break;
    }

    case PQ_RADIO:
        cs_error(cs, "radio information not present in capture");
        break;

    default:
        cs_error(cs, "unsupported index operation");
        break;
    }

    {
        stmt *s = new_stmt(cs, BPF_ST);
        s->k = (uint32_t)regno;
        sl_app(&sh, &st, s);
    }

    a.g = idx.g;
    if (guard.first != NULL) {
        if (a.g.first == NULL)
            a.g = guard;
        else
            frag_and2(cs, &a.g, guard);
    }
    a.sh = NULL;
    a.st = NULL;
    sl_app(&a.sh, &a.st, idx.sh);
    sl_app(&a.sh, &a.st, sh);
    a.regno = regno;
    return a;
}

aexpr gen_arth(cstate *cs, int op, aexpr a0, aexpr a1)
{
    aexpr a;
    stmt *sh = NULL, *st = NULL;
    int regno;

    if ((op == BPF_DIV || op == BPF_MOD) && a1.sh != NULL &&
        a1.sh->code == (BPF_LD | BPF_IMM) && a1.sh->k == 0)
        cs_error(cs, op == BPF_DIV ? "division by zero" : "modulus by zero");

    free_reg(cs, a0.regno);
    free_reg(cs, a1.regno);
    regno = alloc_reg(cs);

    sl_app(&sh, &st, a0.sh);
    sl_app(&sh, &st, a1.sh);
    sl_app(&sh, &st, xfer_to_x(cs, &a1));
    sl_app(&sh, &st, xfer_to_a(cs, &a0));
    sl_app(&sh, &st, new_stmt(cs, (uint16_t)(BPF_ALU | op | BPF_X)));
    {
        stmt *s = new_stmt(cs, BPF_ST);
        s->k = (uint32_t)regno;
        sl_app(&sh, &st, s);
    }

    /* only one guard survives: the operands test the same header anyway */
    a.g = a0.g.first != NULL ? a0.g : a1.g;
    a.sh = sh;
    a.st = st;
    a.regno = regno;
    return a;
}

aexpr gen_neg(cstate *cs, aexpr a)
{
    stmt *sh = NULL, *st = NULL;

    sl_app(&sh, &st, a.sh);
    sl_app(&sh, &st, xfer_to_a(cs, &a));
    sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_NEG));
    {
        stmt *s = new_stmt(cs, BPF_ST);
        s->k = (uint32_t)a.regno;
        sl_app(&sh, &st, s);
    }
    a.sh = sh;
    a.st = st;
    return a;
}

fragment gen_relation(cstate *cs, int code, aexpr a0, aexpr a1, int reversed)
{
    stmt *sh = NULL, *st = NULL;
    blk *b;
    fragment f, g;

    sl_app(&sh, &st, a0.sh);
    sl_app(&sh, &st, a1.sh);
    sl_app(&sh, &st, xfer_to_x(cs, &a1));
    sl_app(&sh, &st, xfer_to_a(cs, &a0));

    if (code == BPF_JEQ) {
        sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_SUB | BPF_X));
        b = new_blk(cs, BPF_JMP | BPF_JEQ | BPF_K);
        b->k = 0;
    } else {
        b = new_blk(cs, (uint16_t)(BPF_JMP | code | BPF_X));
    }
    blk_app(b, sh);
    f = frag_of(b);
    if (reversed)
        frag_not2(cs, &f);

    free_reg(cs, a0.regno);
    free_reg(cs, a1.regno);

    g = a0.g;
    if (a1.g.first != NULL) {
        if (g.first == NULL)
            g = a1.g;
        else
            frag_and2(cs, &g, a1.g);
    }
    if (g.first != NULL) {
        frag_and2(cs, &g, f);
        return g;
    }
    return f;
}

/* ------------------------------------------------------------------ */
/* miscellaneous primitives                                            */

static fragment gen_len(cstate *cs, int jmp, uint32_t n)
{
    stmt *s = new_stmt(cs, BPF_LD | BPF_LEN | BPF_W);
    blk *b = new_blk(cs, (uint16_t)(BPF_JMP | jmp | BPF_K));

    b->k = n;
    blk_app(b, s);
    return frag_of(b);
}

fragment gen_greater(cstate *cs, uint32_t n)
{
    return gen_len(cs, BPF_JGE, n);
}

fragment gen_less(cstate *cs, uint32_t n)
{
    fragment f = gen_len(cs, BPF_JGT, n);

    frag_not2(cs, &f);
    return f;
}

fragment gen_broadcast(cstate *cs, int proto)
{
    static const uint8_t ebroadcast[6] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
    fragment f, f1, f2;

    switch (proto) {
    case PQ_DEFAULT:
    case PQ_LINK:
        switch (cs->dlt) {
        case DLT_EN10MB:
            return gen_bcmp(cs, OR_LINKHDR, 0, 6, ebroadcast);
        case DLT_IEEE802_11:
            return gen_mac48_check(cs, ebroadcast, DQ_DST);
        default:
            cs_error(cs, "not a broadcast link");
        }
        break;

    case PQ_IP:
        if (cs->netmask == 0xffffffffu)
            cs_error(cs, "netmask not known, so 'ip broadcast' not supported");
        f = gen_linktype(cs, ETHERTYPE_IP);
        f1 = gen_mcmp(cs, OR_LINKPL, 16, BPF_W, 0, ~cs->netmask);
        f2 = gen_mcmp(cs, OR_LINKPL, 16, BPF_W, ~cs->netmask, ~cs->netmask);
        frag_or2(cs, &f1, f2);
        frag_and2(cs, &f, f1);
        return f;

    default:
        cs_error(cs, "only link-layer/IP broadcast filters supported");
    }
    return gen_false(cs);
}

fragment gen_multicast(cstate *cs, int proto)
{
    fragment f, f1;
    stmt *s;
    blk *b;

    switch (proto) {
    case PQ_DEFAULT:
    case PQ_LINK:
        switch (cs->dlt) {
        case DLT_EN10MB:
            s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
            b = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);
            b->k = 1;
            blk_app(b, s);
            return frag_of(b);
        case DLT_IEEE802_11:
            return gen_mac48_multicast(cs);
        default:
            cs_error(cs, "link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel");
        }
        break;

    case PQ_IP:
        f = gen_linktype(cs, ETHERTYPE_IP);
        f1 = gen_mcmp(cs, OR_LINKPL, 16, BPF_B, 0xe0, 0xf0);
        frag_and2(cs, &f, f1);
        return f;

    case PQ_IPV6:
        f = gen_linktype(cs, ETHERTYPE_IPV6);
        f1 = gen_cmp(cs, OR_LINKPL, 24, BPF_B, 255);
        frag_and2(cs, &f, f1);
        return f;

    default:
        cs_error(cs, "only IP multicast filters supported on linktype");
    }
    return gen_false(cs);
}

fragment gen_ifindex(cstate *cs, int idx)
{
    switch (cs->dlt) {
    case DLT_LINUX_SLL:
    default:
        return gen_cmp(cs, OR_LINKHDR, SKF_AD_OFF + SKF_AD_IFINDEX, BPF_W, (uint32_t)idx);
    }
}

fragment gen_inbound(cstate *cs, int dir)
{
    fragment f;

    switch (cs->dlt) {
    case DLT_LINUX_SLL:
        f = gen_cmp(cs, OR_LINKHDR, 0, BPF_H, LINUX_SLL_OUTGOING);
        if (!dir)
            frag_not2(cs, &f);
        return f;
    default:
        f = gen_cmp(cs, OR_LINKHDR, SKF_AD_OFF + SKF_AD_PKTTYPE, BPF_H, LINUX_SLL_OUTGOING);
        if (!dir)
            frag_not2(cs, &f);
        return f;
    }
}

/* ------------------------------------------------------------------ */
/* 802.11                                                              */

/* Compare a 48-bit address at a link-header offset. */
static fragment gen_mac48_at(cstate *cs, const uint8_t *addr, uint32_t off)
{
    return gen_bcmp(cs, OR_LINKHDR, off, 6, addr);
}

/* frame-control bit test on the link header */
static fragment gen_fc_jset(cstate *cs, uint32_t off, uint32_t bits)
{
    stmt *s = gen_load_a(cs, OR_LINKHDR, off, BPF_B);
    blk *b = new_blk(cs, BPF_JMP | BPF_JSET | BPF_K);

    b->k = bits;
    blk_app(b, s);
    return frag_of(b);
}

/*
 * The per-address test used by the 802.11 address selectors: either a
 * 48-bit compare or the group-address bit of the address at that offset.
 */
typedef fragment (*wlan_test_fn)(cstate *cs, const uint8_t *addr, uint32_t off);

static fragment wlan_test_addr(cstate *cs, const uint8_t *addr, uint32_t off)
{
    return gen_mac48_at(cs, addr, off);
}

static fragment wlan_test_group(cstate *cs, const uint8_t *addr, uint32_t off)
{
    (void)addr;
    return gen_fc_jset(cs, off, 0x01);
}

/* frames that carry addresses at all: everything but control frames */
static fragment gen_wlan_notctl(cstate *cs)
{
    fragment f = gen_fc_jset(cs, 0, 0x04);

    frag_not2(cs, &f);
    return f;
}

/* the address playing the destination role */
static fragment gen_wlan_dst(cstate *cs, const uint8_t *addr, wlan_test_fn test)
{
    fragment notdata, mgt, data, tods, nots, r1, r2, g;

    notdata = gen_fc_jset(cs, 0, 0x08);
    frag_not2(cs, &notdata);
    mgt = test(cs, addr, 4);
    frag_and2(cs, &notdata, mgt);

    data = gen_fc_jset(cs, 0, 0x08);
    nots = gen_fc_jset(cs, 1, 0x01);
    frag_not2(cs, &nots);
    r1 = test(cs, addr, 4);
    frag_and2(cs, &nots, r1);
    tods = gen_fc_jset(cs, 1, 0x01);
    r2 = test(cs, addr, 16);
    frag_and2(cs, &tods, r2);
    frag_or2(cs, &nots, tods);
    frag_and2(cs, &data, nots);

    frag_or2(cs, &notdata, data);
    g = gen_wlan_notctl(cs);
    frag_and2(cs, &g, notdata);
    return g;
}

/* the address playing the source role */
static fragment gen_wlan_src(cstate *cs, const uint8_t *addr, wlan_test_fn test)
{
    fragment notdata, mgt, data, from, nofrom, tods, nots, r1, r2, r3, g;

    notdata = gen_fc_jset(cs, 0, 0x08);
    frag_not2(cs, &notdata);
    mgt = test(cs, addr, 10);
    frag_and2(cs, &notdata, mgt);

    data = gen_fc_jset(cs, 0, 0x08);
    nofrom = gen_fc_jset(cs, 1, 0x02);
    frag_not2(cs, &nofrom);
    r1 = test(cs, addr, 10);
    frag_and2(cs, &nofrom, r1);

    from = gen_fc_jset(cs, 1, 0x02);
    nots = gen_fc_jset(cs, 1, 0x01);
    frag_not2(cs, &nots);
    r2 = test(cs, addr, 16);
    frag_and2(cs, &nots, r2);
    tods = gen_fc_jset(cs, 1, 0x01);
    r3 = test(cs, addr, 24);
    frag_and2(cs, &tods, r3);
    frag_or2(cs, &nots, tods);
    frag_and2(cs, &from, nots);

    frag_or2(cs, &nofrom, from);
    frag_and2(cs, &data, nofrom);

    frag_or2(cs, &notdata, data);
    g = gen_wlan_notctl(cs);
    frag_and2(cs, &g, notdata);
    return g;
}

static fragment gen_wlan_role(cstate *cs, const uint8_t *addr, int dir,
                              wlan_test_fn test)
{
    fragment f, g;

    switch (dir) {
    case DQ_DST:
        f = gen_wlan_dst(cs, addr, test);
        break;
    case DQ_SRC:
        f = gen_wlan_src(cs, addr, test);
        break;
    case DQ_AND:
        f = gen_wlan_src(cs, addr, test);
        g = gen_wlan_dst(cs, addr, test);
        frag_and2(cs, &f, g);
        break;
    default:
        f = gen_wlan_src(cs, addr, test);
        g = gen_wlan_dst(cs, addr, test);
        frag_or2(cs, &f, g);
        break;
    }
    return f;
}

/*
 * 802.11: locate the address that plays the role asked for, taking the
 * to-DS / from-DS bits into account.
 */
fragment gen_mac48_check(cstate *cs, const uint8_t *addr, int dir)
{
    fragment f, g;

    switch (dir) {
    case DQ_ADDR1:
        return gen_mac48_at(cs, addr, 4);

    case DQ_ADDR2:
        return gen_mac48_at(cs, addr, 10);

    case DQ_ADDR3:
        /* absent from control frames */
        f = gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0x04, 0x0c);
        frag_not2(cs, &f);
        g = gen_mac48_at(cs, addr, 16);
        frag_and2(cs, &f, g);
        return f;

    case DQ_ADDR4:
        /* only carried when the frame travels between two access points */
        f = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x03, 0x03);
        g = gen_mac48_at(cs, addr, 24);
        frag_and2(cs, &f, g);
        return f;

    case DQ_RA:
        f = gen_fc_jset(cs, 0, 0x08);
        g = gen_mac48_at(cs, addr, 4);
        frag_and2(cs, &f, g);
        return f;

    case DQ_TA:
        f = gen_fc_jset(cs, 0, 0x08);
        g = gen_mac48_at(cs, addr, 10);
        frag_and2(cs, &f, g);
        return f;

    default:
        return gen_wlan_role(cs, addr, dir, wlan_test_addr);
    }
}

fragment gen_mac48_multicast(cstate *cs)
{
    static const uint8_t none[6] = { 0, 0, 0, 0, 0, 0 };

    return gen_wlan_role(cs, none, DQ_DST, wlan_test_group);
}

/* Prepend the code that computes the variable link-payload offset. */
void insert_vloffsets(cstate *cs, blk *root)
{
    stmt *sh = NULL, *st = NULL;
    stmt *cont = root->head_s;
    stmt *j1, *j2, *j3, *s;

    if (!cs->off_linkpl.isvar || cs->off_linkpl.reg == -1)
        return;

    if (cs->dlt != DLT_IEEE802_11)
        return;

    /* the optimizer cannot reason about the prologue's internal branches */
    cs->no_optimize = 1;

    s = new_stmt(cs, BPF_LDX | BPF_IMM);
    s->k = 0;
    sl_app(&sh, &st, s);
    sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TXA));
    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 24;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ST);
    s->k = (uint32_t)cs->off_linkpl.reg;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
    s->k = cs->off_linkhdr.cnst;
    sl_app(&sh, &st, s);

    j1 = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    j1->k = 0x08;
    j1->is_jump = 1;
    sl_app(&sh, &st, j1);
    j2 = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    j2->k = 0x04;
    j2->is_jump = 1;
    sl_app(&sh, &st, j2);
    j3 = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    j3->k = 0x80;
    j3->is_jump = 1;
    sl_app(&sh, &st, j3);

    s = new_stmt(cs, BPF_LD | BPF_MEM);
    s->k = (uint32_t)cs->off_linkpl.reg;
    sl_app(&sh, &st, s);
    j1->jt = j2;
    j1->jf = cont;
    j2->jt = cont;
    j2->jf = j3;
    j3->jt = s;
    j3->jf = cont;

    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 2;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ST);
    s->k = (uint32_t)cs->off_linkpl.reg;
    sl_app(&sh, &st, s);

    st->nxt = cont;
    root->head_s = sh;
    if (cont == NULL)
        root->tail_s = st;
}

/* ------------------------------------------------------------------ */
/* encapsulation primitives                                            */

/*
 * Walk the header chain at run time looking for a protocol number. The walk
 * is a loop inside one block's statement list, so it carries its own internal
 * branches and backward jumps and cannot be handed to the optimizer.
 */
static stmt *new_jump(cstate *cs, stmt **sh, stmt **st, uint32_t k)
{
    stmt *s = new_stmt(cs, BPF_JMP | BPF_JEQ | BPF_K);

    s->k = k;
    s->is_jump = 1;
    sl_app(sh, st, s);
    return s;
}

fragment gen_protochain(cstate *cs, uint32_t v, int proto)
{
    static const uint32_t exthdr[4] = { 0, 60, 43, 44 };
    fragment link, f;
    blk *b;
    stmt *sh = NULL, *st = NULL, *s;
    stmt *again, *none, *ahchk, *ah, *body = NULL, *end;
    stmt *alt[4];
    uint32_t base;
    int reg, i;

    switch (proto) {
    case PQ_IP:
        link = gen_linktype(cs, ETHERTYPE_IP);
        break;
    case PQ_IPV6:
        link = gen_linktype(cs, ETHERTYPE_IPV6);
        break;
    default:
        cs_error(cs, "bad protocol applied for 'protochain'");
        return gen_false(cs);
    }

    cs->no_optimize = 1;
    base = cs->off_linkpl.cnst + cs->off_nl;
    reg = alloc_reg(cs);

    s = new_stmt(cs, BPF_LD | BPF_ABS | BPF_B);
    s->k = base + (proto == PQ_IP ? 9u : 6u);
    sl_app(&sh, &st, s);
    if (proto == PQ_IP) {
        s = new_stmt(cs, BPF_LDX | BPF_MSH | BPF_B);
        s->k = base;
    } else {
        s = new_stmt(cs, BPF_LDX | BPF_IMM);
        s->k = 40;
    }
    sl_app(&sh, &st, s);

    again = new_jump(cs, &sh, &st, v);
    none = new_jump(cs, &sh, &st, IPPROTO_NONE);
    again->jf = none;

    if (proto == PQ_IPV6) {
        for (i = 0; i < 4; i++) {
            alt[i] = new_jump(cs, &sh, &st, exthdr[i]);
            if (i == 0)
                none->jf = alt[i];
            else
                alt[i - 1]->jf = alt[i];
        }

        /* a generic extension header carries its own length in 8-byte units */
        body = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
        body->k = base;
        sl_app(&sh, &st, body);
        s = new_stmt(cs, BPF_ST);
        s->k = (uint32_t)reg;
        sl_app(&sh, &st, s);
        s = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
        s->k = base + 1;
        sl_app(&sh, &st, s);
        s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
        s->k = 1;
        sl_app(&sh, &st, s);
        s = new_stmt(cs, BPF_ALU | BPF_MUL | BPF_K);
        s->k = 8;
        sl_app(&sh, &st, s);
        sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
        sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
        s = new_stmt(cs, BPF_LD | BPF_MEM);
        s->k = (uint32_t)reg;
        sl_app(&sh, &st, s);
        s = new_stmt(cs, BPF_JMP | BPF_JA);
        s->is_jump = 1;
        s->jt = again;
        sl_app(&sh, &st, s);

        for (i = 0; i < 4; i++)
            alt[i]->jt = body;
    } else {
        s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
        s->k = 0;
        sl_app(&sh, &st, s);
        none->jf = s;
    }

    ahchk = new_jump(cs, &sh, &st, IPPROTO_AH);
    if (proto == PQ_IPV6)
        alt[3]->jf = ahchk;

    /* the authentication header counts its length in 4-byte units */
    ah = new_stmt(cs, BPF_MISC | BPF_TXA);
    sl_app(&sh, &st, ah);
    s = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
    s->k = base;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ST);
    s->k = (uint32_t)reg;
    sl_app(&sh, &st, s);
    sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TXA));
    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 1;
    sl_app(&sh, &st, s);
    sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
    s = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
    s->k = base;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 2;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ALU | BPF_MUL | BPF_K);
    s->k = 4;
    sl_app(&sh, &st, s);
    sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
    s = new_stmt(cs, BPF_LD | BPF_MEM);
    s->k = (uint32_t)reg;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_JMP | BPF_JA);
    s->is_jump = 1;
    s->jt = again;
    sl_app(&sh, &st, s);

    end = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    end->k = 0;
    sl_app(&sh, &st, end);

    again->jt = end;
    none->jt = end;
    ahchk->jt = ah;
    ahchk->jf = end;

    free_reg(cs, reg);

    b = new_blk(cs, BPF_JMP | BPF_JEQ | BPF_K);
    b->k = v;
    b->head_s = sh;
    b->tail_s = st;
    f = frag_of(b);
    frag_and2(cs, &link, f);
    return link;
}

static const char *dlt_desc(cstate *cs)
{
    switch (cs->dlt) {
    case DLT_LINUX_SLL: return "Linux cooked v1";
    case DLT_EN10MB:    return "Ethernet";
    case DLT_NULL:      return "BSD loopback";
    case DLT_PPP:       return "PPP";
    case DLT_RAW:       return "Raw IP";
    case DLT_IEEE802_11: return "802.11";
    default:            return "unknown";
    }
}

fragment gen_vlan(cstate *cs, uint32_t vid, int has_vid)
{
    fragment f, f1;

    if (cs->label_stack_depth > 0)
        cs_error(cs, "no VLAN match after MPLS");

    switch (cs->dlt) {
    case DLT_LINUX_SLL:
        cs_error(cs, "no VLAN support for %s", dlt_desc(cs));
        break;
    default:
        break;
    }

    f = gen_linktype(cs, ETHERTYPE_VLAN);
    f1 = gen_linktype(cs, ETHERTYPE_8021AD);
    frag_or2(cs, &f, f1);
    f1 = gen_linktype(cs, ETHERTYPE_8021QINQ);
    frag_or2(cs, &f, f1);

    if (has_vid) {
        f1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_H, vid, 0x0fff);
        frag_and2(cs, &f, f1);
    }
    cs->off_linkpl.cnst += 4;
    cs->off_linktype.cnst += 4;
    return f;
}

fragment gen_mpls(cstate *cs, uint32_t label, int has_label)
{
    fragment f, f1;

    if (cs->label_stack_depth > 0) {
        f = gen_mcmp(cs, OR_LINKPL, (uint32_t)-2, BPF_B, 0, 0x01);
    } else {
        switch (cs->dlt) {
        case DLT_EN10MB:
        case DLT_IEEE802_11:
        case DLT_NULL:
        case DLT_RAW:
            f = gen_linktype(cs, ETHERTYPE_MPLS);
            break;
        case DLT_PPP:
            f = gen_linktype(cs, 0x0281);
            break;
        default:
            cs_error(cs, "no MPLS support for %s", dlt_desc(cs));
            return gen_false(cs);
        }
    }

    if (has_label) {
        if (label > 0xfffff)
            cs_error(cs, "MPLS label %u greater than maximum %u", label, 0xfffff);
        f1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_W, label << 12, 0xfffff000u);
        frag_and2(cs, &f, f1);
    }
    cs->off_nl_nosnap += 4;
    cs->off_nl += 4;
    cs->label_stack_depth++;
    return f;
}

fragment gen_pppoed(cstate *cs)
{
    return gen_linktype(cs, ETHERTYPE_PPPOED);
}

fragment gen_pppoes(cstate *cs, uint32_t sess, int has_sess)
{
    fragment f, f1;

    f = gen_linktype(cs, ETHERTYPE_PPPOES);
    if (has_sess) {
        f1 = gen_cmp(cs, OR_LINKPL, 2, BPF_H, sess);
        frag_and2(cs, &f, f1);
    }
    cs->off_linktype.cnst = cs->off_linkpl.cnst + 6;
    cs->off_linkpl.cnst += 8;
    cs->off_nl = 0;
    cs->off_nl_nosnap = 0;
    /* off_linktype now names the PPP protocol field, so later protocol tests
       must compare PPP values rather than Ethertypes. */
    cs->dlt = DLT_PPP;
    return f;
}

#define GENEVE_PORT 6081

/* the encapsulation tests proper, relative to the outer transport header */
static fragment gen_geneve_ports(cstate *cs, int offrel, uint32_t vni,
                                 int has_vni)
{
    fragment f, f1;

    f = gen_cmp(cs, offrel, 2, BPF_H, GENEVE_PORT);
    f1 = gen_mcmp(cs, offrel, 8, BPF_B, 0, 0xc0);
    frag_and2(cs, &f, f1);
    if (has_vni) {
        f1 = gen_mcmp(cs, offrel, 12, BPF_W, vni << 8, 0xffffff00u);
        frag_and2(cs, &f, f1);
    }
    return f;
}

/*
 * A block that always succeeds and leaves both A and X holding the offset of
 * the end of the outer IP header, which is where the shared tail picks up.
 */
static fragment gen_geneve_join(cstate *cs, int ipv6)
{
    stmt *sh = NULL, *st = NULL, *s;
    blk *b;

    if (!ipv6) {
        sl_app(&sh, &st, loadx_iphdrlen(cs));
        sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TXA));
    } else {
        if (cs->off_linkpl.isvar)
            sl_app(&sh, &st, varpart_to_x(cs, &cs->off_linkpl));
        s = new_stmt(cs, BPF_LD | BPF_IMM);
        s->k = 40;
        sl_app(&sh, &st, s);
        if (cs->off_linkpl.isvar)
            sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
        sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
    }

    b = new_blk(cs, BPF_JMP | BPF_JEQ | BPF_X);
    b->head_s = sh;
    b->tail_s = st;
    return frag_of(b);
}

/*
 * Walk past the Geneve header and its options and leave the inner frame's
 * link-type and payload offsets in scratch registers, which is what every
 * test after "geneve" then loads from.
 */
static fragment gen_geneve_offsets(cstate *cs)
{
    stmt *sh = NULL, *st = NULL, *s, *j, *teb;
    blk *b;
    int r_type = alloc_reg(cs);
    int r_pl = alloc_reg(cs);
    int r_new = alloc_reg(cs);

    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = cs->off_linkpl.cnst + cs->off_nl + 8;
    sl_app(&sh, &st, s);
    sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));
    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 2;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ST);
    s->k = (uint32_t)r_type;
    sl_app(&sh, &st, s);

    s = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
    s->k = 0;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
    s->k = 0x3f;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ALU | BPF_MUL | BPF_K);
    s->k = 4;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 8;
    sl_app(&sh, &st, s);
    sl_app(&sh, &st, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
    s = new_stmt(cs, BPF_ST);
    s->k = (uint32_t)r_pl;
    sl_app(&sh, &st, s);

    s = new_stmt(cs, BPF_LD | BPF_IND | BPF_H);
    s->k = 2;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_LDX | BPF_MEM);
    s->k = (uint32_t)r_pl;
    sl_app(&sh, &st, s);

    j = new_stmt(cs, BPF_JMP | BPF_JEQ | BPF_K);
    j->k = ETHERTYPE_TEB;
    j->is_jump = 1;
    sl_app(&sh, &st, j);

    /* a transparent Ethernet bridging payload carries a full Ethernet header */
    teb = new_stmt(cs, BPF_MISC | BPF_TXA);
    sl_app(&sh, &st, teb);
    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 12;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ST);
    s->k = (uint32_t)r_type;
    sl_app(&sh, &st, s);
    s = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s->k = 2;
    sl_app(&sh, &st, s);
    sl_app(&sh, &st, new_stmt(cs, BPF_MISC | BPF_TAX));

    s = new_stmt(cs, BPF_STX);
    s->k = (uint32_t)r_new;
    sl_app(&sh, &st, s);
    j->jt = teb;
    j->jf = s;
    s = new_stmt(cs, BPF_LD | BPF_IMM);
    s->k = 0;
    sl_app(&sh, &st, s);

    b = new_blk(cs, BPF_JMP | BPF_JEQ | BPF_K);
    b->k = 0;
    b->head_s = sh;
    b->tail_s = st;

    cs->off_linktype.cnst = 0;
    cs->off_linktype.isvar = 1;
    cs->off_linktype.reg = r_type;
    cs->off_linkpl.cnst = 0;
    cs->off_linkpl.isvar = 1;
    cs->off_linkpl.reg = r_new;
    cs->off_nl = 0;
    cs->off_nl_nosnap = 0;
    cs->is_geneve = 1;
    return frag_of(b);
}

fragment gen_geneve(cstate *cs, uint32_t vni, int has_vni)
{
    fragment f, f1, f2;

    cs->no_optimize = 1;

    f = gen_linktype(cs, ETHERTYPE_IP);
    f1 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, IPPROTO_UDP);
    frag_and2(cs, &f, f1);
    f1 = gen_ipfrag(cs);
    frag_and2(cs, &f, f1);
    f1 = gen_geneve_ports(cs, OR_TRAN_IPV4, vni, has_vni);
    frag_and2(cs, &f, f1);
    f1 = gen_geneve_join(cs, 0);
    frag_and2(cs, &f, f1);

    f2 = gen_linktype(cs, ETHERTYPE_IPV6);
    f1 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, IPPROTO_UDP);
    frag_and2(cs, &f2, f1);
    f1 = gen_geneve_ports(cs, OR_TRAN_IPV6, vni, has_vni);
    frag_and2(cs, &f2, f1);
    f1 = gen_geneve_join(cs, 1);
    frag_and2(cs, &f2, f1);

    frag_or2(cs, &f, f2);

    f1 = gen_geneve_offsets(cs);
    frag_and2(cs, &f, f1);
    return f;
}

fragment gen_p80211_type(cstate *cs, int type, int mask)
{
    if (cs->dlt != DLT_IEEE802_11)
        cs_error(cs, "802.11 link-layer types supported only on 802.11");
    return gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, (uint32_t)type, (uint32_t)mask);
}

fragment gen_p80211_fcdir(cstate *cs, int fcdir)
{
    if (cs->dlt != DLT_IEEE802_11)
        cs_error(cs, "frame direction supported only with 802.11 headers");
    return gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, (uint32_t)fcdir, 0x03);
}

fragment gen_false2(cstate *cs)
{
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* name-driven primitives                                              */

/* parse a dotted-quad, possibly abbreviated; returns the bit count */
static int atoin(const char *s, uint32_t *addr)
{
    uint32_t v = 0;
    int bits = 0;
    uint32_t part;
    int digits;

    for (;;) {
        part = 0;
        digits = 0;
        while (*s >= '0' && *s <= '9') {
            part = part * 10 + (uint32_t)(*s - '0');
            if (part > 255)
                return -1;
            s++;
            digits++;
        }
        if (digits == 0)
            return -1;
        v = (v << 8) | part;
        bits += 8;
        if (*s == '.') {
            s++;
            continue;
        }
        if (*s != '\0')
            return -1;
        break;
    }
    if (bits > 32)
        return -1;
    *addr = v;
    return bits;
}

static int nametoeproto(const char *s)
{
    static const struct { const char *s; int p; } tab[] = {
        { "aarp", ETHERTYPE_AARP },
        { "arp", ETHERTYPE_ARP },
        { "atalk", ETHERTYPE_ATALK },
        { "decnet", ETHERTYPE_DN },
        { "ip", ETHERTYPE_IP },
        { "ip6", ETHERTYPE_IPV6 },
        { "lat", ETHERTYPE_LAT },
        { "loopback", ETHERTYPE_LOOPBACK },
        { "mopdl", ETHERTYPE_MOPDL },
        { "moprc", ETHERTYPE_MOPRC },
        { "rarp", ETHERTYPE_REVARP },
        { "sca", ETHERTYPE_SCA },
        { NULL, 0 }
    };
    int i;

    for (i = 0; tab[i].s != NULL; i++)
        if (strcmp(tab[i].s, s) == 0)
            return tab[i].p;
    return PROTO_UNDEF;
}

static int nametollc(const char *s)
{
    if (strcmp(s, "iso") == 0)     return LLCSAP_ISONS;
    if (strcmp(s, "stp") == 0)     return LLCSAP_8021D;
    if (strcmp(s, "ipx") == 0)     return LLCSAP_IPX;
    if (strcmp(s, "netbeui") == 0) return LLCSAP_NETBEUI;
    return PROTO_UNDEF;
}

static int lookup_proto(cstate *cs, const char *name, int proto)
{
    int v;

    switch (proto) {
    case PQ_DEFAULT:
    case PQ_IP:
    case PQ_IPV6:
        v = nm_proto(name);
        if (v < 0)
            cs_error(cs, "unknown ip proto '%s'", name);
        break;

    case PQ_LINK:
        v = nametoeproto(name);
        if (v == PROTO_UNDEF) {
            v = nametollc(name);
            if (v == PROTO_UNDEF)
                cs_error(cs, "unknown ether proto '%s'", name);
        }
        break;

    case PQ_ISO:
        if (strcmp(name, "esis") == 0)      v = 0x82;
        else if (strcmp(name, "isis") == 0) v = 0x83;
        else if (strcmp(name, "clnp") == 0) v = 0x81;
        else {
            cs_error(cs, "unknown osi proto '%s'", name);
            v = PROTO_UNDEF;
        }
        break;

    default:
        v = PROTO_UNDEF;
        break;
    }
    return v;
}

/* pcap_nametoport equivalent: returns 0 on failure */
static int nametoport(const char *name, uint32_t *port, int *ipproto)
{
    int tcp_port, udp_port;

    if (name[0] >= '0' && name[0] <= '9') {
        /* a numeric service resolves under either transport */
        const char *q = name;
        uint32_t v = 0;
        while (*q >= '0' && *q <= '9') {
            v = v * 10 + (uint32_t)(*q - '0');
            q++;
        }
        if (*q == '\0' && v <= 65535) {
            *port = v;
            *ipproto = PROTO_UNDEF;
            return 1;
        }
        return 0;
    }
    tcp_port = nm_service(name, "tcp");
    udp_port = nm_service(name, "udp");

    if (tcp_port >= 0 && udp_port >= 0) {
        if (tcp_port != udp_port)
            return 0;
        *port = (uint32_t)tcp_port;
        *ipproto = PROTO_UNDEF;
        return 1;
    }
    if (tcp_port >= 0) {
        *port = (uint32_t)tcp_port;
        *ipproto = IPPROTO_TCP;
        return 1;
    }
    if (udp_port >= 0) {
        *port = (uint32_t)udp_port;
        *ipproto = IPPROTO_UDP;
        return 1;
    }
    return 0;
}

static int qual_to_ipproto(cstate *cs, int proto, const char *what)
{
    switch (proto) {
    case PQ_UDP:     return IPPROTO_UDP;
    case PQ_TCP:     return IPPROTO_TCP;
    case PQ_SCTP:    return IPPROTO_SCTP;
    case PQ_DEFAULT: return PROTO_UNDEF;
    default:
        cs_error(cs, "illegal qualifier of '%s'", what);
    }
    return PROTO_UNDEF;
}

fragment gen_scode(cstate *cs, const char *name, qual q)
{
    int proto = q.proto;
    int dir = q.dir;
    fragment f, tmp;
    int have = 0;

    switch (q.addr) {
    case AQ_NET: {
        long n = nm_network(name);
        uint32_t addr, mask;

        if (n < 0)
            cs_error(cs, "unknown network '%s'", name);
        addr = (uint32_t)n;
        mask = 0xffffffffu;
        while (addr != 0 && (addr & 0xff000000u) == 0) {
            addr <<= 8;
            mask <<= 8;
        }
        return gen_host(cs, addr, mask, proto, dir, q.addr);
    }

    case AQ_DEFAULT:
    case AQ_HOST: {
        named_addr addrs[16];
        int n, i;
        uint8_t mask128[16];

        if (proto == PQ_LINK) {
            uint8_t eaddr[6];
            if (nm_ether(name, eaddr) < 0)
                cs_error(cs, "unknown ether host '%s'", name);
            return gen_ecode(cs, eaddr, q);
        }
        n = nm_host(name, addrs, 16);
        if (n == 0)
            cs_error(cs, "unknown host '%s'", name);
        memset(mask128, 0xff, sizeof(mask128));
        f.first = f.last = NULL;
        for (i = 0; i < n; i++) {
            if (addrs[i].af == ADDR_V4) {
                if (proto == PQ_IPV6)
                    continue;
                tmp = gen_host(cs, addrs[i].v4, 0xffffffffu, proto, dir, q.addr);
            } else {
                if (proto == PQ_IP)
                    continue;
                tmp = gen_host6(cs, addrs[i].v6, mask128, proto, dir, q.addr);
            }
            if (!have) {
                f = tmp;
                have = 1;
            } else {
                frag_or2(cs, &f, tmp);
            }
        }
        if (!have)
            cs_error(cs, "unknown host '%s'", name);
        return f;
    }

    case AQ_PORT: {
        uint32_t port;
        int real_proto, ipproto;

        ipproto = qual_to_ipproto(cs, proto, "port");
        if (!nametoport(name, &port, &real_proto))
            cs_error(cs, "unknown port '%s'", name);
        if (ipproto != PROTO_UNDEF) {
            if (real_proto != PROTO_UNDEF && real_proto != ipproto)
                cs_error(cs, "port '%s' is %s", name,
                         real_proto == IPPROTO_TCP ? "tcp" : "udp");
            real_proto = ipproto;
        }
        return gen_port_all(cs, port, real_proto, dir);
    }

    case AQ_PORTRANGE: {
        uint32_t p1, p2;
        int rp1, rp2, real_proto, ipproto;
        const char *dash = strchr(name, '-');
        char first[64];

        ipproto = qual_to_ipproto(cs, proto, "portrange");
        if (dash == NULL || (size_t)(dash - name) >= sizeof(first))
            cs_error(cs, "unknown port in range '%s'", name);
        memcpy(first, name, (size_t)(dash - name));
        first[dash - name] = '\0';
        if (!nametoport(first, &p1, &rp1) || !nametoport(dash + 1, &p2, &rp2))
            cs_error(cs, "unknown port in range '%s'", name);
        real_proto = (rp1 == rp2) ? rp1 : PROTO_UNDEF;
        if (ipproto != PROTO_UNDEF)
            real_proto = ipproto;
        return gen_portrange_all(cs, p1, p2, real_proto, dir);
    }

    case AQ_GATEWAY:
        cs_error(cs, "'gateway' not supported");
        break;

    case AQ_PROTO: {
        int v = lookup_proto(cs, name, proto);
        return gen_proto(cs, (uint32_t)v, proto);
    }

    case AQ_PROTOCHAIN: {
        int v = lookup_proto(cs, name, proto);
        return gen_protochain(cs, (uint32_t)v, proto);
    }
    }
    cs_error(cs, "unknown qualifier");
    return gen_false(cs);
}

fragment gen_mcode(cstate *cs, const char *n1, const char *n2, uint32_t masklen, qual q)
{
    uint32_t n, m;
    int bits;

    bits = atoin(n1, &n);
    if (bits < 0)
        cs_error(cs, "invalid IPv4 address '%s'", n1);
    /* promote to a full 32-bit value */
    n <<= 32 - bits;

    if (n2 != NULL) {
        int b2 = atoin(n2, &m);
        if (b2 < 0)
            cs_error(cs, "invalid IPv4 address '%s'", n2);
        m <<= 32 - b2;
        if ((n & ~m) != 0)
            cs_error(cs, "non-network bits set in \"%s mask %s\"", n1, n2);
    } else {
        if (masklen > 32)
            cs_error(cs, "mask length must be <= 32");
        if (masklen == 0)
            m = 0;
        else
            m = 0xffffffffu << (32 - masklen);
        if ((n & ~m) != 0)
            cs_error(cs, "non-network bits set in \"%s/%d\"", n1, (int)masklen);
    }

    switch (q.addr) {
    case AQ_NET:
    case AQ_DEFAULT:
    case AQ_HOST:
        return gen_host(cs, n, m, q.proto, q.dir, q.addr);
    default:
        cs_error(cs, "Mask syntax for networks only");
    }
    return gen_false(cs);
}

fragment gen_mcode6(cstate *cs, const char *n1, uint32_t masklen, qual q)
{
    uint8_t addr[16], mask[16];
    unsigned i;

    if (nm_parse_v6(n1, strlen(n1), addr) < 0)
        cs_error(cs, "invalid IPv6 address '%s'", n1);
    if (masklen > 128)
        cs_error(cs, "mask length must be <= 128");
    for (i = 0; i < 16; i++) {
        unsigned bits = masklen > 8 * i ? masklen - 8 * i : 0;
        if (bits >= 8)
            mask[i] = 0xff;
        else
            mask[i] = (uint8_t)(0xff << (8 - bits));
        if ((addr[i] & ~mask[i]) != 0)
            cs_error(cs, "non-network bits set in \"%s/%d\"", n1, (int)masklen);
    }

    switch (q.addr) {
    case AQ_NET:
    case AQ_DEFAULT:
    case AQ_HOST:
        return gen_host6(cs, addr, mask, q.proto, q.dir, q.addr);
    default:
        cs_error(cs, "invalid qualifier against IPv6 address");
    }
    return gen_false(cs);
}

fragment gen_ncode(cstate *cs, const char *s, uint32_t v, qual q)
{
    uint32_t mask;
    int proto = q.proto;
    int dir = q.dir;
    int vlen;

    if (s == NULL) {
        vlen = 32;
    } else {
        vlen = atoin(s, &v);
        if (vlen < 0)
            cs_error(cs, "invalid IPv4 address '%s'", s);
    }

    switch (q.addr) {
    case AQ_DEFAULT:
    case AQ_HOST:
    case AQ_NET:
        if (proto == PQ_LINK)
            cs_error(cs, "illegal link layer address");
        mask = 0xffffffffu;
        if (s == NULL && q.addr == AQ_NET) {
            while (v != 0 && (v & 0xff000000u) == 0) {
                v <<= 8;
                mask <<= 8;
            }
        } else {
            if (vlen < 32) {
                v <<= 32 - vlen;
                mask <<= 32 - vlen;
            }
        }
        return gen_host(cs, v, mask, proto, dir, q.addr);

    case AQ_PORT: {
        int ipproto = qual_to_ipproto(cs, proto, "port");
        if (v > 65535)
            cs_error(cs, "illegal port number %u > 65535", v);
        return gen_port_all(cs, v, ipproto, dir);
    }

    case AQ_PORTRANGE: {
        int ipproto = qual_to_ipproto(cs, proto, "portrange");
        if (v > 65535)
            cs_error(cs, "illegal port number %u > 65535", v);
        return gen_portrange_all(cs, v, v, ipproto, dir);
    }

    case AQ_GATEWAY:
        cs_error(cs, "'gateway' requires a name");
        break;

    case AQ_PROTO:
        return gen_proto(cs, v, proto);

    case AQ_PROTOCHAIN:
        return gen_protochain(cs, v, proto);
    }
    cs_error(cs, "unknown qualifier");
    return gen_false(cs);
}

fragment gen_ecode(cstate *cs, const uint8_t *eaddr, qual q)
{
    if ((q.addr == AQ_HOST || q.addr == AQ_DEFAULT) && q.proto == PQ_LINK)
        return gen_ehostop(cs, eaddr, q.dir);
    cs_error(cs, "ethernet address used in non-ether expression");
    return gen_false(cs);
}

fragment gen_acode(cstate *cs, const uint8_t *eaddr, qual q)
{
    (void)eaddr;
    (void)q;
    cs_error(cs, "ARCnet address used in non-arc expression");
    return gen_false(cs);
}

/* ------------------------------------------------------------------ */
/* finishing                                                           */

blk *finish_root(cstate *cs, fragment f)
{
    fragment t = gen_retblk(cs, (uint32_t)cs->snaplen);
    fragment r = gen_retblk(cs, 0);
    blk *p;

    for (p = f.first; p != NULL; p = p->chain) {
        if (p->jt == cs->sent_t) p->jt = t.first;
        else if (p->jt == cs->sent_f) p->jt = r.first;
        if (p->jf == cs->sent_t) p->jf = t.first;
        else if (p->jf == cs->sent_f) p->jf = r.first;
    }
    insert_vloffsets(cs, f.first);
    return f.first;
}
