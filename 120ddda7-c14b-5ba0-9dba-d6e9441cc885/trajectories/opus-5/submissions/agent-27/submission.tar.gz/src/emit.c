/*
 * emit.c - lay the block graph out as a linear cBPF program.
 *
 * Blocks are placed by a depth-first walk that visits the true successor
 * before the false one, filling the instruction array from the back, so the
 * entry block ends up first and each block precedes everything it reaches.
 */
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"

static int mark_gen;

static int is_marked(blk *b)
{
    return b->mark == mark_gen;
}

static void mark(blk *b)
{
    b->mark = mark_gen;
}

/* set when a pass discovers a branch that will not fit in a jt/jf byte */
static int long_added;

static void emit_r(cstate *cs, blk *p, bpf_insn_t *base, unsigned *tail)
{
    unsigned slen, pos, i;
    stmt *s;
    bpf_insn_t *dst;

    if (p == NULL || is_marked(p))
        return;
    mark(p);

    /*
     * Equality tests lay their true branch out last, everything else lays
     * out the false branch last.
     */
    if (BPF_CLASS(p->code) == BPF_JMP && BPF_OP(p->code) == BPF_JEQ) {
        emit_r(cs, p->jt, base, tail);
        emit_r(cs, p->jf, base, tail);
    } else {
        emit_r(cs, p->jf, base, tail);
        emit_r(cs, p->jt, base, tail);
    }

    slen = 0;
    for (s = p->head_s; s != NULL; s = s->nxt)
        s->emit_idx = (int)slen++;

    *tail -= slen + 1 + (unsigned)p->longjt + (unsigned)p->longjf;
    pos = *tail;
    p->offset = (int)pos;
    dst = base + pos;

    i = 0;
    for (s = p->head_s; s != NULL; s = s->nxt, i++) {
        dst[i].code = s->code;
        dst[i].jt = 0;
        dst[i].jf = 0;
        dst[i].k = s->k;
        if (s->is_jump) {
            int tgt_t = s->jt != NULL ? s->jt->emit_idx : (int)slen;
            int tgt_f = s->jf != NULL ? s->jf->emit_idx : (int)slen;

            if (BPF_OP(s->code) == BPF_JA)
                dst[i].k = (uint32_t)(tgt_t - (int)i - 1);
            else {
                dst[i].jt = (uint8_t)(tgt_t - (int)i - 1);
                dst[i].jf = (uint8_t)(tgt_f - (int)i - 1);
            }
        }
    }

    dst += slen;
    dst->code = p->code;
    dst->k = p->k;
    dst->jt = 0;
    dst->jf = 0;

    if (BPF_CLASS(p->code) == BPF_JMP) {
        int here = (int)(pos + slen);
        int offt = p->jt->offset - here - 1;
        int offf = p->jf->offset - here - 1;

        if (offt > 255 && !p->longjt) {
            p->longjt = 1;
            long_added = 1;
        }
        if (offf > 255 && !p->longjf) {
            p->longjf = 1;
            long_added = 1;
        }

        if (p->longjt) {
            bpf_insn_t *ja = dst + 1;

            dst->jt = 0;
            ja->code = BPF_JMP | BPF_JA;
            ja->jt = 0;
            ja->jf = 0;
            ja->k = (uint32_t)(offt - 1);
        } else {
            dst->jt = (uint8_t)offt;
        }
        if (p->longjf) {
            bpf_insn_t *ja = dst + 1 + p->longjt;

            dst->jf = (uint8_t)p->longjt;
            ja->code = BPF_JMP | BPF_JA;
            ja->jt = 0;
            ja->jf = 0;
            ja->k = (uint32_t)(offf - 1 - p->longjt);
        } else {
            dst->jf = (uint8_t)offf;
        }
    }
}

void bpf_emit_prog(cstate *cs, blk *root, bpf_prog_t *out)
{
    unsigned bound, tail;
    int guard;

    /*
     * Every block emits its statements, one test and at most two long-jump
     * slots, and no block is laid out twice, so what gen allocated bounds the
     * program. Laying out from the back of that bound avoids a counting pass;
     * the jump offsets are all relative, so the result only has to be shifted
     * into place.
     */
    bound = (unsigned)cs->nstmts + 3u * (unsigned)cs->nblocks + 8u;

    bpf_prog_reset(out);
    if (out->cap < bound) {
        out->insns = (bpf_insn_t *)realloc(out->insns,
                                           sizeof(bpf_insn_t) * bound);
        out->cap = bound;
    }

    /*
     * A branch that does not fit in a byte becomes a jump to a BPF_JA slot
     * reserved after the test, which lengthens the layout and can push a
     * further branch over the limit, so lay out again until nothing new
     * needs one. Flags only ever get set, so this terminates.
     */
    for (guard = 0; guard <= cs->nblocks + 1; guard++) {
        long_added = 0;
        tail = bound;
        mark_gen++;
        emit_r(cs, root, out->insns, &tail);
        if (!long_added)
            break;
    }
    out->len = bound - tail;
    if (tail != 0)
        memmove(out->insns, out->insns + tail,
                sizeof(bpf_insn_t) * out->len);
}
