/*
 * parse.c - tokenizer and recursive-descent parser for the filter language.
 *
 * The parser generates code as it goes, exactly as the reference does, so a
 * primitive that cannot be compiled reports its own diagnostic even when the
 * text after it is malformed.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"
#include "protos.h"

enum {
    T_EOF = 0, T_BAD,
    T_NUM, T_HID, T_HID6, T_EID, T_AID, T_ID,
    /* punctuation */
    T_LPAR, T_RPAR, T_LBRA, T_RBRA, T_COLON, T_SLASH,
    T_PLUS, T_MINUS, T_STAR, T_MOD, T_AND_OP, T_OR_OP, T_XOR,
    T_LSH, T_RSH, T_EQ, T_NE, T_LT, T_GT, T_LE, T_GE,
    /* keywords */
    T_AND, T_OR, T_NOT,
    T_SRC, T_DST, T_HOST, T_NET, T_MASK, T_PORT, T_PORTRANGE, T_PROTO,
    T_PROTOCHAIN, T_GATEWAY,
    T_LESS, T_GREATER, T_BYTE, T_LEN, T_INBOUND, T_OUTBOUND, T_IFINDEX,
    T_BROADCAST, T_MULTICAST,
    T_VLAN, T_MPLS, T_PPPOED, T_PPPOES, T_GENEVE,
    T_TYPE, T_SUBTYPE, T_DIR, T_ADDR1, T_ADDR2, T_ADDR3, T_ADDR4, T_RA, T_TA,
    T_PNAME_BASE          /* protocol names carry PQ_* in tok.val */
};

typedef struct {
    int      kind;
    uint32_t num;
    int      pq;            /* for T_PNAME_BASE */
    char    *str;
} token;

typedef struct {
    cstate *cs;
    token  *tv;
    int     n, pos;
} pstate;

/* ------------------------------------------------------------------ */
/* lexer                                                               */

static const struct { const char *name; int kind; int pq; } keywords[] = {
    { "and", T_AND, 0 }, { "or", T_OR, 0 }, { "not", T_NOT, 0 },
    { "src", T_SRC, 0 }, { "dst", T_DST, 0 },
    { "host", T_HOST, 0 }, { "net", T_NET, 0 }, { "mask", T_MASK, 0 },
    { "port", T_PORT, 0 }, { "portrange", T_PORTRANGE, 0 },
    { "proto", T_PROTO, 0 }, { "protochain", T_PROTOCHAIN, 0 },
    { "gateway", T_GATEWAY, 0 },
    { "less", T_LESS, 0 }, { "greater", T_GREATER, 0 }, { "byte", T_BYTE, 0 },
    { "len", T_LEN, 0 }, { "inbound", T_INBOUND, 0 }, { "outbound", T_OUTBOUND, 0 },
    { "ifindex", T_IFINDEX, 0 },
    { "broadcast", T_BROADCAST, 0 }, { "multicast", T_MULTICAST, 0 },
    { "vlan", T_VLAN, 0 }, { "mpls", T_MPLS, 0 },
    { "pppoed", T_PPPOED, 0 }, { "pppoes", T_PPPOES, 0 },
    { "geneve", T_GENEVE, 0 },
    { "type", T_TYPE, 0 }, { "subtype", T_SUBTYPE, 0 }, { "dir", T_DIR, 0 },
    { "addr1", T_ADDR1, 0 }, { "addr2", T_ADDR2, 0 },
    { "addr3", T_ADDR3, 0 }, { "addr4", T_ADDR4, 0 },
    { "ra", T_RA, 0 }, { "ta", T_TA, 0 },

    { "link", T_PNAME_BASE, PQ_LINK },
    { "ether", T_PNAME_BASE, PQ_LINK },
    { "ppp", T_PNAME_BASE, PQ_LINK },
    { "slip", T_PNAME_BASE, PQ_LINK },
    { "fddi", T_PNAME_BASE, PQ_LINK },
    { "tr", T_PNAME_BASE, PQ_LINK },
    { "wlan", T_PNAME_BASE, PQ_LINK },
    { "ip", T_PNAME_BASE, PQ_IP },
    { "arp", T_PNAME_BASE, PQ_ARP },
    { "rarp", T_PNAME_BASE, PQ_RARP },
    { "sctp", T_PNAME_BASE, PQ_SCTP },
    { "tcp", T_PNAME_BASE, PQ_TCP },
    { "udp", T_PNAME_BASE, PQ_UDP },
    { "icmp", T_PNAME_BASE, PQ_ICMP },
    { "igmp", T_PNAME_BASE, PQ_IGMP },
    { "igrp", T_PNAME_BASE, PQ_IGRP },
    { "pim", T_PNAME_BASE, PQ_PIM },
    { "vrrp", T_PNAME_BASE, PQ_VRRP },
    { "carp", T_PNAME_BASE, PQ_CARP },
    { "atalk", T_PNAME_BASE, PQ_ATALK },
    { "aarp", T_PNAME_BASE, PQ_AARP },
    { "decnet", T_PNAME_BASE, PQ_DECNET },
    { "lat", T_PNAME_BASE, PQ_LAT },
    { "sca", T_PNAME_BASE, PQ_SCA },
    { "moprc", T_PNAME_BASE, PQ_MOPRC },
    { "mopdl", T_PNAME_BASE, PQ_MOPDL },
    { "ip6", T_PNAME_BASE, PQ_IPV6 },
    { "icmp6", T_PNAME_BASE, PQ_ICMPV6 },
    { "ah", T_PNAME_BASE, PQ_AH },
    { "esp", T_PNAME_BASE, PQ_ESP },
    { "iso", T_PNAME_BASE, PQ_ISO },
    { "esis", T_PNAME_BASE, PQ_ESIS },
    { "es-is", T_PNAME_BASE, PQ_ESIS },
    { "isis", T_PNAME_BASE, PQ_ISIS },
    { "is-is", T_PNAME_BASE, PQ_ISIS },
    { "l1", T_PNAME_BASE, PQ_ISIS_L1 },
    { "l2", T_PNAME_BASE, PQ_ISIS_L2 },
    { "iih", T_PNAME_BASE, PQ_ISIS_IIH },
    { "lsp", T_PNAME_BASE, PQ_ISIS_LSP },
    { "snp", T_PNAME_BASE, PQ_ISIS_SNP },
    { "csnp", T_PNAME_BASE, PQ_ISIS_CSNP },
    { "psnp", T_PNAME_BASE, PQ_ISIS_PSNP },
    { "clnp", T_PNAME_BASE, PQ_CLNP },
    { "stp", T_PNAME_BASE, PQ_STP },
    { "ipx", T_PNAME_BASE, PQ_IPX },
    { "netbeui", T_PNAME_BASE, PQ_NETBEUI },
    { "radio", T_PNAME_BASE, PQ_RADIO },
    { NULL, 0, 0 }
};

static const struct { const char *name; uint32_t v; } numnames[] = {
    { "icmptype", 0 }, { "icmpcode", 1 },
    { "icmp-echoreply", 0 }, { "icmp-unreach", 3 }, { "icmp-sourcequench", 4 },
    { "icmp-redirect", 5 }, { "icmp-echo", 8 }, { "icmp-routeradvert", 9 },
    { "icmp-routersolicit", 10 }, { "icmp-timxceed", 11 }, { "icmp-paramprob", 12 },
    { "icmp-tstamp", 13 }, { "icmp-tstampreply", 14 }, { "icmp-ireq", 15 },
    { "icmp-ireqreply", 16 }, { "icmp-maskreq", 17 }, { "icmp-maskreply", 18 },
    { "tcpflags", 13 },
    { "tcp-fin", 0x01 }, { "tcp-syn", 0x02 }, { "tcp-rst", 0x04 },
    { "tcp-push", 0x08 }, { "tcp-ack", 0x10 }, { "tcp-urg", 0x20 },
    { "tcp-ece", 0x40 }, { "tcp-cwr", 0x80 },
    { NULL, 0 }
};

static int is_word_char(int c)
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') || c == '_' || c == '-' || c == '.';
}

static int hexdig(int c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

/*
 * Both word tables are scanned for every identifier, so they get a hash
 * index built on first use. Lookup order (numeric names before keywords)
 * is unchanged.
 */
#define WORD_BUCKETS 256

static short kw_head[WORD_BUCKETS], kw_next[256];
static short nn_head[WORD_BUCKETS], nn_next[256];
static int word_ix_built;

static unsigned word_hash(const char *s)
{
    unsigned h = 2166136261u;

    while (*s != '\0')
        h = (h ^ (unsigned char)*s++) * 16777619u;
    return h & (WORD_BUCKETS - 1);
}

static void build_word_ix(void)
{
    int i;

    for (i = 0; i < WORD_BUCKETS; i++) {
        kw_head[i] = -1;
        nn_head[i] = -1;
    }
    for (i = 0; keywords[i].name != NULL; i++) {
        unsigned h = word_hash(keywords[i].name);

        kw_next[i] = kw_head[h];
        kw_head[h] = (short)i;
    }
    for (i = 0; numnames[i].name != NULL; i++) {
        unsigned h = word_hash(numnames[i].name);

        nn_next[i] = nn_head[h];
        nn_head[h] = (short)i;
    }
    word_ix_built = 1;
}

static int lookup_numname(const char *w, uint32_t *v)
{
    unsigned h;
    int i;

    if (!word_ix_built)
        build_word_ix();
    h = word_hash(w);
    for (i = nn_head[h]; i >= 0; i = nn_next[i])
        if (strcmp(numnames[i].name, w) == 0) {
            *v = numnames[i].v;
            return 1;
        }
    return 0;
}

static int lookup_keyword(const char *w, int *kind, int *pq)
{
    unsigned h;
    int i;

    if (!word_ix_built)
        build_word_ix();
    h = word_hash(w);
    for (i = kw_head[h]; i >= 0; i = kw_next[i])
        if (strcmp(keywords[i].name, w) == 0) {
            *kind = keywords[i].kind;
            *pq = keywords[i].pq;
            return 1;
        }
    return 0;
}

/* length of a decimal/hex number at s, 0 if none */
static size_t num_len(const char *s)
{
    size_t i = 0;

    if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X')) {
        i = 2;
        if (hexdig((unsigned char)s[i]) < 0)
            return 0;
        while (hexdig((unsigned char)s[i]) >= 0)
            i++;
        return i;
    }
    while (s[i] >= '0' && s[i] <= '9')
        i++;
    return i;
}

static uint32_t num_val(const char *s, size_t len)
{
    uint32_t v = 0;
    size_t i = 0;
    int base = 10;

    if (len > 1 && s[0] == '0') {
        if (len > 2 && (s[1] == 'x' || s[1] == 'X')) {
            base = 16;
            i = 2;
        } else {
            base = 8;
            i = 1;
        }
    }
    for (; i < len; i++) {
        int d = hexdig((unsigned char)s[i]);
        if (d < 0 || d >= base)
            break;
        v = v * (uint32_t)base + (uint32_t)d;
    }
    return v;
}

/* match a dotted quad (2..4 components) */
static size_t hid_len(const char *s)
{
    size_t i = 0, last = 0;
    int parts = 0;

    for (;;) {
        size_t nl = num_len(s + i);
        if (nl == 0)
            break;
        i += nl;
        parts++;
        if (parts >= 2)
            last = i;
        if (s[i] == '.' && num_len(s + i + 1) > 0) {
            i++;
            continue;
        }
        break;
    }
    if (parts < 2 || parts > 4)
        return 0;
    if (is_word_char((unsigned char)s[last]))
        return 0;
    return last;
}

/* match a 6-group MAC address */
static size_t eid_len(const char *s)
{
    size_t i = 0;
    int g;

    for (g = 0; g < 6; g++) {
        int d = 0;
        while (d < 2 && hexdig((unsigned char)s[i]) >= 0) { i++; d++; }
        if (d == 0)
            return 0;
        if (g < 5) {
            if (s[i] != ':')
                return 0;
            i++;
        }
    }
    if (is_word_char((unsigned char)s[i]) || s[i] == ':')
        return 0;
    return i;
}

/* match an IPv6 literal */
static size_t hid6_len(const char *s)
{
    size_t i = 0;
    char buf[64];
    uint8_t tmp[16];

    while (hexdig((unsigned char)s[i]) >= 0 || s[i] == ':' ||
           (s[i] == '.' && i > 0))
        i++;
    while (i > 0 && (s[i - 1] == '.' ))
        i--;
    if (i == 0 || i >= sizeof(buf))
        return 0;
    if (memchr(s, ':', i) == NULL)
        return 0;
    memcpy(buf, s, i);
    buf[i] = '\0';
    while (i > 0 && nm_parse_v6(buf, i, tmp) < 0) {
        i--;
        buf[i] = '\0';
        if (i > 0 && buf[i - 1] == ':' && (i < 2 || buf[i - 2] != ':'))
            continue;
    }
    if (i == 0)
        return 0;
    return i;
}

static char *dupn(cstate *cs, const char *s, size_t n)
{
    char *p = (char *)cs_alloc(cs, n + 1);

    memcpy(p, s, n);
    p[n] = '\0';
    return p;
}

static void push(cstate *cs, token **tv, int *n, int *cap, token t)
{
    (void)cs;
    if (*n < *cap)
        (*tv)[(*n)++] = t;
}

/*
 * The token vector dies with the parse, so it lives in one buffer that is
 * reused by every compile rather than in the arena: it stays cache-warm and
 * the worst-case sizing below costs nothing after the first long filter.
 */
static token *tokbuf;
static int tokcap;

static int lex_all(cstate *cs, const char *src, token **out, int *outn)
{
    token *tv;
    int n = 0, cap;
    const char *p = src;

    cap = (int)strlen(src) + 2;
    if (cap > tokcap) {
        token *nb = (token *)realloc(tokbuf, sizeof(token) * (size_t)cap);

        if (nb == NULL)
            cs_error(cs, "out of memory");
        tokbuf = nb;
        tokcap = cap;
    }
    tv = tokbuf;

    for (;;) {
        token t;
        size_t len;

        memset(&t, 0, sizeof(t));
        while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')
            p++;
        if (*p == '\0')
            break;

        switch (*p) {
        case '(': t.kind = T_LPAR; p++; goto emit;
        case ')': t.kind = T_RPAR; p++; goto emit;
        case '[': t.kind = T_LBRA; p++; goto emit;
        case ']': t.kind = T_RBRA; p++; goto emit;
        case ':':
            /* an address may start with the compressed-zeroes marker */
            if (p[1] == ':') {
                len = hid6_len(p);
                if (len > 0) {
                    t.kind = T_HID6;
                    t.str = dupn(cs, p, len);
                    p += len;
                    goto emit;
                }
            }
            t.kind = T_COLON;
            p++;
            goto emit;
        case '/': t.kind = T_SLASH; p++; goto emit;
        case '+': t.kind = T_PLUS; p++; goto emit;
        case '*': t.kind = T_STAR; p++; goto emit;
        case '%': t.kind = T_MOD; p++; goto emit;
        case '^': t.kind = T_XOR; p++; goto emit;
        case '-':
            if (num_len(p + 1) == 0 || 1) { t.kind = T_MINUS; p++; goto emit; }
            break;
        case '&':
            if (p[1] == '&') { t.kind = T_AND; p += 2; } else { t.kind = T_AND_OP; p++; }
            goto emit;
        case '|':
            if (p[1] == '|') { t.kind = T_OR; p += 2; } else { t.kind = T_OR_OP; p++; }
            goto emit;
        case '!':
            if (p[1] == '=') { t.kind = T_NE; p += 2; } else { t.kind = T_NOT; p++; }
            goto emit;
        case '=':
            if (p[1] == '=') p += 2; else p++;
            t.kind = T_EQ;
            goto emit;
        case '<':
            if (p[1] == '<') { t.kind = T_LSH; p += 2; }
            else if (p[1] == '=') { t.kind = T_LE; p += 2; }
            else { t.kind = T_LT; p++; }
            goto emit;
        case '>':
            if (p[1] == '>') { t.kind = T_RSH; p += 2; }
            else if (p[1] == '=') { t.kind = T_GE; p += 2; }
            else { t.kind = T_GT; p++; }
            goto emit;
        case '\\':
            p++;
            len = 0;
            while (is_word_char((unsigned char)p[len]))
                len++;
            if (len == 0) {
                t.kind = T_BAD;
                p++;
                goto emit;
            }
            t.kind = T_ID;
            t.str = dupn(cs, p, len);
            p += len;
            goto emit;
        default:
            break;
        }

        len = eid_len(p);
        if (len > 0) {
            t.kind = T_EID;
            t.str = dupn(cs, p, len);
            p += len;
            goto emit;
        }
        len = hid6_len(p);
        if (len > 0) {
            t.kind = T_HID6;
            t.str = dupn(cs, p, len);
            p += len;
            goto emit;
        }
        len = hid_len(p);
        if (len > 0) {
            t.kind = T_HID;
            t.str = dupn(cs, p, len);
            p += len;
            goto emit;
        }
        if ((*p >= '0' && *p <= '9')) {
            size_t wl = 0;
            len = num_len(p);
            while (is_word_char((unsigned char)p[wl]))
                wl++;
            if (wl > len) {
                /* an identifier that happens to start with digits */
                char *w = dupn(cs, p, wl);
                uint32_t nv;

                t.kind = T_ID;
                t.str = w;
                if (lookup_numname(w, &nv)) {
                    t.kind = T_NUM;
                    t.num = nv;
                }
                p += wl;
                goto emit;
            }
            t.kind = T_NUM;
            t.num = num_val(p, len);
            p += len;
            goto emit;
        }
        if (is_word_char((unsigned char)*p)) {
            char *w;
            uint32_t nv;
            int kind, pq;

            len = 0;
            while (is_word_char((unsigned char)p[len]))
                len++;
            w = dupn(cs, p, len);
            p += len;
            t.kind = T_ID;
            t.str = w;
            if (lookup_numname(w, &nv)) {
                t.kind = T_NUM;
                t.num = nv;
                goto emit;
            }
            if (lookup_keyword(w, &kind, &pq)) {
                t.kind = kind;
                t.pq = pq;
            }
            goto emit;
        }
        t.kind = T_BAD;
        p++;
    emit:
        push(cs, &tv, &n, &cap, t);
    }
    {
        token t;
        memset(&t, 0, sizeof(t));
        t.kind = T_EOF;
        push(cs, &tv, &n, &cap, t);
    }
    *out = tv;
    *outn = n;
    return 0;
}

/* ------------------------------------------------------------------ */
/* parser                                                              */

static _Noreturn void syntax_error(pstate *p)
{
    cs_error(p->cs, "can't parse filter expression: syntax error");
}

static int peek(pstate *p)
{
    return p->tv[p->pos].kind;
}

static int peek2(pstate *p, int n)
{
    int i = p->pos + n;

    if (i >= p->n)
        i = p->n - 1;
    return p->tv[i].kind;
}

static token *cur(pstate *p)
{
    return &p->tv[p->pos];
}

static void advance(pstate *p)
{
    if (p->tv[p->pos].kind != T_EOF)
        p->pos++;
}

static void expect(pstate *p, int kind)
{
    if (peek(p) != kind)
        syntax_error(p);
    advance(p);
}

static fragment p_expr(pstate *p);
static fragment p_term(pstate *p);
static aexpr p_arth(pstate *p, int minprec);

static int is_relop(int k)
{
    return k == T_GT || k == T_GE || k == T_EQ || k == T_LE || k == T_LT || k == T_NE;
}

static int is_arith_op(int k)
{
    return k == T_PLUS || k == T_MINUS || k == T_STAR || k == T_SLASH || k == T_MOD ||
           k == T_AND_OP || k == T_OR_OP || k == T_XOR || k == T_LSH || k == T_RSH;
}

/* does the parenthesised group starting at the current '(' belong to an
 * arithmetic expression? */
static int paren_is_arith(pstate *p)
{
    int depth = 0;
    int i = p->pos;

    for (; i < p->n; i++) {
        int k = p->tv[i].kind;
        if (k == T_LPAR) depth++;
        else if (k == T_RPAR) {
            depth--;
            if (depth == 0) {
                int nk = p->tv[i + 1 < p->n ? i + 1 : i].kind;
                return is_relop(nk) || is_arith_op(nk);
            }
        } else if (k == T_EOF) {
            break;
        }
    }
    return 0;
}

static fragment p_id(pstate *p, qual q);

static fragment p_nid(pstate *p, qual q)
{
    token *t = cur(p);
    fragment f;

    switch (t->kind) {
    case T_NOT:
        advance(p);
        f = p_id(p, q);
        frag_not2(p->cs, &f);
        return f;

    case T_ID:
        advance(p);
        return gen_scode(p->cs, t->str, q);

    case T_HID:
        advance(p);
        if (peek(p) == T_SLASH) {
            advance(p);
            if (peek(p) != T_NUM)
                syntax_error(p);
            {
                uint32_t m = cur(p)->num;
                advance(p);
                return gen_mcode(p->cs, t->str, NULL, m, q);
            }
        }
        if (peek(p) == T_MASK) {
            advance(p);
            if (peek(p) != T_HID)
                syntax_error(p);
            {
                char *m = cur(p)->str;
                advance(p);
                return gen_mcode(p->cs, t->str, m, 0, q);
            }
        }
        if (q.addr == AQ_PORT)
            cs_error(p->cs, "'port' modifier applied to ip host");
        if (q.addr == AQ_PORTRANGE)
            cs_error(p->cs, "'portrange' modifier applied to ip host");
        if (q.addr == AQ_PROTO)
            cs_error(p->cs, "'proto' modifier applied to ip host");
        if (q.addr == AQ_PROTOCHAIN)
            cs_error(p->cs, "'protochain' modifier applied to ip host");
        return gen_ncode(p->cs, t->str, 0, q);

    case T_HID6:
        advance(p);
        if (peek(p) == T_SLASH) {
            advance(p);
            if (peek(p) != T_NUM)
                syntax_error(p);
            {
                uint32_t m = cur(p)->num;
                advance(p);
                return gen_mcode6(p->cs, t->str, m, q);
            }
        }
        if (q.addr == AQ_PORT)
            cs_error(p->cs, "'port' modifier applied to ip6 host");
        if (q.addr == AQ_PORTRANGE)
            cs_error(p->cs, "'portrange' modifier applied to ip6 host");
        if (q.addr == AQ_PROTO)
            cs_error(p->cs, "'proto' modifier applied to ip6 host");
        if (q.addr == AQ_PROTOCHAIN)
            cs_error(p->cs, "'protochain' modifier applied to ip6 host");
        return gen_mcode6(p->cs, t->str, 128, q);

    case T_EID: {
        uint8_t eaddr[6];
        unsigned b[6];
        int i;
        advance(p);
        if (sscanf(t->str, "%x:%x:%x:%x:%x:%x", &b[0], &b[1], &b[2], &b[3], &b[4], &b[5]) != 6)
            syntax_error(p);
        for (i = 0; i < 6; i++)
            eaddr[i] = (uint8_t)b[i];
        return gen_ecode(p->cs, eaddr, q);
    }

    default:
        syntax_error(p);
    }
    return gen_false2(p->cs);
}

/* pid: nid | qid and id | qid or id */
static fragment p_pid(pstate *p, qual q)
{
    fragment f;

    if (peek(p) == T_NUM) {
        uint32_t v = cur(p)->num;
        advance(p);
        f = gen_ncode(p->cs, NULL, v, q);
    } else {
        f = p_nid(p, q);
    }
    for (;;) {
        if (peek(p) == T_AND) {
            fragment g;
            advance(p);
            g = p_id(p, q);
            frag_and2(p->cs, &f, g);
        } else if (peek(p) == T_OR) {
            fragment g;
            advance(p);
            g = p_id(p, q);
            frag_or2(p->cs, &f, g);
        } else {
            break;
        }
    }
    return f;
}

/* id: nid | pnum | '(' pid ')' */
static fragment p_id(pstate *p, qual q)
{
    if (peek(p) == T_NUM) {
        uint32_t v = cur(p)->num;
        advance(p);
        return gen_ncode(p->cs, NULL, v, q);
    }
    if (peek(p) == T_LPAR) {
        fragment f;
        advance(p);
        f = p_pid(p, q);
        expect(p, T_RPAR);
        return f;
    }
    return p_nid(p, q);
}

static uint32_t p_pnum(pstate *p)
{
    if (peek(p) == T_LPAR) {
        uint32_t v;
        advance(p);
        v = p_pnum(p);
        expect(p, T_RPAR);
        return v;
    }
    if (peek(p) != T_NUM)
        syntax_error(p);
    {
        uint32_t v = cur(p)->num;
        advance(p);
        return v;
    }
}

/* arithmetic primary */
static aexpr p_arth_primary(pstate *p)
{
    aexpr a;

    switch (peek(p)) {
    case T_NUM: {
        uint32_t v = cur(p)->num;
        advance(p);
        return gen_loadi(p->cs, v);
    }
    case T_LEN:
        advance(p);
        return gen_loadlen(p->cs);
    case T_MINUS:
        advance(p);
        a = p_arth_primary(p);
        return gen_neg(p->cs, a);
    case T_LPAR:
        advance(p);
        a = p_arth(p, 0);
        expect(p, T_RPAR);
        return a;
    case T_PNAME_BASE: {
        int pq = cur(p)->pq;
        uint32_t size = 1;
        aexpr idx;
        advance(p);
        expect(p, T_LBRA);
        idx = p_arth(p, 0);
        if (peek(p) == T_COLON) {
            advance(p);
            if (peek(p) != T_NUM)
                syntax_error(p);
            size = cur(p)->num;
            advance(p);
        }
        expect(p, T_RBRA);
        return gen_load(p->cs, pq, idx, size);
    }
    default:
        syntax_error(p);
    }
    memset(&a, 0, sizeof(a));
    return a;
}

static int arith_prec(int k)
{
    switch (k) {
    case T_OR_OP:  return 1;
    case T_XOR:    return 2;
    case T_AND_OP: return 3;
    case T_LSH: case T_RSH: return 4;
    case T_PLUS: case T_MINUS: return 5;
    case T_STAR: case T_SLASH: case T_MOD: return 6;
    default: return -1;
    }
}

static int arith_op(int k)
{
    switch (k) {
    case T_OR_OP:  return BPF_OR;
    case T_XOR:    return BPF_XOR;
    case T_AND_OP: return BPF_AND;
    case T_LSH:    return BPF_LSH;
    case T_RSH:    return BPF_RSH;
    case T_PLUS:   return BPF_ADD;
    case T_MINUS:  return BPF_SUB;
    case T_STAR:   return BPF_MUL;
    case T_SLASH:  return BPF_DIV;
    case T_MOD:    return BPF_MOD;
    default:       return -1;
    }
}

static aexpr p_arth(pstate *p, int minprec)
{
    aexpr lhs = p_arth_primary(p);

    for (;;) {
        int k = peek(p);
        int prec = arith_prec(k);
        aexpr rhs;

        if (prec < 0 || prec < minprec)
            break;
        advance(p);
        rhs = p_arth(p, prec + 1);
        lhs = gen_arth(p->cs, arith_op(k), lhs, rhs);
    }
    return lhs;
}

static fragment p_relation(pstate *p)
{
    aexpr a0 = p_arth(p, 0);
    aexpr a1;
    int k = peek(p);

    switch (k) {
    case T_GT: advance(p); a1 = p_arth(p, 0); return gen_relation(p->cs, BPF_JGT, a0, a1, 0);
    case T_GE: advance(p); a1 = p_arth(p, 0); return gen_relation(p->cs, BPF_JGE, a0, a1, 0);
    case T_EQ: advance(p); a1 = p_arth(p, 0); return gen_relation(p->cs, BPF_JEQ, a0, a1, 0);
    case T_LE: advance(p); a1 = p_arth(p, 0); return gen_relation(p->cs, BPF_JGT, a0, a1, 1);
    case T_LT: advance(p); a1 = p_arth(p, 0); return gen_relation(p->cs, BPF_JGE, a0, a1, 1);
    case T_NE: advance(p); a1 = p_arth(p, 0); return gen_relation(p->cs, BPF_JEQ, a0, a1, 1);
    default:
        syntax_error(p);
    }
    return gen_false2(p->cs);
}

static int str2tok(const char *s, const char *const *names, int n)
{
    int i;

    for (i = 0; i < n; i++)
        if (names[i] != NULL && strcmp(names[i], s) == 0)
            return i;
    return -1;
}

static const char *const ieee80211_types[] = { "mgt", "ctl", "data" };

static const char *const ieee80211_mgt_subtypes[] = {
    "assoc-req", "assoc-resp", "reassoc-req", "reassoc-resp",
    "probe-req", "probe-resp", NULL, NULL,
    "beacon", "atim", "disassoc", "auth", "deauth", NULL, NULL, NULL
};
static const char *const ieee80211_ctl_subtypes[] = {
    NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
    "bar", "ba", "ps-poll", "rts", "cts", "ack", "cf-end", "cf-end-ack"
};
static const char *const ieee80211_data_subtypes[] = {
    "data", "data-cf-ack", "data-cf-poll", "data-cf-ack-poll", "null",
    "cf-ack", "cf-poll", "cf-ack-poll", "qos-data", "qos-data-cf-ack",
    "qos-data-cf-poll", "qos-data-cf-ack-poll", "qos", NULL,
    "qos-cf-poll", "qos-cf-ack-poll"
};
static const char *const ieee80211_dirs[] = {
    "nods", "tods", "fromds", "dstods"
};

static fragment p_p80211(pstate *p)
{
    int type = -1, subtype = -1;

    if (peek(p) == T_TYPE) {
        advance(p);
        if (peek(p) == T_NUM) {
            type = (int)cur(p)->num;
            advance(p);
        } else if (peek(p) == T_ID || peek(p) == T_PNAME_BASE) {
            const char *s = cur(p)->str;
            if (s == NULL)
                syntax_error(p);
            type = str2tok(s, ieee80211_types, 3);
            if (type < 0)
                cs_error(p->cs, "unknown 802.11 type name");
            advance(p);
        } else {
            syntax_error(p);
        }
        if (peek(p) == T_SUBTYPE) {
            advance(p);
            if (peek(p) == T_NUM) {
                subtype = (int)cur(p)->num;
                advance(p);
            } else if (peek(p) == T_ID || peek(p) == T_PNAME_BASE) {
                const char *s = cur(p)->str;
                const char *const *tab;
                if (s == NULL)
                    syntax_error(p);
                tab = type == 0 ? ieee80211_mgt_subtypes :
                      type == 1 ? ieee80211_ctl_subtypes : ieee80211_data_subtypes;
                subtype = str2tok(s, tab, 16);
                if (subtype < 0)
                    cs_error(p->cs, "unknown 802.11 subtype name");
                advance(p);
            } else {
                syntax_error(p);
            }
            return gen_p80211_type(p->cs, (type << 2) | (subtype << 4), 0xfc);
        }
        return gen_p80211_type(p->cs, type << 2, 0x0c);
    }
    if (peek(p) == T_SUBTYPE) {
        advance(p);
        if (peek(p) == T_NUM) {
            subtype = (int)cur(p)->num;
            advance(p);
            return gen_p80211_type(p->cs, subtype << 4, 0xf0);
        }
        if (peek(p) == T_ID || peek(p) == T_PNAME_BASE) {
            const char *s = cur(p)->str;
            int i, found = -1, ftype = -1;
            if (s == NULL)
                syntax_error(p);
            for (i = 0; i < 16 && found < 0; i++)
                if (ieee80211_mgt_subtypes[i] && strcmp(ieee80211_mgt_subtypes[i], s) == 0) {
                    found = i; ftype = 0;
                }
            for (i = 0; i < 16 && found < 0; i++)
                if (ieee80211_ctl_subtypes[i] && strcmp(ieee80211_ctl_subtypes[i], s) == 0) {
                    found = i; ftype = 1;
                }
            for (i = 0; i < 16 && found < 0; i++)
                if (ieee80211_data_subtypes[i] && strcmp(ieee80211_data_subtypes[i], s) == 0) {
                    found = i; ftype = 2;
                }
            if (found < 0)
                cs_error(p->cs, "unknown 802.11 type name");
            advance(p);
            return gen_p80211_type(p->cs, (ftype << 2) | (found << 4), 0xfc);
        }
        syntax_error(p);
    }
    if (peek(p) == T_DIR) {
        int d;
        advance(p);
        if (peek(p) == T_NUM) {
            d = (int)cur(p)->num;
            advance(p);
        } else if (peek(p) == T_ID) {
            const char *s = cur(p)->str;
            d = str2tok(s, ieee80211_dirs, 4);
            if (d < 0)
                cs_error(p->cs, "unknown 802.11 direction");
            advance(p);
        } else {
            syntax_error(p);
        }
        return gen_p80211_fcdir(p->cs, d);
    }
    syntax_error(p);
    return gen_false2(p->cs);
}

static int is_dqual(int k)
{
    return k == T_SRC || k == T_DST || k == T_ADDR1 || k == T_ADDR2 ||
           k == T_ADDR3 || k == T_ADDR4 || k == T_RA || k == T_TA;
}

static int is_aqual(int k)
{
    return k == T_HOST || k == T_NET || k == T_PORT || k == T_PORTRANGE;
}

static int aqual_of(int k)
{
    switch (k) {
    case T_HOST: return AQ_HOST;
    case T_NET: return AQ_NET;
    case T_PORT: return AQ_PORT;
    default: return AQ_PORTRANGE;
    }
}

/* head id, with the protocol qualifier already consumed */
static fragment p_head_id(pstate *p, int pq)
{
    qual q;
    int k = peek(p);

    q.proto = pq;
    q.dir = DQ_DEFAULT;
    q.addr = AQ_DEFAULT;

    if (is_dqual(k)) {
        advance(p);
        switch (k) {
        case T_SRC:
            if (peek(p) == T_OR && peek2(p, 1) == T_DST) { advance(p); advance(p); q.dir = DQ_OR; }
            else if (peek(p) == T_AND && peek2(p, 1) == T_DST) { advance(p); advance(p); q.dir = DQ_AND; }
            else q.dir = DQ_SRC;
            break;
        case T_DST:
            if (peek(p) == T_OR && peek2(p, 1) == T_SRC) { advance(p); advance(p); q.dir = DQ_OR; }
            else if (peek(p) == T_AND && peek2(p, 1) == T_SRC) { advance(p); advance(p); q.dir = DQ_AND; }
            else q.dir = DQ_DST;
            break;
        case T_ADDR1: q.dir = DQ_ADDR1; break;
        case T_ADDR2: q.dir = DQ_ADDR2; break;
        case T_ADDR3: q.dir = DQ_ADDR3; break;
        case T_ADDR4: q.dir = DQ_ADDR4; break;
        case T_RA: q.dir = DQ_RA; break;
        case T_TA: q.dir = DQ_TA; break;
        }
        if (is_aqual(peek(p))) {
            q.addr = aqual_of(peek(p));
            advance(p);
        }
    } else if (is_aqual(k)) {
        q.addr = aqual_of(k);
        advance(p);
    } else if (k == T_PROTO) {
        q.addr = AQ_PROTO;
        advance(p);
    } else if (k == T_PROTOCHAIN) {
        q.addr = AQ_PROTOCHAIN;
        advance(p);
    } else if (k == T_GATEWAY) {
        q.addr = AQ_GATEWAY;
        advance(p);
    } else {
        syntax_error(p);
    }
    return p_id(p, q);
}

static fragment p_rterm(pstate *p)
{
    int k = peek(p);
    fragment f;

    switch (k) {
    case T_LPAR:
        if (paren_is_arith(p))
            return p_relation(p);
        advance(p);
        f = p_expr(p);
        expect(p, T_RPAR);
        return f;

    case T_NUM:
    case T_LEN:
    case T_MINUS:
        return p_relation(p);

    case T_PNAME_BASE: {
        int pq = cur(p)->pq;
        int nk = peek2(p, 1);

        if (nk == T_LBRA)
            return p_relation(p);
        advance(p);
        if (is_dqual(nk) || is_aqual(nk) || nk == T_PROTO || nk == T_PROTOCHAIN ||
            nk == T_GATEWAY)
            return p_head_id(p, pq);
        if (nk == T_BROADCAST) {
            advance(p);
            return gen_broadcast(p->cs, pq);
        }
        if (nk == T_MULTICAST) {
            advance(p);
            return gen_multicast(p->cs, pq);
        }
        if (nk == T_TYPE || nk == T_SUBTYPE || nk == T_DIR)
            return p_p80211(p);
        return gen_proto_abbrev(p->cs, pq);
    }

    case T_SRC: case T_DST: case T_ADDR1: case T_ADDR2: case T_ADDR3:
    case T_ADDR4: case T_RA: case T_TA:
    case T_HOST: case T_NET: case T_PORT: case T_PORTRANGE:
    case T_PROTO: case T_PROTOCHAIN: case T_GATEWAY:
        return p_head_id(p, PQ_DEFAULT);

    case T_BROADCAST:
        advance(p);
        return gen_broadcast(p->cs, PQ_DEFAULT);

    case T_MULTICAST:
        advance(p);
        return gen_multicast(p->cs, PQ_DEFAULT);

    case T_LESS: {
        uint32_t v;
        advance(p);
        v = p_pnum(p);
        return gen_less(p->cs, v);
    }

    case T_GREATER: {
        uint32_t v;
        advance(p);
        v = p_pnum(p);
        return gen_greater(p->cs, v);
    }

    case T_INBOUND:
        advance(p);
        return gen_inbound(p->cs, 0);

    case T_OUTBOUND:
        advance(p);
        return gen_inbound(p->cs, 1);

    case T_IFINDEX: {
        uint32_t v;
        advance(p);
        v = p_pnum(p);
        return gen_ifindex(p->cs, (int)v);
    }

    case T_VLAN:
        advance(p);
        if (peek(p) == T_NUM || peek(p) == T_LPAR) {
            uint32_t v = p_pnum(p);
            return gen_vlan(p->cs, v, 1);
        }
        return gen_vlan(p->cs, 0, 0);

    case T_MPLS:
        advance(p);
        if (peek(p) == T_NUM || peek(p) == T_LPAR) {
            uint32_t v = p_pnum(p);
            return gen_mpls(p->cs, v, 1);
        }
        return gen_mpls(p->cs, 0, 0);

    case T_PPPOED:
        advance(p);
        return gen_pppoed(p->cs);

    case T_PPPOES:
        advance(p);
        if (peek(p) == T_NUM || peek(p) == T_LPAR) {
            uint32_t v = p_pnum(p);
            return gen_pppoes(p->cs, v, 1);
        }
        return gen_pppoes(p->cs, 0, 0);

    case T_GENEVE:
        advance(p);
        if (peek(p) == T_NUM || peek(p) == T_LPAR) {
            uint32_t v = p_pnum(p);
            return gen_geneve(p->cs, v, 1);
        }
        return gen_geneve(p->cs, 0, 0);

    case T_TYPE:
    case T_SUBTYPE:
    case T_DIR:
        return p_p80211(p);

    default:
        syntax_error(p);
    }
    return gen_false2(p->cs);
}

static fragment p_term(pstate *p)
{
    if (peek(p) == T_NOT) {
        fragment f;
        advance(p);
        f = p_term(p);
        frag_not2(p->cs, &f);
        return f;
    }
    return p_rterm(p);
}

static fragment p_expr(pstate *p)
{
    fragment f = p_term(p);

    for (;;) {
        if (peek(p) == T_AND) {
            fragment g;
            advance(p);
            g = p_term(p);
            frag_and2(p->cs, &f, g);
        } else if (peek(p) == T_OR) {
            fragment g;
            advance(p);
            g = p_term(p);
            frag_or2(p->cs, &f, g);
        } else {
            break;
        }
    }
    return f;
}

fragment parse_filter(cstate *cs, const char *text)
{
    pstate ps;
    fragment f;

    ps.cs = cs;
    ps.tv = NULL;
    ps.n = 0;
    ps.pos = 0;
    lex_all(cs, text, &ps.tv, &ps.n);

    if (peek(&ps) == T_EOF) {
        f.first = f.last = NULL;
        return f;
    }
    f = p_expr(&ps);
    if (peek(&ps) != T_EOF)
        cs_error(cs, "can't parse filter expression: syntax error");
    return f;
}
