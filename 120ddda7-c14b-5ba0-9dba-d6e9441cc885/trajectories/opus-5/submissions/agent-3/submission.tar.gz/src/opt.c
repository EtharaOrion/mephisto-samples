/*
 * opt.c - the block-graph optimizer.
 *
 * The graph is a DAG whose nodes carry a straight-line statement list and a
 * two-way test. Optimization alternates a value-numbering sweep over the
 * blocks (constant folding, redundant load and store removal) with a branch
 * sweep that redirects edges whose outcome is already settled by a test that
 * dominates them. Both run to a fixed point, then structurally identical
 * blocks are merged and the entry block is advanced past anything that no
 * longer decides anything.
 */
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"

#define NOP_CODE 0xffffu
#define VAL_UNKNOWN 0

#define AX_ATOM N_ATOMS

#define HASHSZ 509

typedef struct valnode {
    int             code;
    uint32_t        v0, v1;
    int             val;
    struct valnode *nxt;
} valnode;

typedef struct {
    cstate    *cs;
    blk      **blocks;
    int        n_blocks;
    edge     **edges;
    int        n_edges;
    blk      **levels;
    int        maxlevel;
    int        nodewords, edgewords;
    uint32_t  *dom_space, *closure_space, *edom_space;
    valnode   *hashtbl[HASHSZ];
    valnode   *vnodes;
    int        nvnodes, maxvnodes;
    struct { int is_const; uint32_t const_val; } *vmap;
    int        curval;
    int        done;
    int        mark;
} ostate;

/* ---------------------------------------------------------------- */
/* bit sets                                                          */

static void set_all(uint32_t *s, int words, uint32_t v)
{
    int i;
    for (i = 0; i < words; i++)
        s[i] = v;
}

static void set_insert(uint32_t *s, int bit)
{
    s[bit >> 5] |= (uint32_t)1 << (bit & 31);
}

static void set_intersect(uint32_t *dst, const uint32_t *src, int words)
{
    int i;
    for (i = 0; i < words; i++)
        dst[i] &= src[i];
}

static void set_union(uint32_t *dst, const uint32_t *src, int words)
{
    int i;
    for (i = 0; i < words; i++)
        dst[i] |= src[i];
}

/* ---------------------------------------------------------------- */
/* graph walking                                                     */

static int is_ret(const blk *b)
{
    return BPF_CLASS(b->code) == BPF_RET;
}

static void number_blks(ostate *o, blk *p)
{
    if (p == NULL || p->mark == o->mark)
        return;
    p->mark = o->mark;
    p->id = o->n_blocks;
    o->blocks[o->n_blocks++] = p;
    if (!is_ret(p)) {
        number_blks(o, p->jt);
        number_blks(o, p->jf);
    }
}

static int count_blks(ostate *o, blk *p)
{
    if (p == NULL || p->mark == o->mark)
        return 0;
    p->mark = o->mark;
    if (is_ret(p))
        return 1;
    return 1 + count_blks(o, p->jt) + count_blks(o, p->jf);
}

static void find_levels_r(ostate *o, blk *b)
{
    int level;

    if (b->mark == o->mark)
        return;
    b->mark = o->mark;
    b->link = NULL;

    if (!is_ret(b)) {
        find_levels_r(o, b->jt);
        find_levels_r(o, b->jf);
        level = b->jt->level;
        if (b->jf->level > level)
            level = b->jf->level;
        level++;
    } else {
        level = 0;
    }
    b->level = level;
    b->link = o->levels[level];
    o->levels[level] = b;
}

static void find_levels(ostate *o, blk *root)
{
    memset(o->levels, 0, sizeof(blk *) * (size_t)(o->n_blocks + 1));
    o->mark++;
    find_levels_r(o, root);
    o->maxlevel = root->level;
}

static void find_dom(ostate *o, blk *root)
{
    int i;
    blk *b;

    set_all(o->dom_space, o->nodewords * o->n_blocks, 0xffffffffu);
    set_all(root->dom, o->nodewords, 0);

    for (i = o->maxlevel; i >= 0; --i) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            set_insert(b->dom, b->id);
            if (is_ret(b))
                continue;
            set_intersect(b->jt->dom, b->dom, o->nodewords);
            set_intersect(b->jf->dom, b->dom, o->nodewords);
        }
    }
}

static void find_edom(ostate *o, blk *root)
{
    int i;
    blk *b;

    set_all(o->edom_space, o->edgewords * o->n_edges, 0xffffffffu);
    set_all(root->et.edom, o->edgewords, 0);
    set_all(root->ef.edom, o->edgewords, 0);

    for (i = o->maxlevel; i >= 0; --i) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            if (is_ret(b))
                continue;
            set_insert(b->et.edom, b->et.id);
            set_insert(b->ef.edom, b->ef.id);
            if (!is_ret(b->jt)) {
                set_intersect(b->jt->et.edom, b->et.edom, o->edgewords);
                set_intersect(b->jt->ef.edom, b->et.edom, o->edgewords);
            }
            if (!is_ret(b->jf)) {
                set_intersect(b->jf->et.edom, b->ef.edom, o->edgewords);
                set_intersect(b->jf->ef.edom, b->ef.edom, o->edgewords);
            }
        }
    }
}

static void find_closure(ostate *o, blk *root)
{
    int i;
    blk *b;

    (void)root;
    set_all(o->closure_space, o->nodewords * o->n_blocks, 0);

    for (i = o->maxlevel; i >= 0; --i) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            set_insert(b->closure, b->id);
            if (is_ret(b))
                continue;
            set_union(b->jt->closure, b->closure, o->nodewords);
            set_union(b->jf->closure, b->closure, o->nodewords);
        }
    }
}

/* ---------------------------------------------------------------- */
/* atoms                                                             */

/* the atom a statement reads, -1 for none, AX_ATOM for both A and X */
static int atomuse(const stmt *s)
{
    if (s->code == NOP_CODE)
        return -1;

    switch (BPF_CLASS(s->code)) {
    case BPF_RET:
        return -1;

    case BPF_LD:
        if (BPF_MODE(s->code) == BPF_IND)
            return X_ATOM;
        if (BPF_MODE(s->code) == BPF_MEM)
            return (int)s->k;
        return -1;

    case BPF_LDX:
        if (BPF_MODE(s->code) == BPF_MSH)
            return -1;
        if (BPF_MODE(s->code) == BPF_MEM)
            return (int)s->k;
        return -1;

    case BPF_ST:
        return A_ATOM;

    case BPF_STX:
        return X_ATOM;

    case BPF_JMP:
    case BPF_ALU:
        if (BPF_SRC(s->code) == BPF_X)
            return AX_ATOM;
        return A_ATOM;

    case BPF_MISC:
        return BPF_MISCOP(s->code) == BPF_TXA ? X_ATOM : A_ATOM;
    }
    return -1;
}

/* the atom a statement writes, -1 for none */
static int atomdef(const stmt *s)
{
    if (s->code == NOP_CODE)
        return -1;

    switch (BPF_CLASS(s->code)) {
    case BPF_LD:
    case BPF_ALU:
        return A_ATOM;
    case BPF_LDX:
        return X_ATOM;
    case BPF_ST:
    case BPF_STX:
        return (int)s->k;
    case BPF_MISC:
        return BPF_MISCOP(s->code) == BPF_TAX ? X_ATOM : A_ATOM;
    }
    return -1;
}

#define ATOMMASK(n) ((uint32_t)1 << (n))
#define ATOMELEM(d, n) (((d) & ATOMMASK(n)) != 0)

static void compute_local_ud(blk *b)
{
    uint32_t def = 0, use = 0, killed = 0;
    stmt *s;
    int atom;

    for (s = b->head_s; s != NULL; s = s->nxt) {
        atom = atomuse(s);
        if (atom >= 0) {
            if (atom == AX_ATOM) {
                if (!ATOMELEM(def, X_ATOM))
                    use |= ATOMMASK(X_ATOM);
                if (!ATOMELEM(def, A_ATOM))
                    use |= ATOMMASK(A_ATOM);
            } else if (!ATOMELEM(def, atom)) {
                use |= ATOMMASK(atom);
            }
        }
        atom = atomdef(s);
        if (atom >= 0) {
            if (!ATOMELEM(use, atom))
                killed |= ATOMMASK(atom);
            def |= ATOMMASK(atom);
        }
    }
    b->def = def;
    b->use = use;
    b->kill = killed;

    /* the block's own test reads the accumulator after the statements run */
    b->out_use = 0;
    if (!is_ret(b)) {
        b->out_use = ATOMMASK(A_ATOM);
        if (BPF_SRC(b->code) == BPF_X)
            b->out_use |= ATOMMASK(X_ATOM);
    }
}

static void find_ud(ostate *o, blk *root)
{
    int i;
    blk *b;

    (void)root;
    for (i = 0; i < o->n_blocks; i++)
        compute_local_ud(o->blocks[i]);

    for (i = 0; i <= o->maxlevel; i++) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            if (!is_ret(b))
                b->out_use |= b->jt->in_use | b->jf->in_use;
            b->in_use = b->use | (b->out_use & ~b->kill);
        }
    }
}

static void find_inedges(ostate *o, blk *root)
{
    int i;
    blk *b;

    (void)root;
    for (i = 0; i < o->n_blocks; i++)
        o->blocks[i]->in_edges = NULL;

    for (i = o->maxlevel; i >= 0; --i) {
        for (b = o->levels[i]; b != NULL; b = b->link) {
            if (is_ret(b))
                continue;
            b->et.nxt = b->jt->in_edges;
            b->jt->in_edges = &b->et;
            b->ef.nxt = b->jf->in_edges;
            b->jf->in_edges = &b->ef;
        }
    }
}

/* ---------------------------------------------------------------- */
/* value numbering                                                   */

static void init_val(ostate *o)
{
    o->curval = 0;
    o->nvnodes = 0;
    memset(o->hashtbl, 0, sizeof(o->hashtbl));
    memset(o->vmap, 0, sizeof(*o->vmap) * (size_t)o->maxvnodes);
}

static int vn(ostate *o, int code, uint32_t v0, uint32_t v1)
{
    unsigned hash;
    valnode *p;
    int val;

    hash = ((unsigned)code ^ (v0 << 4) ^ (v1 << 8)) % HASHSZ;
    for (p = o->hashtbl[hash]; p != NULL; p = p->nxt)
        if (p->code == code && p->v0 == v0 && p->v1 == v1)
            return p->val;

    if (o->curval + 1 >= o->maxvnodes || o->nvnodes >= o->maxvnodes)
        return VAL_UNKNOWN;
    val = ++o->curval;
    if (BPF_MODE(code) == BPF_IMM &&
        (BPF_CLASS(code) == BPF_LD || BPF_CLASS(code) == BPF_LDX)) {
        o->vmap[val].const_val = v0;
        o->vmap[val].is_const = 1;
    }
    p = &o->vnodes[o->nvnodes++];
    p->val = val;
    p->code = code;
    p->v0 = v0;
    p->v1 = v1;
    p->nxt = o->hashtbl[hash];
    o->hashtbl[hash] = p;
    return val;
}

static int vconst(ostate *o, uint32_t k)
{
    return vn(o, BPF_LD | BPF_IMM, k, 0);
}

static int is_const(ostate *o, int v)
{
    return v != VAL_UNKNOWN && v < o->maxvnodes && o->vmap[v].is_const;
}

static void vstore(ostate *o, stmt *s, int *valp, int newval, int alter)
{
    if (alter && *valp == newval && newval != VAL_UNKNOWN) {
        s->code = NOP_CODE;
        o->done = 0;
    } else {
        *valp = newval;
    }
}

static uint32_t fold_alu(int op, uint32_t a, uint32_t b, int *ok)
{
    *ok = 1;
    switch (op) {
    case BPF_ADD: return a + b;
    case BPF_SUB: return a - b;
    case BPF_MUL: return a * b;
    case BPF_DIV:
        if (b == 0) { *ok = 0; return 0; }
        return a / b;
    case BPF_AND: return a & b;
    case BPF_OR:  return a | b;
    case BPF_XOR: return a ^ b;
    case BPF_LSH: return b < 32 ? a << b : 0;
    case BPF_RSH: return b < 32 ? a >> b : 0;
    }
    *ok = 0;
    return 0;
}

static void opt_stmt(ostate *o, stmt *s, int val[], int alter)
{
    int op, v, v0, v1, ok;
    uint32_t r;

    if (s->code == NOP_CODE)
        return;

    switch (BPF_CLASS(s->code)) {
    case BPF_LD:
        switch (BPF_MODE(s->code)) {
        case BPF_IMM:
            v = vconst(o, s->k);
            vstore(o, s, &val[A_ATOM], v, alter);
            break;

        case BPF_MEM:
            v = val[s->k];
            if (alter && is_const(o, v)) {
                s->code = BPF_LD | BPF_IMM;
                s->k = o->vmap[v].const_val;
                o->done = 0;
            }
            vstore(o, s, &val[A_ATOM], v, alter);
            break;

        case BPF_IND:
            v = val[X_ATOM];
            if (alter && is_const(o, v)) {
                s->code = (uint16_t)(BPF_LD | BPF_ABS | BPF_SIZE(s->code));
                s->k += o->vmap[v].const_val;
                v = vn(o, (int)s->code, s->k, 0);
                o->done = 0;
            } else {
                v = vn(o, (int)s->code, s->k, (uint32_t)v);
            }
            vstore(o, s, &val[A_ATOM], v, alter);
            break;

        default:
            v = vn(o, (int)s->code, s->k, 0);
            vstore(o, s, &val[A_ATOM], v, alter);
            break;
        }
        break;

    case BPF_LDX:
        switch (BPF_MODE(s->code)) {
        case BPF_IMM:
            v = vconst(o, s->k);
            vstore(o, s, &val[X_ATOM], v, alter);
            break;

        case BPF_MEM:
            v = val[s->k];
            if (alter && is_const(o, v)) {
                s->code = BPF_LDX | BPF_IMM;
                s->k = o->vmap[v].const_val;
                o->done = 0;
            }
            vstore(o, s, &val[X_ATOM], v, alter);
            break;

        default:
            v = vn(o, (int)s->code, s->k, 0);
            vstore(o, s, &val[X_ATOM], v, alter);
            break;
        }
        break;

    case BPF_ST:
        vstore(o, s, &val[s->k], val[A_ATOM], alter);
        break;

    case BPF_STX:
        vstore(o, s, &val[s->k], val[X_ATOM], alter);
        break;

    case BPF_ALU:
        op = BPF_OP(s->code);
        if (op == BPF_NEG) {
            v = val[A_ATOM];
            if (alter && is_const(o, v)) {
                s->code = BPF_LD | BPF_IMM;
                s->k = (uint32_t)(-(int32_t)o->vmap[v].const_val);
                val[A_ATOM] = vconst(o, s->k);
                o->done = 0;
            } else {
                val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v, 0);
            }
            break;
        }
        if (BPF_SRC(s->code) == BPF_K) {
            v = val[A_ATOM];
            if (alter && is_const(o, v)) {
                r = fold_alu(op, o->vmap[v].const_val, s->k, &ok);
                if (ok) {
                    s->code = BPF_LD | BPF_IMM;
                    s->k = r;
                    val[A_ATOM] = vconst(o, r);
                    o->done = 0;
                    break;
                }
            }
            val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v, (uint32_t)vconst(o, s->k));
            break;
        }
        v0 = val[A_ATOM];
        v1 = val[X_ATOM];
        if (alter && is_const(o, v0) && is_const(o, v1)) {
            r = fold_alu(op, o->vmap[v0].const_val, o->vmap[v1].const_val, &ok);
            if (ok) {
                s->code = BPF_LD | BPF_IMM;
                s->k = r;
                val[A_ATOM] = vconst(o, r);
                o->done = 0;
                break;
            }
        }
        if (alter && is_const(o, v1)) {
            s->code = (uint16_t)(BPF_ALU | op | BPF_K);
            s->k = o->vmap[v1].const_val;
            o->done = 0;
            val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v0,
                             (uint32_t)vconst(o, s->k));
            break;
        }
        val[A_ATOM] = vn(o, (int)s->code, (uint32_t)v0, (uint32_t)v1);
        break;

    case BPF_MISC:
        if (BPF_MISCOP(s->code) == BPF_TAX)
            vstore(o, s, &val[X_ATOM], val[A_ATOM], alter);
        else
            vstore(o, s, &val[A_ATOM], val[X_ATOM], alter);
        break;
    }
}

static void opt_deadstores(ostate *o, blk *b)
{
    stmt *last[N_ATOMS];
    stmt *s;
    int atom;

    memset(last, 0, sizeof(last));

    for (s = b->head_s; s != NULL; s = s->nxt) {
        if (s->code == NOP_CODE)
            continue;
        atom = atomuse(s);
        if (atom >= 0) {
            if (atom == AX_ATOM) {
                last[X_ATOM] = NULL;
                last[A_ATOM] = NULL;
            } else {
                last[atom] = NULL;
            }
        }
        atom = atomdef(s);
        if (atom >= 0) {
            if (last[atom] != NULL) {
                last[atom]->code = NOP_CODE;
                o->done = 0;
            }
            last[atom] = s;
        }
    }
    for (atom = 0; atom < N_ATOMS; atom++) {
        if (last[atom] != NULL && !ATOMELEM(b->out_use, (unsigned)atom)) {
            last[atom]->code = NOP_CODE;
            o->done = 0;
        }
    }
}

/* skip over removed statements */
static stmt *this_op(stmt *s)
{
    while (s != NULL && s->code == NOP_CODE)
        s = s->nxt;
    return s;
}

static void opt_not(blk *b)
{
    blk *t = b->jt;

    b->jt = b->jf;
    b->jf = t;
}

static void opt_peep(ostate *o, blk *b)
{
    stmt *s, *next, *last;
    int val;

    s = this_op(b->head_s);
    if (s == NULL)
        goto tests;

    last = s;
    for (;;) {
        s = this_op(s);
        if (s == NULL)
            break;
        next = this_op(s->nxt);
        if (next == NULL)
            break;
        last = next;

        /* a store followed by loading it into X is a copy */
        if (s->code == BPF_ST && next->code == (BPF_LDX | BPF_MEM) &&
            s->k == next->k) {
            o->done = 0;
            next->code = BPF_MISC | BPF_TAX;
        }

        /* loading a constant only to copy it into X loads X directly */
        if (s->code == (BPF_LD | BPF_IMM) && next->code == (BPF_MISC | BPF_TAX)) {
            s->code = BPF_LDX | BPF_IMM;
            next->code = BPF_MISC | BPF_TXA;
            o->done = 0;
        }

        s = next;
    }

    if (is_ret(b))
        return;

    /*
     * The value left in the accumulator is dead, so the last operation
     * feeding an equality test can often be folded into the test.
     */
    if (b->code == (BPF_JMP | BPF_JEQ | BPF_K) && !ATOMELEM(b->out_use, A_ATOM)) {
        if (last->code == (BPF_ALU | BPF_SUB | BPF_X)) {
            val = b->val[X_ATOM];
            if (is_const(o, val)) {
                b->k += o->vmap[val].const_val;
                last->code = NOP_CODE;
                o->done = 0;
            } else if (b->k == 0) {
                last->code = NOP_CODE;
                b->code = BPF_JMP | BPF_JEQ | BPF_X;
                o->done = 0;
            }
        } else if (last->code == (BPF_ALU | BPF_SUB | BPF_K)) {
            b->k += last->k;
            last->code = NOP_CODE;
            o->done = 0;
        } else if (last->code == (BPF_ALU | BPF_AND | BPF_K) && b->k == 0) {
            b->k = last->k;
            b->code = BPF_JMP | BPF_JSET | BPF_K;
            last->code = NOP_CODE;
            o->done = 0;
            opt_not(b);
        }
    }

tests:
    if (is_ret(b))
        return;

    /* a bit test against no bits, or against every bit, is settled */
    if (b->code == (BPF_JMP | BPF_JSET | BPF_K)) {
        if (b->k == 0)
            b->jt = b->jf;
        if (b->k == 0xffffffffu)
            b->jf = b->jt;
    }

    /* comparing against a known index register compares against a constant */
    val = b->val[X_ATOM];
    if (BPF_SRC(b->code) == BPF_X && is_const(o, val)) {
        b->code = (uint16_t)(b->code & ~BPF_X);
        b->k = o->vmap[val].const_val;
        o->done = 0;
    }

    /* if the accumulator is known the test can be settled outright */
    val = b->val[A_ATOM];
    if (BPF_SRC(b->code) == BPF_K && is_const(o, val)) {
        uint32_t v = o->vmap[val].const_val;
        int taken;

        switch (BPF_OP(b->code)) {
        case BPF_JEQ:  taken = (v == b->k); break;
        case BPF_JGT:  taken = (v > b->k); break;
        case BPF_JGE:  taken = (v >= b->k); break;
        case BPF_JSET: taken = ((v & b->k) != 0); break;
        default: return;
        }
        if (b->jf != b->jt)
            o->done = 0;
        if (taken)
            b->jf = b->jt;
        else
            b->jt = b->jf;
    }
}

static void opt_blk(ostate *o, blk *b, int do_stmts)
{
    stmt *s;
    edge *p;
    int i, aval, xval;

    p = b->in_edges;
    if (p == NULL) {
        memset(b->val, 0, sizeof(b->val));
    } else {
        memcpy(b->val, p->pred->val, sizeof(b->val));
        while ((p = p->nxt) != NULL) {
            for (i = 0; i < N_ATOMS; i++)
                if (b->val[i] != p->pred->val[i])
                    b->val[i] = VAL_UNKNOWN;
        }
    }
    aval = b->val[A_ATOM];
    xval = b->val[X_ATOM];
    for (s = b->head_s; s != NULL; s = s->nxt)
        opt_stmt(o, s, b->val, do_stmts);

    /*
     * A block that leaves nothing behind and reloads what was already
     * there does not need its statements at all.
     */
    if (do_stmts &&
        ((b->out_use == 0 &&
          aval != VAL_UNKNOWN && b->val[A_ATOM] == aval &&
          xval != VAL_UNKNOWN && b->val[X_ATOM] == xval) ||
         is_ret(b))) {
        if (b->head_s != NULL) {
            b->head_s = NULL;
            b->tail_s = NULL;
            o->done = 0;
        }
    } else {
        opt_peep(o, b);
        opt_deadstores(o, b);
    }

    if (is_ret(b))
        return;

    if (BPF_SRC(b->code) == BPF_K)
        b->oval = (uint32_t)vconst(o, b->k);
    else
        b->oval = (uint32_t)b->val[X_ATOM];
    b->et.code = (int)b->code;
    b->ef.code = -(int)b->code;
}

/* ---------------------------------------------------------------- */
/* branch optimization                                               */

/*
 * If the test in "child" is already settled by the test the edge came
 * out of, return the successor the child would take.
 */
static blk *fold_edge(blk *child, edge *ep)
{
    int sense;
    int code = ep->code;
    uint32_t aval0, aval1, oval0, oval1;

    if (code < 0) {
        code = -code;
        sense = 0;
    } else {
        sense = 1;
    }

    if (is_ret(child) || (int)child->code != code)
        return NULL;

    aval0 = (uint32_t)child->val[A_ATOM];
    oval0 = child->oval;
    aval1 = (uint32_t)ep->pred->val[A_ATOM];
    oval1 = ep->pred->oval;

    if (aval0 != aval1 || aval0 == VAL_UNKNOWN)
        return NULL;

    if (oval0 == oval1)
        return sense ? child->jt : child->jf;

    if (sense && code == (BPF_JMP | BPF_JEQ | BPF_K))
        return child->jf;

    return NULL;
}

static int use_conflict(blk *b, blk *succ)
{
    int atom;
    uint32_t use = succ->in_use;

    if (use == 0)
        return 0;

    for (atom = 0; atom < N_ATOMS; atom++) {
        if (!ATOMELEM(use, (unsigned)atom))
            continue;
        if (b->val[atom] != succ->val[atom])
            return 1;
    }
    return 0;
}

static void opt_j(ostate *o, edge *ep)
{
    int i, k;
    blk *target;

    if (is_ret(*ep->succp))
        return;

    if ((*ep->succp)->jt == (*ep->succp)->jf) {
        /*
         * The successor no longer decides anything, so the edge can go
         * straight where it would have gone.
         */
        if (!use_conflict(ep->pred, (*ep->succp)->jt)) {
            o->done = 0;
            *ep->succp = (*ep->succp)->jt;
        }
    }

top:
    for (i = 0; i < o->edgewords; i++) {
        uint32_t x = ep->edom[i];

        while (x != 0) {
            uint32_t t = x & (~x + 1);
            int bit = 0;
            uint32_t u = t;

            x &= ~t;
            while ((u >>= 1) != 0)
                bit++;
            k = bit + i * 32;
            if (k >= o->n_edges)
                continue;
            target = fold_edge(*ep->succp, o->edges[k]);
            if (target != NULL && !use_conflict(ep->pred, target)) {
                o->done = 0;
                *ep->succp = target;
                if (!is_ret(target))
                    goto top;
                break;
            }
        }
    }
}

static void opt_blks(ostate *o, blk *root, int do_stmts)
{
    int i;
    blk *p;

    init_val(o);
    find_inedges(o, root);

    for (i = o->maxlevel; i >= 0; --i)
        for (p = o->levels[i]; p != NULL; p = p->link)
            opt_blk(o, p, do_stmts);

    if (do_stmts) {
        /*
         * The root's own edges cannot be improved by a dominating test,
         * since nothing dominates them.
         */
        for (i = 1; i <= o->maxlevel; i++) {
            for (p = o->levels[i]; p != NULL; p = p->link) {
                if (is_ret(p))
                    continue;
                opt_j(o, &p->et);
                opt_j(o, &p->ef);
            }
        }
    }

}

/* ---------------------------------------------------------------- */
/* block merging                                                     */

static int eq_stmts(stmt *a, stmt *b)
{
    a = this_op(a);
    b = this_op(b);
    while (a != NULL && b != NULL) {
        if (a->code != b->code || a->k != b->k)
            return 0;
        a = this_op(a->nxt);
        b = this_op(b->nxt);
    }
    return a == b;
}

static int eq_blk(blk *a, blk *b)
{
    if (a->code != b->code || a->k != b->k)
        return 0;
    if (is_ret(a))
        return eq_stmts(a->head_s, b->head_s);
    if (a->jt != b->jt || a->jf != b->jf)
        return 0;
    return eq_stmts(a->head_s, b->head_s);
}

static void mark_code(ostate *o, blk *p)
{
    if (p == NULL || p->mark == o->mark)
        return;
    p->mark = o->mark;
    if (!is_ret(p)) {
        mark_code(o, p->jt);
        mark_code(o, p->jf);
    }
}

static void intern_blocks(ostate *o, blk **rootp)
{
    blk *p;
    int i, j, done1;

    for (;;) {
        done1 = 1;
        for (i = 0; i < o->n_blocks; i++)
            o->blocks[i]->link = NULL;

        o->mark++;
        mark_code(o, *rootp);

        for (i = o->n_blocks - 1; i >= 0; --i) {
            p = o->blocks[i];
            if (p->mark != o->mark || p->link != NULL)
                continue;
            for (j = i + 1; j < o->n_blocks; j++) {
                blk *q = o->blocks[j];

                if (q->mark != o->mark || q->link != NULL)
                    continue;
                if (eq_blk(p, q)) {
                    q->link = p;
                    done1 = 0;
                }
            }
        }
        for (i = 0; i < o->n_blocks; i++) {
            p = o->blocks[i];
            if (p->mark != o->mark || is_ret(p))
                continue;
            if (p->jt->link != NULL)
                p->jt = p->jt->link;
            if (p->jf->link != NULL)
                p->jf = p->jf->link;
        }
        if ((*rootp)->link != NULL)
            *rootp = (*rootp)->link;
        if (done1)
            break;
    }
}

static void sappend(blk *b, stmt *s)
{
    stmt *t;

    if (s == NULL)
        return;
    for (t = s; t->nxt != NULL; t = t->nxt)
        ;
    t->nxt = b->head_s;
    if (b->head_s == NULL)
        b->tail_s = t;
    b->head_s = s;
}

static void opt_root(blk **rootp)
{
    stmt *s;

    s = (*rootp)->head_s;
    (*rootp)->head_s = NULL;
    (*rootp)->tail_s = NULL;

    while (!is_ret(*rootp) && (*rootp)->jt == (*rootp)->jf)
        *rootp = (*rootp)->jt;

    sappend(*rootp, s);

    if (is_ret(*rootp)) {
        (*rootp)->head_s = NULL;
        (*rootp)->tail_s = NULL;
    }
}

/* drop the statements the optimizer removed */
static void strip_nops(ostate *o)
{
    int i;

    for (i = 0; i < o->n_blocks; i++) {
        blk *b = o->blocks[i];
        stmt *s, *prev = NULL;

        for (s = b->head_s; s != NULL; s = s->nxt) {
            if (s->code == NOP_CODE) {
                if (prev == NULL)
                    b->head_s = s->nxt;
                else
                    prev->nxt = s->nxt;
            } else {
                prev = s;
            }
        }
        b->tail_s = prev;
    }
}

/* ---------------------------------------------------------------- */

blk *bpf_optimize(cstate *cs, blk *root)
{
    ostate o;
    int i, n, pass;

    memset(&o, 0, sizeof(o));
    o.cs = cs;
    o.mark = 1000000;

    o.mark++;
    n = count_blks(&o, root);
    if (n <= 0)
        return root;

    o.blocks = (blk **)cs_alloc(cs, sizeof(blk *) * (size_t)n);
    o.mark++;
    number_blks(&o, root);

    o.n_edges = 2 * o.n_blocks;
    o.edges = (edge **)cs_alloc(cs, sizeof(edge *) * (size_t)o.n_edges);
    o.levels = (blk **)cs_alloc(cs, sizeof(blk *) * (size_t)(o.n_blocks + 1));
    o.nodewords = (o.n_blocks + 31) / 32;
    o.edgewords = (o.n_edges + 31) / 32;
    o.dom_space = (uint32_t *)cs_alloc(cs, sizeof(uint32_t) *
                                       (size_t)o.nodewords * (size_t)o.n_blocks);
    o.closure_space = (uint32_t *)cs_alloc(cs, sizeof(uint32_t) *
                                           (size_t)o.nodewords * (size_t)o.n_blocks);
    o.edom_space = (uint32_t *)cs_alloc(cs, sizeof(uint32_t) *
                                        (size_t)o.edgewords * (size_t)o.n_edges);
    o.maxvnodes = 8 * o.n_blocks + 256;
    o.vnodes = (valnode *)cs_alloc(cs, sizeof(valnode) * (size_t)o.maxvnodes);
    o.vmap = cs_alloc(cs, sizeof(*o.vmap) * (size_t)o.maxvnodes);

    for (i = 0; i < o.n_blocks; i++) {
        blk *b = o.blocks[i];

        b->dom = o.dom_space + (size_t)i * (size_t)o.nodewords;
        b->closure = o.closure_space + (size_t)i * (size_t)o.nodewords;
        b->et.id = 2 * i;
        b->ef.id = 2 * i + 1;
        b->et.pred = b;
        b->ef.pred = b;
        b->et.succp = &b->jt;
        b->ef.succp = &b->jf;
        b->et.edom = o.edom_space + (size_t)(2 * i) * (size_t)o.edgewords;
        b->ef.edom = o.edom_space + (size_t)(2 * i + 1) * (size_t)o.edgewords;
        o.edges[2 * i] = &b->et;
        o.edges[2 * i + 1] = &b->ef;
    }

    for (pass = 0; pass < 2; pass++) {
        int do_stmts = pass;
        int guard = 0;

        do {
            o.done = 1;
            find_levels(&o, root);
            find_dom(&o, root);
            find_closure(&o, root);
            find_ud(&o, root);
            find_edom(&o, root);
            opt_blks(&o, root, do_stmts);
        } while (!o.done && ++guard < 100);
    }

    intern_blocks(&o, &root);
    opt_root(&root);
    strip_nops(&o);
    return root;
}
