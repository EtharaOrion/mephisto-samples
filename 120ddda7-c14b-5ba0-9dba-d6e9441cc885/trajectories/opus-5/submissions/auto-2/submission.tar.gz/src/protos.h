/*
 * protos.h - wire constants used by the generator.
 */
#ifndef PROTOS_H
#define PROTOS_H

/* data link types */
#define DLT_NULL        0
#define DLT_EN10MB      1
#define DLT_PPP         9
#define DLT_RAW         12
#define DLT_LOOP        108
#define DLT_LINUX_SLL   113
#define DLT_IEEE802_11  105

/* ethertypes */
#define ETHERTYPE_IP        0x0800
#define ETHERTYPE_ARP       0x0806
#define ETHERTYPE_REVARP    0x8035
#define ETHERTYPE_IPV6      0x86dd
#define ETHERTYPE_ATALK     0x809b
#define ETHERTYPE_AARP      0x80f3
#define ETHERTYPE_IPX       0x8137
#define ETHERTYPE_DN        0x6003
#define ETHERTYPE_LAT       0x6004
#define ETHERTYPE_SCA       0x6007
#define ETHERTYPE_MOPDL     0x6001
#define ETHERTYPE_MOPRC     0x6002
#define ETHERTYPE_LOOPBACK  0x9000
#define ETHERTYPE_VLAN      0x8100
#define ETHERTYPE_QINQ      0x88a8
#define ETHERTYPE_8021AD    0x88a8
#define ETHERTYPE_8021QINQ  0x9100
#define ETHERTYPE_MPLS      0x8847
#define ETHERTYPE_MPLS_MULTI 0x8848
#define ETHERTYPE_PPPOED    0x8863
#define ETHERTYPE_PPPOES    0x8864
#define ETHERTYPE_TEB       0x6558
#define ETHERMTU            1500

/* LLC SAPs */
#define LLCSAP_NULL     0x00
#define LLCSAP_IP       0x06
#define LLCSAP_8021D    0x42
#define LLCSAP_SNAP     0xaa
#define LLCSAP_IPX      0xe0
#define LLCSAP_NETBEUI  0xf0
#define LLCSAP_ISONS    0xfe

/* IP protocols */
#define IPPROTO_HOPOPTS   0
#define IPPROTO_ICMP      1
#define IPPROTO_IGMP      2
#define IPPROTO_IPIP      4
#define IPPROTO_TCP       6
#define IPPROTO_EGP       8
#define IPPROTO_IGRP      9
#define IPPROTO_UDP       17
#define IPPROTO_IPV6      41
#define IPPROTO_ROUTING   43
#define IPPROTO_FRAGMENT  44
#define IPPROTO_GRE       47
#define IPPROTO_ESP       50
#define IPPROTO_AH        51
#define IPPROTO_ICMPV6    58
#define IPPROTO_NONE      59
#define IPPROTO_DSTOPTS   60
#define IPPROTO_PIM       103
#define IPPROTO_VRRP      112
#define IPPROTO_CARP      112
#define IPPROTO_SCTP      132
#define IPPROTO_MOBILITY  135
#define IPPROTO_HIP       139
#define IPPROTO_SHIM6     140

/* PPP protocol values */
#define PPP_IP      0x21
#define PPP_OSI     0x23
#define PPP_IPX     0x2b
#define PPP_IPV6    0x57
#define PPP_BRPDU   0x31

/* Linux cooked capture protocol values */
#define LINUX_SLL_P_802_3   0x0001
#define LINUX_SLL_P_802_2   0x0004

#define LINUX_SLL_HOST      0
#define LINUX_SLL_BROADCAST 1
#define LINUX_SLL_MULTICAST 2
#define LINUX_SLL_OTHERHOST 3
#define LINUX_SLL_OUTGOING  4

/* address families as seen in DLT_NULL headers */
#define BSD_AF_INET     2
#define BSD_AF_INET6    10

#define PROTO_UNDEF (-1)

#endif /* PROTOS_H */
