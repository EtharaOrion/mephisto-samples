/*
 * opt.c - the block-graph optimizer.
 */
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"

blk *bpf_optimize(cstate *cs, blk *root)
{
    (void)cs;
    return root;
}
