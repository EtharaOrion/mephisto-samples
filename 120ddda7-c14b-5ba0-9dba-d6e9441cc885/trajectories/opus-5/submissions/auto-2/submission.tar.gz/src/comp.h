/*
 * comp.h - shared types for the filter compiler.
 */
#ifndef COMP_H
#define COMP_H

#include <setjmp.h>
#include <stdint.h>
#include <stddef.h>

#include "bpf_defs.h"

#define JMPOP(x) (BPF_JMP | (x) | BPF_K)

/* protocol qualifiers */
enum {
    PQ_UNDEF = 0,
    PQ_LINK, PQ_IP, PQ_ARP, PQ_RARP, PQ_SCTP, PQ_TCP, PQ_UDP, PQ_ICMP,
    PQ_IGMP, PQ_IGRP, PQ_ATALK, PQ_DECNET, PQ_LAT, PQ_SCA, PQ_MOPRC,
    PQ_MOPDL, PQ_IPV6, PQ_ICMPV6, PQ_AH, PQ_ESP, PQ_PIM, PQ_VRRP, PQ_AARP,
    PQ_ISO, PQ_ESIS, PQ_ISIS, PQ_CLNP, PQ_STP, PQ_IPX, PQ_NETBEUI,
    PQ_ISIS_L1, PQ_ISIS_L2, PQ_ISIS_IIH, PQ_ISIS_SNP, PQ_ISIS_CSNP,
    PQ_ISIS_PSNP, PQ_ISIS_LSP, PQ_RADIO, PQ_CARP, PQ_DEFAULT
};

/* direction qualifiers */
enum {
    DQ_DEFAULT = 0, DQ_SRC, DQ_DST, DQ_OR, DQ_AND, DQ_ADDR1, DQ_ADDR2,
    DQ_ADDR3, DQ_ADDR4, DQ_RA, DQ_TA
};

/* address-type qualifiers */
enum {
    AQ_DEFAULT = 0, AQ_HOST, AQ_NET, AQ_PORT, AQ_GATEWAY, AQ_PROTO,
    AQ_PROTOCHAIN, AQ_PORTRANGE
};

typedef struct stmt {
    uint16_t     code;
    uint32_t     k;
    struct stmt *nxt;
    /* block-local branch targets, used by the variable-offset prologues;
     * NULL means "the block's own test instruction". */
    struct stmt *jt, *jf;
    int          is_jump;
    int          emit_idx;
} stmt;

typedef struct blk blk;
struct blk {
    uint16_t  code;             /* branch opcode, or BPF_RET|BPF_K */
    uint32_t  k;
    stmt     *head_s, *tail_s;  /* statement list */
    blk      *jt, *jf;          /* successors (may be sentinels) */
    blk      *chain;            /* fragment membership chain */

    /* emit/optimizer scratch */
    int       id;
    int       mark;
    int       offset;
    int       longjt, longjf;
    int       level;
    blk      *link;
    int       in_deg;
    /* value-numbering state */
    int      *vals;
    void     *dom, *closure;
    blk      *ef_parent;
};

typedef struct frag {
    blk *head;                  /* entry block */
    blk *first, *last;          /* member chain */
} frag;

/* an arithmetic expression value */
typedef struct arth {
    blk  *b;                    /* guard blocks needed before evaluation */
    frag  g;                    /* guard fragment (may be empty) */
    stmt *s_head, *s_tail;      /* statements computing the value */
    int   regno;                /* scratch register holding the value */
    int   is_const;
    uint32_t cval;
} arth;

typedef struct {
    uint32_t cnst;
    int      isvar;
    int      reg;
} absoff;

#define OFF_UNSET 0x7fffffffu

enum offrel {
    OR_LINKHDR, OR_LINKPL, OR_LINKPL_NOSNAP, OR_LINKTYPE, OR_TRAN_IPV4, OR_TRAN_IPV6
};

#define ARENA_CHUNK 65536

typedef struct arena_chunk {
    struct arena_chunk *nxt;
    size_t used;
    char   mem[ARENA_CHUNK];
} arena_chunk;

typedef struct {
    int      dlt;
    int      snaplen;
    uint32_t netmask;
    int      optimize;

    absoff   off_linkhdr;
    absoff   off_linkpl;
    uint32_t off_linktype_c;
    int      off_linktype_var;
    uint32_t off_nl;
    uint32_t off_nl_nosnap;
    int      linktype_unknown;

    int      is_geneve;
    int      is_vlan_vloffset;
    int      no_optimize;
    int      label_stack_depth;
    uint32_t off_outermostlinkhdr_c;

    /* variable-length link headers */
    int      reg_ll_off;        /* register holding link header offset, -1 */
    int      reg_pl_off;        /* register holding payload offset, -1 */

    int      curreg;
    int      regs_used[BPF_MEMWORDS];

    arena_chunk *arena;
    int      nblocks;

    jmp_buf  jb;
    char     errbuf[256];

    blk     *sent_t, *sent_f;
} cstate;

/* arena */
void *cs_alloc(cstate *cs, size_t n);
void  cs_arena_free(cstate *cs);

/* error reporting: longjmps out */
void cs_error(cstate *cs, const char *fmt, ...);

/* block construction */
blk  *new_blk(cstate *cs, uint16_t code);
stmt *new_stmt(cstate *cs, uint16_t code);
void  blk_add(blk *b, stmt *s);

void frag_init(frag *f, blk *b);
void frag_and(cstate *cs, frag *a, frag *b);
void frag_or(cstate *cs, frag *a, frag *b);
void frag_not(cstate *cs, frag *a);

/* entry point used by the driver */
struct bpfc_case;
int bpfc_compile_case(int dlt, int snaplen, int optimize, uint32_t netmask,
                      const char *filter, bpf_prog_t *out, const char **err);

#endif /* COMP_H */
