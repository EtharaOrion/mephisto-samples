/*
 * names.c - lookups in the pinned name tables.
 *
 * The tables are compiled in (see nmdata.c) so the process reads no files and
 * behaves identically no matter what the host's own /etc looks like.
 */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "names.h"

extern const char nm_protocols_data[];
extern const char nm_services_data[];
extern const char nm_hosts_data[];
extern const char nm_networks_data[];
extern const char nm_ethers_data[];

/* Iterate over lines, splitting into whitespace-separated fields, stopping at
 * '#'. Returns the number of fields, and advances *pp past the line. */
static int split_line(const char **pp, const char **fields, int maxf, size_t *lens)
{
    const char *p = *pp;
    int n = 0;

    if (*p == '\0')
        return -1;
    while (*p && *p != '\n') {
        if (*p == '#') {
            while (*p && *p != '\n') p++;
            break;
        }
        if (*p == ' ' || *p == '\t' || *p == '\r') { p++; continue; }
        if (n < maxf) {
            const char *s = p;
            while (*p && *p != '\n' && *p != ' ' && *p != '\t' && *p != '\r' && *p != '#') p++;
            fields[n] = s;
            lens[n] = (size_t)(p - s);
            n++;
        } else {
            while (*p && *p != '\n' && *p != ' ' && *p != '\t' && *p != '\r') p++;
        }
    }
    if (*p == '\n') p++;
    *pp = p;
    return n;
}

static int feq(const char *f, size_t len, const char *name)
{
    return strlen(name) == len && memcmp(f, name, len) == 0;
}

int nm_proto(const char *name)
{
    const char *p = nm_protocols_data;
    const char *f[8];
    size_t l[8];
    int n;

    while ((n = split_line(&p, f, 8, l)) >= 0) {
        int i;
        if (n < 2)
            continue;
        if (feq(f[0], l[0], name))
            return atoi(f[1]);
        for (i = 2; i < n; i++)
            if (feq(f[i], l[i], name))
                return atoi(f[1]);
    }
    return -1;
}

int nm_service(const char *name, const char *proto)
{
    const char *p = nm_services_data;
    const char *f[16];
    size_t l[16];
    int n;
    size_t plen = strlen(proto);

    while ((n = split_line(&p, f, 16, l)) >= 0) {
        const char *slash;
        int i, match = 0;
        if (n < 2)
            continue;
        slash = memchr(f[1], '/', l[1]);
        if (!slash)
            continue;
        if ((size_t)(l[1] - (size_t)(slash + 1 - f[1])) != plen ||
            memcmp(slash + 1, proto, plen) != 0)
            continue;
        if (feq(f[0], l[0], name))
            match = 1;
        for (i = 2; i < n && !match; i++)
            if (feq(f[i], l[i], name))
                match = 1;
        if (match)
            return atoi(f[1]);
    }
    return -1;
}

static int parse_v4(const char *s, size_t len, uint32_t *out)
{
    uint32_t v = 0;
    int parts = 0;
    size_t i = 0;

    while (i < len) {
        uint32_t o = 0;
        int dig = 0;
        while (i < len && s[i] >= '0' && s[i] <= '9') { o = o * 10 + (uint32_t)(s[i] - '0'); i++; dig++; }
        if (!dig || o > 255)
            return -1;
        v = (v << 8) | o;
        parts++;
        if (i < len) {
            if (s[i] != '.')
                return -1;
            i++;
        }
    }
    if (parts != 4)
        return -1;
    *out = v;
    return 0;
}

static int hexval(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

/* Parse an IPv6 literal (with :: compression, optional trailing IPv4). */
int nm_parse_v6(const char *s, size_t len, uint8_t *out)
{
    uint8_t buf[16];
    int nb = 0, gap = -1;
    size_t i = 0;

    memset(buf, 0, sizeof(buf));
    if (len >= 2 && s[0] == ':' && s[1] == ':') {
        gap = 0;
        i = 2;
    } else if (len >= 1 && s[0] == ':') {
        return -1;
    }
    while (i < len) {
        uint32_t v = 0;
        int dig = 0;
        size_t start = i;
        while (i < len && hexval(s[i]) >= 0) { v = v * 16 + (uint32_t)hexval(s[i]); i++; dig++; }
        if (!dig)
            return -1;
        if (i < len && s[i] == '.') {
            uint32_t v4;
            size_t e = i;
            while (e < len && (s[e] == '.' || (s[e] >= '0' && s[e] <= '9'))) e++;
            if (e != len || parse_v4(s + start, e - start, &v4) < 0)
                return -1;
            if (nb + 4 > 16)
                return -1;
            buf[nb++] = (uint8_t)(v4 >> 24); buf[nb++] = (uint8_t)(v4 >> 16);
            buf[nb++] = (uint8_t)(v4 >> 8);  buf[nb++] = (uint8_t)v4;
            i = len;
            break;
        }
        if (dig > 4 || v > 0xffff)
            return -1;
        if (nb + 2 > 16)
            return -1;
        buf[nb++] = (uint8_t)(v >> 8);
        buf[nb++] = (uint8_t)v;
        if (i < len) {
            if (s[i] != ':')
                return -1;
            i++;
            if (i < len && s[i] == ':') {
                if (gap >= 0)
                    return -1;
                gap = nb;
                i++;
                if (i == len)
                    break;
            } else if (i == len) {
                return -1;
            }
        }
    }
    if (gap >= 0) {
        int move = nb - gap;
        int pad = 16 - nb;
        int j;
        if (pad < 0)
            return -1;
        for (j = move - 1; j >= 0; j--)
            buf[gap + pad + j] = buf[gap + j];
        for (j = 0; j < pad; j++)
            buf[gap + j] = 0;
    } else if (nb != 16) {
        return -1;
    }
    memcpy(out, buf, 16);
    return 0;
}

/*
 * Well-known IPv6 aliases that a host table normally carries alongside the
 * loopback entry; consulted only when the table itself has no match.
 */
static const struct { const char *name; const char *addr; } v6_aliases[] = {
    { "ip6-localhost",    "::1" },
    { "ip6-loopback",     "::1" },
    { "ip6-localnet",     "fe00::0" },
    { "ip6-mcastprefix",  "ff00::0" },
    { "ip6-allnodes",     "ff02::1" },
    { "ip6-allrouters",   "ff02::2" },
    { "ip6-allhosts",     "ff02::3" },
    { NULL, NULL }
};

int nm_host(const char *name, named_addr *out, int max)
{
    const char *p = nm_hosts_data;
    const char *f[16];
    size_t l[16];
    int n, cnt = 0;
    named_addr v4s[8];
    int nv4 = 0;

    while ((n = split_line(&p, f, 16, l)) >= 0) {
        int i, match = 0;
        if (n < 2)
            continue;
        for (i = 1; i < n; i++)
            if (feq(f[i], l[i], name))
                match = 1;
        if (!match)
            continue;
        {
            named_addr a;
            memset(&a, 0, sizeof(a));
            if (memchr(f[0], ':', l[0]) != NULL) {
                if (nm_parse_v6(f[0], l[0], a.v6) == 0) {
                    a.af = ADDR_V6;
                    if (cnt < max)
                        out[cnt++] = a;
                }
            } else {
                if (parse_v4(f[0], l[0], &a.v4) == 0) {
                    a.af = ADDR_V4;
                    if (nv4 < 8)
                        v4s[nv4++] = a;
                }
            }
        }
    }
    {
        int i;
        for (i = 0; i < nv4 && cnt < max; i++)
            out[cnt++] = v4s[i];
    }
    if (cnt == 0) {
        int i;
        for (i = 0; v6_aliases[i].name != NULL; i++) {
            if (strcmp(v6_aliases[i].name, name) == 0) {
                named_addr a;
                memset(&a, 0, sizeof(a));
                if (nm_parse_v6(v6_aliases[i].addr, strlen(v6_aliases[i].addr), a.v6) == 0) {
                    a.af = ADDR_V6;
                    if (cnt < max)
                        out[cnt++] = a;
                }
                break;
            }
        }
    }
    return cnt;
}

long nm_network(const char *name)
{
    const char *p = nm_networks_data;
    const char *f[16];
    size_t l[16];
    int n;

    while ((n = split_line(&p, f, 16, l)) >= 0) {
        int i;
        if (n < 2)
            continue;
        for (i = 0; i < n; i++) {
            if (i == 1)
                continue;
            if (feq(f[i], l[i], name)) {
                /* network numbers may be given with fewer than four octets */
                uint32_t v = 0;
                size_t j = 0;
                int parts = 0;
                const char *s = f[1];
                size_t len = l[1];
                while (j < len) {
                    uint32_t o = 0;
                    int dig = 0;
                    while (j < len && s[j] >= '0' && s[j] <= '9') { o = o * 10 + (uint32_t)(s[j] - '0'); j++; dig++; }
                    if (!dig)
                        return -1;
                    v = (v << 8) | o;
                    parts++;
                    if (j < len && s[j] == '.')
                        j++;
                }
                (void)parts;
                return (long)v;
            }
        }
    }
    return -1;
}

int nm_ether(const char *name, uint8_t *out)
{
    const char *p = nm_ethers_data;
    const char *f[8];
    size_t l[8];
    int n;

    while ((n = split_line(&p, f, 8, l)) >= 0) {
        if (n < 2)
            continue;
        if (feq(f[1], l[1], name)) {
            unsigned b[6];
            char tmp[64];
            if (l[0] >= sizeof(tmp))
                continue;
            memcpy(tmp, f[0], l[0]);
            tmp[l[0]] = '\0';
            if (sscanf(tmp, "%x:%x:%x:%x:%x:%x", &b[0], &b[1], &b[2], &b[3], &b[4], &b[5]) == 6) {
                int i;
                for (i = 0; i < 6; i++)
                    out[i] = (uint8_t)b[i];
                return 0;
            }
        }
    }
    return -1;
}
