/*
 * main.c - CLI entry point.
 *
 *   ./bpfc --cases <in.jsonl> --out <out.jsonl>
 *   ./bpfc --bench <in.jsonl> --reps N
 *
 * --cases compiles every record and writes one output record per input
 * record, in input order.
 *
 * --bench compiles every record `reps` times, writes nothing to the output
 * file, and prints exactly one JSON line to stdout:
 *   {"elapsed_sec":FLOAT,"cases":N,"reps":R,"compiles":N*R,"sink":INT}
 * `sink` accumulates program lengths so the compile cannot be optimised away.
 *
 * Determinism: no clock, no locale, no randomness on the --cases path.
 */
/*
 * clock_gettime and CLOCK_MONOTONIC are POSIX, and -std=c11 hides them unless
 * a feature-test macro asks for them.  The Makefile passes this too, but it
 * does so through CPPFLAGS, which a caller's environment can replace wholesale
 * -- and a build that fails is graded as a run that produced nothing.  Stating
 * it here as well makes the source independent of how it is invoked.  Must
 * come before any system header.
 */
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "bpfc.h"
#include "jsonio.h"

static double now_sec(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

static void run_cases(const bpfc_caseset_t *cs, FILE *out)
{
    bpf_prog_t prog;
    size_t k;

    bpf_prog_init(&prog);
    for (k = 0; k < cs->n; k++) {
        const bpfc_case_t *c = &cs->v[k];
        const char *err = NULL;

        if (bpfc_compile(c, &prog, &err) == 0)
            json_write_ok(out, c->i, &prog);
        else
            json_write_err(out, c->i, err);
    }
    bpf_prog_free(&prog);
}

static void run_bench(const bpfc_caseset_t *cs, int reps)
{
    bpf_prog_t prog;
    volatile unsigned long sink = 0;
    double t0, el;
    int r;
    size_t k;

    bpf_prog_init(&prog);
    t0 = now_sec();
    for (r = 0; r < reps; r++) {
        for (k = 0; k < cs->n; k++) {
            const bpfc_case_t *c = &cs->v[k];
            const char *err = NULL;
            if (bpfc_compile(c, &prog, &err) == 0)
                sink += (unsigned long)prog.len;
        }
    }
    el = now_sec() - t0;
    { extern double g_t[8]; const char *n[7]={"parse+gen","analyses","find_ud","work_node","thread+pull","emit","fuse"}; int q; for(q=0;q<7;q++) fprintf(stderr,"%-12s %7.1f ms\n", n[q], g_t[q]/1e6); }
    { extern double g_t[8]; const char *n[5]={"parse+gen","analyses","find_ud","work_node","thread+pull"}; int q; for(q=0;q<5;q++) fprintf(stderr,"%-12s %7.1f ms\n", n[q], g_t[q]/1e6); }
    bpf_prog_free(&prog);

    printf("{\"elapsed_sec\":%.9f,\"cases\":%zu,\"reps\":%d,\"compiles\":%zu,\"sink\":%lu}\n",
           el, cs->n, reps, cs->n * (size_t)reps, (unsigned long)sink);
}

static void usage(void)
{
    fprintf(stderr, "usage: bpfc --cases <in.jsonl> --out <out.jsonl>\n"
                    "       bpfc --bench <in.jsonl> --reps N\n");
}

int main(int argc, char **argv)
{
    const char *cases_path = NULL, *out_path = NULL, *bench_path = NULL;
    int reps = 1;
    int i;
    bpfc_caseset_t cs;
    FILE *out;

    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--cases") && i + 1 < argc)      cases_path = argv[++i];
        else if (!strcmp(argv[i], "--out") && i + 1 < argc)   out_path   = argv[++i];
        else if (!strcmp(argv[i], "--bench") && i + 1 < argc) bench_path = argv[++i];
        else if (!strcmp(argv[i], "--reps") && i + 1 < argc)  reps       = atoi(argv[++i]);
        else { fprintf(stderr, "bpfc: unknown argument %s\n", argv[i]); return 2; }
    }

    if (bench_path) {
        bpfc_cases_load(bench_path, &cs);
        run_bench(&cs, reps > 0 ? reps : 1);
        bpfc_cases_free(&cs);
        return 0;
    }

    if (!cases_path || !out_path) { usage(); return 2; }

    bpfc_cases_load(cases_path, &cs);
    out = fopen(out_path, "w");
    if (!out) {
        fprintf(stderr, "bpfc: cannot write %s\n", out_path);
        bpfc_cases_free(&cs);
        return 2;
    }
    run_cases(&cs, out);
    /*
     * A short write has to be reported: the contract treats a non-zero exit as
     * a failed run, which is the truthful answer, whereas exiting 0 would offer
     * a truncated file as if it were the complete result.
     */
    if (ferror(out) || fclose(out) != 0) {
        fprintf(stderr, "bpfc: write failed on %s\n", out_path);
        bpfc_cases_free(&cs);
        return 2;
    }
    bpfc_cases_free(&cs);
    return 0;
}
