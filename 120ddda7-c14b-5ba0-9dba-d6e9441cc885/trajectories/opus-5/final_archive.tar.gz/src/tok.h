/* tok.h - scanner token codes.  Single-character operators use their own
 * character value, so the named codes start above 127. */
#ifndef TOK_H
#define TOK_H

enum {
    T_EOF = 0,
    T_BAD = 1,
    T_NUM = 256, T_HID, T_HID6, T_EID, T_ID,
    T_AND, T_OR, T_NOT,
    T_GEQ, T_LEQ, T_NEQ, T_LSH, T_RSH,
    T_SRC, T_DST, T_ADDR1, T_ADDR2, T_ADDR3, T_ADDR4, T_RA, T_TA,
    T_HOST, T_NET, T_PORT, T_PORTRANGE, T_GATEWAY, T_PROTO, T_PROTOCHAIN,
    T_NETMASK,
    T_LESS, T_GREATER, T_CBYTE, T_LEN, T_INBOUND, T_OUTBOUND, T_IFINDEX,
    T_VLAN, T_MPLS, T_PPPOED, T_PPPOES, T_GENEVE,
    T_BROADCAST, T_MULTICAST,
    T_TYPE, T_SUBTYPE, T_DIR,
    /* protocol names */
    T_LINK, T_IP, T_ARP, T_RARP, T_SCTP, T_TCP, T_UDP, T_ICMP, T_IGMP,
    T_IGRP, T_ATALK, T_DECNET, T_LAT, T_SCA, T_MOPRC, T_MOPDL, T_IPV6,
    T_ICMPV6, T_AH, T_ESP, T_PIM, T_VRRP, T_AARP, T_ISO, T_ESIS, T_ISIS,
    T_L1, T_L2, T_IIH, T_SNP, T_CSNP, T_PSNP, T_CLNP, T_STP, T_IPX,
    T_NETBEUI, T_RADIO, T_CARP
};

#endif
