/*
 * compile.c - driver: one case in, one program or one error string out.
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "bpfc.h"
#include "proto.h"
#include <time.h>

double g_t[8];
static double nsec(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec*1e9+ts.tv_nsec;}
#include <time.h>

double g_t[8];
static double nsec(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec*1e9+ts.tv_nsec;}
#include <time.h>

double g_t[6];
static double nsec(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec*1e9+ts.tv_nsec;}

void bpf_prog_init(bpf_prog_t *p)
{
    p->insns = NULL;
    p->len = p->cap = 0;
    p->overflow = 0;
}

void bpf_prog_free(bpf_prog_t *p)
{
    free(p->insns);
    p->insns = NULL;
    p->len = p->cap = 0;
}

void bpf_prog_reset(bpf_prog_t *p)
{
    p->len = 0;
    p->overflow = 0;
}

void bpf_emit(bpf_prog_t *p, uint16_t code, uint8_t jt, uint8_t jf, uint32_t k)
{
    if (p->len == p->cap) {
        size_t ncap = p->cap ? p->cap * 2 : 64;
        bpf_insn_t *ni = realloc(p->insns, ncap * sizeof(*ni));
        if (!ni) return;
        p->insns = ni;
        p->cap = ncap;
    }
    p->insns[p->len].code = code;
    p->insns[p->len].jt = jt;
    p->insns[p->len].jf = jf;
    p->insns[p->len].k = k;
    p->len++;
}

void bpf_err(cstate *cs, const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    vsnprintf(cs->err, sizeof(cs->err), fmt, ap);
    va_end(ap);
    cs->failed = 1;
    longjmp(cs->jmp, 1);
}

static cstate g_cs;
static int g_init;

int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err)
{
    cstate *cs = &g_cs;
    block *b;
    int i;

    if (!g_init) {
        memset(cs, 0, sizeof(*cs));
        g_init = 1;
    }
    ar_reset(&cs->ar);
    cs->failed = 0;
    cs->err[0] = '\0';
    cs->linktype = c->dlt;
    cs->outermostlinktype = c->dlt;
    cs->snaplen = c->snaplen;
    cs->netmask = c->netmask;
    cs->netmask_known = (c->netmask != NETMASK_UNKNOWN);
    cs->root = NULL;
    cs->no_shrink = 0;
    cs->n_steps_made = 0;
    cs->n_nodes_made = 0;
    cs->curreg = BPF_MEMWORDS - 1;
    for (i = 0; i < BPF_MEMWORDS; i++) cs->regused[i] = 0;
    cs->n_blocks = 0;
    cs->non_branch_movement = 0;
    init_linktype(cs);
    bpf_prog_reset(out);

    if (setjmp(cs->jmp)) {
        *err = cs->err;
        return -1;
    }

    { double t0 = nsec();
    { double t0=nsec();
    b = parse_filter(cs, c->filter);
    if (b == NULL)
        cs->root = gen_retblk(cs, cs->snaplen);
    else
        finish_parse(cs, b);

    g_t[0] += nsec() - t0; }
    g_t[0]+=nsec()-t0; }
    if (c->optimize && !cs->no_shrink) {
        if (bpf_optimize(cs) < 0) {
            *err = cs->err;
            return -1;
        }
        g_t[1] += nsec() - t1;
        if (cs->root->code == (BPF_RET | BPF_K) && cs->root->k == 0) {
            snprintf(cs->err, sizeof(cs->err), "expression rejects all packets");
            *err = cs->err;
            return -1;
        }
    }

    if (icode_to_fcode(cs, cs->root, out) < 0) {
        snprintf(cs->err, sizeof(cs->err), "filter expression too complex");
        *err = cs->err;
        return -1;
    }
    g_t[2] += nsec() - t2; }
    return 0;
}
