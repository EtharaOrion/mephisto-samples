/*
 * lex.c - scanner for the filter language.
 *
 * Produces one token at a time into cs->tok.  Longest-match rules, with
 * literal keywords beating identifiers on ties and address literals beating
 * identifiers on equal length.
 *
 * The bump allocator every other module builds its nodes out of lives here
 * too: it is reset, not freed, between filters, so a compile costs no more
 * than the graph it builds.
 */
#include <stdlib.h>
#include <string.h>

#include "bpfc.h"
#include "tok.h"

/* ------------------------------------------------------------------ */
/* arena                                                              */
/* ------------------------------------------------------------------ */
#define ARENA_CHUNK (256u * 1024u)

void *ar_alloc_slow(arena_t *a, size_t n)
{
    achunk *c = a->cur;

    {
        /* look for a already-owned chunk with room, else take a new one */
        achunk *scan = c ? c->next : a->head;
        while (scan != NULL && scan->size < n) scan = scan->next;
        if (scan == NULL) {
            size_t sz = n > ARENA_CHUNK ? n : ARENA_CHUNK;
            scan = malloc(sizeof(achunk) + sz);
            if (!scan) abort();
            scan->base = (char *)(scan + 1);
            scan->size = sz;
            scan->next = NULL;
            if (c == NULL) { scan->next = a->head; a->head = scan; }
            else { scan->next = c->next; c->next = scan; }
        }
        scan->used = 0;
        a->cur = scan;
        c = scan;
    }
    {
        void *p = c->base + c->used;
        c->used += n;
        return p;
    }
}

void ar_reset(arena_t *a)
{
    achunk *c;

    for (c = a->head; c; c = c->next) c->used = 0;
    a->cur = a->head;
}

char *ar_strdup(cstate *cs, const char *s, size_t n)
{
    char *p = ar_alloc(&cs->ar, n + 1);
    memcpy(p, s, n);
    p[n] = '\0';
    return p;
}

/* ------------------------------------------------------------------ */
/* keyword table                                                      */
/* ------------------------------------------------------------------ */
typedef struct { const char *name; int tok; u32 val; } kw_t;

static const kw_t keywords[] = {
    { "dst",        T_DST, 0 },
    { "src",        T_SRC, 0 },
    { "link",       T_LINK, 0 },
    { "ether",      T_LINK, 0 },
    { "ppp",        T_LINK, 0 },
    { "slip",       T_LINK, 0 },
    { "fddi",       T_LINK, 0 },
    { "tr",         T_LINK, 0 },
    { "wlan",       T_LINK, 0 },
    { "arp",        T_ARP, 0 },
    { "rarp",       T_RARP, 0 },
    { "ip",         T_IP, 0 },
    { "sctp",       T_SCTP, 0 },
    { "tcp",        T_TCP, 0 },
    { "udp",        T_UDP, 0 },
    { "icmp",       T_ICMP, 0 },
    { "igmp",       T_IGMP, 0 },
    { "igrp",       T_IGRP, 0 },
    { "pim",        T_PIM, 0 },
    { "vrrp",       T_VRRP, 0 },
    { "carp",       T_CARP, 0 },
    { "radio",      T_RADIO, 0 },
    { "ip6",        T_IPV6, 0 },
    { "icmp6",      T_ICMPV6, 0 },
    { "ah",         T_AH, 0 },
    { "esp",        T_ESP, 0 },
    { "atalk",      T_ATALK, 0 },
    { "aarp",       T_AARP, 0 },
    { "decnet",     T_DECNET, 0 },
    { "lat",        T_LAT, 0 },
    { "sca",        T_SCA, 0 },
    { "moprc",      T_MOPRC, 0 },
    { "mopdl",      T_MOPDL, 0 },
    { "iso",        T_ISO, 0 },
    { "esis",       T_ESIS, 0 },
    { "es-is",      T_ESIS, 0 },
    { "isis",       T_ISIS, 0 },
    { "is-is",      T_ISIS, 0 },
    { "l1",         T_L1, 0 },
    { "l2",         T_L2, 0 },
    { "iih",        T_IIH, 0 },
    { "snp",        T_SNP, 0 },
    { "csnp",       T_CSNP, 0 },
    { "psnp",       T_PSNP, 0 },
    { "clnp",       T_CLNP, 0 },
    { "stp",        T_STP, 0 },
    { "ipx",        T_IPX, 0 },
    { "netbeui",    T_NETBEUI, 0 },
    { "host",       T_HOST, 0 },
    { "net",        T_NET, 0 },
    { "mask",       T_NETMASK, 0 },
    { "port",       T_PORT, 0 },
    { "portrange",  T_PORTRANGE, 0 },
    { "proto",      T_PROTO, 0 },
    { "protochain", T_PROTOCHAIN, 0 },
    { "gateway",    T_GATEWAY, 0 },
    { "less",       T_LESS, 0 },
    { "greater",    T_GREATER, 0 },
    { "byte",       T_CBYTE, 0 },
    { "broadcast",  T_BROADCAST, 0 },
    { "multicast",  T_MULTICAST, 0 },
    { "and",        T_AND, 0 },
    { "or",         T_OR, 0 },
    { "not",        T_NOT, 0 },
    { "len",        T_LEN, 0 },
    { "length",     T_LEN, 0 },
    { "inbound",    T_INBOUND, 0 },
    { "outbound",   T_OUTBOUND, 0 },
    { "ifindex",    T_IFINDEX, 0 },
    { "vlan",       T_VLAN, 0 },
    { "mpls",       T_MPLS, 0 },
    { "pppoed",     T_PPPOED, 0 },
    { "pppoes",     T_PPPOES, 0 },
    { "geneve",     T_GENEVE, 0 },
    { "type",       T_TYPE, 0 },
    { "subtype",    T_SUBTYPE, 0 },
    { "direction",  T_DIR, 0 },
    { "dir",        T_DIR, 0 },
    { "addr1",      T_ADDR1, 0 },
    { "addr2",      T_ADDR2, 0 },
    { "addr3",      T_ADDR3, 0 },
    { "addr4",      T_ADDR4, 0 },
    { "ra",         T_RA, 0 },
    { "ta",         T_TA, 0 },
    { "icmptype",   T_NUM, 0 },
    { "icmpcode",   T_NUM, 1 },
    { "tcpflags",   T_NUM, 13 },
    { "tcp-fin",    T_NUM, 0x01 },
    { "tcp-syn",    T_NUM, 0x02 },
    { "tcp-rst",    T_NUM, 0x04 },
    { "tcp-push",   T_NUM, 0x08 },
    { "tcp-ack",    T_NUM, 0x10 },
    { "tcp-urg",    T_NUM, 0x20 },
    { "tcp-ece",    T_NUM, 0x40 },
    { "tcp-cwr",    T_NUM, 0x80 },
    { "icmp-echoreply",      T_NUM, 0 },
    { "icmp-unreach",        T_NUM, 3 },
    { "icmp-sourcequench",   T_NUM, 4 },
    { "icmp-redirect",       T_NUM, 5 },
    { "icmp-echo",           T_NUM, 8 },
    { "icmp-routeradvert",   T_NUM, 9 },
    { "icmp-routersolicit",  T_NUM, 10 },
    { "icmp-timxceed",       T_NUM, 11 },
    { "icmp-paramprob",      T_NUM, 12 },
    { "icmp-tstamp",         T_NUM, 13 },
    { "icmp-tstampreply",    T_NUM, 14 },
    { "icmp-ireq",           T_NUM, 15 },
    { "icmp-ireqreply",      T_NUM, 16 },
    { "icmp-maskreq",        T_NUM, 17 },
    { "icmp-maskreply",      T_NUM, 18 },
    { NULL, 0, 0 }
};

/* ------------------------------------------------------------------ */
/* character classes                                                  */
/* ------------------------------------------------------------------ */
static int is_alnum(int c)
{
    return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
}
static int is_word(int c)
{
    return is_alnum(c) || c == '-' || c == '_' || c == '.';
}
static int hexval(int c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

/* length of a run of 1..maxd hex digits */
static size_t hexrun(const char *p, int maxd)
{
    size_t n = 0;
    while (n < (size_t)maxd && hexval((unsigned char)p[n]) >= 0) n++;
    return n;
}

/* Match "B:B:B:B:B:B" (each 1-2 hex digits). Returns length or 0. */
static size_t match_eid(const char *p)
{
    size_t o = 0;
    int i;
    for (i = 0; i < 6; i++) {
        size_t n = hexrun(p + o, 2);
        if (n == 0) return 0;
        o += n;
        if (i < 5) {
            if (p[o] != ':') return 0;
            o++;
        }
    }
    if (is_word((unsigned char)p[o]) || p[o] == ':') return 0;
    return o;
}

/*
 * Match an IPv6 literal.  Returns its length or 0.  Accepts the usual
 * colon-hex forms with an optional "::" run and an optional trailing dotted
 * quad.
 */
static size_t match_hid6(const char *p)
{
    size_t o = 0;
    int groups = 0, sawdc = 0, ok = 0, sawcolon = 0;

    if (p[0] == ':' && p[1] == ':') { sawdc = 1; sawcolon = 1; o = 2; }
    else if (hexrun(p, 4) == 0) return 0;

    for (;;) {
        size_t n = hexrun(p + o, 4);
        if (n == 0) break;
        /* an embedded dotted quad terminates the address */
        if (p[o + n] == '.') {
            size_t q = o, dots = 0;
            while (is_alnum((unsigned char)p[q]) || p[q] == '.') {
                if (p[q] == '.') dots++;
                q++;
            }
            if (dots == 3) { o = q; groups += 2; }
            break;
        }
        o += n;
        groups++;
        if (p[o] == ':') {
            sawcolon = 1;
            if (p[o + 1] == ':') {
                if (sawdc) break;
                sawdc = 1;
                o += 2;
                continue;
            }
            o++;
            continue;
        }
        break;
    }
    if (o > 0 && p[o - 1] == ':' && !(o >= 2 && p[o - 2] == ':')) o--;   /* trailing single ':' */
    if (!sawcolon) return 0;
    ok = sawdc ? (groups <= 7) : (groups == 8);
    if (!ok) return 0;
    if (is_word((unsigned char)p[o]) || p[o] == ':') return 0;
    return o;
}

/* Match N.N.N.N of decimal/hex numbers. Returns length or 0. */
static size_t match_hid(const char *p)
{
    size_t o = 0;
    int i;
    for (i = 0; i < 4; i++) {
        size_t n = 0;
        if (p[o] == '0' && (p[o+1] == 'x' || p[o+1] == 'X') && hexval((unsigned char)p[o+2]) >= 0) {
            n = 2;
            while (hexval((unsigned char)p[o+n]) >= 0) n++;
        } else {
            while (p[o+n] >= '0' && p[o+n] <= '9') n++;
        }
        if (n == 0) return 0;
        o += n;
        if (i < 3) {
            if (p[o] != '.') return 0;
            o++;
        }
    }
    return o;
}

/* Match a NUM. Returns length or 0. */
static size_t match_num(const char *p, u32 *val)
{
    size_t n = 0;
    u32 v = 0;
    if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X') && hexval((unsigned char)p[2]) >= 0) {
        n = 2;
        while (hexval((unsigned char)p[n]) >= 0) { v = v * 16u + (u32)hexval((unsigned char)p[n]); n++; }
    } else if (p[0] >= '0' && p[0] <= '9') {
        if (p[0] == '0') {
            n = 1;
            v = 0;
            while (p[n] >= '0' && p[n] <= '7') { v = v * 8u + (u32)(p[n] - '0'); n++; }
            if (p[n] >= '8' && p[n] <= '9') {
                /* not octal after all: plain decimal */
                n = 0; v = 0;
                while (p[n] >= '0' && p[n] <= '9') { v = v * 10u + (u32)(p[n] - '0'); n++; }
            }
        } else {
            while (p[n] >= '0' && p[n] <= '9') { v = v * 10u + (u32)(p[n] - '0'); n++; }
        }
    }
    if (val) *val = v;
    return n;
}

/* Match the identifier rule: [A-Za-z0-9]([-_.A-Za-z0-9]*[.A-Za-z0-9])? */
/* Also reports whether the run holds a '.', which is what decides if the word
 * is worth trying as a dotted address; the caller would otherwise walk it a
 * second time to find out. */
static size_t match_id(const char *p, int *has_dot)
{
    size_t n = 0, last = 0;
    int dot = 0;

    *has_dot = 0;
    if (!is_alnum((unsigned char)p[0])) return 0;
    n = 1; last = 1;
    while (is_word((unsigned char)p[n])) {
        n++;
        if (p[n - 1] == '.') { dot = 1; last = n; }
        else if (is_alnum((unsigned char)p[n - 1])) last = n;
    }
    *has_dot = dot;
    return last;
}

void lex_init(cstate *cs, const char *text)
{
    cs->lex_p = text;
    cs->tok = 0;
}

#define KWBUCKETS 512
#define KWHASH(s, n) ((((unsigned char)(s)[0] * 131u) + \
                       (unsigned char)(s)[(n) - 1] * 7u + (unsigned)(n)) & \
                      (KWBUCKETS - 1))

static short kw_first[KWBUCKETS];
static short kw_next[sizeof(keywords) / sizeof(keywords[0])];
static unsigned char kw_len[sizeof(keywords) / sizeof(keywords[0])];
static int kw_ready;

static void kw_index(void)
{
    int i;
    for (i = 0; i < KWBUCKETS; i++) kw_first[i] = -1;
    for (i = 0; keywords[i].name; i++) {
        size_t len = strlen(keywords[i].name);
        unsigned h = KWHASH(keywords[i].name, len);
        kw_len[i] = (unsigned char)len;
        kw_next[i] = kw_first[h];
        kw_first[h] = (short)i;
    }
    kw_ready = 1;
}

static int kw_lookup(const char *s, size_t n, u32 *val)
{
    int i;

    if (!kw_ready) kw_index();
    for (i = kw_first[KWHASH(s, n)]; i >= 0; i = kw_next[i]) {
        if (kw_len[i] != n) continue;
        if (memcmp(keywords[i].name, s, n) != 0) continue;
        *val = keywords[i].val;
        return keywords[i].tok;
    }
    return 0;
}

void lex_next(cstate *cs)
{
    const char *p = cs->lex_p;
    size_t n;

    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r') p++;
    cs->save_p = p;
    cs->tok_num = 0;
    cs->tok_str = NULL;

    if (*p == '\0') { cs->tok = T_EOF; cs->lex_p = p; return; }

    /* backslash escape: everything up to a delimiter is an identifier */
    if (*p == '\\') {
        const char *s = p + 1;
        n = 0;
        while (s[n] && s[n] != ' ' && s[n] != '\t' && s[n] != '\n' &&
               s[n] != '(' && s[n] != ')' && s[n] != '!') n++;
        if (n > 0) {
            cs->tok_str = ar_strdup(cs, s, n);
            cs->tok_len = n;
            cs->tok = T_ID;
            cs->lex_p = s + n;
            return;
        }
    }

    if (is_alnum((unsigned char)*p) || (p[0] == ':' && p[1] == ':')) {
        size_t l_eid = 0, l_h6 = 0, l_hid = 0, l_id, l_num, best = 0;
        u32 numval = 0;
        int which = 0;   /* 1 eid, 2 hid6, 3 hid, 4 num, 5 id */
        size_t hr;
        int dotted = 0;

        /* colon-separated forms only if a ':' actually follows a hex run */
        hr = hexrun(p, 4);
        if (p[0] == ':' || p[hr] == ':') {
            l_eid = match_eid(p);
            l_h6  = match_hid6(p);
        }
        /* dotted quads only if there is a '.' in the word */
        l_id  = match_id(p, &dotted);
        if (dotted) l_hid = match_hid(p);
        l_num = match_num(p, &numval);

        if (l_eid > best) { best = l_eid; which = 1; }
        if (l_h6  > best) { best = l_h6;  which = 2; }
        if (l_hid > best) { best = l_hid; which = 3; }
        if (l_num > best) { best = l_num; which = 4; }
        if (l_id  > best) { best = l_id;  which = 5; }

        if (which == 5) {
            u32 kv;
            int t = kw_lookup(p, l_id, &kv);
            if (t) {
                cs->tok = t;
                cs->tok_num = kv;
                cs->lex_p = p + l_id;
                return;
            }
        }
        cs->lex_p = p + best;
        cs->tok_len = best;
        if (which == 4) {
            cs->tok = T_NUM;
            cs->tok_num = numval;
            cs->tok_str = NULL;
            return;
        }
        switch (which) {
        case 1: cs->tok = T_EID; break;
        case 2: cs->tok = T_HID6; break;
        case 3: cs->tok = T_HID; break;
        default: cs->tok = T_ID; break;
        }
        cs->tok_str = ar_strdup(cs, p, best);
        return;
    }

    /* operators */
    switch (*p) {
    case '>': if (p[1] == '=') { cs->tok = T_GEQ; cs->lex_p = p + 2; }
              else if (p[1] == '>') { cs->tok = T_RSH; cs->lex_p = p + 2; }
              else { cs->tok = '>'; cs->lex_p = p + 1; }
              return;
    case '<': if (p[1] == '=') { cs->tok = T_LEQ; cs->lex_p = p + 2; }
              else if (p[1] == '<') { cs->tok = T_LSH; cs->lex_p = p + 2; }
              else { cs->tok = '<'; cs->lex_p = p + 1; }
              return;
    case '!': if (p[1] == '=') { cs->tok = T_NEQ; cs->lex_p = p + 2; }
              else { cs->tok = T_NOT; cs->lex_p = p + 1; }
              return;
    case '=': if (p[1] == '=') { cs->tok = '='; cs->lex_p = p + 2; }
              else { cs->tok = '='; cs->lex_p = p + 1; }
              return;
    case '&': if (p[1] == '&') { cs->tok = T_AND; cs->lex_p = p + 2; }
              else { cs->tok = '&'; cs->lex_p = p + 1; }
              return;
    case '|': if (p[1] == '|') { cs->tok = T_OR; cs->lex_p = p + 2; }
              else { cs->tok = '|'; cs->lex_p = p + 1; }
              return;
    case '(': case ')': case '[': case ']': case ':': case ',':
    case '+': case '-': case '*': case '/': case '%': case '^':
        cs->tok = (unsigned char)*p; cs->lex_p = p + 1; return;
    default:
        cs->tok = T_BAD; cs->lex_p = p + 1; return;
    }
}
