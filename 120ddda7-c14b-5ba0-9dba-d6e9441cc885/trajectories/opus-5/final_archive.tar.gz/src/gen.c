/*
 * gen.c - block-graph generation.
 */
#include <string.h>
#include <stdlib.h>

#include "bpfc.h"
#include "gen.h"
#include "proto.h"

/* ------------------------------------------------------------------ */
/* primitives                                                         */
/* ------------------------------------------------------------------ */
sstmt *new_stmt(cstate *cs, int code)
{
    sstmt *s = ar_alloc(&cs->ar, sizeof(*s));
    memset(s, 0, sizeof(*s));
    s->code = code;
    return s;
}

block *new_block(cstate *cs, int code)
{
    block *b = ar_alloc(&cs->ar, sizeof(*b));
    memset(b, 0, sizeof(*b));
    b->code = code;
    b->head = b;
    return b;
}

void sappend(sstmt *s0, sstmt *s1)
{
    while (s0->next) s0 = s0->next;
    s0->next = s1;
}

block *gen_retblk(cstate *cs, int v)
{
    block *b = new_block(cs, BPF_RET | BPF_K);
    b->k = (u32)v;
    return b;
}

void backpatch(block *list, block *target)
{
    block *next;
    while (list) {
        if (!list->sense) { next = JT(list); JT(list) = target; }
        else              { next = JF(list); JF(list) = target; }
        list = next;
    }
}

static void merge(block *b0, block *b1)
{
    block **p = &b0;
    while (*p) p = !(*p)->sense ? &JT(*p) : &JF(*p);
    *p = b1;
}

void gen_and(block *b0, block *b1)
{
    backpatch(b0, b1->head);
    b0->sense = !b0->sense;
    b1->sense = !b1->sense;
    merge(b1, b0);
    b1->sense = !b1->sense;
    b1->head = b0->head;
}

void gen_or(block *b0, block *b1)
{
    b0->sense = !b0->sense;
    backpatch(b0, b1->head);
    b0->sense = !b0->sense;
    merge(b1, b0);
    b1->head = b0->head;
}

void gen_not(block *b)
{
    b->sense = !b->sense;
}

/* ------------------------------------------------------------------ */
/* register allocation                                                */
/* ------------------------------------------------------------------ */
int alloc_reg(cstate *cs)
{
    int n = cs->curreg;
    while (n >= 0) {
        if (!cs->regused[n]) { cs->curreg = n; cs->regused[n] = 1; return n; }
        n--;
    }
    bpf_err(cs, "too many registers needed to evaluate expression");
    return 0;
}

void free_reg(cstate *cs, int n)
{
    if (n >= 0 && n < BPF_MEMWORDS) cs->regused[n] = 0;
}

/* ------------------------------------------------------------------ */
/* loads                                                              */
/* ------------------------------------------------------------------ */
static sstmt *gen_abs_offset_variable_part(cstate *cs, absoff *off)
{
    sstmt *s;
    if (!off->is_variable) return NULL;
    if (off->reg == -1) off->reg = alloc_reg(cs);
    s = new_stmt(cs, BPF_LDX | BPF_MEM);
    s->k = (u32)off->reg;
    return s;
}

static sstmt *gen_load_absoffsetrel(cstate *cs, absoff *off, u32 offset, u32 size)
{
    sstmt *s, *s2;

    s = gen_abs_offset_variable_part(cs, off);
    if (s != NULL) {
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->k = off->constant_part + offset;
        sappend(s, s2);
        return s;
    }
    s = new_stmt(cs, BPF_LD | BPF_ABS | size);
    s->k = off->constant_part + offset;
    return s;
}

static sstmt *gen_loadx_iphdrlen(cstate *cs)
{
    sstmt *s, *s2;

    s = gen_abs_offset_variable_part(cs, &cs->off_linkpl);
    if (s != NULL) {
        /* X currently holds the variable part; add the IP header length */
        s2 = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
        s2->k = cs->off_linkpl.constant_part + cs->off_nl;
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->k = 0xf;
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_ALU | BPF_LSH | BPF_K);
        s2->k = 2;
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X);
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_MISC | BPF_TAX);
        sappend(s, s2);
        return s;
    }
    s = new_stmt(cs, BPF_LDX | BPF_MSH | BPF_B);
    s->k = cs->off_linkpl.constant_part + cs->off_nl;
    return s;
}

sstmt *gen_load_a(cstate *cs, int offrel, u32 offset, u32 size)
{
    sstmt *s, *s2;

    switch (offrel) {
    case OR_PACKET:
        s = new_stmt(cs, BPF_LD | BPF_ABS | size);
        s->k = offset;
        return s;
    case OR_LINKHDR:
        return gen_load_absoffsetrel(cs, &cs->off_linkhdr, offset, size);
    case OR_PREVLINKHDR:
        return gen_load_absoffsetrel(cs, &cs->off_prevlinkhdr, offset, size);
    case OR_LLC:
        return gen_load_absoffsetrel(cs, &cs->off_linkpl, offset, size);
    case OR_PREVMPLSHDR:
        return gen_load_absoffsetrel(cs, &cs->off_linkpl, cs->off_nl - 4 + offset, size);
    case OR_LINKTYPE:
        return gen_load_absoffsetrel(cs, &cs->off_linktype, offset, size);
    case OR_LINKPL:
        return gen_load_absoffsetrel(cs, &cs->off_linkpl, cs->off_nl + offset, size);
    case OR_LINKPL_NOSNAP:
        return gen_load_absoffsetrel(cs, &cs->off_linkpl, cs->off_nl_nosnap + offset, size);
    case OR_TRAN_IPV4:
        s = gen_loadx_iphdrlen(cs);
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->k = cs->off_linkpl.constant_part + cs->off_nl + offset;
        sappend(s, s2);
        return s;
    default: /* OR_TRAN_IPV6 */
        return gen_load_absoffsetrel(cs, &cs->off_linkpl, cs->off_nl + 40 + offset, size);
    }
}

/* ------------------------------------------------------------------ */
/* comparisons                                                        */
/* ------------------------------------------------------------------ */
block *gen_ncmp(cstate *cs, int offrel, u32 offset, u32 size, u32 mask,
                int jtype, int reverse, u32 v)
{
    sstmt *s, *s2;
    block *b;

    s = gen_load_a(cs, offrel, offset, size);
    if (mask != 0xffffffffu) {
        s2 = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->k = mask;
        sappend(s, s2);
    }
    b = new_block(cs, JMPOP(jtype));
    b->stmts = s;
    b->k = v;
    if (reverse) gen_not(b);
    return b;
}

block *gen_cmp(cstate *cs, int offrel, u32 offset, u32 size, u32 v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JEQ, 0, v);
}

block *gen_cmp_gt(cstate *cs, int offrel, u32 offset, u32 size, u32 v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGT, 0, v);
}

block *gen_cmp_ge(cstate *cs, int offrel, u32 offset, u32 size, u32 v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGT, 0, v - 1);
}

block *gen_cmp_le(cstate *cs, int offrel, u32 offset, u32 size, u32 v)
{
    return gen_ncmp(cs, offrel, offset, size, 0xffffffffu, BPF_JGT, 1, v);
}

block *gen_mcmp(cstate *cs, int offrel, u32 offset, u32 size, u32 v, u32 mask)
{
    return gen_ncmp(cs, offrel, offset, size, mask, BPF_JEQ, 0, v);
}

block *gen_bcmp(cstate *cs, int offrel, u32 offset, u32 size, const unsigned char *v)
{
    block *b = NULL, *tmp;

    while (size >= 4) {
        const unsigned char *p = &v[size - 4];
        u32 w = ((u32)p[0] << 24) | ((u32)p[1] << 16) | ((u32)p[2] << 8) | p[3];
        tmp = gen_cmp(cs, offrel, offset + size - 4, BPF_W, w);
        if (b != NULL) gen_and(b, tmp);
        b = tmp;
        size -= 4;
    }
    while (size >= 2) {
        const unsigned char *p = &v[size - 2];
        u32 w = ((u32)p[0] << 8) | p[1];
        tmp = gen_cmp(cs, offrel, offset + size - 2, BPF_H, w);
        if (b != NULL) gen_and(b, tmp);
        b = tmp;
        size -= 2;
    }
    if (size > 0) {
        tmp = gen_cmp(cs, offrel, offset, BPF_B, (u32)v[0]);
        if (b != NULL) gen_and(b, tmp);
        b = tmp;
    }
    return b;
}

static block *gen_uncond(cstate *cs, int rsense)
{
    sstmt *s;
    block *b;

    s = new_stmt(cs, BPF_LD | BPF_IMM);
    s->k = (u32)!rsense;
    b = new_block(cs, JMPOP(BPF_JEQ));
    b->stmts = s;
    return b;
}

block *gen_true(cstate *cs)  { return gen_uncond(cs, 1); }
block *gen_false(cstate *cs) { return gen_uncond(cs, 0); }
