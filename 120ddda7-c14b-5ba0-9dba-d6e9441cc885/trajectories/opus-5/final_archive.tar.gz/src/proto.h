/* proto.h - protocol constants and internal codegen helpers. */
#ifndef PROTO_H
#define PROTO_H

#include <stddef.h>
#include <string.h>

#include "bpfc.h"

#define ETHERTYPE_IP      0x0800
#define ETHERTYPE_ARP     0x0806
#define ETHERTYPE_REVARP  0x8035
#define ETHERTYPE_IPV6    0x86dd
#define ETHERTYPE_ATALK   0x809b
#define ETHERTYPE_AARP    0x80f3
#define ETHERTYPE_IPX     0x8137
#define ETHERTYPE_NS      0x0600
#define ETHERTYPE_SPRITE  0x0500
#define ETHERTYPE_TRAIL   0x1000
#define ETHERTYPE_MOPDL   0x6001
#define ETHERTYPE_MOPRC   0x6002
#define ETHERTYPE_DN      0x6003
#define ETHERTYPE_LAT     0x6004
#define ETHERTYPE_SCA     0x6007
#define ETHERTYPE_LANBRIDGE 0x8038
#define ETHERTYPE_DECDNS  0x803c
#define ETHERTYPE_DECDTS  0x803e
#define ETHERTYPE_VEXP    0x805b
#define ETHERTYPE_VPROD   0x805c
#define ETHERTYPE_LOOPBACK 0x9000
#define ETHERTYPE_8021Q   0x8100
#define ETHERTYPE_8021AD  0x88a8
#define ETHERTYPE_8021QINQ 0x9100
#define ETHERTYPE_MPLS    0x8847
#define ETHERTYPE_MPLS_MULTI 0x8848
#define ETHERTYPE_PPPOED  0x8863
#define ETHERTYPE_PPPOES  0x8864
#define ETHERTYPE_JUMBO   0x8870
#define ETHERTYPE_GENEVE_PORT 6081
#define ETHERMTU          1500

#define LLCSAP_NULL       0x00
#define LLCSAP_8021B_I    0x02
#define LLCSAP_IP         0x06
#define LLCSAP_SNA        0x04
#define LLCSAP_PROWAYNM   0x0e
#define LLCSAP_8021D      0x42
#define LLCSAP_RS511      0x4e
#define LLCSAP_ISO8208    0x7e
#define LLCSAP_PROWAY     0x8e
#define LLCSAP_IPX        0xe0
#define LLCSAP_NETBEUI    0xf0
#define LLCSAP_ISONS      0xfe
#define LLCSAP_GLOBAL     0xff
#define LLCSAP_SNAP       0xaa

#define IPPROTO_ICMP      1
#define IPPROTO_IGMP      2
#define IPPROTO_TCP       6
#define IPPROTO_EGP       8
#define IPPROTO_IGRP      9
#define IPPROTO_UDP       17
#define IPPROTO_RSVP      46
#define IPPROTO_GRE       47
#define IPPROTO_ESP       50
#define IPPROTO_AH        51
#define IPPROTO_MOBILITY  135
#define IPPROTO_ICMPV6    58
#define IPPROTO_NONE      59
#define IPPROTO_DSTOPTS   60
#define IPPROTO_ROUTING   43
#define IPPROTO_FRAGMENT  44
#define IPPROTO_HOPOPTS   0
#define IPPROTO_PIM       103
#define IPPROTO_VRRP      112
#define IPPROTO_CARP      112
#define IPPROTO_SCTP      132

#define PPP_IP            0x0021
#define PPP_IPV6          0x0057
#define PPP_IPX           0x002b
#define PPP_OSI           0x0023
#define PPP_MPLS_UCAST    0x0281
#define PPP_MPLS_MCAST    0x0283
#define PPP_DECNET        0x0027
#define PPP_APPLE         0x0029
#define PPP_NS            0x0025
#define PPP_VJC           0x002d
#define PPP_VJNC          0x002f

#define LINUX_SLL_HOST      0
#define LINUX_SLL_BROADCAST 1
#define LINUX_SLL_MULTICAST 2
#define LINUX_SLL_OTHERHOST 3
#define LINUX_SLL_OUTGOING  4
#define LINUX_SLL_P_802_3   0x0001
#define LINUX_SLL_P_802_2   0x0004

#define SKF_AD_OFF        (-0x1000)
#define SKF_AD_PROTOCOL   0
#define SKF_AD_PKTTYPE    4
#define SKF_AD_IFINDEX    8
#define SKF_AD_VLAN_TAG   44
#define SKF_AD_VLAN_TAG_PRESENT 48

/* internal helpers shared between the gen*.c files */
sstmt *new_stmt(cstate *cs, int code);
block *new_block(cstate *cs, int code);
void   sappend(sstmt *s0, sstmt *s1);
sstmt *gen_load_a(cstate *cs, int offrel, u32 offset, u32 size);
block *gen_ncmp(cstate *cs, int offrel, u32 offset, u32 size, u32 mask,
                int jtype, int reverse, u32 v);
block *gen_cmp(cstate *cs, int offrel, u32 offset, u32 size, u32 v);
block *gen_cmp_gt(cstate *cs, int offrel, u32 offset, u32 size, u32 v);
block *gen_cmp_ge(cstate *cs, int offrel, u32 offset, u32 size, u32 v);
block *gen_cmp_le(cstate *cs, int offrel, u32 offset, u32 size, u32 v);
block *gen_mcmp(cstate *cs, int offrel, u32 offset, u32 size, u32 v, u32 mask);
block *gen_bcmp(cstate *cs, int offrel, u32 offset, u32 size, const unsigned char *v);
block *gen_true(cstate *cs);
block *gen_false(cstate *cs);
block *gen_linktype(cstate *cs, u32 ll_proto);
block *gen_llc_linktype(cstate *cs, u32 ll_proto);
block *gen_snap(cstate *cs, u32 orgcode, u32 ptype);
void   init_linktype(cstate *cs);
const char *dlt_description(int dlt);
block *gen_host(cstate *cs, u32 addr, u32 mask, int proto, int dir, int type);
block *gen_host6(cstate *cs, const unsigned char *addr, const unsigned char *mask,
                 int proto, int dir, int type);
block *gen_proto(cstate *cs, u32 v, int proto, int dir);
block *gen_protochain(cstate *cs, u32 v, int proto);
block *gen_ipfrag(cstate *cs);
block *gen_ehostop(cstate *cs, const unsigned char *eaddr, int dir);
void   backpatch(block *list, block *target);
int    alloc_reg(cstate *cs);
void   free_reg(cstate *cs, int n);
int    tbl_parse_ip6(const char *s, unsigned char *out);
sstmt *base_into_x(cstate *cs, varoff *off);
sstmt *iphl_into_x(cstate *cs);
block *p4(cstate *cs, u32 port, int ip_proto, int dir);
block *p6(cstate *cs, u32 port, int ip_proto, int dir);

#endif
