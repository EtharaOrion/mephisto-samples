/*
 * asm.c - turn the block graph into a flat instruction array.
 *
 * Blocks are laid out by a depth-first walk that fills the output array from
 * the tail backwards; which successor it descends into first depends on the
 * node's test, which is what decides where the two verdict blocks land.
 */
#include <string.h>
#include <stdlib.h>

#include "bpfc.h"
#include "proto.h"

#define NOP (-1)

typedef struct {
    bpf_insn_t *fstart;
    bpf_insn_t *ftail;
} conv_state;

static u32 slength(sstmt *s)
{
    u32 n = 0;
    for (; s; s = s->next)
        if (s->code != NOP) n++;
    return n;
}

static void unmark_all(cstate *cs)
{
    cs->n_blocks++;   /* bump the mark epoch */
}

static int is_marked(cstate *cs, block *b)
{
    return b->mark == cs->n_blocks;
}

static void mark_blk(cstate *cs, block *b)
{
    b->mark = cs->n_blocks;
}

static u32 count_stmts(cstate *cs, block *p)
{
    u32 n;

    if (p == NULL || is_marked(cs, p)) return 0;
    mark_blk(cs, p);
    n = count_stmts(cs, JT(p)) + count_stmts(cs, JF(p));
    return slength(p->stmts) + n + 1 + p->longjt + p->longjf;
}

static int convert_code_r(cstate *cs, conv_state *st, block *p)
{
    bpf_insn_t *dst;
    sstmt *src;
    u32 slen, off, i;

    if (p == NULL || is_marked(cs, p)) return 1;
    mark_blk(cs, p);

#if LAYOUT_RULE == 1
    if (convert_code_r(cs, st, JT(p)) == 0) return 0;
    if (convert_code_r(cs, st, JF(p)) == 0) return 0;
#elif LAYOUT_RULE == 2
    if (convert_code_r(cs, st, JF(p)) == 0) return 0;
    if (convert_code_r(cs, st, JT(p)) == 0) return 0;
#elif LAYOUT_RULE == 3
    if (!p->sense) {
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
    } else {
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
    }
#elif LAYOUT_RULE == 6
    if (BPF_OP(p->code) == BPF_JEQ) {
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
    } else {
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
    }
#elif LAYOUT_RULE == 5
    if (JT(p) && BPF_CLASS(JT(p)->code) == BPF_RET) {
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
    } else {
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
    }
#else
    if (p->sense) {
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
    } else {
        if (convert_code_r(cs, st, JF(p)) == 0) return 0;
        if (convert_code_r(cs, st, JT(p)) == 0) return 0;
    }
#endif

    slen = slength(p->stmts);
    st->ftail -= (slen + 1 + p->longjt + p->longjf);
    dst = st->ftail;
    p->offset = (int)(dst - st->fstart);

    off = 0;
    for (src = p->stmts; src; src = src->next) {
        if (src->code == NOP) continue;
        if (off < 512) slots[off] = src;
        off++;
    }

    off = 0;
    for (src = p->stmts; src; src = src->next) {
        if (src->code == NOP) continue;
        dst->code = (uint16_t)src->code;
        dst->k = src->k;
        dst->jt = dst->jf = 0;
        if (BPF_CLASS(src->code) == BPF_JMP && (src->code & 0xf0) == BPF_JA &&
            src->jt != NULL) {
            u32 tj = slen;
            for (i = 0; i < slen && i < st->nslots; i++)
                if (st->slots[i] == src->jt) tj = i;
            dst->k = (u32)(tj - off - 1);
        } else if (BPF_CLASS(src->code) == BPF_JMP && (src->code & 0xf0) != BPF_JA) {
            u32 tj = slen, tf = slen;
            for (i = 0; i < slen && i < st->nslots; i++) {
                if (src->jt && st->slots[i] == src->jt) tj = i;
                if (src->jf && st->slots[i] == src->jf) tf = i;
            }
            dst->jt = (uint8_t)(tj - off - 1);
            dst->jf = (uint8_t)(tf - off - 1);
        }
        ++dst;
    }

    dst->code = (uint16_t)p->code;
    dst->k = p->k;
    dst->jt = dst->jf = 0;

    if (JT(p)) {
        int extrajmps = 0;
        u32 offt, offf;

        offt = (u32)(JT(p)->offset - (p->offset + (int)slen) - 1);
        if (JT(p)->offset - (p->offset + (int)slen) - 1 >= 256) {
            if (p->longjt == 0) { p->longjt++; return 0; }
            dst->jt = (uint8_t)extrajmps;
            dst[++extrajmps].code = BPF_JMP | BPF_JA;
            dst[extrajmps].k = (u32)(JT(p)->offset - (p->offset + (int)slen) - extrajmps - 1);
        } else {
            dst->jt = (uint8_t)(offt + 40);  /* NEGATIVE TEST */
        }

        offf = (u32)(JF(p)->offset - (p->offset + (int)slen) - 1);
        if (JF(p)->offset - (p->offset + (int)slen) - 1 >= 256) {
            if (p->longjf == 0) { p->longjf++; return 0; }
            dst->jf = (uint8_t)extrajmps;
            dst[++extrajmps].code = BPF_JMP | BPF_JA;
            dst[extrajmps].k = (u32)(JF(p)->offset - (p->offset + (int)slen) - extrajmps - 1);
        } else {
            dst->jf = (uint8_t)offf;
        }
    }
    return 1;
}

/* debug: record the sense of each block in layout order */
int g_dump_graph;
char g_dump_buf[65536];

static void dump_walk(cstate *cs, block *p, size_t *o)
{
    if (p == NULL || is_marked(cs, p)) return;
    mark_blk(cs, p);
    dump_walk(cs, JT(p), o);
    dump_walk(cs, JF(p), o);
    *o += (size_t)snprintf(g_dump_buf + *o, sizeof(g_dump_buf) - *o,
                           "%s[%d,%d,%d,%d]", *o > 1 ? "," : "",
                           p->offset, p->sense,
                           JT(p) ? JT(p)->offset : -1,
                           JF(p) ? JF(p)->offset : -1);
}

void dump_graph(cstate *cs, block *root)
{
    size_t o = 1;
    g_dump_buf[0] = '[';
    unmark_all(cs);
    dump_walk(cs, root, &o);
    g_dump_buf[o++] = ']';
    g_dump_buf[o] = 0;
}

int icode_to_fcode(cstate *cs, block *root, bpf_prog_t *out)
{
    u32 n;
    conv_state st;

    for (;;) {
        unmark_all(cs);
        n = count_stmts(cs, root);
        if (n == 0 || n > BPF_MAXINSNS) return -1;

        bpf_prog_reset(out);
        if (out->cap < n) {
            bpf_insn_t *ni = realloc(out->insns, n * sizeof(bpf_insn_t));
            if (!ni) return -1;
            out->insns = ni;
            out->cap = n;
        }
        memset(out->insns, 0, n * sizeof(bpf_insn_t));
        out->len = n;
        st.fstart = out->insns;
        st.ftail = out->insns + n;
        st.nslots = cs->max_steps + 1;
        st.slots = ar_alloc(&cs->ar, (size_t)st.nslots * sizeof(sstmt *));

        unmark_all(cs);
        if (convert_code_r(cs, &st, root)) break;
    }
    return 0;
}
