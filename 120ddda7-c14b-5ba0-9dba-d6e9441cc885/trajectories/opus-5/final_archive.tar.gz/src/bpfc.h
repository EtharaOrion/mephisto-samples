/*
 * bpfc.h - shared declarations for the filter compiler.
 *
 * The compiler is organised as: scanner (lex.c) -> parser (gram.c) ->
 * block-graph generation (gen.c) -> optimiser + assembler (opt.c).
 */
#ifndef BPFC_H
#define BPFC_H

#include <setjmp.h>
#include <stdint.h>
#include <stddef.h>

#include "bpf_defs.h"
#include "jsonio.h"

typedef uint32_t u32;

/* ------------------------------------------------------------------ */
/* arena                                                              */
/* ------------------------------------------------------------------ */
typedef struct achunk {
    struct achunk *next;
    size_t used, size;
    char  *base;
} achunk;

typedef struct {
    achunk *head;
    achunk *cur;
} arena_t;

void *ar_alloc_slow(arena_t *a, size_t n);

static inline void *ar_alloc(arena_t *a, size_t n)
{
    achunk *c = a->cur;

    n = (n + 15u) & ~(size_t)15u;
    if (c != NULL && c->used + n <= c->size) {
        void *p = c->base + c->used;
        c->used += n;
        return p;
    }
    return ar_alloc_slow(a, n);
}
void  ar_reset(arena_t *a);
void  ar_free(arena_t *a);

/* ------------------------------------------------------------------ */
/* qualifiers                                                         */
/* ------------------------------------------------------------------ */
enum {
    P_DEFAULT = 0, P_UNDEF, P_LINK, P_IP, P_ARP, P_RARP, P_SCTP, P_TCP, P_UDP,
    P_ICMP, P_IGMP, P_IGRP, P_ATALK, P_DECNET, P_LAT, P_SCA, P_MOPRC, P_MOPDL,
    P_IPV6, P_ICMPV6, P_AH, P_ESP, P_PIM, P_VRRP, P_AARP, P_ISO, P_ESIS,
    P_ISIS, P_L1, P_L2, P_IIH, P_SNP, P_CSNP, P_PSNP, P_CLNP, P_STP, P_IPX,
    P_NETBEUI, P_RADIO, P_CARP
};

enum { D_DEFAULT = 0, D_SRC, D_DST, D_OR, D_AND, D_ADDR1, D_ADDR2, D_ADDR3,
       D_ADDR4, D_RA, D_TA, D_UNDEF };

enum { A_DEFAULT = 0, A_HOST, A_NET, A_PORT, A_GATEWAY, A_PROTO, A_PROTOCHAIN,
       A_PORTRANGE, A_UNDEF };

typedef struct { int proto, dir, addr; } qual;

/* ------------------------------------------------------------------ */
/* icode: statements, blocks, edges                                   */
/* ------------------------------------------------------------------ */
typedef struct sstmt {
    int            code;
    u32            k;
    u32            vc;          /* value number, valid while vc_ok holds */
    int            vc_ok;
    struct sstmt  *jt, *jf;    /* jumps inside a statement list */
    struct sstmt  *next;
} sstmt;

typedef struct block block;

typedef struct edge {
    u32           id;
    int           code;
    uint64_t     *edom;
    block        *succ;
    block        *pred;
    struct edge  *next;        /* chain of in-edges of succ */
} edge;

struct block {
    int      id;
    sstmt   *stmts;
    int      code;             /* exit test opcode */
    u32      k;
    int      mark;
    u32      longjt, longjf;
    int      level;
    int      offset;
    int      sense;
    edge     et, ef;
    block   *head;
    block   *link;             /* level chain / free chain */
    uint64_t *dom;
    u32     *closure;
    edge    *in_edges;
    int      out_use;
    int      in_use;
    int      kill;
    int      steps_dirty;      /* statements changed since find_ud looked */
    int      wn_dirty;         /* statements changed since work_node ran */
    int      val_valid;        /* val[] holds the result of the last run */
    u32      last_in_a, last_in_x;
    block   *last_jt, *last_jf;
    int      last_out_use;
    int      last_alter;
    int      base_use;
    u32      kval, kval_k;
    int      kval_ok;
    u32      nsteps_cache;
    u32      oval;
    int      op;
    /* scratch for interning */
    block   *inext;
    /* value numbers per atom; always filled in before they are read, so the
     * constructor does not have to clear them */
    u32      val[BPF_MEMWORDS + 2];
};

#define JT(b) ((b)->et.succ)
#define JF(b) ((b)->ef.succ)

#define A_ATOM (BPF_MEMWORDS)
#define X_ATOM (BPF_MEMWORDS + 1)
#define N_ATOMS (BPF_MEMWORDS + 2)

/* ------------------------------------------------------------------ */
/* absolute-offset descriptors                                        */
/* ------------------------------------------------------------------ */
#define OFF_UNSET 0xffffffffu

typedef struct {
    u32 constant_part;
    int reg;
    int is_variable;
} absoff;

enum offrel {
    OR_PACKET, OR_LINKHDR, OR_PREVLINKHDR, OR_LLC, OR_PREVMPLSHDR,
    OR_LINKTYPE, OR_LINKPL, OR_LINKPL_NOSNAP, OR_TRAN_IPV4, OR_TRAN_IPV6
};

/* ------------------------------------------------------------------ */
/* compiler state                                                     */
/* ------------------------------------------------------------------ */
#define ERRBUF_SIZE 256

typedef struct arth {
    block  *b;
    sstmt  *s;
    int     regno;
} arth;

typedef struct cstate {
    arena_t  ar;
    jmp_buf  jmp;
    char     err[ERRBUF_SIZE];
    int      failed;

    int      linktype;
    int      outermostlinktype;
    int      prevlinktype;
    int      snaplen;
    u32      netmask;
    int      netmask_known;
    int      no_shrink;
    u32      max_steps;
    u32      n_steps_made, n_nodes_made;

    absoff   off_linkhdr, off_prevlinkhdr, off_linktype, off_linkpl;
    u32      off_nl, off_nl_nosnap;

    int      is_geneve;
    int      label_stack_depth;
    int      vlan_stack_depth;

    int      regused[BPF_MEMWORDS];
    int      curreg;

    /* scanner */
    const char *lex_p;
    int      tok;
    u32      tok_num;
    const char *tok_str;      /* arena copy */
    size_t   tok_len;
    const char *save_p;

    block   *root;
    int      n_blocks;
    block  **blocks;
    int      n_edges;
    edge   **edges;

    /* optimizer scratch */
    int      done;
    int      nodewords, edgewords;
    u32     *space;
    block  **levels;
    u32     *vmap_ok;
    struct vnode *vnode_base;
    struct vnode **hashtbl;
    u32      curval;
    u32      maxval;
    struct vmapent *vmap;
    int      non_branch_movement;
} cstate;

/* jump helpers */
#define JMPOP(x) (BPF_JMP | (x) | BPF_K)

/* ------------------------------------------------------------------ */
/* api                                                                */
/* ------------------------------------------------------------------ */
void bpf_err(cstate *cs, const char *fmt, ...);

/* lex.c */
void lex_init(cstate *cs, const char *text);
void lex_next(cstate *cs);
char *ar_strdup(cstate *cs, const char *s, size_t n);

/* name tables */
int tbl_lookup_proto(const char *name, int *val);
int tbl_lookup_port(const char *name, int *port, int *proto);   /* proto: 0 any,6 tcp,17 udp,132 sctp */
int tbl_lookup_net(const char *name, u32 *val);
int tbl_lookup_host(const char *name, u32 *addrs, int max, int *n);
int tbl_lookup_host6(const char *name, unsigned char *out);
int tbl_lookup_ether(const char *name, unsigned char *out);
int tbl_lookup_llcsap(const char *name, int *val);
int tbl_lookup_ethertype(const char *name, int *val);

/* gram.c */
block *parse_filter(cstate *cs, const char *text);

/* gen.c */
void gen_init(cstate *cs);
void finish_parse(cstate *cs, block *p);
block *gen_retblk(cstate *cs, int v);

/* opt.c */
int  bpf_optimize(cstate *cs);
int  icode_to_fcode(cstate *cs, block *root, bpf_prog_t *out);

/* driver */
int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err);

#endif /* BPFC_H */
