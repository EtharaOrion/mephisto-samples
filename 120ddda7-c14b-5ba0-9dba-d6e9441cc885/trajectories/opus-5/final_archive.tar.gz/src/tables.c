/*
 * tables.c - name lookups.  The tables are the pinned ones, compiled in so
 * the process reads no files at all.
 */
#include <string.h>
#include <stdlib.h>

#include "bpfc.h"
#include "tables_data.h"

#define PROTO_UNDEF (-1)
#define IPPROTO_TCP 6
#define IPPROTO_UDP 17

/* extra names from the standard container hosts file */
typedef struct { const char *name; const char *addr; } h6extra;
static const h6extra host6_extra[] = {
    { "ip6-localnet",    "fe00::0" },
    { "ip6-mcastprefix", "ff00::0" },
    { "ip6-allnodes",    "ff02::1" },
    { "ip6-allrouters",  "ff02::2" },
    { NULL, NULL }
};

int tbl_lookup_proto(const char *name, int *val)
{
    const num_ent *e;
    for (e = proto_tab; e->name; e++)
        if (strcmp(e->name, name) == 0) { *val = e->num; return 1; }
    return 0;
}

int tbl_lookup_port(const char *name, int *port, int *proto)
{
    const serv_ent *e;
    char *end;
    long v;

    /* a numeric string is accepted as a port number */
    v = strtol(name, &end, 10);
    if (*name != '\0' && *end == '\0' && v >= 0 && v <= 65535) {
        *port = (int)v;
        *proto = PROTO_UNDEF;
        return 1;
    }
    for (e = serv_tab; e->name; e++) {
        if (strcmp(e->name, name) != 0) continue;
        if (e->tcp >= 0) {
            *port = e->tcp;
            *proto = IPPROTO_TCP;
            if (e->udp >= 0) {
                if (e->udp == e->tcp) *proto = PROTO_UNDEF;
                else return 0;
            }
            return 1;
        }
        if (e->udp >= 0) { *port = e->udp; *proto = IPPROTO_UDP; return 1; }
        return 0;
    }
    return 0;
}

int tbl_lookup_net(const char *name, u32 *val)
{
    const net_ent *e;
    for (e = net_tab; e->name; e++)
        if (strcmp(e->name, name) == 0) { *val = e->val; return 1; }
    return 0;
}

int tbl_lookup_host(const char *name, u32 *addrs, int max, int *n)
{
    const host_ent *e;
    int c = 0;
    for (e = host_tab; e->name; e++)
        if (strcmp(e->name, name) == 0 && c < max) addrs[c++] = e->addr;
    *n = c;
    return c > 0;
}

/* parse an IPv6 literal into 16 bytes */
int tbl_parse_ip6(const char *s, unsigned char *out)
{
    unsigned char buf[16];
    int i, ngroups = 0, dcpos = -1;
    unsigned int groups[8];
    const char *p = s;

    memset(buf, 0, sizeof(buf));
    if (p[0] == ':' && p[1] == ':') { dcpos = 0; p += 2; }
    while (*p) {
        unsigned int v = 0;
        int nd = 0;
        if (*p == ':') {
            if (dcpos >= 0) return 0;
            dcpos = ngroups;
            p++;
            if (*p == '\0') break;
            continue;
        }
        while (*p) {
            int d;
            if (*p >= '0' && *p <= '9') d = *p - '0';
            else if (*p >= 'a' && *p <= 'f') d = *p - 'a' + 10;
            else if (*p >= 'A' && *p <= 'F') d = *p - 'A' + 10;
            else break;
            v = v * 16 + (unsigned)d;
            nd++;
            p++;
        }
        if (nd == 0 || nd > 4) return 0;
        if (*p == '.') {
            /* embedded IPv4 */
            unsigned int q[4];
            int k;
            const char *r = p;
            while (r > s && *(r-1) != ':') r--;
            for (k = 0; k < 4; k++) {
                unsigned int a = 0;
                int m = 0;
                while (*r >= '0' && *r <= '9') { a = a * 10 + (unsigned)(*r - '0'); r++; m++; }
                if (m == 0 || a > 255) return 0;
                q[k] = a;
                if (k < 3) { if (*r != '.') return 0; r++; }
            }
            if (ngroups > 6) return 0;
            groups[ngroups++] = (q[0] << 8) | q[1];
            groups[ngroups++] = (q[2] << 8) | q[3];
            p = r;
            break;
        }
        if (ngroups >= 8) return 0;
        groups[ngroups++] = v;
        if (*p == ':') { p++; if (*p == '\0') return 0; }
        else break;
    }
    if (*p != '\0') return 0;
    if (dcpos < 0) {
        if (ngroups != 8) return 0;
        for (i = 0; i < 8; i++) { buf[i*2] = (unsigned char)(groups[i] >> 8); buf[i*2+1] = (unsigned char)groups[i]; }
    } else {
        int tail = ngroups - dcpos;
        if (ngroups > 8) return 0;
        for (i = 0; i < dcpos; i++) { buf[i*2] = (unsigned char)(groups[i] >> 8); buf[i*2+1] = (unsigned char)groups[i]; }
        for (i = 0; i < tail; i++) {
            int d = 8 - tail + i;
            buf[d*2] = (unsigned char)(groups[dcpos+i] >> 8);
            buf[d*2+1] = (unsigned char)groups[dcpos+i];
        }
    }
    memcpy(out, buf, 16);
    return 1;
}

int tbl_lookup_host6(const char *name, unsigned char *out)
{
    const host6_ent *e;
    const h6extra *x;

    for (e = host6_tab; e->name; e++)
        if (strcmp(e->name, name) == 0) return tbl_parse_ip6(e->addr, out);
    for (x = host6_extra; x->name; x++)
        if (strcmp(x->name, name) == 0) return tbl_parse_ip6(x->addr, out);
    return 0;
}

int tbl_lookup_ether(const char *name, unsigned char *out)
{
    (void)name; (void)out;
    return 0;   /* the pinned ethers table is empty */
}

typedef struct { const char *name; int val; } sname;

static const sname eproto_db[] = {
    { "aarp", 0x80f3 },
    { "arp", 0x0806 },
    { "atalk", 0x809b },
    { "decnet", 0x6003 },
    { "ip", 0x0800 },
    { "ip6", 0x86dd },
    { "lat", 0x6004 },
    { "loopback", 0x9000 },
    { "mopdl", 0x6001 },
    { "moprc", 0x6002 },
    { "rarp", 0x8035 },
    { "sca", 0x6007 },
    { NULL, 0 }
};

static const sname llc_db[] = {
    { "iso", 0xfe },
    { "stp", 0x42 },
    { "ipx", 0xe0 },
    { "netbeui", 0xf0 },
    { NULL, 0 }
};

int tbl_lookup_ethertype(const char *name, int *val)
{
    const sname *e;
    for (e = eproto_db; e->name; e++)
        if (strcmp(e->name, name) == 0) { *val = e->val; return 1; }
    return 0;
}

int tbl_lookup_llcsap(const char *name, int *val)
{
    const sname *e;
    for (e = llc_db; e->name; e++)
        if (strcmp(e->name, name) == 0) { *val = e->val; return 1; }
    return 0;
}
