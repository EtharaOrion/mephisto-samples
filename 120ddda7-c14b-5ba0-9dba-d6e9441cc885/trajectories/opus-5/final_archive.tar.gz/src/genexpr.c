/*
 * genexpr.c - address, port and protocol primitives.
 */
#include <string.h>

#include "bpfc.h"
#include "gen.h"
#include "proto.h"

#define PROTO_UNDEF (-1)

block *gen_ipfrag(cstate *cs)
{
    sstmt *s;
    block *b;

    s = gen_load_a(cs, OR_LINKPL, 6, BPF_H);
    b = new_block(cs, JMPOP(BPF_JSET));
    b->k = 0x1fff;
    b->stmts = s;
    gen_not(b);
    return b;
}

/* ------------------------------------------------------------------ */
/* proto                                                              */
/* ------------------------------------------------------------------ */
block *gen_proto(cstate *cs, u32 v, int proto, int dir)
{
    block *b0, *b1, *b2, *tmp;

    if (dir != D_DEFAULT)
        bpf_err(cs, "direction applied to 'proto'");

    switch (proto) {
    case P_DEFAULT:
        b0 = gen_proto(cs, v, P_IP, dir);
        b1 = gen_proto(cs, v, P_IPV6, dir);
        gen_or(b0, b1);
        return b1;

    case P_LINK:
        return gen_linktype(cs, v);

    case P_IP:
        b0 = gen_linktype(cs, ETHERTYPE_IP);
        b1 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, v);
        gen_and(b0, b1);
        return b1;

    case P_ARP:
        bpf_err(cs, "arp does not encapsulate another protocol");
        return NULL;

    case P_RARP:
        bpf_err(cs, "rarp does not encapsulate another protocol");
        return NULL;

    case P_IPV6:
        b0 = gen_linktype(cs, ETHERTYPE_IPV6);
        b2 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, IPPROTO_FRAGMENT);
        b1 = gen_cmp(cs, OR_LINKPL, 40, BPF_B, v);
        gen_and(b2, b1);
        tmp = gen_cmp(cs, OR_LINKPL, 6, BPF_B, v);
        gen_or(tmp, b1);
        gen_and(b0, b1);
        return b1;

    case P_ISO:
        b0 = gen_linktype(cs, LLCSAP_ISONS);
        b1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, v);
        gen_and(b0, b1);
        return b1;

    case P_ATALK: case P_AARP: case P_DECNET: case P_LAT: case P_SCA:
    case P_MOPRC: case P_MOPDL:
        bpf_err(cs, "%s encapsulation is not specified", proto_name(proto));
        return NULL;

    default:
        bpf_err(cs, "'%s proto' is bogus", proto_name(proto));
        return NULL;
    }
}

block *gen_proto_abbrev(cstate *cs, int proto)
{
    block *b0, *b1;

    switch (proto) {
    case P_SCTP:
        b0 = gen_proto(cs, IPPROTO_SCTP, P_IP, D_DEFAULT);
        b1 = gen_proto(cs, IPPROTO_SCTP, P_IPV6, D_DEFAULT);
        gen_or(b0, b1);
        return b1;
    case P_TCP:
        b0 = gen_proto(cs, IPPROTO_TCP, P_IP, D_DEFAULT);
        b1 = gen_proto(cs, IPPROTO_TCP, P_IPV6, D_DEFAULT);
        gen_or(b0, b1);
        return b1;
    case P_UDP:
        b0 = gen_proto(cs, IPPROTO_UDP, P_IP, D_DEFAULT);
        b1 = gen_proto(cs, IPPROTO_UDP, P_IPV6, D_DEFAULT);
        gen_or(b0, b1);
        return b1;
    case P_ICMP:
        return gen_proto(cs, IPPROTO_ICMP, P_IP, D_DEFAULT);
    case P_IGMP:
        return gen_proto(cs, IPPROTO_IGMP, P_IP, D_DEFAULT);
    case P_IGRP:
        return gen_proto(cs, IPPROTO_IGRP, P_IP, D_DEFAULT);
    case P_PIM:
        b0 = gen_proto(cs, IPPROTO_PIM, P_IP, D_DEFAULT);
        b1 = gen_proto(cs, IPPROTO_PIM, P_IPV6, D_DEFAULT);
        gen_or(b0, b1);
        return b1;
    case P_VRRP:
        return gen_proto(cs, IPPROTO_VRRP, P_IP, D_DEFAULT);
    case P_CARP:
        return gen_proto(cs, IPPROTO_CARP, P_IP, D_DEFAULT);
    case P_IP:
        return gen_linktype(cs, ETHERTYPE_IP);
    case P_ARP:
        return gen_linktype(cs, ETHERTYPE_ARP);
    case P_RARP:
        return gen_linktype(cs, ETHERTYPE_REVARP);
    case P_LINK:
        bpf_err(cs, "link layer applied in wrong context");
        return NULL;
    case P_ATALK:
        return gen_linktype(cs, ETHERTYPE_ATALK);
    case P_AARP:
        return gen_linktype(cs, ETHERTYPE_AARP);
    case P_DECNET:
        return gen_linktype(cs, ETHERTYPE_DN);
    case P_SCA:
        return gen_linktype(cs, ETHERTYPE_SCA);
    case P_LAT:
        return gen_linktype(cs, ETHERTYPE_LAT);
    case P_MOPDL:
        return gen_linktype(cs, ETHERTYPE_MOPDL);
    case P_MOPRC:
        return gen_linktype(cs, ETHERTYPE_MOPRC);
    case P_IPV6:
        return gen_linktype(cs, ETHERTYPE_IPV6);
    case P_ICMPV6:
        return gen_proto(cs, IPPROTO_ICMPV6, P_IPV6, D_DEFAULT);
    case P_AH:
        b0 = gen_proto(cs, IPPROTO_AH, P_IP, D_DEFAULT);
        b1 = gen_proto(cs, IPPROTO_AH, P_IPV6, D_DEFAULT);
        gen_or(b0, b1);
        return b1;
    case P_ESP:
        b0 = gen_proto(cs, IPPROTO_ESP, P_IP, D_DEFAULT);
        b1 = gen_proto(cs, IPPROTO_ESP, P_IPV6, D_DEFAULT);
        gen_or(b0, b1);
        return b1;
    case P_ISO:
        return gen_linktype(cs, LLCSAP_ISONS);
    case P_STP:
        return gen_linktype(cs, LLCSAP_8021D);
    case P_IPX:
        return gen_linktype(cs, LLCSAP_IPX);
    case P_NETBEUI:
        return gen_linktype(cs, LLCSAP_NETBEUI);
    case P_ESIS:
        return gen_proto(cs, 0x82, P_ISO, D_DEFAULT);
    case P_ISIS:
        return gen_proto(cs, 0x83, P_ISO, D_DEFAULT);
    case P_CLNP:
        return gen_proto(cs, 0x81, P_ISO, D_DEFAULT);
    case P_RADIO:
        bpf_err(cs, "'radio' is not a valid protocol");
        return NULL;
    default:
        bpf_err(cs, "unsupported protocol abbreviation");
        return NULL;
    }
}

/* ------------------------------------------------------------------ */
/* hosts                                                              */
/* ------------------------------------------------------------------ */
static block *gen_hostop(cstate *cs, u32 addr, u32 mask, int dir, u32 proto,
                         u32 src_off, u32 dst_off)
{
    block *b0, *b1;
    u32 offset;

    switch (dir) {
    case D_SRC: offset = src_off; break;
    case D_DST: offset = dst_off; break;
    case D_AND:
        b0 = gen_hostop(cs, addr, mask, D_SRC, proto, src_off, dst_off);
        b1 = gen_hostop(cs, addr, mask, D_DST, proto, src_off, dst_off);
        gen_and(b0, b1);
        return b1;
    case D_DEFAULT:
    case D_OR:
        b0 = gen_hostop(cs, addr, mask, D_SRC, proto, src_off, dst_off);
        b1 = gen_hostop(cs, addr, mask, D_DST, proto, src_off, dst_off);
        gen_or(b0, b1);
        return b1;
    default:
        bpf_err(cs, "direction not supported on linktype");
        return NULL;
    }
    b0 = gen_linktype(cs, proto);
    b1 = gen_mcmp(cs, OR_LINKPL, offset, BPF_W, addr, mask);
    gen_and(b0, b1);
    return b1;
}

static block *gen_hostop6(cstate *cs, const unsigned char *addr,
                          const unsigned char *mask, int dir, u32 proto,
                          u32 src_off, u32 dst_off)
{
    block *b0, *b1, *tmp;
    u32 offset;
    u32 a[4], m[4];
    int i;

    switch (dir) {
    case D_SRC: offset = src_off; break;
    case D_DST: offset = dst_off; break;
    case D_AND:
        b0 = gen_hostop6(cs, addr, mask, D_SRC, proto, src_off, dst_off);
        b1 = gen_hostop6(cs, addr, mask, D_DST, proto, src_off, dst_off);
        gen_and(b0, b1);
        return b1;
    case D_DEFAULT:
    case D_OR:
        b0 = gen_hostop6(cs, addr, mask, D_SRC, proto, src_off, dst_off);
        b1 = gen_hostop6(cs, addr, mask, D_DST, proto, src_off, dst_off);
        gen_or(b0, b1);
        return b1;
    default:
        bpf_err(cs, "direction not supported on linktype");
        return NULL;
    }
    for (i = 0; i < 4; i++) {
        a[i] = ((u32)addr[i*4] << 24) | ((u32)addr[i*4+1] << 16) |
               ((u32)addr[i*4+2] << 8) | addr[i*4+3];
        m[i] = ((u32)mask[i*4] << 24) | ((u32)mask[i*4+1] << 16) |
               ((u32)mask[i*4+2] << 8) | mask[i*4+3];
    }
    b0 = gen_linktype(cs, proto);
    b1 = gen_mcmp(cs, OR_LINKPL, offset + 12, BPF_W, a[3], m[3]);
    for (i = 2; i >= 0; i--) {
        tmp = gen_mcmp(cs, OR_LINKPL, offset + (u32)i * 4, BPF_W, a[i], m[i]);
        gen_and(tmp, b1);
    }
    gen_and(b0, b1);
    return b1;
}

block *gen_ehostop(cstate *cs, const unsigned char *eaddr, int dir);

block *gen_host(cstate *cs, u32 addr, u32 mask, int proto, int dir, int type)
{
    block *b0, *b1;
    const char *typestr = (type == A_NET) ? "net" : "host";

    switch (proto) {
    case P_DEFAULT:
        b0 = gen_host(cs, addr, mask, P_IP, dir, type);
        if (cs->label_stack_depth == 0) {
            b1 = gen_host(cs, addr, mask, P_ARP, dir, type);
            gen_or(b0, b1);
            b0 = gen_host(cs, addr, mask, P_RARP, dir, type);
            gen_or(b1, b0);
            return b0;
        }
        return b0;

    case P_LINK:
        bpf_err(cs, "link-layer modifier applied to %s", typestr);
        return NULL;

    case P_IP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_IP, 12, 16);

    case P_RARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_REVARP, 14, 24);

    case P_ARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_ARP, 14, 24);

    default:
        bpf_err(cs, "'%s' modifier applied to %s", proto_name(proto), typestr);
        return NULL;
    }
}

block *gen_host6(cstate *cs, const unsigned char *addr, const unsigned char *mask,
                 int proto, int dir, int type)
{
    const char *typestr = (type == A_NET) ? "net" : "host";

    switch (proto) {
    case P_DEFAULT:
        return gen_host6(cs, addr, mask, P_IPV6, dir, type);
    case P_LINK:
        bpf_err(cs, "link-layer modifier applied to ip6 %s", typestr);
        return NULL;
    case P_IPV6:
        return gen_hostop6(cs, addr, mask, dir, ETHERTYPE_IPV6, 8, 24);
    default:
        bpf_err(cs, "'%s' modifier applied to ip6 %s", "proto", typestr);
        return NULL;
    }
}

/* ------------------------------------------------------------------ */
/* ports                                                              */
/* ------------------------------------------------------------------ */
static block *gen_portop(cstate *cs, u32 port, u32 proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    tmp = gen_ipfrag(cs);
    gen_and(b0, tmp);
    b0 = tmp;

    switch (dir) {
    case D_SRC:
        b1 = gen_cmp(cs, OR_TRAN_IPV4, 0, BPF_H, port);
        break;
    case D_DST:
        b1 = gen_cmp(cs, OR_TRAN_IPV4, 2, BPF_H, port);
        break;
    case D_OR:
    case D_DEFAULT:
        tmp = gen_cmp(cs, OR_TRAN_IPV4, 0, BPF_H, port);
        b1 = gen_cmp(cs, OR_TRAN_IPV4, 2, BPF_H, port);
        gen_or(tmp, b1);
        break;
    case D_AND:
        tmp = gen_cmp(cs, OR_TRAN_IPV4, 0, BPF_H, port);
        b1 = gen_cmp(cs, OR_TRAN_IPV4, 2, BPF_H, port);
        gen_and(tmp, b1);
        break;
    default:
        bpf_err(cs, "direction not supported on port");
        return NULL;
    }
    gen_and(b0, b1);
    return b1;
}

static block *gen_port(cstate *cs, u32 port, int ip_proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portop(cs, port, (u32)ip_proto, dir);
        break;
    default:
        tmp = gen_portop(cs, port, IPPROTO_TCP, dir);
        b1 = gen_portop(cs, port, IPPROTO_UDP, dir);
        gen_or(tmp, b1);
        tmp = gen_portop(cs, port, IPPROTO_SCTP, dir);
        gen_or(tmp, b1);
        break;
    }
    gen_and(b0, b1);
    return b1;
}

static block *gen_portop6(cstate *cs, u32 port, u32 proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case D_SRC:
        b1 = gen_cmp(cs, OR_TRAN_IPV6, 0, BPF_H, port);
        break;
    case D_DST:
        b1 = gen_cmp(cs, OR_TRAN_IPV6, 2, BPF_H, port);
        break;
    case D_OR:
    case D_DEFAULT:
        tmp = gen_cmp(cs, OR_TRAN_IPV6, 0, BPF_H, port);
        b1 = gen_cmp(cs, OR_TRAN_IPV6, 2, BPF_H, port);
        gen_or(tmp, b1);
        break;
    case D_AND:
        tmp = gen_cmp(cs, OR_TRAN_IPV6, 0, BPF_H, port);
        b1 = gen_cmp(cs, OR_TRAN_IPV6, 2, BPF_H, port);
        gen_and(tmp, b1);
        break;
    default:
        bpf_err(cs, "direction not supported on port");
        return NULL;
    }
    gen_and(b0, b1);
    return b1;
}

static block *gen_port6(cstate *cs, u32 port, int ip_proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portop6(cs, port, (u32)ip_proto, dir);
        break;
    default:
        tmp = gen_portop6(cs, port, IPPROTO_TCP, dir);
        b1 = gen_portop6(cs, port, IPPROTO_UDP, dir);
        gen_or(tmp, b1);
        tmp = gen_portop6(cs, port, IPPROTO_SCTP, dir);
        gen_or(tmp, b1);
        break;
    }
    gen_and(b0, b1);
    return b1;
}

static block *gen_portrangeop(cstate *cs, u32 p1, u32 p2, u32 proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    tmp = gen_ipfrag(cs);
    gen_and(b0, tmp);
    b0 = tmp;

    switch (dir) {
    case D_SRC:
        b1 = gen_cmp_ge(cs, OR_TRAN_IPV4, 0, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV4, 0, BPF_H, p2);
        gen_and(b1, tmp);
        b1 = tmp;
        break;
    case D_DST:
        b1 = gen_cmp_ge(cs, OR_TRAN_IPV4, 2, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV4, 2, BPF_H, p2);
        gen_and(b1, tmp);
        b1 = tmp;
        break;
    case D_OR:
    case D_DEFAULT: {
        block *s, *d;
        s = gen_cmp_ge(cs, OR_TRAN_IPV4, 0, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV4, 0, BPF_H, p2);
        gen_and(s, tmp);
        s = tmp;
        d = gen_cmp_ge(cs, OR_TRAN_IPV4, 2, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV4, 2, BPF_H, p2);
        gen_and(d, tmp);
        d = tmp;
        gen_or(s, d);
        b1 = d;
        break;
    }
    case D_AND: {
        block *s, *d;
        s = gen_cmp_ge(cs, OR_TRAN_IPV4, 0, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV4, 0, BPF_H, p2);
        gen_and(s, tmp);
        s = tmp;
        d = gen_cmp_ge(cs, OR_TRAN_IPV4, 2, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV4, 2, BPF_H, p2);
        gen_and(d, tmp);
        d = tmp;
        gen_and(s, d);
        b1 = d;
        break;
    }
    default:
        bpf_err(cs, "direction not supported on portrange");
        return NULL;
    }
    gen_and(b0, b1);
    return b1;
}

static block *gen_portrange(cstate *cs, u32 p1, u32 p2, int ip_proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portrangeop(cs, p1, p2, (u32)ip_proto, dir);
        break;
    default:
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_TCP, dir);
        b1 = gen_portrangeop(cs, p1, p2, IPPROTO_UDP, dir);
        gen_or(tmp, b1);
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_SCTP, dir);
        gen_or(tmp, b1);
        break;
    }
    gen_and(b0, b1);
    return b1;
}

static block *gen_portrangeop6(cstate *cs, u32 p1, u32 p2, u32 proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case D_SRC:
        b1 = gen_cmp_ge(cs, OR_TRAN_IPV6, 0, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV6, 0, BPF_H, p2);
        gen_and(b1, tmp);
        b1 = tmp;
        break;
    case D_DST:
        b1 = gen_cmp_ge(cs, OR_TRAN_IPV6, 2, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV6, 2, BPF_H, p2);
        gen_and(b1, tmp);
        b1 = tmp;
        break;
    case D_OR:
    case D_DEFAULT: {
        block *s, *d;
        s = gen_cmp_ge(cs, OR_TRAN_IPV6, 0, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV6, 0, BPF_H, p2);
        gen_and(s, tmp);
        s = tmp;
        d = gen_cmp_ge(cs, OR_TRAN_IPV6, 2, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV6, 2, BPF_H, p2);
        gen_and(d, tmp);
        d = tmp;
        gen_or(s, d);
        b1 = d;
        break;
    }
    case D_AND: {
        block *s, *d;
        s = gen_cmp_ge(cs, OR_TRAN_IPV6, 0, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV6, 0, BPF_H, p2);
        gen_and(s, tmp);
        s = tmp;
        d = gen_cmp_ge(cs, OR_TRAN_IPV6, 2, BPF_H, p1);
        tmp = gen_cmp_le(cs, OR_TRAN_IPV6, 2, BPF_H, p2);
        gen_and(d, tmp);
        d = tmp;
        gen_and(s, d);
        b1 = d;
        break;
    }
    default:
        bpf_err(cs, "direction not supported on portrange");
        return NULL;
    }
    gen_and(b0, b1);
    return b1;
}

static block *gen_portrange6(cstate *cs, u32 p1, u32 p2, int ip_proto, int dir)
{
    block *b0, *b1, *tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portrangeop6(cs, p1, p2, (u32)ip_proto, dir);
        break;
    default:
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_TCP, dir);
        b1 = gen_portrangeop6(cs, p1, p2, IPPROTO_UDP, dir);
        gen_or(tmp, b1);
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_SCTP, dir);
        gen_or(tmp, b1);
        break;
    }
    gen_and(b0, b1);
    return b1;
}

/* ------------------------------------------------------------------ */
/* name-based primitives                                              */
/* ------------------------------------------------------------------ */
static int proto_to_ipproto(int proto)
{
    switch (proto) {
    case P_UDP:  return IPPROTO_UDP;
    case P_TCP:  return IPPROTO_TCP;
    case P_SCTP: return IPPROTO_SCTP;
    default:     return PROTO_UNDEF;
    }
}

static u32 net_mask(u32 addr)
{
    if (addr == 0) return 0;
    if ((addr & 0xff000000u) == 0) return 0;
    if ((addr & 0x80000000u) == 0) return 0xff000000u;
    if ((addr & 0x40000000u) == 0) return 0xffff0000u;
    return 0xffffff00u;
}

static int lookup_proto(cstate *cs, const char *name, int proto)
{
    int v;

    switch (proto) {
    case P_DEFAULT:
    case P_IP:
    case P_IPV6:
        if (!tbl_lookup_proto(name, &v))
            bpf_err(cs, "unknown ip proto '%s'", name);
        break;
    case P_LINK:
        if (!tbl_lookup_ethertype(name, &v)) {
            if (!tbl_lookup_llcsap(name, &v))
                bpf_err(cs, "unknown ether proto '%s'", name);
        }
        break;
    case P_ISO:
        if (!tbl_lookup_proto(name, &v))
            bpf_err(cs, "unknown osi proto '%s'", name);
        break;
    default:
        v = PROTO_UNDEF;
        break;
    }
    return v;
}

block *gen_scode(cstate *cs, const char *name, qual q)
{
    int proto = q.proto, dir = q.dir;
    u32 addr, mask;
    block *b, *tmp;
    int port, port2, real_proto, tproto;
    u32 addrs[16];
    unsigned char eaddr[6];
    int naddr, i;

    switch (q.addr) {
    case A_NET:
        if (!tbl_lookup_net(name, &addr))
            bpf_err(cs, "unknown network '%s'", name);
        mask = net_mask(addr);
        return gen_host(cs, addr, mask, proto, dir, q.addr);

    case A_DEFAULT:
    case A_HOST:
        if (proto == P_LINK) {
            if (!tbl_lookup_ether(name, eaddr))
                bpf_err(cs, "unknown ether host '%s'", name);
            return gen_ehostop(cs, eaddr, dir);
        } else {
            unsigned char a6[16], m6[16];
            b = NULL;
            if (tbl_lookup_host6(name, a6)) {
                memset(m6, 0xff, sizeof(m6));
                b = gen_host6(cs, a6, m6, proto, dir, q.addr);
            }
            if (tbl_lookup_host(name, addrs, 16, &naddr)) {
                for (i = 0; i < naddr; i++) {
                    tmp = gen_host(cs, addrs[i], 0xffffffffu, proto, dir, q.addr);
                    if (b) { gen_or(b, tmp); }
                    b = tmp;
                }
            }
            if (b == NULL)
                bpf_err(cs, "unknown host '%s'", name);
            return b;
        }

    case A_PORT:
        if (proto != P_DEFAULT && proto != P_UDP && proto != P_TCP && proto != P_SCTP)
            bpf_err(cs, "illegal qualifier of 'port'");
        if (!tbl_lookup_port(name, &port, &real_proto))
            bpf_err(cs, "unknown port '%s'", name);
        tproto = proto_to_ipproto(proto);
        if (proto == P_DEFAULT && real_proto != PROTO_UNDEF)
            tproto = real_proto;
        if (proto == P_UDP && real_proto == IPPROTO_TCP)
            bpf_err(cs, "port '%s' is tcp", name);
        if (proto == P_TCP && real_proto == IPPROTO_UDP)
            bpf_err(cs, "port '%s' is udp", name);
        b = gen_port(cs, (u32)port, tproto, dir);
        tmp = gen_port6(cs, (u32)port, tproto, dir);
        gen_or(tmp, b);
        return b;

    case A_PORTRANGE:
        if (proto != P_DEFAULT && proto != P_UDP && proto != P_TCP && proto != P_SCTP)
            bpf_err(cs, "illegal qualifier of 'portrange'");
        {
            const char *dash = strchr(name, '-');
            char lo[64];
            size_t n;
            int p1 = -1, p2 = -1, rp1 = PROTO_UNDEF, rp2 = PROTO_UNDEF;
            if (!dash) {
                if (!tbl_lookup_port(name, &p1, &rp1))
                    bpf_err(cs, "unknown port in range '%s'", name);
                p2 = p1; rp2 = rp1;
            } else {
                n = (size_t)(dash - name);
                if (n >= sizeof(lo)) n = sizeof(lo) - 1;
                memcpy(lo, name, n);
                lo[n] = '\0';
                if (!tbl_lookup_port(lo, &p1, &rp1) ||
                    !tbl_lookup_port(dash + 1, &p2, &rp2))
                    bpf_err(cs, "unknown port in range '%s'", name);
            }
            real_proto = (rp1 == rp2) ? rp1 : PROTO_UNDEF;
            tproto = proto_to_ipproto(proto);
            if (proto == P_DEFAULT && real_proto != PROTO_UNDEF)
                tproto = real_proto;
            b = gen_portrange(cs, (u32)p1, (u32)p2, tproto, dir);
            tmp = gen_portrange6(cs, (u32)p1, (u32)p2, tproto, dir);
            gen_or(tmp, b);
            return b;
        }

    case A_GATEWAY:
        /* a gateway needs both a link-layer and an IP address for the name */
        if (!tbl_lookup_ether(name, eaddr))
            bpf_err(cs, "unknown ether host: %s", name);
        return NULL;

    case A_PROTO:
        real_proto = lookup_proto(cs, name, proto);
        return gen_proto(cs, (u32)real_proto, proto, dir);

    case A_PROTOCHAIN:
        real_proto = lookup_proto(cs, name, proto);
        return gen_protochain(cs, (u32)real_proto, proto);

    default:
        bpf_err(cs, "can't parse filter expression: syntax error");
        return NULL;
    }
}

/* parse a dotted quad; sets *bits to the number of octets * 8 */
static int atoin(cstate *cs, const char *s, u32 *addr)
{
    u32 v = 0, part;
    int n = 0;
    const char *p = s;

    while (*p) {
        part = 0;
        if (!(*p >= '0' && *p <= '9')) return 0;
        while (*p >= '0' && *p <= '9') { part = part * 10 + (u32)(*p - '0'); p++; }
        if (part > 255) bpf_err(cs, "invalid IPv4 address '%s'", s);
        v = (v << 8) | part;
        n += 8;
        if (*p == '.') p++;
        else break;
    }
    *addr = v;
    return n;
}

block *gen_ncode(cstate *cs, const char *s, u32 v, qual q)
{
    u32 mask;
    int proto = q.proto, dir = q.dir;
    int vlen, tproto;
    block *b, *tmp;

    if (s == NULL) vlen = 32;
    else vlen = atoin(cs, s, &v);

    switch (q.addr) {
    case A_DEFAULT:
    case A_HOST:
    case A_NET:
        if (proto == P_LINK)
            bpf_err(cs, "illegal link layer address");
        mask = 0xffffffffu;
        if (s == NULL && q.addr == A_NET) {
            while (v && (v & 0xff000000u) == 0) { v <<= 8; mask <<= 8; }
        } else {
            if (vlen < 32) { v <<= (u32)(32 - vlen); mask <<= (u32)(32 - vlen); }
        }
        return gen_host(cs, v, mask, proto, dir, q.addr);

    case A_PORT:
        if (proto != P_DEFAULT && proto != P_UDP && proto != P_TCP && proto != P_SCTP)
            bpf_err(cs, "illegal qualifier of 'port'");
        if (v > 65535)
            bpf_err(cs, "illegal port number %u > 65535", v);
        tproto = proto_to_ipproto(proto);
        b = gen_port(cs, v, tproto, dir);
        tmp = gen_port6(cs, v, tproto, dir);
        gen_or(tmp, b);
        return b;

    case A_PORTRANGE:
        if (proto != P_DEFAULT && proto != P_UDP && proto != P_TCP && proto != P_SCTP)
            bpf_err(cs, "illegal qualifier of 'portrange'");
        if (v > 65535)
            bpf_err(cs, "illegal port number %u > 65535", v);
        tproto = proto_to_ipproto(proto);
        b = gen_portrange(cs, v, v, tproto, dir);
        tmp = gen_portrange6(cs, v, v, tproto, dir);
        gen_or(tmp, b);
        return b;

    case A_GATEWAY:
        bpf_err(cs, "'gateway' requires a name");
        return NULL;

    case A_PROTO:
        return gen_proto(cs, v, proto, dir);

    case A_PROTOCHAIN:
        return gen_protochain(cs, v, proto);

    default:
        bpf_err(cs, "can't parse filter expression: syntax error");
        return NULL;
    }
}

block *gen_mcode(cstate *cs, const char *a1, const char *a2, u32 masklen, qual q)
{
    u32 addr, mask;
    int nlen, mlen;

    nlen = atoin(cs, a1, &addr);
    if (a2 != NULL) {
        mlen = atoin(cs, a2, &mask);
        if (mlen < 32) mask <<= (u32)(32 - mlen);
        if ((addr & ~mask) != 0)
            bpf_err(cs, "non-network bits set in \"%s mask %s\"", a1, a2);
    } else {
        if (masklen > 32)
            bpf_err(cs, "mask length must be <= 32");
        if (masklen == 0) mask = 0;
        else mask = 0xffffffffu << (32 - masklen);
        if (nlen < 32) addr <<= (u32)(32 - nlen);
        if ((addr & ~mask) != 0)
            bpf_err(cs, "non-network bits set in \"%s/%u\"", a1, masklen);
    }

    switch (q.addr) {
    case A_NET:
    case A_DEFAULT:
    case A_HOST:
        return gen_host(cs, addr, mask, q.proto, q.dir, q.addr);
    default:
        bpf_err(cs, "Mask syntax for networks only");
        return NULL;
    }
}

block *gen_mcode6(cstate *cs, const char *a1, u32 masklen, qual q)
{
    unsigned char addr[16], mask[16];
    int i;

    if (!tbl_parse_ip6(a1, addr))
        bpf_err(cs, "invalid IPv6 address '%s'", a1);
    if (masklen > 128)
        bpf_err(cs, "mask length must be <= 128");
    for (i = 0; i < 16; i++) {
        u32 bits = (u32)(i * 8);
        if (masklen >= bits + 8) mask[i] = 0xff;
        else if (masklen <= bits) mask[i] = 0;
        else mask[i] = (unsigned char)(0xff << (8 - (masklen - bits)));
    }
    for (i = 0; i < 16; i++) {
        if (addr[i] & ~mask[i])
            bpf_err(cs, "non-network bits set in \"%s/%u\"", a1, masklen);
    }
    switch (q.addr) {
    case A_NET:
    case A_DEFAULT:
    case A_HOST:
        return gen_host6(cs, addr, mask, q.proto, q.dir, q.addr);
    default:
        bpf_err(cs, "invalid qualifier against IPv6 address");
        return NULL;
    }
}

block *gen_acode(cstate *cs, const char *s, qual q)
{
    (void)s; (void)q;
    bpf_err(cs, "ATM address used in non-ATM expression");
    return NULL;
}
