/*
 * genmisc.c - arithmetic, byte slices, encapsulation and the remaining
 * primitives, plus the final wiring of the block graph.
 */
#include <string.h>

#include "bpfc.h"
#include "gen.h"
#include "proto.h"

#define PROTO_UNDEF (-1)

/* ------------------------------------------------------------------ */
/* link-layer addresses                                               */
/* ------------------------------------------------------------------ */
static block *gen_wlanhostop(cstate *cs, const unsigned char *eaddr, int dir)
{
    block *b0, *b1;

    switch (dir) {
    case D_ADDR1: return gen_bcmp(cs, OR_LINKHDR, 4, 6, eaddr);
    case D_ADDR2: return gen_bcmp(cs, OR_LINKHDR, 10, 6, eaddr);
    case D_ADDR3: return gen_bcmp(cs, OR_LINKHDR, 16, 6, eaddr);
    case D_ADDR4:
        b0 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x03, 0x03);
        b1 = gen_bcmp(cs, OR_LINKHDR, 24, 6, eaddr);
        gen_and(b0, b1);
        return b1;
    case D_RA:
        b0 = gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0x04, 0x0c);
        gen_not(b0);
        b1 = gen_bcmp(cs, OR_LINKHDR, 4, 6, eaddr);
        gen_and(b0, b1);
        return b1;
    case D_TA:
        b0 = gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0x04, 0x0c);
        gen_not(b0);
        b1 = gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0xc0, 0xf0);
        gen_not(b1);
        gen_and(b0, b1);
        b0 = b1;
        b1 = gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0xd0, 0xf0);
        gen_not(b1);
        gen_and(b0, b1);
        b0 = b1;
        b1 = gen_bcmp(cs, OR_LINKHDR, 10, 6, eaddr);
        gen_and(b0, b1);
        return b1;
    default:
        bpf_err(cs, "direction not supported on 802.11 link-layer address");
        return NULL;
    }
}

block *gen_ehostop(cstate *cs, const unsigned char *eaddr, int dir)
{
    block *b0, *b1;

    switch (cs->linktype) {
    case 1:     /* DLT_EN10MB */
        break;
    case 105:   /* DLT_IEEE802_11 */
        return gen_wlanhostop(cs, eaddr, dir);
    default:
        if (dlt_name(cs->linktype) == NULL)
            bpf_err(cs, "unknown data link type %d", cs->linktype);
        bpf_err(cs, "ethernet addresses supported only on "
                    "ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel");
        return NULL;
    }

    switch (dir) {
    case D_SRC:
        return gen_bcmp(cs, OR_LINKHDR, 6, 6, eaddr);
    case D_DST:
        return gen_bcmp(cs, OR_LINKHDR, 0, 6, eaddr);
    case D_AND:
        b0 = gen_ehostop(cs, eaddr, D_SRC);
        b1 = gen_ehostop(cs, eaddr, D_DST);
        gen_and(b0, b1);
        return b1;
    case D_DEFAULT:
    case D_OR:
        b0 = gen_ehostop(cs, eaddr, D_SRC);
        b1 = gen_ehostop(cs, eaddr, D_DST);
        gen_or(b0, b1);
        return b1;
    default:
        bpf_err(cs, "direction not supported on linktype");
        return NULL;
    }
}

block *gen_ecode(cstate *cs, const char *s, qual q)
{
    unsigned char eaddr[6];
    int i, n = 0;
    u32 v = 0;

    /* parse the b:b:b:b:b:b literal */
    for (i = 0; s[i] && n < 6; i++) {
        char c = s[i];
        if (c == ':') { eaddr[n++] = (unsigned char)v; v = 0; continue; }
        v = v * 16;
        if (c >= '0' && c <= '9') v += (u32)(c - '0');
        else if (c >= 'a' && c <= 'f') v += (u32)(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') v += (u32)(c - 'A' + 10);
    }
    if (n < 6) eaddr[n++] = (unsigned char)v;

    if ((q.addr == A_HOST || q.addr == A_DEFAULT) && q.proto == P_LINK)
        return gen_ehostop(cs, eaddr, q.dir);
    bpf_err(cs, "ethernet address used in non-ether expression");
    return NULL;
}

/* ------------------------------------------------------------------ */
/* arithmetic                                                         */
/* ------------------------------------------------------------------ */
static sstmt *xfer_to_x(cstate *cs, arth *a)
{
    sstmt *s = new_stmt(cs, BPF_LDX | BPF_MEM);
    s->k = (u32)a->regno;
    return s;
}

static sstmt *xfer_to_a(cstate *cs, arth *a)
{
    sstmt *s = new_stmt(cs, BPF_LD | BPF_MEM);
    s->k = (u32)a->regno;
    return s;
}

static arth *new_arth(cstate *cs)
{
    arth *a = ar_alloc(&cs->ar, sizeof(*a));
    memset(a, 0, sizeof(*a));
    a->regno = -1;
    return a;
}

arth *gen_loadi(cstate *cs, u32 val)
{
    arth *a;
    sstmt *s, *s2;
    int reg = alloc_reg(cs);

    a = new_arth(cs);
    s = new_stmt(cs, BPF_LD | BPF_IMM);
    s->k = val;
    s2 = new_stmt(cs, BPF_ST);
    s2->k = (u32)reg;
    sappend(s, s2);
    a->s = s;
    a->regno = reg;
    return a;
}

arth *gen_loadlen(cstate *cs)
{
    int reg = alloc_reg(cs);
    arth *a = new_arth(cs);
    sstmt *s, *s2;

    s = new_stmt(cs, BPF_LD | BPF_LEN);
    s2 = new_stmt(cs, BPF_ST);
    s2->k = (u32)reg;
    sappend(s, s2);
    a->s = s;
    a->regno = reg;
    return a;
}

arth *gen_load(cstate *cs, int proto, arth *inst, u32 size)
{
    sstmt *s, *tmp;
    block *b;
    int regno = alloc_reg(cs);

    switch (size) {
    default: bpf_err(cs, "data size must be 1, 2, or 4"); return NULL;
    case 1: size = BPF_B; break;
    case 2: size = BPF_H; break;
    case 4: size = BPF_W; break;
    }

    switch (proto) {
    default:
        bpf_err(cs, "unsupported index operation");
        return NULL;

    case P_RADIO:
        bpf_err(cs, "radio information not present in capture");
        return NULL;

    case P_LINK:
        s = xfer_to_x(cs, inst);
        tmp = new_stmt(cs, BPF_LD | BPF_IND | size);
        tmp->k = cs->off_linkhdr.constant_part;
        sappend(s, tmp);
        sappend(inst->s, s);
        break;

    case P_IP: case P_ARP: case P_RARP: case P_ATALK: case P_DECNET:
    case P_SCA: case P_LAT: case P_MOPRC: case P_MOPDL: case P_IPV6:
        s = xfer_to_x(cs, inst);
        tmp = new_stmt(cs, BPF_LD | BPF_IND | size);
        tmp->k = cs->off_linkpl.constant_part + cs->off_nl;
        sappend(s, tmp);
        sappend(inst->s, s);
        b = gen_proto_abbrev(cs, proto);
        if (inst->b) { gen_and(inst->b, b); }
        inst->b = b;
        break;

    case P_SCTP: case P_TCP: case P_UDP: case P_ICMP: case P_IGMP:
    case P_IGRP: case P_PIM: case P_VRRP: case P_CARP: case P_ICMPV6:
    case P_AH: case P_ESP:
    {
        block *b2;
        b = gen_linktype(cs, ETHERTYPE_IP);
        b2 = gen_proto_abbrev(cs, proto);
        gen_and(b, b2);
        b = b2;
        b2 = gen_ipfrag(cs);
        gen_and(b, b2);
        b = b2;

        s = gen_load_a(cs, OR_TRAN_IPV4, 0, size);
        /* replace the tail load with an indexed load through the index reg */
        {
            sstmt *ldx = s;
            sstmt *prev = NULL, *cur = s;
            while (cur->next) { prev = cur; cur = cur->next; }
            (void)ldx; (void)prev;
            /* cur is the BPF_LD|BPF_IND load; rebuild the sequence */
        }
        /* build: ldx iphdrlen ; ld M[reg] ; add x ; tax ; ld [x + off] */
        {
            sstmt *seq, *t;
            seq = gen_load_a(cs, OR_TRAN_IPV4, 0, size);
            /* drop the final load, we need the index added first */
            {
                sstmt *p2 = seq, *last = NULL;
                while (p2->next) { last = p2; p2 = p2->next; }
                if (last) last->next = NULL;
            }
            t = xfer_to_a(cs, inst);
            sappend(seq, t);
            t = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X);
            sappend(seq, t);
            t = new_stmt(cs, BPF_MISC | BPF_TAX);
            sappend(seq, t);
            t = new_stmt(cs, BPF_LD | BPF_IND | size);
            t->k = cs->off_linkpl.constant_part + cs->off_nl;
            sappend(seq, t);
            sappend(inst->s, seq);
        }
        if (inst->b) { gen_and(inst->b, b); }
        inst->b = b;
        break;
    }
    }

    inst->regno = regno;
    s = new_stmt(cs, BPF_ST);
    s->k = (u32)regno;
    sappend(inst->s, s);
    return inst;
}

arth *gen_neg(cstate *cs, arth *a)
{
    sstmt *s;

    s = xfer_to_a(cs, a);
    sappend(a->s, s);
    s = new_stmt(cs, BPF_ALU | BPF_NEG);
    sappend(a->s, s);
    s = new_stmt(cs, BPF_ST);
    s->k = (u32)a->regno;
    sappend(a->s, s);
    return a;
}

arth *gen_arth(cstate *cs, int code, arth *a0, arth *a1)
{
    sstmt *s0, *s1, *s2;
    int reg;

    s0 = xfer_to_x(cs, a1);
    s1 = xfer_to_a(cs, a0);
    s2 = new_stmt(cs, BPF_ALU | BPF_X | code);
    sappend(s1, s2);
    sappend(s0, s1);
    sappend(a1->s, s0);
    sappend(a0->s, a1->s);

    free_reg(cs, a0->regno);
    free_reg(cs, a1->regno);
    reg = alloc_reg(cs);
    a0->regno = reg;
    s2 = new_stmt(cs, BPF_ST);
    s2->k = (u32)reg;
    sappend(a0->s, s2);

    if (a0->b == NULL) a0->b = a1->b;
    else if (a1->b != NULL) { gen_and(a0->b, a1->b); a0->b = a1->b; }
    return a0;
}

block *gen_relation(cstate *cs, int code, arth *a0, arth *a1, int reversed)
{
    sstmt *s0, *s1, *s2;
    block *b, *tmp;

    s0 = xfer_to_x(cs, a1);
    s1 = xfer_to_a(cs, a0);
    if (code == BPF_JEQ) {
        s2 = new_stmt(cs, BPF_ALU | BPF_SUB | BPF_X);
        b = new_block(cs, JMPOP(code));
        sappend(s1, s2);
    } else {
        b = new_block(cs, BPF_JMP | code | BPF_X);
    }
    sappend(s0, s1);
    sappend(a1->s, s0);
    sappend(a0->s, a1->s);
    b->stmts = a0->s;
    b->k = 0;

    if (reversed) gen_not(b);

    free_reg(cs, a0->regno);
    free_reg(cs, a1->regno);

    if (a0->b) {
        if (a1->b) { gen_and(a0->b, a1->b); tmp = a1->b; }
        else tmp = a0->b;
    } else tmp = a1->b;
    if (tmp) { gen_and(tmp, b); }
    return b;
}

/* ------------------------------------------------------------------ */
/* misc primitives                                                    */
/* ------------------------------------------------------------------ */
static block *gen_len(cstate *cs, int jmp, int n)
{
    sstmt *s;
    block *b;

    s = new_stmt(cs, BPF_LD | BPF_LEN);
    b = new_block(cs, JMPOP(jmp));
    b->stmts = s;
    b->k = (u32)n;
    return b;
}

block *gen_greater(cstate *cs, int n)
{
    return gen_len(cs, BPF_JGE, n);
}

block *gen_less(cstate *cs, int n)
{
    block *b = gen_len(cs, BPF_JGT, n);
    gen_not(b);
    return b;
}

block *gen_byteop(cstate *cs, int op, int idx, int val)
{
    block *b;
    sstmt *s;

    switch (op) {
    default: bpf_err(cs, "unsupported byte op"); return NULL;
    case '=': case BPF_JEQ:
        return gen_cmp(cs, OR_LINKHDR, (u32)idx, BPF_B, (u32)val);
    case BPF_JGT:
        return gen_cmp_gt(cs, OR_LINKHDR, (u32)idx, BPF_B, (u32)val);
    case BPF_JGE:
        return gen_cmp_ge(cs, OR_LINKHDR, (u32)idx, BPF_B, (u32)val);
    }
    (void)s; (void)b;
}

block *gen_broadcast(cstate *cs, int proto)
{
    static const unsigned char ebroadcast[6] = { 0xff,0xff,0xff,0xff,0xff,0xff };
    block *b0, *b1, *b2;
    u32 hostmask;

    switch (proto) {
    case P_DEFAULT:
    case P_LINK:
        switch (cs->linktype) {
        case 1:
            return gen_bcmp(cs, OR_LINKHDR, 0, 6, ebroadcast);
        default:
            bpf_err(cs, "not a broadcast link");
            return NULL;
        }
    case P_IP:
        if (!cs->netmask_known)
            bpf_err(cs, "netmask not known, so 'ip broadcast' not supported");
        b0 = gen_linktype(cs, ETHERTYPE_IP);
        hostmask = ~cs->netmask;
        b1 = gen_mcmp(cs, OR_LINKPL, 16, BPF_W, 0, hostmask);
        b2 = gen_mcmp(cs, OR_LINKPL, 16, BPF_W, hostmask, hostmask);
        gen_or(b1, b2);
        gen_and(b0, b2);
        return b2;
    default:
        bpf_err(cs, "only link-layer/IP broadcast filters supported");
        return NULL;
    }
}

block *gen_multicast(cstate *cs, int proto)
{
    block *b0, *b1;
    sstmt *s;

    switch (proto) {
    case P_DEFAULT:
    case P_LINK:
        switch (cs->linktype) {
        case 1:
            s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
            b0 = new_block(cs, JMPOP(BPF_JSET));
            b0->k = 1;
            b0->stmts = s;
            return b0;
        case 105:
            s = gen_load_a(cs, OR_LINKHDR, 4, BPF_B);
            b0 = new_block(cs, JMPOP(BPF_JSET));
            b0->k = 1;
            b0->stmts = s;
            return b0;
        default:
            bpf_err(cs, "link-layer multicast filters supported only on "
                        "ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel");
            return NULL;
        }
    case P_IP:
        b0 = gen_linktype(cs, ETHERTYPE_IP);
        b1 = gen_mcmp(cs, OR_LINKPL, 16, BPF_B, 0xe0, 0xf0);
        gen_and(b0, b1);
        return b1;
    case P_IPV6:
        b0 = gen_linktype(cs, ETHERTYPE_IPV6);
        b1 = gen_cmp(cs, OR_LINKPL, 24, BPF_B, 255);
        gen_and(b0, b1);
        return b1;
    default:
        bpf_err(cs, "only link-layer/IP multicast filters supported");
        return NULL;
    }
}

block *gen_inbound(cstate *cs, int dir)
{
    block *b0;

    switch (cs->linktype) {
    case 113:
        b0 = gen_cmp(cs, OR_LINKHDR, 0, BPF_H, LINUX_SLL_OUTGOING);
        if (!dir) gen_not(b0);
        return b0;
    default:
        bpf_err(cs, "inbound/outbound not supported on %s",
                dlt_description(cs->linktype));
        return NULL;
    }
}

block *gen_ifindex(cstate *cs, int idx)
{
    return gen_cmp(cs, OR_LINKHDR, (u32)(SKF_AD_OFF + SKF_AD_IFINDEX), BPF_W, (u32)idx);
}

block *gen_vlan(cstate *cs, u32 num, int has_num)
{
    block *b0, *b1;

    if (cs->label_stack_depth > 0)
        bpf_err(cs, "no VLAN match after MPLS");

    switch (cs->linktype) {
    case 1:
        break;
    default:
        bpf_err(cs, "no VLAN support for %s", dlt_description(cs->linktype));
        return NULL;
    }

    b0 = gen_linktype(cs, ETHERTYPE_8021Q);
    b1 = gen_linktype(cs, ETHERTYPE_8021AD);
    gen_or(b0, b1);
    b0 = b1;
    b1 = gen_linktype(cs, ETHERTYPE_8021QINQ);
    gen_or(b0, b1);
    b0 = b1;

    if (has_num) {
        b1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_H, num, 0x0fff);
        gen_and(b0, b1);
        b0 = b1;
    }

    cs->off_linkpl.constant_part += 4;
    cs->off_linktype.constant_part += 4;
    cs->vlan_stack_depth++;
    return b0;
}

block *gen_mpls(cstate *cs, u32 num, int has_num)
{
    block *b0, *b1;

    if (cs->label_stack_depth > 0) {
        b0 = gen_mcmp(cs, OR_PREVMPLSHDR, 2, BPF_B, 0, 0x01);
    } else {
        switch (cs->linktype) {
        case 1:
        case 104:
            b0 = gen_linktype(cs, ETHERTYPE_MPLS);
            break;
        case 9:
            b0 = gen_linktype(cs, PPP_MPLS_UCAST);
            break;
        default:
            bpf_err(cs, "no MPLS support for %s", dlt_description(cs->linktype));
            return NULL;
        }
    }

    if (has_num) {
        b1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_W, num << 12, 0xfffff000u);
        gen_and(b0, b1);
        b0 = b1;
    }

    cs->off_nl_nosnap += 4;
    cs->off_nl += 4;
    cs->label_stack_depth++;
    return b0;
}

block *gen_pppoed(cstate *cs)
{
    return gen_linktype(cs, ETHERTYPE_PPPOED);
}

block *gen_pppoes(cstate *cs, u32 num, int has_num)
{
    block *b0, *b1;

    b0 = gen_linktype(cs, ETHERTYPE_PPPOES);
    if (has_num) {
        b1 = gen_mcmp(cs, OR_LINKPL, 2, BPF_H, num, 0x0000ffffu);
        gen_and(b0, b1);
        b0 = b1;
    }

    cs->off_linkhdr.constant_part = cs->off_linkpl.constant_part;
    cs->off_linkhdr.is_variable = cs->off_linkpl.is_variable;
    cs->off_linkhdr.reg = cs->off_linkpl.reg;
    cs->off_linktype.constant_part = cs->off_linkpl.constant_part + 6;
    cs->off_linktype.is_variable = cs->off_linkpl.is_variable;
    cs->off_linktype.reg = cs->off_linkpl.reg;
    cs->off_linkpl.constant_part = cs->off_linkpl.constant_part + 8;
    cs->off_nl = 0;
    cs->off_nl_nosnap = 0;
    cs->linktype = 9;   /* PPP */
    return b0;
}

block *gen_geneve(cstate *cs, u32 num, int has_num)
{
    (void)num; (void)has_num;
    bpf_err(cs, "geneve not supported");
    return NULL;
}

block *gen_p80211_type(cstate *cs, int type, int mask)
{
    switch (cs->linktype) {
    case 105:
        return gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, (u32)type, (u32)mask);
    default:
        bpf_err(cs, "802.11 link-layer types supported only on 802.11");
        return NULL;
    }
}

block *gen_p80211_fcdir(cstate *cs, int dir)
{
    switch (cs->linktype) {
    case 105:
        return gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, (u32)dir, 0x03);
    default:
        bpf_err(cs, "frame direction supported only with 802.11 headers");
        return NULL;
    }
}

/* protochain: not yet an exact reproduction; approximate with a proto test */
block *gen_protochain(cstate *cs, u32 v, int proto)
{
    return gen_proto(cs, v, proto, D_DEFAULT);
}

/* ------------------------------------------------------------------ */
/* variable-offset preamble                                           */
/* ------------------------------------------------------------------ */
static sstmt *gen_load_802_11_header_len(cstate *cs)
{
    sstmt *s, *t, *j1, *j2, *jq;

    s = new_stmt(cs, BPF_LDX | BPF_IMM);
    s->k = 0;

    t = new_stmt(cs, BPF_MISC | BPF_TXA);
    sappend(s, t);
    t = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    t->k = 24;
    sappend(s, t);
    t = new_stmt(cs, BPF_ST);
    t->k = (u32)cs->off_linkpl.reg;
    sappend(s, t);

    t = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
    t->k = 0;
    sappend(s, t);

    j1 = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    j1->k = 0x08;
    sappend(s, j1);
    j2 = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    j2->k = 0x04;
    sappend(s, j2);
    jq = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    jq->k = 0x80;
    sappend(s, jq);

    t = new_stmt(cs, BPF_LD | BPF_MEM);
    t->k = (u32)cs->off_linkpl.reg;
    sappend(s, t);
    j1->jt = j2;
    j1->jf = NULL;
    j2->jt = NULL;
    j2->jf = jq;
    jq->jt = t;
    jq->jf = NULL;

    t = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    t->k = 2;
    sappend(s, t);
    t = new_stmt(cs, BPF_ST);
    t->k = (u32)cs->off_linkpl.reg;
    sappend(s, t);

    return s;
}

static void insert_compute_vloffsets(cstate *cs, block *b)
{
    sstmt *s = NULL, *p;

    switch (cs->linktype) {
    case 105:
        if (cs->off_linkpl.is_variable && cs->off_linkpl.reg != -1)
            s = gen_load_802_11_header_len(cs);
        break;
    default:
        break;
    }
    if (s == NULL) return;
    /* the preamble contains jumps between steps, which the shrinker cannot
     * reason about */
    cs->no_shrink = 1;

    /* jumps that fall out of the sequence continue at the old first stmt */
    for (p = s; p; p = p->next) {
        if (BPF_CLASS(p->code) == BPF_JMP) {
            if (p->jt == NULL) p->jt = b->stmts;
            if (p->jf == NULL) p->jf = b->stmts;
        }
    }
    sappend(s, b->stmts);
    b->stmts = s;
}

void finish_parse(cstate *cs, block *p)
{
    insert_compute_vloffsets(cs, p->head);
    backpatch(p, gen_retblk(cs, cs->snaplen));
    p->sense = !p->sense;
    backpatch(p, gen_retblk(cs, 0));
    cs->root = p->head;
}
