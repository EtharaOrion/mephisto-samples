/*
 * genlink.c - link-layer specific code generation.
 */
#include <string.h>

#include "bpfc.h"
#include "gen.h"
#include "proto.h"

const char *dlt_description(int dlt)
{
    switch (dlt) {
    case 0:   return "BSD loopback";
    case 1:   return "Ethernet";
    case 3:   return "AX.25";
    case 6:   return "Token ring";
    case 7:   return "ARCNET";
    case 8:   return "SLIP";
    case 9:   return "PPP";
    case 10:  return "FDDI";
    case 12:  return "Raw IP";
    case 50:  return "PPP over serial";
    case 51:  return "PPPoE";
    case 100: return "RFC 1483 LLC-encapsulated ATM";
    case 104: return "Cisco HDLC";
    case 105: return "802.11";
    case 107: return "Frame Relay";
    case 108: return "OpenBSD loopback";
    case 113: return "Linux cooked v1";
    case 114: return "LocalTalk";
    case 117: return "OpenBSD pflog";
    case 119: return "802.11 plus Prism header";
    case 122: return "IP-over-Fibre Channel";
    case 127: return "802.11 plus radiotap header";
    case 143: return "DOCSIS";
    case 163: return "802.11 plus AVS header";
    case 228: return "Raw IPv4";
    case 229: return "Raw IPv6";
    case 276: return "Linux cooked v2";
    default:  return NULL;
    }
}

void init_linktype(cstate *cs)
{
    cs->off_linkhdr.constant_part = 0;
    cs->off_linkhdr.is_variable = 0;
    cs->off_linkhdr.reg = -1;
    cs->off_prevlinkhdr = cs->off_linkhdr;
    cs->off_linktype.constant_part = OFF_UNSET;
    cs->off_linktype.is_variable = 0;
    cs->off_linktype.reg = -1;
    cs->off_linkpl.constant_part = 0;
    cs->off_linkpl.is_variable = 0;
    cs->off_linkpl.reg = -1;
    cs->off_nl = OFF_UNSET;
    cs->off_nl_nosnap = OFF_UNSET;
    cs->label_stack_depth = 0;
    cs->vlan_stack_depth = 0;

    switch (cs->linktype) {
    case 1:     /* DLT_EN10MB */
        cs->off_linktype.constant_part = 12;
        cs->off_linkpl.constant_part = 14;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 3;
        break;
    case 0:     /* DLT_NULL */
    case 108:   /* DLT_LOOP */
    case 109:   /* DLT_ENC */
        cs->off_linktype.constant_part = 0;
        cs->off_linkpl.constant_part = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;
    case 9:     /* DLT_PPP */
    case 50:    /* DLT_PPP_SERIAL */
    case 51:    /* DLT_PPP_ETHER */
    case 204:   /* DLT_PPP_PPPD */
        cs->off_linktype.constant_part = 2;
        cs->off_linkpl.constant_part = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;
    case 12:    /* DLT_RAW */
    case 101:   /* handled as unknown */
    case 228:
    case 229:
        cs->off_linktype.constant_part = OFF_UNSET;
        cs->off_linkpl.constant_part = 0;
        cs->off_nl = 0;
        cs->off_nl_nosnap = OFF_UNSET;
        break;
    case 113:   /* DLT_LINUX_SLL */
        cs->off_linktype.constant_part = 14;
        cs->off_linkpl.constant_part = 16;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;
    case 105:   /* DLT_IEEE802_11 */
        cs->off_linktype.constant_part = OFF_UNSET;
        cs->off_linkpl.constant_part = 0;
        cs->off_linkpl.is_variable = 1;
        cs->off_nl = 8;
        cs->off_nl_nosnap = 3;
        break;
    case 104:   /* DLT_C_HDLC */
        cs->off_linktype.constant_part = 2;
        cs->off_linkpl.constant_part = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;
    case 10:    /* DLT_FDDI */
        cs->off_linktype.constant_part = 13;
        cs->off_linkpl.constant_part = 13;
        cs->off_nl = 8;
        cs->off_nl_nosnap = 3;
        break;
    default:
        break;
    }
}

/* raw IP: check the version nibble */
static block *gen_ip_version(cstate *cs, u32 ver)
{
    return gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, ver << 4, 0xf0);
}

block *gen_snap(cstate *cs, u32 orgcode, u32 ptype)
{
    unsigned char snapblock[8];

    snapblock[0] = LLCSAP_SNAP;
    snapblock[1] = LLCSAP_SNAP;
    snapblock[2] = 0x03;
    snapblock[3] = (unsigned char)(orgcode >> 16);
    snapblock[4] = (unsigned char)(orgcode >> 8);
    snapblock[5] = (unsigned char)(orgcode);
    snapblock[6] = (unsigned char)(ptype >> 8);
    snapblock[7] = (unsigned char)(ptype);
    return gen_bcmp(cs, OR_LLC, 0, 8, snapblock);
}

/* 802.2 LLC header check, used where there is no type field */
block *gen_llc_linktype(cstate *cs, u32 ll_proto)
{
    switch (ll_proto) {
    case LLCSAP_IP:
    case LLCSAP_ISONS:
    case LLCSAP_NETBEUI:
        return gen_cmp(cs, OR_LLC, 0, BPF_H, (ll_proto << 8) | ll_proto);
    case LLCSAP_IPX:
        return gen_cmp(cs, OR_LLC, 0, BPF_B, LLCSAP_IPX);
    case ETHERTYPE_ATALK:
        return gen_snap(cs, 0x080007, ETHERTYPE_ATALK);
    default:
        if (ll_proto <= ETHERMTU)
            return gen_cmp(cs, OR_LLC, 0, BPF_B, ll_proto);
        return gen_cmp(cs, OR_LLC, 6, BPF_H, ll_proto);
    }
}

static block *gen_ether_linktype(cstate *cs, u32 ll_proto)
{
    block *b0, *b1, *b2;

    switch (ll_proto) {
    case LLCSAP_ISONS:
    case LLCSAP_IP:
    case LLCSAP_NETBEUI:
        b0 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
        gen_not(b0);
        b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_H, (ll_proto << 8) | ll_proto);
        gen_and(b0, b1);
        return b1;

    case LLCSAP_IPX:
        b0 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);
        b1 = gen_snap(cs, 0x000000, ETHERTYPE_IPX);
        gen_or(b0, b1);
        b0 = gen_cmp(cs, OR_LINKPL, 0, BPF_H, 0xffff);
        gen_or(b0, b1);
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ETHERTYPE_IPX);
        gen_or(b0, b1);
        return b1;

    case ETHERTYPE_ATALK:
    case ETHERTYPE_AARP:
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
        b1 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
        gen_not(b1);
        b2 = gen_snap(cs, ll_proto == ETHERTYPE_ATALK ? 0x080007 : 0x000000,
                      ll_proto);
        gen_and(b1, b2);
        gen_or(b0, b2);
        return b2;

    default:
        if (ll_proto <= ETHERMTU) {
            b0 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
            gen_not(b0);
            b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, ll_proto);
            gen_and(b0, b1);
            return b1;
        }
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
    }
}

static block *gen_linux_sll_linktype(cstate *cs, u32 ll_proto)
{
    block *b0, *b1;

    switch (ll_proto) {
    case LLCSAP_ISONS:
    case LLCSAP_IP:
    case LLCSAP_NETBEUI:
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
        b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_H, (ll_proto << 8) | ll_proto);
        gen_and(b0, b1);
        return b1;

    case LLCSAP_IPX:
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
        b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);
        gen_and(b0, b1);
        return b1;

    case ETHERTYPE_ATALK:
    case ETHERTYPE_AARP:
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
        b1 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
        {
            block *b2 = gen_snap(cs, ll_proto == ETHERTYPE_ATALK ? 0x080007 : 0x000000,
                                 ll_proto);
            gen_and(b1, b2);
            gen_or(b0, b2);
            return b2;
        }

    default:
        if (ll_proto <= ETHERMTU) {
            b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, ll_proto);
            gen_and(b0, b1);
            return b1;
        }
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
    }
}

static u32 swap32(u32 v)
{
    return ((v & 0xffu) << 24) | ((v & 0xff00u) << 8) |
           ((v >> 8) & 0xff00u) | ((v >> 24) & 0xffu);
}

static block *gen_loopback_linktype(cstate *cs, u32 ll_proto)
{
    switch (ll_proto) {
    case ETHERTYPE_IP:
        return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, swap32(2));
    case ETHERTYPE_IPV6:
        return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, swap32(10));
    default:
        return gen_false(cs);
    }
}

static block *gen_ppp_linktype(cstate *cs, u32 ll_proto)
{
    switch (ll_proto) {
    case ETHERTYPE_IP:   ll_proto = PPP_IP; break;
    case ETHERTYPE_IPV6: ll_proto = PPP_IPV6; break;
    case ETHERTYPE_DN:   ll_proto = PPP_DECNET; break;
    case ETHERTYPE_ATALK: ll_proto = PPP_APPLE; break;
    case ETHERTYPE_NS:   ll_proto = PPP_NS; break;
    case LLCSAP_ISONS:   ll_proto = PPP_OSI; break;
    case LLCSAP_8021D:   return gen_false(cs);
    case LLCSAP_IPX:     ll_proto = PPP_IPX; break;
    default:
        if (ll_proto <= ETHERMTU) return gen_false(cs);
        break;
    }
    return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
}

/* 802.11: is this a data frame? */
static block *gen_check_802_11_data_frame(cstate *cs)
{
    block *b0, *b1;
    sstmt *s;

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b0 = new_block(cs, JMPOP(BPF_JSET));
    b0->k = 0x08;
    b0->stmts = s;

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b1 = new_block(cs, JMPOP(BPF_JSET));
    b1->k = 0x04;
    b1->stmts = s;
    gen_not(b1);

    gen_and(b1, b0);
    return b0;
}

static block *gen_mpls_linktype(cstate *cs, u32 ll_proto)
{
    block *b0, *b1;

    switch (ll_proto) {
    case ETHERTYPE_IP:
        b0 = gen_mcmp(cs, OR_LINKPL, -2, BPF_B, 0x01, 0x01);
        b1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_B, 0x40, 0xf0);
        gen_and(b0, b1);
        return b1;
    case ETHERTYPE_IPV6:
        b0 = gen_mcmp(cs, OR_LINKPL, -2, BPF_B, 0x01, 0x01);
        b1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_B, 0x60, 0xf0);
        gen_and(b0, b1);
        return b1;
    default:
        return gen_false(cs);
    }
}

block *gen_linktype(cstate *cs, u32 ll_proto)
{
    block *b0, *b1;

    if (cs->label_stack_depth > 0)
        return gen_mpls_linktype(cs, ll_proto);

    switch (cs->linktype) {

    case 1:     /* DLT_EN10MB */
        return gen_ether_linktype(cs, ll_proto);

    case 113:   /* DLT_LINUX_SLL */
        return gen_linux_sll_linktype(cs, ll_proto);

    case 0:     /* DLT_NULL */
    case 108:   /* DLT_LOOP */
    case 109:
        return gen_loopback_linktype(cs, ll_proto);

    case 9:
    case 50:
    case 51:
    case 204:
        return gen_ppp_linktype(cs, ll_proto);

    case 12:    /* DLT_RAW */
    case 228:
    case 229:
        if (ll_proto == ETHERTYPE_IP)
            return gen_ip_version(cs, 4);
        if (ll_proto == ETHERTYPE_IPV6)
            return gen_ip_version(cs, 6);
        return gen_false(cs);

    case 105:   /* DLT_IEEE802_11 */
        b0 = gen_check_802_11_data_frame(cs);
        b1 = gen_llc_linktype(cs, ll_proto);
        gen_and(b0, b1);
        return b1;

    case 104:   /* DLT_C_HDLC */
        switch (ll_proto) {
        case ETHERTYPE_IP:
        case ETHERTYPE_IPV6:
        case ETHERTYPE_ARP:
        case ETHERTYPE_REVARP:
            return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
        default:
            return gen_false(cs);
        }

    case 10:    /* DLT_FDDI */
        return gen_llc_linktype(cs, ll_proto);

    default:
        bpf_err(cs, "unknown data link type %d", cs->linktype);
    }
    return NULL;
}
