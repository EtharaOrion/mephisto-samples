/*
 * gram.c - recursive-descent parser for the filter language.
 *
 * The accepted language matches the LALR grammar of the reference: equal
 * precedence and left associativity for "and"/"or", a prefix "not", qualifier
 * heads in front of address ids, and a separate arithmetic sub-language for
 * relational tests.
 */
#include <string.h>

#include "bpfc.h"
#include "tok.h"
#include "gen.h"

#define SYNTAX(cs) bpf_err((cs), "can't parse filter expression: syntax error")

typedef struct {
    const char *p;
    int         tok;
    u32         num;
    const char *str;
    size_t      len;
} lexsave;

static void save_lex(cstate *cs, lexsave *s)
{
    s->p = cs->lex_p; s->tok = cs->tok; s->num = cs->tok_num;
    s->str = cs->tok_str; s->len = cs->tok_len;
}
static void load_lex(cstate *cs, const lexsave *s)
{
    cs->lex_p = s->p; cs->tok = s->tok; cs->tok_num = s->num;
    cs->tok_str = s->str; cs->tok_len = s->len;
}

static block *p_expr(cstate *cs);
static block *p_arith_rel(cstate *cs);

static int pname_of(int tok)
{
    switch (tok) {
    case T_LINK: return P_LINK;
    case T_IP: return P_IP;
    case T_ARP: return P_ARP;
    case T_RARP: return P_RARP;
    case T_SCTP: return P_SCTP;
    case T_TCP: return P_TCP;
    case T_UDP: return P_UDP;
    case T_ICMP: return P_ICMP;
    case T_IGMP: return P_IGMP;
    case T_IGRP: return P_IGRP;
    case T_ATALK: return P_ATALK;
    case T_DECNET: return P_DECNET;
    case T_LAT: return P_LAT;
    case T_SCA: return P_SCA;
    case T_MOPRC: return P_MOPRC;
    case T_MOPDL: return P_MOPDL;
    case T_IPV6: return P_IPV6;
    case T_ICMPV6: return P_ICMPV6;
    case T_AH: return P_AH;
    case T_ESP: return P_ESP;
    case T_PIM: return P_PIM;
    case T_VRRP: return P_VRRP;
    case T_AARP: return P_AARP;
    case T_ISO: return P_ISO;
    case T_ESIS: return P_ESIS;
    case T_ISIS: return P_ISIS;
    case T_L1: return P_L1;
    case T_L2: return P_L2;
    case T_IIH: return P_IIH;
    case T_SNP: return P_SNP;
    case T_CSNP: return P_CSNP;
    case T_PSNP: return P_PSNP;
    case T_CLNP: return P_CLNP;
    case T_STP: return P_STP;
    case T_IPX: return P_IPX;
    case T_NETBEUI: return P_NETBEUI;
    case T_RADIO: return P_RADIO;
    case T_CARP: return P_CARP;
    default: return -1;
    }
}

/* ------------------------------------------------------------------ */
/* 802.11 type / subtype / direction names                            */
/* ------------------------------------------------------------------ */
typedef struct { int val; const char *name; } tokent;

static const tokent w_types[] = {
    { 0x00, "mgt" }, { 0x00, "management" },
    { 0x04, "ctl" }, { 0x04, "control" },
    { 0x08, "data" },
    { 0, NULL }
};
static const tokent w_sub_mgt[] = {
    { 0x00, "assoc-req" }, { 0x10, "assoc-resp" }, { 0x20, "reassoc-req" },
    { 0x30, "reassoc-resp" }, { 0x40, "probe-req" }, { 0x50, "probe-resp" },
    { 0x80, "beacon" }, { 0x90, "atim" }, { 0xa0, "disassoc" },
    { 0xb0, "auth" }, { 0xc0, "deauth" }, { 0, NULL }
};
static const tokent w_sub_ctl[] = {
    { 0x70, "bar" }, { 0x80, "ba" },
    { 0xa0, "ps-poll" }, { 0xb0, "rts" }, { 0xc0, "cts" }, { 0xd0, "ack" },
    { 0xe0, "cf-end" }, { 0xf0, "cf-end-ack" }, { 0, NULL }
};
static const tokent w_sub_data[] = {
    { 0x00, "data" }, { 0x10, "data-cf-ack" }, { 0x20, "data-cf-poll" },
    { 0x30, "data-cf-ack-poll" }, { 0x40, "null" }, { 0x50, "cf-ack" },
    { 0x60, "cf-poll" }, { 0x70, "cf-ack-poll" }, { 0x80, "qos-data" },
    { 0x90, "qos-data-cf-ack" }, { 0xa0, "qos-data-cf-poll" },
    { 0xb0, "qos-data-cf-ack-poll" }, { 0xc0, "qos" }, { 0xe0, "qos-cf-poll" },
    { 0xf0, "qos-cf-ack-poll" }, { 0, NULL }
};
static const tokent w_dirs[] = {
    { 0x00, "nods" }, { 0x01, "tods" }, { 0x02, "fromds" }, { 0x03, "dstods" },
    { 0, NULL }
};

static int tok2val(const tokent *t, const char *s, int *out)
{
    for (; t->name; t++)
        if (strcmp(t->name, s) == 0) { *out = t->val; return 1; }
    return 0;
}

/* ------------------------------------------------------------------ */
/* ids                                                                */
/* ------------------------------------------------------------------ */
static block *p_id(cstate *cs, qual q);

static block *p_nid(cstate *cs, qual q)
{
    const char *s = cs->tok_str;

    switch (cs->tok) {
    case T_NOT: {
        block *b;
        lex_next(cs);
        b = p_id(cs, q);
        gen_not(b);
        return b;
    }
    case T_ID:
        lex_next(cs);
        return gen_scode(cs, s, q);
    case T_HID:
        lex_next(cs);
        if (cs->tok == '/') {
            u32 n;
            lex_next(cs);
            if (cs->tok != T_NUM) SYNTAX(cs);
            n = cs->tok_num;
            lex_next(cs);
            return gen_mcode(cs, s, NULL, n, q);
        }
        if (cs->tok == T_NETMASK) {
            const char *s2;
            lex_next(cs);
            if (cs->tok != T_HID) SYNTAX(cs);
            s2 = cs->tok_str;
            lex_next(cs);
            return gen_mcode(cs, s, s2, 0, q);
        }
        if (q.addr == A_PORT) bpf_err(cs, "'port' modifier applied to ip host");
        if (q.addr == A_PORTRANGE) bpf_err(cs, "'portrange' modifier applied to ip host");
        if (q.addr == A_PROTO) bpf_err(cs, "'proto' modifier applied to ip host");
        if (q.addr == A_PROTOCHAIN) bpf_err(cs, "'protochain' modifier applied to ip host");
        return gen_ncode(cs, s, 0, q);
    case T_HID6:
        lex_next(cs);
        if (cs->tok == '/') {
            u32 n;
            lex_next(cs);
            if (cs->tok != T_NUM) SYNTAX(cs);
            n = cs->tok_num;
            lex_next(cs);
            return gen_mcode6(cs, s, n, q);
        }
        return gen_mcode6(cs, s, 128, q);
    case T_EID:
        lex_next(cs);
        return gen_ecode(cs, s, q);
    default:
        SYNTAX(cs);
    }
    return NULL;
}

/* pid: nid | qid and id | qid or id ; qid: pnum | pid */
static block *p_pid(cstate *cs, qual q)
{
    block *b;

    if (cs->tok == T_NUM) {
        u32 v = cs->tok_num;
        lex_next(cs);
        b = gen_ncode(cs, NULL, v, q);
    } else {
        b = p_nid(cs, q);
    }
    for (;;) {
        if (cs->tok == T_AND) {
            block *b2;
            lex_next(cs);
            b2 = p_id(cs, q);
            gen_and(b, b2);
            b = b2;
        } else if (cs->tok == T_OR) {
            block *b2;
            lex_next(cs);
            b2 = p_id(cs, q);
            gen_or(b, b2);
            b = b2;
        } else break;
    }
    return b;
}

/*
 * The qualified-identifier list is a third recursive cycle (p_id -> p_nid /
 * p_pid -> p_id), reached by "host not not ... x" and by parenthesised lists,
 * so it needs the same ceiling.  Every path through the cycle passes here.
 */
static block *p_id(cstate *cs, qual q)
{
    if (cs->tok == T_NUM) {
        u32 v = cs->tok_num;
        lex_next(cs);
        return gen_ncode(cs, NULL, v, q);
    }
    if (cs->tok == '(') {
        block *b;
        if (++cs->depth > MAX_PARSE_DEPTH) SYNTAX(cs);
        lex_next(cs);
        b = p_pid(cs, q);
        if (cs->tok != ')') SYNTAX(cs);
        lex_next(cs);
        cs->depth--;
        return b;
    }
    return p_nid(cs, q);
}

/* ------------------------------------------------------------------ */
/* arithmetic                                                         */
/* ------------------------------------------------------------------ */
static arth *p_arith(cstate *cs, int minprec);

static int arith_prec(int tok)
{
    switch (tok) {
    case '|': return 1;
    case '&': return 2;
    case '^': return 3;
    case T_LSH: case T_RSH: return 4;
    case '+': case '-': return 5;
    case '*': case '/': case '%': return 6;
    default: return 0;
    }
}

static arth *p_arith_atom_inner(cstate *cs);

static arth *p_arith_atom(cstate *cs)
{
    arth *a;

    /* the arithmetic sub-language recurses through parentheses and unary
     * minus, on its own path from the boolean grammar, so it needs the same
     * ceiling -- see MAX_PARSE_DEPTH */
    if (++cs->depth > MAX_PARSE_DEPTH) SYNTAX(cs);
    a = p_arith_atom_inner(cs);
    cs->depth--;
    return a;
}

static arth *p_arith_atom_inner(cstate *cs)
{
    int pn;

    if (cs->tok == '-') {
        arth *a;
        lex_next(cs);
        a = p_arith(cs, 7);
        return gen_neg(cs, a);
    }
    if (cs->tok == T_LEN) {
        lex_next(cs);
        return gen_loadlen(cs);
    }
    if (cs->tok == T_NUM) {
        u32 v = cs->tok_num;
        lex_next(cs);
        return gen_loadi(cs, v);
    }
    if (cs->tok == '(') {
        arth *a;
        if (++cs->depth > MAX_PARSE_DEPTH) SYNTAX(cs);
        lex_next(cs);
        a = p_arith(cs, 0);
        if (cs->tok != ')') SYNTAX(cs);
        lex_next(cs);
        cs->depth--;
        return a;
    }
    pn = pname_of(cs->tok);
    if (pn >= 0) {
        arth *idx;
        u32 size = 1;
        lex_next(cs);
        if (cs->tok != '[') SYNTAX(cs);
        lex_next(cs);
        idx = p_arith(cs, 0);
        if (cs->tok == ':') {
            lex_next(cs);
            if (cs->tok != T_NUM) SYNTAX(cs);
            size = cs->tok_num;
            lex_next(cs);
        }
        if (cs->tok != ']') SYNTAX(cs);
        lex_next(cs);
        return gen_load(cs, pn, idx, size);
    }
    SYNTAX(cs);
    return NULL;
}

static arth *p_arith(cstate *cs, int minprec)
{
    arth *a = p_arith_atom(cs);

    for (;;) {
        int p = arith_prec(cs->tok);
        int op, t;
        if (p == 0 || p < minprec) break;
        t = cs->tok;
        switch (t) {
        case '|': op = BPF_OR; break;
        case '&': op = BPF_AND; break;
        case '^': op = BPF_XOR; break;
        case T_LSH: op = BPF_LSH; break;
        case T_RSH: op = BPF_RSH; break;
        case '+': op = BPF_ADD; break;
        case '-': op = BPF_SUB; break;
        case '*': op = BPF_MUL; break;
        case '/': op = BPF_DIV; break;
        default:  op = BPF_MOD; break;
        }
        lex_next(cs);
        {
            arth *b = p_arith(cs, p + 1);
            a = gen_arth(cs, op, a, b);
        }
    }
    return a;
}

static block *p_arith_rel(cstate *cs)
{
    arth *a0, *a1;
    int code, reversed = 0;

    a0 = p_arith(cs, 0);
    switch (cs->tok) {
    case '>':   code = BPF_JGT; break;
    case T_GEQ: code = BPF_JGE; break;
    case '=':   code = BPF_JEQ; break;
    case T_LEQ: code = BPF_JGT; reversed = 1; break;
    case '<':   code = BPF_JGE; reversed = 1; break;
    case T_NEQ: code = BPF_JEQ; reversed = 1; break;
    default: SYNTAX(cs); return NULL;
    }
    lex_next(cs);
    a1 = p_arith(cs, 0);
    return gen_relation(cs, code, a0, a1, reversed);
}

/*
 * Decide whether a '(' starts a parenthesised boolean expression or an
 * arithmetic term: scan to the matching ')' and look at what follows.
 */
static int paren_is_arith(cstate *cs)
{
    lexsave sv;
    int depth = 0, res = 0;

    save_lex(cs, &sv);
    for (;;) {
        if (cs->tok == T_EOF) break;
        if (cs->tok == '(') depth++;
        else if (cs->tok == ')') {
            depth--;
            if (depth == 0) {
                lex_next(cs);
                switch (cs->tok) {
                case '>': case '<': case '=': case T_GEQ: case T_LEQ: case T_NEQ:
                case '|': case '&': case '^': case T_LSH: case T_RSH:
                case '+': case '-': case '*': case '/': case '%':
                    res = 1; break;
                default: res = 0; break;
                }
                break;
            }
        }
        lex_next(cs);
    }
    load_lex(cs, &sv);
    return res;
}

/* Is the current token the start of an arithmetic term? */
static int at_arith(cstate *cs)
{
    lexsave sv;
    int r = 0;

    if (cs->tok == T_LEN || cs->tok == '-' || cs->tok == T_NUM) return 1;
    if (cs->tok == '(') return paren_is_arith(cs);
    if (pname_of(cs->tok) >= 0) {
        save_lex(cs, &sv);
        lex_next(cs);
        r = (cs->tok == '[');
        load_lex(cs, &sv);
    }
    return r;
}

/* ------------------------------------------------------------------ */
/* other primitives                                                   */
/* ------------------------------------------------------------------ */
static block *p_p80211(cstate *cs)
{
    int type = 0, sub = 0;

    if (cs->tok == T_TYPE) {
        lex_next(cs);
        if (cs->tok == T_NUM) { type = (int)cs->tok_num << 2; lex_next(cs); }
        else if (cs->tok == T_ID) {
            if (!tok2val(w_types, cs->tok_str, &type))
                bpf_err(cs, "unknown 802.11 type name");
            lex_next(cs);
        } else { SYNTAX(cs); return NULL; }
        if (cs->tok == T_SUBTYPE) {
            const tokent *tbl;
            lex_next(cs);
            if (cs->tok == T_NUM) { sub = (int)cs->tok_num << 4; lex_next(cs); }
            else if (cs->tok == T_ID) {
                tbl = (type == 0x00) ? w_sub_mgt : (type == 0x04) ? w_sub_ctl : w_sub_data;
                if (!tok2val(tbl, cs->tok_str, &sub))
                    bpf_err(cs, "unknown 802.11 subtype name");
                lex_next(cs);
            } else { SYNTAX(cs); return NULL; }
            return gen_p80211_type(cs, type | sub, 0x0c | 0xf0);
        }
        return gen_p80211_type(cs, type, 0x0c);
    }
    if (cs->tok == T_SUBTYPE) {
        int v;
        lex_next(cs);
        if (cs->tok == T_NUM) {
            v = (int)cs->tok_num << 4;
            lex_next(cs);
            return gen_p80211_type(cs, v, 0xf0);
        }
        if (cs->tok != T_ID) { SYNTAX(cs); return NULL; }
        if (tok2val(w_sub_mgt, cs->tok_str, &v))       type = 0x00;
        else if (tok2val(w_sub_ctl, cs->tok_str, &v))  type = 0x04;
        else if (tok2val(w_sub_data, cs->tok_str, &v)) type = 0x08;
        else { bpf_err(cs, "unknown 802.11 type name"); return NULL; }
        lex_next(cs);
        return gen_p80211_type(cs, type | v, 0x0c | 0xf0);
    }
    /* DIR */
    lex_next(cs);
    if (cs->tok == T_NUM) { type = (int)cs->tok_num; lex_next(cs); }
    else if (cs->tok == T_ID) {
        if (!tok2val(w_dirs, cs->tok_str, &type))
            bpf_err(cs, "unknown 802.11 direction");
        lex_next(cs);
    } else { SYNTAX(cs); return NULL; }
    return gen_p80211_fcdir(cs, type);
}

static int is_dqual(int t)
{
    switch (t) {
    case T_SRC: case T_DST: case T_ADDR1: case T_ADDR2: case T_ADDR3:
    case T_ADDR4: case T_RA: case T_TA: return 1;
    default: return 0;
    }
}

static block *p_rterm(cstate *cs)
{
    qual q;
    int haspname = 0, hashead = 0;

    q.proto = P_DEFAULT; q.dir = D_DEFAULT; q.addr = A_DEFAULT;

    if (cs->tok == '(' && !at_arith(cs)) {
        block *b;
        if (++cs->depth > MAX_PARSE_DEPTH) SYNTAX(cs);
        lex_next(cs);
        b = p_expr(cs);
        if (cs->tok != ')') SYNTAX(cs);
        lex_next(cs);
        cs->depth--;
        return b;
    }
    if (at_arith(cs)) return p_arith_rel(cs);

    {
        int pn = pname_of(cs->tok);
        if (pn >= 0) { q.proto = pn; haspname = 1; lex_next(cs); }
    }

    /* dqual */
    if (is_dqual(cs->tok)) {
        int t = cs->tok;
        lexsave sv;
        hashead = 1;
        if (t == T_SRC || t == T_DST) {
            save_lex(cs, &sv);
            lex_next(cs);
            if (cs->tok == T_AND || cs->tok == T_OR) {
                int conj = cs->tok;
                lex_next(cs);
                if ((t == T_SRC && cs->tok == T_DST) || (t == T_DST && cs->tok == T_SRC)) {
                    q.dir = (conj == T_AND) ? D_AND : D_OR;
                    lex_next(cs);
                } else {
                    load_lex(cs, &sv);
                    q.dir = (t == T_SRC) ? D_SRC : D_DST;
                    lex_next(cs);
                }
            } else {
                q.dir = (t == T_SRC) ? D_SRC : D_DST;
            }
        } else {
            switch (t) {
            case T_ADDR1: q.dir = D_ADDR1; break;
            case T_ADDR2: q.dir = D_ADDR2; break;
            case T_ADDR3: q.dir = D_ADDR3; break;
            case T_ADDR4: q.dir = D_ADDR4; break;
            case T_RA:    q.dir = D_RA; break;
            default:      q.dir = D_TA; break;
            }
            lex_next(cs);
        }
    }

    /* aqual / proto / protochain / gateway */
    switch (cs->tok) {
    case T_HOST:       q.addr = A_HOST;       hashead = 1; lex_next(cs); break;
    case T_NET:        q.addr = A_NET;        hashead = 1; lex_next(cs); break;
    case T_PORT:       q.addr = A_PORT;       hashead = 1; lex_next(cs); break;
    case T_PORTRANGE:  q.addr = A_PORTRANGE;  hashead = 1; lex_next(cs); break;
    case T_PROTO:      q.addr = A_PROTO;      hashead = 1; lex_next(cs); break;
    case T_PROTOCHAIN: q.addr = A_PROTOCHAIN; hashead = 1; lex_next(cs); break;
    case T_GATEWAY:    q.addr = A_GATEWAY;    hashead = 1; lex_next(cs); break;
    default: break;
    }

    if (hashead) return p_id(cs, q);

    switch (cs->tok) {
    case T_BROADCAST: lex_next(cs); return gen_broadcast(cs, q.proto);
    case T_MULTICAST: lex_next(cs); return gen_multicast(cs, q.proto);
    case T_TYPE: case T_SUBTYPE: case T_DIR: return p_p80211(cs);
    default: break;
    }

    if (haspname) return gen_proto_abbrev(cs, q.proto);

    switch (cs->tok) {
    case T_LESS: {
        u32 v;
        lex_next(cs);
        if (cs->tok != T_NUM) SYNTAX(cs);
        v = cs->tok_num;
        lex_next(cs);
        return gen_less(cs, (int)v);
    }
    case T_GREATER: {
        u32 v;
        lex_next(cs);
        if (cs->tok != T_NUM) SYNTAX(cs);
        v = cs->tok_num;
        lex_next(cs);
        return gen_greater(cs, (int)v);
    }
    case T_CBYTE: {
        u32 idx, val;
        int op;
        lex_next(cs);
        if (cs->tok != T_NUM) SYNTAX(cs);
        idx = cs->tok_num;
        lex_next(cs);
        switch (cs->tok) {
        case '>':   op = BPF_JGT; break;
        case T_GEQ: op = BPF_JGE; break;
        case '=':   op = BPF_JEQ; break;
        default: SYNTAX(cs); return NULL;
        }
        lex_next(cs);
        if (cs->tok != T_NUM) SYNTAX(cs);
        val = cs->tok_num;
        lex_next(cs);
        return gen_byteop(cs, op, (int)idx, (int)val);
    }
    case T_INBOUND:  lex_next(cs); return gen_inbound(cs, 0);
    case T_OUTBOUND: lex_next(cs); return gen_inbound(cs, 1);
    case T_IFINDEX: {
        u32 v;
        lex_next(cs);
        if (cs->tok != T_NUM) SYNTAX(cs);
        v = cs->tok_num;
        lex_next(cs);
        return gen_ifindex(cs, (int)v);
    }
    case T_VLAN: {
        lex_next(cs);
        if (cs->tok == T_NUM) { u32 v = cs->tok_num; lex_next(cs); return gen_vlan(cs, v, 1); }
        return gen_vlan(cs, 0, 0);
    }
    case T_MPLS: {
        lex_next(cs);
        if (cs->tok == T_NUM) { u32 v = cs->tok_num; lex_next(cs); return gen_mpls(cs, v, 1); }
        return gen_mpls(cs, 0, 0);
    }
    case T_PPPOED: lex_next(cs); return gen_pppoed(cs);
    case T_PPPOES: {
        lex_next(cs);
        if (cs->tok == T_NUM) { u32 v = cs->tok_num; lex_next(cs); return gen_pppoes(cs, v, 1); }
        return gen_pppoes(cs, 0, 0);
    }
    case T_GENEVE: {
        lex_next(cs);
        if (cs->tok == T_NUM) { u32 v = cs->tok_num; lex_next(cs); return gen_geneve(cs, v, 1); }
        return gen_geneve(cs, 0, 0);
    }
    default:
        SYNTAX(cs);
    }
    return NULL;
}

static block *p_term(cstate *cs)
{
    if (cs->tok == T_NOT) {
        block *b;
        lex_next(cs);
        b = p_term(cs);
        gen_not(b);
        return b;
    }
    return p_rterm(cs);
}

static block *p_expr(cstate *cs)
{
    block *b = p_term(cs);

    for (;;) {
        if (cs->tok == T_AND) {
            block *b2;
            lex_next(cs);
            b2 = p_term(cs);
            gen_and(b, b2);
            b = b2;
        } else if (cs->tok == T_OR) {
            block *b2;
            lex_next(cs);
            b2 = p_term(cs);
            gen_or(b, b2);
            b = b2;
        } else break;
    }
    return b;
}

block *parse_filter(cstate *cs, const char *text)
{
    block *b;

    lex_init(cs, text);
    lex_next(cs);
    if (cs->tok == T_EOF) return NULL;
    b = p_expr(cs);
    if (cs->tok != T_EOF) SYNTAX(cs);
    return b;
}
