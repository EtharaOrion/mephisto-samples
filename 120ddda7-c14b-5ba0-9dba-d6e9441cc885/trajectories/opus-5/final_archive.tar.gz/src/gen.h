/* gen.h - block-graph generation entry points used by the parser. */
#ifndef GEN_H
#define GEN_H

#include "bpfc.h"

void gen_and(block *b0, block *b1);
void gen_or(block *b0, block *b1);
void gen_not(block *b);

block *gen_scode(cstate *cs, const char *name, qual q);
block *gen_mcode(cstate *cs, const char *a1, const char *a2, u32 masklen, qual q);
block *gen_mcode6(cstate *cs, const char *a1, u32 masklen, qual q);
block *gen_ncode(cstate *cs, const char *s, u32 v, qual q);
block *gen_ecode(cstate *cs, const char *s, qual q);
block *gen_acode(cstate *cs, const char *s, qual q);
block *gen_proto_abbrev(cstate *cs, int proto);
block *gen_relation(cstate *cs, int code, arth *a0, arth *a1, int reversed);
arth  *gen_loadi(cstate *cs, u32 val);
arth  *gen_load(cstate *cs, int proto, arth *inst, u32 size);
arth  *gen_loadlen(cstate *cs);
arth  *gen_neg(cstate *cs, arth *a);
arth  *gen_arth(cstate *cs, int code, arth *a0, arth *a1);
block *gen_less(cstate *cs, int n);
block *gen_greater(cstate *cs, int n);
block *gen_byteop(cstate *cs, int op, int idx, int val);
block *gen_broadcast(cstate *cs, int proto);
block *gen_multicast(cstate *cs, int proto);
block *gen_inbound(cstate *cs, int dir);
block *gen_ifindex(cstate *cs, int idx);
block *gen_vlan(cstate *cs, u32 num, int has_num);
block *gen_mpls(cstate *cs, u32 num, int has_num);
block *gen_pppoed(cstate *cs);
block *gen_pppoes(cstate *cs, u32 num, int has_num);
block *gen_geneve(cstate *cs, u32 num, int has_num);
block *gen_p80211_type(cstate *cs, int type, int mask);
block *gen_p80211_fcdir(cstate *cs, int dir);

#endif
