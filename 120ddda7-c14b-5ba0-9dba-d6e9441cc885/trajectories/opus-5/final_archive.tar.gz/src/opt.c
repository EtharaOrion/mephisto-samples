/*
 * opt.c - flow-graph shrinker.
 *
 * Repeatedly: rank the nodes by depth, work out which node dominates which,
 * value-number every step in every node, fold what can be folded, drop what is
 * dead, then re-point edges whose test outcome is already known.  Finally
 * identical nodes are fused and the entry node is simplified.
 */
#include <string.h>
#include <stdlib.h>

#include "bpfc.h"
#include "proto.h"
#include <time.h>
extern double g_t[8];
static double nsec(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec*1e9+ts.tv_nsec;}
#include <time.h>

extern double g_t[8];
static double nsec(void){struct timespec ts;clock_gettime(CLOCK_MONOTONIC,&ts);return ts.tv_sec*1e9+ts.tv_nsec;}
#include <time.h>

#define NOP (-1)
#define WBITS 64
#define HASHSZ 1024
#define HASHMASK (HASHSZ - 1)

typedef struct vnode {
    int           code;
    u32           a, b;
    u32           num;
    struct vnode *next;
} vnode;

typedef struct {
    u32 fixed;
    int known;
} vslot;

typedef struct {
    cstate *cs;
    int     changed;
    int     touched;
    int     shape_changed;
    int     nnodes;
    int     nsteps;
    block **nodes;
    int     nedges;
    edge  **edges;
    int     nwords, ewords;
    uint64_t *bits;
    block **rank;
    block **order_desc;    /* nodes, deepest level first */
    block **order_asc;     /* nodes, leaves first */
    int     nleaf;         /* how many of order_asc are leaves */
    int     nnodes_live;
    int     maxrank;
    vnode  *vpool;
    int     vused;
    int     vmax;
    vnode  *htab[HASHSZ];
    int     hused[HASHSZ];
    int     nhused;
    vslot  *vals;
    int     vcap;
    u32     memmask;           /* scratch slots this filter can ever write */
    int     n_post;            /* nodes recorded by count_r, in finishing order */
    int     ranks_ready;       /* those levels and that order are still current */
    u32    *e_aval;            /* per edge: val[A_ATOM] of its predecessor */
    struct eattr { int code; u32 oval; } *e_attr;
    int     e_cap;
    u32     nextval;
    int     epoch;
    int     rank_epoch;   /* epoch of the walk that built the level lists */
} shrink;

#define BSET(p, i)   ((p)[(unsigned)(i) / WBITS] |= (uint64_t)1 << ((unsigned)(i) % WBITS))

static void bs_and(uint64_t *a, const uint64_t *b, int n) { while (n--) *a++ &= *b++; }

/* intersect one mask into two sets at once: the sets always come in pairs */
static void bs_and2(uint64_t *a, uint64_t *b, const uint64_t *m, int n)
{
    /* graphs small enough for a single word are by far the common case */
    if (n == 1) { uint64_t v = *m; *a &= v; *b &= v; return; }
    while (n--) { uint64_t v = *m++; *a++ &= v; *b++ &= v; }
}
static void bs_or(u32 *a, const u32 *b, int n)  { while (n--) *a++ |= *b++; }

#define AX_ATOM N_ATOMS

static inline int step_reads(int code, u32 k)
{
    switch (BPF_CLASS(code)) {
    case BPF_RET:
        return (code & 0x18) == 0x10 ? A_ATOM : -1;
    case BPF_LD:
    case BPF_LDX:
        return (BPF_MODE(code) == BPF_IND) ? X_ATOM :
               (BPF_MODE(code) == BPF_MEM) ? (int)k : -1;
    case BPF_ST:
        return A_ATOM;
    case BPF_STX:
        return X_ATOM;
    case BPF_JMP:
        return (BPF_OP(code) == BPF_JA) ? -1 :
               (BPF_SRC(code) == BPF_X) ? AX_ATOM : A_ATOM;
    case BPF_ALU:
        if (BPF_OP(code) == BPF_NEG) return A_ATOM;
        return (BPF_SRC(code) == BPF_X) ? AX_ATOM : A_ATOM;
    case BPF_MISC:
        return (code & 0xf8) == BPF_TXA ? X_ATOM : A_ATOM;
    }
    return -1;
}

/* read and written atom of one step, in a single dispatch */
static inline void step_atoms(int code, u32 k, int *rd, int *wr)
{
    switch (BPF_CLASS(code)) {
    case BPF_LD:
        *rd = (BPF_MODE(code) == BPF_IND) ? X_ATOM :
              (BPF_MODE(code) == BPF_MEM) ? (int)k : -1;
        *wr = A_ATOM;
        return;
    case BPF_LDX:
        *rd = (BPF_MODE(code) == BPF_IND) ? X_ATOM :
              (BPF_MODE(code) == BPF_MEM) ? (int)k : -1;
        *wr = X_ATOM;
        return;
    case BPF_ST:
        *rd = A_ATOM;
        *wr = (int)k;
        return;
    case BPF_STX:
        *rd = X_ATOM;
        *wr = (int)k;
        return;
    case BPF_ALU:
        *rd = (BPF_OP(code) == BPF_NEG) ? A_ATOM :
              (BPF_SRC(code) == BPF_X) ? AX_ATOM : A_ATOM;
        *wr = A_ATOM;
        return;
    case BPF_MISC:
        if ((code & 0xf8) == BPF_TXA) { *rd = X_ATOM; *wr = A_ATOM; }
        else { *rd = A_ATOM; *wr = X_ATOM; }
        return;
    case BPF_JMP:
        *rd = (BPF_OP(code) == BPF_JA) ? -1 :
              (BPF_SRC(code) == BPF_X) ? AX_ATOM : A_ATOM;
        *wr = -1;
        return;
    default:
        *rd = ((code & 0x18) == 0x10) ? A_ATOM : -1;
        *wr = -1;
        return;
    }
}

static int step_writes(int code, u32 k)
{
    switch (BPF_CLASS(code)) {
    case BPF_LD:  return A_ATOM;
    case BPF_LDX: return X_ATOM;
    case BPF_ST:  return (int)k;
    case BPF_STX: return (int)k;
    case BPF_ALU: return A_ATOM;
    case BPF_MISC: return (code & 0xf8) == BPF_TXA ? A_ATOM : X_ATOM;
    }
    return -1;
}

/* ------------------------------------------------------------------ */
/* value numbering                                                    */
/* ------------------------------------------------------------------ */
static void vn_reset(shrink *o)
{
    int i;
    for (i = 0; i < o->nhused; i++) o->htab[o->hused[i]] = NULL;
    o->nhused = 0;
    o->vused = 0;
    o->nextval = 0;
    /* value 0 is the "nothing known about this atom" number; numbering starts
     * at 1, so nobody ever fills this entry in and it has to be stated here */
    o->vals[0].known = 0;
    o->vals[0].fixed = 0;
}

static u32 vn(shrink *o, int code, u32 a, u32 b)
{
    unsigned h = (unsigned)(((u32)code * 2654435761u + a * 40503u +
                             b * 2246822519u) >> 13) & HASHMASK;
    vnode *p;
    u32 v;

    for (p = o->htab[h]; p; p = p->next)
        if (p->code == code && p->a == a && p->b == b) return p->num;

    { extern long g_maxv; if (o->vused > g_maxv) g_maxv = o->vused; }
    { extern long g_full; if (o->vused >= o->vmax - 1) { g_full++; return 0; } }
    v = ++o->nextval;
    o->vals[v].known = 0;
    o->vals[v].fixed = 0;
    if (BPF_MODE(code) == BPF_IMM &&
        (BPF_CLASS(code) == BPF_LD || BPF_CLASS(code) == BPF_LDX)) {
        o->vals[v].fixed = a;
        o->vals[v].known = 1;
    }
    p = &o->vpool[o->vused++];
    p->code = code; p->a = a; p->b = b; p->num = v;
    if (o->htab[h] == NULL) o->hused[o->nhused++] = (int)h;
    p->next = o->htab[h];
    o->htab[h] = p;
    return v;
}

/* value of a step that depends only on its own opcode and operand; numbers
 * live for the whole compile, so one lookup per step is enough */
static u32 vn_pure(shrink *o, sstmt *s)
{
    if (!s->vc_ok) {
        s->vc = vn(o, s->code, s->k, 0);
        s->vc_ok = 1;
    }
    return s->vc;
}

static u32 vn_const(shrink *o, u32 k)
{
    return vn(o, BPF_LD | BPF_IMM, k, 0);
}

static void fold_alu(shrink *o, sstmt *s, u32 v0, u32 v1)
{
    u32 a = o->vals[v0].fixed, b = o->vals[v1].fixed;

    switch (BPF_OP(s->code)) {
    case BPF_ADD: a += b; break;
    case BPF_SUB: a -= b; break;
    case BPF_MUL: a *= b; break;
    case BPF_DIV:
        if (b == 0) bpf_err(o->cs, "division by zero");
        a /= b; break;
    case BPF_MOD:
        if (b == 0) bpf_err(o->cs, "modulus by zero");
        a %= b; break;
    case BPF_AND: a &= b; break;
    case BPF_OR:  a |= b; break;
    case BPF_XOR: a ^= b; break;
    case BPF_LSH: if (b > 31) a = 0; else a <<= b; break;
    case BPF_RSH: if (b > 31) a = 0; else a >>= b; break;
    default: return;
    }
    s->k = a;
    s->code = BPF_LD | BPF_IMM;
    s->vgen = 0;
    o->changed = 1;
    o->touched = 1;
}

/* record a new value for an atom; a step that recomputes what is already
 * there is dropped */
static void put_val(shrink *o, sstmt *s, u32 *slot, u32 nv, int alter)
{
    if (alter && nv != 0 && *slot == nv) {
        s->code = NOP;
        o->changed = 1; g_c[0]++;
    } else {
        *slot = nv;
    }
}

__attribute__((noinline))
static void run_step(shrink *o, sstmt *s, u32 *val, const int alter)
{
    int op;
    u32 v;

    switch (s->code) {

    case BPF_LD | BPF_ABS | BPF_W:
    case BPF_LD | BPF_ABS | BPF_H:
    case BPF_LD | BPF_ABS | BPF_B:
        val[A_ATOM] = vn(o, s->code, s->k, 0);
        return;

    case BPF_LD | BPF_IND | BPF_W:
    case BPF_LD | BPF_IND | BPF_H:
    case BPF_LD | BPF_IND | BPF_B:
        v = val[X_ATOM];
        if (alter && o->vals[v].known) {
            s->code = BPF_LD | BPF_ABS | BPF_SIZE(s->code);
            s->vgen = 0;
            s->k += o->vals[v].fixed;
            v = vn(o, s->code, s->k, 0);
            o->changed = 1;
            o->touched = 1;
        } else {
            v = vn(o, s->code, s->k, v);
        }
        val[A_ATOM] = v;
        return;

    case BPF_LD | BPF_LEN:
        val[A_ATOM] = vn(o, s->code, 0, 0);
        return;

    case BPF_LDX | BPF_LEN:
        val[X_ATOM] = vn(o, s->code, 0, 0);
        return;

    case BPF_LD | BPF_IMM:
        val[A_ATOM] = vn_const(o, s->k);
        return;

    case BPF_LDX | BPF_IMM:
        val[X_ATOM] = vn_const(o, s->k);
        return;

    case BPF_LDX | BPF_MSH | BPF_B:
        val[X_ATOM] = vn(o, s->code, s->k, 0);
        return;

    case BPF_ALU | BPF_NEG:
        if (alter && o->vals[val[A_ATOM]].known) {
            s->code = BPF_LD | BPF_IMM;
            s->k = (u32)(-(int32_t)o->vals[val[A_ATOM]].fixed);
            val[A_ATOM] = vn_const(o, s->k);
            o->changed = 1;
            o->touched = 1;
        } else {
            val[A_ATOM] = vn(o, s->code, val[A_ATOM], 0);
        }
        return;

    case BPF_LD | BPF_MEM:
        v = val[s->k];
        if (alter && o->vals[v].known) {
            s->code = BPF_LD | BPF_IMM;
            s->k = o->vals[v].fixed;
            o->changed = 1;
            o->touched = 1;
        }
        val[A_ATOM] = v;
        return;

    case BPF_LDX | BPF_MEM:
        v = val[s->k];
        if (alter && o->vals[v].known) {
            s->code = BPF_LDX | BPF_IMM;
            s->k = o->vals[v].fixed;
            o->changed = 1;
            o->touched = 1;
        }
        val[X_ATOM] = v;
        return;

    case BPF_ST:
        val[s->k] = val[A_ATOM];
        return;

    case BPF_STX:
        val[s->k] = val[X_ATOM];
        return;

    case BPF_MISC | BPF_TAX:
        val[X_ATOM] = val[A_ATOM];
        return;

    case BPF_MISC | BPF_TXA:
        val[A_ATOM] = val[X_ATOM];
        return;

    default:
        break;
    }

    if (BPF_CLASS(s->code) != BPF_ALU) return;

    op = BPF_OP(s->code);
    if (BPF_SRC(s->code) == BPF_K) {
        if (alter) {
            if (s->k == 0) {
                if (op == BPF_ADD || op == BPF_SUB || op == BPF_OR ||
                    op == BPF_XOR || op == BPF_LSH || op == BPF_RSH) {
                    s->code = NOP;
                    o->changed = 1;
                    o->touched = 1;
                    return;
                }
                if (op == BPF_MUL || op == BPF_AND) {
                    s->code = BPF_LD | BPF_IMM;
                    s->k = 0;
                    val[A_ATOM] = vn_const(o, 0);
                    o->changed = 1;
                    o->touched = 1;
                    return;
                }
            }
            if (o->vals[val[A_ATOM]].known) {
                fold_alu(o, s, val[A_ATOM], vn_const(o, s->k));
                val[A_ATOM] = vn_const(o, s->k);
                return;
            }
        }
        val[A_ATOM] = vn(o, s->code, val[A_ATOM], vn_const(o, s->k));
        return;
    }

    if (alter && o->vals[val[X_ATOM]].known) {
        if (o->vals[val[A_ATOM]].known) {
            fold_alu(o, s, val[A_ATOM], val[X_ATOM]);
            val[A_ATOM] = vn_const(o, s->k);
        } else {
            s->code = BPF_ALU | BPF_K | op;
            s->k = o->vals[val[X_ATOM]].fixed;
            o->changed = 1;
            o->touched = 1;
            val[A_ATOM] = vn(o, s->code, val[A_ATOM], vn_const(o, s->k));
        }
        return;
    }
    val[A_ATOM] = vn(o, s->code, val[A_ATOM], val[X_ATOM]);
}

/* ------------------------------------------------------------------ */
/* graph walks                                                        */
/* ------------------------------------------------------------------ */
static void epoch_next(shrink *o) { o->epoch++; }
static int  visited(shrink *o, block *b) { return b->mark == o->epoch; }
static void visit(shrink *o, block *b) { b->mark = o->epoch; }

/* pre-order walk over the reachable nodes, done with an explicit stack */
static block **walk_stack;
static int walk_cap;

static void walk_room(int n)
{
    if (n <= walk_cap) return;
    walk_cap = n + 64;
    walk_stack = realloc(walk_stack, (size_t)walk_cap * sizeof(block *));
    if (walk_stack == NULL) abort();
}

static void number_r(shrink *o, block *p)
{
    int sp = 0;

    walk_room(o->nnodes + 4);
    if (p == NULL || visited(o, p)) return;
    visit(o, p);
    walk_stack[sp++] = p;
    while (sp > 0) {
        block *b = walk_stack[--sp];
        b->id = o->nnodes;
        o->nodes[o->nnodes++] = b;
        if (JF(b) && !visited(o, JF(b))) { visit(o, JF(b)); walk_stack[sp++] = JF(b); }
        if (JT(b) && !visited(o, JT(b))) { visit(o, JT(b)); walk_stack[sp++] = JT(b); }
    }
}

/* both predecessors of a block reach it, so roughly half of the recursive
 * calls in these walks are for a block that has already been seen */
#define WALK(fn, o, b) do { if ((b) != NULL && !visited(o, b)) fn(o, b); } while (0)

static void rank_r(shrink *o, block *p)
{
    int level;

    visit(o, p);
    /* Reset here rather than in find_flow_sets: that walk links a node into
     * its successors' lists, so every list has to be empty before it starts.
     * The two always run together, ranking first. */
    p->in_edges = NULL;
    if (JT(p)) {
        WALK(rank_r, o, JT(p));
        WALK(rank_r, o, JF(p));
        level = (JT(p)->level > JF(p)->level ? JT(p)->level : JF(p)->level) + 1;
    } else {
        level = 0;
    }
    p->level = level;
    p->link = o->rank[level];
    o->rank[level] = p;
}

static void find_ranks(shrink *o, block *root)
{
    int i, n = 0;
    block *p;

    memset(o->rank, 0, (size_t)(o->nnodes + 1) * sizeof(block *));
    epoch_next(o);
    o->rank_epoch = o->epoch;
    rank_r(o, root);
    o->maxrank = root->level;

    /* flatten the level lists once, so the per-round walks run over an array */
    for (i = o->maxrank; i >= 0; --i)
        for (p = o->rank[i]; p; p = p->link)
            o->order_desc[n++] = p;
    o->nnodes_live = n;
    n = 0;
    for (p = o->rank[0]; p; p = p->link) o->order_asc[n++] = p;
    o->nleaf = n;
    for (i = 1; i <= o->maxrank; ++i)
        for (p = o->rank[i]; p; p = p->link)
            o->order_asc[n++] = p;
}

static void find_flow_sets(shrink *o, block *root)
{
    int i;
    block *b;

    memset(o->bits, 0xff, (size_t)o->nnodes * o->nwords * sizeof(uint64_t));
    for (i = 0; i < o->nnodes; i++) o->nodes[i]->dom = &o->bits[i * o->nwords];
    memset(root->dom, 0, (size_t)o->nwords * sizeof(uint64_t));

    for (i = o->maxrank; i >= 0; --i) {
        for (b = o->rank[i]; b; b = b->link) {
            BSET(b->dom, b->id);
            b->in_edges = NULL;   /* reset here; find_inedges only links */
            if (JT(b) == NULL) continue;
            if (JT(b) == JF(b)) bs_and(JT(b)->dom, b->dom, o->nwords);
            else bs_and2(JT(b)->dom, JF(b)->dom, b->dom, o->nwords);
        }
    }
}

static void find_edoms(shrink *o, block *root)
{
    int i;
    uint64_t *sp = o->bits + (size_t)o->nnodes * o->nwords;
    block *b;

    memset(sp, 0xff, (size_t)o->nedges * o->ewords * sizeof(uint64_t));
    if ((o->nedges & (WBITS - 1)) != 0) {
        /* clear the padding bits of the last word once, so every later
         * intersection keeps them clear and the scan below can iterate the
         * whole word without a bound check */
        uint64_t tail = ((uint64_t)1 << (o->nedges & (WBITS - 1))) - 1;
        for (i = 0; i < o->nedges; i++) sp[(size_t)i * o->ewords + o->ewords - 1] = tail;
    }
    for (i = 0; i < o->nedges; i++) o->edges[i]->edom = sp + (size_t)i * o->ewords;
    memset(root->et.edom, 0, (size_t)o->ewords * sizeof(uint64_t));
    memset(root->ef.edom, 0, (size_t)o->ewords * sizeof(uint64_t));

    for (i = o->maxrank; i >= 0; --i) {
        for (b = o->rank[i]; b; b = b->link) {
            if (JT(b) == NULL) continue;
            BSET(b->et.edom, ET_ID(b));
            BSET(b->ef.edom, EF_ID(b));
            bs_and2(JT(b)->et.edom, JT(b)->ef.edom, b->et.edom, o->ewords);
            bs_and2(JF(b)->et.edom, JF(b)->ef.edom, b->ef.edom, o->ewords);
        }
    }
}

static void find_closure_unused(shrink *o, block *root)
{
    int i;
    block *b;
    u32 *sp = o->bits + (size_t)o->nnodes * o->nwords + (size_t)o->nedges * o->ewords;

    memset(sp, 0, (size_t)o->nnodes * o->nwords * sizeof(u32));
    for (i = 0; i < o->nnodes; i++) o->nodes[i]->closure = sp + (size_t)i * o->nwords;
    (void)root;
    for (i = o->maxrank; i >= 0; --i) {
        for (b = o->rank[i]; b; b = b->link) {
            BSET(b->closure, b->id);
            if (JT(b) == NULL) continue;
            bs_or(JT(b)->closure, b->closure, o->nwords);
            bs_or(JF(b)->closure, b->closure, o->nwords);
        }
    }
}

static void local_ud(block *b)
{
    sstmt *s;
    u32 def = 0, use = 0, kill = 0;
    int atom;

    for (s = b->steps; s; s = s->next) {
        int wr;
        if (s->code == NOP) continue;
        step_atoms(s->code, s->k, &atom, &wr);
        if (atom >= 0) {
            if (atom == AX_ATOM) {
                if (!(def & ((u32)1 << X_ATOM))) use |= (u32)1 << X_ATOM;
                if (!(def & ((u32)1 << A_ATOM))) use |= (u32)1 << A_ATOM;
            } else if (!(def & ((u32)1 << atom))) {
                use |= (u32)1 << atom;
            }
        }
        atom = wr;
        if (atom >= 0) {
            if (!(use & ((u32)1 << atom))) kill |= (u32)1 << atom;
            def |= (u32)1 << atom;
        }
    }
    atom = step_reads(b->code, b->k);
    if (atom >= 0) {
        if (atom == AX_ATOM) {
            if (!(def & ((u32)1 << X_ATOM))) use |= (u32)1 << X_ATOM;
            if (!(def & ((u32)1 << A_ATOM))) use |= (u32)1 << A_ATOM;
        } else if (!(def & ((u32)1 << atom))) {
            use |= (u32)1 << atom;
        }
    }
    b->base_use = (int)use;
    b->in_use = (int)use;
    b->kill = (int)kill;
}

static void find_live_atoms(shrink *o, block *root)
{
    int i;
    block *p;

    (void)root;
    for (i = 0; i <= o->maxrank; ++i)
        for (p = o->rank[i]; p; p = p->link) {
            if (p->steps_dirty) { local_ud(p); p->steps_dirty = 0; }
            p->out_use = 0;
            p->in_use = p->base_use;
        }
    for (i = 1; i <= o->maxrank; ++i)
        for (p = o->rank[i]; p; p = p->link) {
            if (JT(p) == NULL) continue;
            p->out_use |= JT(p)->in_use | JF(p)->in_use;
            p->in_use |= p->out_use & ~p->kill;
        }
}

static void find_inedges(shrink *o, block *root)
{
    int i;
    block *b;

    for (i = o->maxrank; i >= 0; --i) {
        for (b = o->rank[i]; b; b = b->link) {
            if (JT(b) == NULL) continue;
            b->et.next = JT(b)->in_edges;
            JT(b)->in_edges = &b->et;
            b->ef.next = JF(b)->in_edges;
            JF(b)->in_edges = &b->ef;
        }
    }
    (void)root;
}

/* ------------------------------------------------------------------ */
/* per node work                                                      */
/* ------------------------------------------------------------------ */
static sstmt *live_step(sstmt *s)
{
    while (s != NULL && s->code == NOP) s = s->next;
    return s;
}

static inline void peep(shrink *o, block *b)
{
    sstmt *s, *next, *last;

    s = b->steps;
    if (s == NULL) return;

    for (;;) {
        s = live_step(s);
        if (s == NULL) break;
        next = live_step(s->next);
        if (next == NULL) break;

        if (s->code == BPF_ST && next->code == (BPF_LDX | BPF_MEM) &&
            s->k == next->k) {
            o->changed = 1;
            o->touched = 1;
            next->code = BPF_MISC | BPF_TAX;
        }
        if (s->code == (BPF_LD | BPF_IMM) && next->code == (BPF_MISC | BPF_TAX)) {
            s->code = BPF_LDX | BPF_IMM;
            s->vgen = 0;
            next->code = BPF_MISC | BPF_TXA;
            o->changed = 1;
            o->touched = 1;
        }
        /*
         * ld #k ; ldxb 4*([j]&0xf) ; add x ; tax ; ld [x+m]
         *   ->  ldxb 4*([j]&0xf) ; ld [x+m+k]
         */
        if (s->code == (BPF_LD | BPF_IMM) && !(b->out_use & (1 << X_ATOM))) {
            sstmt *add, *tax, *ild;
            if ((add = (next->code == (BPF_LDX | BPF_MSH | BPF_B)) ?
                       live_step(next->next) : next) != NULL &&
                add->code == (BPF_ALU | BPF_ADD | BPF_X) &&
                (tax = live_step(add->next)) != NULL &&
                tax->code == (BPF_MISC | BPF_TAX) &&
                (ild = live_step(tax->next)) != NULL &&
                BPF_CLASS(ild->code) == BPF_LD && BPF_MODE(ild->code) == BPF_IND) {
                ild->k += s->k;
                ild->vgen = 0;
                s->code = NOP;
                add->code = NOP;
                tax->code = NOP;
                o->changed = 1;
                o->touched = 1;
            }
        }
        s = next;
    }

    if ((b->code == (BPF_JMP | BPF_JEQ | BPF_K) ||
         b->code == (BPF_JMP | BPF_JGT | BPF_K)) &&  /* NEGATIVE TEST */
        !(b->out_use & (1 << A_ATOM))) {
        s = live_step(b->steps);
        if (s == NULL) return;
        last = s;
        while ((next = live_step(s->next)) != NULL) { s = next; last = next; }
        if (last->code == (BPF_ALU | BPF_SUB | BPF_X) && b->k == 0) {
            b->code = BPF_JMP | BPF_JEQ | BPF_X;
            last->code = NOP;
            o->changed = 1;
            o->touched = 1;
            return;
        }
        if (BPF_CLASS(last->code) != BPF_ALU || BPF_SRC(last->code) != BPF_K)
            return;
        if (BPF_OP(last->code) == BPF_AND && b->k == 0) {
            block *t = JT(b);
            b->k = last->k;
            b->code = BPF_JMP | BPF_JSET | BPF_K;
            last->code = NOP;
            JT(b) = JF(b);
            JF(b) = t;
            o->changed = 1;
            o->shape_changed = 1;
            return;
        }
        switch (BPF_OP(last->code)) {
        case BPF_SUB:
            b->k += last->k;
            last->code = NOP;
            o->changed = 1;
            o->touched = 1;
            break;
        case BPF_ADD:
            b->k -= last->k;
            last->code = NOP;
            o->changed = 1;
            o->touched = 1;
            break;
        default:
            break;
        }
    }
}

/*
 * Unlink the statements this round turned into NOPs.  They are invisible to
 * everything downstream already, but peep, the fusion signatures, use/def and
 * the emitter all pay to skip them on every later walk.
 *
 * Nothing here can be the target of an in-list jump: only the preamble
 * builders emit those, and each of them turns the shrinker off, so a block
 * holding one is never worked in the first place.
 */
static void compact_steps(block *b)
{
    sstmt *s = b->steps, **pp = &b->steps;

    while (s != NULL) {
        if (s->code == NOP) *pp = s->next;   /* drop it; pp still points here */
        else pp = &s->next;
        s = s->next;
    }
}

static void kill_deadstores(shrink *o, block *b)
{
    sstmt *s;
    sstmt *last[N_ATOMS];
    int atom;

    memset(last, 0, sizeof(last));
    for (s = b->steps; s; s = s->next) {
        if (s->code == NOP) continue;
        atom = step_reads(s->code, s->k);
        if (atom >= 0) {
            if (atom == AX_ATOM) { last[X_ATOM] = NULL; last[A_ATOM] = NULL; }
            else last[atom] = NULL;
        }
        atom = step_writes(s->code, s->k);
        if (atom >= 0) {
            if (last[atom]) { o->changed = 1; last[atom]->code = NOP; }
            last[atom] = s;
        }
    }
    atom = step_reads(b->code, b->k);
    if (atom >= 0) {
        if (atom == AX_ATOM) { last[X_ATOM] = NULL; last[A_ATOM] = NULL; }
        else last[atom] = NULL;
    }
    for (atom = 0; atom < N_ATOMS; ++atom)
        if (last[atom] && !(b->out_use & (1 << atom))) {
            last[atom]->code = NOP;
            o->changed = 1;
        }
}

static inline void work_node_impl(shrink *o, block *b, const int alter)
{
    sstmt *s;
    edge *p;
    u32 aval, xval;

    /*
     * What the predecessors leave in A and X, or nothing if they disagree.
     * The pull-ups need to know whether they agreed at all, which is not the
     * same question -- they may agree on "unknown" -- so record it here rather
     * than have each of them walk this list again.
     */
    p = b->in_edges;
    if (p == NULL) {
        aval = 0;
        xval = 0;
        b->pred_agree = 0;
    } else {
        u32 first = p->pred->val[A_ATOM];
        int agree = 1;

        aval = first;
        xval = p->pred->val[X_ATOM];
        for (p = p->next; p; p = p->next) {
            u32 pa = p->pred->val[A_ATOM];
            if (pa != first) agree = 0;
            if (aval != pa) aval = 0;
            if (xval != p->pred->val[X_ATOM]) xval = 0;
        }
        b->pred_aval = first;
        b->pred_agree = agree;
    }
    if (b->val_valid && !b->wn_dirty && aval == b->last_in_a &&
        xval == b->last_in_x && b->out_use == b->last_out_use &&
        JT(b) == b->last_jt && JF(b) == b->last_jf &&
        b->last_alter == alter)
        return;                 /* same inputs, same steps, same outcome */

    b->last_in_a = aval;
    b->last_in_x = xval;
    b->last_out_use = b->out_use;
    b->last_alter = alter;
    b->last_jt = JT(b);
    b->last_jf = JF(b);
    b->val_valid = 1;
    b->wn_dirty = 0;

    /* Only the slots this filter actually uses need re-clearing each round:
     * shrink_graph zeroed the whole array once, and a slot no statement ever
     * writes stays zero.  pull_or/pull_and compare all of val[], so they still
     * see a consistent zero for the untouched ones. */
    {
        u32 m = o->memmask;
        while (m) { int a = __builtin_ctz(m); m &= m - 1; b->val[a] = 0; }
    }
    b->val[A_ATOM] = aval;
    b->val[X_ATOM] = xval;

    o->touched = 0;
    b->nsteps = 0;
    for (s = b->steps; s; s = s->next) {
        run_step(o, s, b->val, alter);
        if (s->code != NOP) b->nsteps++;   /* run_step may have just voided it */
    }

    if (BPF_CLASS(b->code) == BPF_JMP && BPF_SRC(b->code) == BPF_X &&
        alter && o->vals[b->val[X_ATOM]].known) {
        b->code = (b->code & ~BPF_X) | BPF_K;
        b->k = o->vals[b->val[X_ATOM]].fixed;
        o->changed = 1;
    }

    if (BPF_CLASS(b->code) == BPF_JMP) {
        if (BPF_SRC(b->code) == BPF_K) {
            if (!b->kval_ok || b->kval_k != b->k) {
                b->kval = vn_const(o, b->k);
                b->kval_k = b->k;
                b->kval_ok = 1;
            }
            b->oval = b->kval;
        } else {
            b->oval = b->val[X_ATOM];
        }
    }

    /* a test against a constant whose operand is already known folds away */
    if (alter && BPF_CLASS(b->code) == BPF_JMP && BPF_SRC(b->code) == BPF_K &&
        JT(b) != NULL && o->vals[b->val[A_ATOM]].known) {
        u32 a = o->vals[b->val[A_ATOM]].fixed;
        int t;
        switch (BPF_OP(b->code)) {
        case BPF_JEQ: t = (a == b->k); break;
        case BPF_JGT: t = (a > b->k); break;
        case BPF_JGE: t = (a >= b->k); break;
        case BPF_JSET: t = ((a & b->k) != 0); break;
        default: t = -1; break;
        }
        if (t >= 0 && JT(b) != JF(b)) {
            if (t) JF(b) = JT(b); else JT(b) = JF(b);
            o->changed = 1;
            o->shape_changed = 1; g_c[7]++;
        }
    }

    if (alter) peep(o, b);
    kill_deadstores(o, b);
    if (o->touched) {
        sstmt **pp = &b->steps;
        sstmt *q;
        b->steps_dirty = 1;
        /* physically drop the steps that were turned into no-ops: nothing
         * points at a step inside a node the shrinker is allowed to touch */
        for (q = b->steps; q; q = q->next) {
            if (q->code == NOP) *pp = q->next;
            else pp = &q->next;
        }
    }
    b->last_jt = JT(b);
    b->last_jf = JF(b);

    {
        u32 t = ET_ID(b), f = EF_ID(b);
        o->e_aval[t] = o->e_aval[f] = b->val[A_ATOM];
        o->e_attr[t].code = b->code;
        o->e_attr[f].code = -b->code;
        o->e_attr[t].oval = o->e_attr[f].oval = b->oval;
    }
}

static void work_node_scan(shrink *o, block *b)  { work_node_impl(o, b, 0); }
static void work_node_alter(shrink *o, block *b) { work_node_impl(o, b, 1); }

/* ------------------------------------------------------------------ */
/* edge folding                                                       */
/* ------------------------------------------------------------------ */
/* Only reached once a candidate edge has matched, so keeping it out of line
 * leaves the scan loop above with fewer live values to juggle. */
__attribute__((noinline))
static int reads_conflict(block *b, block *succ)
{
    int atom;
    u32 mask = (u32)succ->out_use;

    if (mask == 0) return 0;
    for (atom = 0; atom < N_ATOMS; atom++) {
        if (!(mask & ((u32)1 << atom))) continue;
        if (b->val[atom] != succ->val[atom]) return 1;
    }
    return 0;
}

static block *fold_edge_unused(shrink *o, block *child, edge *ep)
{
    int sense;
    int code = ep->code;
    u32 aval0, aval1, oval0, oval1;

    (void)o;
    if (code < 0) { code = -code; sense = 0; } else sense = 1;

    if (child->code != code) return NULL;

    aval0 = child->val[A_ATOM];
    oval0 = child->oval;
    aval1 = ep->pred->val[A_ATOM];
    oval1 = ep->pred->oval;

    if (aval0 != aval1) return NULL;

    if (oval0 == oval1) return sense ? JT(child) : JF(child);

    if (sense && code == (BPF_JMP | BPF_JEQ | BPF_K)) return JF(child);

    return NULL;
}

#define BTEST(p, i)  ((p)[(unsigned)(i) / WBITS] & ((uint64_t)1 << ((unsigned)(i) % WBITS)))
#define EHASH(o, v) (((unsigned)(v) * 2654435761u) & (unsigned)((o)->ehsize - 1))

static void thread_edge(shrink *o, edge *ep)
{
    int i, k;
    block *target;

    if (JT(ep->succ) == NULL) return;

    if (JT(ep->succ) == JF(ep->succ)) {
        if (!reads_conflict(ep->pred, JT(ep->succ))) {
            o->changed = 1;
            ep->succ = JT(ep->succ);
            return;
        }
    }

    for (i = 0; i < o->ewords; ++i) {
        u32 x = ep->edom[i];
        while (x != 0) {
            k = 0;
            while (!(x & ((u32)1 << k))) k++;
            x &= ~((uint64_t)1 << k);
            if (k + i * WBITS >= o->nedges) continue;
            target = fold_edge(o, ep->succ, o->edges[k + i * WBITS]);
            if (target != NULL && !reads_conflict(ep->pred, target)) {
                o->changed = 1;
                ep->succ = target;
                return;
            }
        }
    }
}

/* ------------------------------------------------------------------ */
/* fuse identical nodes                                               */
/* ------------------------------------------------------------------ */
static int same_steps(sstmt *x, sstmt *y)
{
    for (;;) {
        x = live_step(x);
        y = live_step(y);
        if (x == NULL || y == NULL) return x == y;
        if (x->code != y->code || x->k != y->k) return 0;
        if (x->jt != y->jt || x->jf != y->jf) return 0;
        x = x->next;
        y = y->next;
    }
}

static int same_node(block *x, block *y)
{
    if (x->code != y->code || x->k != y->k) return 0;
    if (JT(x) != JT(y) || JF(x) != JF(y)) return 0;
    return same_steps(x->steps, y->steps);
}

static void mark_live(shrink *o, block *p)
{
    int sp = 0;

    walk_room(o->nnodes + 4);
    if (p == NULL || visited(o, p)) return;
    visit(o, p);
    walk_stack[sp++] = p;
    while (sp > 0) {
        block *b = walk_stack[--sp];
        if (JT(b) && !visited(o, JT(b))) { visit(o, JT(b)); walk_stack[sp++] = JT(b); }
        if (JF(b) && !visited(o, JF(b))) { visit(o, JF(b)); walk_stack[sp++] = JF(b); }
    }
}

/*
 * Merge nodes that test the same thing and go to the same places.  Nodes are
 * bucketed by a signature over exactly the fields same_node() compares, so the
 * search is linear rather than quadratic; each duplicate is pointed at the
 * survivor and the predecessors are then rewired to match.  Fusing can expose
 * further duplicates, so this repeats until a round merges nothing.
 */
static void fuse_nodes(shrink *o, block *root)
{
    int i, j, again;
    block *p;

    for (;;) {
        again = 1;
        for (i = 0; i < o->nnodes; ++i) o->nodes[i]->inext = NULL;

        epoch_next(o);

        for (i = o->nnodes - 1; --i >= 0; ) {
            if (!visited(o, o->nodes[i])) continue;
            for (j = i + 1; j < o->nnodes; ++j) {
                if (!visited(o, o->nodes[j])) continue;
                if (same_node(o->nodes[i], o->nodes[j])) {
                    o->nodes[i]->inext = o->nodes[j]->inext ?
                                         o->nodes[j]->inext : o->nodes[j];
                    nredir++;
                    break;
                }
            }
        }
        if (nredir == 0) break;
        nrew = 0;
        for (i = 0; i < o->nnodes; ++i) {   /* point predecessors at the keeper */
            int moved = 0;
            p = o->nodes[i];
            if (JT(p) == NULL || !visited(o, p)) continue;
            if (JT(p)->inext) { again = 0; JT(p) = JT(p)->inext; moved = 1; }
            if (JF(p)->inext) { again = 0; JF(p) = JF(p)->inext; moved = 1; }
            if (moved) rew[nrew++] = i;
        }
        while (nredir > 0) o->nodes[redir[--nredir]]->inext = NULL;
        if (again) break;
    }
}

/*
 * Step the entry point past any test whose two exits agree, carrying the
 * statements along, and drop the statements entirely if the graph has been
 * reduced to a bare verdict.
 */
static void simplify_root(block **b)
{
    sstmt *tmp, *s;

    s = (*b)->steps;
    (*b)->steps = NULL;
    while (BPF_CLASS((*b)->code) == BPF_JMP && JT(*b) == JF(*b))
        *b = JT(*b);

    tmp = (*b)->steps;
    if (tmp != NULL) {
        if (s == NULL) s = tmp;
        else step_cat(s, tmp);
    }
    (*b)->steps = s;

    if (BPF_CLASS((*b)->code) == BPF_RET)
        (*b)->steps = NULL;

    /* this is the one place statements move between blocks after the last
     * time the node was worked, so the live count has to be redone here */
    {
        sstmt *q;
        int n = 0;
        for (q = (*b)->steps; q; q = q->next)
            if (q->code != NOP) n++;
        (*b)->nsteps = n;
    }
}

/* ------------------------------------------------------------------ */
/* driver                                                             */
/* ------------------------------------------------------------------ */
static block **s_nodes;
static block **s_post;      /* the same nodes in the order the walk leaves them */
static int s_nodes_cap;

static void count_r(shrink *o, block *p)
{
    sstmt *s;

    visit(o, p);
    if (o->nnodes >= s_nodes_cap) {
        s_nodes_cap = s_nodes_cap ? s_nodes_cap * 2 : 256;
        s_nodes = realloc(s_nodes, (size_t)s_nodes_cap * sizeof(block *));
        s_post = realloc(s_post, (size_t)s_nodes_cap * sizeof(block *));
        if (s_nodes == NULL || s_post == NULL) abort();
    }
    p->id = o->nnodes;
    s_nodes[o->nnodes++] = p;
    for (s = p->steps; s; s = s->next) {
        o->nsteps++;
        /* which scratch-memory slots this filter touches at all */
        if (BPF_CLASS(s->code) == BPF_ST || BPF_CLASS(s->code) == BPF_STX ||
            ((BPF_CLASS(s->code) == BPF_LD || BPF_CLASS(s->code) == BPF_LDX) &&
             BPF_MODE(s->code) == BPF_MEM))
            if (s->k < BPF_MEMWORDS) o->memmask |= (u32)1 << s->k;
    }
    WALK(count_r, o, JT(p));
    WALK(count_r, o, JF(p));

    /* This walk and find_ranks visit the graph identically, so the levels and
     * the order nodes are finished in can be taken here and the first ranking
     * pass reduced to threading the lists together. */
    if (JT(p) != NULL)
        p->level = (JT(p)->level > JF(p)->level ? JT(p)->level : JF(p)->level) + 1;
    else
        p->level = 0;
    s_post[o->n_post++] = p;
}

static void pass(shrink *o, block *root, int alter)
{
    int i, rounds = 0;
    block *p;
    edge *ep;

    for (;;) {
        o->changed = 0;
        { double a=nsec();
        if (o->shape_changed) {

            find_flow_sets(o, root);
            o->shape_changed = 0;
        }
        g_t[1]+=nsec()-a; a=nsec(); }
        { double a=nsec(); find_live_atoms(o, root); g_t[2]+=nsec()-a; }
        for (i = o->maxrank; i >= 0; --i)
            for (p = o->rank[i]; p; p = p->link)
                { extern long g_wn; g_wn++; work_node(o, p, alter); }

        if (1) {
            double a=nsec();
            for (i = 1; i <= o->maxrank; ++i)
                for (p = o->rank[i]; p; p = p->link) {
                    pull_and(o, p);
                    pull_or(o, p);

                }
        }
        { extern long g_it; g_it++; }
        { extern long g_i0,g_i1; if (alter) g_i1++; else g_i0++; }
        if (!o->changed) break;
        if (++rounds > 100) break;
    }
}

long g_c[8];

long g_scan;

long g_it, g_wn, g_cc;

/* One shrinker state, reused across compiles: the value table is large and
 * clearing it wholesale for every filter costs more than the analysis does. */
static shrink g_shrink;

long g_skip, g_run, g_maxv, g_full;

long g_skip, g_run;

long g_i0, g_i1;

int shrink_graph(cstate *cs)
{
    shrink *op = &g_shrink;
    int i, nedge;
    size_t nb, nbits;

#define o (*op)
    if (o.epoch == 0) o.epoch = 100000;
    if (!atom_tab_ready) build_atom_tab();
    o.cs = cs;
    o.changed = 0;
    o.touched = 0;
    o.shape_changed = 1;
    o.ud_valid = 0;
    o.nnodes = 0;
    o.nsteps = 0;
    o.memmask = 0;
    o.n_post = 0;
    o.maxrank = 0;

    epoch_next(op);
    WALK(count_r, op, cs->root);
    o.ranks_ready = 1;
    nb = (size_t)o.nnodes;
    if (nb == 0) return 0;

    o.nodes = s_nodes;
    nedge = 2 * o.nnodes;
    o.edges = ar_alloc(&cs->ar, (size_t)nedge * sizeof(edge *));
    o.nwords = (o.nnodes + WBITS - 1) / WBITS;
    o.ewords = (nedge + WBITS - 1) / WBITS;
    nbits = (size_t)o.nnodes * o.nwords + (size_t)nedge * o.ewords;
    /*
     * The dominator sets are quadratic in the size of the graph, so a filter
     * with some thousands of distinct terms would ask for tens of gigabytes,
     * and being killed by the OOM reaper takes every other case in the run
     * down with it.  A graph that large is already turned away by the block
     * ceiling in bpfc_compile, so this is a backstop that keeps the guarantee
     * local to the code that does the allocating.
     */
    if (nbits > (size_t)32 * 1024 * 1024)
        bpf_err(cs, "filter expression too complex");
    o.bits = ar_alloc(&cs->ar, nbits * sizeof(uint64_t));
    o.rank = ar_alloc(&cs->ar, (nb + 2) * sizeof(block *));
    if (nedge > o.e_cap) {
        /* Commit the pointer and the capacity only once both allocations have
         * succeeded.  Bumping the capacity first leaves a failed compile with a
         * capacity that promises a buffer it does not have, and the *next*
         * compile skips the growth branch and dereferences NULL. */
        int ncap = nedge * 2;
        u32 *na = realloc(o.e_aval, (size_t)ncap * sizeof(*o.e_aval));
        struct eattr *nt;
        if (na != NULL) o.e_aval = na;
        nt = realloc(o.e_attr, (size_t)ncap * sizeof(*o.e_attr));
        if (nt != NULL) o.e_attr = nt;
        if (na == NULL || nt == NULL) return -1;
        o.e_cap = ncap;
    }
    o.ehsize = 16;
    while (o.ehsize < 2 * nedge) o.ehsize *= 2;   /* sized for *this* graph */
    if (o.ehsize > o.ecap) {
        o.ecap = o.ehsize * 2;
        o.ehead = realloc(o.ehead, (size_t)o.ecap * sizeof(int));
        o.enext = realloc(o.enext, (size_t)o.ecap * sizeof(int));
        if (o.ehead == NULL || o.enext == NULL) return -1;
    }
    if (nedge > o.e_cap) {
        /* Commit the pointer and the capacity only once both allocations have
         * succeeded.  Bumping the capacity first leaves a failed compile with a
         * capacity that promises a buffer it does not have, and the *next*
         * compile skips the growth branch and dereferences NULL. */
        int ncap = nedge * 2;
        u32 *na = realloc(o.e_aval, (size_t)ncap * sizeof(*o.e_aval));
        struct eattr *nt;
        if (na != NULL) o.e_aval = na;
        nt = realloc(o.e_attr, (size_t)ncap * sizeof(*o.e_attr));
        if (nt != NULL) o.e_attr = nt;
        if (na == NULL || nt == NULL) return -1;
        o.e_cap = ncap;
    }
    o.order_desc = ar_alloc(&cs->ar, (nb + 2) * sizeof(block *));
    o.order_asc = ar_alloc(&cs->ar, (nb + 2) * sizeof(block *));
    o.vmax = o.nsteps * 24 + o.nnodes * 24 + 1024;
    o.vpool = ar_alloc(&cs->ar, (size_t)o.vmax * sizeof(vnode));
    o.vals = ar_alloc(&cs->ar, (size_t)(o.vmax + 2) * sizeof(vslot));

    for (i = 0; i < o.nnodes; i++) {
        o.nodes[i]->steps_dirty = 1;
        o.nodes[i]->wn_dirty = 1;
        o.nodes[i]->val_valid = 0;
    }

    for (i = 0; i < o.nnodes; i++) {
        block *b = o.nodes[i];
        b->et.id = (u32)(2 * i);
        o.edges[2 * i] = &b->et;
        b->ef.id = (u32)(2 * i + 1);
        o.edges[2 * i + 1] = &b->ef;
        b->et.pred = b;
        b->ef.pred = b;
    }
    o.nedges = nedge;

    { extern long g_cc; g_cc++; }
    pass(op, cs->root, 1);
    { double a=nsec(); fuse_nodes(op, cs->root); g_t[6]+=nsec()-a; }
    simplify_root(&cs->root);
    return 0;
#undef o
}
