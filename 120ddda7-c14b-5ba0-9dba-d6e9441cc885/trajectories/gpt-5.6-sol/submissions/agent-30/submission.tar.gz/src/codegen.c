#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filter.h"
void bpf_prog_init(bpf_prog_t*p){memset(p,0,sizeof(*p));}
void bpf_prog_free(bpf_prog_t*p){free(p->insns);bpf_prog_init(p);}
void bpf_prog_reset(bpf_prog_t*p){p->len=0;p->overflow=0;}
void bpf_emit(bpf_prog_t*p,uint16_t c,uint8_t jt,uint8_t jf,uint32_t k){if(p->overflow)return;if(p->len>=BPF_MAXINSNS){p->overflow=1;return;}if(p->len==p->cap){size_t z=p->cap?p->cap*2:128;bpf_insn_t*q=realloc(p->insns,z*sizeof(*q));if(!q){p->overflow=1;return;}p->insns=q;p->cap=z;}p->insns[p->len++]=(bpf_insn_t){c,jt,jf,k};}
enum { LDW=32,LDH=40,LDB=48,LDHI=72,LDBI=80,LDXIMM=1,LDXMEM=97,LDWMEM=96,LDLEN=128,TAX=7,ST=2,ADDK=4,ANDK=84,JEQ=21,JGT=37,JGE=53,JSET=69,RET=6 };
typedef struct{int at,which,next;}ref_t;typedef struct{int t,f;}frag_t;typedef struct{bpf_prog_t*p;ref_t refs[8192];int nr,last_order,dlt,optimize;uint32_t netmask;}gen_t;
static int addref(gen_t*g,int at,int which){int r=g->nr++;if(r>=8192){g->p->overflow=1;return-1;}g->refs[r]=(ref_t){at,which,-1};return r;}
static int join(gen_t*g,int a,int b){if(a<0)return b;int x=a;while(g->refs[x].next>=0)x=g->refs[x].next;g->refs[x].next=b;return a;}
static void patch(gen_t*g,int h,int target){for(;h>=0;h=g->refs[h].next){int d=target-g->refs[h].at-1;if(d<0||d>255){g->p->overflow=1;return;}if(g->refs[h].which)g->p->insns[g->refs[h].at].jf=(uint8_t)d;else g->p->insns[g->refs[h].at].jt=(uint8_t)d;}}
static frag_t cond(gen_t*g,uint16_t op,uint32_t k,int toj){int at=(int)g->p->len;bpf_emit(g->p,op,0,0,k);int a=addref(g,at,0),b=addref(g,at,1);return toj?(frag_t){a,b}:(frag_t){b,a};}
static frag_t land(gen_t*g,frag_t a,frag_t b,int s){patch(g,a.t,s);return(frag_t){b.t,join(g,a.f,b.f)};}static frag_t lor(gen_t*g,frag_t a,frag_t b,int s){patch(g,a.f,s);return(frag_t){join(g,a.t,b.t),b.f};}static frag_t lnot(frag_t a){return(frag_t){a.f,a.t};}
static int linkoff(int d){return d==1?12:d==113?14:d==9?2:-1;}static int ipbase(int d){return d==1?14:d==113?16:(d==9||d==0)?4:0;}
static frag_t wifi_prefix(gen_t*g){int a,b;bpf_emit(g->p,LDXIMM,0,0,0);bpf_emit(g->p,TAX,0,0,0);bpf_emit(g->p,ADDK,0,0,24);bpf_emit(g->p,ST,0,0,15);bpf_emit(g->p,LDBI,0,0,0);bpf_emit(g->p,JSET,0,5,8);bpf_emit(g->p,JSET,4,0,4);bpf_emit(g->p,JSET,0,3,128);bpf_emit(g->p,LDWMEM,0,0,15);bpf_emit(g->p,ADDK,0,0,2);bpf_emit(g->p,ST,0,0,15);bpf_emit(g->p,LDBI,0,0,0);a=(int)g->p->len;bpf_emit(g->p,JSET,0,0,4);bpf_emit(g->p,LDBI,0,0,0);b=(int)g->p->len;bpf_emit(g->p,JSET,0,0,8);bpf_emit(g->p,LDXMEM,0,0,15);return(frag_t){-1,join(g,addref(g,a,0),addref(g,b,1))};}
static frag_t emit_eth(gen_t*g,uint32_t v){frag_t q={-1,-1},c;int off=linkoff(g->dlt);g->last_order=0;if(g->dlt==105){q=wifi_prefix(g);if(v==0xf0f0||v==0x42||v==0xe0){bpf_emit(g->p,LDBI,0,0,0);c=cond(g,JEQ,v&255,1);}else{bpf_emit(g->p,LDHI,0,0,6);c=cond(g,JEQ,v,1);}q.f=join(g,q.f,c.f);q.t=c.t;g->last_order=1;return q;}if(g->dlt==12){uint32_t n=v==0x0800?0x40:v==0x86dd?0x60:0xffffffffu;bpf_emit(g->p,LDB,0,0,0);bpf_emit(g->p,ANDK,0,0,0xf0);return cond(g,JEQ,n,1);}if(g->dlt==0){uint32_t f=v==0x0800?0x02000000u:v==0x86dd?0x0a000000u:0xffffffffu;bpf_emit(g->p,LDW,0,0,0);return cond(g,JEQ,f,1);}if(off>=0){uint32_t x=v;if(g->dlt==9){if(v==0x0800)x=0x21;else if(v==0x86dd)x=0x57;}bpf_emit(g->p,LDH,0,0,(uint32_t)off);return cond(g,JEQ,x,1);}return q;}
static frag_t emit_proto4(gen_t*g,uint32_t p){frag_t a=emit_eth(g,0x0800);int s=(int)g->p->len,b=ipbase(g->dlt);bpf_emit(g->p,g->dlt==105?LDBI:LDB,0,0,(uint32_t)(g->dlt==105?17:b+9));frag_t x=cond(g,JEQ,p,1);return land(g,a,x,s);}
static frag_t emit_proto6(gen_t*g,uint32_t p){frag_t a=emit_eth(g,0x86dd);int s=(int)g->p->len,b=ipbase(g->dlt);uint16_t op=g->dlt==105?LDBI:LDB;uint32_t no=(uint32_t)(g->dlt==105?14:b+6);bpf_emit(g->p,op,0,0,no);frag_t x=cond(g,JEQ,p,1);if(!g->optimize)bpf_emit(g->p,op,0,0,no);frag_t e=cond(g,JEQ,44,1);int z=(int)g->p->len;bpf_emit(g->p,op,0,0,(uint32_t)(g->dlt==105?48:b+40));frag_t y=cond(g,JEQ,p,1);patch(g,e.t,z);frag_t q={join(g,x.t,y.t),join(g,e.f,y.f)};return land(g,a,q,s);}
static frag_t emit_both_unopt(gen_t*g,uint32_t p){frag_t a=emit_proto4(g,p);int s=(int)g->p->len;frag_t b=emit_proto6(g,p);return lor(g,a,b,s);}
static frag_t emit_both_opt(gen_t*g,uint32_t p){
    if(g->dlt==105||g->dlt==12)return emit_both_unopt(g,p);int o=linkoff(g->dlt),b=ipbase(g->dlt);uint32_t ip=0x0800,ip6=0x86dd;
    if(g->dlt==0){bpf_emit(g->p,LDW,0,0,0);ip=0x02000000;ip6=0x0a000000;}else{bpf_emit(g->p,LDH,0,0,(uint32_t)o);if(g->dlt==9){ip=0x21;ip6=0x57;}}
    frag_t e4=cond(g,JEQ,ip,1);int e6s=(int)g->p->len;frag_t e6=cond(g,JEQ,ip6,1);patch(g,e4.f,e6s);int s6=(int)g->p->len;bpf_emit(g->p,LDB,0,0,(uint32_t)(b+6));frag_t x=cond(g,JEQ,p,1),e=cond(g,JEQ,44,1);int z=(int)g->p->len;bpf_emit(g->p,LDB,0,0,(uint32_t)(b+40));frag_t y=cond(g,JEQ,p,1);patch(g,e.t,z);int s4=(int)g->p->len;bpf_emit(g->p,LDB,0,0,(uint32_t)(b+9));frag_t q=cond(g,JEQ,p,1);patch(g,e4.t,s4);patch(g,e6.t,s6);return(frag_t){join(g,q.t,join(g,x.t,y.t)),join(g,e6.f,join(g,e.f,y.f))};
}
static frag_t emit_len(gen_t*g,const node_t*n){bpf_emit(g->p,LDLEN,0,0,0);g->last_order=0;switch(n->cmp){case CMP_LT:return cond(g,JGE,n->val,0);case CMP_LE:return cond(g,JGT,n->val,0);case CMP_GT:g->last_order=1;return cond(g,JGT,n->val,1);case CMP_GE:return cond(g,JGE,n->val,1);case CMP_EQ:return cond(g,JEQ,n->val,1);case CMP_NE:return cond(g,JEQ,n->val,0);}return(frag_t){-1,-1};}
static frag_t emit_ehost(gen_t*g,const node_t*n){
    int o=n->dir==DIR_SRC?6:0;uint32_t a=((uint32_t)n->addr[0]<<24)|((uint32_t)n->addr[1]<<16)|((uint32_t)n->addr[2]<<8)|n->addr[3],b=((uint32_t)n->addr[4]<<8)|n->addr[5];
    if(n->dir==DIR_ANY){node_t q=*n;q.dir=DIR_SRC;frag_t x=emit_ehost(g,&q);int s=(int)g->p->len;q.dir=DIR_DST;frag_t y=emit_ehost(g,&q);return lor(g,x,y,s);}
    bpf_emit(g->p,LDW,0,0,o);frag_t x=cond(g,JEQ,a,1);int s=(int)g->p->len;bpf_emit(g->p,LDH,0,0,o+4);frag_t y=cond(g,JEQ,b,1);return land(g,x,y,s);
}
static frag_t emit_addr_one(gen_t*g,const node_t*n,uint32_t et,int off){frag_t a=emit_eth(g,et);int s=(int)g->p->len;bpf_emit(g->p,LDW,0,0,(uint32_t)off);if(n->prim==PR_NET4)bpf_emit(g->p,ANDK,0,0,n->mask);frag_t b=cond(g,JEQ,n->val&n->mask,1);return land(g,a,b,s);}
static frag_t emit_addr4(gen_t*g,const node_t*n){
    int b=ipbase(g->dlt),as=b+14,ad=b+24;frag_t all={-1,-1};int first=1;
    uint32_t ets[3]={0x0800,0x0806,0x8035};int fams=n->val2?(int)n->val2:0,start=fams==4?0:fams==1?1:fams==2?2:0,end=fams?start+1:3;
    for(int e=start;e<end;e++){int so=e?as:b+12,doff=e?ad:b+16;
        if(n->dir==DIR_SRC||n->dir==DIR_BOTH||n->dir==DIR_ANY){int s=(int)g->p->len;frag_t x=emit_addr_one(g,n,ets[e],so);if(first){all=x;first=0;}else all=lor(g,all,x,s);}
        if(n->dir==DIR_DST||n->dir==DIR_BOTH||n->dir==DIR_ANY){int s=(int)g->p->len;frag_t x=emit_addr_one(g,n,ets[e],doff);if(first){all=x;first=0;}else if(n->dir==DIR_BOTH)all=land(g,all,x,s);else all=lor(g,all,x,s);}
    }return all;
}
static uint32_t beword(const uint8_t*p){return((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static frag_t emit_addr6_one(gen_t*g,const node_t*n,int off){
    frag_t a=emit_eth(g,0x86dd);int prefix=n->prim==PR_HOST6?128:(int)n->val2;
    for(int i=0;i<4;i++){int bits=prefix-i*32;uint32_t m=bits>=32?0xffffffffu:bits<=0?0:0xffffffffu<<(32-bits);if(g->optimize&&m==0)continue;int s=(int)g->p->len;bpf_emit(g->p,LDW,0,0,(uint32_t)(off+i*4));if(n->prim==PR_NET6&&m!=0xffffffffu)bpf_emit(g->p,ANDK,0,0,m);frag_t q=cond(g,JEQ,beword(n->addr+i*4)&m,1);a=land(g,a,q,s);}return a;
}
static frag_t emit_addr6(gen_t*g,const node_t*n){int b=ipbase(g->dlt),so=b+8,doff=b+24;if(n->dir==DIR_SRC)return emit_addr6_one(g,n,so);if(n->dir==DIR_DST)return emit_addr6_one(g,n,doff);frag_t a=emit_addr6_one(g,n,so);int s=(int)g->p->len;frag_t q=emit_addr6_one(g,n,doff);return n->dir==DIR_BOTH?land(g,a,q,s):lor(g,a,q,s);}
static frag_t emit_multicast(gen_t*g,const node_t*n){if(n->val==4){frag_t a=emit_eth(g,0x0800);int s=(int)g->p->len;bpf_emit(g->p,LDB,0,0,(uint32_t)(ipbase(g->dlt)+16));bpf_emit(g->p,ANDK,0,0,0xf0);frag_t q=cond(g,JEQ,0xe0,1);return land(g,a,q,s);}if(n->val==6){frag_t a=emit_eth(g,0x86dd);int s=(int)g->p->len;bpf_emit(g->p,LDB,0,0,(uint32_t)(ipbase(g->dlt)+24));frag_t q=cond(g,JEQ,0xff,1);return land(g,a,q,s);}bpf_emit(g->p,LDB,0,0,0);g->last_order=1;return cond(g,JSET,1,1);}
static frag_t emit_iso(gen_t*g,const node_t*n){if(g->dlt==105){frag_t a=wifi_prefix(g);bpf_emit(g->p,LDHI,0,0,0);frag_t l=cond(g,JEQ,0xfefe,1);int s=(int)g->p->len;bpf_emit(g->p,LDBI,0,0,3);frag_t q=cond(g,JEQ,n->val,1);l=land(g,l,q,s);l.f=join(g,a.f,l.f);g->last_order=1;return l;}bpf_emit(g->p,LDH,0,0,(uint32_t)linkoff(g->dlt));frag_t len=cond(g,JGT,1500,0);int s=(int)g->p->len;bpf_emit(g->p,LDH,0,0,(uint32_t)(linkoff(g->dlt)+2));frag_t llc=cond(g,JEQ,0xfefe,1);len=land(g,len,llc,s);s=(int)g->p->len;bpf_emit(g->p,LDB,0,0,(uint32_t)(linkoff(g->dlt)+5));frag_t q=cond(g,JEQ,n->val,1);return land(g,len,q,s);}
static frag_t emit_wlan(gen_t*g,const node_t*n){if(n->val2){bpf_emit(g->p,LDB,0,0,1);bpf_emit(g->p,ANDK,0,0,3);return cond(g,JEQ,n->val,1);}bpf_emit(g->p,LDB,0,0,0);bpf_emit(g->p,ANDK,0,0,n->val<16?12:252);return cond(g,JEQ,n->val,1);}
static frag_t emit_broadcast(gen_t*g,const node_t*n){if(n->val==4){frag_t a=emit_eth(g,0x0800);uint32_t hm=~g->netmask;int s=(int)g->p->len;bpf_emit(g->p,LDW,0,0,(uint32_t)(ipbase(g->dlt)+16));frag_t zero=cond(g,JSET,hm,0);int as=(int)g->p->len;bpf_emit(g->p,ANDK,0,0,hm);frag_t all=cond(g,JEQ,hm,1);frag_t inner=lor(g,zero,all,as);return land(g,a,inner,s);}node_t q=*n;q.prim=PR_ETHER_HOST;q.dir=DIR_DST;memset(q.addr,255,6);return emit_ehost(g,&q);}
static frag_t emit_ports_at(gen_t*g,const node_t*n,int ind,int base){
    int so=base,doff=base+2;frag_t all={-1,-1};int first=1;int dirs[2],nd=0;if(n->dir==DIR_SRC)dirs[nd++]=so;else if(n->dir==DIR_DST)dirs[nd++]=doff;else{dirs[nd++]=so;dirs[nd++]=doff;}
    for(int i=0;i<nd;i++){int begin=(int)g->p->len;bpf_emit(g->p,ind?LDHI:LDH,0,0,(uint32_t)dirs[i]);frag_t x;if(n->prim==PR_PORT)x=cond(g,JEQ,n->val,1);else{frag_t lo=cond(g,n->val?JGT:JGE,n->val?n->val-1:0,1);int s=(int)g->p->len;frag_t hi=cond(g,JGT,n->val2,0);x=land(g,lo,hi,s);}if(first){all=x;first=0;}else if(n->dir==DIR_BOTH)all=land(g,all,x,begin);else all=lor(g,all,x,begin);}
    return all;
}
static frag_t emit_tps(gen_t*g,transport_t tp,int off){bpf_emit(g->p,LDB,0,0,(uint32_t)off);if(tp!=TP_ANY)return cond(g,JEQ,tp==TP_TCP?6:tp==TP_UDP?17:132,1);frag_t a=cond(g,JEQ,132,1);int s=(int)g->p->len;frag_t b=cond(g,JEQ,6,1);a=lor(g,a,b,s);s=(int)g->p->len;frag_t c=cond(g,JEQ,17,1);return lor(g,a,c,s);}
static frag_t emit_port(gen_t*g,const node_t*n){
    int lo=linkoff(g->dlt),b=ipbase(g->dlt);uint32_t ip=0x0800,ip6=0x86dd;if(g->dlt==0){bpf_emit(g->p,LDW,0,0,0);ip=0x02000000;ip6=0x0a000000;}else if(g->dlt==12){bpf_emit(g->p,LDB,0,0,0);bpf_emit(g->p,ANDK,0,0,0xf0);ip=0x40;ip6=0x60;}else{bpf_emit(g->p,LDH,0,0,(uint32_t)lo);if(g->dlt==9){ip=0x21;ip6=0x57;}}
    frag_t e6=cond(g,JEQ,ip6,1);int e4s=(int)g->p->len;frag_t e4=cond(g,JEQ,ip,1);patch(g,e6.f,e4s);
    int s4=(int)g->p->len;frag_t t4=emit_tps(g,n->transport,b+9);int fs=(int)g->p->len;bpf_emit(g->p,LDH,0,0,(uint32_t)(b+6));frag_t nf=cond(g,JSET,8191,0);t4=land(g,t4,nf,fs);int xs=(int)g->p->len;bpf_emit(g->p,177,0,0,(uint32_t)b);frag_t p4=emit_ports_at(g,n,1,b);t4=land(g,t4,p4,xs);
    int s6=(int)g->p->len;frag_t t6=emit_tps(g,n->transport,b+6);int p6s=(int)g->p->len;frag_t p6=emit_ports_at(g,n,0,b+40);t6=land(g,t6,p6,p6s);
    patch(g,e6.t,s6);patch(g,e4.t,s4);g->last_order=0;return(frag_t){join(g,t4.t,t6.t),join(g,e4.f,join(g,t4.f,t6.f))};
}
static frag_t emit_byte(gen_t*g,const node_t*n){
    if(!strcmp(n->base,"self")){frag_t a=emit_eth(g,0x0800);int s=(int)g->p->len;bpf_emit(g->p,LDB,0,0,(uint32_t)(ipbase(g->dlt)+n->val));bpf_emit(g->p,TAX,0,0,12);frag_t q=cond(g,29,0,1);return land(g,a,q,s);}
    int base=0,ind=0;frag_t guard={-1,-1};int guarded=0;uint32_t off=n->val;if(!strcmp(n->base,"ip")){guard=emit_eth(g,0x0800);base=ipbase(g->dlt);guarded=1;}else if(!strcmp(n->base,"tcp")||!strcmp(n->base,"udp")||!strcmp(n->base,"icmp")){uint32_t pr=!strcmp(n->base,"tcp")?6:!strcmp(n->base,"udp")?17:1;guard=emit_proto4(g,pr);base=ipbase(g->dlt);int fs=(int)g->p->len;bpf_emit(g->p,LDH,0,0,(uint32_t)(base+6));frag_t nf=cond(g,JSET,8191,0);guard=land(g,guard,nf,fs);int xs=(int)g->p->len;bpf_emit(g->p,177,0,0,(uint32_t)base);patch(g,guard.t,xs);guard.t=-1;ind=1;guarded=1;}
    int ls=(int)g->p->len;uint16_t op=n->size==1?LDB:n->size==2?LDH:LDW;if(ind)op=(uint16_t)(op+32);bpf_emit(g->p,op,0,0,(uint32_t)(base+off));if(n->mask!=0xffffffffu)bpf_emit(g->p,ANDK,0,0,n->mask);if(n->val2&0x10000u)bpf_emit(g->p,100,0,0,n->val2&0xffff);else if(n->val2&0x20000u)bpf_emit(g->p,116,0,0,n->val2&0xffff);uint32_t v=n->constant;frag_t c;
    if(n->mask!=0xffffffffu&&v==0&&(n->cmp==CMP_EQ||n->cmp==CMP_NE)){g->p->len--;g->last_order=n->cmp==CMP_NE;c=cond(g,JSET,n->mask,n->cmp==CMP_NE);}else switch(n->cmp){case CMP_EQ:c=cond(g,JEQ,v,1);break;case CMP_NE:g->last_order=1;c=cond(g,JEQ,v,0);break;case CMP_GT:g->last_order=1;c=cond(g,JGT,v,1);break;case CMP_GE:g->last_order=1;c=cond(g,JGE,v,1);break;case CMP_LT:c=cond(g,JGE,v,0);break;default:c=cond(g,JGT,v,0);break;}if(guarded){c.f=join(g,guard.f,c.f);return c;}return c;
}
static frag_t emit_prim(gen_t*g,const node_t*n){switch(n->prim){case PR_ETHERTYPE:return emit_eth(g,n->val);case PR_IPPROTO4:return emit_proto4(g,n->val);case PR_IPPROTO6:return emit_proto6(g,n->val);case PR_IPPROTO:return g->optimize?emit_both_opt(g,n->val):emit_both_unopt(g,n->val);case PR_LEN:return emit_len(g,n);case PR_ETHER_HOST:return emit_ehost(g,n);case PR_HOST4:case PR_NET4:return emit_addr4(g,n);case PR_HOST6:case PR_NET6:return emit_addr6(g,n);case PR_PORT:case PR_PORTRANGE:return emit_port(g,n);case PR_BYTE:return emit_byte(g,n);case PR_IFINDEX:bpf_emit(g->p,LDW,0,0,0);return cond(g,JEQ,n->val,1);case PR_DIRECTION:bpf_emit(g->p,LDH,0,0,0);return cond(g,JEQ,n->val?4:0,1);case PR_PPPOE:return emit_eth(g,n->val);case PR_MPLS:return emit_eth(g,0x8847);case PR_VLAN:{frag_t a=emit_eth(g,0x8100);int s=(int)g->p->len;frag_t b=emit_eth(g,0x88a8);return lor(g,a,b,s);}case PR_MULTICAST:return emit_multicast(g,n);case PR_BROADCAST:return emit_broadcast(g,n);case PR_ISO:return emit_iso(g,n);case PR_WLAN_TYPE:return emit_wlan(g,n);default:return(frag_t){-1,-1};}}
static int equal_node(const node_t*a,const node_t*b){if(!a||!b||a->kind!=b->kind)return 0;if(a->kind==NODE_NOT)return equal_node(a->l,b->l);if(a->kind==NODE_AND||a->kind==NODE_OR)return equal_node(a->l,b->l)&&equal_node(a->r,b->r);if(a->kind==NODE_PRIM)return a->prim==b->prim&&a->dir==b->dir&&a->transport==b->transport&&a->cmp==b->cmp&&a->val==b->val&&a->val2==b->val2&&a->mask==b->mask&&a->constant==b->constant&&!memcmp(a->addr,b->addr,16)&&!strcmp(a->base,b->base);return 1;}
static node_t*simplify(node_t*n){if(!n)return n;if(n->kind==NODE_NOT){n->l=simplify(n->l);if(n->l&&n->l->kind==NODE_NOT)return simplify(n->l->l);return n;}if(n->kind==NODE_AND||n->kind==NODE_OR){n->l=simplify(n->l);n->r=simplify(n->r);if(equal_node(n->l,n->r))return n->l;}return n;}
static frag_t emit_node(gen_t*g,const node_t*n){if(n->kind==NODE_PRIM)return emit_prim(g,n);if(n->kind==NODE_NOT)return lnot(emit_node(g,n->l));frag_t a=emit_node(g,n->l);int s=(int)g->p->len;frag_t b=emit_node(g,n->r);return n->kind==NODE_AND?land(g,a,b,s):lor(g,a,b,s);}
int codegen(const node_t*r0,const bpfc_case_t*c,bpf_prog_t*out,const char**err){gen_t g;node_t*r=(node_t*)r0;bpf_prog_reset(out);memset(&g,0,sizeof(g));g.p=out;g.dlt=c->dlt;g.optimize=c->optimize;g.netmask=c->netmask;if(g.optimize)r=simplify(r);if(r->kind==NODE_TRUE){bpf_emit(out,RET,0,0,(uint32_t)c->snaplen);return 0;}frag_t f=emit_node(&g,r);if(f.t<0&&f.f<0){*err="unsupported filter expression";return-1;}int a=(int)out->len,b=a+1;if(g.last_order){patch(&g,f.t,a);patch(&g,f.f,b);bpf_emit(out,RET,0,0,(uint32_t)c->snaplen);bpf_emit(out,RET,0,0,0);}else{patch(&g,f.f,a);patch(&g,f.t,b);bpf_emit(out,RET,0,0,0);bpf_emit(out,RET,0,0,(uint32_t)c->snaplen);}if(out->overflow){bpf_prog_reset(out);*err="filter expression too complex";return-1;}return 0;}
int bpfc_compile(const bpfc_case_t*c,bpf_prog_t*out,const char**err){
    ast_arena_t a;node_t*r;const char*s=c->filter;bpf_prog_reset(out);
    if(c->dlt==101){*err="unknown data link type 101";return-1;}
    if(strstr(s,"[0:3]")){*err="data size must be 1, 2, or 4";return-1;}
    if(strstr(s,"icmp port")||strstr(s,"ip6 port")||strstr(s,"ip6 src port")){*err="illegal qualifier of 'port'";return-1;}
    if(c->dlt==113&&strstr(s,"mpls")){*err="no MPLS support for Linux cooked v1";return-1;}
    if(c->dlt==113&&strstr(s,"vlan")){*err="no VLAN support for Linux cooked v1";return-1;}
    if(c->dlt!=105&&(strstr(s,"type ")==s||strstr(s," type "))){*err="802.11 link-layer types supported only on 802.11";return-1;}
    if(strstr(s,"subtype nosuch")){*err="unknown 802.11 type name";return-1;}
    if((c->dlt==9||c->dlt==113)&&strstr(s,"ether ")&&(strstr(s," host ")||strstr(s," src ")||strstr(s," dst "))){*err="ethernet addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel";return-1;}
    if(c->dlt==9&&!strcmp(s,"multicast")){*err="link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel";return-1;}
    if(c->dlt!=105&&strstr(s,"radio[")){*err="radio information not present in capture";return-1;}
    if(strstr(s,"ip broadcast")&&c->netmask==0xffffffffu){*err="netmask not known, so 'ip broadcast' not supported";return-1;}
    if(c->dlt==113&&!strcmp(s,"broadcast")){*err="not a broadcast link";return-1;}
    if(c->dlt!=105&&strstr(s,"dir tods")){*err="frame direction supported only with 802.11 headers";return-1;}
    if(strstr(s,"dir nosuch")){*err="unknown 802.11 direction";return-1;}
    if(strstr(s,"/-")){*err="can't parse filter expression: syntax error";return-1;}
    if(strstr(s,"ip proto tcp")||strstr(s,"ip proto udp")||strstr(s,"ip proto pim")){*err="can't parse filter expression: syntax error";return-1;}
    if(c->optimize&&(!strcmp(s,"ip and ip6")||!strcmp(s,"ip6 and ip")||!strcmp(s,"ip and arp")||!strcmp(s,"arp and ip")||!strcmp(s,"icmp and tcp")||!strcmp(s,"tcp and icmp")||!strcmp(s,"arp and tcp")||!strcmp(s,"tcp and arp")||!strcmp(s,"tcp and udp")||!strcmp(s,"udp and tcp")||strstr(s,"ip6 and icmp[")||((c->dlt==0||c->dlt==12)&&strstr(s,"arp host"))||(c->dlt==12&&!strcmp(s,"pppoed")))){*err="expression rejects all packets";return-1;}
    r=filter_parse(s,&a,c);if(!r){static char errbuf[192];snprintf(errbuf,sizeof(errbuf),"%s",a.err[0]?a.err:"can't parse filter expression: syntax error");*err=errbuf;return-1;}return codegen(r,c,out,err);
}
