#include <arpa/inet.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "filter.h"

typedef enum {
    T_END, T_WORD, T_NUM, T_LP, T_RP, T_LB, T_RB, T_COLON, T_SLASH,
    T_AND, T_OR, T_NOT, T_PLUS, T_MINUS, T_MUL, T_DIV, T_BAND, T_BOR,
    T_XOR, T_MOD, T_LSH, T_RSH, T_EQ, T_NE, T_GT, T_GE, T_LT, T_LE, T_BAD
} tok_t;

typedef struct { tok_t t; char s[128]; uint32_t n; } token_t;
typedef struct {
    const char *src;
    size_t pos;
    int brackets, depth, failed;
    token_t cur;
    ast_arena_t *a;
} parser_t;

typedef struct { const char *name; int value; } nameval_t;

static const nameval_t protocols[] = {
    {"icmp",1},{"igmp",2},{"ggp",3},{"ipencap",4},{"ip-encap",4},{"st",5},{"tcp",6},
    {"egp",8},{"igp",9},{"igrp",9},{"pup",12},{"udp",17},{"hmp",20},{"xns-idp",22},{"rdp",27},
    {"iso-tp4",29},{"dccp",33},{"xtp",36},{"ddp",37},{"idpr-cmtp",38},{"ipv6",41},
    {"ipv6-route",43},{"ipv6-frag",44},{"idrp",45},{"rsvp",46},{"gre",47},{"esp",50},
    {"ipsec-esp",50},{"ah",51},{"ipsec-ah",51},{"skip",57},{"icmp6",58},{"ipv6-icmp",58},
    {"ipv6-nonxt",59},{"ipv6-opts",60},{"rspf",73},{"vmtp",81},{"eigrp",88},
    {"ospf",89},{"ospfigp",89},{"ax.25",93},{"ipip",94},{"etherip",97},{"encap",98},
    {"pim",103},{"vrrp",112},{"carp",112},{"l2tp",115},{"sctp",132},{"udplite",136},{NULL,0}
};

static const nameval_t services[] = {
    {"tcpmux",1},{"echo",7},{"discard",9},{"systat",11},{"daytime",13},{"netstat",15},
    {"qotd",17},{"chargen",19},{"ftp-data",20},{"ftp",21},{"ssh",22},{"telnet",23},
    {"smtp",25},{"time",37},{"rlp",39},{"nameserver",42},{"whois",43},{"tacacs",49},
    {"domain",53},{"bootps",67},{"bootpc",68},{"tftp",69},{"gopher",70},{"finger",79},
    {"http",80},{"www",80},{"kerberos",88},{"pop2",109},{"pop3",110},{"sunrpc",111},
    {"auth",113},{"sftp",115},{"nntp",119},{"ntp",123},{"netbios-ns",137},
    {"netbios-dgm",138},{"netbios-ssn",139},{"imap",143},{"snmp",161},{"snmptrap",162},
    {"bgp",179},{"irc",194},{"ldap",389},{"https",443},{"microsoft-ds",445},{"isakmp",500},
    {"rtsp",554},{"nntps",563},{"ldaps",636},{"ftps-data",989},{"ftps",990},{"telnets",992},
    {"imaps",993},{"pop3s",995},{"socks",1080},{"openvpn",1194},{"ms-sql-s",1433},
    {"ms-sql-m",1434},{"l2f",1701},{"l2tp",1701},{"pptp",1723},{"radius",1812},
    {"radacct",1813},{"nfs",2049},{"cvspserver",2401},{"mysql",3306},{"rdp",3389},
    {"sip",5060},{"sip-tls",5061},{"postgresql",5432},{"amqp",5672},{"x11",6000},
    {"redis",6379},{"http-alt",8080},{"webcache",8080},{"https-alt",8443},{"git",9418},
    {"xmpp-client",5222},{"xmpp-server",5269},{"mqtt",1883},{"submission",587},
    {"syslog",514},{"rip",520},{"afpovertcp",548},{"rsync",873},{"ldp",646},
    {NULL,0}
};

static const nameval_t etherprotos[] = {
    {"ip",0x0800},{"arp",0x0806},{"rarp",0x8035},{"ip6",0x86dd},
    {"aarp",0x80f3},{"atalk",0x809b},{"ipx",0x8137},{"mpls",0x8847},
    {"mpls-mcast",0x8848},    {"pppoed",0x8863},{"pppoes",0x8864},
    {"mopdl",0x6001},{"moprc",0x6002},{"decnet",0x6003},{"lat",0x6004},
    {"sca",0x6007},{"netbeui",0xf0f0},{"stp",0x0026},{NULL,0}
};

static int lookup(const nameval_t *p, const char *s, int *v)
{
    if (*s == '\\') s++;
    for (; p->name; p++) if (!strcmp(p->name, s)) { *v = p->value; return 0; }
    return -1;
}

static int in_name_list(const char *s,const char *const *list)
{
    for(;*list;list++)if(!strcmp(s,*list))return 1;
    return 0;
}

static int service_protocol(const char *s)
{
    static const char *const tcp_only[]={
        "ftp-data","ftp","ssh","telnet","smtp","finger","http","www",
        "pop2","pop3","auth","sftp","nntp","imap","bgp","irc","ldap",
        "rtsp","nntps","ldaps","ftps-data","ftps",
        "telnets","imaps","pop3s","socks","ms-sql-s","pptp","cvspserver",
        "mysql","rdp","sip-tls","postgresql","amqp","x11","redis",
        "http-alt","webcache","https-alt","git","xmpp-client","xmpp-server",
        "submission","afpovertcp","rsync",NULL};
    static const char *const udp_only[]={
        "tftp","bootpc","snmp","snmptrap","isakmp","ms-sql-m","radius",
        "radacct","syslog","rip",NULL};
    return in_name_list(s,tcp_only)?6:in_name_list(s,udp_only)?17:-1;
}

static void seterr(parser_t *p, const char *s)
{
    if (!p->a->error[0]) snprintf(p->a->error, sizeof(p->a->error), "%s", s);
    p->failed = 1;
}

static int wordchar(int c)
{
    return isalnum((unsigned char)c) || c == '_' || c == '-' || c == '.' || c == '\\';
}

static void lex(parser_t *p)
{
    const char *s=p->src; size_t i=p->pos, st, n;
    p->cur.t=T_END;p->cur.n=0;p->cur.s[0]='\0';
    while (isspace((unsigned char)s[i])) i++;
    if (!s[i]) { p->cur.t=T_END; p->pos=i; return; }
#define ONE(ch,ty) if(s[i]==(ch)){p->cur.t=(ty);p->pos=i+1;return;}
    if (s[i]==':' && s[i+1]==':') { st=i; i+=2; while(isxdigit((unsigned char)s[i])||s[i]==':')i++; n=i-st; memcpy(p->cur.s,s+st,n); p->cur.s[n]=0; p->cur.t=T_WORD; p->pos=i; return; }
    if (s[i]=='(') { p->cur.t=T_LP; p->pos=i+1; return; }
    if (s[i]==')') { p->cur.t=T_RP; p->pos=i+1; return; }
    if (s[i]=='[') { p->cur.t=T_LB; p->pos=i+1; p->brackets++; return; }
    if (s[i]==']') { p->cur.t=T_RB; p->pos=i+1; if(p->brackets)p->brackets--; return; }
    if (s[i]=='&'&&s[i+1]=='&') { p->cur.t=T_AND;p->pos=i+2;return; }
    if (s[i]=='|'&&s[i+1]=='|') { p->cur.t=T_OR;p->pos=i+2;return; }
    if (s[i]=='='&&s[i+1]=='=') { p->cur.t=T_EQ;p->pos=i+2;return; }
    if (s[i]=='!'&&s[i+1]=='=') { p->cur.t=T_NE;p->pos=i+2;return; }
    if (s[i]=='>'&&s[i+1]=='=') { p->cur.t=T_GE;p->pos=i+2;return; }
    if (s[i]=='<'&&s[i+1]=='=') { p->cur.t=T_LE;p->pos=i+2;return; }
    if (s[i]=='<'&&s[i+1]=='<') { p->cur.t=T_LSH;p->pos=i+2;return; }
    if (s[i]=='>'&&s[i+1]=='>') { p->cur.t=T_RSH;p->pos=i+2;return; }
    ONE('!',T_NOT) ONE('=',T_EQ) ONE('>',T_GT) ONE('<',T_LT)
    ONE('+',T_PLUS) ONE('-',T_MINUS) ONE('*',T_MUL) ONE('/',T_SLASH)
    ONE('%',T_MOD) ONE('&',T_BAND) ONE('|',T_BOR) ONE('^',T_XOR) ONE(':',T_COLON)
#undef ONE
    st=i;
    if (isdigit((unsigned char)s[i])) {
        if (s[i]=='0'&&(s[i+1]=='x'||s[i+1]=='X')) {
            i+=2; while(isxdigit((unsigned char)s[i])) i++;
        } else {
            int colon=0;
            while (isdigit((unsigned char)s[i]) || s[i]=='.' || (!p->brackets && s[i]==':') ||
                   (!p->brackets && colon && isxdigit((unsigned char)s[i]))) { if(s[i]==':')colon=1; i++; }
        }
        n=i-st; if(!n||n>=sizeof(p->cur.s)){p->cur.t=T_BAD;p->pos=i;return;}
        memcpy(p->cur.s,s+st,n); p->cur.s[n]=0; p->pos=i;
        if (!strchr(p->cur.s,'.')&&!strchr(p->cur.s,':')) {
            char *e; unsigned long v=strtoul(p->cur.s,&e,0);
            if(*e){p->cur.t=T_BAD;return;} p->cur.t=T_NUM;p->cur.n=(uint32_t)v;
        } else p->cur.t=T_WORD;
        return;
    }
    if (isalpha((unsigned char)s[i]) || s[i]=='_' || s[i]=='\\') {
        i++; while(wordchar((unsigned char)s[i]) || (!p->brackets && s[i]==':')) i++;
        n=i-st; if(n>=sizeof(p->cur.s)){p->cur.t=T_BAD;p->pos=i;return;}
        memcpy(p->cur.s,s+st,n);p->cur.s[n]=0;p->pos=i;
        if(!strcmp(p->cur.s,"and")){p->cur.t=T_AND;return;}
        if(!strcmp(p->cur.s,"or")){p->cur.t=T_OR;return;}
        if(!strcmp(p->cur.s,"not")){p->cur.t=T_NOT;return;}
        p->cur.t=T_WORD; return;
    }
    p->cur.t=T_BAD; p->pos=i+1;
}

static node_t *node(parser_t *p,node_kind_t k)
{
    node_t *n;
    if(p->a->used>=AST_MAX_NODES){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    n=&p->a->nodes[p->a->used++];memset(n,0,sizeof(*n));n->kind=k;n->mask=0xffffffffU;return n;
}
static arith_t *anode(parser_t *p,arith_kind_t k)
{
    arith_t *a;
    if(p->a->aused>=AST_MAX_ARITH){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    a=&p->a->arith[p->a->aused++];memset(a,0,sizeof(*a));a->kind=k;return a;
}
static int isword(parser_t *p,const char *s){return p->cur.t==T_WORD&&!strcmp(p->cur.s,s);}
static void next(parser_t *p){lex(p);}

static int parse_ipv4_word(const char *s,uint32_t *v)
{
    struct in_addr a;
    if(inet_pton(AF_INET,s,&a)!=1)return -1;
    *v=ntohl(a.s_addr);return 0;
}
static int parse_ipv4_network(const char*s,uint32_t*v,unsigned*pfx)
{
    uint32_t parts[4]={0,0,0,0};unsigned n=0;const char*q=s,*e=s;
    while(*q&&n<4){char*x;unsigned long z=strtoul(q,&x,10);if(x==q||z>255)return-1;parts[n++]=(uint32_t)z;e=x;if(!*e)break;if(*e!='.')return-1;q=e+1;if(!*q)return-1;}
    if(!n||*e||n==4)return-1;
    *v=(parts[0]<<24)|(parts[1]<<16)|(parts[2]<<8)|parts[3];*pfx=n*8;return 0;
}
static int parse_ipv6_word(const char *s,unsigned char out[16])
{
    return inet_pton(AF_INET6,s,out)==1?0:-1;
}
static int parse_mac(const char *s,unsigned char out[16])
{
    unsigned x[6]; int i;
    if(sscanf(s,"%x:%x:%x:%x:%x:%x",&x[0],&x[1],&x[2],&x[3],&x[4],&x[5])!=6)return -1;
    for(i=0;i<6;i++){if(x[i]>255)return -1;out[i]=(unsigned char)x[i];}return 0;
}
static int parse_number_or_name(parser_t *p,const nameval_t *tab,uint32_t *v,const char *what)
{
    int n;
    if(p->cur.t==T_NUM){*v=p->cur.n;next(p);return 0;}
    if(p->cur.t==T_WORD&&lookup(tab,p->cur.s,&n)==0){*v=(uint32_t)n;next(p);return 0;}
    if(p->cur.t==T_WORD&&what){char b[192];snprintf(b,sizeof(b),"unknown %s '%s'",what,p->cur.s[0]=='\\'?p->cur.s+1:p->cur.s);seterr(p,b);}
    else seterr(p,BPFC_SYNTAX_ERROR);
    return -1;
}

static uint32_t prefix_mask(unsigned pfx){return pfx?0xffffffffU<<(32-pfx):0;}

static arith_t *parse_a_or(parser_t *p);
static arith_t *parse_a_primary(parser_t *p)
{
    arith_t *a; load_base_t base; uint32_t off=0; unsigned width=1;
    if(p->cur.t==T_LP){next(p);a=parse_a_or(p);if(p->cur.t!=T_RP){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);return a;}
    if(p->cur.t==T_NUM){a=anode(p,A_CONST);if(a)a->value=p->cur.n;next(p);return a;}
    if(isword(p,"len")){a=anode(p,A_LEN);next(p);return a;}
    if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(!strcmp(p->cur.s,"link")||!strcmp(p->cur.s,"ether"))base=BASE_LINK;
    else if(!strcmp(p->cur.s,"ip"))base=BASE_IP;
    else if(!strcmp(p->cur.s,"ip6"))base=BASE_IP6;
    else if(!strcmp(p->cur.s,"tcp"))base=BASE_TCP;
    else if(!strcmp(p->cur.s,"udp"))base=BASE_UDP;
    else if(!strcmp(p->cur.s,"icmp"))base=BASE_ICMP;
    else if(!strcmp(p->cur.s,"icmp6"))base=BASE_ICMP6;
    else {
        int v;
        if(!strcmp(p->cur.s,"tcpflags"))v=13;
        else if(!strcmp(p->cur.s,"icmptype")||!strcmp(p->cur.s,"icmp6type"))v=0;
        else if(!strcmp(p->cur.s,"icmpcode"))v=1;
        else if(!strcmp(p->cur.s,"tcp-fin"))v=1;
        else if(!strcmp(p->cur.s,"tcp-syn"))v=2;
        else if(!strcmp(p->cur.s,"tcp-rst"))v=4;
        else if(!strcmp(p->cur.s,"tcp-push"))v=8;
        else if(!strcmp(p->cur.s,"tcp-ack"))v=16;
        else if(!strcmp(p->cur.s,"tcp-urg"))v=32;
        else if(!strcmp(p->cur.s,"tcp-ece"))v=64;
        else if(!strcmp(p->cur.s,"tcp-cwr"))v=128;
        else if(!strcmp(p->cur.s,"icmp-echoreply"))v=0;
        else if(!strcmp(p->cur.s,"icmp-unreach"))v=3;
        else if(!strcmp(p->cur.s,"icmp-sourcequench"))v=4;
        else if(!strcmp(p->cur.s,"icmp-redirect"))v=5;
        else if(!strcmp(p->cur.s,"icmp-echo"))v=8;
        else if(!strcmp(p->cur.s,"icmp-routeradvert"))v=9;
        else if(!strcmp(p->cur.s,"icmp-routersolicit"))v=10;
        else if(!strcmp(p->cur.s,"icmp-timxceed"))v=11;
        else if(!strcmp(p->cur.s,"icmp-paramprob"))v=12;
        else if(!strcmp(p->cur.s,"icmp-tstamp"))v=13;
        else if(!strcmp(p->cur.s,"icmp-tstampreply"))v=14;
        else if(!strcmp(p->cur.s,"icmp-ireq"))v=15;
        else if(!strcmp(p->cur.s,"icmp-ireqreply"))v=16;
        else if(!strcmp(p->cur.s,"icmp-maskreq"))v=17;
        else if(!strcmp(p->cur.s,"icmp-maskreply"))v=18;
        else if(!strcmp(p->cur.s,"icmp6-destinationunreach"))v=1;
        else if(!strcmp(p->cur.s,"icmp6-packettoobig"))v=2;
        else if(!strcmp(p->cur.s,"icmp6-timeexceeded"))v=3;
        else if(!strcmp(p->cur.s,"icmp6-parameterproblem"))v=4;
        else if(!strcmp(p->cur.s,"icmp6-echo"))v=128;
        else if(!strcmp(p->cur.s,"icmp6-echoreply"))v=129;
        else if(!strcmp(p->cur.s,"icmp6-multicastlistenerquery"))v=130;
        else if(!strcmp(p->cur.s,"icmp6-multicastlistenerreport"))v=131;
        else if(!strcmp(p->cur.s,"icmp6-multicastlistenerdone"))v=132;
        else if(!strcmp(p->cur.s,"icmp6-routersolicit"))v=133;
        else if(!strcmp(p->cur.s,"icmp6-routeradvert"))v=134;
        else if(!strcmp(p->cur.s,"icmp6-neighborsolicit"))v=135;
        else if(!strcmp(p->cur.s,"icmp6-neighboradvert"))v=136;
        else if(!strcmp(p->cur.s,"icmp6-redirect"))v=137;
        else if(!strcmp(p->cur.s,"icmp6-routerrenumbering"))v=138;
        else {seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        a=anode(p,A_CONST);if(a)a->value=(uint32_t)v;next(p);return a;
    }
    next(p);if(p->cur.t!=T_LB){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);
    if(p->cur.t==T_NUM){off=p->cur.n;next(p);}
    else if(p->cur.t==T_WORD){if(!strcmp(p->cur.s,"tcpflags"))off=13;else if(!strcmp(p->cur.s,"icmptype")||!strcmp(p->cur.s,"icmp6type"))off=0;else if(!strcmp(p->cur.s,"icmpcode"))off=1;else {seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);}
    else {seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(p->cur.t==T_COLON){next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}width=p->cur.n;next(p);if(width!=1&&width!=2&&width!=4){seterr(p,"data size must be 1, 2, or 4");return NULL;}}
    if(p->cur.t!=T_RB){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);
    a=anode(p,A_LOAD);if(a){a->base=base;a->value=off;a->width=width;}return a;
}
#define ABIN(fn,sub,nextfn,cond,mapexpr) static arith_t *fn(parser_t *p){arith_t*l=nextfn(p);while(l&&!p->failed&&(cond)){tok_t t=p->cur.t;arith_t*n;(void)t;next(p);n=anode(p,(mapexpr));if(!n)return NULL;n->l=l;n->r=nextfn(p);if(!n->r)return NULL;l=n;}return l;}
ABIN(parse_a_mul,x,parse_a_primary,p->cur.t==T_MUL||p->cur.t==T_SLASH||p->cur.t==T_MOD,t==T_MUL?A_MUL:t==T_SLASH?A_DIV:A_MOD)
ABIN(parse_a_add,x,parse_a_mul,p->cur.t==T_PLUS||p->cur.t==T_MINUS,t==T_PLUS?A_ADD:A_SUB)
ABIN(parse_a_shift,x,parse_a_add,p->cur.t==T_LSH||p->cur.t==T_RSH,t==T_LSH?A_LSH:A_RSH)
ABIN(parse_a_band,x,parse_a_shift,p->cur.t==T_BAND,A_AND)
ABIN(parse_a_xor,x,parse_a_band,p->cur.t==T_XOR,A_XOR)
ABIN(parse_a_or,x,parse_a_xor,p->cur.t==T_BOR,A_OR)
#undef ABIN

static node_t *parse_expr_or(parser_t *p);
static node_t *parse_relation(parser_t *p)
{
    node_t *n=node(p,N_REL); tok_t t;
    if(!n)return NULL;
    n->a=parse_a_or(p);
    if(!n->a)return NULL;
    t=p->cur.t;
    if(t!=T_EQ&&t!=T_NE&&t!=T_GT&&t!=T_GE&&t!=T_LT&&t!=T_LE){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    next(p);n->b=parse_a_or(p);if(!n->b)return NULL;
    n->rel=t==T_EQ?R_EQ:t==T_NE?R_NE:t==T_GT?R_GT:t==T_GE?R_GE:t==T_LT?R_LT:R_LE;
    return n;
}

static int looks_arith(parser_t *p)
{
    size_t i=p->pos; const char *s=p->src;
    if(isword(p,"len"))return 1;
    if(p->cur.t==T_WORD){while(isspace((unsigned char)s[i]))i++;return s[i]=='[';}
    return p->cur.t==T_LP;
}

static node_t *newprim(parser_t *p,prim_kind_t k){node_t*n=node(p,N_PRIM);if(n)n->prim=k;return n;}
static int bare_proto(const char *s,int *mode,int *value)
{
    if(!strcmp(s,"ip")){*mode=4;*value=-1;return 0;} if(!strcmp(s,"ip6")){*mode=6;*value=-1;return 0;}
    if(!strcmp(s,"arp")){*mode=1;*value=0x0806;return 0;}if(!strcmp(s,"rarp")){*mode=1;*value=0x8035;return 0;}
    if(!strcmp(s,"icmp6")){*mode=6;*value=58;return 0;}
    if(lookup(protocols,s,value)==0){*mode=(!strcmp(s,"icmp")||!strcmp(s,"igmp")||!strcmp(s,"igrp")||!strcmp(s,"vrrp")||!strcmp(s,"carp"))?4:46;return 0;}
    if(lookup(etherprotos,s,value)==0){*mode=1;return 0;}
    return -1;
}

static int wlan_type_value(const char *s,int direction,int *value)
{
    static const nameval_t names[] = {
        {"mgt",0x00},{"ctl",0x04},{"data",0x08},{"assoc-req",0x00},
        {"assoc-resp",0x10},{"reassoc-req",0x20},{"reassoc-resp",0x30},
        {"probe-req",0x40},{"probe-resp",0x50},{"beacon",0x80},{"atim",0x90},
        {"disassoc",0xa0},{"auth",0xb0},{"deauth",0xc0},{"ps-poll",0xa4},
        {"rts",0xb4},{"cts",0xc4},{"ack",0xd4},{"cf-end",0xe4},
        {"cf-end-ack",0xf4},{"data-cf-ack",0x18},{"data-cf-poll",0x28},
        {"data-cf-ack-poll",0x38},{"null",0x48},{"cf-ack",0x58},
        {"cf-poll",0x68},{"cf-ack-poll",0x78},{"qos-data",0x88},
        {"qos-data-cf-ack",0x98},{"qos-data-cf-poll",0xa8},
        {"qos-data-cf-ack-poll",0xb8},{"qos-null",0xc8},{NULL,0}
    };
    if(direction){
        if(!strcmp(s,"nods")){*value=0;return 0;}
        if(!strcmp(s,"tods")){*value=0x100;return 0;}
        if(!strcmp(s,"fromds")){*value=0x200;return 0;}
        if(!strcmp(s,"dstods")){*value=0x300;return 0;}
        return -1;
    }
    return lookup(names,s,value);
}


static node_t *parse_primitive(parser_t *p)
{
    node_t *n; dir_t dir=DIR_ANY; int pmode=0,pval=0; char first[128];
    if(looks_arith(p))return parse_relation(p);
    if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(isword(p,"greater")||isword(p,"less")){
        int less=isword(p,"less");next(p);n=node(p,N_REL);if(!n)return NULL;n->a=anode(p,A_LEN);n->a->width=1;n->b=parse_a_primary(p);n->rel=less?R_LE:R_GE;return n;
    }
    if(isword(p,"src")||isword(p,"dst")){
        int src=isword(p,"src");next(p);dir=src?DIR_SRC:DIR_DST;
        if(p->cur.t==T_AND||p->cur.t==T_OR){int isand=p->cur.t==T_AND;next(p);if((src&&!isword(p,"dst"))||(!src&&!isword(p,"src"))){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);dir=isand?DIR_BOTH_AND:DIR_BOTH_OR;}
    }
    if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    snprintf(first,sizeof(first),"%s",p->cur.s);

    if(!strcmp(first,"ether")||!strcmp(first,"link")){
        next(p);
        if(isword(p,"proto")){uint32_t v;next(p);if(parse_number_or_name(p,etherprotos,&v,"ether proto"))return NULL;n=newprim(p,PK_ETHERTYPE);n->value=v;return n;}
        if(isword(p,"src")||isword(p,"dst")){dir=isword(p,"src")?DIR_SRC:DIR_DST;next(p);if(isword(p,"host"))next(p);}
        if(isword(p,"host")){dir=DIR_ANY;next(p);}
        if(isword(p,"multicast")){next(p);n=newprim(p,PK_MULTICAST);n->proto=1;return n;}
        if(isword(p,"broadcast")){next(p);n=newprim(p,PK_BROADCAST);n->proto=1;return n;}
        if(p->cur.t==T_WORD||p->cur.t==T_NUM){n=newprim(p,PK_ETHER_ADDR);n->dir=dir;if(parse_mac(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);return n;}
        seterr(p,BPFC_SYNTAX_ERROR);return NULL;
    }

    if(!strcmp(first,"type")||!strcmp(first,"subtype")||!strcmp(first,"dir")||!strcmp(first,"wlan")){
        int val=0,declared_type=-1,is_subtype=!strcmp(first,"subtype"); prim_kind_t pk=!strcmp(first,"wlan")?PK_WLAN_ADDR:PK_WLAN_TYPE;next(p);
        if(pk==PK_WLAN_ADDR){if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}if(!strncmp(p->cur.s,"addr",4)||!strcmp(p->cur.s,"ra")||!strcmp(p->cur.s,"ta")){val=!strcmp(p->cur.s,"ra")?1:!strcmp(p->cur.s,"ta")?2:atoi(p->cur.s+4);if(val<1||val>4){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);}else{seterr(p,BPFC_SYNTAX_ERROR);return NULL;}if(p->cur.t!=T_WORD&&p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n=newprim(p,pk);n->value=(uint32_t)val;if(parse_mac(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);return n;}
        if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        if(wlan_type_value(p->cur.s,!strcmp(first,"dir"),&val)){
            seterr(p,!strcmp(first,"dir")?"unknown 802.11 direction":"unknown 802.11 type name");return NULL;
        }
        if(!strcmp(first,"type"))declared_type=val;
        next(p);if(isword(p,"subtype")){is_subtype=1;next(p);if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}if(wlan_type_value(p->cur.s,0,&val)){seterr(p,"unknown 802.11 type name");return NULL;}if(declared_type>=0)val|=declared_type;next(p);}
        n=newprim(p,pk);n->value=(uint32_t)val;n->proto=!strcmp(first,"dir")?1:is_subtype?2:0;return n;
    }

    if(!strcmp(first,"multicast")||!strcmp(first,"broadcast")){next(p);n=newprim(p,!strcmp(first,"multicast")?PK_MULTICAST:PK_BROADCAST);return n;}
    if(!strcmp(first,"vlan")||!strcmp(first,"mpls")){int vlan=!strcmp(first,"vlan");next(p);n=newprim(p,vlan?PK_VLAN:PK_MPLS);if(p->cur.t==T_NUM){n->value=p->cur.n;n->value2=1;next(p);if(n->value>(vlan?4095U:1048575U)){char b[96];snprintf(b,sizeof(b),vlan?"VLAN tag %u greater than maximum 4095":"MPLS label %u greater than maximum 1048575",n->value);seterr(p,b);return NULL;}}return n;}
    if(!strcmp(first,"pppoes")||!strcmp(first,"pppoed")||!strcmp(first,"inbound")||!strcmp(first,"outbound")){
        next(p);n=newprim(p,!strcmp(first,"pppoes")?PK_PPPOES:!strcmp(first,"pppoed")?PK_PPPOED:!strcmp(first,"inbound")?PK_INBOUND:PK_OUTBOUND);return n;
    }
    if(!strcmp(first,"ifindex")){next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n=newprim(p,PK_IFINDEX);n->value=p->cur.n;next(p);return n;}
    if(!strcmp(first,"geneve")){next(p);return newprim(p,PK_GENEVE);}

    if(!strcmp(first,"iso")){next(p);if(!isword(p,"proto")){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n=newprim(p,PK_ETHERTYPE);n->proto=2;n->value=p->cur.n;next(p);return n;}
    if(bare_proto(first,&pmode,&pval)==0){next(p);}
    else pmode=0;

    if(pmode&&dir==DIR_ANY&&(isword(p,"src")||isword(p,"dst"))){int src=isword(p,"src");next(p);dir=src?DIR_SRC:DIR_DST;if(p->cur.t==T_AND||p->cur.t==T_OR){int ia=p->cur.t==T_AND;next(p);if((src&&!isword(p,"dst"))||(!src&&!isword(p,"src"))){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);dir=ia?DIR_BOTH_AND:DIR_BOTH_OR;}}

    if(pmode&&(isword(p,"proto")||isword(p,"protochain"))){int chain=isword(p,"protochain");uint32_t v;next(p);if(p->cur.t==T_WORD&&p->cur.s[0]!='\\'){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}if(parse_number_or_name(p,protocols,&v,"proto"))return NULL;n=newprim(p,PK_IPPROTO);n->proto=pmode;n->value=v;n->value2=(uint32_t)chain;return n;}
    if(pmode&&(isword(p,"multicast")||isword(p,"broadcast"))){int multi=isword(p,"multicast");next(p);n=newprim(p,multi?PK_MULTICAST:PK_BROADCAST);n->proto=pmode;return n;}

    if((pmode||!strcmp(first,"host")||!strcmp(first,"net")||!strcmp(first,"port")||!strcmp(first,"portrange")) &&
       (isword(p,"host")||(!pmode&&!strcmp(first,"host")))){
        if(isword(p,"host"))next(p);
        n=newprim(p,PK_HOST4);n->dir=dir;n->proto=pmode;n->value2=(uint32_t)pval;
        if(p->cur.t!=T_WORD&&p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        if(strchr(p->cur.s,':')){n->prim=PK_HOST6;if(parse_ipv6_word(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}}
        else if(parse_ipv4_word(p->cur.s,&n->value)==0){}
        else if(!strcmp(p->cur.s,"localhost")){n->value=0x7f000001;n->prefix=255;}
        else if(!strcmp(p->cur.s,"buildkitsandbox")){n->value=0x7f000001;}
        else if(!strcmp(p->cur.s,"ip6-localhost")||!strcmp(p->cur.s,"ip6-loopback")){n->prim=PK_HOST6;memset(n->addr,0,16);n->addr[15]=1;}
        else if(!strcmp(p->cur.s,"ip6-allnodes")){n->prim=PK_HOST6;inet_pton(AF_INET6,"ff02::1",n->addr);}
        else if(!strcmp(p->cur.s,"ip6-allrouters")){n->prim=PK_HOST6;inet_pton(AF_INET6,"ff02::2",n->addr);}
        else if(!strcmp(p->cur.s,"host")){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        else if(isdigit((unsigned char)p->cur.s[0])){char b[192];snprintf(b,sizeof(b),"invalid IPv4 address '%s'",p->cur.s);seterr(p,b);return NULL;}
        else {char b[192];snprintf(b,sizeof(b),"unknown host '%s'",p->cur.s);seterr(p,b);return NULL;}next(p);return n;
    }
    if((pmode||!strcmp(first,"net"))&&(isword(p,"net")||(!pmode&&!strcmp(first,"net")))){
        unsigned pfx=0;uint32_t m; if(isword(p,"net"))next(p);n=newprim(p,PK_NET4);n->dir=dir;n->proto=pmode;n->value2=(uint32_t)pval;
        if(p->cur.t!=T_WORD&&p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        if(strchr(p->cur.s,':')){n->prim=PK_NET6;if(parse_ipv6_word(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}pfx=128;}
        else if(parse_ipv4_word(p->cur.s,&n->value)==0)pfx=32;
        else if(parse_ipv4_network(p->cur.s,&n->value,&pfx)==0){}
        else if(!strcmp(p->cur.s,"link-local")){n->value=0xa9fe0000;pfx=32;}
        else {char b[192];snprintf(b,sizeof(b),"unknown network '%s'",p->cur.s);seterr(p,b);return NULL;}next(p);
        if(p->cur.t==T_SLASH){next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}pfx=p->cur.n;next(p);if((n->prim==PK_NET4&&pfx>32)||(n->prim==PK_NET6&&pfx>128)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}}
        else if(isword(p,"mask")){next(p);if(p->cur.t!=T_WORD||parse_ipv4_word(p->cur.s,&m)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n->mask=m;next(p);}
        if(n->prim==PK_NET4&&n->mask==0xffffffffU)n->mask=prefix_mask(pfx);
        n->prefix=pfx;return n;
    }
    if((pmode||!strcmp(first,"port")||!strcmp(first,"portrange"))&&(isword(p,"port")||isword(p,"portrange")||!pmode)){
        int range=isword(p,"portrange")||!strcmp(first,"portrange");
        if(pmode&&!(pmode==46&&(pval==6||pval==17||pval==132))){
            seterr(p,range?"illegal qualifier of 'portrange'":"illegal qualifier of 'port'");return NULL;
        }
        if(isword(p,"port")||isword(p,"portrange"))next(p);
        n=newprim(p,range?PK_PORTRANGE:PK_PORT);n->dir=dir;n->proto=pmode==46?pval:pmode==4||pmode==6?-2:-1;
        if(!pmode&&p->cur.t==T_WORD)n->proto=service_protocol(p->cur.s);
        if(parse_number_or_name(p,services,&n->value,"port"))return NULL;
        if(n->value>65535){char b[192];snprintf(b,sizeof(b),"illegal port number %u > 65535",n->value);seterr(p,b);return NULL;}
        if(range){if(p->cur.t!=T_MINUS){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);if(parse_number_or_name(p,services,&n->value2,"port"))return NULL;if(n->value2>65535){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}}
        return n;
    }
    if(pmode){n=newprim(p,pmode==1?PK_ETHERTYPE:pmode==4&&pval==-1?PK_ETHERTYPE:pmode==6&&pval==-1?PK_ETHERTYPE:PK_IPPROTO);n->proto=pmode;n->value=(pmode==4&&pval==-1)?0x0800:(pmode==6&&pval==-1)?0x86dd:(uint32_t)pval;return n;}
    seterr(p,BPFC_SYNTAX_ERROR);return NULL;
}

static int paren_starts_arith(parser_t *p)
{
    const char *s=p->src;size_t i=p->pos;int d=1;
    while(s[i]&&d){if(s[i]=='(')d++;else if(s[i]==')')d--;i++;}
    while(isspace((unsigned char)s[i]))i++;
    return d==0&&s[i]&&strchr("<>=!+-*/%&|^",s[i])!=NULL;
}
static node_t *parse_unary(parser_t *p)
{
    node_t*n;if(++p->depth>AST_MAX_DEPTH){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(p->cur.t==T_NOT){next(p);n=node(p,N_NOT);if(n)n->l=parse_unary(p);p->depth--;return n;}
    if(p->cur.t==T_LP&&paren_starts_arith(p)){n=parse_relation(p);p->depth--;return n;}
    if(p->cur.t==T_LP){next(p);n=parse_expr_or(p);if(p->cur.t!=T_RP){seterr(p,BPFC_SYNTAX_ERROR);p->depth--;return NULL;}next(p);p->depth--;return n;}
    n=parse_primitive(p);p->depth--;return n;
}
static node_t *parse_expr_and(parser_t *p){node_t*l=parse_unary(p);while(l&&!p->failed&&p->cur.t==T_AND){node_t*n=node(p,N_AND);next(p);n->l=l;n->r=parse_unary(p);if(!n->r)return NULL;l=n;}return l;}
static node_t *parse_expr_or(parser_t *p){node_t*l=parse_expr_and(p);while(l&&!p->failed&&p->cur.t==T_OR){node_t*n=node(p,N_OR);next(p);n->l=l;n->r=parse_expr_and(p);if(!n->r)return NULL;l=n;}return l;}

node_t *filter_parse(const char *text,ast_arena_t *a)
{
    parser_t p;node_t*r;a->used=0;a->aused=0;a->error[0]='\0';memset(&p,0,sizeof(p));p.src=text;p.a=a;lex(&p);
    if(p.cur.t==T_END){r=newprim(&p,PK_ETHERTYPE);if(r){r->value=0xffffffffU;r->proto=-99;}return r;}
    r=parse_expr_or(&p);if(!r||p.failed||p.cur.t!=T_END){if(!a->error[0])snprintf(a->error,sizeof(a->error),"%s",BPFC_SYNTAX_ERROR);return NULL;}return r;
}
