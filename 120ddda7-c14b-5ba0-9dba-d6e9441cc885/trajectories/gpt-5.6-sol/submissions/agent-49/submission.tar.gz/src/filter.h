#ifndef FILTER_H
#define FILTER_H

#include <stddef.h>
#include <stdint.h>

#include "bpf_defs.h"
#include "jsonio.h"

#define BPFC_SYNTAX_ERROR "can't parse filter expression: syntax error"

typedef enum { DIR_ANY, DIR_SRC, DIR_DST, DIR_BOTH_AND, DIR_BOTH_OR } dir_t;
typedef enum {
    PK_ETHERTYPE, PK_IPPROTO, PK_PROTO, PK_HOST4, PK_NET4, PK_HOST6, PK_NET6,
    PK_PORT, PK_PORTRANGE, PK_ETHER_ADDR, PK_MULTICAST, PK_BROADCAST,
    PK_VLAN, PK_MPLS, PK_PPPOES, PK_PPPOED, PK_INBOUND, PK_OUTBOUND,
    PK_IFINDEX, PK_WLAN_TYPE, PK_WLAN_ADDR, PK_GENEVE
} prim_kind_t;
typedef enum { BASE_LINK, BASE_IP, BASE_IP6, BASE_TCP, BASE_UDP, BASE_ICMP, BASE_ICMP6 } load_base_t;
typedef enum { A_CONST, A_LEN, A_LOAD, A_NEG, A_ADD, A_SUB, A_MUL, A_DIV, A_MOD, A_AND, A_OR, A_XOR, A_LSH, A_RSH } arith_kind_t;
typedef enum { R_EQ, R_NE, R_GT, R_GE, R_LT, R_LE } rel_kind_t;
typedef enum { N_AND, N_OR, N_NOT, N_PRIM, N_REL } node_kind_t;

typedef struct arith {
    arith_kind_t kind;
    uint32_t value;
    unsigned width;
    load_base_t base;
    struct arith *l, *r;
} arith_t;

typedef struct node {
    node_kind_t kind;
    struct node *l, *r;
    prim_kind_t prim;
    dir_t dir;
    int proto;
    uint32_t value, value2, mask;
    unsigned prefix;
    unsigned char addr[16];
    rel_kind_t rel;
    arith_t *a, *b;
} node_t;

#define AST_MAX_NODES 768
#define AST_MAX_ARITH 768
#define AST_MAX_DEPTH 80

typedef struct {
    node_t nodes[AST_MAX_NODES];
    arith_t arith[AST_MAX_ARITH];
    size_t used, aused;
    char error[192];
} ast_arena_t;

node_t *filter_parse(const char *text, ast_arena_t *arena);
int codegen(const node_t *root, const bpfc_case_t *c, bpf_prog_t *out);
int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err);

#endif
