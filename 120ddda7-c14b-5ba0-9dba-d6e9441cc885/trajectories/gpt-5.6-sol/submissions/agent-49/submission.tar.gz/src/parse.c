#include <arpa/inet.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "filter.h"

typedef enum {
    T_END, T_WORD, T_NUM, T_LP, T_RP, T_LB, T_RB, T_COLON, T_SLASH,
    T_AND, T_OR, T_NOT, T_PLUS, T_MINUS, T_MUL, T_DIV, T_MOD, T_BAND, T_BOR,
    T_XOR, T_LSH, T_RSH, T_EQ, T_NE, T_GT, T_GE, T_LT, T_LE, T_BAD
} tok_t;

typedef struct { tok_t t; char s[128]; uint32_t n; } token_t;
typedef struct {
    const char *src;
    size_t pos;
    int brackets, depth, failed;
    token_t cur;
    ast_arena_t *a;
} parser_t;

typedef struct { const char *name; int value; } nameval_t;

static const nameval_t protocols[] = {
    {"ip",0},{"IP",0},{"hopopt",0},{"HOPOPT",0},{"icmp",1},{"ICMP",1},{"igmp",2},{"IGMP",2},
    {"ggp",3},{"GGP",3},{"ipencap",4},{"IP-ENCAP",4},{"st",5},{"ST",5},{"tcp",6},{"TCP",6},
    {"egp",8},{"EGP",8},{"igp",9},{"IGP",9},{"pup",12},{"PUP",12},{"udp",17},{"UDP",17},
    {"hmp",20},{"HMP",20},{"xns-idp",22},{"XNS-IDP",22},{"rdp",27},{"RDP",27},{"iso-tp4",29},
    {"ISO-TP4",29},{"dccp",33},{"DCCP",33},{"xtp",36},{"XTP",36},{"ddp",37},{"DDP",37},
    {"idpr-cmtp",38},{"IDPR-CMTP",38},{"ipv6",41},{"IPv6",41},{"ipv6-route",43},
    {"IPv6-Route",43},{"ipv6-frag",44},{"IPv6-Frag",44},{"idrp",45},{"IDRP",45},{"rsvp",46},
    {"RSVP",46},{"gre",47},{"GRE",47},{"esp",50},{"IPSEC-ESP",50},{"ah",51},{"IPSEC-AH",51},
    {"skip",57},{"SKIP",57},{"ipv6-icmp",58},{"IPv6-ICMP",58},{"ipv6-nonxt",59},
    {"IPv6-NoNxt",59},{"ipv6-opts",60},{"IPv6-Opts",60},{"rspf",73},{"RSPF",73},{"CPHB",73},
    {"vmtp",81},{"VMTP",81},{"eigrp",88},{"EIGRP",88},{"ospf",89},{"OSPFIGP",89},{"ax.25",93},
    {"AX.25",93},{"ipip",94},{"IPIP",94},{"etherip",97},{"ETHERIP",97},{"encap",98},
    {"ENCAP",98},{"pim",103},{"PIM",103},{"ipcomp",108},{"IPCOMP",108},{"vrrp",112},
    {"VRRP",112},{"l2tp",115},{"L2TP",115},{"isis",124},{"ISIS",124},{"sctp",132},{"SCTP",132},
    {"fc",133},{"FC",133},{"mobility-header",135},{"Mobility-Header",135},{"udplite",136},
    {"UDPLite",136},{"mpls-in-ip",137},{"MPLS-in-IP",137},{"manet",138},{"hip",139},{"HIP",139},
    {"shim6",140},{"Shim6",140},{"wesp",141},{"WESP",141},{"rohc",142},{"ROHC",142},
    {"icmp6",58},{"igrp",9},{"carp",112},{"ip-encap",4},{"ipsec-ah",51},{"ipsec-esp",50},
    {"ospfigp",89},
    {NULL,0}
};
typedef struct { const char *name; int value,protocols; } serviceval_t;
static const nameval_t services[] = {{NULL,0}};
static const serviceval_t service_values[] = {
    {"Clearcase",371,2},
    {"acr-nema",104,1},
    {"afpovertcp",548,1},
    {"afs3-bos",7007,2},
    {"afs3-callback",7001,2},
    {"afs3-fileserver",7000,2},
    {"afs3-kaserver",7004,2},
    {"afs3-prserver",7002,2},
    {"afs3-rmtsys",7009,2},
    {"afs3-update",7008,2},
    {"afs3-vlserver",7003,2},
    {"afs3-volser",7005,2},
    {"amanda",10080,1},
    {"amandaidx",10082,1},
    {"amidxtape",10083,1},
    {"amqp",5672,5},
    {"amqps",5671,1},
    {"asf-rmcp",623,2},
    {"asp",27374,3},
    {"auth",113,1},
    {"authentication",113,1},
    {"babel",6696,2},
    {"bacula-dir",9101,1},
    {"bacula-fd",9102,1},
    {"bacula-sd",9103,1},
    {"bbs",7000,1},
    {"bgp",179,1},
    {"bgpd",2605,1},
    {"biff",512,2},
    {"binkp",24554,1},
    {"bootpc",68,2},
    {"bootps",67,2},
    {"canna",5680,1},
    {"cfengine",5308,1},
    {"chargen",19,3},
    {"cisco-sccp",2000,1},
    {"clc-build-daemon",8990,1},
    {"clearcase",371,2},
    {"cmd",514,1},
    {"cmip-agent",164,3},
    {"cmip-man",163,3},
    {"codaauth2",370,3},
    {"codasrv",2432,3},
    {"codasrv-se",2433,3},
    {"comsat",512,2},
    {"csync2",30865,1},
    {"cvspserver",2401,1},
    {"daap",3689,1},
    {"datametrics",1645,3},
    {"daytime",13,3},
    {"db-lsp",17500,1},
    {"dcap",22125,1},
    {"dhcpv6-client",546,2},
    {"dhcpv6-server",547,2},
    {"dicom",104,1},
    {"dict",2628,1},
    {"dircproxy",57000,1},
    {"discard",9,3},
    {"distcc",3632,1},
    {"domain",53,3},
    {"domain-s",853,3},
    {"echo",7,3},
    {"epmap",135,1},
    {"epmd",4369,1},
    {"exec",512,1},
    {"f5-globalsite",2792,1},
    {"f5-iquery",4353,1},
    {"fax",4557,1},
    {"fido",60179,1},
    {"finger",79,1},
    {"font-service",7100,1},
    {"freeciv",5556,1},
    {"fsp",21,2},
    {"fspd",21,2},
    {"ftp",21,1},
    {"ftp-data",20,1},
    {"ftps",990,1},
    {"ftps-data",989,1},
    {"gdomap",538,3},
    {"gds-db",3050,1},
    {"gds_db",3050,1},
    {"git",9418,1},
    {"gnunet",2086,3},
    {"gnutella-rtr",6347,3},
    {"gnutella-svc",6346,3},
    {"gopher",70,1},
    {"gpsd",2947,1},
    {"gris",2135,1},
    {"groupwise",1677,1},
    {"gsidcap",22128,1},
    {"gsiftp",2811,1},
    {"gsigatekeeper",2119,1},
    {"hkp",11371,1},
    {"hprop",754,1},
    {"http",80,1},
    {"http-alt",8080,1},
    {"https",443,3},
    {"hylafax",4559,1},
    {"iax",4569,2},
    {"icp",3130,2},
    {"icpv2",3130,2},
    {"ident",113,1},
    {"imap",143,1},
    {"imap2",143,1},
    {"imaps",993,1},
    {"ingreslock",1524,1},
    {"ipp",631,1},
    {"iprop",2121,1},
    {"ipsec-nat-t",4500,2},
    {"ipx",213,2},
    {"ircd",6667,1},
    {"ircs-u",6697,1},
    {"isakmp",500,2},
    {"iscsi-target",3260,1},
    {"isisd",2608,1},
    {"isns",3205,3},
    {"iso-tsap",102,1},
    {"jabber-client",5222,1},
    {"jabber-server",5269,1},
    {"kamanda",10081,1},
    {"kdc",750,3},
    {"kerberos",88,3},
    {"kerberos-adm",749,1},
    {"kerberos-iv",750,3},
    {"kerberos-master",751,3},
    {"kerberos-sec",88,3},
    {"kerberos4",750,3},
    {"kerberos5",88,3},
    {"kerberos_master",751,2},
    {"kermit",1649,1},
    {"klogin",543,1},
    {"kpasswd",464,3},
    {"krb-prop",754,1},
    {"krb5",88,3},
    {"krb5_prop",754,1},
    {"krb_prop",754,1},
    {"krcmd",544,1},
    {"kshell",544,1},
    {"l2f",1701,2},
    {"l2tp",1701,2},
    {"ldap",389,3},
    {"ldaps",636,3},
    {"ldp",646,3},
    {"loc-srv",135,1},
    {"login",513,1},
    {"lotusnote",1352,1},
    {"lotusnotes",1352,1},
    {"lrrd",4949,1},
    {"mail",25,1},
    {"mailq",174,1},
    {"mdns",5353,2},
    {"microsoft-ds",445,1},
    {"moira-db",775,1},
    {"moira-update",777,1},
    {"moira-ureg",779,2},
    {"moira_db",775,1},
    {"moira_update",777,1},
    {"moira_ureg",779,2},
    {"mon",2583,3},
    {"ms-sql-m",1434,2},
    {"ms-sql-s",1433,1},
    {"ms-wbt-server",3389,1},
    {"mtn",4691,1},
    {"munin",4949,1},
    {"mysql",3306,1},
    {"mysql-proxy",6446,1},
    {"nbd",10809,1},
    {"netbios-dgm",138,2},
    {"netbios-ns",137,2},
    {"netbios-ssn",139,1},
    {"netstat",15,1},
    {"nfs",2049,3},
    {"nicname",43,1},
    {"nntp",119,1},
    {"nntps",563,1},
    {"nqs",607,1},
    {"nrpe",5666,1},
    {"nsca",5667,1},
    {"ntalk",518,2},
    {"ntp",123,2},
    {"ntske",4460,1},
    {"null",9,3},
    {"nut",3493,3},
    {"old-radacct",1646,3},
    {"old-radius",1645,3},
    {"omniorb",8088,1},
    {"openvpn",1194,3},
    {"ospf6d",2606,1},
    {"ospfapi",2607,1},
    {"ospfd",2604,1},
    {"passwd-server",752,2},
    {"passwd_server",752,2},
    {"pawserv",345,1},
    {"pop-3",110,1},
    {"pop3",110,1},
    {"pop3s",995,1},
    {"poppassd",106,1},
    {"portmapper",111,3},
    {"postgres",5432,1},
    {"postgresql",5432,1},
    {"predict",1210,2},
    {"printer",515,1},
    {"proofd",1093,1},
    {"ptp-event",319,2},
    {"ptp-general",320,2},
    {"puppet",8140,1},
    {"qmqp",628,1},
    {"qmtp",209,1},
    {"qotd",17,1},
    {"quote",17,1},
    {"radacct",1813,3},
    {"radius",1812,3},
    {"radius-acct",1813,3},
    {"radmin-port",4899,1},
    {"readnews",119,1},
    {"redis",6379,1},
    {"remctl",4373,1},
    {"ripd",2602,1},
    {"ripngd",2603,1},
    {"rmiregistry",1099,1},
    {"rmtcfg",1236,1},
    {"rootd",1094,1},
    {"route",520,2},
    {"routed",520,2},
    {"router",520,2},
    {"rpc2portmap",369,3},
    {"rplay",5555,2},
    {"rptp",5556,1},
    {"rsync",873,1},
    {"rtcm-sc104",2101,3},
    {"rtsp",554,3},
    {"sa-msg-port",1646,3},
    {"saft",487,1},
    {"sane",6566,1},
    {"sane-port",6566,1},
    {"saned",6566,1},
    {"sge-execd",6445,1},
    {"sge-qmaster",6444,1},
    {"sge_execd",6445,1},
    {"sge_qmaster",6444,1},
    {"sgi-cad",17004,1},
    {"sgi-cmsd",17001,2},
    {"sgi-crsd",17002,2},
    {"sgi-gcd",17003,2},
    {"shell",514,1},
    {"sieve",4190,1},
    {"silc",706,1},
    {"sink",9,3},
    {"sip",5060,3},
    {"sip-tls",5061,3},
    {"skkserv",1178,1},
    {"smtp",25,1},
    {"smtps",465,1},
    {"smux",199,1},
    {"snmp",161,3},
    {"snmp-trap",162,3},
    {"snmptrap",162,3},
    {"snntp",563,1},
    {"snpp",444,1},
    {"socks",1080,1},
    {"source",19,3},
    {"spamd",783,1},
    {"spooler",515,1},
    {"ssh",22,1},
    {"ssmtp",465,1},
    {"submission",587,1},
    {"submissions",465,1},
    {"subversion",3690,1},
    {"sunrpc",111,3},
    {"supfiledbg",1127,1},
    {"supfilesrv",871,1},
    {"suucp",4031,1},
    {"svn",3690,1},
    {"svrloc",427,3},
    {"syslog",514,3},
    {"syslog-tls",6514,1},
    {"sysrqd",4094,1},
    {"systat",11,1},
    {"tacacs",49,3},
    {"talk",517,2},
    {"tap",113,1},
    {"tcpmux",1,1},
    {"telnet",23,1},
    {"telnets",992,1},
    {"tfido",60177,1},
    {"tftp",69,2},
    {"time",37,3},
    {"timserver",37,3},
    {"tinc",655,3},
    {"tproxy",8081,1},
    {"tsap",102,1},
    {"ttytst",19,3},
    {"untp",119,1},
    {"urd",465,1},
    {"users",11,1},
    {"uucp",540,1},
    {"uucpd",540,1},
    {"venus",2430,3},
    {"venus-se",2431,3},
    {"wais",210,1},
    {"webcache",8080,1},
    {"webmin",10000,1},
    {"who",513,2},
    {"whod",513,2},
    {"whois",43,1},
    {"wnn6",22273,1},
    {"www",80,1},
    {"x11",6000,1},
    {"x11-0",6000,1},
    {"x11-1",6001,1},
    {"x11-2",6002,1},
    {"x11-3",6003,1},
    {"x11-4",6004,1},
    {"x11-5",6005,1},
    {"x11-6",6006,1},
    {"x11-7",6007,1},
    {"xdmcp",177,2},
    {"xfs",7100,1},
    {"xinetd",9098,1},
    {"xmms2",9667,1},
    {"xmpp-client",5222,1},
    {"xmpp-server",5269,1},
    {"xtel",1313,1},
    {"xtelw",1314,1},
    {"z3950",210,1},
    {"zabbix-agent",10050,1},
    {"zabbix-trapper",10051,1},
    {"zebra",2601,1},
    {"zebrasrv",2600,1},
    {"zephyr-clt",2103,2},
    {"zephyr-hm",2104,2},
    {"zephyr-srv",2102,2},
    {"zope",9673,1},
    {"zope-ftp",8021,1},
    {"zserv",346,1},
};
static int service_lookup(const char *name,int *value,int *protocols)
{
    size_t lo=0,hi=sizeof(service_values)/sizeof(service_values[0]);
    while(lo<hi){size_t mid=lo+(hi-lo)/2;int cmp=strcmp(name,service_values[mid].name);
        if(cmp<0)hi=mid;else if(cmp>0)lo=mid+1;else{*value=service_values[mid].value;if(protocols)*protocols=service_values[mid].protocols;return 0;}}
    return -1;
}

static const nameval_t etherprotos[] = {
    {"ip",0x0800},{"arp",0x0806},{"rarp",0x8035},{"ip6",0x86dd},
    {"aarp",0x80f3},{"atalk",0x809b},{"ipx",0x8137},{"mpls",0x8847},
    {"mpls-mcast",0x8848},    {"pppoed",0x8863},{"pppoes",0x8864},
    {"mopdl",0x6001},{"moprc",0x6002},{"decnet",0x6003},{"lat",0x6004},
    {"sca",0x6007},{"netbeui",0xf0f0},{"stp",0x0026},{NULL,0}
};

static int lookup(const nameval_t *p, const char *s, int *v)
{
    if (*s == '\\') s++;
    if(p==services)return service_lookup(s,v,NULL);
    for (; p->name; p++) if (!strcmp(p->name, s)) { *v = p->value; return 0; }
    return -1;
}

static int service_protocol(const char *s)
{
    int value,mask;
    return service_lookup(s,&value,&mask)?-1:mask==1?6:mask==2?17:mask==4?132:-1;
}

static void seterr(parser_t *p, const char *s)
{
    if (!p->a->error[0]) snprintf(p->a->error, sizeof(p->a->error), "%s", s);
    p->failed = 1;
}

static int wordchar(int c)
{
    return isalnum((unsigned char)c) || c == '_' || c == '-' || c == '.' || c == '\\';
}

static void lex(parser_t *p)
{
    const char *s=p->src; size_t i=p->pos, st, n;
    p->cur.t=T_END;p->cur.n=0;p->cur.s[0]='\0';
    while (isspace((unsigned char)s[i])) i++;
    if (!s[i]) { p->cur.t=T_END; p->pos=i; return; }
#define ONE(ch,ty) if(s[i]==(ch)){p->cur.t=(ty);p->pos=i+1;return;}
    if (s[i]==':' && s[i+1]==':') { st=i; i+=2; while(isxdigit((unsigned char)s[i])||s[i]==':')i++; n=i-st; memcpy(p->cur.s,s+st,n); p->cur.s[n]=0; p->cur.t=T_WORD; p->pos=i; return; }
    if (s[i]=='(') { p->cur.t=T_LP; p->pos=i+1; return; }
    if (s[i]==')') { p->cur.t=T_RP; p->pos=i+1; return; }
    if (s[i]=='[') { p->cur.t=T_LB; p->pos=i+1; p->brackets++; return; }
    if (s[i]==']') { p->cur.t=T_RB; p->pos=i+1; if(p->brackets)p->brackets--; return; }
    if (s[i]=='&'&&s[i+1]=='&') { p->cur.t=T_AND;p->pos=i+2;return; }
    if (s[i]=='|'&&s[i+1]=='|') { p->cur.t=T_OR;p->pos=i+2;return; }
    if (s[i]=='='&&s[i+1]=='=') { p->cur.t=T_EQ;p->pos=i+2;return; }
    if (s[i]=='!'&&s[i+1]=='=') { p->cur.t=T_NE;p->pos=i+2;return; }
    if (s[i]=='>'&&s[i+1]=='=') { p->cur.t=T_GE;p->pos=i+2;return; }
    if (s[i]=='<'&&s[i+1]=='=') { p->cur.t=T_LE;p->pos=i+2;return; }
    if (s[i]=='<'&&s[i+1]=='<') { p->cur.t=T_LSH;p->pos=i+2;return; }
    if (s[i]=='>'&&s[i+1]=='>') { p->cur.t=T_RSH;p->pos=i+2;return; }
    ONE('!',T_NOT) ONE('=',T_EQ) ONE('>',T_GT) ONE('<',T_LT)
    ONE('+',T_PLUS) ONE('-',T_MINUS) ONE('*',T_MUL) ONE('/',T_SLASH) ONE('%',T_MOD)
    ONE('&',T_BAND) ONE('|',T_BOR) ONE('^',T_XOR) ONE(':',T_COLON)
#undef ONE
    st=i;
    if (isdigit((unsigned char)s[i])) {
        if (s[i]=='0'&&(s[i+1]=='x'||s[i+1]=='X')) {
            i+=2; while(isxdigit((unsigned char)s[i])) i++;
        } else {
            int colon=0;
            while (isdigit((unsigned char)s[i]) || s[i]=='.' || (!p->brackets && s[i]==':') ||
                   (!p->brackets && colon && isxdigit((unsigned char)s[i]))) { if(s[i]==':')colon=1; i++; }
        }
        n=i-st; if(!n||n>=sizeof(p->cur.s)){p->cur.t=T_BAD;p->pos=i;return;}
        memcpy(p->cur.s,s+st,n); p->cur.s[n]=0; p->pos=i;
        if (!strchr(p->cur.s,'.')&&!strchr(p->cur.s,':')) {
            char *e; unsigned long v=strtoul(p->cur.s,&e,0);
            if(*e){p->cur.t=T_BAD;return;} p->cur.t=T_NUM;p->cur.n=(uint32_t)v;
        } else p->cur.t=T_WORD;
        return;
    }
    if (isalpha((unsigned char)s[i]) || s[i]=='_' || s[i]=='\\') {
        i++; while(wordchar((unsigned char)s[i]) || (!p->brackets && s[i]==':')) i++;
        n=i-st; if(n>=sizeof(p->cur.s)){p->cur.t=T_BAD;p->pos=i;return;}
        memcpy(p->cur.s,s+st,n);p->cur.s[n]=0;p->pos=i;
        if(!strcmp(p->cur.s,"and")){p->cur.t=T_AND;return;}
        if(!strcmp(p->cur.s,"or")){p->cur.t=T_OR;return;}
        if(!strcmp(p->cur.s,"not")){p->cur.t=T_NOT;return;}
        p->cur.t=T_WORD; return;
    }
    p->cur.t=T_BAD; p->pos=i+1;
}

static node_t *node(parser_t *p,node_kind_t k)
{
    node_t *n;
    if(p->a->used>=AST_MAX_NODES){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    n=&p->a->nodes[p->a->used++];memset(n,0,sizeof(*n));n->kind=k;n->mask=0xffffffffU;return n;
}
static arith_t *anode(parser_t *p,arith_kind_t k)
{
    arith_t *a;
    if(p->a->aused>=AST_MAX_ARITH){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    a=&p->a->arith[p->a->aused++];memset(a,0,sizeof(*a));a->kind=k;return a;
}
static int isword(parser_t *p,const char *s){return p->cur.t==T_WORD&&!strcmp(p->cur.s,s);}
static void next(parser_t *p){lex(p);}

static int parse_ipv4_word(const char *s,uint32_t *v)
{
    struct in_addr a;
    if(inet_pton(AF_INET,s,&a)!=1)return -1;
    *v=ntohl(a.s_addr);return 0;
}
static int parse_ipv6_word(const char *s,unsigned char out[16])
{
    return inet_pton(AF_INET6,s,out)==1?0:-1;
}
static int parse_mac(const char *s,unsigned char out[16])
{
    unsigned x[6]; int i;
    if(sscanf(s,"%x:%x:%x:%x:%x:%x",&x[0],&x[1],&x[2],&x[3],&x[4],&x[5])!=6)return -1;
    for(i=0;i<6;i++){if(x[i]>255)return -1;out[i]=(unsigned char)x[i];}return 0;
}
static int parse_number_or_name(parser_t *p,const nameval_t *tab,uint32_t *v,const char *what)
{
    int n;
    if(p->cur.t==T_NUM){*v=p->cur.n;next(p);return 0;}
    if(p->cur.t==T_WORD&&lookup(tab,p->cur.s,&n)==0){*v=(uint32_t)n;next(p);return 0;}
    if(p->cur.t==T_WORD&&what){char b[192];snprintf(b,sizeof(b),"unknown %s '%s'",what,p->cur.s[0]=='\\'?p->cur.s+1:p->cur.s);seterr(p,b);}
    else seterr(p,BPFC_SYNTAX_ERROR);
    return -1;
}

static uint32_t prefix_mask(unsigned pfx){return pfx?0xffffffffU<<(32-pfx):0;}

static arith_t *parse_a_or(parser_t *p);
static arith_t *parse_a_primary(parser_t *p)
{
    arith_t *a; load_base_t base; uint32_t off=0; unsigned width=1;
    if(p->cur.t==T_MINUS){next(p);a=anode(p,A_NEG);if(a)a->l=parse_a_primary(p);return a;}
    if(p->cur.t==T_LP){next(p);a=parse_a_or(p);if(p->cur.t!=T_RP){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);return a;}
    if(p->cur.t==T_NUM){a=anode(p,A_CONST);if(a)a->value=p->cur.n;next(p);return a;}
    if(isword(p,"len")){a=anode(p,A_LEN);next(p);return a;}
    if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(!strcmp(p->cur.s,"link")||!strcmp(p->cur.s,"ether"))base=BASE_LINK;
    else if(!strcmp(p->cur.s,"ip"))base=BASE_IP;
    else if(!strcmp(p->cur.s,"ip6"))base=BASE_IP6;
    else if(!strcmp(p->cur.s,"tcp"))base=BASE_TCP;
    else if(!strcmp(p->cur.s,"udp"))base=BASE_UDP;
    else if(!strcmp(p->cur.s,"icmp"))base=BASE_ICMP;
    else if(!strcmp(p->cur.s,"icmp6"))base=BASE_ICMP6;
    else {
        int v;
        if(!strcmp(p->cur.s,"tcpflags"))v=13;
        else if(!strcmp(p->cur.s,"icmptype"))v=0;
        else if(!strcmp(p->cur.s,"tcp-fin"))v=1;
        else if(!strcmp(p->cur.s,"tcp-syn"))v=2;
        else if(!strcmp(p->cur.s,"tcp-rst"))v=4;
        else if(!strcmp(p->cur.s,"tcp-push"))v=8;
        else if(!strcmp(p->cur.s,"tcp-ack"))v=16;
        else if(!strcmp(p->cur.s,"tcp-urg"))v=32;
        else if(!strcmp(p->cur.s,"tcp-ece"))v=64;
        else if(!strcmp(p->cur.s,"tcp-cwr"))v=128;
        else if(!strcmp(p->cur.s,"icmp-echoreply"))v=0;
        else if(!strcmp(p->cur.s,"icmp-unreach"))v=3;
        else if(!strcmp(p->cur.s,"icmp-sourcequench"))v=4;
        else if(!strcmp(p->cur.s,"icmp-redirect"))v=5;
        else if(!strcmp(p->cur.s,"icmp-echo"))v=8;
        else if(!strcmp(p->cur.s,"icmp-routeradvert"))v=9;
        else if(!strcmp(p->cur.s,"icmp-routersolicit"))v=10;
        else if(!strcmp(p->cur.s,"icmp-timxceed"))v=11;
        else if(!strcmp(p->cur.s,"icmp-paramprob"))v=12;
        else if(!strcmp(p->cur.s,"icmp-tstamp"))v=13;
        else if(!strcmp(p->cur.s,"icmp-tstampreply"))v=14;
        else if(!strcmp(p->cur.s,"icmp-ireq"))v=15;
        else if(!strcmp(p->cur.s,"icmp-ireqreply"))v=16;
        else if(!strcmp(p->cur.s,"icmp-maskreq"))v=17;
        else if(!strcmp(p->cur.s,"icmp-maskreply"))v=18;
        else {seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        a=anode(p,A_CONST);if(a)a->value=(uint32_t)v;next(p);return a;
    }
    next(p);if(p->cur.t!=T_LB){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);
    if(p->cur.t==T_NUM){off=p->cur.n;next(p);}
    else if(p->cur.t==T_WORD){if(!strcmp(p->cur.s,"tcpflags"))off=13;else if(!strcmp(p->cur.s,"icmptype"))off=0;else if(!strcmp(p->cur.s,"icmpcode"))off=1;else {seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);}
    else {seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(p->cur.t==T_COLON){next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}width=p->cur.n;next(p);if(width!=1&&width!=2&&width!=4){seterr(p,"data size must be 1, 2, or 4");return NULL;}}
    if(p->cur.t!=T_RB){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);
    a=anode(p,A_LOAD);if(a){a->base=base;a->value=off;a->width=width;}return a;
}
#define ABIN(fn,sub,nextfn,cond,mapexpr) static arith_t *fn(parser_t *p){arith_t*l=nextfn(p);while(l&&!p->failed&&(cond)){tok_t t=p->cur.t;arith_t*n;(void)t;next(p);n=anode(p,(mapexpr));if(!n)return NULL;n->l=l;n->r=nextfn(p);if(!n->r)return NULL;l=n;}return l;}
ABIN(parse_a_mul,x,parse_a_primary,p->cur.t==T_MUL||p->cur.t==T_SLASH||p->cur.t==T_MOD,t==T_MUL?A_MUL:t==T_MOD?A_MOD:A_DIV)
ABIN(parse_a_add,x,parse_a_mul,p->cur.t==T_PLUS||p->cur.t==T_MINUS,t==T_PLUS?A_ADD:A_SUB)
ABIN(parse_a_shift,x,parse_a_add,p->cur.t==T_LSH||p->cur.t==T_RSH,t==T_LSH?A_LSH:A_RSH)
ABIN(parse_a_band,x,parse_a_shift,p->cur.t==T_BAND,A_AND)
ABIN(parse_a_xor,x,parse_a_band,p->cur.t==T_XOR,A_XOR)
ABIN(parse_a_or,x,parse_a_xor,p->cur.t==T_BOR,A_OR)
#undef ABIN

static node_t *parse_expr_or(parser_t *p);
static node_t *parse_relation(parser_t *p)
{
    node_t *n=node(p,N_REL); tok_t t;
    if(!n)return NULL;
    n->a=parse_a_or(p);
    if(!n->a)return NULL;
    t=p->cur.t;
    if(t!=T_EQ&&t!=T_NE&&t!=T_GT&&t!=T_GE&&t!=T_LT&&t!=T_LE){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    next(p);n->b=parse_a_or(p);if(!n->b)return NULL;
    n->rel=t==T_EQ?R_EQ:t==T_NE?R_NE:t==T_GT?R_GT:t==T_GE?R_GE:t==T_LT?R_LT:R_LE;
    return n;
}

static int looks_arith(parser_t *p)
{
    size_t i=p->pos; const char *s=p->src;
    if(isword(p,"len"))return 1;
    if(p->cur.t==T_WORD){while(isspace((unsigned char)s[i]))i++;return s[i]=='[';}
    return p->cur.t==T_LP||p->cur.t==T_MINUS;
}

static node_t *newprim(parser_t *p,prim_kind_t k){node_t*n=node(p,N_PRIM);if(n)n->prim=k;return n;}
static int bare_proto(const char *s,int *mode,int *value)
{
    if(!strcmp(s,"ip")){*mode=4;*value=-1;return 0;} if(!strcmp(s,"ip6")){*mode=6;*value=-1;return 0;}
    if(!strcmp(s,"arp")){*mode=1;*value=0x0806;return 0;}if(!strcmp(s,"rarp")){*mode=1;*value=0x8035;return 0;}
    if(!strcmp(s,"icmp6")){*mode=6;*value=58;return 0;}
    if(lookup(protocols,s,value)==0){*mode=(!strcmp(s,"icmp")||!strcmp(s,"igmp")||!strcmp(s,"igrp")||!strcmp(s,"vrrp")||!strcmp(s,"carp"))?4:46;return 0;}
    if(lookup(etherprotos,s,value)==0){*mode=1;return 0;}
    return -1;
}

static int wlan_type_value(const char *s,int direction,int *value)
{
    static const nameval_t names[] = {
        {"mgt",0x00},{"ctl",0x04},{"data",0x08},{"assoc-req",0x00},
        {"assoc-resp",0x10},{"reassoc-req",0x20},{"reassoc-resp",0x30},
        {"probe-req",0x40},{"probe-resp",0x50},{"beacon",0x80},{"atim",0x90},
        {"disassoc",0xa0},{"auth",0xb0},{"deauth",0xc0},{"ps-poll",0xa4},
        {"rts",0xb4},{"cts",0xc4},{"ack",0xd4},{"cf-end",0xe4},
        {"cf-end-ack",0xf4},{"data-cf-ack",0x18},{"data-cf-poll",0x28},
        {"data-cf-ack-poll",0x38},{"null",0x48},{"cf-ack",0x58},
        {"cf-poll",0x68},{"cf-ack-poll",0x78},{"qos-data",0x88},
        {"qos-data-cf-ack",0x98},{"qos-data-cf-poll",0xa8},
        {"qos-data-cf-ack-poll",0xb8},{"qos-null",0xc8},{NULL,0}
    };
    if(direction){
        if(!strcmp(s,"nods")){*value=0;return 0;}
        if(!strcmp(s,"tods")){*value=0x100;return 0;}
        if(!strcmp(s,"fromds")){*value=0x200;return 0;}
        if(!strcmp(s,"dstods")){*value=0x300;return 0;}
        return -1;
    }
    return lookup(names,s,value);
}

static node_t *parse_primitive(parser_t *p)
{
    node_t *n; dir_t dir=DIR_ANY; int pmode=0,pval=0; char first[128];
    if(looks_arith(p))return parse_relation(p);
    if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(isword(p,"greater")||isword(p,"less")){
        int less=isword(p,"less");next(p);n=node(p,N_REL);if(!n)return NULL;n->a=anode(p,A_LEN);n->a->width=1;n->b=parse_a_primary(p);n->rel=less?R_LE:R_GE;return n;
    }
    if(isword(p,"src")||isword(p,"dst")){
        int src=isword(p,"src");next(p);dir=src?DIR_SRC:DIR_DST;
        if(p->cur.t==T_AND||p->cur.t==T_OR){int isand=p->cur.t==T_AND;next(p);if((src&&!isword(p,"dst"))||(!src&&!isword(p,"src"))){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);dir=isand?DIR_BOTH_AND:DIR_BOTH_OR;}
    }
    if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    snprintf(first,sizeof(first),"%s",p->cur.s);

    if(!strcmp(first,"ether")||!strcmp(first,"link")){
        next(p);
        if(isword(p,"proto")){uint32_t v;next(p);if(parse_number_or_name(p,etherprotos,&v,"ether proto"))return NULL;n=newprim(p,PK_ETHERTYPE);n->value=v;return n;}
        if(isword(p,"src")||isword(p,"dst")){dir=isword(p,"src")?DIR_SRC:DIR_DST;next(p);if(isword(p,"host"))next(p);}
        if(isword(p,"host")){dir=DIR_ANY;next(p);}
        if(isword(p,"multicast")){next(p);n=newprim(p,PK_MULTICAST);n->proto=1;return n;}
        if(isword(p,"broadcast")){next(p);n=newprim(p,PK_BROADCAST);n->proto=1;return n;}
        if(p->cur.t==T_WORD||p->cur.t==T_NUM){n=newprim(p,PK_ETHER_ADDR);n->dir=dir;if(parse_mac(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);return n;}
        seterr(p,BPFC_SYNTAX_ERROR);return NULL;
    }

    if(!strcmp(first,"type")||!strcmp(first,"subtype")||!strcmp(first,"dir")||!strcmp(first,"wlan")){
        int val=0; prim_kind_t pk=!strcmp(first,"wlan")?PK_WLAN_ADDR:PK_WLAN_TYPE;next(p);
        if(pk==PK_WLAN_ADDR){if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}if(!strncmp(p->cur.s,"addr",4)||!strcmp(p->cur.s,"ra")||!strcmp(p->cur.s,"ta")){val=!strcmp(p->cur.s,"ra")?1:!strcmp(p->cur.s,"ta")?2:atoi(p->cur.s+4);next(p);}if(p->cur.t!=T_WORD&&p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n=newprim(p,pk);n->value=(uint32_t)val;if(parse_mac(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);return n;}
        if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        if(wlan_type_value(p->cur.s,!strcmp(first,"dir"),&val)){
            seterr(p,!strcmp(first,"dir")?"unknown 802.11 direction":"unknown 802.11 type name");return NULL;
        }
        next(p);if(isword(p,"subtype")){next(p);if(p->cur.t!=T_WORD){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}if(wlan_type_value(p->cur.s,0,&val)){seterr(p,"unknown 802.11 type name");return NULL;}next(p);}
        n=newprim(p,pk);n->value=(uint32_t)val;n->proto=!strcmp(first,"dir");return n;
    }

    if(!strcmp(first,"multicast")||!strcmp(first,"broadcast")){next(p);n=newprim(p,!strcmp(first,"multicast")?PK_MULTICAST:PK_BROADCAST);return n;}
    if(!strcmp(first,"vlan")||!strcmp(first,"mpls")){int vlan=!strcmp(first,"vlan");next(p);n=newprim(p,vlan?PK_VLAN:PK_MPLS);if(p->cur.t==T_NUM){n->value=p->cur.n;n->value2=1;next(p);}return n;}
    if(!strcmp(first,"pppoes")||!strcmp(first,"pppoed")||!strcmp(first,"inbound")||!strcmp(first,"outbound")){
        next(p);n=newprim(p,!strcmp(first,"pppoes")?PK_PPPOES:!strcmp(first,"pppoed")?PK_PPPOED:!strcmp(first,"inbound")?PK_INBOUND:PK_OUTBOUND);return n;
    }
    if(!strcmp(first,"ifindex")){next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n=newprim(p,PK_IFINDEX);n->value=p->cur.n;next(p);return n;}
    if(!strcmp(first,"geneve")){next(p);return newprim(p,PK_GENEVE);}

    if(!strcmp(first,"iso")){next(p);if(!isword(p,"proto")){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n=newprim(p,PK_ETHERTYPE);n->proto=2;n->value=p->cur.n;next(p);return n;}
    if(bare_proto(first,&pmode,&pval)==0){next(p);}
    else pmode=0;

    if(pmode&&dir==DIR_ANY&&(isword(p,"src")||isword(p,"dst"))){int src=isword(p,"src");next(p);dir=src?DIR_SRC:DIR_DST;if(p->cur.t==T_AND||p->cur.t==T_OR){int ia=p->cur.t==T_AND;next(p);if((src&&!isword(p,"dst"))||(!src&&!isword(p,"src"))){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);dir=ia?DIR_BOTH_AND:DIR_BOTH_OR;}}

    if(pmode&&(isword(p,"proto")||isword(p,"protochain"))){int chain=isword(p,"protochain");uint32_t v;next(p);if(p->cur.t==T_WORD&&p->cur.s[0]!='\\'){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}if(parse_number_or_name(p,protocols,&v,"proto"))return NULL;n=newprim(p,PK_IPPROTO);n->proto=pmode;n->value=v;n->value2=(uint32_t)chain;return n;}
    if(pmode&&(isword(p,"multicast")||isword(p,"broadcast"))){int multi=isword(p,"multicast");next(p);n=newprim(p,multi?PK_MULTICAST:PK_BROADCAST);n->proto=pmode;return n;}

    if((pmode||!strcmp(first,"host")||!strcmp(first,"net")||!strcmp(first,"port")||!strcmp(first,"portrange")) &&
       (isword(p,"host")||(!pmode&&!strcmp(first,"host")))){
        if(isword(p,"host"))next(p);
        n=newprim(p,PK_HOST4);n->dir=dir;n->proto=pmode;n->value2=(uint32_t)pval;
        if(p->cur.t!=T_WORD&&p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        if(strchr(p->cur.s,':')){n->prim=PK_HOST6;if(parse_ipv6_word(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}}
        else if(parse_ipv4_word(p->cur.s,&n->value)==0){}
        else if(!strcmp(p->cur.s,"localhost")){n->value=0x7f000001;n->prefix=255;}
        else if(!strcmp(p->cur.s,"buildkitsandbox")){n->value=0x7f000001;}
        else if(!strcmp(p->cur.s,"ip6-localhost")||!strcmp(p->cur.s,"ip6-loopback")){n->prim=PK_HOST6;memset(n->addr,0,16);n->addr[15]=1;}
        else if(!strcmp(p->cur.s,"ip6-allnodes")){n->prim=PK_HOST6;inet_pton(AF_INET6,"ff02::1",n->addr);}
        else if(!strcmp(p->cur.s,"ip6-allrouters")){n->prim=PK_HOST6;inet_pton(AF_INET6,"ff02::2",n->addr);}
        else if(isdigit((unsigned char)p->cur.s[0])){char b[192];snprintf(b,sizeof(b),"invalid IPv4 address '%s'",p->cur.s);seterr(p,b);return NULL;}
        else {char b[192];snprintf(b,sizeof(b),"unknown host '%s'",p->cur.s);seterr(p,b);return NULL;}next(p);return n;
    }
    if((pmode||!strcmp(first,"net"))&&(isword(p,"net")||(!pmode&&!strcmp(first,"net")))){
        unsigned pfx=0;uint32_t m; if(isword(p,"net"))next(p);n=newprim(p,PK_NET4);n->dir=dir;n->proto=pmode;n->value2=(uint32_t)pval;
        if(p->cur.t!=T_WORD&&p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
        if(strchr(p->cur.s,':')){n->prim=PK_NET6;if(parse_ipv6_word(p->cur.s,n->addr)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}pfx=128;}
        else if(parse_ipv4_word(p->cur.s,&n->value)==0)pfx=32;
        else if(!strcmp(p->cur.s,"link-local")){n->value=0xa9fe0000;pfx=32;}
        else {char b[192];snprintf(b,sizeof(b),"unknown network '%s'",p->cur.s);seterr(p,b);return NULL;}next(p);
        if(p->cur.t==T_SLASH){next(p);if(p->cur.t!=T_NUM){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}pfx=p->cur.n;next(p);if((n->prim==PK_NET4&&pfx>32)||(n->prim==PK_NET6&&pfx>128)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}}
        else if(isword(p,"mask")){next(p);if(p->cur.t!=T_WORD||parse_ipv4_word(p->cur.s,&m)){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}n->mask=m;next(p);}
        if(n->prim==PK_NET4&&n->mask==0xffffffffU)n->mask=prefix_mask(pfx);
        n->prefix=pfx;return n;
    }
    if((pmode||!strcmp(first,"port")||!strcmp(first,"portrange"))&&(isword(p,"port")||isword(p,"portrange")||!pmode)){
        int range=isword(p,"portrange")||!strcmp(first,"portrange");
        if(pmode&&!(pmode==46&&(pval==6||pval==17||pval==132))){
            seterr(p,range?"illegal qualifier of 'portrange'":"illegal qualifier of 'port'");return NULL;
        }
        if(isword(p,"port")||isword(p,"portrange"))next(p);
        n=newprim(p,range?PK_PORTRANGE:PK_PORT);n->dir=dir;n->proto=pmode==46?pval:pmode==4||pmode==6?-2:-1;
        if(!pmode&&p->cur.t==T_WORD)n->proto=service_protocol(p->cur.s);
        if(parse_number_or_name(p,services,&n->value,"port"))return NULL;
        if(n->value>65535){char b[192];snprintf(b,sizeof(b),"illegal port number %u > 65535",n->value);seterr(p,b);return NULL;}
        if(range){if(p->cur.t!=T_MINUS){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}next(p);if(parse_number_or_name(p,services,&n->value2,"port"))return NULL;if(n->value2>65535){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}}
        return n;
    }
    if(pmode){n=newprim(p,pmode==1?PK_ETHERTYPE:pmode==4&&pval==-1?PK_ETHERTYPE:pmode==6&&pval==-1?PK_ETHERTYPE:PK_IPPROTO);n->proto=pmode;n->value=(pmode==4&&pval==-1)?0x0800:(pmode==6&&pval==-1)?0x86dd:(uint32_t)pval;return n;}
    seterr(p,BPFC_SYNTAX_ERROR);return NULL;
}

static int paren_starts_arith(parser_t *p)
{
    const char *s=p->src;size_t i=p->pos;int d=1;
    while(s[i]&&d){if(s[i]=='(')d++;else if(s[i]==')')d--;i++;}
    while(isspace((unsigned char)s[i]))i++;
    return d==0&&s[i]&&strchr("<>=!+-*/%&|^",s[i])!=NULL;
}
static node_t *parse_unary(parser_t *p)
{
    node_t*n;if(++p->depth>AST_MAX_DEPTH){seterr(p,BPFC_SYNTAX_ERROR);return NULL;}
    if(p->cur.t==T_NOT){next(p);n=node(p,N_NOT);if(n)n->l=parse_unary(p);p->depth--;return n;}
    if(p->cur.t==T_LP&&paren_starts_arith(p)){n=parse_relation(p);p->depth--;return n;}
    if(p->cur.t==T_LP){next(p);n=parse_expr_or(p);if(p->cur.t!=T_RP){seterr(p,BPFC_SYNTAX_ERROR);p->depth--;return NULL;}next(p);p->depth--;return n;}
    n=parse_primitive(p);p->depth--;return n;
}
static node_t *parse_expr_and(parser_t *p){node_t*l=parse_unary(p);while(l&&!p->failed&&p->cur.t==T_AND){node_t*n=node(p,N_AND);next(p);n->l=l;n->r=parse_unary(p);if(!n->r)return NULL;l=n;}return l;}
static node_t *parse_expr_or(parser_t *p){node_t*l=parse_expr_and(p);while(l&&!p->failed&&p->cur.t==T_OR){node_t*n=node(p,N_OR);next(p);n->l=l;n->r=parse_expr_and(p);if(!n->r)return NULL;l=n;}return l;}

node_t *filter_parse(const char *text,ast_arena_t *a)
{
    parser_t p;node_t*r;a->used=0;a->aused=0;a->error[0]='\0';memset(&p,0,sizeof(p));p.src=text;p.a=a;lex(&p);
    if(p.cur.t==T_END){r=newprim(&p,PK_ETHERTYPE);if(r){r->value=0xffffffffU;r->proto=-99;}return r;}
    r=parse_expr_or(&p);if(!r||p.failed||p.cur.t!=T_END){if(!a->error[0])snprintf(a->error,sizeof(a->error),"%s",BPFC_SYNTAX_ERROR);return NULL;}return r;
}
