#ifndef FILTER_H
#define FILTER_H

#include <stddef.h>
#include <stdint.h>
#include "bpf_defs.h"
#include "jsonio.h"

typedef enum { NODE_AND, NODE_OR, NODE_NOT, NODE_PRIM, NODE_TRUE, NODE_FALSE } node_kind_t;
typedef enum { DIR_ANY, DIR_SRC, DIR_DST, DIR_BOTH } dir_t;
typedef enum {
    PR_ETHERTYPE, PR_IPPROTO4, PR_IPPROTO6, PR_IPPROTO,
    PR_HOST4, PR_NET4, PR_HOST6, PR_NET6, PR_ETHER_HOST,
    PR_PORT, PR_PORTRANGE, PR_LEN, PR_BYTE,
    PR_VLAN, PR_MPLS, PR_PPPOE, PR_IFINDEX, PR_DIRECTION,
    PR_WLAN_TYPE, PR_WLAN_ADDR, PR_BROADCAST, PR_MULTICAST, PR_ISO
} prim_kind_t;
typedef enum { CMP_EQ, CMP_NE, CMP_GT, CMP_GE, CMP_LT, CMP_LE } cmp_t;
typedef enum { TP_ANY, TP_TCP, TP_UDP, TP_SCTP } transport_t;

typedef struct node {
    node_kind_t kind;
    struct node *l, *r;
    prim_kind_t prim;
    dir_t dir;
    transport_t transport;
    cmp_t cmp;
    uint32_t val, val2, mask, constant;
    uint8_t size;
    uint8_t addr[16];
    char base[12];
} node_t;

#define AST_MAX_NODES 1024
#define AST_MAX_DEPTH 96
typedef struct { node_t pool[AST_MAX_NODES]; size_t used; char err[192]; } ast_arena_t;

node_t *filter_parse(const char *text, ast_arena_t *arena, const bpfc_case_t *c);
int codegen(const node_t *root, const bpfc_case_t *c, bpf_prog_t *out, const char **err);
int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err);

#endif
