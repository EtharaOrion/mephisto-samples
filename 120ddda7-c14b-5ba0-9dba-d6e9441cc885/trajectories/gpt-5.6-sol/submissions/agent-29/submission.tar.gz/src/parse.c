#include <arpa/inet.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filter.h"

typedef enum { T_END, T_WORD, T_LP, T_RP, T_LB, T_RB, T_AND, T_OR, T_NOT,
               T_AMP, T_PIPE, T_EQ, T_NE, T_GT, T_GE, T_LT, T_LE, T_SHL, T_SHR, T_PLUS, T_MINUS, T_MUL, T_DIV, T_BAD } tt_t;
typedef struct { tt_t t; char s[128]; uint32_t n; } tok_t;
typedef struct { const char *s; size_t p; tok_t t; ast_arena_t *a; const bpfc_case_t *c; int depth; } parser_t;

static void seterr(parser_t *p, const char *s) { if (!p->a->err[0]) snprintf(p->a->err,sizeof(p->a->err),"%s",s); }
static int delim(int c) { return !c || isspace((unsigned char)c) || strchr("()[]&|=!<>+*",c)!=NULL; }
static void next(parser_t *p) {
    const char *s=p->s; size_t i=p->p,j=0; tok_t *t=&p->t; memset(t,0,sizeof(*t));
    while (isspace((unsigned char)s[i])) i++;
    if (!s[i]) { t->t=T_END; p->p=i; return; }
    if (s[i]=='(') t->t=T_LP; else if(s[i]==')')t->t=T_RP; else if(s[i]=='[')t->t=T_LB; else if(s[i]==']')t->t=T_RB;
    else if(s[i]=='!'&&s[i+1]=='='){t->t=T_NE;i++;} else if(s[i]=='!' )t->t=T_NOT;
    else if(s[i]=='='&&s[i+1]=='='){t->t=T_EQ;i++;} else if(s[i]=='=')t->t=T_EQ;
    else if(s[i]=='>'&&s[i+1]=='='){t->t=T_GE;i++;} else if(s[i]=='>'&&s[i+1]=='>'){t->t=T_SHR;i++;} else if(s[i]=='>')t->t=T_GT;
    else if(s[i]=='<'&&s[i+1]=='='){t->t=T_LE;i++;} else if(s[i]=='<'&&s[i+1]=='<'){t->t=T_SHL;i++;} else if(s[i]=='<')t->t=T_LT;
    else if(s[i]=='&'&&s[i+1]=='&'){t->t=T_AND;i++;} else if(s[i]=='&')t->t=T_AMP;
    else if(s[i]=='|'&&s[i+1]=='|'){t->t=T_OR;i++;} else if(s[i]=='|')t->t=T_PIPE;
    else if(s[i]=='+')t->t=T_PLUS; else if(s[i]=='*')t->t=T_MUL;
    else {
        while(s[i] && !delim((unsigned char)s[i]) && j+1<sizeof(t->s)) t->s[j++]=s[i++];
        if (!j) { t->t=T_BAD; p->p=i+1; return; }
        t->s[j]=0; t->t=T_WORD; t->n=(uint32_t)strtoul(t->s,NULL,0); p->p=i;
        if(!strcmp(t->s,"and"))t->t=T_AND; else if(!strcmp(t->s,"or"))t->t=T_OR; else if(!strcmp(t->s,"not"))t->t=T_NOT;
        return;
    }
    p->p=i+1;
}
static node_t *nn(parser_t *p,node_kind_t k){ node_t*n;if(p->a->used>=AST_MAX_NODES){seterr(p,"filter expression too complex");return NULL;}n=&p->a->pool[p->a->used++];memset(n,0,sizeof(*n));n->kind=k;n->mask=0xffffffffu;return n; }
static node_t *prim(parser_t*p,prim_kind_t k){node_t*n=nn(p,NODE_PRIM);if(n)n->prim=k;return n;}
static int word(parser_t*p,const char*s){return p->t.t==T_WORD&&!strcmp(p->t.s,s);}
static int number(const char*s,uint32_t*n){char*e;unsigned long v;if(!s[0])return 0;v=strtoul(s,&e,0);if(*e)return 0;*n=(uint32_t)v;return 1;}
static int proto_num(const char*s,uint32_t*n){
    if(number(s,n))return 1; if(*s=='\\')s++;
    struct {const char*n;uint8_t v;} q[]={{"ip",0},{"hopopt",0},{"icmp",1},{"igmp",2},{"tcp",6},{"igrp",9},{"igp",9},{"udp",17},{"gre",47},{"esp",50},{"ah",51},{"ipv6-icmp",58},{"pim",103},{"vrrp",112},{"sctp",132}};
    for(size_t i=0;i<sizeof(q)/sizeof(q[0]);i++)if(!strcmp(s,q[i].n)){*n=q[i].v;return 1;}return 0;
}
static int ether_num(const char*s,uint32_t*n){
    if(number(s,n))return 1;if(*s=='\\')s++;
    struct {const char*n;uint16_t v;} q[]={{"ip",0x0800},{"arp",0x0806},{"rarp",0x8035},{"ip6",0x86dd},{"ipv6",0x86dd},{"aarp",0x80f3},{"atalk",0x809b},{"ipx",0x8137},{"mopdl",0x6001},{"moprc",0x6002},{"lat",0x6004},{"sca",0x6007},{"netbeui",0xf0f0}};
    for(size_t i=0;i<sizeof(q)/sizeof(q[0]);i++)if(!strcmp(s,q[i].n)){*n=q[i].v;return 1;}return 0;
}
static int service_num(const char*s,uint32_t*n,transport_t *tp){
    if(number(s,n))return 1;
    struct {const char*n;uint16_t v;transport_t t;} q[]={{"ftp",21,TP_TCP},{"ftp-data",20,TP_TCP},{"ssh",22,TP_TCP},{"telnet",23,TP_TCP},{"smtp",25,TP_TCP},{"domain",53,TP_ANY},{"bootps",67,TP_UDP},{"bootpc",68,TP_UDP},{"http",80,TP_TCP},{"www",80,TP_TCP},{"https",443,TP_ANY},{"ntp",123,TP_UDP},{"snmp",161,TP_ANY},{"route",520,TP_UDP}};
    for(size_t i=0;i<sizeof(q)/sizeof(q[0]);i++)if(!strcmp(s,q[i].n)){*n=q[i].v;if(*tp==TP_ANY)*tp=q[i].t;return 1;}return 0;
}
static int ipv4(const char*s,uint32_t*n){struct in_addr a;if(inet_pton(AF_INET,s,&a)!=1)return 0;*n=ntohl(a.s_addr);return 1;}
static int ipv6(const char*s,uint8_t*a){const char*q=s;if(!strcmp(s,"ip6-allnodes"))q="ff02::1";else if(!strcmp(s,"ip6-allrouters"))q="ff02::2";else if(!strcmp(s,"ip6-localhost")||!strcmp(s,"ip6-loopback"))q="::1";return inet_pton(AF_INET6,q,a)==1;}
static int mac(const char*s,uint8_t*a){unsigned x[6];if(sscanf(s,"%x:%x:%x:%x:%x:%x",&x[0],&x[1],&x[2],&x[3],&x[4],&x[5])!=6)return 0;for(int i=0;i<6;i++)a[i]=(uint8_t)x[i];return 1;}
static int cmp_tok(tt_t t,cmp_t*c){switch(t){case T_EQ:*c=CMP_EQ;return 1;case T_NE:*c=CMP_NE;return 1;case T_GT:*c=CMP_GT;return 1;case T_GE:*c=CMP_GE;return 1;case T_LT:*c=CMP_LT;return 1;case T_LE:*c=CMP_LE;return 1;default:return 0;}}
static int parse_dir(parser_t*p,dir_t*d){
    if(!word(p,"src")&&!word(p,"dst"))return 0;int src=word(p,"src");next(p);
    if(p->t.t==T_AND||p->t.t==T_OR){tt_t op=p->t.t;next(p);if((src&&!word(p,"dst"))||(!src&&!word(p,"src")))return -1;next(p);*d=(op==T_AND)?DIR_BOTH:DIR_ANY;}
    else *d=src?DIR_SRC:DIR_DST;return 1;
}
static node_t *parse_expr(parser_t*p);

static node_t *parse_byte(parser_t*p,const char*base){
    node_t*n=prim(p,PR_BYTE);uint32_t off=0,sz=1,v=0;if(!n)return NULL;strncpy(n->base,base,sizeof(n->base)-1);
    next(p); if(p->t.t!=T_WORD){seterr(p,"can't parse filter expression: syntax error");return NULL;}
    char *colon=strchr(p->t.s,':');if(colon){*colon=0;if(!number(p->t.s,&off)||!number(colon+1,&sz)){seterr(p,"can't parse filter expression: syntax error");return NULL;}}else if(!number(p->t.s,&off)){if(!strcmp(p->t.s,"tcpflags"))off=13;else if(!strcmp(p->t.s,"icmptype"))off=0;else{seterr(p,"can't parse filter expression: syntax error");return NULL;}}
    if(sz!=1&&sz!=2&&sz!=4){seterr(p,"data size must be 1, 2, or 4");return NULL;}n->val=off;n->size=(uint8_t)sz;next(p);if(p->t.t!=T_RB){seterr(p,"can't parse filter expression: syntax error");return NULL;}next(p);
    n->mask=0xffffffffu;
    if(p->t.t==T_AMP){next(p);if(p->t.t!=T_WORD||!number(p->t.s,&n->mask)){seterr(p,"can't parse filter expression: syntax error");return NULL;}next(p);}
    if(p->t.t==T_SHL||p->t.t==T_SHR){n->val2=(p->t.t==T_SHL?0x10000u:0x20000u);next(p);if(p->t.t!=T_WORD||!number(p->t.s,&v)){seterr(p,"can't parse filter expression: syntax error");return NULL;}n->val2|=v;next(p);}
    if(!cmp_tok(p->t.t,&n->cmp)){seterr(p,"can't parse filter expression: syntax error");return NULL;}next(p);
    if(p->t.t!=T_WORD||!number(p->t.s,&v)){
        struct {const char*n;uint32_t v;} q[]={{"icmp-echo",8},{"icmp-echoreply",0},{"icmp-unreach",3},{"icmp-redirect",5},{"icmp-timxceed",11},{"icmp-tstamp",13},{"icmp-tstampreply",14},{"icmp-ireq",15},{"tcp-fin",1},{"tcp-syn",2},{"tcp-rst",4},{"tcp-push",8},{"tcp-ack",16},{"tcp-urg",32},{"tcp-ece",64},{"tcp-cwr",128}};int ok=0;
        if(p->t.t==T_WORD)for(size_t i=0;i<sizeof(q)/sizeof(q[0]);i++)if(!strcmp(p->t.s,q[i].n)){v=q[i].v;ok=1;break;}if(!ok){seterr(p,"can't parse filter expression: syntax error");return NULL;}
    }n->val2=(n->val2&0xffff0000u)|v;next(p);return n;
}
static node_t *parse_primary(parser_t*p){
    node_t*n=NULL;char first[128];dir_t dir=DIR_ANY;transport_t tp=TP_ANY;int family=0,dr;uint32_t v;
    if(++p->depth>AST_MAX_DEPTH){seterr(p,"filter expression too complex");return NULL;}
    if(p->t.t==T_LP){next(p);n=parse_expr(p);if(!n||p->t.t!=T_RP){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);p->depth--;return n;}
    if(p->t.t!=T_WORD){seterr(p,"can't parse filter expression: syntax error");p->depth--;return NULL;}
    strncpy(first,p->t.s,sizeof(first)-1);first[sizeof(first)-1]=0;next(p);
    if(p->t.t==T_LB){n=parse_byte(p,first);p->depth--;return n;}
    if(!strcmp(first,"less")||!strcmp(first,"greater")){n=prim(p,PR_LEN);if(!n)goto out;n->cmp=!strcmp(first,"less")?CMP_LT:CMP_GT;if(p->t.t!=T_WORD||!number(p->t.s,&n->val)){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);goto out;}
    if(!strcmp(first,"len")){n=prim(p,PR_LEN);if(!n)goto out;if(!cmp_tok(p->t.t,&n->cmp)){seterr(p,"can't parse filter expression: syntax error");n=NULL;goto out;}next(p);if(p->t.t!=T_WORD||!number(p->t.s,&n->val)){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);goto out;}
    if(!strcmp(first,"ether")&&word(p,"proto")){next(p);n=prim(p,PR_ETHERTYPE);if(p->t.t!=T_WORD||!ether_num(p->t.s,&n->val)){snprintf(p->a->err,sizeof(p->a->err),"unknown ether proto '%s'",p->t.s[0]=='\\'?p->t.s+1:p->t.s);n=NULL;}else next(p);goto out;}
    if(!strcmp(first,"ether")&&(word(p,"host")||word(p,"src")||word(p,"dst"))){n=prim(p,PR_ETHER_HOST);if(!n)goto out;if(word(p,"src")){n->dir=DIR_SRC;next(p);if(word(p,"host"))next(p);}else if(word(p,"dst")){n->dir=DIR_DST;next(p);if(word(p,"host"))next(p);}else {n->dir=DIR_ANY;next(p);}if(p->t.t!=T_WORD||!mac(p->t.s,n->addr)){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);goto out;}
    if(!strcmp(first,"ip")&&word(p,"proto")){next(p);n=prim(p,PR_IPPROTO4);if(p->t.t!=T_WORD||!proto_num(p->t.s,&n->val)){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);goto out;}
    if(!strcmp(first,"ip6")&&word(p,"proto")){next(p);n=prim(p,PR_IPPROTO6);if(p->t.t!=T_WORD||!proto_num(p->t.s,&n->val)){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);goto out;}
    if(!strcmp(first,"tcp")){tp=TP_TCP;v=6;}else if(!strcmp(first,"udp")){tp=TP_UDP;v=17;}else if(!strcmp(first,"sctp")){tp=TP_SCTP;v=132;}
    if(tp!=TP_ANY&&!word(p,"port")&&!word(p,"portrange")&&!word(p,"src")&&!word(p,"dst")){n=prim(p,PR_IPPROTO);n->val=v;goto out;}
    if(!strcmp(first,"ip"))family=4;else if(!strcmp(first,"ip6"))family=6;else if(!strcmp(first,"arp"))family=1;else if(!strcmp(first,"rarp"))family=2;
    if(family&&!word(p,"host")&&!word(p,"net")&&!word(p,"src")&&!word(p,"dst")){n=prim(p,PR_ETHERTYPE);n->val=family==4?0x0800:family==6?0x86dd:family==1?0x0806:0x8035;goto out;}
    if(tp!=TP_ANY||family){dr=parse_dir(p,&dir);if(dr<0){seterr(p,"can't parse filter expression: syntax error");goto out;}}
    else {
        if(!strcmp(first,"src"))dir=DIR_SRC;else if(!strcmp(first,"dst"))dir=DIR_DST;
        if(dir!=DIR_ANY&&(p->t.t==T_AND||p->t.t==T_OR)){tt_t op=p->t.t;next(p);if((dir==DIR_SRC&&!word(p,"dst"))||(dir==DIR_DST&&!word(p,"src"))){seterr(p,"can't parse filter expression: syntax error");goto out;}next(p);dir=op==T_AND?DIR_BOTH:DIR_ANY;}
    }
    if(!strcmp(first,"port")||!strcmp(first,"portrange")||word(p,"port")||word(p,"portrange")){
        int range=!strcmp(first,"portrange")||word(p,"portrange");
        if(word(p,"port")||word(p,"portrange"))next(p);
        n=prim(p,range?PR_PORTRANGE:PR_PORT);n->dir=dir;n->transport=tp;
        if(p->t.t!=T_WORD){seterr(p,"can't parse filter expression: syntax error");n=NULL;goto out;}
        if(range){char*q=strchr(p->t.s,'-');if(!q){seterr(p,"can't parse filter expression: syntax error");n=NULL;goto out;}*q=0;if(!number(p->t.s,&n->val)||!number(q+1,&n->val2)){seterr(p,"can't parse filter expression: syntax error");n=NULL;goto out;}}
        else if(!service_num(p->t.s,&n->val,&n->transport)){seterr(p,"can't parse filter expression: syntax error");n=NULL;goto out;}
        if(n&&(n->val>65535||n->val2>65535)){snprintf(p->a->err,sizeof(p->a->err),"illegal port number %u > 65535",n->val>65535?n->val:n->val2);n=NULL;}next(p);goto out;
    }
    if(!strcmp(first,"host")||!strcmp(first,"net")||word(p,"host")||word(p,"net")){
        int isn=!strcmp(first,"net")||word(p,"net");char text[128],*slash;int prefix=-1;
        if(word(p,"host")||word(p,"net"))next(p);
        if(p->t.t!=T_WORD){seterr(p,"can't parse filter expression: syntax error");goto out;}
        snprintf(text,sizeof(text),"%s",p->t.s);slash=strchr(text,'/');if(slash){*slash=0;prefix=atoi(slash+1);}
        if(family==6||strchr(text,':')){n=prim(p,isn?PR_NET6:PR_HOST6);if(!ipv6(text,n->addr)){snprintf(p->a->err,sizeof(p->a->err),"unknown host '%s'",text);n=NULL;}else n->val2=prefix<0?128:(uint32_t)prefix;}
        else {n=prim(p,isn?PR_NET4:PR_HOST4);if(!strcmp(text,"localhost"))n->val=0x7f000001;else if(!strcmp(text,"link-local")){n->val=0xa9fe0000;n->mask=0xffff0000;}else if(!ipv4(text,&n->val)){if(isn)snprintf(p->a->err,sizeof(p->a->err),"unknown network '%s'",text);else if(isdigit((unsigned char)text[0]))snprintf(p->a->err,sizeof(p->a->err),"invalid IPv4 address '%s'",text);else snprintf(p->a->err,sizeof(p->a->err),"unknown host '%s'",text);n=NULL;}if(n&&prefix>=0)n->mask=prefix?0xffffffffu<<(32-prefix):0;}
        if(n){n->dir=dir;if(n->prim==PR_HOST4||n->prim==PR_NET4)n->val2=(uint32_t)family;}next(p);
        if(n&&isn&&word(p,"mask")){next(p);if(p->t.t!=T_WORD||!ipv4(p->t.s,&n->mask)){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);}goto out;
    }
    { struct {const char*n;prim_kind_t k;uint32_t v;} q[]={{"icmp",PR_IPPROTO4,1},{"igmp",PR_IPPROTO4,2},{"igrp",PR_IPPROTO4,9},{"esp",PR_IPPROTO,50},{"ah",PR_IPPROTO,51},{"pim",PR_IPPROTO,103},{"vrrp",PR_IPPROTO4,112},{"carp",PR_IPPROTO4,112},{"icmp6",PR_IPPROTO6,58},{"ipx",PR_ETHERTYPE,0x8137},{"atalk",PR_ETHERTYPE,0x809b},{"aarp",PR_ETHERTYPE,0x80f3},{"netbeui",PR_ETHERTYPE,0xf0f0},{"sca",PR_ETHERTYPE,0x6007},{"moprc",PR_ETHERTYPE,0x6002},{"stp",PR_ETHERTYPE,0x0042}};for(size_t i=0;i<sizeof(q)/sizeof(q[0]);i++)if(!strcmp(first,q[i].n)){n=prim(p,q[i].k);n->val=q[i].v;goto out;}}
    if(!strcmp(first,"vlan")){n=prim(p,PR_VLAN);if(p->t.t==T_WORD&&number(p->t.s,&n->val)){n->val2=1;next(p);}goto out;}
    if(!strcmp(first,"mpls")){n=prim(p,PR_MPLS);if(p->t.t==T_WORD&&number(p->t.s,&n->val)){n->val2=1;next(p);}goto out;}
    if(!strcmp(first,"pppoes")||!strcmp(first,"pppoed")){n=prim(p,PR_PPPOE);n->val=!strcmp(first,"pppoes")?0x8864:0x8863;goto out;}
    if(!strcmp(first,"ifindex")){n=prim(p,PR_IFINDEX);if(p->t.t!=T_WORD||!number(p->t.s,&n->val)){seterr(p,"can't parse filter expression: syntax error");n=NULL;}else next(p);goto out;}
    if(!strcmp(first,"inbound")||!strcmp(first,"outbound")){n=prim(p,PR_DIRECTION);n->val=!strcmp(first,"outbound");goto out;}
    if(!strcmp(first,"broadcast")||!strcmp(first,"multicast")){n=prim(p,!strcmp(first,"broadcast")?PR_BROADCAST:PR_MULTICAST);goto out;}
    seterr(p,"can't parse filter expression: syntax error");
out:p->depth--;return n;
}
static node_t *parse_unary(parser_t*p){if(p->t.t==T_NOT){node_t*n=nn(p,NODE_NOT);next(p);n->l=parse_unary(p);return n->l?n:NULL;}return parse_primary(p);}
static node_t *parse_and(parser_t*p){node_t*l=parse_unary(p);while(l&&p->t.t==T_AND){node_t*n=nn(p,NODE_AND);next(p);n->l=l;n->r=parse_unary(p);if(!n->r)return NULL;l=n;}return l;}
static node_t *parse_expr(parser_t*p){node_t*l=parse_and(p);while(l&&p->t.t==T_OR){node_t*n=nn(p,NODE_OR);next(p);n->l=l;n->r=parse_and(p);if(!n->r)return NULL;l=n;}return l;}
node_t *filter_parse(const char*text,ast_arena_t*a,const bpfc_case_t*c){parser_t p;node_t*n;memset(a,0,sizeof(*a));memset(&p,0,sizeof(p));p.s=text;p.a=a;p.c=c;next(&p);if(p.t.t==T_END)return nn(&p,NODE_TRUE);n=parse_expr(&p);if(!n||p.t.t!=T_END){if(!a->err[0])seterr(&p,"can't parse filter expression: syntax error");return NULL;}return n;}
