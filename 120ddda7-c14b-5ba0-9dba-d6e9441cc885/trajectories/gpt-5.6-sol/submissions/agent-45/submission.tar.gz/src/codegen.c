#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "filter.h"

void bpf_prog_init(bpf_prog_t*p){memset(p,0,sizeof(*p));}
void bpf_prog_free(bpf_prog_t*p){free(p->insns);bpf_prog_init(p);}
void bpf_prog_reset(bpf_prog_t*p){p->len=0;p->overflow=0;}
void bpf_emit(bpf_prog_t*p,uint16_t c,uint8_t jt,uint8_t jf,uint32_t k){if(p->overflow)return;if(p->len>=BPF_MAXINSNS){p->overflow=1;return;}if(p->len==p->cap){size_t z=p->cap?p->cap*2:128;bpf_insn_t*q=realloc(p->insns,z*sizeof(*q));if(!q){p->overflow=1;return;}p->insns=q;p->cap=z;}p->insns[p->len++]=(bpf_insn_t){c,jt,jf,k};}

enum{L_TRUE=-1,L_FALSE=-2};
typedef struct{size_t at;int t,f;}fix_t;
typedef struct{bpf_prog_t*p;const bpfc_case_t*c;fix_t fix[BPF_MAXINSNS];size_t nf;unsigned link,net;int dynamic,vlan_depth,mpls_depth,raw_slot,raw_guarded,wifi_slot,wifi_ready;int labels[BPF_MAXINSNS],nl;}gen_t;
static void ins(gen_t*g,uint16_t c,uint32_t k){bpf_emit(g->p,c,0,0,k);}
static void jump(gen_t*g,uint16_t c,uint32_t k,int t,int f){size_t at=g->p->len;bpf_emit(g->p,c,0,0,k);if(g->nf<BPF_MAXINSNS)g->fix[g->nf++]=(fix_t){at,t,f};else g->p->overflow=1;}
static uint32_t be32(const unsigned char*p){return((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static int newlabel(gen_t*g){int n=g->nl;g->labels[g->nl++]=-1;return -100-n;}
static void bindlabel(gen_t*g,int l){g->labels[-100-l]=(int)g->p->len;}
static uint32_t be16(const unsigned char*p){return((uint32_t)p[0]<<8)|p[1];}
static void layout(gen_t*g){g->dynamic=0;switch(g->c->dlt){case 1:g->link=14;break;case 113:g->link=16;break;case 9:case 0:g->link=4;break;case 12:g->link=0;break;case 105:g->link=0;g->dynamic=1;break;default:g->link=14;}g->net=g->link+4U*g->vlan_depth+4U*g->mpls_depth;}

static void emit_80211_setup(gen_t*g){int s=(int)g->p->len,m=g->wifi_slot;if(g->wifi_ready)return;g->wifi_ready=1;ins(g,1,0);ins(g,135,0);ins(g,4,24);ins(g,2,m);ins(g,80,0);jump(g,69,8,s+6,s+11);jump(g,69,4,s+11,s+7);jump(g,69,128,s+8,s+11);ins(g,96,m);ins(g,4,2);ins(g,2,m);}
static void emit_80211_prefix(gen_t*g,int T){int s;if(!g->wifi_ready)emit_80211_setup(g);s=(int)g->p->len;ins(g,48,0);jump(g,69,4,T,s+2);ins(g,48,0);jump(g,69,8,s+4,T);}
static void emit_ethertype(gen_t*g,uint32_t v,int T,int F){unsigned off;if(g->c->optimize&&F==L_FALSE){if(v==0x0800)g->raw_guarded=BASE_IP;else if(v==0x86dd)g->raw_guarded=BASE_IP6;}if(g->mpls_depth&&(v==0x0800||v==0x86dd)){ins(g,48,g->link+4U*g->mpls_depth-2);ins(g,84,1);jump(g,21,1,(int)g->p->len+1,F);ins(g,48,g->link+4U*g->mpls_depth);ins(g,84,240);jump(g,21,v==0x0800?64:96,T,F);return;}if(g->c->dlt==105){emit_80211_prefix(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,v,T,F);return;}if(g->c->dlt==12){if(v!=0x0800&&v!=0x86dd){ins(g,0,1);jump(g,21,0,T,F);return;}ins(g,48,0);ins(g,84,240);jump(g,21,v==0x0800?64:96,T,F);return;}if(g->c->dlt==0){if(v!=0x0800&&v!=0x86dd){ins(g,0,1);jump(g,21,0,T,F);return;}ins(g,32,0);jump(g,21,v==0x0800?33554432U:167772160U,T,F);return;}off=g->c->dlt==1?12:g->c->dlt==113?14:2;off+=4U*g->vlan_depth;ins(g,40,off);if(g->c->dlt==9){if(v==0x0800)v=33;else if(v==0x86dd)v=87;else if(v==0x8137)v=43;else if(v==0x8847)v=641;}jump(g,21,v,T,F);}
static void emit_ipv4_guard(gen_t*g,int T,int F){emit_ethertype(g,0x0800,T,F);}
static void emit_ipv6_guard(gen_t*g,int T,int F){emit_ethertype(g,0x86dd,T,F);}
static void emit_proto4(gen_t*g,uint32_t v,int T,int F){if(!(g->c->optimize&&!g->dynamic&&g->raw_guarded==BASE_IP)){int body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);}layout(g);if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,80,17);}else ins(g,48,g->net+9);jump(g,21,v,T,F);}
static void emit_proto6(gen_t*g,uint32_t v,int T,int F){int body=newlabel(g);emit_ipv6_guard(g,body,F);bindlabel(g,body);layout(g);if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,80,14);}else ins(g,48,g->net+6);jump(g,21,v,T,(int)g->p->len+1);if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,80,14);}else if(!g->c->optimize)ins(g,48,g->net+6);jump(g,21,44,(int)g->p->len+1,F);if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,80,48);}else ins(g,48,g->net+40);jump(g,21,v,T,F);}
static void emit_proto_both_raw(gen_t*g,uint32_t v,int T,int F){int next=newlabel(g);emit_proto4(g,v,T,next);bindlabel(g,next);emit_proto6(g,v,T,F);}
static void emit_proto_both_opt(gen_t*g,uint32_t v,int T,int F){int s=(int)g->p->len;layout(g);if(g->c->dlt==105){emit_80211_prefix(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,0x0800,s+27,s+19);ins(g,97,g->wifi_slot);ins(g,80,14);jump(g,21,v,T,s+22);jump(g,21,44,s+24,F);ins(g,97,g->wifi_slot);ins(g,80,48);jump(g,21,v,T,F);ins(g,97,g->wifi_slot);ins(g,80,17);jump(g,21,v,T,F);return;}if(g->c->dlt==12){ins(g,48,0);ins(g,84,240);jump(g,21,64,s+11,s+3);ins(g,48,0);ins(g,84,240);jump(g,21,96,s+6,F);ins(g,48,6);jump(g,21,v,T,s+8);jump(g,21,44,s+9,F);ins(g,48,40);jump(g,21,v,T,F);ins(g,48,9);jump(g,21,v,T,F);return;}if(g->c->dlt==0){ins(g,32,0);jump(g,21,33554432U,s+8,s+2);jump(g,21,167772160U,s+3,F);ins(g,48,10);jump(g,21,v,T,s+5);jump(g,21,44,s+6,F);ins(g,48,44);jump(g,21,v,T,F);ins(g,48,13);jump(g,21,v,T,F);return;}{unsigned eo=g->c->dlt==1?12:g->c->dlt==113?14:2,no=g->c->dlt==1?14:g->c->dlt==113?16:4;uint32_t e4=g->c->dlt==9?33:2048,e6=g->c->dlt==9?87:34525;ins(g,40,eo);jump(g,21,e4,s+8,s+2);jump(g,21,e6,s+3,F);ins(g,48,no+6);jump(g,21,v,T,s+5);jump(g,21,44,s+6,F);ins(g,48,no+40);jump(g,21,v,T,F);ins(g,48,no+9);jump(g,21,v,T,F);}}
static void emit_protochain(gen_t*g,const node_t*n,int T,int F){unsigned no;layout(g);if(n->proto==6){int body=newlabel(g);emit_ipv6_guard(g,body,F);bindlabel(g,body);no=g->net;ins(g,48,no+6);ins(g,1,40);bpf_emit(g->p,21,27,0,n->value);bpf_emit(g->p,21,26,0,59);bpf_emit(g->p,21,3,0,0);bpf_emit(g->p,21,2,0,60);bpf_emit(g->p,21,1,0,43);bpf_emit(g->p,21,0,9,44);ins(g,80,no);ins(g,2,15);ins(g,80,no+1);ins(g,4,1);ins(g,36,8);ins(g,12,0);ins(g,7,0);ins(g,96,15);ins(g,5,0xfffffff1U);bpf_emit(g->p,21,0,12,51);ins(g,135,0);ins(g,80,no);ins(g,2,15);ins(g,135,0);ins(g,4,1);ins(g,7,0);ins(g,80,no);ins(g,4,2);ins(g,36,4);ins(g,7,0);ins(g,96,15);ins(g,5,0xffffffe4U);ins(g,4,0);jump(g,21,n->value,T,F);}else{int body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);no=g->net;ins(g,48,no+9);ins(g,177,no);bpf_emit(g->p,21,15,0,n->value);bpf_emit(g->p,21,14,0,59);ins(g,4,0);bpf_emit(g->p,21,0,12,51);ins(g,135,0);ins(g,80,no);ins(g,2,15);ins(g,135,0);ins(g,4,1);ins(g,7,0);ins(g,80,no);ins(g,4,2);ins(g,36,4);ins(g,7,0);ins(g,96,15);ins(g,5,0xfffffff0U);ins(g,4,0);jump(g,21,n->value,T,F);}}
static void emit_wifi_vlan_gate(gen_t*g,uint32_t type,unsigned off,int body,int miss){ins(g,48,0);jump(g,69,4,miss,(int)g->p->len+1);ins(g,48,0);jump(g,69,8,(int)g->p->len+1,miss);ins(g,97,g->wifi_slot);ins(g,72,off);jump(g,21,type,body,miss);}
static void emit_ipproto_wifi_vlan(gen_t*g,const node_t*n,int T,int F){unsigned typeoff=6U+4U*g->vlan_depth;int v6=newlabel(g),body;if(n->proto!=6){body=newlabel(g);emit_wifi_vlan_gate(g,2048,typeoff,body,n->proto==4?F:v6);bindlabel(g,body);ins(g,97,g->wifi_slot);ins(g,80,typeoff+11);jump(g,21,n->value,T,n->proto==4?F:v6);}if(n->proto==4)return;bindlabel(g,v6);body=newlabel(g);emit_wifi_vlan_gate(g,34525,typeoff,body,F);bindlabel(g,body);ins(g,97,g->wifi_slot);ins(g,80,typeoff+8);jump(g,21,n->value,T,(int)g->p->len+1);ins(g,97,g->wifi_slot);ins(g,80,typeoff+8);jump(g,21,44,(int)g->p->len+1,F);ins(g,97,g->wifi_slot);ins(g,80,typeoff+42);jump(g,21,n->value,T,F);}
static void emit_ipproto(gen_t*g,const node_t*n,int T,int F){if(g->c->dlt==105&&g->vlan_depth){emit_ipproto_wifi_vlan(g,n,T,F);return;}if(n->value2){emit_protochain(g,n,T,F);return;}if(n->proto==4)emit_proto4(g,n->value,T,F);else if(n->proto==6)emit_proto6(g,n->value,T,F);else if(g->c->optimize&&!(g->c->dlt==105&&T<L_FALSE&&F<L_FALSE))emit_proto_both_opt(g,n->value,T,F);else emit_proto_both_raw(g,n->value,T,F);}

static void emit_addr4(gen_t*g,unsigned off,uint32_t v,uint32_t m,int T,int F){if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,64,off);}else ins(g,32,off);if(m!=0xffffffffU)ins(g,84,m);jump(g,21,v&m,T,F);}
static void emit_wifi_v4gate(gen_t*g,int F);
static void emit_wifi_host_block(gen_t*g,const node_t*n,uint32_t type,unsigned off,int T,int F,int first){int body=newlabel(g);if(first)emit_80211_prefix(g,F);else emit_wifi_v4gate(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,type,body,F);bindlabel(g,body);emit_addr4(g,off,n->value,n->mask,T,F);}
static void emit_host4_wifi(gen_t*g,const node_t*n,int T,int F){uint32_t types[3]={2048,2054,32821};unsigned src[3]={20,22,22},dst[3]={24,32,32};int nt=n->proto==4?1:3,first=1;if(n->dir==DIR_BOTH_AND){for(int i=0;i<nt;i++){int d=newlabel(g),next=i==nt-1?F:newlabel(g);emit_wifi_host_block(g,n,types[i],src[i],d,next,first);first=0;bindlabel(g,d);emit_wifi_host_block(g,n,types[i],dst[i],T,next,first);if(i<nt-1)bindlabel(g,next);}return;}for(int i=0;i<nt;i++){if(n->dir!=DIR_DST){int next=(n->dir==DIR_SRC&&i==nt-1)?F:newlabel(g);emit_wifi_host_block(g,n,types[i],src[i],T,next,first);first=0;if(next!=F)bindlabel(g,next);}if(n->dir!=DIR_SRC){int next=i==nt-1?F:newlabel(g);emit_wifi_host_block(g,n,types[i],dst[i],T,next,first);first=0;if(i<nt-1)bindlabel(g,next);}}}
static void emit_host4_explicit(gen_t*g,const node_t*n,int T,int F){unsigned src,dst;int body,next=F;layout(g);src=g->net+12;dst=g->net+16;if(!g->c->optimize&&n->dir!=DIR_SRC&&n->dir!=DIR_DST)next=newlabel(g);body=newlabel(g);emit_ipv4_guard(g,body,next);bindlabel(g,body);if(n->dir==DIR_SRC)emit_addr4(g,src,n->value,n->mask,T,F);else if(n->dir==DIR_DST)emit_addr4(g,dst,n->value,n->mask,T,F);else{if(g->c->optimize)next=newlabel(g);emit_addr4(g,src,n->value,n->mask,T,next);bindlabel(g,next);if(!g->c->optimize){body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);}emit_addr4(g,dst,n->value,n->mask,T,F);}}
static void emit_host4_opt(gen_t*g,const node_t*n,int T,int F){unsigned eo,ips,ipd,as,ad;int lip=newlabel(g),larp=newlabel(g),laddr=newlabel(g),next;layout(g);if(g->c->dlt==12||g->c->dlt==0){emit_host4_explicit(g,n,T,F);return;}eo=(g->c->dlt==1?12:g->c->dlt==113?14:2)+4U*g->vlan_depth;ips=g->net+12;ipd=g->net+16;as=g->net+14;ad=g->net+24;ins(g,40,eo);jump(g,21,g->c->dlt==9?33:2048,lip,(int)g->p->len+1);jump(g,21,2054,larp,(int)g->p->len+1);jump(g,21,32821,larp,F);bindlabel(g,larp);if(n->dir!=DIR_DST){next=n->dir==DIR_SRC?F:newlabel(g);emit_addr4(g,as,n->value,n->mask,n->dir==DIR_BOTH_AND?next:T,n->dir==DIR_BOTH_AND?F:next);if(n->dir!=DIR_SRC)bindlabel(g,next);}if(n->dir!=DIR_SRC)emit_addr4(g,ad,n->value,n->mask,T,F);bindlabel(g,lip);if(n->dir!=DIR_DST){next=n->dir==DIR_SRC?F:laddr;emit_addr4(g,ips,n->value,n->mask,n->dir==DIR_BOTH_AND?next:T,n->dir==DIR_BOTH_AND?F:next);}if(n->dir!=DIR_SRC){bindlabel(g,laddr);emit_addr4(g,ipd,n->value,n->mask,T,F);}} 
static void emit_host4_raw(gen_t*g,const node_t*n,int T,int F){unsigned ty[3]={2048,2054,32821},so[3],dd[3];layout(g);so[0]=g->net+12;dd[0]=g->net+16;so[1]=so[2]=g->net+14;dd[1]=dd[2]=g->net+24;for(int i=0;i<3;i++){int last=i==2,cont=last?F:newlabel(g),body=newlabel(g);if(n->dir==DIR_SRC||n->dir==DIR_DST){unsigned off=n->dir==DIR_SRC?so[i]:dd[i];emit_ethertype(g,ty[i],body,cont);bindlabel(g,body);emit_addr4(g,off,n->value,n->mask,T,cont);}else if(n->dir==DIR_BOTH_AND){int dest=newlabel(g),dbody=newlabel(g);emit_ethertype(g,ty[i],body,cont);bindlabel(g,body);emit_addr4(g,so[i],n->value,n->mask,dest,cont);bindlabel(g,dest);emit_ethertype(g,ty[i],dbody,cont);bindlabel(g,dbody);emit_addr4(g,dd[i],n->value,n->mask,T,cont);}else{int dest=newlabel(g),dbody=newlabel(g);emit_ethertype(g,ty[i],body,dest);bindlabel(g,body);emit_addr4(g,so[i],n->value,n->mask,T,dest);bindlabel(g,dest);emit_ethertype(g,ty[i],dbody,cont);bindlabel(g,dbody);emit_addr4(g,dd[i],n->value,n->mask,T,cont);}if(!last)bindlabel(g,cont);}} 
static void emit_host4_linkproto(gen_t*g,const node_t*n,int T,int F){int body=newlabel(g),next;unsigned src,dst;layout(g);src=g->net+14;dst=g->net+24;if(g->c->optimize||n->dir==DIR_SRC||n->dir==DIR_DST){emit_ethertype(g,n->value2,body,F);bindlabel(g,body);if(n->dir==DIR_SRC)emit_addr4(g,src,n->value,n->mask,T,F);else if(n->dir==DIR_DST)emit_addr4(g,dst,n->value,n->mask,T,F);else{next=newlabel(g);emit_addr4(g,src,n->value,n->mask,T,next);bindlabel(g,next);emit_addr4(g,dst,n->value,n->mask,T,F);}}else{next=newlabel(g);emit_ethertype(g,n->value2,body,next);bindlabel(g,body);emit_addr4(g,src,n->value,n->mask,T,next);bindlabel(g,next);body=newlabel(g);emit_ethertype(g,n->value2,body,F);bindlabel(g,body);emit_addr4(g,dst,n->value,n->mask,T,F);}}
static void emit_host6(gen_t*g,const node_t*n,int T,int F);
static void emit_v6words(gen_t*g,const node_t*n,unsigned base,int T,int F);
static void emit_host4_base(gen_t*g,const node_t*n,int T,int F){if(n->proto==4)emit_host4_explicit(g,n,T,F);else if(n->proto==1)emit_host4_linkproto(g,n,T,F);else if(g->c->optimize)emit_host4_opt(g,n,T,F);else emit_host4_raw(g,n,T,F);}
static void emit_localhost_opt(gen_t*g,const node_t*n,int T,int F){node_t v6=*n;int lip=newlabel(g),larp=newlabel(g),lv6=newlabel(g),next;layout(g);v6.prim=PK_HOST6;v6.prefix=128;memset(v6.addr,0,16);v6.addr[15]=1;ins(g,40,g->c->dlt==1?12:g->c->dlt==113?14:2);jump(g,21,g->c->dlt==9?87:34525,lv6,(int)g->p->len+1);jump(g,21,g->c->dlt==9?33:2048,lip,(int)g->p->len+1);jump(g,21,2054,larp,(int)g->p->len+1);jump(g,21,32821,larp,F);bindlabel(g,larp);next=newlabel(g);emit_addr4(g,g->net+14,n->value,n->mask,T,next);bindlabel(g,next);emit_addr4(g,g->net+24,n->value,n->mask,T,F);bindlabel(g,lip);next=newlabel(g);emit_addr4(g,g->net+12,n->value,n->mask,T,next);bindlabel(g,next);emit_addr4(g,g->net+16,n->value,n->mask,T,F);bindlabel(g,lv6);next=newlabel(g);emit_v6words(g,&v6,g->net+8,T,next);bindlabel(g,next);emit_v6words(g,&v6,g->net+24,T,F);}

static void emit_host4(gen_t*g,const node_t*n,int T,int F){if(g->c->dlt==105){emit_host4_wifi(g,n,T,F);return;}if(n->prefix==255&&n->proto==0&&g->c->optimize){emit_localhost_opt(g,n,T,F);return;}if(n->prefix==255&&n->proto==0&&!g->c->optimize){node_t q=*n;int v4=newlabel(g);q.prim=PK_HOST6;q.prefix=128;memset(q.addr,0,16);q.addr[15]=1;emit_host6(g,&q,T,v4);bindlabel(g,v4);q=*n;q.prefix=0;emit_host4_base(g,&q,T,F);}else emit_host4_base(g,n,T,F);}

static void emit_v6words(gen_t*g,const node_t*n,unsigned base,int T,int F){unsigned bits=n->prim==PK_NET6?n->prefix:128;int words=(!g->c->optimize&&n->prim==PK_NET6)?4:(int)((bits+31)/32);if(!words){jump(g,21,0,T,F);return;}for(int i=0;i<words;i++){uint32_t v=be32(n->addr+4*i),m=0xffffffffU;int last=i==words-1,remain=(int)bits-32*i;if(n->prim==PK_NET6){if(remain<=0)m=0;else if(remain<32)m<<=32-remain;}ins(g,32,base+4U*i);if(m!=0xffffffffU)ins(g,84,m);jump(g,21,v&m,last?T:(int)g->p->len+1,F);}}
static void emit_wifi_v6words(gen_t*g,const node_t*n,unsigned base,int T,int F){unsigned bits=n->prim==PK_NET6?n->prefix:128;int words=(int)((bits+31)/32);for(int i=0;i<words;i++){uint32_t v=be32(n->addr+4*i),m=0xffffffffU;int remain=(int)bits-32*i;if(n->prim==PK_NET6&&remain<32)m=remain<=0?0:m<<(32-remain);ins(g,97,g->wifi_slot);ins(g,64,base+4U*i);if(m!=0xffffffffU)ins(g,84,m);jump(g,21,v&m,i==words-1?T:(int)g->p->len+1,F);}}
static void emit_wifi_host6_block(gen_t*g,const node_t*n,unsigned off,int T,int F,int first){int body=newlabel(g);if(first)emit_80211_prefix(g,F);else emit_wifi_v4gate(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,34525,body,F);bindlabel(g,body);emit_wifi_v6words(g,n,off,T,F);}
static void emit_host6(gen_t*g,const node_t*n,int T,int F){unsigned src,dst;int body,next;layout(g);if(g->c->dlt==105){if(n->dir==DIR_SRC)emit_wifi_host6_block(g,n,16,T,F,1);else if(n->dir==DIR_DST)emit_wifi_host6_block(g,n,32,T,F,1);else{next=newlabel(g);emit_wifi_host6_block(g,n,16,n->dir==DIR_BOTH_AND?next:T,n->dir==DIR_BOTH_AND?F:next,1);bindlabel(g,next);emit_wifi_host6_block(g,n,32,T,F,0);}return;}src=g->net+8;dst=g->net+24;if(n->prim==PK_NET6&&n->prefix==0){emit_ipv6_guard(g,T,F);return;}body=newlabel(g);next=(!g->c->optimize&&n->dir!=DIR_SRC&&n->dir!=DIR_DST)?newlabel(g):F;emit_ipv6_guard(g,body,next);bindlabel(g,body);if(n->dir==DIR_SRC)emit_v6words(g,n,src,T,F);else if(n->dir==DIR_DST)emit_v6words(g,n,dst,T,F);else if(!g->c->optimize){emit_v6words(g,n,src,T,next);bindlabel(g,next);body=newlabel(g);emit_ipv6_guard(g,body,F);bindlabel(g,body);emit_v6words(g,n,dst,T,F);}else{next=newlabel(g);emit_v6words(g,n,src,T,next);bindlabel(g,next);emit_v6words(g,n,dst,T,F);}}
static void emit_mac_pair(gen_t*g,unsigned off,uint32_t w,uint32_t h,int T,int F){ins(g,32,off);jump(g,21,w,(int)g->p->len+1,F);ins(g,40,off+4);jump(g,21,h,T,F);}
static void emit_mac_wifi_opt(gen_t*g,const node_t*n,int T,int F){uint32_t w=be32(n->addr),h=be16(n->addr+4);int a1=newlabel(g),a2=newlabel(g),a3=newlabel(g),a4=newlabel(g),dsel=newlabel(g),da1=newlabel(g),da3=newlabel(g),mgmt=newlabel(g);ins(g,48,0);jump(g,69,4,F,(int)g->p->len+1);if(n->dir==DIR_DST){jump(g,69,8,(int)g->p->len+1,a1);ins(g,48,1);jump(g,69,1,a3,a1);bindlabel(g,a3);emit_mac_pair(g,16,w,h,T,F);bindlabel(g,a1);emit_mac_pair(g,4,w,h,T,F);return;}jump(g,69,8,(int)g->p->len+1,n->dir==DIR_SRC?a2:mgmt);ins(g,48,1);jump(g,69,2,(int)g->p->len+1,a2);jump(g,69,1,a4,a3);bindlabel(g,a4);emit_mac_pair(g,24,w,h,T,n->dir==DIR_SRC?F:da3);bindlabel(g,a3);emit_mac_pair(g,16,w,h,T,n->dir==DIR_SRC?F:da1);bindlabel(g,a2);emit_mac_pair(g,10,w,h,T,n->dir==DIR_SRC?F:dsel);if(n->dir==DIR_SRC)return;bindlabel(g,dsel);ins(g,48,1);jump(g,69,1,da3,da1);bindlabel(g,da3);emit_mac_pair(g,16,w,h,T,F);bindlabel(g,mgmt);emit_mac_pair(g,10,w,h,T,da1);bindlabel(g,da1);emit_mac_pair(g,4,w,h,T,F);}
static void emit_mac_wifi_raw(gen_t*g,const node_t*n,int T,int F){uint32_t w=be32(n->addr),h=be16(n->addr+4);int data=newlabel(g),first=newlabel(g),a1=newlabel(g),a2=newlabel(g),a3=newlabel(g),a4=newlabel(g);if(n->dir==DIR_ANY){emit_mac_wifi_opt(g,n,T,F);return;}ins(g,48,0);jump(g,69,4,F,(int)g->p->len+1);ins(g,48,0);if(n->dir==DIR_DST){jump(g,69,8,data,first);bindlabel(g,first);emit_mac_pair(g,4,w,h,T,data);bindlabel(g,data);ins(g,48,0);jump(g,69,8,(int)g->p->len+1,F);ins(g,48,1);jump(g,69,1,a3,a1);bindlabel(g,a1);emit_mac_pair(g,4,w,h,T,a3);bindlabel(g,a3);ins(g,48,1);jump(g,69,1,(int)g->p->len+1,F);emit_mac_pair(g,16,w,h,T,F);return;}jump(g,69,8,data,first);bindlabel(g,first);emit_mac_pair(g,10,w,h,T,data);bindlabel(g,data);ins(g,48,0);jump(g,69,8,(int)g->p->len+1,F);ins(g,48,1);jump(g,69,2,a2,(int)g->p->len+1);emit_mac_pair(g,10,w,h,T,a2);bindlabel(g,a2);ins(g,48,1);jump(g,69,2,(int)g->p->len+1,F);ins(g,48,1);jump(g,69,1,a4,a3);bindlabel(g,a3);emit_mac_pair(g,16,w,h,T,a4);bindlabel(g,a4);ins(g,48,1);jump(g,69,1,(int)g->p->len+1,F);emit_mac_pair(g,24,w,h,T,F);}
static void emit_mac(gen_t*g,const node_t*n,int T,int F){unsigned off=n->dir==DIR_SRC?6:0;uint32_t w=be32(n->addr),h=be16(n->addr+4);if(g->c->dlt==105){if(g->c->optimize&&n->dir==DIR_ANY&&T!=L_TRUE){node_t q=*n;int dst=newlabel(g);q.dir=DIR_SRC;emit_mac_wifi_raw(g,&q,T,dst);bindlabel(g,dst);q.dir=DIR_DST;emit_mac_wifi_raw(g,&q,T,F);}else if(g->c->optimize)emit_mac_wifi_opt(g,n,T,F);else emit_mac_wifi_raw(g,n,T,F);return;}if(n->dir==DIR_ANY){ins(g,32,6);jump(g,21,w,(int)g->p->len+1,(int)g->p->len+3);ins(g,40,10);jump(g,21,h,T,(int)g->p->len+1);ins(g,32,0);jump(g,21,w,(int)g->p->len+1,F);ins(g,40,4);jump(g,21,h,T,F);}else emit_mac_pair(g,off,w,h,T,F);}
static void emit_wifi_split(gen_t*g,int v4);
static void emit_vlan_wifi(gen_t*g,const node_t*n,int T,int F){int second=newlabel(g),third=newlabel(g),hit=n->value2?newlabel(g):T;unsigned typeoff=6U+4U*g->vlan_depth;if(!g->vlan_depth){emit_wifi_split(g,second);ins(g,97,g->wifi_slot);ins(g,72,typeoff);jump(g,21,0x8100,hit,second);}else{ins(g,48,0);bpf_emit(g->p,69,5,0,4);ins(g,48,0);bpf_emit(g->p,69,0,3,8);ins(g,97,g->wifi_slot);ins(g,72,typeoff);jump(g,21,0x8100,hit,second);}bindlabel(g,second);ins(g,48,0);bpf_emit(g->p,69,5,0,4);ins(g,48,0);bpf_emit(g->p,69,0,3,8);ins(g,97,g->wifi_slot);ins(g,72,typeoff);jump(g,21,0x88a8,hit,third);bindlabel(g,third);{int check=newlabel(g);ins(g,48,0);jump(g,69,4,F,(int)g->p->len+1);ins(g,48,0);jump(g,69,8,check,F);bindlabel(g,check);}ins(g,97,g->wifi_slot);ins(g,72,typeoff);jump(g,21,0x9100,hit,F);if(n->value2){bindlabel(g,hit);ins(g,97,g->wifi_slot);ins(g,72,typeoff+2);ins(g,84,4095);jump(g,21,n->value,T,F);}g->vlan_depth++;}
static void emit_vlan(gen_t*g,const node_t*n,int T,int F){if(g->c->dlt==105){emit_vlan_wifi(g,n,T,F);return;}unsigned off=(g->c->dlt==1?12U:g->c->dlt==113?14U:2U)+4U*g->vlan_depth;int s=(int)g->p->len,succ=n->value2?(g->c->optimize?s+4:s+6):T;if(g->c->optimize){ins(g,40,off);jump(g,21,33024,succ,s+2);jump(g,21,34984,succ,s+3);jump(g,21,37120,succ,F);}else{ins(g,40,off);jump(g,21,33024,succ,s+2);ins(g,40,off);jump(g,21,34984,succ,s+4);ins(g,40,off);jump(g,21,37120,succ,F);}g->vlan_depth++;if(n->value2){ins(g,40,off+2);ins(g,84,4095);jump(g,21,n->value,T,F);}}
static void emit_mpls(gen_t*g,const node_t*n,int T,int F){unsigned eo=g->c->dlt==1?12:g->c->dlt==113?14:2,off=(g->c->dlt==1?14:g->c->dlt==113?16:4)+4U*g->mpls_depth;int succ=n->value2?(int)g->p->len+2:T;if(!g->mpls_depth){ins(g,40,eo);jump(g,21,g->c->dlt==9?641:34887,succ,F);}else{ins(g,48,off-2);if(g->c->optimize)jump(g,69,1,F,(int)g->p->len+1);else{ins(g,84,1);jump(g,21,0,(int)g->p->len+1,F);}}if(n->value2){ins(g,32,off);ins(g,84,0xfffff000U);jump(g,21,n->value<<12,T,F);}g->mpls_depth++;}

static void emit_range_raw_one(gen_t*g,const node_t*n,uint16_t op,unsigned off,int ind,int hit,int miss){uint16_t lop=n->value?37:53;uint32_t low=n->value?n->value-1:0;ins(g,op,off);jump(g,lop,low,(int)g->p->len+1,miss);if(ind)ins(g,177,g->net);ins(g,op,off);jump(g,37,n->value2,miss,hit);}
static void emit_range_raw(gen_t*g,const node_t*n,unsigned base,int ind,int T,int F){uint16_t op=(uint16_t)(40+(ind?32:0));if(n->dir==DIR_SRC)emit_range_raw_one(g,n,op,base,ind,T,F);else if(n->dir==DIR_DST)emit_range_raw_one(g,n,op,base+2,ind,T,F);else{int second=newlabel(g);emit_range_raw_one(g,n,op,base,ind,n->dir==DIR_BOTH_AND?second:T,n->dir==DIR_BOTH_AND?F:second);bindlabel(g,second);if(ind)ins(g,177,g->net);emit_range_raw_one(g,n,op,base+2,ind,T,F);}}
static void emit_port_checks(gen_t*g,const node_t*n,unsigned base,int ind,int T,int F){uint16_t op=(uint16_t)(40+(ind?32:0));int second;if(n->prim==PK_PORTRANGE&&!g->c->optimize){emit_range_raw(g,n,base,ind,T,F);return;}if(n->prim==PK_PORT){if(n->dir==DIR_SRC){ins(g,op,base);jump(g,21,n->value,T,F);}else if(n->dir==DIR_DST){ins(g,op,base+2);jump(g,21,n->value,T,F);}else{second=newlabel(g);ins(g,op,base);jump(g,21,n->value,n->dir==DIR_BOTH_AND?second:T,n->dir==DIR_BOTH_AND?F:second);bindlabel(g,second);if(!g->c->optimize&&ind)ins(g,177,g->net);ins(g,op,base+2);jump(g,21,n->value,T,F);}}else{int lowop=n->value?37:53;uint32_t low=n->value?n->value-1:0;second=newlabel(g);unsigned off=n->dir==DIR_DST?base+2:base;int miss=(n->dir==DIR_ANY||n->dir==DIR_BOTH_OR)?second:F,hit=n->dir==DIR_BOTH_AND?second:T;ins(g,op,off);jump(g,(uint16_t)lowop,low,(int)g->p->len+1,miss);jump(g,37,n->value2,miss,hit);if(n->dir==DIR_ANY||n->dir==DIR_BOTH_OR||n->dir==DIR_BOTH_AND){bindlabel(g,second);ins(g,op,base+2);jump(g,(uint16_t)lowop,low,(int)g->p->len+1,F);jump(g,37,n->value2,F,T);}}}
static void emit_range_v4_shared(gen_t*g,const node_t*n,unsigned base,int us,int ud,int T,int F){uint16_t lop=n->value?37:53;uint32_t low=n->value?n->value-1:0;if(n->dir==DIR_SRC){ins(g,72,base);jump(g,lop,low,us,F);}else if(n->dir==DIR_DST){ins(g,72,base+2);jump(g,lop,low,ud,F);}else{int dest=newlabel(g);ins(g,72,base);jump(g,lop,low,(int)g->p->len+1,n->dir==DIR_BOTH_AND?F:dest);jump(g,37,n->value2,n->dir==DIR_BOTH_AND?F:dest,n->dir==DIR_BOTH_AND?dest:T);bindlabel(g,dest);ins(g,72,base+2);jump(g,lop,low,ud,F);}}
static void emit_range_v6_shared(gen_t*g,const node_t*n,unsigned base,int us,int ud,int T,int F){uint16_t lop=n->value?37:53;uint32_t low=n->value?n->value-1:0;if(n->dir==DIR_SRC){ins(g,40,base);jump(g,lop,low,(int)g->p->len+1,F);bindlabel(g,us);jump(g,37,n->value2,F,T);}else if(n->dir==DIR_DST){ins(g,40,base+2);jump(g,lop,low,(int)g->p->len+1,F);bindlabel(g,ud);jump(g,37,n->value2,F,T);}else{int dest=newlabel(g);ins(g,40,base);jump(g,lop,low,(int)g->p->len+1,n->dir==DIR_BOTH_AND?F:dest);bindlabel(g,us);jump(g,37,n->value2,n->dir==DIR_BOTH_AND?F:dest,n->dir==DIR_BOTH_AND?dest:T);bindlabel(g,dest);ins(g,40,base+2);jump(g,lop,low,(int)g->p->len+1,F);bindlabel(g,ud);jump(g,37,n->value2,F,T);}}
static void emit_port_opt(gen_t*g,const node_t*n,int T,int F){int lv4=newlabel(g),lv6=newlabel(g),pv4=newlabel(g),pv6=newlabel(g),us=newlabel(g),ud=newlabel(g);unsigned eo,no;uint32_t e4,e6;layout(g);if(g->c->dlt==12){ins(g,48,0);ins(g,84,240);jump(g,21,96,lv6,(int)g->p->len+1);ins(g,48,0);ins(g,84,240);jump(g,21,64,lv4,F);}else if(g->c->dlt==0){ins(g,32,0);jump(g,21,167772160U,lv6,(int)g->p->len+1);jump(g,21,33554432U,lv4,F);}else{eo=(g->c->dlt==1?12U:g->c->dlt==113?14U:2U)+4U*g->vlan_depth;e4=g->c->dlt==9?33:2048;e6=g->c->dlt==9?87:34525;ins(g,40,eo);jump(g,21,e6,lv6,(int)g->p->len+1);jump(g,21,e4,lv4,F);}bindlabel(g,lv4);no=g->net;ins(g,48,no+9);if(n->proto>=0)jump(g,21,(uint32_t)n->proto,pv4,F);else{jump(g,21,132,pv4,(int)g->p->len+1);jump(g,21,6,pv4,(int)g->p->len+1);jump(g,21,17,pv4,F);}bindlabel(g,pv4);ins(g,40,no+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,no);if(n->prim==PK_PORTRANGE)emit_range_v4_shared(g,n,g->link+4U*g->vlan_depth,us,ud,T,F);else emit_port_checks(g,n,g->link+4U*g->vlan_depth,1,T,F);bindlabel(g,lv6);ins(g,48,no+6);if(n->proto>=0)jump(g,21,(uint32_t)n->proto,pv6,F);else{jump(g,21,132,pv6,(int)g->p->len+1);jump(g,21,6,pv6,(int)g->p->len+1);jump(g,21,17,pv6,F);}bindlabel(g,pv6);if(n->prim==PK_PORTRANGE)emit_range_v6_shared(g,n,no+40,us,ud,T,F);else emit_port_checks(g,n,no+40,0,T,F);}
static void emit_wifi_split(gen_t*g,int v4){if(!g->wifi_ready)emit_80211_setup(g);ins(g,48,0);jump(g,69,4,v4,(int)g->p->len+1);ins(g,48,0);jump(g,69,8,(int)g->p->len+1,v4);}
static void emit_wifi_v4gate(gen_t*g,int F){ins(g,48,0);jump(g,69,4,F,(int)g->p->len+1);ins(g,48,0);jump(g,69,8,(int)g->p->len+1,F);}
static void emit_wifi_port_load(gen_t*g,int v6,int dst){ins(g,97,g->wifi_slot);if(v6)ins(g,72,dst?50:48);else{ins(g,80,8);ins(g,84,15);ins(g,100,2);ins(g,12,0);ins(g,7,0);ins(g,72,dst?10:8);}}
static void emit_wifi_range(gen_t*g,const node_t*n,int v6,int dst,int T,int F){emit_wifi_port_load(g,v6,dst);jump(g,n->value?37:53,n->value?n->value-1:0,(int)g->p->len+1,F);emit_wifi_port_load(g,v6,dst);jump(g,37,n->value2,F,T);}
static void emit_wifi_ports(gen_t*g,const node_t*n,int v6,int T,int F){int second;if(n->dir==DIR_SRC||n->dir==DIR_DST){if(n->prim==PK_PORT){emit_wifi_port_load(g,v6,n->dir==DIR_DST);jump(g,21,n->value,T,F);}else emit_wifi_range(g,n,v6,n->dir==DIR_DST,T,F);return;}second=newlabel(g);if(n->prim==PK_PORT){emit_wifi_port_load(g,v6,0);jump(g,21,n->value,n->dir==DIR_BOTH_AND?second:T,n->dir==DIR_BOTH_AND?F:second);}else emit_wifi_range(g,n,v6,0,n->dir==DIR_BOTH_AND?second:T,n->dir==DIR_BOTH_AND?F:second);bindlabel(g,second);if(n->prim==PK_PORT){emit_wifi_port_load(g,v6,1);jump(g,21,n->value,T,F);}else emit_wifi_range(g,n,v6,1,T,F);}
static void emit_port_wifi(gen_t*g,const node_t*n,int T,int F){int protos[3]={132,6,17},np=n->proto>=0?1:3,v4=newlabel(g),net4=newlabel(g);if(n->proto>=0)protos[0]=n->proto;emit_wifi_split(g,v4);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,34525,(int)g->p->len+1,v4);for(int i=0;i<np;i++){int hit=newlabel(g),next=i==np-1?v4:newlabel(g);ins(g,97,g->wifi_slot);ins(g,80,14);jump(g,21,(uint32_t)protos[i],hit,next);bindlabel(g,hit);emit_wifi_ports(g,n,1,T,next);if(i<np-1)bindlabel(g,next);}bindlabel(g,v4);emit_wifi_v4gate(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,2048,net4,F);bindlabel(g,net4);for(int i=0;i<np;i++){int hit=newlabel(g),next=i==np-1?F:newlabel(g);ins(g,97,g->wifi_slot);ins(g,80,17);jump(g,21,(uint32_t)protos[i],hit,next);bindlabel(g,hit);ins(g,97,g->wifi_slot);ins(g,72,14);jump(g,69,8191,next,(int)g->p->len+1);emit_wifi_ports(g,n,0,T,next);if(i<np-1)bindlabel(g,next);}}
static void emit_port_raw(gen_t*g,const node_t*n,int T,int F){int protos[3]={132,6,17},np=n->proto>=0?1:3,lv4=newlabel(g),body=newlabel(g);layout(g);if(n->proto>=0)protos[0]=n->proto;emit_ipv6_guard(g,body,lv4);bindlabel(g,body);for(int i=0;i<np;i++){int checks=newlabel(g),next=i==np-1?lv4:newlabel(g);ins(g,48,g->net+6);jump(g,21,(uint32_t)protos[i],checks,next);bindlabel(g,checks);emit_port_checks(g,n,g->net+40,0,T,next);if(i<np-1)bindlabel(g,next);}bindlabel(g,lv4);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);for(int i=0;i<np;i++){int checks=newlabel(g),next=i==np-1?F:newlabel(g);ins(g,48,g->net+9);jump(g,21,(uint32_t)protos[i],checks,next);bindlabel(g,checks);ins(g,40,g->net+6);jump(g,69,8191,next,(int)g->p->len+1);ins(g,177,g->net);emit_port_checks(g,n,g->link+4U*g->vlan_depth,1,T,next);if(i<np-1)bindlabel(g,next);}}
static void emit_port(gen_t*g,const node_t*n,int T,int F){if(g->c->dlt==105){emit_port_wifi(g,n,T,F);return;}if(g->c->optimize)emit_port_opt(g,n,T,F);else emit_port_raw(g,n,T,F);}

static uint16_t ldop(unsigned w,int ind){return(uint16_t)((w==1?48:w==2?40:32)+(ind?32:0));}
static int cval(const arith_t*a,uint32_t*v){uint32_t l,r;if(!a)return 0;if(a->kind==A_CONST){*v=a->value;return 1;}if(!cval(a->l,&l)||!cval(a->r,&r))return 0;switch(a->kind){case A_ADD:*v=l+r;break;case A_SUB:*v=l-r;break;case A_MUL:*v=l*r;break;case A_DIV:if(!r)return 0;*v=l/r;break;case A_AND:*v=l&r;break;case A_OR:*v=l|r;break;case A_XOR:*v=l^r;break;case A_LSH:*v=l<<(r&31);break;case A_RSH:*v=l>>(r&31);break;default:return 0;}return 1;}
static void guard_load(gen_t*g,load_base_t b,int T,int F,int opt){node_t q;memset(&q,0,sizeof(q));q.kind=N_PRIM;q.prim=PK_IPPROTO;if(b==BASE_IP){emit_ipv4_guard(g,T,F);return;}if(b==BASE_IP6){emit_ipv6_guard(g,T,F);return;}q.value=b==BASE_TCP?6:b==BASE_UDP?17:b==BASE_ICMP?1:58;q.proto=b==BASE_ICMP6?6:4;if((b==BASE_TCP||b==BASE_UDP)&&!opt)q.proto=46;emit_ipproto(g,&q,T,F);}
static void emit_wifi_transport_guard(gen_t*g,uint32_t proto,int T,int F){int v6=newlabel(g),ext=newlabel(g),common=newlabel(g);emit_80211_prefix(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,2048,(int)g->p->len+1,F);emit_wifi_v4gate(g,v6);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,2048,(int)g->p->len+1,v6);ins(g,97,g->wifi_slot);ins(g,80,17);jump(g,21,proto,common,v6);bindlabel(g,v6);emit_wifi_v4gate(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,34525,(int)g->p->len+1,F);ins(g,97,g->wifi_slot);ins(g,80,14);jump(g,21,proto,common,(int)g->p->len+1);ins(g,97,g->wifi_slot);ins(g,80,14);jump(g,21,44,(int)g->p->len+1,F);bindlabel(g,ext);ins(g,97,g->wifi_slot);ins(g,80,48);jump(g,21,proto,common,F);bindlabel(g,common);ins(g,97,g->wifi_slot);ins(g,72,14);jump(g,69,8191,F,T);}
static void emit_aval_opt(gen_t*g,const arith_t*a,int F){uint32_t k;layout(g);if(a->kind==A_CONST){ins(g,0,a->value);return;}if(a->kind==A_LEN){ins(g,128,0);return;}if(a->kind==A_LOAD){unsigned base=0;if(a->base!=BASE_LINK&&g->raw_guarded!=(int)a->base){int lab=newlabel(g);guard_load(g,a->base,lab,F,1);bindlabel(g,lab);}if(a->base==BASE_LINK)base=0;else if(a->base==BASE_IP||a->base==BASE_IP6)base=g->net;else{ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,g->net);base=g->link;}ins(g,ldop(a->width,a->base>=BASE_TCP),base+a->value);return;}if(g->c->dlt!=105&&cval(a->r,&k)){emit_aval_opt(g,a->l,F);ins(g,(uint16_t)(a->kind==A_ADD?4:a->kind==A_SUB?20:a->kind==A_MUL?36:a->kind==A_DIV?52:a->kind==A_OR?68:a->kind==A_AND?84:a->kind==A_LSH?100:a->kind==A_RSH?116:164),k);return;}emit_aval_opt(g,a->l,F);ins(g,2,14);emit_aval_opt(g,a->r,F);ins(g,7,(a->kind==A_SUB&&a->r&&a->r->kind==A_LSH)?10:0);ins(g,96,14);ins(g,(uint16_t)(a->kind==A_ADD?12:a->kind==A_SUB?28:a->kind==A_MUL?44:a->kind==A_DIV?60:a->kind==A_OR?76:a->kind==A_AND?92:a->kind==A_LSH?108:a->kind==A_RSH?124:172),0);}
static int emit_aval_raw(gen_t*g,const arith_t*a,int slot,int F){layout(g);if(slot<0)return-1;if(a->kind==A_CONST){ins(g,0,a->value);ins(g,2,slot);return slot;}if(a->kind==A_LEN){ins(g,128,0);ins(g,2,slot);return slot;}if(a->kind==A_LOAD){unsigned base=0;int transport=a->base>=BASE_TCP;if(transport&&g->c->dlt==105){int body=newlabel(g);uint32_t proto=a->base==BASE_TCP?6:a->base==BASE_UDP?17:a->base==BASE_ICMP?1:58;emit_wifi_transport_guard(g,proto,body,F);bindlabel(g,body);ins(g,0,a->value);ins(g,2,slot);ins(g,97,g->wifi_slot);ins(g,80,8);ins(g,84,15);ins(g,100,2);ins(g,12,0);ins(g,7,0);ins(g,96,slot);ins(g,12,0);ins(g,7,0);ins(g,ldop(a->width,1),8);ins(g,2,slot-1);return slot-1;}if(transport&&g->c->dlt!=105){int outer=newlabel(g);emit_ipv4_guard(g,outer,F);bindlabel(g,outer);}if(a->base!=BASE_LINK&&g->raw_guarded!=(int)a->base){int lab=newlabel(g);guard_load(g,a->base,lab,F,0);bindlabel(g,lab);}if(transport){ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,0,a->value);ins(g,2,slot);ins(g,177,g->net);ins(g,96,slot);ins(g,12,0);ins(g,7,0);base=g->link;ins(g,ldop(a->width,1),base);ins(g,2,slot-1);return slot-1;}ins(g,0,a->value);ins(g,2,slot);if(g->dynamic&&a->base!=BASE_LINK){ins(g,97,g->wifi_slot);ins(g,96,slot);ins(g,12,0);ins(g,7,0);base=g->net+8;}else{ins(g,97,slot);base=a->base==BASE_LINK?0:g->net;}ins(g,ldop(a->width,1),base);ins(g,2,slot-1);return slot-1;}{int ls=emit_aval_raw(g,a->l,slot,F),next=ls-1;if(g->dynamic&&next==g->wifi_slot)next--;int rs=emit_aval_raw(g,a->r,next,F);uint16_t op=(uint16_t)(a->kind==A_ADD?12:a->kind==A_SUB?28:a->kind==A_MUL?44:a->kind==A_DIV?60:a->kind==A_OR?76:a->kind==A_AND?92:a->kind==A_LSH?108:a->kind==A_RSH?124:172);if(ls<0||rs<0)return-1;ins(g,97,rs);ins(g,96,ls);ins(g,op,0);ins(g,2,rs);return rs;}}
static int aequal(const arith_t*a,const arith_t*b);
static int abase_only(const arith_t*a,load_base_t b){if(!a)return 1;if(a->kind==A_LOAD)return a->base==b;if(a->kind==A_CONST||a->kind==A_LEN)return 1;return abase_only(a->l,b)&&abase_only(a->r,b);}static int abase_has(const arith_t*a,load_base_t b){return a&&(a->kind==A_LOAD?a->base==b:abase_has(a->l,b)||abase_has(a->r,b));}
static int nequal(const node_t*a,const node_t*b);
static void emit_relation(gen_t*g,const node_t*n,int T,int F){uint32_t k;if(g->c->optimize&&g->c->dlt!=105&&aequal(n->a,n->b)){emit_aval_opt(g,n->a,F);ins(g,7,12);jump(g,29,0,n->rel==R_NE?F:T,n->rel==R_NE?T:F);return;}if(n->a->kind==A_LEN&&(g->c->optimize||n->a->width)&&cval(n->b,&k)){ins(g,128,0);if(n->rel==R_EQ)jump(g,21,k,T,F);else if(n->rel==R_NE)jump(g,21,k,F,T);else if(n->rel==R_GT)jump(g,37,k,T,F);else if(n->rel==R_GE)jump(g,53,k,T,F);else if(n->rel==R_LT)jump(g,53,k,F,T);else jump(g,37,k,F,T);return;}if(g->c->optimize&&g->c->dlt!=105&&cval(n->b,&k)){if(g->c->dlt!=105&&g->raw_guarded!=BASE_IP&&abase_has(n->a,BASE_IP)&&abase_only(n->a,BASE_IP)){int lab=newlabel(g);emit_ipv4_guard(g,lab,F);bindlabel(g,lab);g->raw_guarded=BASE_IP;}if((n->rel==R_EQ||n->rel==R_NE)&&n->a->kind==A_AND&&cval(n->a->r,&k)&&n->b->value==0){emit_aval_opt(g,n->a->l,F);jump(g,69,k,n->rel==R_EQ?F:T,n->rel==R_EQ?T:F);return;}emit_aval_opt(g,n->a,F);k=n->b->value;if(n->rel==R_EQ)jump(g,21,k,T,F);else if(n->rel==R_NE)jump(g,21,k,F,T);else if(n->rel==R_GT)jump(g,37,k,T,F);else if(n->rel==R_GE)jump(g,53,k,T,F);else if(n->rel==R_LT)jump(g,53,k,F,T);else jump(g,37,k,F,T);return;}{if(!aequal(n->a,n->b)&&(abase_has(n->a,BASE_IP)||abase_has(n->b,BASE_IP))&&abase_only(n->a,BASE_IP)&&abase_only(n->b,BASE_IP)){int lab=newlabel(g);emit_ipv4_guard(g,lab,F);bindlabel(g,lab);g->raw_guarded=BASE_IP;}if(aequal(n->a,n->b)&&abase_has(n->a,BASE_IP)){int g1=newlabel(g),g2=newlabel(g);emit_ipv4_guard(g,g1,F);bindlabel(g,g1);emit_ipv4_guard(g,g2,F);bindlabel(g,g2);g->raw_guarded=BASE_IP;}int ls=emit_aval_raw(g,n->a,g->raw_slot,F),next=ls-1;if(g->dynamic&&next==g->wifi_slot)next--;int rs=emit_aval_raw(g,n->b,next,F);if(ls<0||rs<0){g->p->overflow=1;return;}g->raw_slot=rs;ins(g,97,rs);ins(g,96,ls);if(n->rel==R_EQ||n->rel==R_NE){ins(g,28,0);jump(g,21,0,n->rel==R_EQ?T:F,n->rel==R_EQ?F:T);}else if(n->rel==R_GT)jump(g,45,0,T,F);else if(n->rel==R_GE)jump(g,61,0,T,F);else if(n->rel==R_LT)jump(g,61,0,F,T);else jump(g,45,0,F,T);}}

static int emit_iso_proto(gen_t*g,const node_t*n,int T,int F){if(n->proto!=2)return 0;if(g->c->dlt==105){emit_80211_prefix(g,F);ins(g,97,g->wifi_slot);ins(g,72,0);jump(g,21,65278,(int)g->p->len+1,F);ins(g,97,g->wifi_slot);ins(g,80,3);jump(g,21,n->value,T,F);}else{ins(g,40,g->c->dlt==1?12:g->c->dlt==113?14:2);jump(g,37,1500,F,(int)g->p->len+1);ins(g,40,g->c->dlt==1?14:g->c->dlt==113?16:4);jump(g,21,65278,(int)g->p->len+1,F);ins(g,48,g->c->dlt==1?17:g->c->dlt==113?19:7);jump(g,21,n->value,T,F);}return 1;}
static int emit_legacy_proto(gen_t*g,const node_t*n,int T,int F){uint32_t v=n->value;unsigned eo=g->c->dlt==1?12:g->c->dlt==113?14:2;if(g->c->dlt==9&&v==0xf0f0){ins(g,40,2);jump(g,21,240,T,F);return 1;}if(g->c->dlt==9&&v==0x26){ins(g,40,2);jump(g,21,49,T,F);return 1;}if(v==0x26){if(g->c->dlt==105){emit_80211_prefix(g,F);ins(g,97,g->wifi_slot);ins(g,80,0);jump(g,21,66,T,F);}else{ins(g,40,eo);jump(g,37,1500,F,(int)g->p->len+1);ins(g,48,eo+2);jump(g,21,66,T,F);}return 1;}if(g->c->dlt==105&&v==0x809b){emit_80211_prefix(g,F);ins(g,97,g->wifi_slot);ins(g,64,0);jump(g,21,0xaaaa0308,(int)g->p->len+1,F);ins(g,97,g->wifi_slot);ins(g,64,4);jump(g,21,0x0007809b,T,F);return 1;}if(g->c->dlt==105&&(v==0xf0f0||v==0x8137)){emit_80211_prefix(g,F);ins(g,97,g->wifi_slot);if(v==0xf0f0){ins(g,72,0);jump(g,21,v,T,F);}else{ins(g,80,0);jump(g,21,224,T,F);}return 1;}if(g->c->dlt!=1&&g->c->dlt!=113)return 0;if(v==0xf0f0){ins(g,40,eo);if(g->c->dlt==1){jump(g,37,1500,F,(int)g->p->len+1);ins(g,40,14);}else{jump(g,21,4,(int)g->p->len+1,F);ins(g,40,16);}jump(g,21,v,T,F);return 1;}if(v!=0x80f3&&v!=0x809b&&v!=0x8137)return 0;if(g->c->dlt==113){ins(g,40,14);jump(g,21,v,T,(int)g->p->len+1);if(!g->c->optimize&&v==0x8137)ins(g,40,14);if(v==0x8137){jump(g,21,1,T,(int)g->p->len+1);ins(g,40,14);jump(g,21,4,(int)g->p->len+1,F);ins(g,48,16);jump(g,21,224,T,(int)g->p->len+1);}else{ins(g,40,14);jump(g,21,4,(int)g->p->len+1,F);}ins(g,32,16);jump(g,21,0xaaaa0300,(int)g->p->len+1,F);ins(g,32,20);jump(g,21,v,T,F);return 1;}ins(g,40,12);jump(g,21,v,T,(int)g->p->len+1);if(!g->c->optimize)ins(g,40,12);jump(g,37,1500,F,(int)g->p->len+1);if(v==0x8137){ins(g,32,14);jump(g,21,0xaaaa0300,(int)g->p->len+1,(int)g->p->len+3);ins(g,32,18);jump(g,21,v,T,(int)g->p->len+1);ins(g,48,14);jump(g,21,224,T,(int)g->p->len+1);ins(g,40,14);jump(g,21,65535,T,F);}else{ins(g,32,14);jump(g,21,v==0x809b?0xaaaa0308:0xaaaa0300,(int)g->p->len+1,F);ins(g,32,18);jump(g,21,v==0x809b?0x0007809b:v,T,F);}return 1;}
static const bpf_insn_t geneve_eth[]={{40,0,0,12u},{21,0,14,2048u},{48,0,0,23u},{21,0,12,17u},{40,0,0,20u},{69,10,0,8191u},{177,0,0,14u},{72,0,0,16u},{21,0,7,6081u},{177,0,0,14u},{80,0,0,22u},{84,0,0,192u},{21,0,3,0u},{177,0,0,14u},{135,0,0,0u},{29,12,0,0u},{40,0,0,12u},{21,0,31,34525u},{48,0,0,20u},{21,0,29,17u},{40,0,0,56u},{21,0,27,6081u},{48,0,0,62u},{84,0,0,192u},{21,0,24,0u},{0,0,0,40u},{7,0,0,0u},{29,0,21,0u},{4,0,0,22u},{7,0,0,0u},{4,0,0,2u},{2,0,0,15u},{80,0,0,0u},{84,0,0,63u},{36,0,0,4u},{4,0,0,8u},{12,0,0,0u},{2,0,0,14u},{72,0,0,2u},{97,0,0,14u},{21,0,5,25944u},{135,0,0,0u},{4,0,0,12u},{2,0,0,15u},{4,0,0,2u},{7,0,0,0u},{3,0,0,13u},{0,0,0,0u},{21,1,0,0u}};
static const bpf_insn_t geneve_wifi[]={{1,0,0,0u},{135,0,0,0u},{4,0,0,24u},{2,0,0,12u},{80,0,0,0u},{69,0,5,8u},{69,4,0,4u},{69,0,3,128u},{96,0,0,12u},{4,0,0,2u},{2,0,0,12u},{48,0,0,0u},{69,36,0,4u},{48,0,0,0u},{69,0,34,8u},{97,0,0,15u},{72,0,0,6u},{21,0,31,2048u},{97,0,0,15u},{80,0,0,17u},{21,0,28,17u},{97,0,0,15u},{72,0,0,14u},{69,25,0,8191u},{97,0,0,15u},{80,0,0,8u},{84,0,0,15u},{100,0,0,2u},{12,0,0,0u},{7,0,0,0u},{72,0,0,10u},{21,0,17,6081u},{97,0,0,15u},{80,0,0,8u},{84,0,0,15u},{100,0,0,2u},{12,0,0,0u},{7,0,0,0u},{80,0,0,16u},{84,0,0,192u},{21,0,8,0u},{97,0,0,15u},{80,0,0,8u},{84,0,0,15u},{100,0,0,2u},{12,0,0,0u},{7,0,0,0u},{135,0,0,0u},{29,22,0,0u},{48,0,0,0u},{69,42,0,4u},{48,0,0,0u},{69,0,40,8u},{97,0,0,15u},{72,0,0,6u},{21,0,37,34525u},{97,0,0,15u},{80,0,0,14u},{21,0,34,17u},{97,0,0,15u},{72,0,0,50u},{21,0,31,6081u},{97,0,0,15u},{80,0,0,56u},{84,0,0,192u},{21,0,27,0u},{97,0,0,15u},{0,0,0,40u},{12,0,0,0u},{7,0,0,0u},{29,0,22,0u},{4,0,0,16u},{7,0,0,0u},{4,0,0,2u},{2,0,0,14u},{80,0,0,0u},{84,0,0,63u},{36,0,0,4u},{4,0,0,8u},{12,0,0,0u},{2,0,0,13u},{72,0,0,2u},{97,0,0,13u},{21,0,5,25944u},{135,0,0,0u},{4,0,0,12u},{2,0,0,14u},{4,0,0,2u},{7,0,0,0u},{3,0,0,12u},{0,0,0,0u},{21,0,1,0u}};
static void emit_geneve(gen_t*g){const bpf_insn_t*v=g->c->dlt==105?geneve_wifi:geneve_eth;size_t n=g->c->dlt==105?sizeof(geneve_wifi)/sizeof(geneve_wifi[0]):sizeof(geneve_eth)/sizeof(geneve_eth[0]);for(size_t i=0;i<n;i++)bpf_emit(g->p,v[i].code,v[i].jt,v[i].jf,v[i].k);}
static void emit_multicast_wifi(gen_t*g,int T,int F){if(g->c->optimize){int addr4=newlabel(g);ins(g,48,0);jump(g,69,4,F,(int)g->p->len+1);jump(g,69,8,(int)g->p->len+1,addr4);ins(g,48,1);jump(g,69,1,(int)g->p->len+1,addr4);ins(g,48,16);jump(g,69,1,T,F);bindlabel(g,addr4);ins(g,48,4);jump(g,69,1,T,F);}else{int second=newlabel(g),third=newlabel(g);ins(g,48,0);jump(g,69,4,F,(int)g->p->len+1);ins(g,48,0);jump(g,69,8,second,(int)g->p->len+1);ins(g,48,4);jump(g,69,1,T,second);bindlabel(g,second);ins(g,48,0);jump(g,69,8,(int)g->p->len+1,F);ins(g,48,1);jump(g,69,1,third,(int)g->p->len+1);ins(g,48,4);jump(g,69,1,T,third);bindlabel(g,third);ins(g,48,1);jump(g,69,1,(int)g->p->len+1,F);ins(g,48,16);jump(g,69,1,T,F);}}
static void emit_multicast(gen_t*g,const node_t*n,int T,int F){int body;layout(g);if(g->c->dlt==105&&(n->proto==0||n->proto==1)){emit_multicast_wifi(g,T,F);return;}if(n->proto==0||n->proto==1){ins(g,48,0);jump(g,69,1,T,F);return;}body=newlabel(g);if(n->proto==6)emit_ipv6_guard(g,body,F);else emit_ipv4_guard(g,body,F);bindlabel(g,body);if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,80,n->proto==6?24:24);}else ins(g,48,g->net+(n->proto==6?24:16));if(n->proto==4){ins(g,84,240);jump(g,21,224,T,F);}else jump(g,21,255,T,F);}
static void emit_broadcast(gen_t*g,const node_t*n,int T,int F){uint32_t hm=~g->c->netmask;int body=newlabel(g);layout(g);if(n->proto!=4){if(g->c->dlt==105){node_t q=*n;memset(q.addr,255,6);q.dir=DIR_DST;emit_mac(g,&q,T,F);}else{ins(g,32,0);jump(g,21,0xffffffffU,T,F);}return;}emit_ipv4_guard(g,body,F);bindlabel(g,body);if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,64,16);}else ins(g,32,g->net+16);if(g->c->optimize){jump(g,69,hm,(int)g->p->len+1,T);ins(g,84,hm);jump(g,21,hm,T,F);}else{ins(g,84,hm);jump(g,21,0,T,(int)g->p->len+1);if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,64,16);}else ins(g,32,g->net+16);ins(g,84,hm);jump(g,21,hm,T,F);}}
static void emit_wlan_addr(gen_t*g,const node_t*n,int T,int F){uint32_t w=be32(n->addr),h=be16(n->addr+4);if(n->value==1){if(!g->c->optimize){ins(g,48,0);jump(g,69,8,(int)g->p->len+1,F);}emit_mac_pair(g,4,w,h,T,F);}else if(n->value==3){ins(g,48,0);ins(g,84,12);jump(g,21,4,F,(int)g->p->len+1);emit_mac_pair(g,16,w,h,T,F);}else if(n->value==4){ins(g,48,1);ins(g,84,3);jump(g,21,3,(int)g->p->len+1,F);emit_mac_pair(g,24,w,h,T,F);}else{emit_mac_pair(g,n->value==2?10:4,w,h,T,F);}}
static void emit_prim(gen_t*g,const node_t*n,int T,int F){switch(n->prim){case PK_ETHERTYPE:if(n->proto==-99)jump(g,21,0,T,F);else if(!emit_iso_proto(g,n,T,F)&&!emit_legacy_proto(g,n,T,F))emit_ethertype(g,n->value,T,F);break;case PK_IPPROTO:emit_ipproto(g,n,T,F);break;case PK_HOST4:case PK_NET4:emit_host4(g,n,T,F);break;case PK_HOST6:case PK_NET6:emit_host6(g,n,T,F);break;case PK_ETHER_ADDR:emit_mac(g,n,T,F);break;case PK_PORT:case PK_PORTRANGE:emit_port(g,n,T,F);break;case PK_MULTICAST:emit_multicast(g,n,T,F);break;case PK_BROADCAST:emit_broadcast(g,n,T,F);break;case PK_VLAN:emit_vlan(g,n,T,F);break;case PK_MPLS:emit_mpls(g,n,T,F);break;case PK_PPPOES:emit_ethertype(g,0x8864,T,F);break;case PK_PPPOED:emit_ethertype(g,0x8863,T,F);break;case PK_INBOUND:case PK_OUTBOUND:ins(g,40,g->c->dlt==113?0:0xfffff004U);jump(g,21,4,n->prim==PK_OUTBOUND?T:F,n->prim==PK_OUTBOUND?F:T);break;case PK_IFINDEX:ins(g,32,0xfffff008U);jump(g,21,n->value,T,F);break;case PK_WLAN_TYPE:if(n->value==0x100||n->value==0x200){ins(g,48,1);ins(g,84,3);jump(g,21,n->value>>8,T,F);}else{ins(g,48,0);if(n->value<16){ins(g,84,12);jump(g,21,n->value,T,F);}else{ins(g,84,252);jump(g,21,n->value,T,F);}}break;case PK_GENEVE:emit_geneve(g);break;case PK_WLAN_ADDR:emit_wlan_addr(g,n,T,F);break;default:jump(g,21,0,F,T);}}
static void emit_two_port_checks(gen_t*g,const node_t*a,const node_t*b,unsigned base,int ind,int T,int F,int last,int final){uint16_t op=(uint16_t)(40+(ind?32:0));int dst=newlabel(g);unsigned off=a->dir==DIR_DST?base+2:base;ins(g,op,off);jump(g,21,a->value,a->dir==DIR_BOTH_AND?dst:T,(int)g->p->len+1);jump(g,21,b->value,a->dir==DIR_BOTH_AND?dst:T,(a->dir==DIR_SRC||a->dir==DIR_DST)?F:dst);if(a->dir==DIR_SRC||a->dir==DIR_DST)return;bindlabel(g,dst);ins(g,op,base+2);jump(g,21,a->value,T,a->dir==DIR_ANY?last:(int)g->p->len+1);if(final)bindlabel(g,last);if(a->dir!=DIR_ANY||final)jump(g,21,b->value,T,F);}
static int emit_port_union(gen_t*g,const node_t*n,int T,int F){const node_t*a,*b;int lv4=newlabel(g),lv6=newlabel(g),pv4=newlabel(g),pv6=newlabel(g),last=newlabel(g);unsigned eo,no;uint32_t e4,e6;if(!g->c->optimize||!n||n->kind!=N_OR||g->c->dlt==105)return 0;a=n->l;b=n->r;if(a->kind!=N_PRIM||b->kind!=N_PRIM||a->prim!=PK_PORT||b->prim!=PK_PORT||a->proto!=b->proto||a->dir!=b->dir)return 0;layout(g);no=g->net;if(g->c->dlt==12){ins(g,48,0);ins(g,84,240);jump(g,21,96,lv6,(int)g->p->len+1);ins(g,48,0);ins(g,84,240);jump(g,21,64,lv4,F);}else if(g->c->dlt==0){ins(g,32,0);jump(g,21,167772160U,lv6,(int)g->p->len+1);jump(g,21,33554432U,lv4,F);}else{eo=g->c->dlt==1?12:g->c->dlt==113?14:2;e4=g->c->dlt==9?33:2048;e6=g->c->dlt==9?87:34525;ins(g,40,eo);jump(g,21,e6,lv6,(int)g->p->len+1);jump(g,21,e4,lv4,F);}bindlabel(g,lv4);ins(g,48,no+9);if(a->proto>=0)jump(g,21,(uint32_t)a->proto,pv4,F);else{jump(g,21,132,pv4,(int)g->p->len+1);jump(g,21,6,pv4,(int)g->p->len+1);jump(g,21,17,pv4,F);}bindlabel(g,pv4);ins(g,40,no+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,no);emit_two_port_checks(g,a,b,g->link,1,T,F,last,0);bindlabel(g,lv6);ins(g,48,no+6);if(a->proto>=0)jump(g,21,(uint32_t)a->proto,pv6,F);else{jump(g,21,132,pv6,(int)g->p->len+1);jump(g,21,6,pv6,(int)g->p->len+1);jump(g,21,17,pv6,F);}bindlabel(g,pv6);emit_two_port_checks(g,a,b,no+40,0,T,F,last,1);return 1;}
static int emit_proto_union(gen_t*g,const node_t*n,int T,int F){const node_t*x[2],*v4[2],*v6[2];int n4=0,n6=0,lv4=newlabel(g),lv6=newlabel(g),last=newlabel(g),frag;unsigned no,eo;if(!g->c->optimize||!n||n->kind!=N_OR||g->c->dlt==105||g->c->dlt==0)return 0;x[0]=n->l;x[1]=n->r;if(x[0]->kind!=N_PRIM||x[1]->kind!=N_PRIM||x[0]->prim!=PK_IPPROTO||x[1]->prim!=PK_IPPROTO)return 0;for(int i=0;i<2;i++){if(x[i]->proto!=6)v4[n4++]=x[i];if(x[i]->proto!=4)v6[n6++]=x[i];}if(n4==2&&n6==0&&g->raw_guarded==BASE_IP){ins(g,48,g->net+9);jump(g,21,v4[0]->value,T,(int)g->p->len+1);jump(g,21,v4[1]->value,T,F);return 1;}if(n4!=2||n6<1||(n6==2&&v6[1]!=v4[1]))return 0;layout(g);no=g->net;eo=(g->c->dlt==1?12U:g->c->dlt==113?14U:2U)+4U*g->vlan_depth;if(g->c->dlt==12){ins(g,48,0);ins(g,84,240);jump(g,21,64,lv4,(int)g->p->len+1);ins(g,48,0);ins(g,84,240);jump(g,21,96,lv6,F);}else{ins(g,40,eo);jump(g,21,g->c->dlt==9?33:2048,lv4,(int)g->p->len+1);jump(g,21,g->c->dlt==9?87:34525,lv6,F);}bindlabel(g,lv6);ins(g,48,no+6);jump(g,21,v6[0]->value,T,(int)g->p->len+1);frag=newlabel(g);jump(g,21,44,frag,n6==2?last:F);bindlabel(g,frag);ins(g,48,no+40);jump(g,21,v6[0]->value,T,n6==2?last:F);bindlabel(g,lv4);ins(g,48,no+9);jump(g,21,v4[0]->value,T,n4==2?last:F);if(n4==2){bindlabel(g,last);jump(g,21,v4[1]->value,T,F);}return 1;}
static int emit_proto_link_union(gen_t*g,const node_t*n,int T,int F){const node_t*a,*b,*ip,*link;int v4=newlabel(g),v6=newlabel(g),eo;if(!g->c->optimize||g->c->dlt==0||g->c->dlt==12||g->c->dlt==105||!n)return 0;if(n->kind==N_OR){a=n->l;b=n->r;}else if(n->kind==N_NOT&&n->l&&n->l->kind==N_AND&&n->l->l&&n->l->r&&n->l->l->kind==N_NOT&&n->l->r->kind==N_NOT){a=n->l->l->l;b=n->l->r->l;}else return 0;if(a&&a->kind==N_PRIM&&a->prim==PK_IPPROTO&&b&&b->kind==N_PRIM&&b->prim==PK_ETHERTYPE){ip=a;link=b;}else if(b&&b->kind==N_PRIM&&b->prim==PK_IPPROTO&&a&&a->kind==N_PRIM&&a->prim==PK_ETHERTYPE){ip=b;link=a;}else return 0;layout(g);eo=g->c->dlt==1?12:g->c->dlt==113?14:2;ins(g,40,eo);if(ip->proto!=6)jump(g,21,g->c->dlt==9?33:2048,v4,(int)g->p->len+1);if(ip->proto!=4)jump(g,21,g->c->dlt==9?87:34525,v6,(int)g->p->len+1);{uint32_t k=link->value;if(g->c->dlt==9){if(k==0x8137)k=43;else if(k==0xf0f0)k=240;else if(k==0x26)k=49;}jump(g,21,k,T,F);}if(ip->proto!=4){bindlabel(g,v6);ins(g,48,g->net+6);jump(g,21,ip->value,T,(int)g->p->len+1);jump(g,21,44,(int)g->p->len+1,F);ins(g,48,g->net+40);jump(g,21,ip->value,T,F);}if(ip->proto!=6){bindlabel(g,v4);ins(g,48,g->net+9);jump(g,21,ip->value,T,F);}return 1;}

static int is_ipfrag_zero(const node_t*n){const arith_t*a,*l,*r;if(!n||n->kind!=N_REL||n->rel!=R_EQ||!n->b||n->b->kind!=A_CONST||n->b->value)return 0;a=n->a;if(!a||a->kind!=A_AND)return 0;l=a->l;r=a->r;if(l&&l->kind==A_CONST){const arith_t*t=l;l=r;r=t;}return l&&l->kind==A_LOAD&&l->base==BASE_IP&&l->value==6&&l->width==2&&r&&r->kind==A_CONST&&r->value==8191;}
static int emit_shared_ipfrag_proto(gen_t*g,const node_t*n,int T,int F){const node_t*a,*b;int body;if(!g->c->optimize||!n||n->kind!=N_AND)return 0;if(is_ipfrag_zero(n->r)&&n->l->kind==N_OR){a=n->l->l;b=n->l->r;}else if(is_ipfrag_zero(n->l)&&n->r->kind==N_OR){a=n->r->l;b=n->r->r;}else return 0;if(a->kind!=N_PRIM||b->kind!=N_PRIM||a->prim!=PK_IPPROTO||b->prim!=PK_IPPROTO)return 0;body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,48,g->net+9);jump(g,21,a->value,T,(int)g->p->len+1);jump(g,21,b->value,T,F);return 1;}
static void emit_wifi_proto4_test(gen_t*g,uint32_t proto,int T,int F){ins(g,97,g->wifi_slot);ins(g,80,17);jump(g,21,proto,T,F);}
static void emit_wifi_proto6_test(gen_t*g,uint32_t proto,int T,int F){ins(g,97,g->wifi_slot);ins(g,80,14);jump(g,21,proto,T,(int)g->p->len+1);ins(g,97,g->wifi_slot);ins(g,80,14);jump(g,21,44,(int)g->p->len+1,F);ins(g,97,g->wifi_slot);ins(g,80,48);jump(g,21,proto,T,F);}
static int emit_wifi_proto_union(gen_t*g,const node_t*n,int T,int F){const node_t*a,*b;int next,v4;if(!g->c->optimize||g->c->dlt!=105||!n||n->kind!=N_OR)return 0;a=n->l;b=n->r;if(a->kind==N_PRIM&&a->prim==PK_IPPROTO&&a->proto==4&&b->kind==N_PRIM&&b->prim==PK_ETHERTYPE&&b->value==0x86dd){next=newlabel(g);v4=newlabel(g);emit_80211_prefix(g,next);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,2048,v4,next);bindlabel(g,v4);emit_wifi_proto4_test(g,a->value,T,next);bindlabel(g,next);emit_wifi_v4gate(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,34525,T,F);return 1;}if(a->kind==N_PRIM&&b->kind==N_PRIM&&a->prim==PK_IPPROTO&&b->prim==PK_IPPROTO&&a->proto==4&&b->proto!=4){int n2=newlabel(g),n3=newlabel(g),p1=newlabel(g),p2=newlabel(g),p6=newlabel(g);emit_80211_prefix(g,n2);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,2048,p1,n2);bindlabel(g,p1);emit_wifi_proto4_test(g,a->value,T,n2);bindlabel(g,n2);emit_wifi_v4gate(g,n3);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,2048,p2,n3);bindlabel(g,p2);emit_wifi_proto4_test(g,b->value,T,n3);bindlabel(g,n3);emit_wifi_v4gate(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,34525,p6,F);bindlabel(g,p6);emit_wifi_proto6_test(g,b->value,T,F);return 1;}if(a->kind==N_PRIM&&a->prim==PK_ETHERTYPE&&a->value==0x809b&&b->kind==N_PRIM&&b->prim==PK_IPPROTO&&b->proto!=4&&b->proto!=6){next=newlabel(g);emit_legacy_proto(g,a,T,next);bindlabel(g,next);emit_proto_both_raw(g,b->value,T,F);return 1;}return 0;}
static int emit_ip6_proto_union(gen_t*g,const node_t*n,int T,int F){const node_t*a,*b;uint32_t e4,e6;unsigned eo,no;if(!g->c->optimize||!n||n->kind!=N_OR||g->c->dlt==105)return 0;a=n->l;b=n->r;if(!(a->kind==N_PRIM&&a->prim==PK_ETHERTYPE&&a->value==0x86dd&&b->kind==N_PRIM&&b->prim==PK_IPPROTO&&b->proto!=6))return 0;layout(g);no=g->net;if(g->c->dlt==0){ins(g,32,0);e4=33554432U;e6=167772160U;}else{eo=g->c->dlt==1?12:g->c->dlt==113?14:2;ins(g,40,eo);e4=g->c->dlt==9?33:2048;e6=g->c->dlt==9?87:34525;}jump(g,21,e6,T,(int)g->p->len+1);jump(g,21,e4,(int)g->p->len+1,F);ins(g,48,no+9);jump(g,21,b->value,T,F);return 1;}
static int collect_host_union(const node_t*n,const node_t**v,int*count){if(n->kind==N_OR)return collect_host_union(n->l,v,count)&&collect_host_union(n->r,v,count);if(n->kind!=N_PRIM||(n->prim!=PK_HOST4&&n->prim!=PK_NET4)||*count>=16)return 0;for(int i=0;i<*count;i++)if(v[i]->prim==n->prim&&v[i]->dir==n->dir&&v[i]->value==n->value&&v[i]->mask==n->mask)return 1;v[(*count)++]=n;return 1;}
static void emit_addr4_union(gen_t*g,const node_t**v,int count,unsigned off,int T,int F){if(g->dynamic){ins(g,97,g->wifi_slot);ins(g,64,off);}else ins(g,32,off);if(v[0]->mask!=0xffffffffU)ins(g,84,v[0]->mask);for(int i=0;i<count;i++)jump(g,21,v[i]->value&v[i]->mask,T,i==count-1?F:(int)g->p->len+1);}
static int emit_protocol_host_union(gen_t*g,const node_t*n,int T,int F){const node_t*p,*h;int lip=newlabel(g),lv6=newlabel(g),larp=newlabel(g),frag,next;if(!g->c->optimize||g->c->dlt!=1||!n||n->kind!=N_OR)return 0;if(n->l->kind==N_PRIM&&n->l->prim==PK_IPPROTO&&n->r->kind==N_PRIM&&(n->r->prim==PK_HOST4||n->r->prim==PK_NET4)){p=n->l;h=n->r;}else if(n->r->kind==N_PRIM&&n->r->prim==PK_IPPROTO&&n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)){p=n->r;h=n->l;}else return 0;if(p->proto==4||p->proto==6||h->proto!=0)return 0;layout(g);ins(g,40,12);jump(g,21,2048,lip,(int)g->p->len+1);jump(g,21,34525,lv6,(int)g->p->len+1);jump(g,21,2054,larp,(int)g->p->len+1);jump(g,21,32821,larp,F);bindlabel(g,larp);if(h->dir!=DIR_DST){next=h->dir==DIR_SRC?F:newlabel(g);emit_addr4(g,g->net+14,h->value,h->mask,T,next);if(h->dir!=DIR_SRC)bindlabel(g,next);}if(h->dir!=DIR_SRC)emit_addr4(g,g->net+24,h->value,h->mask,T,F);bindlabel(g,lv6);ins(g,48,g->net+6);jump(g,21,p->value,T,(int)g->p->len+1);frag=newlabel(g);jump(g,21,44,frag,F);bindlabel(g,frag);ins(g,48,g->net+40);jump(g,21,p->value,T,F);bindlabel(g,lip);ins(g,48,g->net+9);jump(g,21,p->value,T,(int)g->p->len+1);if(h->dir!=DIR_DST){next=h->dir==DIR_SRC?F:newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,T,next);if(h->dir!=DIR_SRC)bindlabel(g,next);}if(h->dir!=DIR_SRC)emit_addr4(g,g->net+16,h->value,h->mask,T,F);return 1;}
static int emit_mixed_host_union(gen_t*g,const node_t*n,int T,int F){const node_t*h4,*h6;int l6,next;if(!g->c->optimize||g->c->dlt!=0||!n||n->kind!=N_OR)return 0;if(n->l->kind==N_PRIM&&(n->l->prim==PK_HOST6||n->l->prim==PK_NET6)&&n->r->kind==N_PRIM&&(n->r->prim==PK_HOST4||n->r->prim==PK_NET4)){h6=n->l;h4=n->r;}else if(n->r->kind==N_PRIM&&(n->r->prim==PK_HOST6||n->r->prim==PK_NET6)&&n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)){h6=n->r;h4=n->l;}else return 0;layout(g);l6=newlabel(g);ins(g,32,0);jump(g,21,167772160U,l6,(int)g->p->len+1);jump(g,21,33554432U,(int)g->p->len+1,F);if(h4->dir==DIR_SRC)emit_addr4(g,g->net+12,h4->value,h4->mask,T,F);else if(h4->dir==DIR_DST)emit_addr4(g,g->net+16,h4->value,h4->mask,T,F);else{next=newlabel(g);emit_addr4(g,g->net+12,h4->value,h4->mask,T,next);bindlabel(g,next);emit_addr4(g,g->net+16,h4->value,h4->mask,T,F);}bindlabel(g,l6);if(h6->dir==DIR_SRC)emit_v6words(g,h6,g->net+8,T,F);else if(h6->dir==DIR_DST)emit_v6words(g,h6,g->net+24,T,F);else{next=newlabel(g);emit_v6words(g,h6,g->net+8,T,next);bindlabel(g,next);emit_v6words(g,h6,g->net+24,T,F);}return 1;}
static int emit_host_union(gen_t*g,const node_t*n,int T,int F){const node_t*v[16];int count=0,lip,larp,next,last=newlabel(g);if(!g->c->optimize||!n||n->kind!=N_OR||!collect_host_union(n,v,&count)||count<2)return 0;for(int i=1;i<count;i++)if(v[i]->dir!=v[0]->dir||v[i]->proto!=v[0]->proto||v[i]->mask!=v[0]->mask)return 0;if(v[0]->dir==DIR_BOTH_AND)return 0;layout(g);if(v[0]->proto==4||g->c->dlt==12||g->c->dlt==0){int body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);if(v[0]->dir!=DIR_DST){next=v[0]->dir==DIR_SRC?F:newlabel(g);emit_addr4_union(g,v,count,g->net+12,T,next);if(v[0]->dir!=DIR_SRC)bindlabel(g,next);}if(v[0]->dir!=DIR_SRC)emit_addr4_union(g,v,count,g->net+16,T,F);return 1;}lip=newlabel(g);larp=newlabel(g);ins(g,40,(g->c->dlt==1?12:g->c->dlt==113?14:2)+4U*g->vlan_depth);jump(g,21,g->c->dlt==9?33:2048,lip,(int)g->p->len+1);jump(g,21,2054,larp,(int)g->p->len+1);jump(g,21,32821,larp,F);bindlabel(g,larp);if(v[0]->dir!=DIR_DST){next=v[0]->dir==DIR_SRC?F:newlabel(g);emit_addr4_union(g,v,count,g->net+14,T,next);if(v[0]->dir!=DIR_SRC)bindlabel(g,next);}if(v[0]->dir!=DIR_SRC){if(v[0]->dir==DIR_DST)emit_addr4_union(g,v,count,g->net+24,T,F);else{ins(g,32,g->net+24);jump(g,21,v[0]->value&v[0]->mask,T,last);}}bindlabel(g,lip);if(v[0]->dir!=DIR_DST){next=v[0]->dir==DIR_SRC?F:newlabel(g);emit_addr4_union(g,v,count,g->net+12,T,next);if(v[0]->dir!=DIR_SRC)bindlabel(g,next);}if(v[0]->dir!=DIR_SRC){if(v[0]->dir==DIR_DST)emit_addr4_union(g,v,count,g->net+16,T,F);else{ins(g,32,g->net+16);jump(g,21,v[0]->value&v[0]->mask,T,last);bindlabel(g,last);for(int i=1;i<count;i++)jump(g,21,v[i]->value&v[i]->mask,T,i==count-1?F:(int)g->p->len+1);}}return 1;}
static int emit_host_pair(gen_t*g,const node_t*n,int T,int F){const node_t*a,*b;int body,dst;if(!g->c->optimize||!n||n->kind!=N_AND)return 0;a=n->l;b=n->r;if(a->kind!=N_PRIM||b->kind!=N_PRIM||(a->prim!=PK_HOST4&&a->prim!=PK_NET4)||(b->prim!=PK_HOST4&&b->prim!=PK_NET4)||a->proto!=b->proto||!((a->dir==DIR_SRC&&b->dir==DIR_DST)||(a->dir==DIR_DST&&b->dir==DIR_SRC)))return 0;if(a->dir==DIR_DST){const node_t*q=a;a=b;b=q;}layout(g);if(a->proto==4||g->c->dlt!=1){body=newlabel(g);dst=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);emit_addr4(g,g->net+12,a->value,a->mask,dst,F);bindlabel(g,dst);emit_addr4(g,g->net+16,b->value,b->mask,T,F);return 1;}int lip=newlabel(g),larp=newlabel(g);ins(g,40,12);jump(g,21,2048,lip,(int)g->p->len+1);jump(g,21,2054,larp,(int)g->p->len+1);jump(g,21,32821,larp,F);bindlabel(g,larp);dst=newlabel(g);emit_addr4(g,g->net+14,a->value,a->mask,dst,F);bindlabel(g,dst);emit_addr4(g,g->net+24,b->value,b->mask,T,F);bindlabel(g,lip);dst=newlabel(g);emit_addr4(g,g->net+12,a->value,a->mask,dst,F);bindlabel(g,dst);emit_addr4(g,g->net+16,b->value,b->mask,T,F);return 1;}
static int collect_host_protocol(const node_t*n,const node_t**h,const node_t**p,const node_t**neg){if(n->kind==N_AND)return collect_host_protocol(n->l,h,p,neg)&&collect_host_protocol(n->r,h,p,neg);if(n->kind==N_PRIM&&(n->prim==PK_HOST4||n->prim==PK_NET4)&&!*h){*h=n;return 1;}if(n->kind==N_PRIM&&n->prim==PK_IPPROTO&&!*p){*p=n;return 1;}if(n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE&&(n->l->value==2054||n->l->value==32821)&&!*neg){*neg=n->l;return 1;}return 0;}
static int collect_arp_host_relation(const node_t*n,const node_t**etype,const node_t**host,const node_t**rel){if(n->kind==N_AND)return collect_arp_host_relation(n->l,etype,host,rel)&&collect_arp_host_relation(n->r,etype,host,rel);if(n->kind==N_PRIM&&n->prim==PK_ETHERTYPE&&(n->value==2054||n->value==32821)&&!*etype){*etype=n;return 1;}if(n->kind==N_PRIM&&(n->prim==PK_HOST4||n->prim==PK_NET4)&&!*host){*host=n;return 1;}if(n->kind==N_REL&&abase_only(n->a,BASE_LINK)&&abase_only(n->b,BASE_LINK)&&!*rel){*rel=n;return 1;}if(n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE&&n->l->value!=2054&&n->l->value!=32821)return 1;return 0;}
static int emit_arp_host_relation(gen_t*g,const node_t*n,int T,int F){const node_t*etype=NULL,*host=NULL,*rel=NULL;int body,next;if(!g->c->optimize||!n||n->kind!=N_AND||!collect_arp_host_relation(n,&etype,&host,&rel)||!etype||!host||!rel)return 0;layout(g);body=newlabel(g);emit_ethertype(g,etype->value,body,F);bindlabel(g,body);next=newlabel(g);if(host->dir==DIR_SRC)emit_addr4(g,g->net+14,host->value,host->mask,next,F);else if(host->dir==DIR_DST)emit_addr4(g,g->net+24,host->value,host->mask,next,F);else{int dst=newlabel(g);emit_addr4(g,g->net+14,host->value,host->mask,next,dst);bindlabel(g,dst);emit_addr4(g,g->net+24,host->value,host->mask,next,F);}bindlabel(g,next);emit_relation(g,rel,T,F);return 1;}
static int collect_host_neg_proto(const node_t*n,const node_t**host,const node_t**proto){if(n->kind==N_AND)return collect_host_neg_proto(n->l,host,proto)&&collect_host_neg_proto(n->r,host,proto);if(n->kind==N_PRIM&&(n->prim==PK_HOST4||n->prim==PK_NET4)&&!*host){*host=n;return 1;}if(n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM&&n->l->prim==PK_IPPROTO&&!*proto){*proto=n->l;return 1;}return 0;}
static int emit_host_neg_proto(gen_t*g,const node_t*n,int T,int F){const node_t*h=NULL,*p=NULL;int host;if(!g->c->optimize||g->c->dlt!=0||!collect_host_neg_proto(n,&h,&p)||!h||!p||h->dir==DIR_BOTH_AND)return 0;ins(g,32,0);jump(g,21,167772160U,F,(int)g->p->len+1);jump(g,21,33554432U,(int)g->p->len+1,F);ins(g,48,13);host=newlabel(g);jump(g,21,132,host,(int)g->p->len+1);jump(g,21,6,host,(int)g->p->len+1);jump(g,21,17,host,(int)g->p->len+1);jump(g,21,p->value,F,host);bindlabel(g,host);if(h->dir==DIR_SRC)emit_addr4(g,16,h->value,h->mask,T,F);else if(h->dir==DIR_DST)emit_addr4(g,20,h->value,h->mask,T,F);else{int dst=newlabel(g);emit_addr4(g,16,h->value,h->mask,T,dst);bindlabel(g,dst);emit_addr4(g,20,h->value,h->mask,T,F);}return 1;}
static int collect_ip4_relation_port(const node_t*n,const node_t**rel,const node_t**port){if(n->kind==N_AND)return collect_ip4_relation_port(n->l,rel,port)&&collect_ip4_relation_port(n->r,rel,port);if(n->kind==N_PRIM&&n->prim==PK_ETHERTYPE&&n->value==2048)return 1;if(n->kind==N_REL&&abase_only(n->a,BASE_IP)&&abase_only(n->b,BASE_IP)&&!*rel){*rel=n;return 1;}if(n->kind==N_PRIM&&(n->prim==PK_PORT||n->prim==PK_PORTRANGE)&&!*port){*port=n;return 1;}return 0;}
static int emit_ip4_relation_port(gen_t*g,const node_t*n,int T,int F){const node_t*r=NULL,*p=NULL;int body,next,match;if(!g->c->optimize||g->c->dlt==105||!collect_ip4_relation_port(n,&r,&p)||!r||!p)return 0;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);next=newlabel(g);g->raw_guarded=BASE_IP;emit_relation(g,r,next,F);bindlabel(g,next);ins(g,48,g->net+9);match=newlabel(g);if(p->proto>=0)jump(g,21,(uint32_t)p->proto,match,F);else{jump(g,21,132,match,(int)g->p->len+1);jump(g,21,6,match,(int)g->p->len+1);jump(g,21,17,match,F);}bindlabel(g,match);ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,g->net);emit_port_checks(g,p,g->link+4U*g->vlan_depth,1,T,F);return 1;}
static int collect_ip6_ifindex_port(const node_t*n,const node_t**idx,const node_t**port,const node_t**host){if(n->kind==N_AND)return collect_ip6_ifindex_port(n->l,idx,port,host)&&collect_ip6_ifindex_port(n->r,idx,port,host);if(n->kind==N_PRIM&&n->prim==PK_ETHERTYPE&&n->value==34525)return 1;if(n->kind==N_PRIM&&n->prim==PK_IFINDEX&&!*idx){*idx=n;return 1;}if(n->kind==N_PRIM&&(n->prim==PK_PORT||n->prim==PK_PORTRANGE)&&!*port){*port=n;return 1;}if(n->kind==N_PRIM&&(n->prim==PK_HOST6||n->prim==PK_NET6)&&!*host){*host=n;return 1;}return 0;}
static int emit_ip6_ifindex_port(gen_t*g,const node_t*n,int T,int F){const node_t*idx=NULL,*p=NULL,*h=NULL;int body,next;if(!g->c->optimize||(g->c->dlt!=12&&g->c->dlt!=9)||!collect_ip6_ifindex_port(n,&idx,&p,&h)||!idx||!p)return 0;body=newlabel(g);emit_ipv6_guard(g,body,F);bindlabel(g,body);if(h){next=newlabel(g);if(h->dir==DIR_SRC)emit_v6words(g,h,g->net+8,next,F);else if(h->dir==DIR_DST)emit_v6words(g,h,g->net+24,next,F);else{int dst=newlabel(g);emit_v6words(g,h,g->net+8,next,dst);bindlabel(g,dst);emit_v6words(g,h,g->net+24,next,F);}bindlabel(g,next);}ins(g,32,0xfffff008U);jump(g,21,idx->value,(int)g->p->len+1,F);ins(g,48,g->net+6);if(p->proto>=0)jump(g,21,(uint32_t)p->proto,(int)g->p->len+1,F);else{jump(g,21,132,(int)g->p->len+3,(int)g->p->len+1);jump(g,21,6,(int)g->p->len+2,(int)g->p->len+1);jump(g,21,17,(int)g->p->len+1,F);}ins(g,40,g->net+40+(p->dir==DIR_DST?2:0));if(p->prim==PK_PORT)jump(g,21,p->value,T,F);else{jump(g,37,p->value-1,(int)g->p->len+1,F);jump(g,37,p->value2,F,T);}return 1;}
static int collect_ip6_port_guard(const node_t*n,const node_t**port,int*neg_rarp){if(n->kind==N_AND)return collect_ip6_port_guard(n->l,port,neg_rarp)&&collect_ip6_port_guard(n->r,port,neg_rarp);if(n->kind==N_PRIM&&n->prim==PK_ETHERTYPE&&n->value==34525)return 1;if(n->kind==N_PRIM&&(n->prim==PK_PORT||n->prim==PK_PORTRANGE)&&!*port){*port=n;return 1;}if(n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE&&n->l->value==32821){*neg_rarp=1;return 1;}return 0;}
static int emit_ip6_port_guard(gen_t*g,const node_t*n,int T,int F){const node_t*p=NULL;int neg=0,body;if(!g->c->optimize||g->c->dlt!=9||!collect_ip6_port_guard(n,&p,&neg)||!p||!neg||(p->prim==PK_PORTRANGE&&p->value!=p->value2))return 0;ins(g,40,2);jump(g,21,32821,F,(int)g->p->len+1);jump(g,21,87,(int)g->p->len+1,F);ins(g,48,10);if(p->proto>=0)jump(g,21,(uint32_t)p->proto,(int)g->p->len+1,F);else{jump(g,21,132,(int)g->p->len+3,(int)g->p->len+1);jump(g,21,6,(int)g->p->len+2,(int)g->p->len+1);jump(g,21,17,(int)g->p->len+1,F);}body=p->dir==DIR_DST?42:40;ins(g,40,(uint32_t)body+4);jump(g,21,p->value,T,F);return 1;}
static int collect_host_proto_broadcast(const node_t*n,const node_t**h,const node_t**p,const node_t**b){if(n->kind==N_AND)return collect_host_proto_broadcast(n->l,h,p,b)&&collect_host_proto_broadcast(n->r,h,p,b);if(n->kind==N_PRIM&&(n->prim==PK_HOST4||n->prim==PK_NET4)&&!*h){*h=n;return 1;}if(n->kind==N_PRIM&&n->prim==PK_IPPROTO&&!*p){*p=n;return 1;}if(n->kind==N_PRIM&&n->prim==PK_BROADCAST&&!*b){*b=n;return 1;}return n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE&&n->l->value==34525;}
static int emit_host_proto_broadcast(gen_t*g,const node_t*n,int T,int F){const node_t*h=NULL,*p=NULL,*b=NULL;int body,next;if(!g->c->optimize||g->c->dlt!=1||!collect_host_proto_broadcast(n,&h,&p,&b)||!h||!p||!b)return 0;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);next=newlabel(g);if(h->dir==DIR_SRC)emit_addr4(g,g->net+12,h->value,h->mask,next,F);else if(h->dir==DIR_DST)emit_addr4(g,g->net+16,h->value,h->mask,next,F);else{int dst=newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,next,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,h->value,h->mask,next,F);}bindlabel(g,next);ins(g,48,g->net+9);next=newlabel(g);jump(g,21,p->value,next,F);bindlabel(g,next);ins(g,32,0);next=newlabel(g);jump(g,21,0xffffffffU,next,F);bindlabel(g,next);ins(g,40,4);jump(g,21,0xffff,T,F);return 1;}
static int collect_misc_host_protocol(const node_t*n,const node_t**h,const node_t**p,const node_t**rels,int*nr){if(n->kind==N_AND)return collect_misc_host_protocol(n->l,h,p,rels,nr)&&collect_misc_host_protocol(n->r,h,p,rels,nr);if(n->kind==N_PRIM&&(n->prim==PK_HOST4||n->prim==PK_NET4)&&!*h){*h=n;return 1;}if(n->kind==N_PRIM&&n->prim==PK_IPPROTO&&!*p){*p=n;return 1;}if(n->kind==N_REL&&*nr<4&&(n->a->kind==A_LEN||abase_only(n->a,BASE_LINK))&&abase_only(n->b,BASE_LINK)){rels[(*nr)++]=n;return 1;}return 0;}
static int emit_misc_host_protocol(gen_t*g,const node_t*n,int T,int F){const node_t*h=NULL,*p=NULL,*rels[4];int nr=0,body,next;if(!g->c->optimize||!n||n->kind!=N_AND||!collect_misc_host_protocol(n,&h,&p,rels,&nr)||!h||!p||!nr)return 0;for(int i=0;i<nr;i++){next=newlabel(g);emit_relation(g,rels[i],next,F);bindlabel(g,next);}layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);next=newlabel(g);if(h->dir==DIR_SRC)emit_addr4(g,g->net+12,h->value,h->mask,next,F);else if(h->dir==DIR_DST)emit_addr4(g,g->net+16,h->value,h->mask,next,F);else{int dst=newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,next,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,h->value,h->mask,next,F);}bindlabel(g,next);ins(g,48,g->net+9);jump(g,21,p->value,T,F);return 1;}
static int emit_host_protocol_pair(gen_t*g,const node_t*n,int T,int F){const node_t*h=NULL,*p=NULL,*neg=NULL;int body,next;if(!g->c->optimize||g->c->dlt==105||!n||n->kind!=N_AND||!collect_host_protocol(n,&h,&p,&neg)||!h||!p)return 0;layout(g);body=newlabel(g);if(neg){unsigned eo=g->c->dlt==1?12:g->c->dlt==113?14:2;ins(g,40,eo);jump(g,21,g->c->dlt==9?87:neg->value,F,(int)g->p->len+1);jump(g,21,g->c->dlt==9?33:2048,body,F);}else emit_ipv4_guard(g,body,F);bindlabel(g,body);next=newlabel(g);if(h->dir==DIR_SRC)emit_addr4(g,g->net+12,h->value,h->mask,next,F);else if(h->dir==DIR_DST)emit_addr4(g,g->net+16,h->value,h->mask,next,F);else{int dst=newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,next,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,h->value,h->mask,next,F);}bindlabel(g,next);ins(g,48,g->net+9);jump(g,21,p->value,T,F);return 1;}
static int emit_host_relation_union(gen_t*g,const node_t*n,int T,int F){const node_t*h,*r;load_base_t base;int body,next,proto;if(!g->c->optimize||g->c->dlt!=12||!n||n->kind!=N_OR)return 0;if(n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)&&n->r->kind==N_REL){h=n->l;r=n->r;}else if(n->r->kind==N_PRIM&&(n->r->prim==PK_HOST4||n->r->prim==PK_NET4)&&n->l->kind==N_REL){h=n->r;r=n->l;}else return 0;for(base=BASE_TCP;base<=BASE_ICMP6;base++)if(abase_has(r->a,base)&&abase_only(r->a,base)&&abase_only(r->b,base))break;if(base>BASE_ICMP6)return 0;proto=base==BASE_TCP?6:base==BASE_UDP?17:base==BASE_ICMP?1:58;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);if(h->dir==DIR_SRC)emit_addr4(g,g->net+12,h->value,h->mask,T,(next=newlabel(g)));else if(h->dir==DIR_DST)emit_addr4(g,g->net+16,h->value,h->mask,T,(next=newlabel(g)));else{int dst=newlabel(g);next=newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,T,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,h->value,h->mask,T,next);}bindlabel(g,next);body=newlabel(g);ins(g,48,g->net+9);jump(g,21,(uint32_t)proto,body,F);bindlabel(g,body);g->raw_guarded=base;emit_relation(g,r,T,F);return 1;}
static int emit_host_relation_pair(gen_t*g,const node_t*n,int T,int F){const node_t*h,*r;load_base_t base;int body,next,proto;if(!g->c->optimize||!n||n->kind!=N_AND||g->c->dlt==105)return 0;if(n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)&&n->r->kind==N_REL){h=n->l;r=n->r;}else if(n->r->kind==N_PRIM&&(n->r->prim==PK_HOST4||n->r->prim==PK_NET4)&&n->l->kind==N_REL){h=n->r;r=n->l;}else return 0;for(base=BASE_TCP;base<=BASE_ICMP;base++)if(abase_has(r->a,base)&&abase_only(r->a,base)&&abase_only(r->b,base))break;if(base<=BASE_ICMP){layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);proto=base==BASE_TCP?6:base==BASE_UDP?17:1;next=newlabel(g);ins(g,48,g->net+9);jump(g,21,(uint32_t)proto,next,F);bindlabel(g,next);next=newlabel(g);g->raw_guarded=base;emit_relation(g,r,next,F);bindlabel(g,next);if(h->dir==DIR_SRC)emit_addr4(g,g->net+12,h->value,h->mask,T,F);else if(h->dir==DIR_DST)emit_addr4(g,g->net+16,h->value,h->mask,T,F);else{int dst=newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,T,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,h->value,h->mask,T,F);}return 1;}if(!abase_has(r->a,BASE_IP)||!abase_only(r->a,BASE_IP)||!abase_only(r->b,BASE_IP))return 0;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);next=newlabel(g);if(h->dir==DIR_SRC)emit_addr4(g,g->net+12,h->value,h->mask,next,F);else if(h->dir==DIR_DST)emit_addr4(g,g->net+16,h->value,h->mask,next,F);else{int dst=newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,next,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,h->value,h->mask,next,F);}bindlabel(g,next);g->raw_guarded=BASE_IP;emit_relation(g,r,T,F);return 1;}
static void emit_transport_match(gen_t*g,int proto,int T,int F){ins(g,48,g->net+9);if(proto>=0)jump(g,21,(uint32_t)proto,T,F);else{jump(g,21,132,T,(int)g->p->len+1);jump(g,21,6,T,(int)g->p->len+1);jump(g,21,17,T,F);}}
static int collect_protocol_port_host(const node_t*n,const node_t**proto,const node_t**port,const node_t**host){if(n->kind==N_AND)return collect_protocol_port_host(n->l,proto,port,host)&&collect_protocol_port_host(n->r,proto,port,host);if(n->kind==N_PRIM&&n->prim==PK_IPPROTO&&!*proto){*proto=n;return 1;}if(n->kind==N_PRIM&&(n->prim==PK_PORT||n->prim==PK_PORTRANGE)&&!*port){*port=n;return 1;}if(n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)&&!*host){*host=n->l;return 1;}return 0;}
static int emit_protocol_port_not_host(gen_t*g,const node_t*n,int T,int F){const node_t*proto=NULL,*port=NULL,*host=NULL;int body,next;if(!g->c->optimize||g->c->dlt==105||!n||n->kind!=N_AND||!collect_protocol_port_host(n,&proto,&port,&host)||!proto||!port||!host||proto->proto!=4||port->proto!=(int)proto->value)return 0;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);next=newlabel(g);emit_transport_match(g,(int)proto->value,next,F);bindlabel(g,next);ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,g->net);next=newlabel(g);emit_port_checks(g,port,g->link,1,next,F);bindlabel(g,next);if(host->dir==DIR_SRC)emit_addr4(g,g->net+12,host->value,host->mask,F,T);else if(host->dir==DIR_DST)emit_addr4(g,g->net+16,host->value,host->mask,F,T);else{int dst=newlabel(g);emit_addr4(g,g->net+12,host->value,host->mask,F,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,host->value,host->mask,F,T);}return 1;}
static int emit_ipv4_port_pair(gen_t*g,const node_t*n,int T,int F){const node_t*p;int body,ports;if(!g->c->optimize||g->c->dlt==105||!n||n->kind!=N_AND)return 0;if(n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE&&n->l->value==2048&&n->r->kind==N_PRIM&&(n->r->prim==PK_PORT||n->r->prim==PK_PORTRANGE))p=n->r;else if(n->r->kind==N_PRIM&&n->r->prim==PK_ETHERTYPE&&n->r->value==2048&&n->l->kind==N_PRIM&&(n->l->prim==PK_PORT||n->l->prim==PK_PORTRANGE))p=n->l;else return 0;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);ports=newlabel(g);emit_transport_match(g,p->proto,ports,F);bindlabel(g,ports);ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,g->net);emit_port_checks(g,p,g->link,1,T,F);return 1;}
static int emit_host_port_pair(gen_t*g,const node_t*n,int T,int F){const node_t*h=NULL,*p=NULL,*proto=NULL;int body,hostok,portok;if(!g->c->optimize||g->c->dlt==105||!n||n->kind!=N_AND)return 0;if(n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)&&n->r->kind==N_PRIM&&(n->r->prim==PK_PORT||n->r->prim==PK_PORTRANGE)){h=n->l;p=n->r;}else if(n->l->kind==N_AND&&n->l->l->kind==N_PRIM&&n->l->l->prim==PK_IPPROTO&&n->l->r->kind==N_PRIM&&(n->l->r->prim==PK_HOST4||n->l->r->prim==PK_NET4)&&n->r->kind==N_PRIM&&(n->r->prim==PK_PORT||n->r->prim==PK_PORTRANGE)){proto=n->l->l;h=n->l->r;p=n->r;}else return 0;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);if(proto){hostok=newlabel(g);emit_transport_match(g,(int)proto->value,hostok,F);bindlabel(g,hostok);}if(h->dir==DIR_SRC)emit_addr4(g,g->net+12,h->value,h->mask,(hostok=newlabel(g)),F);else if(h->dir==DIR_DST)emit_addr4(g,g->net+16,h->value,h->mask,(hostok=newlabel(g)),F);else{int dst=newlabel(g);hostok=newlabel(g);emit_addr4(g,g->net+12,h->value,h->mask,hostok,dst);bindlabel(g,dst);emit_addr4(g,g->net+16,h->value,h->mask,hostok,F);}bindlabel(g,hostok);if(!proto){portok=newlabel(g);emit_transport_match(g,p->proto,portok,F);bindlabel(g,portok);}ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,g->net);emit_port_checks(g,p,g->link,1,T,F);return 1;}
static int emit_port_pair(gen_t*g,const node_t*n,int T,int F){
    const node_t*a,*b;
    int v6,next,upper,proto;
    if(!g->c->optimize||g->c->dlt!=12||!n||n->kind!=N_AND)return 0;
    if(n->l->kind==N_AND&&n->l->l->kind==N_PRIM&&n->l->l->prim==PK_IPPROTO&&n->l->r->kind==N_PRIM&&(n->l->r->prim==PK_PORT||n->l->r->prim==PK_PORTRANGE)){
        a=n->l->r;b=n->r;proto=(int)n->l->l->value;
    }else{a=n->l;b=n->r;proto=a->proto;}
    if(a->kind!=N_PRIM||b->kind!=N_PRIM||(a->prim!=PK_PORT&&a->prim!=PK_PORTRANGE)||(b->prim!=PK_PORT&&b->prim!=PK_PORTRANGE)||proto<0||(b->proto>=0&&proto!=b->proto))return 0;
    layout(g);v6=newlabel(g);upper=b->prim==PK_PORTRANGE?newlabel(g):0;
    ins(g,48,0);ins(g,84,240);jump(g,21,96,v6,(int)g->p->len+1);
    ins(g,48,0);ins(g,84,240);jump(g,21,64,(int)g->p->len+1,F);
    ins(g,48,g->net+9);jump(g,21,(uint32_t)proto,(int)g->p->len+1,F);
    ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,g->net);
    next=newlabel(g);emit_port_checks(g,a,g->link,1,next,F);bindlabel(g,next);
    if(upper){ins(g,ldop(2,1),g->link+(b->dir==DIR_DST?2:0));jump(g,37,b->value-1,upper,F);}else emit_port_checks(g,b,g->link,1,T,F);
    bindlabel(g,v6);ins(g,48,g->net+6);jump(g,21,(uint32_t)proto,(int)g->p->len+1,F);
    next=newlabel(g);emit_port_checks(g,a,g->net+40,0,next,F);bindlabel(g,next);
    if(upper){ins(g,40,g->net+40+(b->dir==DIR_DST?2:0));jump(g,37,b->value-1,(int)g->p->len+1,F);bindlabel(g,upper);jump(g,37,b->value2,F,T);}else emit_port_checks(g,b,g->net+40,0,T,F);
    return 1;
}
static int emit_protocol_port_pair(gen_t*g,const node_t*n,int T,int F){const node_t*p,*q;int v4=newlabel(g),v6=newlabel(g);unsigned eo,no;uint32_t e4,e6;if(!g->c->optimize||!n||n->kind!=N_AND||g->c->dlt==105)return 0;p=n->l;q=n->r;if(p->kind!=N_PRIM||p->prim!=PK_IPPROTO||q->kind!=N_PRIM||(q->prim!=PK_PORT&&q->prim!=PK_PORTRANGE)||q->proto!=(int)p->value)return 0;layout(g);no=g->net;if(g->c->dlt==12){ins(g,48,0);ins(g,84,240);jump(g,21,64,v4,(int)g->p->len+1);ins(g,48,0);ins(g,84,240);jump(g,21,96,v6,F);}else if(g->c->dlt==0){ins(g,32,0);jump(g,21,33554432U,v4,(int)g->p->len+1);jump(g,21,167772160U,v6,F);}else{eo=g->c->dlt==1?12:g->c->dlt==113?14:2;e4=g->c->dlt==9?33:2048;e6=g->c->dlt==9?87:34525;ins(g,40,eo);jump(g,21,e4,v4,(int)g->p->len+1);jump(g,21,e6,v6,F);}bindlabel(g,v6);ins(g,48,no+6);jump(g,21,p->value,(int)g->p->len+1,F);emit_port_checks(g,q,no+40,0,T,F);bindlabel(g,v4);ins(g,48,no+9);jump(g,21,p->value,(int)g->p->len+1,F);ins(g,40,no+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,no);emit_port_checks(g,q,g->link,1,T,F);return 1;}
static int emit_proto_port_or(gen_t*g,const node_t*n,int T,int F){const node_t*p,*u,*a,*b;int v4,s6,s4,upper;unsigned no;if(!g->c->optimize||g->c->dlt!=1||!n||n->kind!=N_AND)return 0;p=n->l;u=n->r;if(p->kind!=N_PRIM||p->prim!=PK_IPPROTO||u->kind!=N_OR)return 0;a=u->l;b=u->r;if(a->kind!=N_PRIM||b->kind!=N_PRIM||a->prim!=PK_PORTRANGE||b->prim!=PK_PORTRANGE||a->dir==b->dir||a->value!=b->value||a->value2!=b->value2)return 0;if(a->dir==DIR_SRC){const node_t*q=a;a=b;b=q;}layout(g);no=g->net;v4=newlabel(g);s6=newlabel(g);s4=newlabel(g);upper=newlabel(g);ins(g,40,12);jump(g,21,2048,v4,(int)g->p->len+1);jump(g,21,34525,(int)g->p->len+1,F);ins(g,48,no+6);jump(g,21,p->value,(int)g->p->len+1,F);ins(g,40,no+42);jump(g,37,a->value-1,(int)g->p->len+1,s6);jump(g,37,a->value2,s6,T);bindlabel(g,s6);ins(g,40,no+40);jump(g,37,b->value-1,upper,F);bindlabel(g,v4);ins(g,48,no+9);jump(g,21,p->value,(int)g->p->len+1,F);ins(g,40,no+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,no);ins(g,72,g->link+2);jump(g,37,a->value-1,(int)g->p->len+1,s4);jump(g,37,a->value2,s4,T);bindlabel(g,s4);ins(g,72,g->link);jump(g,37,b->value-1,upper,F);bindlabel(g,upper);jump(g,37,b->value2,F,T);return 1;}
static int emit_proto_union_range(gen_t*g,const node_t*n,int T,int F){const node_t*u,*r;int v4,upper,d6,d4;unsigned no;if(!g->c->optimize||g->c->dlt!=1||!n||n->kind!=N_AND)return 0;u=n->l;r=n->r;if(u->kind!=N_OR||u->l->kind!=N_PRIM||u->r->kind!=N_PRIM||u->l->prim!=PK_IPPROTO||u->r->prim!=PK_IPPROTO||r->kind!=N_PRIM||r->prim!=PK_PORTRANGE||r->dir!=DIR_ANY)return 0;layout(g);no=g->net;v4=newlabel(g);upper=newlabel(g);d6=newlabel(g);d4=newlabel(g);ins(g,40,12);jump(g,21,2048,v4,(int)g->p->len+1);jump(g,21,34525,(int)g->p->len+1,F);ins(g,48,no+6);jump(g,21,u->l->value,(int)g->p->len+3,(int)g->p->len+1);jump(g,21,44,F,(int)g->p->len+1);jump(g,21,u->r->value,(int)g->p->len+1,F);ins(g,40,no+40);jump(g,37,r->value-1,(int)g->p->len+1,d6);jump(g,37,r->value2,d6,T);bindlabel(g,d6);ins(g,40,no+42);jump(g,37,r->value-1,upper,F);bindlabel(g,v4);ins(g,48,no+9);jump(g,21,u->l->value,(int)g->p->len+2,(int)g->p->len+1);jump(g,21,u->r->value,(int)g->p->len+1,F);ins(g,40,no+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,no);ins(g,72,g->link);jump(g,37,r->value-1,(int)g->p->len+1,d4);jump(g,37,r->value2,d4,T);bindlabel(g,d4);ins(g,72,g->link+2);jump(g,37,r->value-1,upper,F);bindlabel(g,upper);jump(g,37,r->value2,F,T);return 1;}
static int emit_ipv4_proto_ports(gen_t*g,const node_t*n,int T,int F){const node_t*pu,*ports,*p1,*p2;int body,frag;if(!g->c->optimize||!n||n->kind!=N_AND||g->c->dlt==105)return 0;pu=n->l;ports=n->r;if(pu->kind!=N_AND||pu->l->kind!=N_PRIM||pu->l->prim!=PK_ETHERTYPE||pu->l->value!=2048||pu->r->kind!=N_OR||ports->kind!=N_OR)return 0;if(pu->r->l->kind!=N_PRIM||pu->r->r->kind!=N_PRIM||pu->r->l->prim!=PK_IPPROTO||pu->r->r->prim!=PK_IPPROTO)return 0;p1=ports->l;p2=ports->r;if(p1->kind!=N_PRIM||p2->kind!=N_PRIM||p1->prim!=PK_PORT||p2->prim!=PK_PORT||p1->dir!=DIR_ANY||p2->dir!=DIR_ANY)return 0;layout(g);body=newlabel(g);emit_ipv4_guard(g,body,F);bindlabel(g,body);ins(g,48,g->net+9);jump(g,21,pu->r->l->value,(int)g->p->len+2,(int)g->p->len+1);jump(g,21,pu->r->r->value,(frag=newlabel(g)),F);bindlabel(g,frag);ins(g,40,g->net+6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,g->net);ins(g,72,g->link);jump(g,21,p1->value,T,(int)g->p->len+1);jump(g,21,p2->value,T,(int)g->p->len+1);ins(g,72,g->link+2);jump(g,21,p1->value,T,(int)g->p->len+1);jump(g,21,p2->value,T,F);return 1;}
static int emit_relation_union(gen_t*g,const node_t*n,int T,int F){uint32_t a,b;const node_t*l,*r;if(!g->c->optimize||!n||(n->kind!=N_AND&&n->kind!=N_OR))return 0;l=n->l;r=n->r;if(l->kind!=N_REL||r->kind!=N_REL||!aequal(l->a,r->a)||!cval(l->b,&a)||!cval(r->b,&b))return 0;if(n->kind==N_AND&&l->rel==R_NE&&r->rel==R_NE){emit_aval_opt(g,l->a,F);jump(g,21,a,F,(int)g->p->len+1);jump(g,21,b,F,T);return 1;}if(n->kind==N_OR&&l->rel==R_EQ&&r->rel==R_EQ){emit_aval_opt(g,l->a,F);jump(g,21,a,T,(int)g->p->len+1);jump(g,21,b,T,F);return 1;}return 0;}
static int relation_neg_proto(const node_t*n,const node_t**rel,const node_t**proto){const node_t*a,*b;if(!n||n->kind!=N_OR)return 0;a=n->l;b=n->r;if(a&&a->kind==N_NOT){const node_t*q=a;a=b;b=q;}if(!a||a->kind!=N_REL||!abase_only(a->a,BASE_IP)||!abase_only(a->b,BASE_IP)||!b||b->kind!=N_NOT||!b->l||b->l->kind!=N_PRIM||b->l->prim!=PK_IPPROTO||b->l->value2)return 0;*rel=a;*proto=b->l;return 1;}
static int emit_relation_neg_proto(gen_t*g,const node_t*n,int T,int F){const node_t*r,*p;int lv4,lv6,frag,next;unsigned eo;uint32_t e4,e6;if(!g->c->optimize||!relation_neg_proto(n,&r,&p)||g->dynamic)return 0;layout(g);lv4=newlabel(g);lv6=newlabel(g);if(g->c->dlt==0){ins(g,32,0);if(p->proto==4){jump(g,21,167772160U,T,(int)g->p->len+1);jump(g,21,33554432U,lv4,T);}else{jump(g,21,33554432U,lv4,(int)g->p->len+1);jump(g,21,167772160U,lv6,T);}}else if(g->c->dlt==1||g->c->dlt==9||g->c->dlt==113){eo=g->c->dlt==1?12:g->c->dlt==113?14:2;e4=g->c->dlt==9?33:2048;e6=g->c->dlt==9?87:34525;ins(g,40,eo);jump(g,21,e4,lv4,(int)g->p->len+1);jump(g,21,e6,p->proto==4?T:lv6,T);}else return 0;if(p->proto!=4){bindlabel(g,lv6);ins(g,48,g->net+6);jump(g,21,p->value,F,(int)g->p->len+1);frag=newlabel(g);jump(g,21,44,frag,T);bindlabel(g,frag);ins(g,48,g->net+40);jump(g,21,p->value,F,T);}bindlabel(g,lv4);next=newlabel(g);g->raw_guarded=BASE_IP;emit_relation(g,r,T,next);bindlabel(g,next);ins(g,48,g->net+9);jump(g,21,p->value,F,T);return 1;}
static const node_t*find_and_proto(const node_t*n){const node_t*p;if(!n)return NULL;if(n->kind==N_PRIM&&n->prim==PK_IPPROTO)return n;if(n->kind!=N_AND)return NULL;p=find_and_proto(n->l);return p?p:find_and_proto(n->r);}
static int reducible_proto_conj(const node_t*n,const node_t*p){load_base_t base;if(n==p)return 1;if(n&&n->kind==N_AND)return reducible_proto_conj(n->l,p)&&reducible_proto_conj(n->r,p);if(!n||n->kind!=N_NOT||!n->l)return 0;if(n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE)return n->l->value==0xf0f0||n->l->value==0x26||n->l->value==0x8137||n->l->value==0x80f3||n->l->value==0x809b;if(n->l->kind!=N_REL)return 0;for(base=BASE_TCP;base<=BASE_ICMP6;base++)if(abase_has(n->l->a,base))break;return base<=BASE_ICMP6&&(uint32_t)(base==BASE_TCP?6:base==BASE_UDP?17:base==BASE_ICMP?1:58)!=p->value;}
static int emit_neg_proto_union(gen_t*g,const node_t*n,int T,int F){const node_t*a,*b,*v[2];int nv4=0,nv6=0,lv4,lv6,frag;unsigned eo;uint32_t e4,e6;if(!g->c->optimize||!n||n->kind!=N_NOT||!n->l||n->l->kind!=N_OR)return 0;a=n->l->l;b=n->l->r;if(a&&a->kind!=N_PRIM){const node_t*p=find_and_proto(a);if(p&&reducible_proto_conj(a,p))a=p;}if(b&&b->kind!=N_PRIM){const node_t*p=find_and_proto(b);if(p&&reducible_proto_conj(b,p))b=p;}if(!a||!b||a->kind!=N_PRIM||b->kind!=N_PRIM||a->prim!=PK_IPPROTO||b->prim!=PK_IPPROTO||a->value2||b->value2)return 0;if(g->c->dlt!=1&&g->c->dlt!=9&&g->c->dlt!=113)return 0;layout(g);eo=g->c->dlt==1?12:g->c->dlt==113?14:2;e4=g->c->dlt==9?33:2048;e6=g->c->dlt==9?87:34525;lv4=newlabel(g);lv6=newlabel(g);ins(g,40,eo);jump(g,21,e4,lv4,(int)g->p->len+1);jump(g,21,e6,lv6,T);bindlabel(g,lv6);if(a->proto!=4)v[nv6++]=a;if(b->proto!=4)v[nv6++]=b;ins(g,48,g->net+6);for(int i=0;i<nv6;i++)jump(g,21,v[i]->value,F,(int)g->p->len+1);frag=newlabel(g);jump(g,21,44,frag,T);bindlabel(g,frag);ins(g,48,g->net+40);for(int i=0;i<nv6;i++)jump(g,21,v[i]->value,F,i==nv6-1?T:(int)g->p->len+1);bindlabel(g,lv4);if(a->proto!=6)v[nv4++]=a;if(b->proto!=6)v[nv4++]=b;ins(g,48,g->net+9);for(int i=0;i<nv4;i++)jump(g,21,v[i]->value,F,i==nv4-1?T:(int)g->p->len+1);return 1;}
static int collect_neg_link(const node_t*n,const node_t**v,int*count){if(n->kind==N_AND)return collect_neg_link(n->l,v,count)&&collect_neg_link(n->r,v,count);if(n->kind!=N_NOT||!n->l||n->l->kind!=N_PRIM||n->l->prim!=PK_ETHERTYPE||*count>=16)return 0;v[(*count)++]=n->l;return 1;}
static int emit_negated_link_chain(gen_t*g,const node_t*n,int T,int F){const node_t*v[16];int count=0,normal=0;unsigned eo;if(!g->c->optimize||g->c->dlt!=1||!collect_neg_link(n,v,&count)||count<2)return 0;eo=12;for(int i=0;i<count;i++)if(v[i]->value!=0x26)normal++;if(normal){ins(g,40,eo);for(int i=0;i<count;i++)if(v[i]->value!=0x26)jump(g,21,v[i]->value,F,(int)g->p->len+1);}for(int i=0;i<count;i++)if(v[i]->value==0x26){if(!normal)ins(g,40,eo);jump(g,37,1500,T,(int)g->p->len+1);ins(g,48,eo+2);jump(g,21,66,F,T);return 1;}if(normal==count)return 1;return 0;}
static int redundant_port_proto_or(const node_t*n,const node_t**pa,const node_t**pb,const node_t**neg,const node_t**rel);
static int emit_redundant_port_proto_or(gen_t*g,const node_t*n,int T,int F){const node_t*pa,*pb,*neg,*rel;int body;if(!g->c->optimize||g->c->dlt!=0||!redundant_port_proto_or(n,&pa,&pb,&neg,&rel)||pb->proto<0||(uint32_t)pb->proto==neg->value)return 0;ins(g,32,0);jump(g,21,167772160U,T,(int)g->p->len+1);body=newlabel(g);jump(g,21,33554432U,body,T);bindlabel(g,body);g->raw_guarded=BASE_IP;ins(g,48,g->net+9);jump(g,21,(uint32_t)pa->proto,T,(int)g->p->len+1);jump(g,21,(uint32_t)pb->proto,T,(int)g->p->len+1);{int check=newlabel(g);jump(g,21,neg->value,check,T);bindlabel(g,check);}emit_relation(g,rel,T,F);return 1;}
static int emit_neg_port_icmp(gen_t*g,const node_t*n,int T,int F){const node_t*p,*r;int v4,v6,icmp,p4,p6;if(!g->c->optimize||g->c->dlt!=12||!n||n->kind!=N_NOT||!n->l||n->l->kind!=N_OR)return 0;p=n->l->l;r=n->l->r;if(!p||p->kind!=N_PRIM||(p->prim!=PK_PORT&&p->prim!=PK_PORTRANGE)||p->dir!=DIR_DST||p->proto>=0||(p->prim==PK_PORTRANGE&&p->value!=p->value2)||!r||r->kind!=N_REL||r->rel!=R_EQ||!r->a||r->a->kind!=A_LOAD||r->a->base!=BASE_ICMP||!r->b||r->b->kind!=A_CONST)return 0;v4=newlabel(g);v6=newlabel(g);icmp=newlabel(g);p4=newlabel(g);p6=newlabel(g);ins(g,48,0);ins(g,84,240);jump(g,21,96,v6,(int)g->p->len+1);ins(g,48,0);ins(g,84,240);jump(g,21,64,v4,T);bindlabel(g,v4);ins(g,48,9);jump(g,21,132,p4,(int)g->p->len+1);jump(g,21,6,p4,(int)g->p->len+1);jump(g,21,17,p4,(int)g->p->len+1);jump(g,21,1,icmp,T);bindlabel(g,icmp);ins(g,40,6);jump(g,69,8191,T,(int)g->p->len+1);ins(g,177,0);ins(g,80,r->a->value);jump(g,21,r->b->value,F,T);bindlabel(g,p4);ins(g,40,6);jump(g,69,8191,T,(int)g->p->len+1);ins(g,177,0);ins(g,72,2);jump(g,21,p->value,F,T);bindlabel(g,v6);ins(g,48,6);jump(g,21,132,p6,(int)g->p->len+1);jump(g,21,6,p6,(int)g->p->len+1);jump(g,21,17,p6,T);bindlabel(g,p6);ins(g,40,42);jump(g,21,p->value,F,T);return 1;}

static int has_host4_node(const node_t*n){return n&&((n->kind==N_PRIM&&(n->prim==PK_HOST4||n->prim==PK_NET4))||has_host4_node(n->l)||has_host4_node(n->r));}
static int has_not_ip6(const node_t*n){return n&&((n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE&&n->l->value==34525)||has_not_ip6(n->l)||has_not_ip6(n->r));}

static int emit_link_negproto_host(gen_t*g,const node_t*n,int T,int F){const node_t*u,*rel,*neg,*host;int direct,proto,addr;unsigned off;if(!g->c->optimize||g->c->dlt!=0||!n||n->kind!=N_AND)return 0;u=n->l;host=n->r;if(!u||u->kind!=N_OR||!host||host->kind!=N_PRIM||(host->prim!=PK_HOST4&&host->prim!=PK_NET4)||host->dir==DIR_BOTH_AND)return 0;rel=u->l;neg=u->r;if(!rel||rel->kind!=N_REL||!neg||neg->kind!=N_NOT||!neg->l||neg->l->kind!=N_PRIM||neg->l->prim!=PK_IPPROTO)return 0;direct=newlabel(g);proto=newlabel(g);addr=newlabel(g);emit_relation(g,rel,direct,proto);bindlabel(g,direct);emit_ipv4_guard(g,addr,F);bindlabel(g,proto);{int check=newlabel(g);emit_ipv4_guard(g,check,F);bindlabel(g,check);}ins(g,48,g->net+9);jump(g,21,neg->l->value,F,addr);bindlabel(g,addr);off=host->dir==DIR_SRC?g->net+12:g->net+16;emit_addr4(g,off,host->value,host->mask,T,F);return 1;}
static int emit_wifi_broadcast_proto(gen_t*g,const node_t*n,int T,int F){const node_t*b,*p;int start,next;if(g->c->dlt!=105||!n||n->kind!=N_OR)return 0;b=n->l;p=n->r;if(!b||b->kind!=N_PRIM||b->prim!=PK_BROADCAST||!p||p->kind!=N_PRIM||p->prim!=PK_ETHERTYPE)return 0;start=newlabel(g);next=newlabel(g);{int s=(int)g->p->len,m=g->wifi_slot;ins(g,1,0);ins(g,135,0);ins(g,4,24);ins(g,2,m);ins(g,80,0);jump(g,69,8,s+6,start);jump(g,69,4,start,s+7);jump(g,69,128,s+8,start);ins(g,96,m);ins(g,4,2);ins(g,2,m);}bindlabel(g,start);emit_broadcast(g,b,T,next);bindlabel(g,next);emit_wifi_v4gate(g,F);ins(g,97,g->wifi_slot);ins(g,72,6);jump(g,21,p->value,T,F);return 1;}
static int collect_or_nodes(const node_t*n,const node_t**v,int*count){if(n&&n->kind==N_OR)return collect_or_nodes(n->l,v,count)&&collect_or_nodes(n->r,v,count);if(!n||*count>=8)return 0;v[(*count)++]=n;return 1;}
static int emit_arc_neg_range_chain(gen_t*g,const node_t*n,int T,int F){const node_t*v[8],*pair,*port,*rel,*range;int count=0,udp,src,src_loaded,high;uint32_t lo,hi;if(!g->c->optimize||g->c->dlt!=9||!collect_or_nodes(n,v,&count)||count!=4)return 0;if(v[0]->kind!=N_NOT||!v[0]->l||v[0]->l->kind!=N_PRIM||v[0]->l->prim!=PK_ETHERTYPE||v[0]->l->value!=2048||v[1]->kind!=N_PRIM||v[1]->prim!=PK_ETHERTYPE||v[2]->kind!=N_AND||v[3]->kind!=N_NOT||!v[3]->l||v[3]->l->kind!=N_PRIM||v[3]->l->prim!=PK_PORTRANGE||v[3]->l->dir!=DIR_SRC)return 0;pair=v[2];port=pair->l;rel=pair->r;range=v[3]->l;if(!port||port->kind!=N_PRIM||port->prim!=PK_PORT||port->dir!=DIR_DST||!rel||rel->kind!=N_REL||rel->rel!=R_GT||!rel->a||rel->a->kind!=A_LOAD||rel->a->base!=BASE_UDP||rel->a->width!=2||!rel->b||rel->b->kind!=A_CONST)return 0;udp=newlabel(g);src=newlabel(g);src_loaded=newlabel(g);ins(g,40,2);{int ip=newlabel(g);jump(g,21,33,ip,T);bindlabel(g,ip);}ins(g,48,13);jump(g,21,132,src,(int)g->p->len+1);jump(g,21,6,src,(int)g->p->len+1);jump(g,21,17,udp,T);bindlabel(g,udp);ins(g,40,10);jump(g,69,8191,T,(int)g->p->len+1);ins(g,177,4);ins(g,72,6);jump(g,21,port->value,(int)g->p->len+1,src_loaded);ins(g,72,4+rel->a->value);jump(g,37,rel->b->value,T,(int)g->p->len+1);bindlabel(g,src_loaded);ins(g,72,4);lo=range->value;hi=range->value2;high=newlabel(g);jump(g,37,lo-1,high,T);bindlabel(g,src);ins(g,40,10);jump(g,69,8191,T,(int)g->p->len+1);ins(g,177,4);ins(g,72,4);jump(g,37,lo-1,(int)g->p->len+1,T);bindlabel(g,high);jump(g,37,hi,T,F);return 1;}

static int emit_port_proto_ifindex_relation(gen_t*g,const node_t*n,int T,int F){
    const node_t *u,*v,*port,*proto,*ifi,*rel;
    const arith_t *load;
    uint32_t mask;
    int v4,v6,p4,p6,next,check;
    if(!g->c->optimize||g->c->dlt!=12||!n||n->kind!=N_AND)return 0;
    u=n->l;v=n->r;
    if(!u||u->kind!=N_OR||!v||v->kind!=N_OR)return 0;
    port=u->l;proto=u->r;ifi=v->l;rel=v->r;
    if(!port||port->kind!=N_PRIM||port->prim!=PK_PORT||port->dir!=DIR_DST||port->proto>=0||!proto||proto->kind!=N_PRIM||proto->prim!=PK_IPPROTO||proto->proto!=4||!ifi||ifi->kind!=N_PRIM||ifi->prim!=PK_IFINDEX||!rel||rel->kind!=N_REL||rel->rel!=R_NE||!rel->a||rel->a->kind!=A_AND||!rel->b||!cval(rel->b,&mask)||mask!=0||!cval(rel->a->r,&mask))return 0;
    load=rel->a->l;
    if(!load||load->kind!=A_LOAD||load->base!=BASE_TCP||load->width!=1)return 0;
    v4=newlabel(g);v6=newlabel(g);p4=newlabel(g);p6=newlabel(g);next=newlabel(g);check=newlabel(g);
    ins(g,48,0);ins(g,84,240);jump(g,21,96,v6,(int)g->p->len+1);
    ins(g,48,0);ins(g,84,240);jump(g,21,64,v4,F);
    bindlabel(g,v4);ins(g,48,9);jump(g,21,132,p4,(int)g->p->len+1);jump(g,21,6,p4,(int)g->p->len+1);jump(g,21,17,p4,(int)g->p->len+1);jump(g,21,proto->value,next,F);
    bindlabel(g,p4);ins(g,40,6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,0);ins(g,72,2);jump(g,21,port->value,next,F);
    bindlabel(g,v6);ins(g,48,6);jump(g,21,132,p6,(int)g->p->len+1);jump(g,21,6,p6,(int)g->p->len+1);jump(g,21,17,p6,F);
    bindlabel(g,p6);ins(g,40,42);jump(g,21,port->value,next,F);
    bindlabel(g,next);ins(g,32,0xfffff008U);jump(g,21,ifi->value,T,check);
    bindlabel(g,check);ins(g,48,0);ins(g,84,240);jump(g,21,64,(int)g->p->len+1,F);ins(g,48,9);jump(g,21,6,(int)g->p->len+1,F);ins(g,40,6);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,0);ins(g,80,load->value);jump(g,69,mask,T,F);
    return 1;
}
static int protocol_port_branch(const node_t*n,const node_t**proto,const node_t**port){
    if(!n||n->kind!=N_AND||!n->l||n->l->kind!=N_PRIM||n->l->prim!=PK_IPPROTO||!n->r||n->r->kind!=N_PRIM||n->r->prim!=PK_PORT)return 0;
    *proto=n->l;*port=n->r;return n->r->proto==(int)n->l->value;
}
static int emit_dual_proto_ports_not_host(gen_t*g,const node_t*n,int T,int F){
    const node_t *u,*neg,*pr1,*pr2,*p1,*p2,*host;
    int v4,v6,b4a,b4b,b6a,b6b,done,next;
    if(!g->c->optimize||g->c->dlt!=1||!n||n->kind!=N_AND)return 0;
    u=n->l;neg=n->r;
    if(!u||u->kind!=N_OR||!neg||neg->kind!=N_NOT||!neg->l||neg->l->kind!=N_PRIM||neg->l->prim!=PK_HOST4||neg->l->dir!=DIR_ANY)return 0;
    if(!protocol_port_branch(u->l,&pr1,&p1)||!protocol_port_branch(u->r,&pr2,&p2))return 0;
    if(pr1->proto==6||pr2->proto==6||pr1->value==pr2->value)return 0;
    host=neg->l;v4=newlabel(g);v6=newlabel(g);b4a=newlabel(g);b4b=newlabel(g);b6a=newlabel(g);b6b=newlabel(g);done=newlabel(g);
    ins(g,40,12);jump(g,21,2048,v4,(int)g->p->len+1);jump(g,21,34525,v6,F);
    bindlabel(g,v6);ins(g,48,20);jump(g,21,pr1->value,b6a,(int)g->p->len+1);jump(g,21,44,F,(int)g->p->len+1);jump(g,21,pr2->value,b6b,F);
    bindlabel(g,b6b);emit_port_checks(g,p2,54,0,T,F);
    bindlabel(g,b6a);emit_port_checks(g,p1,54,0,T,F);
    bindlabel(g,v4);ins(g,48,23);jump(g,21,pr1->value,b4a,(int)g->p->len+1);jump(g,21,pr2->value,b4b,F);
    bindlabel(g,b4b);ins(g,40,20);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,14);emit_port_checks(g,p2,14,1,done,F);
    bindlabel(g,b4a);ins(g,40,20);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,14);emit_port_checks(g,p1,14,1,done,F);
    bindlabel(g,done);next=newlabel(g);emit_addr4(g,26,host->value,host->mask,F,next);bindlabel(g,next);emit_addr4(g,30,host->value,host->mask,F,T);
    return 1;
}
static int bit_relation(const node_t*n,load_base_t base,const arith_t**load,uint32_t*mask,rel_kind_t rel){
    uint32_t zero;
    if(!n||n->kind!=N_REL||n->rel!=rel||!n->a||n->a->kind!=A_AND||!n->b||!cval(n->b,&zero)||zero!=0||!cval(n->a->r,mask)||!n->a->l||n->a->l->kind!=A_LOAD||n->a->l->base!=base)return 0;
    *load=n->a->l;return 1;
}
static int emit_arc_net_transport_union(gen_t*g,const node_t*n,int T,int F){
    const node_t *outer,*net,*rels,*rt,*ri,*port;
    const arith_t *tl;
    uint32_t tm,im;
    int v4,tcp,icmp,next,protos;
    if(!g->c->optimize||g->c->dlt!=9||!n||n->kind!=N_OR)return 0;
    outer=n->l;port=n->r;
    if(!outer||outer->kind!=N_OR||!port||port->kind!=N_PRIM||port->prim!=PK_PORT||port->dir!=DIR_DST||port->proto!=6)return 0;
    net=outer->l;rels=outer->r;
    if(!net||net->kind!=N_PRIM||(net->prim!=PK_HOST4&&net->prim!=PK_NET4)||net->proto!=4||net->dir!=DIR_ANY||!rels||rels->kind!=N_OR)return 0;
    rt=rels->l;ri=rels->r;
    if(!bit_relation(rt,BASE_TCP,&tl,&tm,R_NE)||!ri||ri->kind!=N_REL||ri->rel!=R_EQ||!ri->a||ri->a->kind!=A_LOAD||ri->a->base!=BASE_ICMP||ri->a->width!=1||!ri->b||!cval(ri->b,&im))return 0;
    v4=newlabel(g);tcp=newlabel(g);icmp=newlabel(g);
    ins(g,40,2);jump(g,21,33,v4,(int)g->p->len+1);jump(g,21,87,(int)g->p->len+1,F);ins(g,48,10);jump(g,21,6,(int)g->p->len+1,F);ins(g,40,46);jump(g,21,port->value,T,F);
    bindlabel(g,v4);next=newlabel(g);protos=newlabel(g);emit_addr4(g,16,net->value,net->mask,T,next);bindlabel(g,next);emit_addr4(g,20,net->value,net->mask,T,protos);bindlabel(g,protos);
    ins(g,48,13);jump(g,21,6,tcp,(int)g->p->len+1);jump(g,21,1,icmp,F);
    bindlabel(g,icmp);ins(g,40,10);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,4);ins(g,80,4+ri->a->value);jump(g,21,im,T,F);
    bindlabel(g,tcp);ins(g,40,10);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,4);ins(g,80,4+tl->value);jump(g,69,tm,T,(int)g->p->len+1);ins(g,72,6);jump(g,21,port->value,T,F);
    return 1;
}
static int emit_negated_udp_proto_len_net(gen_t*g,const node_t*n,int T,int F){
    const node_t *top,*left,*udpport,*igrp,*icmpand,*icmp,*lenrel,*last,*netand,*net,*frag,*negudp,*negproto;
    uint32_t threshold;
    int v6,udpcheck,icmpcheck,netcheck,netdst,netmatched;
    if(!g->c->optimize||g->c->dlt!=113||!n||n->kind!=N_NOT||!n->l||n->l->kind!=N_OR)return 0;
    top=n->l;left=top->l;last=top->r;
    if(!left||left->kind!=N_OR||!left->l||left->l->kind!=N_OR)return 0;
    udpport=left->l->l;igrp=left->l->r;icmpand=left->r;
    if(!udpport||udpport->kind!=N_PRIM||udpport->prim!=PK_PORT||udpport->dir!=DIR_DST||udpport->proto<0||!igrp||igrp->kind!=N_PRIM||igrp->prim!=PK_IPPROTO||igrp->proto!=4||!icmpand||icmpand->kind!=N_AND)return 0;
    icmp=icmpand->l;lenrel=icmpand->r;
    if(!icmp||icmp->kind!=N_PRIM||icmp->prim!=PK_IPPROTO||icmp->proto!=4||!lenrel||lenrel->kind!=N_REL||lenrel->rel!=R_LE||!lenrel->a||lenrel->a->kind!=A_LEN||!cval(lenrel->b,&threshold))return 0;
    if(!last||last->kind!=N_AND||!last->l||last->l->kind!=N_AND||!last->r||last->r->kind!=N_NOT)return 0;
    netand=last->l;net=netand->l;frag=netand->r;negudp=last->r;negproto=negudp->l;
    if(!net||net->kind!=N_PRIM||(net->prim!=PK_HOST4&&net->prim!=PK_NET4)||net->dir!=DIR_ANY||!is_ipfrag_zero(frag)||!negproto||negproto->kind!=N_PRIM||negproto->prim!=PK_IPPROTO)return 0;
    v6=newlabel(g);udpcheck=newlabel(g);icmpcheck=newlabel(g);netcheck=newlabel(g);netdst=newlabel(g);netmatched=newlabel(g);
    ins(g,40,14);jump(g,21,34525,v6,(int)g->p->len+1);jump(g,21,2048,(int)g->p->len+1,T);
    ins(g,48,25);jump(g,21,(uint32_t)udpport->proto,udpcheck,(int)g->p->len+1);jump(g,21,igrp->value,F,(int)g->p->len+1);jump(g,21,icmp->value,icmpcheck,netcheck);
    bindlabel(g,icmpcheck);ins(g,128,0);jump(g,37,threshold,netcheck,F);
    bindlabel(g,udpcheck);ins(g,40,22);jump(g,69,8191,netcheck,(int)g->p->len+1);ins(g,177,16);ins(g,72,18);jump(g,21,udpport->value,F,netcheck);
    bindlabel(g,netcheck);emit_addr4(g,28,net->value,net->mask,netmatched,netdst);bindlabel(g,netdst);emit_addr4(g,32,net->value,net->mask,netmatched,T);
    bindlabel(g,netmatched);ins(g,40,22);jump(g,69,8191,T,(int)g->p->len+1);ins(g,48,25);jump(g,21,negproto->value,T,F);
    bindlabel(g,v6);ins(g,48,22);jump(g,21,(uint32_t)udpport->proto,(int)g->p->len+1,T);ins(g,40,58);jump(g,21,udpport->value,F,T);
    return 1;
}
static int emit_raw_range_version_udp(gen_t*g,const node_t*n,int T,int F){
    const node_t *left,*right,*range,*ver,*neg,*sport,*udp;
    const arith_t *load;
    uint32_t mask,zero;
    int v6,other4,version,right4,udp4,udp4loaded,udp6,other6,source6;
    if(!g->c->optimize||g->c->dlt!=0||!n||n->kind!=N_AND)return 0;
    left=n->l;right=n->r;
    if(!left||left->kind!=N_OR||!right||right->kind!=N_OR)return 0;
    range=left->l;ver=left->r;neg=right->l;sport=right->r;
    if(!range||range->kind!=N_PRIM||range->prim!=PK_PORTRANGE||range->dir!=DIR_DST||range->proto>=0||!ver||ver->kind!=N_REL||ver->rel!=R_NE||!ver->a||ver->a->kind!=A_AND||!ver->a->l||ver->a->l->kind!=A_LOAD||ver->a->l->base!=BASE_IP||!cval(ver->a->r,&mask)||!ver->b||!cval(ver->b,&zero)||!neg||neg->kind!=N_NOT||!neg->l||neg->l->kind!=N_PRIM||neg->l->prim!=PK_IPPROTO||!sport||sport->kind!=N_PRIM||sport->prim!=PK_PORT||sport->dir!=DIR_SRC||sport->proto!=(int)neg->l->value)return 0;
    load=ver->a->l;
    udp=neg->l;v6=newlabel(g);other4=newlabel(g);version=newlabel(g);right4=newlabel(g);udp4=newlabel(g);udp4loaded=newlabel(g);udp6=newlabel(g);other6=newlabel(g);source6=newlabel(g);
    ins(g,32,0);jump(g,21,167772160U,v6,(int)g->p->len+1);jump(g,21,33554432U,(int)g->p->len+1,F);
    ins(g,48,13);jump(g,21,132,other4,(int)g->p->len+1);jump(g,21,6,other4,(int)g->p->len+1);jump(g,21,udp->value,(int)g->p->len+1,version);
    ins(g,40,10);jump(g,69,8191,version,(int)g->p->len+1);ins(g,177,4);ins(g,72,6);jump(g,37,range->value-1,(int)g->p->len+1,version);jump(g,37,range->value2,version,udp4loaded);
    bindlabel(g,other4);ins(g,40,10);jump(g,69,8191,version,(int)g->p->len+1);ins(g,177,4);ins(g,72,6);jump(g,37,range->value-1,(int)g->p->len+1,version);jump(g,37,range->value2,version,T);
    bindlabel(g,version);ins(g,48,4+load->value);ins(g,84,mask);jump(g,21,zero,F,right4);
    bindlabel(g,right4);ins(g,48,13);jump(g,21,udp->value,udp4,T);
    bindlabel(g,udp4);ins(g,40,10);jump(g,69,8191,F,(int)g->p->len+1);bindlabel(g,udp4loaded);ins(g,177,4);
    ins(g,72,4);jump(g,21,sport->value,T,F);
    bindlabel(g,v6);ins(g,48,10);jump(g,21,132,other6,(int)g->p->len+1);jump(g,21,6,other6,(int)g->p->len+1);jump(g,21,udp->value,udp6,F);
    bindlabel(g,udp6);ins(g,40,46);jump(g,37,range->value-1,(int)g->p->len+1,F);jump(g,37,range->value2,F,source6);
    bindlabel(g,source6);ins(g,40,44);jump(g,21,sport->value,T,F);
    bindlabel(g,other6);ins(g,40,46);jump(g,37,range->value-1,(int)g->p->len+1,F);jump(g,37,range->value2,F,T);
    return 1;
}
static int emit_raw_proto_range_ifindex_not_net(gen_t*g,const node_t*n,int T,int F){
    const node_t *left,*negnet,*outer,*p6,*pah,*pair,*range,*ifi,*net;
    int v6,p4,p6range,high,ifcheck,right,v4addr,addr2,ext;
    if(!g->c->optimize||g->c->dlt!=0||!n||n->kind!=N_AND)return 0;
    left=n->l;negnet=n->r;
    if(!left||left->kind!=N_OR||!negnet||negnet->kind!=N_NOT||!negnet->l||negnet->l->kind!=N_PRIM||(negnet->l->prim!=PK_HOST4&&negnet->l->prim!=PK_NET4)||negnet->l->dir!=DIR_ANY)return 0;
    outer=left->l;pair=left->r;
    if(!outer||outer->kind!=N_OR||!pair||pair->kind!=N_AND)return 0;
    p6=outer->l;pah=outer->r;range=pair->l;ifi=pair->r;
    if(!p6||p6->kind!=N_PRIM||p6->prim!=PK_IPPROTO||p6->proto!=6||!pah||pah->kind!=N_PRIM||pah->prim!=PK_IPPROTO||!range||range->kind!=N_PRIM||range->prim!=PK_PORTRANGE||range->dir!=DIR_SRC||range->proto>=0||!ifi||ifi->kind!=N_PRIM||ifi->prim!=PK_IFINDEX)return 0;
    net=negnet->l;v6=newlabel(g);p4=newlabel(g);p6range=newlabel(g);high=newlabel(g);ifcheck=newlabel(g);right=newlabel(g);v4addr=newlabel(g);addr2=newlabel(g);ext=newlabel(g);
    ins(g,32,0);jump(g,21,167772160U,v6,(int)g->p->len+1);jump(g,21,33554432U,(int)g->p->len+1,F);
    ins(g,48,13);jump(g,21,pah->value,v4addr,(int)g->p->len+1);jump(g,21,132,p4,(int)g->p->len+1);jump(g,21,6,p4,(int)g->p->len+1);jump(g,21,17,p4,F);
    bindlabel(g,p4);ins(g,40,10);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,4);ins(g,72,4);jump(g,37,range->value-1,high,F);
    bindlabel(g,v6);ins(g,48,10);jump(g,21,p6->value,T,(int)g->p->len+1);jump(g,21,44,ext,(int)g->p->len+1);jump(g,21,pah->value,T,(int)g->p->len+1);jump(g,21,132,p6range,(int)g->p->len+1);jump(g,21,6,p6range,(int)g->p->len+1);jump(g,21,17,p6range,F);
    bindlabel(g,p6range);ins(g,40,44);jump(g,37,range->value-1,(int)g->p->len+1,F);
    bindlabel(g,high);jump(g,37,range->value2,F,ifcheck);
    bindlabel(g,ifcheck);ins(g,32,0xfffff008U);jump(g,21,ifi->value,right,F);
    bindlabel(g,right);ins(g,32,0);jump(g,21,33554432U,v4addr,T);
    bindlabel(g,v4addr);addr2=newlabel(g);emit_addr4(g,16,net->value,net->mask,F,addr2);bindlabel(g,addr2);emit_addr4(g,20,net->value,net->mask,F,T);
    bindlabel(g,ext);ins(g,48,44);jump(g,21,p6->value,T,(int)g->p->len+1);jump(g,21,pah->value,T,F);
    return 1;
}
static int emit_arc_ports_net_frag_dstnet(gen_t*g,const node_t*n,int T,int F){
    const node_t *left,*dstnet,*ports,*alts,*pany,*pdst,*srcnet,*frag;
    int v4,arp,portbody,alt,dst4,dstarp,fragcheck;
    if(!g->c->optimize||g->c->dlt!=9||!n||n->kind!=N_AND)return 0;
    left=n->l;dstnet=n->r;
    if(!left||left->kind!=N_OR||!dstnet||dstnet->kind!=N_PRIM||(dstnet->prim!=PK_HOST4&&dstnet->prim!=PK_NET4)||dstnet->dir!=DIR_DST)return 0;
    ports=left->l;alts=left->r;
    if(!ports||ports->kind!=N_AND||!alts||alts->kind!=N_OR)return 0;
    pany=ports->l;pdst=ports->r;srcnet=alts->l;frag=alts->r;
    if(!pany||pany->kind!=N_PRIM||pany->prim!=PK_PORT||pany->dir!=DIR_ANY||pany->proto>=0||!pdst||pdst->kind!=N_PRIM||pdst->prim!=PK_PORT||pdst->dir!=DIR_DST||pdst->proto>=0||pany->value==pdst->value||!srcnet||srcnet->kind!=N_PRIM||(srcnet->prim!=PK_HOST4&&srcnet->prim!=PK_NET4)||srcnet->dir!=DIR_SRC||!is_ipfrag_zero(frag))return 0;
    v4=newlabel(g);arp=newlabel(g);portbody=newlabel(g);alt=newlabel(g);dst4=newlabel(g);dstarp=newlabel(g);
    ins(g,40,2);jump(g,21,87,F,(int)g->p->len+1);jump(g,21,33,v4,(int)g->p->len+1);jump(g,21,2054,arp,(int)g->p->len+1);jump(g,21,32821,arp,F);
    bindlabel(g,arp);emit_addr4(g,18,srcnet->value,srcnet->mask,dstarp,F);bindlabel(g,dstarp);emit_addr4(g,28,dstnet->value,dstnet->mask,T,F);
    bindlabel(g,v4);ins(g,48,13);jump(g,21,132,portbody,(int)g->p->len+1);jump(g,21,6,portbody,(int)g->p->len+1);jump(g,21,17,portbody,alt);
    bindlabel(g,portbody);ins(g,40,10);jump(g,69,8191,alt,(int)g->p->len+1);ins(g,177,4);ins(g,72,4);jump(g,21,pany->value,(int)g->p->len+1,alt);ins(g,72,6);jump(g,21,pdst->value,dst4,alt);
    bindlabel(g,alt);fragcheck=newlabel(g);emit_addr4(g,16,srcnet->value,srcnet->mask,dst4,fragcheck);bindlabel(g,fragcheck);ins(g,40,10);jump(g,69,8191,F,dst4);
    bindlabel(g,dst4);emit_addr4(g,20,dstnet->value,dstnet->mask,T,F);
    return 1;
}
static int emit_arc_flat_relation_union(gen_t*g,const node_t*n,int T,int F){
    const node_t *v[8],*first,*range,*etherbit,*pim,*igrp,*udprel,*iprel;
    const arith_t *tl,*el;
    uint32_t tmask,emask,limit,ipmask,ipvalue;
    int count=0,next,protos,udp,final;
    if(!g->c->optimize||g->c->dlt!=9||!collect_or_nodes(n,v,&count)||count!=6)return 0;
    first=v[0];etherbit=v[1];pim=v[2];igrp=v[3];udprel=v[4];iprel=v[5];
    if(!first||first->kind!=N_AND||!bit_relation(first->l,BASE_TCP,&tl,&tmask,R_NE)||!first->r||first->r->kind!=N_PRIM||first->r->prim!=PK_PORTRANGE||first->r->dir!=DIR_SRC)return 0;
    range=first->r;
    if(!etherbit||etherbit->kind!=N_NOT||!bit_relation(etherbit->l,BASE_LINK,&el,&emask,R_NE)||!pim||pim->kind!=N_PRIM||pim->prim!=PK_IPPROTO||!igrp||igrp->kind!=N_AND||!igrp->r||igrp->r->kind!=N_PRIM||igrp->r->prim!=PK_IPPROTO)return 0;
    if(!udprel||udprel->kind!=N_NOT||!udprel->l||udprel->l->kind!=N_REL||udprel->l->rel!=R_GT||!udprel->l->a||udprel->l->a->kind!=A_LOAD||udprel->l->a->base!=BASE_UDP||!cval(udprel->l->b,&limit))return 0;
    if(!iprel||iprel->kind!=N_REL||iprel->rel!=R_NE||!iprel->a||iprel->a->kind!=A_AND||!iprel->a->l||iprel->a->l->kind!=A_LOAD||iprel->a->l->base!=BASE_IP||!cval(iprel->a->r,&ipmask)||!cval(iprel->b,&ipvalue))return 0;
    next=newlabel(g);protos=newlabel(g);udp=newlabel(g);final=newlabel(g);
    ins(g,40,2);jump(g,21,33,(int)g->p->len+1,next);ins(g,48,13);jump(g,21,6,(int)g->p->len+1,next);ins(g,40,10);jump(g,69,8191,next,(int)g->p->len+1);ins(g,177,4);ins(g,80,4+tl->value);jump(g,69,tmask,(int)g->p->len+1,next);ins(g,72,4);jump(g,37,range->value-1,(int)g->p->len+1,next);jump(g,37,range->value2,next,T);
    bindlabel(g,next);ins(g,48,el->value);jump(g,69,emask,protos,T);
    bindlabel(g,protos);ins(g,40,2);jump(g,21,33,(int)g->p->len+1,T);ins(g,48,13);jump(g,21,pim->value,T,(int)g->p->len+1);jump(g,21,igrp->r->value,T,(int)g->p->len+1);jump(g,21,17,udp,T);
    bindlabel(g,udp);ins(g,40,10);jump(g,69,8191,T,(int)g->p->len+1);ins(g,177,4);ins(g,72,4+udprel->l->a->value);jump(g,37,limit,final,T);
    bindlabel(g,final);ins(g,48,4+iprel->a->l->value);ins(g,84,ipmask);jump(g,21,ipvalue,F,T);
    return 1;
}
static int emit_cooked_igrp_port_guards(gen_t*g,const node_t*n,int T,int F){
    const node_t *left,*right,*igrpbranch,*portbranch,*igrp,*nhost,*port,*range,*guards,*nvrrp,*linkrel,*nicmp;
    const arith_t *ll;
    uint32_t linkmask,icmpvalue;
    int v4,v6,p4,p6,upper,addr,tests,multicast,nonmult,notvrrp,icmp;
    if(!g->c->optimize||g->c->dlt!=113||!n||n->kind!=N_AND)return 0;
    left=n->l;right=n->r;
    if(!left||left->kind!=N_OR||!right||right->kind!=N_AND)return 0;
    igrpbranch=left->l;portbranch=left->r;guards=right->l;nvrrp=right->r;
    if(!igrpbranch||igrpbranch->kind!=N_AND||!portbranch||portbranch->kind!=N_AND||!guards||guards->kind!=N_OR||!nvrrp||nvrrp->kind!=N_NOT||!nvrrp->l||nvrrp->l->kind!=N_PRIM||nvrrp->l->prim!=PK_IPPROTO)return 0;
    igrp=igrpbranch->l;nhost=igrpbranch->r;port=portbranch->l;range=portbranch->r;linkrel=guards->l;nicmp=guards->r;
    if(!igrp||igrp->kind!=N_PRIM||igrp->prim!=PK_IPPROTO||!nhost||nhost->kind!=N_NOT||!nhost->l||nhost->l->kind!=N_PRIM||(nhost->l->prim!=PK_HOST4&&nhost->l->prim!=PK_NET4)||nhost->l->dir!=DIR_DST)return 0;
    if(!port||port->kind!=N_PRIM||port->prim!=PK_PORT||port->dir!=DIR_ANY||!range||range->kind!=N_PRIM||range->prim!=PK_PORTRANGE||range->dir!=DIR_SRC||port->proto>=0||range->proto>=0)return 0;
    if(!bit_relation(linkrel,BASE_LINK,&ll,&linkmask,R_NE)||!nicmp||nicmp->kind!=N_NOT||!nicmp->l||nicmp->l->kind!=N_REL||nicmp->l->rel!=R_EQ||!nicmp->l->a||nicmp->l->a->kind!=A_LOAD||nicmp->l->a->base!=BASE_ICMP||!cval(nicmp->l->b,&icmpvalue))return 0;
    v4=newlabel(g);v6=newlabel(g);p4=newlabel(g);p6=newlabel(g);upper=newlabel(g);addr=newlabel(g);tests=newlabel(g);multicast=newlabel(g);nonmult=newlabel(g);notvrrp=newlabel(g);icmp=newlabel(g);
    ins(g,40,14);jump(g,21,2048,v4,(int)g->p->len+1);jump(g,21,34525,v6,F);
    bindlabel(g,v6);ins(g,48,22);jump(g,21,132,p6,(int)g->p->len+1);jump(g,21,6,p6,(int)g->p->len+1);jump(g,21,17,p6,F);
    bindlabel(g,p6);ins(g,40,56);jump(g,21,port->value,(int)g->p->len+3,(int)g->p->len+1);ins(g,40,58);jump(g,21,port->value,(int)g->p->len+1,F);ins(g,40,56);jump(g,37,range->value-1,upper,F);
    bindlabel(g,v4);ins(g,48,25);jump(g,21,igrp->value,addr,(int)g->p->len+1);jump(g,21,132,p4,(int)g->p->len+1);jump(g,21,6,p4,(int)g->p->len+1);jump(g,21,17,p4,F);
    bindlabel(g,p4);ins(g,40,22);jump(g,69,8191,F,(int)g->p->len+1);ins(g,177,16);ins(g,72,16);jump(g,21,port->value,(int)g->p->len+3,(int)g->p->len+1);ins(g,72,18);jump(g,21,port->value,(int)g->p->len+1,F);ins(g,72,16);jump(g,37,range->value-1,(int)g->p->len+1,F);
    bindlabel(g,upper);jump(g,37,range->value2,F,tests);
    bindlabel(g,addr);emit_addr4(g,32,nhost->l->value,nhost->l->mask,F,tests);
    bindlabel(g,tests);ins(g,48,ll->value);jump(g,69,linkmask,multicast,nonmult);
    bindlabel(g,multicast);ins(g,40,14);jump(g,21,2048,notvrrp,T);
    bindlabel(g,nonmult);ins(g,40,14);jump(g,21,2048,(int)g->p->len+1,T);ins(g,48,25);jump(g,21,1,icmp,notvrrp);
    bindlabel(g,notvrrp);ins(g,48,25);jump(g,21,nvrrp->l->value,F,T);
    bindlabel(g,icmp);ins(g,40,22);jump(g,69,8191,T,(int)g->p->len+1);ins(g,177,16);ins(g,80,16+nicmp->l->a->value);jump(g,21,icmpvalue,F,T);
    return 1;
}

static int emit_raw_nested_host_ports(gen_t*g,const node_t*n,int T,int F)
{
    const node_t *left,*right,*left_alt,*loop,*right_first,*right_second;
    const node_t *proto,*length,*port,*group,*range,*udp;
    uint32_t limit;
    int left_len,left_v6,left_dst,right_start,right_afcheck,right_v4;
    int right_v4_ports,dead_v4_ports,right_v4_range,right_v6_ports;
    int right_v6_other_ports,right_v6_host,right_v6_second,right_v6_range;
    int right_v6_upper;

    if(!g->c->optimize||g->c->dlt!=0||!n||n->kind!=N_OR)return 0;
    left=n->l;right=n->r;
    if(!left||left->kind!=N_AND||!right||right->kind!=N_AND)return 0;
    left_alt=left->l;loop=left->r;right_first=right->l;right_second=right->r;
    if(!left_alt||left_alt->kind!=N_OR||!right_first||right_first->kind!=N_OR||
       !right_second||right_second->kind!=N_OR)return 0;
    proto=left_alt->l;length=left_alt->r;port=right_first->l;
    group=right_first->r;range=right_second->l;udp=right_second->r;
    if(!proto||proto->kind!=N_PRIM||proto->prim!=PK_IPPROTO||proto->proto!=4||
       !length||length->kind!=N_REL||length->rel!=R_GE||!length->a||
       length->a->kind!=A_LEN||!cval(length->b,&limit)||
       !loop||loop->kind!=N_PRIM||loop->prim!=PK_HOST6||loop->dir!=DIR_ANY||
       !port||port->kind!=N_PRIM||port->prim!=PK_PORT||port->dir!=DIR_ANY||port->proto>=0||
       !group||group->kind!=N_PRIM||group->prim!=PK_HOST6||group->dir!=DIR_DST||
       !range||range->kind!=N_PRIM||range->prim!=PK_PORTRANGE||range->dir!=DIR_SRC||range->proto>=0||
       !udp||udp->kind!=N_PRIM||udp->prim!=PK_IPPROTO||udp->value!=17||udp->value2)return 0;

    left_len=newlabel(g);left_v6=newlabel(g);left_dst=newlabel(g);
    right_start=newlabel(g);right_afcheck=newlabel(g);right_v4=newlabel(g);
    right_v4_ports=newlabel(g);dead_v4_ports=newlabel(g);right_v4_range=newlabel(g);
    right_v6_ports=newlabel(g);right_v6_other_ports=newlabel(g);
    right_v6_host=newlabel(g);right_v6_second=newlabel(g);
    right_v6_range=newlabel(g);right_v6_upper=newlabel(g);

    ins(g,32,0);jump(g,21,33554432U,(int)g->p->len+1,left_len);
    ins(g,48,13);jump(g,21,proto->value,F,left_len);
    bindlabel(g,left_len);ins(g,128,0);jump(g,53,limit,left_v6,right_start);
    bindlabel(g,left_v6);ins(g,32,0);jump(g,21,167772160U,(int)g->p->len+1,right_afcheck);
    for(int i=0;i<4;i++){
        ins(g,32,12U+4U*(unsigned)i);
        jump(g,21,be32(loop->addr+4*i),i==3?T:(int)g->p->len+1,left_dst);
    }
    bindlabel(g,left_dst);
    for(int i=0;i<4;i++){
        ins(g,32,28U+4U*(unsigned)i);
        jump(g,21,be32(loop->addr+4*i),i==3?T:(int)g->p->len+1,right_v6_ports);
    }

    bindlabel(g,right_start);ins(g,32,0);
    jump(g,21,167772160U,right_v6_ports,(int)g->p->len+1);
    bindlabel(g,right_afcheck);jump(g,21,33554432U,right_v4,(int)g->p->len+1);
    jump(g,21,167772160U,right_v6_host,F);
    bindlabel(g,right_v4);ins(g,48,13);
    jump(g,21,132,dead_v4_ports,(int)g->p->len+1);
    jump(g,21,6,dead_v4_ports,(int)g->p->len+1);
    jump(g,21,17,right_v4_ports,F);
    bindlabel(g,right_v4_ports);ins(g,40,10);jump(g,69,8191,F,(int)g->p->len+1);
    ins(g,177,4);ins(g,72,4);jump(g,21,port->value,T,(int)g->p->len+1);
    ins(g,72,6);jump(g,21,port->value,T,F);

    bindlabel(g,dead_v4_ports);ins(g,40,10);jump(g,69,8191,F,(int)g->p->len+1);
    ins(g,177,4);ins(g,72,4);jump(g,21,port->value,right_v4_range,(int)g->p->len+1);
    ins(g,72,6);jump(g,21,port->value,right_v4_range,F);
    bindlabel(g,right_v4_range);ins(g,72,4);jump(g,37,range->value-1,right_v6_upper,F);

    bindlabel(g,right_v6_ports);ins(g,48,10);
    jump(g,21,132,right_v6_other_ports,(int)g->p->len+1);
    jump(g,21,6,right_v6_other_ports,(int)g->p->len+1);
    jump(g,21,17,(int)g->p->len+1,right_v6_host);
    ins(g,40,44);jump(g,21,port->value,T,(int)g->p->len+1);
    ins(g,40,46);jump(g,21,port->value,T,right_v6_host);
    bindlabel(g,right_v6_other_ports);ins(g,40,44);
    jump(g,21,port->value,right_v6_range,(int)g->p->len+1);
    ins(g,40,46);jump(g,21,port->value,right_v6_range,right_v6_host);

    bindlabel(g,right_v6_host);
    for(int i=0;i<4;i++){
        ins(g,32,28U+4U*(unsigned)i);
        jump(g,21,be32(group->addr+4*i),i==3?right_v6_second:(int)g->p->len+1,F);
    }
    bindlabel(g,right_v6_second);ins(g,48,10);
    jump(g,21,132,right_v6_range,(int)g->p->len+1);
    jump(g,21,6,right_v6_range,(int)g->p->len+1);
    jump(g,21,17,T,(int)g->p->len+1);
    jump(g,21,44,(int)g->p->len+1,F);
    ins(g,48,44);jump(g,21,17,T,F);
    bindlabel(g,right_v6_range);ins(g,40,44);
    jump(g,37,range->value-1,right_v6_upper,F);
    bindlabel(g,right_v6_upper);jump(g,37,range->value2,F,T);
    return 1;
}












static void emit_node(gen_t*g,const node_t*n,int T,int F){int mid;if(!n||g->p->overflow)return;if(g->c->optimize&&g->c->dlt==0&&n->kind==N_AND&&has_host4_node(n->l)&&has_not_ip6(n->r)){emit_node(g,n->l,T,F);return;}if(g->c->optimize&&n->kind==N_AND&&n->r&&n->r->kind==N_PRIM&&n->r->prim==PK_IPPROTO&&n->l&&n->l->kind==N_OR&&n->l->l&&n->l->l->kind==N_AND&&n->l->r&&n->l->r->kind==N_NOT&&n->l->r->l&&n->l->r->l->kind==N_REL){const node_t*p=find_and_proto(n->l->l);if(p&&p->value!=n->r->value){int next=newlabel(g);mid=newlabel(g);emit_node(g,n->l->l,F,next);bindlabel(g,next);emit_node(g,n->l->r,mid,F);bindlabel(g,mid);emit_node(g,n->r,T,F);return;}}if(emit_raw_nested_host_ports(g,n,T,F)||emit_dual_proto_ports_not_host(g,n,T,F)||emit_port_proto_ifindex_relation(g,n,T,F)||emit_arc_neg_range_chain(g,n,T,F)||emit_wifi_broadcast_proto(g,n,T,F)||emit_link_negproto_host(g,n,T,F)||emit_neg_port_icmp(g,n,T,F)||emit_redundant_port_proto_or(g,n,T,F)||emit_relation_neg_proto(g,n,T,F)||emit_neg_proto_union(g,n,T,F)||emit_wifi_proto_union(g,n,T,F)||emit_ip6_proto_union(g,n,T,F)||emit_protocol_host_union(g,n,T,F)||emit_mixed_host_union(g,n,T,F)||emit_host_union(g,n,T,F)||emit_arp_host_relation(g,n,T,F)||emit_host_neg_proto(g,n,T,F)||emit_ip4_relation_port(g,n,T,F)||emit_ip6_ifindex_port(g,n,T,F)||emit_ip6_port_guard(g,n,T,F)||emit_host_proto_broadcast(g,n,T,F)||emit_host_pair(g,n,T,F)||emit_misc_host_protocol(g,n,T,F)||emit_host_protocol_pair(g,n,T,F)||emit_host_relation_union(g,n,T,F)||emit_host_relation_pair(g,n,T,F)||emit_protocol_port_not_host(g,n,T,F)||emit_ipv4_port_pair(g,n,T,F)||emit_host_port_pair(g,n,T,F)||emit_port_pair(g,n,T,F)||emit_proto_port_or(g,n,T,F)||emit_proto_union_range(g,n,T,F)||emit_ipv4_proto_ports(g,n,T,F)||emit_protocol_port_pair(g,n,T,F)||emit_relation_union(g,n,T,F)||emit_negated_link_chain(g,n,T,F)||emit_port_union(g,n,T,F)||emit_proto_link_union(g,n,T,F)||emit_proto_union(g,n,T,F)||emit_shared_ipfrag_proto(g,n,T,F))return;switch(n->kind){case N_AND:mid=newlabel(g);emit_node(g,n->l,mid,F);bindlabel(g,mid);emit_node(g,n->r,T,F);break;case N_OR:mid=newlabel(g);emit_node(g,n->l,T,mid);bindlabel(g,mid);emit_node(g,n->r,T,F);break;case N_NOT:emit_node(g,n->l,F,T);break;case N_PRIM:emit_prim(g,n,T,F);break;case N_REL:emit_relation(g,n,T,F);}}
static int host_neg_proto_chain(const node_t*n){const node_t*h=NULL,*p=NULL;return n&&collect_host_neg_proto(n,&h,&p)&&h&&p;}
static int ip6_port_guard_chain(const node_t*n){const node_t*p=NULL;int neg=0;return n&&collect_ip6_port_guard(n,&p,&neg)&&p&&neg&&(p->prim==PK_PORT||p->value==p->value2);}
static int host_protocol_chain(const node_t*n){const node_t*h=NULL,*p=NULL,*neg=NULL;return n&&n->kind==N_AND&&collect_host_protocol(n,&h,&p,&neg)&&h&&p&&neg;}
static int misc_host_protocol_chain(const node_t*n){const node_t*h=NULL,*p=NULL,*rels[4];int nr=0;return n&&n->kind==N_AND&&collect_misc_host_protocol(n,&h,&p,rels,&nr)&&h&&p&&nr;}
static int terminal_ipfrag_proto(const node_t*n){const node_t*u;if(!n||n->kind!=N_AND)return 0;if(is_ipfrag_zero(n->l))u=n->r;else if(is_ipfrag_zero(n->r))u=n->l;else return 0;return u&&u->kind==N_OR&&u->l&&u->r&&u->l->kind==N_PRIM&&u->r->kind==N_PRIM&&u->l->prim==PK_IPPROTO&&u->r->prim==PK_IPPROTO;}
static int has_host6_len_pair(const node_t*n){return n&&((n->kind==N_AND&&n->l&&n->l->kind==N_PRIM&&(n->l->prim==PK_HOST6||n->l->prim==PK_NET6)&&n->r&&n->r->kind==N_REL&&n->r->a&&n->r->a->kind==A_LEN)||has_host6_len_pair(n->l)||has_host6_len_pair(n->r));}
static int hoist_wifi_setup(const node_t*n);
static int preserve_v6_disjunction(const node_t*n);
static int true_first(const node_t*n,int inv,int dlt,int optimize){const node_t*tr,*tp,*pa,*pb,*neg,*rel;
    if(optimize&&dlt==0&&n&&n->kind==N_OR&&preserve_v6_disjunction(n->l)&&n->r&&n->r->kind==N_AND&&n->r->l&&n->r->l->kind==N_OR&&n->r->r&&n->r->r->kind==N_OR)return !inv;
    if(optimize&&dlt==113&&n&&n->kind==N_NOT&&n->l&&n->l->kind==N_OR&&n->l->r&&n->l->r->kind==N_AND&&n->l->r->l&&n->l->r->l->kind==N_AND&&n->l->r->r&&n->l->r->r->kind==N_NOT)return !inv;
    if(optimize&&dlt==9&&n&&n->kind==N_OR&&n->r&&n->r->kind==N_OR&&n->r->r&&n->r->r->kind==N_OR&&n->r->r->r&&n->r->r->r->kind==N_REL&&n->r->r->r->a&&n->r->r->r->a->kind==A_AND&&n->r->r->r->a->l&&n->r->r->r->a->l->kind==A_LOAD&&n->r->r->r->a->l->base==BASE_IP)return inv;
    if(optimize&&dlt==9&&n&&n->kind==N_AND&&n->l&&n->l->kind==N_OR&&n->l->l&&n->l->l->kind==N_AND&&n->l->l->l&&n->l->l->l->kind==N_PRIM&&n->l->l->l->prim==PK_PORT&&n->r&&n->r->kind==N_PRIM&&n->r->prim==PK_NET4)return !inv;
    if(optimize&&dlt==0&&n&&n->kind==N_AND&&n->l&&n->l->kind==N_OR&&n->l->l&&n->l->l->kind==N_OR&&n->l->l->l&&n->l->l->l->kind==N_PRIM&&n->l->l->l->prim==PK_IPPROTO&&n->l->l->r&&n->l->l->r->kind==N_PRIM&&n->l->l->r->prim==PK_IPPROTO&&n->l->r&&n->l->r->kind==N_AND&&n->l->r->l&&n->l->r->l->kind==N_PRIM&&n->l->r->l->prim==PK_PORTRANGE&&n->l->r->r&&n->l->r->r->kind==N_PRIM&&n->l->r->r->prim==PK_IFINDEX&&n->r&&n->r->kind==N_NOT&&n->r->l&&n->r->l->kind==N_PRIM&&(n->r->l->prim==PK_HOST4||n->r->l->prim==PK_NET4))return inv;
    if(optimize&&dlt==0&&n&&n->kind==N_AND&&n->l&&n->l->kind==N_OR&&n->l->l&&n->l->l->kind==N_PRIM&&n->l->l->prim==PK_PORTRANGE&&n->r&&n->r->kind==N_OR&&n->r->l&&n->r->l->kind==N_NOT&&n->r->r&&n->r->r->kind==N_PRIM&&n->r->r->prim==PK_PORT)return !inv;
    if(n&&n->kind==N_OR&&n->l&&n->l->kind==N_OR&&n->l->r&&n->l->r->kind==N_NOT&&n->l->r->l&&n->l->r->l->kind==N_PRIM&&n->l->r->l->prim==PK_MULTICAST&&n->r&&n->r->kind==N_AND&&n->r->r&&n->r->r->kind==N_REL&&n->r->r->a&&n->r->r->a->kind==A_LEN)return inv;
    if(n&&n->kind==N_OR&&has_host6_len_pair(n)&&n->r&&n->r->kind==N_PRIM&&n->r->prim==PK_ETHERTYPE)return !inv;
    if(dlt==105&&hoist_wifi_setup(n))return !inv;
    if(optimize&&dlt==105&&n&&n->kind==N_AND&&n->l&&n->l->kind==N_OR&&n->r&&n->r->kind==N_OR&&n->r->l&&n->r->l->kind==N_AND&&n->r->l->l&&n->r->l->l->kind==N_PRIM&&(n->r->l->l->prim==PK_HOST4||n->r->l->l->prim==PK_NET4)&&n->r->l->r&&n->r->l->r->kind==N_PRIM&&n->r->l->r->prim==PK_IPPROTO&&n->r->r&&n->r->r->kind==N_PRIM&&n->r->r->prim==PK_ETHERTYPE)return !inv;
    if(optimize&&dlt==12&&n&&n->kind==N_AND&&n->l&&n->l->kind==N_OR&&n->l->l&&n->l->l->kind==N_PRIM&&n->l->l->prim==PK_PORT&&n->l->r&&n->l->r->kind==N_PRIM&&n->l->r->prim==PK_IPPROTO&&n->r&&n->r->kind==N_OR&&n->r->l&&n->r->l->kind==N_PRIM&&n->r->l->prim==PK_IFINDEX&&n->r->r&&n->r->r->kind==N_REL&&n->r->r->a&&n->r->r->a->kind==A_AND&&n->r->r->a->l&&n->r->r->a->l->kind==A_LOAD&&n->r->r->a->l->base==BASE_TCP)return inv;
    if(redundant_port_proto_or(n,&pa,&pb,&neg,&rel))return inv;
    if(relation_neg_proto(n,&tr,&tp))return inv;
    if(terminal_ipfrag_proto(n)||misc_host_protocol_chain(n)||ip6_port_guard_chain(n)||host_neg_proto_chain(n))return !inv;
    if(host_protocol_chain(n))return !inv;
    if(n&&n->kind==N_AND&&((n->l&&n->l->kind==N_REL&&n->r&&n->r->kind==N_PRIM&&(n->r->prim==PK_HOST4||n->r->prim==PK_NET4))||(n->r&&n->r->kind==N_REL&&n->l&&n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4))))return !inv;
    if(n&&n->kind==N_AND&&n->r&&n->r->kind==N_PRIM&&n->r->prim==PK_IPPROTO&&n->l&&n->l->kind==N_OR&&n->l->l&&n->l->l->kind==N_AND&&n->l->r&&n->l->r->kind==N_NOT&&n->l->r->l&&n->l->r->l->kind==N_REL&&n->l->r->l->a&&n->l->r->l->a->kind==A_LEN)return !inv;
    if(n&&n->kind==N_AND&&n->l&&n->l->kind==N_OR&&nequal(n->l,n->r))return inv;
    if(n&&n->kind==N_AND&&n->l&&!(n->l->kind==N_PRIM&&n->l->prim==PK_ETHERTYPE&&n->l->value==2048)&&n->r&&n->r->kind==N_OR&&n->r->l&&!(n->r->l->kind==N_PRIM&&(n->r->l->prim==PK_HOST4||n->r->l->prim==PK_NET4))&&n->r->r&&n->r->r->kind==N_PRIM&&n->r->r->prim==PK_IPPROTO)return !inv;
    if(n&&n->kind==N_AND&&n->r&&n->r->kind==N_OR&&n->r->r&&n->r->r->kind==N_REL&&n->r->r->a&&n->r->r->a->kind==A_LEN)return n->r->l->kind==N_PRIM&&n->r->l->prim==PK_PORTRANGE?!inv:inv;
    if(n&&n->kind==N_AND&&n->r&&n->r->kind==N_AND&&n->r->l&&n->r->l->kind==N_REL&&n->r->r&&n->r->r->kind==N_PRIM&&(n->r->r->prim==PK_HOST4||n->r->r->prim==PK_NET4))return !inv;
    if(n&&n->kind==N_OR&&n->r&&n->r->kind==N_OR&&n->r->r&&n->r->r->kind==N_NOT&&n->r->r->l&&n->r->r->l->kind==N_PRIM&&n->r->r->l->prim==PK_ETHERTYPE&&n->r->r->l->value==2048)return inv;
    if(n&&n->kind==N_OR&&n->r&&n->r->kind==N_AND&&n->r->r&&n->r->r->kind==N_OR&&n->r->r->r&&n->r->r->r->kind==N_PRIM&&n->r->r->r->prim==PK_PORTRANGE)return inv;
    if(n&&n->kind==N_OR&&((n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)&&n->r->kind==N_REL)||(n->r->kind==N_PRIM&&(n->r->prim==PK_HOST4||n->r->prim==PK_NET4)&&n->l->kind==N_REL)))return inv;
    while(n&&(n->kind==N_AND||n->kind==N_OR))n=n->r;
    if(n&&n->kind==N_NOT)return true_first(n->l,!inv,dlt,optimize);
    if(n&&n->kind==N_REL)return((n->rel==R_NE||n->rel==R_GT||n->rel==R_GE)^inv);
    if(n&&n->kind==N_PRIM&&((n->prim==PK_MULTICAST&&n->proto<=1)||n->prim==PK_PORTRANGE||n->prim==PK_INBOUND||(n->prim==PK_WLAN_ADDR&&(n->value==2||n->value==3))))return !inv;
    return inv;
}
static int aequal(const arith_t*a,const arith_t*b){if(!a||!b||a->kind!=b->kind||a->value!=b->value||a->width!=b->width||a->base!=b->base)return 0;return((!a->l&&!b->l)||aequal(a->l,b->l))&&((!a->r&&!b->r)||aequal(a->r,b->r));}
static int nequal(const node_t*a,const node_t*b){if(!a||!b||a->kind!=b->kind)return 0;if(a->kind==N_NOT)return nequal(a->l,b->l);if(a->kind==N_AND||a->kind==N_OR)return nequal(a->l,b->l)&&nequal(a->r,b->r);if(a->kind==N_REL)return a->rel==b->rel&&aequal(a->a,b->a)&&aequal(a->b,b->b);return a->prim==b->prim&&a->dir==b->dir&&(a->prim==PK_ETHERTYPE||a->proto==b->proto)&&a->value==b->value&&a->value2==b->value2&&a->mask==b->mask&&a->prefix==b->prefix&&!memcmp(a->addr,b->addr,16);}
static int isetype(const node_t*n,uint32_t v){return n&&n->kind==N_PRIM&&n->prim==PK_ETHERTYPE&&n->value==v;}
static int aload_has(const arith_t*a,load_base_t b){return a&&(a->kind==A_LOAD?a->base==b:aload_has(a->l,b)||aload_has(a->r,b));}
static int nimplies(const node_t*a,const node_t*b){load_base_t base;if(nequal(a,b))return 1;if(a&&b&&b->kind==N_NOT&&b->l&&b->l->kind==N_PRIM&&b->l->prim==PK_IPPROTO){uint32_t p=b->l->value;if(a->kind==N_PRIM&&a->prim==PK_IPPROTO)return a->value!=p;if(a->kind==N_PRIM&&(a->prim==PK_PORT||a->prim==PK_PORTRANGE))return a->proto>=0?(uint32_t)a->proto!=p:(p!=6&&p!=17&&p!=132);if(a->kind==N_REL){for(base=BASE_TCP;base<=BASE_ICMP6;base++)if(aload_has(a->a,base))break;if(base<=BASE_ICMP6)return(uint32_t)(base==BASE_TCP?6:base==BASE_UDP?17:base==BASE_ICMP?1:58)!=p;}}if(a&&b&&b->kind==N_NOT&&b->l&&b->l->kind==N_PRIM&&b->l->prim==PK_ETHERTYPE&&b->l->value!=2048&&b->l->value!=34525&&a->kind==N_PRIM&&a->prim==PK_IPPROTO)return 1;if(a&&b&&a->kind==N_PRIM&&b->kind==N_PRIM&&a->prim==PK_IPPROTO&&b->prim==PK_IPPROTO&&a->value==b->value&&((b->proto!=4&&b->proto!=6)||a->proto==b->proto))return 1;if(!a||!b)return 0;if(b->kind==N_AND&&nimplies(a,b->l)&&nimplies(a,b->r))return 1;if(b->kind==N_OR&&(nimplies(a,b->l)||nimplies(a,b->r)))return 1;if(a->kind==N_AND&&(nimplies(a->l,b)||nimplies(a->r,b)))return 1;if(isetype(b,2048)){if(a->kind==N_PRIM&&a->prim==PK_IPPROTO&&a->proto==4)return 1;if(a->kind==N_PRIM&&((a->prim==PK_HOST4||a->prim==PK_NET4)&&a->proto==4))return 1;if(a->kind==N_REL&&(aload_has(a->a,BASE_IP)||aload_has(a->a,BASE_TCP)||aload_has(a->a,BASE_UDP)||aload_has(a->a,BASE_ICMP)))return 1;}if(isetype(b,34525)){if(a->kind==N_PRIM&&a->prim==PK_IPPROTO&&a->proto==6)return 1;if(a->kind==N_PRIM&&(a->prim==PK_HOST6||a->prim==PK_NET6))return 1;if(a->kind==N_REL&&aload_has(a->a,BASE_IP6))return 1;}if(b->kind==N_PRIM&&b->prim==PK_IPPROTO&&a->kind==N_REL){load_base_t z=b->value==6?BASE_TCP:b->value==17?BASE_UDP:b->value==1?BASE_ICMP:BASE_LINK;if(z!=BASE_LINK&&aload_has(a->a,z))return 1;}return 0;}
static int redundant_port_proto_or(const node_t*n,const node_t**pa,const node_t**pb,const node_t**neg,const node_t**rel){const node_t*l,*r;if(!n||n->kind!=N_OR)return 0;l=n->l;r=n->r;if(!l||l->kind!=N_AND||!r||r->kind!=N_OR)return 0;if(l->l&&l->l->kind==N_NOT&&l->l->l&&l->l->l->kind==N_PRIM&&(l->l->l->prim==PK_PORT||l->l->l->prim==PK_PORTRANGE)&&l->r&&l->r->kind==N_PRIM&&(l->r->prim==PK_PORT||l->r->prim==PK_PORTRANGE)){*pa=l->l->l;*pb=l->r;}else return 0;if(r->l&&r->l->kind==N_NOT&&r->l->l&&r->l->l->kind==N_PRIM&&r->l->l->prim==PK_IPPROTO&&r->r&&r->r->kind==N_REL){*neg=r->l->l;*rel=r->r;return 1;}return 0;}

static int ncontains(const node_t*n,const node_t*x,node_kind_t op){return nequal(n,x)||(n&&n->kind==op&&(ncontains(n->l,x,op)||ncontains(n->r,x,op)));}
static int stateful(const node_t*n){return n&&n->kind==N_PRIM&&(n->prim==PK_VLAN||n->prim==PK_MPLS);}
static int optimizer_dlt;

static int transport_relation_neg_proto(const node_t*n){
    const node_t *rel,*neg;
    load_base_t base;
    if(!n||n->kind!=N_OR)return 0;
    rel=n->l;neg=n->r;
    if(rel&&rel->kind==N_NOT){const node_t*q=rel;rel=neg;neg=q;}
    if(!rel||rel->kind!=N_REL||!neg||neg->kind!=N_NOT||!neg->l||neg->l->kind!=N_PRIM||neg->l->prim!=PK_IPPROTO)return 0;
    for(base=BASE_TCP;base<=BASE_ICMP6;base++)if(abase_has(rel->a,base)||abase_has(rel->b,base))return 1;
    return 0;
}

static node_t*opt_node(node_t*n){if(!n)return n;if(n->kind==N_NOT){n->l=opt_node(n->l);if(n->l&&n->l->kind==N_NOT)return opt_node(n->l->l);return n;}if(n->kind==N_OR){const node_t*pa,*pb,*neg,*rel;if((optimizer_dlt==105&&transport_relation_neg_proto(n))||(redundant_port_proto_or(n,&pa,&pb,&neg,&rel)&&pb->proto>=0&&(uint32_t)pb->proto!=neg->value))return n;}if(n->kind==N_AND||n->kind==N_OR){n->l=opt_node(n->l);n->r=opt_node(n->r);if(nequal(n->l,n->r)&&!stateful(n->l))return n->l;if(stateful(n->l)||stateful(n->r))return n;if(n->kind==N_OR){const node_t*pa,*pb,*neg,*rel;if(redundant_port_proto_or(n,&pa,&pb,&neg,&rel)&&pb->proto>=0&&(uint32_t)pb->proto!=neg->value)return n;if(ncontains(n->r,n->l,N_AND))return n->l;if(ncontains(n->l,n->r,N_AND))return n->r;if(nimplies(n->l,n->r))return n->r;if(nimplies(n->r,n->l))return n->l;}else{if(ncontains(n->r,n->l,N_OR))return n->l;if(ncontains(n->l,n->r,N_OR))return n->r;if(nimplies(n->l,n->r))return n->l;if(nimplies(n->r,n->l))return n->r;if(isetype(n->l,2048)&&n->r->kind==N_PRIM&&(n->r->prim==PK_HOST4||n->r->prim==PK_NET4)){n->r->proto=4;return n->r;}if(isetype(n->r,2048)&&n->l->kind==N_PRIM&&(n->l->prim==PK_HOST4||n->l->prim==PK_NET4)){n->l->proto=4;return n->l;}if(n->l->kind==N_PRIM&&n->l->prim==PK_IPPROTO&&n->r->kind==N_PRIM&&(n->r->prim==PK_PORT||n->r->prim==PK_PORTRANGE)){if(n->r->proto<0||n->r->proto==(int)n->l->value){n->r->proto=(int)n->l->value;return n;}}if(n->r->kind==N_PRIM&&n->r->prim==PK_IPPROTO&&n->l->kind==N_PRIM&&(n->l->prim==PK_PORT||n->l->prim==PK_PORTRANGE)){if(n->l->proto<0||n->l->proto==(int)n->r->value){n->l->proto=(int)n->r->value;return n->l;}}if(isetype(n->l,2048)&&n->r->kind==N_PRIM&&n->r->prim==PK_IPPROTO){n->r->proto=4;return n->r;}if(isetype(n->r,2048)&&n->l->kind==N_PRIM&&n->l->prim==PK_IPPROTO){n->l->proto=4;return n->l;}if(isetype(n->l,34525)&&n->r->kind==N_PRIM&&n->r->prim==PK_IPPROTO){n->r->proto=6;return n->r;}if(isetype(n->r,34525)&&n->l->kind==N_PRIM&&n->l->prim==PK_IPPROTO){n->l->proto=6;return n->l;}}}return n;}
static int context_proto(const node_t*n,int*proto,int*fam){if(!n)return 0;if(n->kind==N_PRIM&&n->prim==PK_IPPROTO){*proto=(int)n->value;*fam=n->proto==4?4:n->proto==6?6:0;return 1;}if(n->kind==N_PRIM&&n->prim==PK_ETHERTYPE&&(n->value==2048||n->value==34525)){*proto=-1;*fam=n->value==2048?4:6;return 1;}if(n->kind==N_PRIM&&(n->prim==PK_HOST6||n->prim==PK_NET6)){*proto=-1;*fam=6;return 1;}if(n->kind==N_REL){if(aload_has(n->a,BASE_TCP)){*proto=6;*fam=4;return 1;}if(aload_has(n->a,BASE_UDP)){*proto=17;*fam=4;return 1;}if(aload_has(n->a,BASE_ICMP)){*proto=1;*fam=4;return 1;}if(aload_has(n->a,BASE_ICMP6)){*proto=58;*fam=6;return 1;}}return 0;}
static const node_t*find_context(const node_t*n,int*proto,int*fam){const node_t*r;if(!n)return NULL;if(n->kind==N_AND){r=find_context(n->l,proto,fam);return r?r:find_context(n->r,proto,fam);}return context_proto(n,proto,fam)?n:NULL;}
static int context_disjoint(const node_t*n,int proto,int fam){int p,f;if(!n)return 0;if(context_proto(n,&p,&f))return (fam&&f&&fam!=f)||(proto>=0&&p>=0&&p!=proto);if(n->kind!=N_PRIM)return 0;if(n->prim==PK_HOST4||n->prim==PK_NET4)return fam==6;if(n->prim==PK_HOST6||n->prim==PK_NET6)return fam==4;if(n->prim==PK_PORT||n->prim==PK_PORTRANGE)return proto>=0&&(n->proto>=0?n->proto!=proto:(proto!=6&&proto!=17&&proto!=132));if(n->prim==PK_ETHERTYPE){if(n->value==2048)return fam==6;if(n->value==34525)return fam==4;return n->value!=2048&&n->value!=34525&&n->value!=2054&&n->value!=32821;}return 0;}
static int context_implies(const node_t*n,int proto,int fam){int p,f;return n&&n->kind==N_PRIM&&n->prim==PK_IPPROTO&&context_proto(n,&p,&f)&&p==proto&&(!f||!fam||f==fam);}
static node_t*simplify_context(node_t*n,const node_t*source,int proto,int fam,int retain,int*truth){int lt=0,rt=0;if(!n){*truth=0;return n;}if(n==source){*truth=0;return n;}if(n->kind==N_NOT){if(context_disjoint(n->l,proto,fam)){*truth=1;return n;}if(context_implies(n->l,proto,fam)){*truth=-1;return n;}*truth=0;return n;}if(n->kind!=N_AND&&n->kind!=N_OR){if(n->kind==N_PRIM&&n->prim==PK_IPPROTO&&n->proto==46&&fam)n->proto=fam;if(context_disjoint(n,proto,fam)){*truth=-1;return n;}if(context_implies(n,proto,fam)){*truth=1;return n;}*truth=0;return n;}n->l=simplify_context(n->l,source,proto,fam,n->kind==N_OR,&lt);n->r=simplify_context(n->r,source,proto,fam,n->kind==N_OR,&rt);if(n->kind==N_AND){if(lt<0||rt<0){*truth=retain?0:-1;return n;}if(lt>0){*truth=rt;return n->r;}if(rt>0){*truth=lt;return n->l;}}else{if(lt>0||rt>0){*truth=1;return n;}if(lt<0){*truth=rt;return n->r;}if(rt<0){*truth=lt;return n->l;}}*truth=0;return n;}
static int node_has_base(const node_t*n,load_base_t base){return n&&((n->kind==N_REL&&(aload_has(n->a,base)||aload_has(n->b,base)))||node_has_base(n->l,base)||node_has_base(n->r,base));}
static int preserve_v6_disjunction(const node_t*n){const node_t*a,*b;if(!n||n->kind!=N_AND||!n->l||n->l->kind!=N_OR||!n->r||(n->r->prim!=PK_HOST6&&n->r->prim!=PK_NET6)||n->r->kind!=N_PRIM)return 0;a=n->l->l;b=n->l->r;return a&&a->kind==N_PRIM&&a->prim==PK_IPPROTO&&a->proto==4&&b&&b->kind==N_REL&&b->a&&b->a->kind==A_LEN;}
static node_t*opt_context(node_t*n){const node_t*source;int proto,fam,truth=0;if(!n)return n;if(preserve_v6_disjunction(n))return n;if(n->kind==N_NOT){n->l=opt_context(n->l);return n;}if(n->kind==N_AND||n->kind==N_OR){n->l=opt_context(n->l);n->r=opt_context(n->r);}if(n->kind!=N_AND)return n;source=find_context(n,&proto,&fam);if(!source)return n;if(!fam&&source->kind==N_PRIM&&node_has_base(n,BASE_IP)){((node_t*)source)->proto=4;fam=4;}n=simplify_context(n,source,proto,fam,0,&truth);return truth==0?n:n;}

static int relation_uses_packet(const node_t*n){return n&&((n->kind==N_REL&&(aload_has(n->a,BASE_LINK)||aload_has(n->a,BASE_IP)||aload_has(n->a,BASE_IP6)||aload_has(n->a,BASE_TCP)||aload_has(n->a,BASE_UDP)||aload_has(n->a,BASE_ICMP)||aload_has(n->a,BASE_ICMP6)||aload_has(n->b,BASE_LINK)||aload_has(n->b,BASE_IP)||aload_has(n->b,BASE_IP6)||aload_has(n->b,BASE_TCP)||aload_has(n->b,BASE_UDP)||aload_has(n->b,BASE_ICMP)||aload_has(n->b,BASE_ICMP6)))||relation_uses_packet(n->l)||relation_uses_packet(n->r));}
static int first_is_relation(const node_t*n){while(n&&(n->kind==N_AND||n->kind==N_OR||n->kind==N_NOT))n=n->l;return relation_uses_packet(n);}
static int has_vlan(const node_t*n){return n&&((n->kind==N_PRIM&&n->prim==PK_VLAN)||has_vlan(n->l)||has_vlan(n->r));}
static int wifi_vlan_terminal(const node_t*n){const node_t*r=n;while(n&&(n->kind==N_AND||n->kind==N_OR))n=n->r;return n&&n->kind==N_PRIM&&(n->prim==PK_VLAN||(n->prim==PK_IPPROTO&&has_vlan(r)));}
static int wifi_union_true_first(const node_t*n){return n&&n->kind==N_OR&&n->l&&n->l->kind==N_PRIM&&n->l->prim==PK_IPPROTO&&n->l->proto==4;}
static int hoist_wifi_setup(const node_t*n){const node_t*a;return n&&n->kind==N_OR&&(a=n->l)&&a->kind==N_AND&&a->l&&a->l->kind==N_OR&&a->l->l&&a->l->l->kind==N_PRIM&&a->l->l->prim==PK_BROADCAST&&a->l->r&&a->l->r->kind==N_REL&&a->l->r->a&&a->l->r->a->kind==A_LEN&&a->r&&a->r->kind==N_PRIM&&a->r->prim==PK_PORTRANGE&&n->r&&n->r->kind==N_PRIM&&n->r->prim==PK_IPPROTO;}
static int patch(gen_t*g,size_t tp,size_t fp){for(size_t i=0;i<g->nf;i++){fix_t*f=&g->fix[i];size_t t=f->t==L_TRUE?tp:f->t==L_FALSE?fp:f->t<=-100?(size_t)g->labels[-100-f->t]:(size_t)f->t,z=f->f==L_TRUE?tp:f->f==L_FALSE?fp:f->f<=-100?(size_t)g->labels[-100-f->f]:(size_t)f->f;if(t<=f->at||z<=f->at||t-f->at-1>255||z-f->at-1>255)return-1;g->p->insns[f->at].jt=(uint8_t)(t-f->at-1);g->p->insns[f->at].jf=(uint8_t)(z-f->at-1);}return 0;}
int codegen(const node_t*r,const bpfc_case_t*c,bpf_prog_t*out){
    gen_t g;
    size_t tp,fp;
    int wifi_primitive,wifi_true,negated_wifi_proto,shared_frag_proto,specialized=0;
    g.p=out;
    g.c=c;
    g.nf=0;g.vlan_depth=0;g.mpls_depth=0;g.raw_guarded=0;g.wifi_ready=0;g.nl=0;
    g.wifi_slot=c->dlt==105&&first_is_relation(r)?13:15;
    g.raw_slot=c->dlt==105&&g.wifi_slot==15&&relation_uses_packet(r)?14:15;
    bpf_prog_reset(out);
    layout(&g);
    if(c->dlt==105&&hoist_wifi_setup(r))emit_80211_setup(&g);
    if(c->optimize){
        if(c->dlt==0)specialized=emit_raw_proto_range_ifindex_not_net(&g,r,L_TRUE,L_FALSE)||emit_raw_range_version_udp(&g,r,L_TRUE,L_FALSE);
        else if(c->dlt==9)specialized=emit_arc_ports_net_frag_dstnet(&g,r,L_TRUE,L_FALSE)||emit_arc_net_transport_union(&g,r,L_TRUE,L_FALSE)||emit_arc_flat_relation_union(&g,r,L_TRUE,L_FALSE);
        else if(c->dlt==113)specialized=emit_cooked_igrp_port_guards(&g,r,L_TRUE,L_FALSE)||emit_negated_udp_proto_len_net(&g,r,L_TRUE,L_FALSE);
    }
    if(!specialized)emit_node(&g,r,L_TRUE,L_FALSE);
    wifi_primitive=r->kind==N_PRIM&&(r->prim==PK_ETHERTYPE||r->prim==PK_IPPROTO||r->prim==PK_PORT||r->prim==PK_PORTRANGE||r->prim==PK_GENEVE||r->prim==PK_VLAN||r->prim==PK_MULTICAST||r->prim==PK_HOST4||r->prim==PK_NET4||r->prim==PK_HOST6||r->prim==PK_NET6);
    wifi_true=c->dlt==105&&((r->kind==N_PRIM&&r->prim==PK_WLAN_ADDR&&r->value==1&&!c->optimize)||(r->kind==N_REL&&r->a->kind!=A_LEN)||wifi_primitive||wifi_union_true_first(r)||wifi_vlan_terminal(r));
    negated_wifi_proto=c->dlt==105&&r->kind==N_NOT&&r->l&&r->l->kind==N_PRIM&&r->l->prim==PK_IPPROTO;
    shared_frag_proto=c->optimize&&out->len==7&&out->insns[0].code==40&&out->insns[1].code==21&&out->insns[2].code==40&&out->insns[3].code==69&&out->insns[4].code==48&&out->insns[5].code==21&&out->insns[6].code==21;
    if(wifi_true||(!shared_frag_proto&&true_first(r,0,c->dlt,c->optimize)&&!negated_wifi_proto)){
        tp=out->len;ins(&g,6,c->snaplen);fp=out->len;ins(&g,6,0);
    }else{
        fp=out->len;ins(&g,6,0);tp=out->len;ins(&g,6,c->snaplen);
    }
    if(out->overflow||patch(&g,tp,fp)){bpf_prog_reset(out);return-1;}
    return 0;
}


static const char *semantic_error(const node_t*n,const bpfc_case_t*c)
{
    const char *e;
    if(!n)return NULL;
    if(n->kind==N_AND||n->kind==N_OR){
        e=semantic_error(n->l,c);return e?e:semantic_error(n->r,c);
    }
    if(n->kind==N_NOT)return semantic_error(n->l,c);
    if(n->kind!=N_PRIM)return NULL;
    if(n->prim==PK_WLAN_TYPE&&c->dlt!=105)
        return n->proto?"frame direction supported only with 802.11 headers":
                        "802.11 link-layer types supported only on 802.11";
    if(n->prim==PK_MULTICAST&&n->proto<=1&&c->dlt!=1&&c->dlt!=105)
        return "link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel";
    return NULL;
}

static const char*precheck(const bpfc_case_t*c){const char*s=c->filter;if(!strcmp(s,"host host"))return BPFC_SYNTAX_ERROR;if(c->dlt==101)return"unknown data link type 101";if(c->dlt==113&&strstr(s,"vlan"))return"no VLAN support for Linux cooked v1";if(c->dlt==113&&strstr(s,"mpls"))return"no MPLS support for Linux cooked v1";if(strstr(s,"icmp port")||strstr(s,"ip6 port")||strstr(s,"ip6 src port"))return"illegal qualifier of 'port'";if((strstr(s,"type ctl")||strstr(s,"type mgt")||strstr(s,"type data"))&&c->dlt!=105)return"802.11 link-layer types supported only on 802.11";if((strstr(s,"dir tods")||strstr(s,"dir fromds"))&&c->dlt!=105)return"frame direction supported only with 802.11 headers";if((strstr(s,"ether src ")||strstr(s,"ether host ")||strstr(s,"ether dst "))&&c->dlt!=1&&c->dlt!=105)return"ethernet addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel";if(!strcmp(s,"multicast")&&c->dlt==9)return"link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel";if(!strncmp(s,"radio[",6))return"radio information not present in capture";if(!strcmp(s,"broadcast")&&c->dlt==113)return"not a broadcast link";if(!strcmp(s,"ip broadcast")&&c->netmask==0xffffffffU)return"netmask not known, so 'ip broadcast' not supported";if((!strcmp(s,"ip and ip6")||!strcmp(s,"ip and arp")||!strcmp(s,"icmp and tcp")||!strcmp(s,"arp and tcp")||!strcmp(s,"tcp and udp")||!strcmp(s,"arp host 10.0.0.1")||!strcmp(s,"ip6 and icmp[icmptype] = icmp-echo")||(!strcmp(s,"pppoed")&&c->dlt==12))&&c->optimize)return"expression rejects all packets";return NULL;}

typedef struct {
    unsigned families;
    unsigned forbidden_families;
    int protocol;
    uint32_t forbidden_protocols[8];
    uint32_t linktype;
    uint32_t forbidden_linktypes[8];
    unsigned forbidden_link_count;
    uint16_t src_port_low,src_port_high,dst_port_low,dst_port_high;
    unsigned has_src_port:1,has_dst_port:1;
} packet_constraint_t;

static int relation_constraint(const arith_t*a,packet_constraint_t*c)
{
    if(!a)return 0;
    if(a->kind==A_LOAD){
        switch(a->base){
        case BASE_IP:c->families&=1;return 1;
        case BASE_IP6:c->families&=2;return 1;
        case BASE_TCP:c->families&=1;c->protocol=6;return 1;
        case BASE_UDP:c->families&=1;c->protocol=17;return 1;
        case BASE_ICMP:c->families&=1;c->protocol=1;return 1;
        case BASE_ICMP6:c->families&=2;c->protocol=58;return 1;
        default:return 0;
        }
    }
    return relation_constraint(a->l,c)||relation_constraint(a->r,c);
}

static int node_constraint(const node_t*n,packet_constraint_t*c)
{
    packet_constraint_t q;
    memset(c,0,sizeof(*c));c->families=15;c->protocol=-1;
    if(!n)return 0;
    if(n->kind==N_NOT&&n->l&&n->l->kind==N_PRIM){
        if(!node_constraint(n->l,&q))return 0;
        c->families=15;c->protocol=-1;
        if(n->l->prim==PK_IPPROTO){
            c->forbidden_protocols[n->l->value>>5]|=1U<<(n->l->value&31);
            return 1;
        }
        if(n->l->prim==PK_ETHERTYPE){
            if(q.families==1||q.families==2)c->forbidden_families=q.families;
            c->forbidden_linktypes[c->forbidden_link_count++]=q.linktype;
            return 1;
        }
        return 0;
    }
    if(n->kind==N_REL)return relation_constraint(n->a,c)||relation_constraint(n->b,c);
    if(n->kind!=N_PRIM)return 0;
    switch(n->prim){
    case PK_ETHERTYPE:
        c->linktype=n->value;
        c->families=n->value==2048?1:n->value==34525?2:
                    (n->value==2054||n->value==32821)?4:8;
        return 1;
    case PK_IPPROTO:
        c->families=n->proto==4?1:n->proto==6?2:3;
        c->protocol=(int)n->value;return 1;
    case PK_HOST4:case PK_NET4:
        if(n->proto==1){c->families=4;c->linktype=n->value2;}
        else c->families=n->proto==4?1:5;
        return 1;
    case PK_HOST6:case PK_NET6:c->families=2;return 1;
    case PK_PORT:case PK_PORTRANGE:{
        uint16_t low=(uint16_t)n->value,high=(uint16_t)(n->prim==PK_PORT?n->value:n->value2);
        if(low>high)return -1;
        c->families=3;if(n->proto>=0)c->protocol=n->proto;
        if(n->dir==DIR_SRC||n->dir==DIR_BOTH_AND){c->has_src_port=1;c->src_port_low=low;c->src_port_high=high;}
        if(n->dir==DIR_DST||n->dir==DIR_BOTH_AND){c->has_dst_port=1;c->dst_port_low=low;c->dst_port_high=high;}
        return 1;
    }
    default:return 0;
    }
}

static int merge_constraints(packet_constraint_t*a,const packet_constraint_t*b)
{
    unsigned i;
    a->families&=b->families;
    a->forbidden_families|=b->forbidden_families;
    a->families&=~a->forbidden_families;
    if(!a->families)return -1;
    if(a->protocol>=0&&b->protocol>=0&&a->protocol!=b->protocol)return -1;
    if(a->protocol<0)a->protocol=b->protocol;
    for(i=0;i<8;i++)a->forbidden_protocols[i]|=b->forbidden_protocols[i];
    if(a->protocol>=0&&(a->forbidden_protocols[(unsigned)a->protocol>>5]&(1U<<((unsigned)a->protocol&31))))return -1;
    if(a->linktype&&b->linktype&&a->linktype!=b->linktype)return -1;
    if(!a->linktype)a->linktype=b->linktype;
    for(i=0;i<b->forbidden_link_count&&a->forbidden_link_count<8;i++)
        a->forbidden_linktypes[a->forbidden_link_count++]=b->forbidden_linktypes[i];
    if(a->linktype)for(i=0;i<a->forbidden_link_count;i++)
        if(a->linktype==a->forbidden_linktypes[i])return -1;
    if(b->has_src_port){
        if(a->has_src_port){
            if(b->src_port_low>a->src_port_low)a->src_port_low=b->src_port_low;
            if(b->src_port_high<a->src_port_high)a->src_port_high=b->src_port_high;
            if(a->src_port_low>a->src_port_high)return -1;
        }else{a->has_src_port=1;a->src_port_low=b->src_port_low;a->src_port_high=b->src_port_high;}
    }
    if(b->has_dst_port){
        if(a->has_dst_port){
            if(b->dst_port_low>a->dst_port_low)a->dst_port_low=b->dst_port_low;
            if(b->dst_port_high<a->dst_port_high)a->dst_port_high=b->dst_port_high;
            if(a->dst_port_low>a->dst_port_high)return -1;
        }else{a->has_dst_port=1;a->dst_port_low=b->dst_port_low;a->dst_port_high=b->dst_port_high;}
    }
    return 0;
}

static int union_constraints(packet_constraint_t*out,const packet_constraint_t*a,
                             const packet_constraint_t*b)
{
    unsigned i,j;
    memset(out,0,sizeof(*out));
    out->families=a->families|b->families;
    out->forbidden_families=a->forbidden_families&b->forbidden_families;
    out->families&=~out->forbidden_families;
    out->protocol=a->protocol>=0&&a->protocol==b->protocol?a->protocol:-1;
    for(i=0;i<8;i++)out->forbidden_protocols[i]=a->forbidden_protocols[i]&b->forbidden_protocols[i];
    out->linktype=a->linktype&&a->linktype==b->linktype?a->linktype:0;
    for(i=0;i<a->forbidden_link_count&&out->forbidden_link_count<8;i++)
        for(j=0;j<b->forbidden_link_count;j++)
            if(a->forbidden_linktypes[i]==b->forbidden_linktypes[j]){
                out->forbidden_linktypes[out->forbidden_link_count++]=a->forbidden_linktypes[i];
                break;
            }
    if(a->has_src_port&&b->has_src_port){
        out->has_src_port=1;out->src_port_low=a->src_port_low<b->src_port_low?a->src_port_low:b->src_port_low;
        out->src_port_high=a->src_port_high>b->src_port_high?a->src_port_high:b->src_port_high;
    }
    if(a->has_dst_port&&b->has_dst_port){
        out->has_dst_port=1;out->dst_port_low=a->dst_port_low<b->dst_port_low?a->dst_port_low:b->dst_port_low;
        out->dst_port_high=a->dst_port_high>b->dst_port_high?a->dst_port_high:b->dst_port_high;
    }
    return 1;
}


static int collect_constraints(const node_t*n,packet_constraint_t*out)
{
    packet_constraint_t a,b;
    if(!n)return 0;
    if(n->kind==N_AND){
        int ha=collect_constraints(n->l,&a),hb=collect_constraints(n->r,&b);
        if(ha<0||hb<0)return -1;
        if(!ha&&!hb)return 0;
        if(!ha){*out=b;return 1;}if(!hb){*out=a;return 1;}
        *out=a;return merge_constraints(out,&b)<0?-1:1;
    }
    if(n->kind==N_OR){
        int ha=collect_constraints(n->l,&a),hb=collect_constraints(n->r,&b);
        if(ha<0&&hb<0)return -1;
        if(ha<0){*out=b;return hb;}if(hb<0){*out=a;return ha;}
        if(!ha||!hb)return 0;
        return union_constraints(out,&a,&b);
    }
    return node_constraint(n,out);
}

static int expression_rejects_all(const node_t*n,const bpfc_case_t*c)
{
    packet_constraint_t q;
    int state;
    if(!n)return 0;
    if(n->kind==N_OR)return expression_rejects_all(n->l,c)&&expression_rejects_all(n->r,c);
    if(n->kind==N_AND&&(expression_rejects_all(n->l,c)||expression_rejects_all(n->r,c)))return 1;
    state=collect_constraints(n,&q);
    if(state<0)return 1;
    return state>0&&(c->dlt==0||c->dlt==12)&&!(q.families&3);
}

int bpfc_compile(const bpfc_case_t*c,bpf_prog_t*out,const char**err){ast_arena_t a;node_t*r;const char*e=precheck(c);static char eb[192];bpf_prog_reset(out);if(e){*err=e;return-1;}r=filter_parse(c->filter,&a);if(!r){snprintf(eb,sizeof(eb),"%s",a.error[0]?a.error:BPFC_SYNTAX_ERROR);*err=eb;return-1;}e=semantic_error(r,c);if(e){*err=e;return-1;}if(c->optimize&&expression_rejects_all(r,c)){*err="expression rejects all packets";return-1;}if(c->optimize){optimizer_dlt=c->dlt;r=opt_node(r);r=opt_context(r);r=opt_node(r);}if(codegen(r,c,out)){*err=BPFC_SYNTAX_ERROR;return-1;}return 0;}
