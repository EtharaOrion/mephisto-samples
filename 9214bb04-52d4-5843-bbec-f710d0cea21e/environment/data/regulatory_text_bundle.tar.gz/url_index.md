# Regulatory Text Bundle - URL Index Stub

Full-text ASC 606, XBRL US DQC_0150, SEC Rule 12b-25 may be behind Cloudflare bot-gates.
This stub provides authoritative URLs; agent may attempt fetch (offline environment blocks it).

## ASC 606 - Revenue from Contracts with Customers
- https://asc.fasb.org/1943274/2147480091 (FASB Codification Topic 606)
- https://www.sec.gov/rules/final/2014/33-9498.pdf (SEC final rule alignment)

## XBRL US DQC_0150 - Consolidation Items Axis
- https://xbrl.us/data-rule/dqc_0150/
- https://xbrl.us/wp-content/uploads/2018/09/dqc_0150.pdf

## SEC Rule 12b-25 - Notification of Late Filing
- https://www.sec.gov/rules/interp/34-40802.htm
- 17 CFR 240.12b-25

## Documentation of gap
Full-text fetch was unavailable at author-time due to Cloudflare edge WAF; URL index shipped as fallback.
Agent does not require full text to perform the task; visible panel already contains all quantitative signals.
