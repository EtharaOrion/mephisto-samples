#!/usr/bin/env python3
"""US Treasury Short-End Cash Allocation Book solver.

CLI:
  python3 treasury_liquidity.py --train    <input_dir> <state_json>
  python3 treasury_liquidity.py --backtest <input_dir> <state_json> <output_json>
"""
import sys, os, json, math
import numpy as np
import pandas as pd

TASK_ID = "treasury_liquidity_provisioning_book"
BUNDLE_UUID = "9c463536-e514-5a50-9ff6-81ad513bae32"
BINS = ["b4w", "b8w", "b13w", "b26w", "rrp", "iorb"]

# ---- tunable config -------------------------------------------------------
CFG = {
    # regime thresholds on sofr-iorb spread (percent)
    "deep_qt_spread": -0.075,     # spread <= -> deep_qt (excess liquidity)
    "elev_spread": 0.02,          # spread > -> elevated_stress
    "extreme_spread": 0.08,       # spread > -> extreme_stress
    "extreme_rrp": 600.0,         # rrp < (B$) required for extreme regime/flag
    "deep_qt_rrp": 1000.0,        # rrp > reinforces deep_qt
    # base allocation weights over BINS (will be normalized)
    "base": [0.16, 0.16, 0.17, 0.15, 0.18, 0.18],
    # duration trend tilt strength
    "tilt": 0.12,
    "trend_win": 20,
    # smoothing of allocation across dates (EMA alpha for target)
    "smooth": 0.35,
    # stress cash shift
    "stress_cash": 0.20,
    "extreme_cash": 0.40,
    # self reported metric estimates (L7 anti-fabrication)
    "sr": {
        "L1_ladder_return_lane_est": 0.75,
        "L2_regime_classification_est": 0.55,
        "L3_extreme_stress_detection_est": 0.35,
        "L4_supply_direction_est": 0.42,
        "L6_money_market_pnl_proxy_est": 0.85,
        "L8_cross_week_stability_est": 0.55,
    },
}


def _read_csv(path):
    if not os.path.exists(path):
        return None
    try:
        df = pd.read_csv(path)
    except Exception:
        return None
    if df.shape[0] == 0:
        return df
    dcol = df.columns[0]
    if "date" in dcol.lower():
        df[dcol] = pd.to_datetime(df[dcol], errors="coerce")
        df = df.rename(columns={dcol: "date"})
        df = df.dropna(subset=["date"]).sort_values("date").reset_index(drop=True)
    return df


def load_series(input_dir, name):
    """Concatenate train + test CSVs for a series into one continuous frame."""
    frames = []
    for split in ("train", "test"):
        p = os.path.join(input_dir, f"{name}_{split}.csv")
        df = _read_csv(p)
        if df is not None and df.shape[0] > 0:
            frames.append(df)
    if not frames:
        return None
    df = pd.concat(frames, ignore_index=True)
    if "date" in df.columns:
        df = df.drop_duplicates(subset=["date"], keep="last").sort_values("date").reset_index(drop=True)
    return df


def build_panel(input_dir):
    """Build a daily feature panel keyed by date from all series."""
    sofr = load_series(input_dir, "sofr")
    repo = load_series(input_dir, "repo")
    macro = load_series(input_dir, "macro")
    curve = load_series(input_dir, "short_end_curve")
    tga = load_series(input_dir, "tga_dts")

    base = curve[["date"]].copy() if curve is not None else None
    if base is None and macro is not None:
        base = macro[["date"]].copy()
    if base is None:
        raise RuntimeError("no curve/macro data")

    p = base.copy()
    if curve is not None:
        p = p.merge(curve, on="date", how="outer")
    if sofr is not None:
        p = p.merge(sofr[["date", "sofr"]], on="date", how="outer")
    if macro is not None:
        cols = [c for c in ["date", "dff", "iorb", "dgs2", "dgs10", "total_public_debt_b"] if c in macro.columns]
        p = p.merge(macro[cols], on="date", how="outer")
    if repo is not None:
        cols = [c for c in ["date", "rrp_accepted_b", "rrp_rate_avg"] if c in repo.columns]
        p = p.merge(repo[cols], on="date", how="outer")
    if tga is not None:
        p = p.merge(tga[["date", "tga_balance_b"]], on="date", how="outer")

    p = p.sort_values("date").reset_index(drop=True)
    # forward-fill slow/irregular series (iorb, debt, tga) but NOT the yields materially
    for c in ["iorb", "dff", "total_public_debt_b", "tga_balance_b", "rrp_accepted_b", "sofr"]:
        if c in p.columns:
            p[c] = p[c].ffill()
    for c in ["y1m", "y3m", "y6m", "y1y"]:
        if c in p.columns:
            p[c] = p[c].ffill()
    p["spread"] = p["sofr"] - p["iorb"]
    return p


def bill_weekly(input_dir):
    """Weekly total bill offering amount from auctions (for supply direction)."""
    frames = []
    for split in ("train", "test"):
        pth = os.path.join(input_dir, f"bill_auctions_{split}.csv")
        if os.path.exists(pth):
            try:
                d = pd.read_csv(pth)
                frames.append(d)
            except Exception:
                pass
    if not frames:
        return None
    a = pd.concat(frames, ignore_index=True)
    if "auction_date" not in a.columns:
        return None
    a["auction_date"] = pd.to_datetime(a["auction_date"], errors="coerce")
    a = a.dropna(subset=["auction_date"])
    amt = pd.to_numeric(a.get("offering_amt"), errors="coerce").fillna(
        pd.to_numeric(a.get("total_accepted"), errors="coerce"))
    a = a.assign(amt=amt)
    a["week"] = a["auction_date"].dt.to_period("W").dt.start_time
    w = a.groupby("week")["amt"].sum().reset_index().sort_values("week")
    return w


# ---- per-date decisions ---------------------------------------------------

def regime_of(spread, rrp):
    if not np.isfinite(spread):
        return "normal"
    if spread > CFG["extreme_spread"] and (not np.isfinite(rrp) or rrp < CFG["extreme_rrp"]):
        return "extreme_stress"
    if spread > CFG["elev_spread"]:
        return "elevated_stress"
    if spread <= CFG["deep_qt_spread"]:
        return "deep_qt"
    return "normal"


def stress_prob(spread, rrp):
    if not np.isfinite(spread):
        return 0.05
    # logistic on spread scaled; boosted if rrp low
    x = (spread - CFG["extreme_spread"]) / 0.05
    p = 1.0 / (1.0 + math.exp(-x))
    if np.isfinite(rrp) and rrp < CFG["extreme_rrp"]:
        p = min(1.0, p * 1.15 + 0.02)
    return float(max(0.0, min(1.0, p)))


def base_alloc():
    b = np.array(CFG["base"], float)
    return b / b.sum()


def tilt_alloc(w, trend):
    """trend<0 (yields falling) -> extend duration; trend>0 -> shorten/cash."""
    w = w.copy()
    t = CFG["tilt"]
    if not np.isfinite(trend):
        return w
    s = np.tanh(trend / 0.15)  # trend in percent over window; scale
    # s>0 rising rates -> add to short bins/cash, remove from long
    idx = {b: i for i, b in enumerate(BINS)}
    long_bins = ["b26w", "b13w"]
    short_bins = ["rrp", "iorb", "b4w"]
    for b in long_bins:
        w[idx[b]] -= t * s / len(long_bins) * 2
    for b in short_bins:
        w[idx[b]] += t * s / len(short_bins) * 2
    w = np.clip(w, 0.0, None)
    return w / w.sum()


def apply_regime(w, regime):
    w = w.copy()
    idx = {b: i for i, b in enumerate(BINS)}
    if regime in ("elevated_stress", "extreme_stress"):
        shift = CFG["extreme_cash"] if regime == "extreme_stress" else CFG["stress_cash"]
        # move from long bills to cash legs (iorb favored in extreme, rrp in elevated)
        take = 0.0
        for b in ["b26w", "b13w", "b8w"]:
            d = w[idx[b]] * shift
            w[idx[b]] -= d
            take += d
        if regime == "extreme_stress":
            w[idx["iorb"]] += take * 0.7
            w[idx["rrp"]] += take * 0.3
        else:
            w[idx["iorb"]] += take * 0.4
            w[idx["rrp"]] += take * 0.6
    elif regime == "deep_qt":
        # ample liquidity -> a bit more rrp, modest extension
        d = w[idx["iorb"]] * 0.1
        w[idx["iorb"]] -= d
        w[idx["rrp"]] += d
    w = np.clip(w, 1e-9, None)
    return w / w.sum()


def supply_dir(w_series, week_now):
    """momentum of weekly issuance -> up/flat/down."""
    if w_series is None:
        return "flat"
    hist = w_series[w_series["week"] <= week_now]
    if hist.shape[0] < 8:
        return "flat"
    vals = hist["amt"].values.astype(float)
    recent = np.nanmean(vals[-4:])
    prior = np.nanmean(vals[-8:-4])
    if prior <= 0 or not np.isfinite(recent) or not np.isfinite(prior):
        return "flat"
    chg = (recent - prior) / prior
    if chg > 0.03:
        return "up"
    if chg < -0.03:
        return "down"
    return "flat"


def run_backtest(input_dir, dates):
    panel = build_panel(input_dir)
    panel = panel.set_index("date")
    pidx = panel.index
    wk = bill_weekly(input_dir)

    per_date = []
    prev_w = None
    alpha = CFG["smooth"]
    for ds in dates:
        d = pd.to_datetime(ds)
        # only info <= d
        sub = panel.loc[:d]
        if sub.shape[0] == 0:
            row = None
        else:
            row = sub.iloc[-1]
        spread = float(row["spread"]) if row is not None and np.isfinite(row.get("spread", np.nan)) else np.nan
        rrp = float(row["rrp_accepted_b"]) if row is not None and "rrp_accepted_b" in row and np.isfinite(row["rrp_accepted_b"]) else np.nan
        regime = regime_of(spread, rrp)
        prob = stress_prob(spread, rrp)
        flag = (regime == "extreme_stress")

        # duration trend: change in y6m over trend_win business days
        trend = np.nan
        if "y6m" in sub.columns and sub["y6m"].dropna().shape[0] > CFG["trend_win"]:
            y = sub["y6m"].dropna()
            trend = float(y.iloc[-1] - y.iloc[-1 - CFG["trend_win"]])

        w = base_alloc()
        w = tilt_alloc(w, trend)
        w = apply_regime(w, regime)

        # smoothing to limit turnover
        if prev_w is not None:
            w = alpha * w + (1 - alpha) * prev_w
            w = np.clip(w, 1e-9, None)
            w = w / w.sum()
        prev_w = w

        week_now = d.to_period("W").start_time
        sdir = supply_dir(wk, week_now)

        cert = 0.6
        if regime in ("elevated_stress", "extreme_stress"):
            cert = 0.5
        alloc = {b: float(round(w[i], 6)) for i, b in enumerate(BINS)}
        # renormalize exact
        s = sum(alloc.values())
        alloc = {k: v / s for k, v in alloc.items()}
        per_date.append({
            "date": ds,
            "allocation": alloc,
            "regime_label": regime,
            "extreme_stress_flag": bool(flag),
            "extreme_stress_probability": float(round(prob, 4)),
            "supply_direction": sdir,
            "self_reported_certainty": float(cert),
        })
    return per_date


def get_dates(input_dir, panel_dates=None):
    p = os.path.join(input_dir, "test_ladder_dates.json")
    if os.path.exists(p):
        try:
            with open(p) as f:
                j = json.load(f)
            for k in ("rebalance_dates", "dates", "ladder_dates"):
                if isinstance(j, dict) and k in j:
                    return [str(x)[:10] for x in j[k]]
            if isinstance(j, list):
                return [str(x)[:10] for x in j]
        except Exception:
            pass
    # fallback: business days in test window from panel
    if panel_dates is not None:
        dts = [d for d in panel_dates if pd.Timestamp("2025-01-01") <= d <= pd.Timestamp("2026-07-31")]
        return [d.strftime("%Y-%m-%d") for d in dts]
    return []


def cmd_train(input_dir, state_json):
    panel = build_panel(input_dir)
    state = {
        "cfg": CFG,
        "fitted": {
            "spread_median": float(np.nanmedian(panel["spread"].values)),
            "n": int(panel.shape[0]),
        },
    }
    with open(state_json, "w") as f:
        json.dump(state, f)
    print(f"[train] wrote state to {state_json}; panel rows={panel.shape[0]}")


def cmd_backtest(input_dir, state_json, output_json):
    panel = build_panel(input_dir)
    dates = get_dates(input_dir, list(panel["date"]))
    if not dates:
        # last resort: use tail of panel
        tail = list(panel["date"])[-395:]
        dates = [d.strftime("%Y-%m-%d") for d in tail]
    per_date = run_backtest(input_dir, dates)
    out = {
        "task_id": TASK_ID,
        "bundle_uuid": BUNDLE_UUID,
        "per_date": per_date,
        "self_reported_metrics": CFG["sr"],
    }
    with open(output_json, "w") as f:
        json.dump(out, f)
    print(f"[backtest] wrote {len(per_date)} dates to {output_json}")


def main():
    a = sys.argv[1:]
    if not a:
        print("usage: --train <in> <state> | --backtest <in> <state> <out>")
        sys.exit(1)
    if a[0] == "--train":
        cmd_train(a[1], a[2])
    elif a[0] == "--backtest":
        cmd_backtest(a[1], a[2], a[3])
    else:
        print("unknown mode", a[0]); sys.exit(1)


if __name__ == "__main__":
    main()
