// C-compatible pixel conversion and scaling implementation with portable
// scalar paths and AArch64 NEON backends for the common conversion kernels.

use std::ffi::c_void;
use std::os::raw::c_int;
use std::ptr;

#[cfg(target_arch = "aarch64")]
use std::arch::aarch64::*;

const PIXFMT_YUV420P: c_int = 0;
const PIXFMT_YUV422P: c_int = 1;
const PIXFMT_YUV444P: c_int = 2;
const PIXFMT_NV12: c_int = 3;
const PIXFMT_NV21: c_int = 4;
const PIXFMT_RGB24: c_int = 5;
const PIXFMT_BGR24: c_int = 6;
const PIXFMT_RGBA: c_int = 7;
const PIXFMT_BGRA: c_int = 8;
const PIXFMT_GRAY8: c_int = 9;

const ALGO_NEAREST: c_int = 0;
const ALGO_BILINEAR: c_int = 1;
const ALGO_BICUBIC: c_int = 2;

const RY: i32 = (0.299 * 219.0 / 255.0 * 32768.0 + 0.5) as i32;
const GY: i32 = (0.587 * 219.0 / 255.0 * 32768.0 + 0.5) as i32;
const BY: i32 = (0.114 * 219.0 / 255.0 * 32768.0 + 0.5) as i32;
const RU: i32 = -((0.169 * 224.0 / 255.0 * 32768.0 + 0.5) as i32);
const GU: i32 = -((0.331 * 224.0 / 255.0 * 32768.0 + 0.5) as i32);
const BU: i32 = (0.500 * 224.0 / 255.0 * 32768.0 + 0.5) as i32;
const RV: i32 = (0.500 * 224.0 / 255.0 * 32768.0 + 0.5) as i32;
const GV: i32 = -((0.419 * 224.0 / 255.0 * 32768.0 + 0.5) as i32);
const BV: i32 = -((0.081 * 224.0 / 255.0 * 32768.0 + 0.5) as i32);

const YUV_RGB_CY: i32 = 76309;
const YUV_RGB_CRV: i32 = 89830;
const YUV_RGB_CBU: i32 = 113537;
const YUV_RGB_CGU: i32 = -22049;
const YUV_RGB_CGV: i32 = -45756;

const fn make_yuv_rgb_table() -> [u8; 1536] {
    let mut table = [0u8; 1536];
    let mut index = 0;
    while index < table.len() {
        let value = (-(384 << 16) - 512 * YUV_RGB_CY - (16 << 16)
            + index as i32 * YUV_RGB_CY
            + 0x8000)
            >> 16;
        table[index] = if value < 0 {
            0
        } else if value > 255 {
            255
        } else {
            value as u8
        };
        index += 1;
    }
    table
}

static YUV_RGB_TABLE: [u8; 1536] = make_yuv_rgb_table();

#[derive(Clone, Copy, PartialEq, Eq)]
enum Kind {
    Yuv,
    Rgb,
    Gray,
}

struct SwsContext {
    src_w: usize,
    src_h: usize,
    src_fmt: c_int,
    dst_w: usize,
    dst_h: usize,
    dst_fmt: c_int,
    algo: c_int,
    linear_x: Vec<(usize, usize, i32)>,
    linear_y: Vec<(usize, usize, i32)>,
    nearest_x: Vec<usize>,
    nearest_y: Vec<usize>,
}

#[inline]
fn valid_fmt(fmt: c_int) -> bool {
    (0..=9).contains(&fmt)
}

#[inline]
fn kind(fmt: c_int) -> Kind {
    match fmt {
        PIXFMT_RGB24 | PIXFMT_BGR24 | PIXFMT_RGBA | PIXFMT_BGRA => Kind::Rgb,
        PIXFMT_GRAY8 => Kind::Gray,
        _ => Kind::Yuv,
    }
}

#[inline]
fn is_yuv(fmt: c_int) -> bool {
    kind(fmt) == Kind::Yuv
}

#[inline]
fn bytes_per_pixel(fmt: c_int) -> usize {
    match fmt {
        PIXFMT_RGB24 | PIXFMT_BGR24 => 3,
        PIXFMT_RGBA | PIXFMT_BGRA => 4,
        _ => 1,
    }
}

#[inline]
fn chroma_shift(fmt: c_int) -> (usize, usize) {
    match fmt {
        PIXFMT_YUV420P | PIXFMT_NV12 | PIXFMT_NV21 => (1, 1),
        PIXFMT_YUV422P => (1, 0),
        PIXFMT_YUV444P => (0, 0),
        _ => (0, 0),
    }
}

#[inline]
fn plane_count(fmt: c_int) -> usize {
    match fmt {
        PIXFMT_YUV420P | PIXFMT_YUV422P | PIXFMT_YUV444P => 3,
        PIXFMT_NV12 | PIXFMT_NV21 => 2,
        _ => 1,
    }
}

#[inline]
fn plane_dims(fmt: c_int, plane: usize, w: usize, h: usize) -> (usize, usize, usize) {
    match fmt {
        PIXFMT_YUV420P => {
            if plane == 0 { (w, h, 1) } else { ((w + 1) >> 1, (h + 1) >> 1, 1) }
        }
        PIXFMT_YUV422P => {
            if plane == 0 { (w, h, 1) } else { ((w + 1) >> 1, h, 1) }
        }
        PIXFMT_YUV444P => (w, h, 1),
        PIXFMT_NV12 | PIXFMT_NV21 => {
            if plane == 0 { (w, h, 1) } else { ((w + 1) >> 1, (h + 1) >> 1, 2) }
        }
        PIXFMT_RGB24 | PIXFMT_BGR24 => (w, h, 3),
        PIXFMT_RGBA | PIXFMT_BGRA => (w, h, 4),
        PIXFMT_GRAY8 => (w, h, 1),
        _ => (0, 0, 0),
    }
}

#[inline]
fn clip_u8(v: i32) -> u8 {
    if v < 0 {
        0
    } else if v > 255 {
        255
    } else {
        v as u8
    }
}

#[inline]
fn rgb_to_y(r: u8, g: u8, b: u8) -> u8 {
    (((RY * r as i32 + GY * g as i32 + BY * b as i32 + (1 << 14)) >> 15) + 16) as u8
}

#[inline]
fn rgb_to_u_scaled(r: u8, g: u8, b: u8) -> i32 {
    (RU * r as i32 + GU * g as i32 + BU * b as i32 + (256 << 14) + (1 << 8)) >> 9
}

#[inline]
fn rgb_to_v_scaled(r: u8, g: u8, b: u8) -> i32 {
    (RV * r as i32 + GV * g as i32 + BV * b as i32 + (256 << 14) + (1 << 8)) >> 9
}

#[inline]
fn rgb_pair_to_u_scaled(r: i32, g: i32, b: i32) -> i32 {
    (RU * r + GU * g + BU * b + (256 << 15) + (1 << 9)) >> 10
}

#[inline]
fn rgb_pair_to_v_scaled(r: i32, g: i32, b: i32) -> i32 {
    (RV * r + GV * g + BV * b + (256 << 15) + (1 << 9)) >> 10
}

#[inline]
fn scaled_chroma_to_u8(v: i32) -> u8 {
    clip_u8((v + 32) >> 6)
}

#[inline]
fn filtered_chroma_to_u8(v: i32) -> u8 {
    clip_u8(v >> 19)
}

#[inline]
fn rgb_to_gray(r: u8, g: u8, b: u8) -> u8 {
    (((9798 * r as i32 + 19235 * g as i32 + 3735 * b as i32 + (1 << 14)) >> 15)
        .clamp(0, 255)) as u8
}

#[inline]
fn yuv_to_rgb(y: u8, u: u8, v: u8) -> (u8, u8, u8) {
    let c = y as i32 - 16;
    let d = u as i32 - 128;
    let e = v as i32 - 128;
    let r = (76309 * c + 104597 * e + 32768) >> 16;
    let g = (76309 * c - 25675 * d - 53279 * e + 32768) >> 16;
    let b = (76309 * c + 132201 * d + 32768) >> 16;
    (clip_u8(r), clip_u8(g), clip_u8(b))
}

#[inline]
fn yuv_to_rgb_table(y: u8, u: u8, v: u8) -> (u8, u8, u8) {
    let yy = y as i32 + 838;
    let uu = u as i32;
    let vv = v as i32;
    unsafe {
        (
            *YUV_RGB_TABLE.get_unchecked((yy - (YUV_RGB_CRV >> 9) + ((vv * YUV_RGB_CRV) >> 16)) as usize),
            *YUV_RGB_TABLE.get_unchecked((yy - (YUV_RGB_CGU >> 9) + ((uu * YUV_RGB_CGU) >> 16)
                - (YUV_RGB_CGV >> 9) + ((vv * YUV_RGB_CGV) >> 16)) as usize),
            *YUV_RGB_TABLE.get_unchecked((yy - (YUV_RGB_CBU >> 9) + ((uu * YUV_RGB_CBU) >> 16)) as usize),
        )
    }
}

#[inline]
fn clip_u30_i32_to_u8(v: i32) -> u8 {
    let clipped = if v < 0 {
        0
    } else if v > 0x3fff_ffffi32 {
        0x3fff_ffff
    } else {
        v
    };
    (clipped >> 22) as u8
}

#[inline]
fn yuv_to_rgb_full_chroma(y: u8, u: u8, v: u8) -> (u8, u8, u8) {
    yuv_to_rgb_full_values(
        (y as i32) << 9,
        ((u as i32) - 128) << 9,
        ((v as i32) - 128) << 9,
    )
}

#[inline]
fn yuv_to_rgb_full_values(y: i32, u: i32, v: i32) -> (u8, u8, u8) {
    const CY: i32 = 9539;
    const CRV: i32 = 13075;
    const CBU: i32 = 16525;
    const CGU: i32 = -3209;
    const CGV: i32 = -6660;

    let yy = y - 8192;
    let base = yy.wrapping_mul(CY).wrapping_add(1 << 21);
    let r = base.wrapping_add(v.wrapping_mul(CRV));
    let g = base
        .wrapping_add(v.wrapping_mul(CGV))
        .wrapping_add(u.wrapping_mul(CGU));
    let b = base.wrapping_add(u.wrapping_mul(CBU));
    (
        clip_u30_i32_to_u8(r),
        clip_u30_i32_to_u8(g),
        clip_u30_i32_to_u8(b),
    )
}

#[inline]
fn yuv_to_rgb_for_fmt(fmt: c_int, y: u8, u: u8, v: u8) -> (u8, u8, u8) {
    match fmt {
        PIXFMT_YUV420P | PIXFMT_YUV422P | PIXFMT_NV12 | PIXFMT_NV21 => yuv_to_rgb_table(y, u, v),
        PIXFMT_YUV444P => yuv_to_rgb_full_chroma(y, u, v),
        _ => yuv_to_rgb(y, u, v),
    }
}

#[inline]
fn yuv_luma_to_gray(y: u8) -> u8 {
    // FFmpeg's yuv420p->gray8 path expands limited-range luma to full-range gray.
    clip_u8((76309 * (y as i32 - 16) + 32768) >> 16)
}

#[inline]
unsafe fn row_ptr(ptr: *const u8, stride: c_int, y: usize) -> *const u8 {
    ptr.offset(y as isize * stride as isize)
}

#[inline]
unsafe fn row_mut(ptr: *mut u8, stride: c_int, y: usize) -> *mut u8 {
    ptr.offset(y as isize * stride as isize)
}

#[inline]
unsafe fn read_packed_rgb(src: *const u8, fmt: c_int, x: usize) -> (u8, u8, u8, u8) {
    let p = src.add(x * bytes_per_pixel(fmt));
    match fmt {
        PIXFMT_RGB24 => (*p, *p.add(1), *p.add(2), 255),
        PIXFMT_BGR24 => (*p.add(2), *p.add(1), *p, 255),
        PIXFMT_RGBA => (*p, *p.add(1), *p.add(2), *p.add(3)),
        PIXFMT_BGRA => (*p.add(2), *p.add(1), *p, *p.add(3)),
        PIXFMT_GRAY8 => {
            let y = *p;
            (y, y, y, 255)
        }
        _ => (0, 0, 0, 255),
    }
}

#[inline]
unsafe fn write_packed_rgb(dst: *mut u8, fmt: c_int, x: usize, r: u8, g: u8, b: u8, a: u8) {
    let p = dst.add(x * bytes_per_pixel(fmt));
    match fmt {
        PIXFMT_RGB24 => {
            *p = r;
            *p.add(1) = g;
            *p.add(2) = b;
        }
        PIXFMT_BGR24 => {
            *p = b;
            *p.add(1) = g;
            *p.add(2) = r;
        }
        PIXFMT_RGBA => {
            *p = r;
            *p.add(1) = g;
            *p.add(2) = b;
            *p.add(3) = a;
        }
        PIXFMT_BGRA => {
            *p = b;
            *p.add(1) = g;
            *p.add(2) = r;
            *p.add(3) = a;
        }
        PIXFMT_GRAY8 => *p = rgb_to_gray(r, g, b),
        _ => {}
    }
}

#[inline]
fn scale_nearest_pos(out: usize, in_len: usize, out_len: usize) -> usize {
    // FFmpeg point scaling is center-positioned; for 2:1 downscale this maps 0->1, 1->3, ...
    ((((2 * out + 1) as u64 * in_len as u64) / (2 * out_len) as u64)
        .min(in_len as u64 - 1)) as usize
}

#[inline]
fn scale_linear_pos(out: usize, in_len: usize, out_len: usize) -> (usize, usize, i32) {
    if out_len <= 1 || in_len <= 1 {
        return (0, 0, 0);
    }
    let fp = (((out as i64 * 2 + 1) * in_len as i64 - out_len as i64) << 15) / (2 * out_len as i64);
    let pos = fp >> 15;
    let frac = (fp & 32767) as i32;
    let x0 = pos.max(0).min(in_len as i64 - 1) as usize;
    let x1 = (pos + 1).max(0).min(in_len as i64 - 1) as usize;
    (x0, x1, frac)
}

#[inline]
fn lerp_u8(a: u8, b: u8, t: i32) -> u8 {
    (((a as i32 * (32768 - t) + b as i32 * t + 16384) >> 15).clamp(0, 255)) as u8
}

#[inline]
fn cubic_weight(x: f64) -> f64 {
    let x = x.abs();
    if x < 1.0 {
        ((12.0 - 3.6) * x * x * x + (-18.0 + 3.6) * x * x + 6.0) / 6.0
    } else if x < 2.0 {
        (-3.6 * x * x * x + 18.0 * x * x - 28.8 * x + 14.4) / 6.0
    } else {
        0.0
    }
}

#[inline]
fn cubic_pos(out: usize, in_len: usize, out_len: usize) -> (isize, f64) {
    if out_len <= 1 || in_len <= 1 {
        return (0, 0.0);
    }
    let pos = ((out as f64 + 0.5) * in_len as f64 / out_len as f64) - 0.5;
    (pos.floor() as isize, pos.fract())
}

unsafe fn copy_same(
    fmt: c_int,
    w: usize,
    h: usize,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    if fmt == PIXFMT_NV12 || fmt == PIXFMT_NV21 {
        for y in 0..h {
            ptr::copy_nonoverlapping(row_ptr(src[0], ss[0], y), row_mut(dst[0], ds[0], y), w);
        }
        return;
    }
    for p in 0..plane_count(fmt) {
        let (pw, ph, bpp) = plane_dims(fmt, p, w, h);
        let n = pw * bpp;
        for y in 0..ph {
            ptr::copy_nonoverlapping(row_ptr(src[p], ss[p], y), row_mut(dst[p], ds[p], y), n);
        }
    }
}

unsafe fn exact_rgb_convert(
    sf: c_int,
    df: c_int,
    w: usize,
    h: usize,
    src: *const u8,
    ss: c_int,
    dst: *mut u8,
    ds: c_int,
) -> bool {
    if kind(sf) != Kind::Rgb && sf != PIXFMT_GRAY8 {
        return false;
    }
    if kind(df) != Kind::Rgb && df != PIXFMT_GRAY8 {
        return false;
    }
    if sf == PIXFMT_GRAY8 && df == PIXFMT_GRAY8 {
        return false;
    }
    #[cfg(target_arch = "aarch64")]
    if sf == PIXFMT_GRAY8 && kind(df) == Kind::Rgb {
        for y in 0..h {
            gray8_to_packed_neon(row_ptr(src, ss, y), row_mut(dst, ds, y), df, w);
        }
        return true;
    }
    #[cfg(target_arch = "aarch64")]
    if kind(sf) == Kind::Rgb && df == PIXFMT_GRAY8 {
        for y in 0..h {
            rgb_to_gray8_neon(row_ptr(src, ss, y), sf, row_mut(dst, ds, y), w);
        }
        return true;
    }
    #[cfg(target_arch = "aarch64")]
    if matches!(sf, PIXFMT_RGB24 | PIXFMT_BGR24) && matches!(df, PIXFMT_RGB24 | PIXFMT_BGR24 | PIXFMT_RGBA | PIXFMT_BGRA) {
        for y in 0..h {
            packed_rgb_neon(row_ptr(src, ss, y), sf, row_mut(dst, ds, y), df, w);
        }
        return true;
    }
    #[cfg(target_arch = "aarch64")]
    if matches!(sf, PIXFMT_RGBA | PIXFMT_BGRA) && matches!(df, PIXFMT_RGB24 | PIXFMT_BGR24 | PIXFMT_RGBA | PIXFMT_BGRA) {
        for y in 0..h {
            packed_rgb_neon(row_ptr(src, ss, y), sf, row_mut(dst, ds, y), df, w);
        }
        return true;
    }
    if sf == PIXFMT_RGB24 && df == PIXFMT_BGRA {
        for y in 0..h {
            let sr = row_ptr(src, ss, y);
            let dr = row_mut(dst, ds, y);
            for x in 0..w.saturating_sub(1) {
                let packed = ptr::read_unaligned(sr.add(x * 3) as *const u32);
                let output = (packed & 0xff00) | ((packed & 0xff) << 16)
                    | ((packed >> 16) & 0xff) | 0xff00_0000;
                ptr::write_unaligned(dr.add(x * 4) as *mut u32, output);
            }
            if w != 0 {
                let x = w - 1;
                let packed = *sr.add(x * 3) as u32
                    | ((*sr.add(x * 3 + 1) as u32) << 8)
                    | ((*sr.add(x * 3 + 2) as u32) << 16);
                let output = (packed & 0xff00) | ((packed & 0xff) << 16)
                    | ((packed >> 16) & 0xff) | 0xff00_0000;
                ptr::write_unaligned(dr.add(x * 4) as *mut u32, output);
            }
        }
        return true;
    }
    for y in 0..h {
        let sr = row_ptr(src, ss, y);
        let dr = row_mut(dst, ds, y);
        for x in 0..w {
            let (r, g, b, a0) = read_packed_rgb(sr, sf, x);
            let a = if matches!(df, PIXFMT_RGBA | PIXFMT_BGRA) {
                if matches!(sf, PIXFMT_RGBA | PIXFMT_BGRA) { a0 } else { 255 }
            } else {
                255
            };
            if df == PIXFMT_GRAY8 {
                *dr.add(x) = rgb_to_gray(r, g, b);
            } else {
                write_packed_rgb(dr, df, x, r, g, b, a);
            }
        }
    }
    true
}

#[cfg(target_arch = "aarch64")]
unsafe fn packed_rgb_neon(source: *const u8, sf: c_int, output: *mut u8, df: c_int, width: usize) {
    let source_bpp = bytes_per_pixel(sf);
    let dest_bpp = bytes_per_pixel(df);
    let mut x = 0;
    while x + 16 <= width {
        let (red, green, blue, alpha) = if source_bpp == 3 {
            let values = vld3q_u8(source.add(x * 3));
            if sf == PIXFMT_RGB24 {
                (values.0, values.1, values.2, vdupq_n_u8(255))
            } else {
                (values.2, values.1, values.0, vdupq_n_u8(255))
            }
        } else {
            let values = vld4q_u8(source.add(x * 4));
            if sf == PIXFMT_RGBA {
                (values.0, values.1, values.2, values.3)
            } else {
                (values.2, values.1, values.0, values.3)
            }
        };
        if dest_bpp == 3 {
            let values = if df == PIXFMT_RGB24 {
                uint8x16x3_t(red, green, blue)
            } else {
                uint8x16x3_t(blue, green, red)
            };
            vst3q_u8(output.add(x * 3), values);
        } else {
            let values = if df == PIXFMT_RGBA {
                uint8x16x4_t(red, green, blue, alpha)
            } else {
                uint8x16x4_t(blue, green, red, alpha)
            };
            vst4q_u8(output.add(x * 4), values);
        }
        x += 16;
    }
    while x < width {
        let (red, green, blue, source_alpha) = read_packed_rgb(source, sf, x);
        let alpha = if dest_bpp == 4 { source_alpha } else { 255 };
        write_packed_rgb(output, df, x, red, green, blue, alpha);
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn gray_coefficients_neon(red: uint8x8_t, green: uint8x8_t, blue: uint8x8_t) -> uint8x8_t {
    let red = vmovl_u8(red);
    let green = vmovl_u8(green);
    let blue = vmovl_u8(blue);
    let calculate = |r: uint16x4_t, g: uint16x4_t, b: uint16x4_t| {
        let sum = vmlal_n_u16(vmlal_n_u16(vmull_n_u16(r, 9798), g, 19235), b, 3735);
        vshrn_n_u32::<15>(vaddq_u32(sum, vdupq_n_u32(1 << 14)))
    };
    vmovn_u16(vcombine_u16(
        calculate(vget_low_u16(red), vget_low_u16(green), vget_low_u16(blue)),
        calculate(vget_high_u16(red), vget_high_u16(green), vget_high_u16(blue)),
    ))
}

#[cfg(target_arch = "aarch64")]
unsafe fn rgb_to_gray8_neon(source: *const u8, sf: c_int, output: *mut u8, width: usize) {
    let source_bpp = bytes_per_pixel(sf);
    let mut x = 0;
    while x + 8 <= width {
        let (red, green, blue) = if source_bpp == 3 {
            let values = vld3_u8(source.add(x * 3));
            if sf == PIXFMT_RGB24 { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        } else {
            let values = vld4_u8(source.add(x * 4));
            if sf == PIXFMT_RGBA { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        };
        vst1_u8(output.add(x), gray_coefficients_neon(red, green, blue));
        x += 8;
    }
    while x < width {
        let (red, green, blue, _) = read_packed_rgb(source, sf, x);
        *output.add(x) = rgb_to_gray(red, green, blue);
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn gray8_to_packed_neon(source: *const u8, output: *mut u8, df: c_int, width: usize) {
    let bpp = bytes_per_pixel(df);
    let mut x = 0;
    while x + 16 <= width {
        let gray = vld1q_u8(source.add(x));
        if bpp == 3 {
            vst3q_u8(output.add(x * 3), uint8x16x3_t(gray, gray, gray));
        } else {
            vst4q_u8(output.add(x * 4), uint8x16x4_t(gray, gray, gray, vdupq_n_u8(255)));
        }
        x += 16;
    }
    while x < width {
        let gray = *source.add(x);
        write_packed_rgb(output, df, x, gray, gray, gray, 255);
        x += 1;
    }
}

unsafe fn planar_nv_convert(
    sf: c_int,
    df: c_int,
    w: usize,
    h: usize,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) -> bool {
    let src_nv = sf == PIXFMT_NV12 || sf == PIXFMT_NV21;
    let dst_nv = df == PIXFMT_NV12 || df == PIXFMT_NV21;
    let src_420 = sf == PIXFMT_YUV420P;
    let dst_420 = df == PIXFMT_YUV420P;
    if !(src_nv || src_420) || !(dst_nv || dst_420) {
        return false;
    }
    for y in 0..h {
        ptr::copy_nonoverlapping(row_ptr(src[0], ss[0], y), row_mut(dst[0], ds[0], y), w);
    }
    let cw = w >> 1;
    let ch = h >> 1;
    for y in 0..ch {
        if src_420 && dst_nv {
            let u = row_ptr(src[1], ss[1], y);
            let v = row_ptr(src[2], ss[2], y);
            let d = row_mut(dst[1], ds[1], y);
            #[cfg(target_arch = "aarch64")]
            {
                planar_to_nv_neon(u, v, d, cw, df == PIXFMT_NV21);
                continue;
            }
            #[cfg(not(target_arch = "aarch64"))]
            for x in 0..cw {
                if df == PIXFMT_NV12 {
                    *d.add(2 * x) = *u.add(x);
                    *d.add(2 * x + 1) = *v.add(x);
                } else {
                    *d.add(2 * x) = *v.add(x);
                    *d.add(2 * x + 1) = *u.add(x);
                }
            }
        } else if src_nv && dst_420 {
            let s = row_ptr(src[1], ss[1], y);
            let u = row_mut(dst[1], ds[1], y);
            let v = row_mut(dst[2], ds[2], y);
            #[cfg(target_arch = "aarch64")]
            {
                nv_to_planar_neon(s, u, v, cw, sf == PIXFMT_NV21);
                continue;
            }
            #[cfg(not(target_arch = "aarch64"))]
            for x in 0..cw {
                if sf == PIXFMT_NV12 {
                    *u.add(x) = *s.add(2 * x);
                    *v.add(x) = *s.add(2 * x + 1);
                } else {
                    *v.add(x) = *s.add(2 * x);
                    *u.add(x) = *s.add(2 * x + 1);
                }
            }
        } else if src_nv && dst_nv {
            let s = row_ptr(src[1], ss[1], y);
            let d = row_mut(dst[1], ds[1], y);
            if sf == df {
                ptr::copy_nonoverlapping(s, d, w);
            } else {
                #[cfg(target_arch = "aarch64")]
                {
                    swap_nv_neon(s, d, cw);
                    continue;
                }
                #[cfg(not(target_arch = "aarch64"))]
                for x in 0..cw {
                    *d.add(2 * x) = *s.add(2 * x + 1);
                    *d.add(2 * x + 1) = *s.add(2 * x);
                }
            }
        }
    }
    true
}

#[cfg(target_arch = "aarch64")]
unsafe fn planar_to_nv_neon(u: *const u8, v: *const u8, output: *mut u8, length: usize, reverse: bool) {
    let mut offset = 0;
    while offset + 16 <= length {
        let first = vld1q_u8(u.add(offset));
        let second = vld1q_u8(v.add(offset));
        let pair = if reverse { uint8x16x2_t(second, first) } else { uint8x16x2_t(first, second) };
        vst2q_u8(output.add(offset * 2), pair);
        offset += 16;
    }
    while offset < length {
        if reverse {
            *output.add(offset * 2) = *v.add(offset);
            *output.add(offset * 2 + 1) = *u.add(offset);
        } else {
            *output.add(offset * 2) = *u.add(offset);
            *output.add(offset * 2 + 1) = *v.add(offset);
        }
        offset += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn nv_to_planar_neon(source: *const u8, u: *mut u8, v: *mut u8, length: usize, reverse: bool) {
    let mut offset = 0;
    while offset + 16 <= length {
        let pair = vld2q_u8(source.add(offset * 2));
        if reverse {
            vst1q_u8(v.add(offset), pair.0);
            vst1q_u8(u.add(offset), pair.1);
        } else {
            vst1q_u8(u.add(offset), pair.0);
            vst1q_u8(v.add(offset), pair.1);
        }
        offset += 16;
    }
    while offset < length {
        if reverse {
            *v.add(offset) = *source.add(offset * 2);
            *u.add(offset) = *source.add(offset * 2 + 1);
        } else {
            *u.add(offset) = *source.add(offset * 2);
            *v.add(offset) = *source.add(offset * 2 + 1);
        }
        offset += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn swap_nv_neon(source: *const u8, output: *mut u8, length: usize) {
    let mut offset = 0;
    while offset + 16 <= length {
        let pair = vld2q_u8(source.add(offset * 2));
        vst2q_u8(output.add(offset * 2), uint8x16x2_t(pair.1, pair.0));
        offset += 16;
    }
    while offset < length {
        *output.add(offset * 2) = *source.add(offset * 2 + 1);
        *output.add(offset * 2 + 1) = *source.add(offset * 2);
        offset += 1;
    }
}

#[inline]
unsafe fn sample_yuv(src: &[*const u8; 4], ss: &[c_int; 4], fmt: c_int, x: usize, y: usize) -> (u8, u8, u8) {
    if fmt == PIXFMT_GRAY8 {
        let yy = *row_ptr(src[0], ss[0], y).add(x);
        return (yy, 128, 128);
    }
    let yy = *row_ptr(src[0], ss[0], y).add(x);
    let (xs, ys) = chroma_shift(fmt);
    let cx = x >> xs;
    let cy = y >> ys;
    match fmt {
        PIXFMT_NV12 => {
            let uv = row_ptr(src[1], ss[1], cy).add(cx * 2);
            (yy, *uv, *uv.add(1))
        }
        PIXFMT_NV21 => {
            let uv = row_ptr(src[1], ss[1], cy).add(cx * 2);
            (yy, *uv.add(1), *uv)
        }
        _ => {
            let u = *row_ptr(src[1], ss[1], cy).add(cx);
            let v = *row_ptr(src[2], ss[2], cy).add(cx);
            (yy, u, v)
        }
    }
}

#[inline]
unsafe fn sample_yuv_for_rgb(
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    fmt: c_int,
    x: usize,
    y: usize,
    h: usize,
) -> (u8, u8, u8) {
    if fmt != PIXFMT_NV12 && fmt != PIXFMT_NV21 {
        return sample_yuv(src, ss, fmt, x, y);
    }
    let yy = *row_ptr(src[0], ss[0], y).add(x);
    let cx = x >> 1;
    let cy0 = y >> 1;
    let (ca, cb) = if y <= 1 {
        (cy0, cy0)
    } else if (y & 1) == 0 {
        (cy0 - 1, cy0)
    } else if y + 1 >= h && cy0 > 0 {
        (cy0 - 1, cy0)
    } else {
        (cy0, cy0)
    };
    let pa = row_ptr(src[1], ss[1], ca).add(cx * 2);
    let pb = row_ptr(src[1], ss[1], cb).add(cx * 2);
    let (u0, v0, u1, v1) = if fmt == PIXFMT_NV12 {
        (*pa as u16, *pa.add(1) as u16, *pb as u16, *pb.add(1) as u16)
    } else {
        (*pa.add(1) as u16, *pa as u16, *pb.add(1) as u16, *pb as u16)
    };
    (yy, ((u0 + u1 + 1) >> 1) as u8, ((v0 + v1 + 1) >> 1) as u8)
}

#[inline]
unsafe fn sample_rgb(src: &[*const u8; 4], ss: &[c_int; 4], fmt: c_int, x: usize, y: usize) -> (u8, u8, u8) {
    match kind(fmt) {
        Kind::Rgb | Kind::Gray => {
            let row = row_ptr(src[0], ss[0], y);
            let (r, g, b, _) = read_packed_rgb(row, fmt, x);
            (r, g, b)
        }
        Kind::Yuv => {
            let (yy, u, v) = sample_yuv(src, ss, fmt, x, y);
            yuv_to_rgb_for_fmt(fmt, yy, u, v)
        }
    }
}

unsafe fn convert_yuv_to_packed(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    if ctx.dst_fmt == PIXFMT_GRAY8 {
        for y in 0..ctx.dst_h {
            let source = row_ptr(src[0], ss[0], y);
            let output = row_mut(dst[0], ds[0], y);
            #[cfg(target_arch = "aarch64")]
            {
                yuv_luma_to_gray_neon(source, output, ctx.dst_w);
                continue;
            }
            #[cfg(not(target_arch = "aarch64"))]
            for x in 0..ctx.dst_w {
                *output.add(x) = yuv_luma_to_gray(*source.add(x));
            }
        }
        return;
    }
    if ctx.src_fmt == PIXFMT_YUV420P
        && kind(ctx.dst_fmt) == Kind::Rgb
        && ctx.src_w == ctx.dst_w
        && ctx.src_h == ctx.dst_h
    {
        let output_bpp = bytes_per_pixel(ctx.dst_fmt);
        for y in (0..ctx.dst_h).step_by(2) {
            let y0 = row_ptr(src[0], ss[0], y);
            let y1 = row_ptr(src[0], ss[0], (y + 1).min(ctx.dst_h - 1));
            let ur = row_ptr(src[1], ss[1], y >> 1);
            let vr = row_ptr(src[2], ss[2], y >> 1);
            let d0 = row_mut(dst[0], ds[0], y);
            let d1 = row_mut(dst[0], ds[0], (y + 1).min(ctx.dst_h - 1));
            #[cfg(target_arch = "aarch64")]
            {
                let mut cx = 0;
                while cx + 8 <= (ctx.dst_w >> 1) {
                    let uu = vcombine_u8(vld1_u8(ur.add(cx)), vdup_n_u8(0));
                    let vv = vcombine_u8(vld1_u8(vr.add(cx)), vdup_n_u8(0));
                    let uu = expand_u8_to_i32x4(vzip1q_u8(uu, uu));
                    let vv = expand_u8_to_i32x4(vzip1q_u8(vv, vv));
                    let mut red_offsets = [vdupq_n_s32(0); 4];
                    let mut green_offsets = [vdupq_n_s32(0); 4];
                    let mut blue_offsets = [vdupq_n_s32(0); 4];
                    for group in 0..4 {
                        red_offsets[group] = vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(vv[group], YUV_RGB_CRV)), vdupq_n_s32(-(YUV_RGB_CRV >> 9)));
                        green_offsets[group] = vaddq_s32(
                            vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(uu[group], YUV_RGB_CGU)), vdupq_n_s32(-(YUV_RGB_CGU >> 9))),
                            vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(vv[group], YUV_RGB_CGV)), vdupq_n_s32(-(YUV_RGB_CGV >> 9))),
                        );
                        blue_offsets[group] = vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(uu[group], YUV_RGB_CBU)), vdupq_n_s32(-(YUV_RGB_CBU >> 9)));
                    }
                    yuv_table_row16_neon(y0.add(cx * 2), d0.add(cx * 2 * output_bpp), ctx.dst_fmt, red_offsets, green_offsets, blue_offsets);
                    yuv_table_row16_neon(y1.add(cx * 2), d1.add(cx * 2 * output_bpp), ctx.dst_fmt, red_offsets, green_offsets, blue_offsets);
                    cx += 8;
                }
                while cx < (ctx.dst_w >> 1) {
                    yuv420_block_scalar(y0, y1, ur, vr, d0, d1, ctx.dst_fmt, cx);
                    cx += 1;
                }
                continue;
            }
            #[cfg(not(target_arch = "aarch64"))]
            for cx in 0..((ctx.dst_w + 1) >> 1) {
                yuv420_block_scalar(y0, y1, ur, vr, d0, d1, ctx.dst_fmt, cx);
            }
        }
        return;
    }
    if ctx.src_fmt == PIXFMT_YUV422P
        && kind(ctx.dst_fmt) == Kind::Rgb
        && ctx.src_w == ctx.dst_w
        && ctx.src_h == ctx.dst_h
    {
        for y in 0..ctx.dst_h {
            let luma = row_ptr(src[0], ss[0], y);
            let u = row_ptr(src[1], ss[1], y);
            let v = row_ptr(src[2], ss[2], y);
            let output = row_mut(dst[0], ds[0], y);
            for cx in 0..(ctx.dst_w >> 1) {
                let x = cx * 2;
                let uu = *u.add(cx) as i32;
                let vv = *v.add(cx) as i32;
                let red_offset = -(YUV_RGB_CRV >> 9) + ((vv * YUV_RGB_CRV) >> 16);
                let green_offset = -(YUV_RGB_CGU >> 9) + ((uu * YUV_RGB_CGU) >> 16)
                    - (YUV_RGB_CGV >> 9) + ((vv * YUV_RGB_CGV) >> 16);
                let blue_offset = -(YUV_RGB_CBU >> 9) + ((uu * YUV_RGB_CBU) >> 16);
                for pixel in 0..2 {
                    let yy = *luma.add(x + pixel) as i32 + 838;
                    let destination = output.add((x + pixel) * bytes_per_pixel(ctx.dst_fmt));
                    let red = *YUV_RGB_TABLE.get_unchecked((yy + red_offset) as usize);
                    let green = *YUV_RGB_TABLE.get_unchecked((yy + green_offset) as usize);
                    let blue = *YUV_RGB_TABLE.get_unchecked((yy + blue_offset) as usize);
                    write_packed_rgb(destination, ctx.dst_fmt, 0, red, green, blue, 255);
                }
            }
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if matches!(ctx.src_fmt, PIXFMT_NV12 | PIXFMT_NV21)
        && kind(ctx.dst_fmt) == Kind::Rgb
        && ctx.src_w == ctx.dst_w
        && ctx.src_h == ctx.dst_h
    {
        for y in 0..ctx.dst_h {
            let chroma_y = y >> 1;
            let (row_a, row_b) = if y <= 1 {
                (chroma_y, chroma_y)
            } else if y & 1 == 0 {
                (chroma_y - 1, chroma_y)
            } else if y + 1 >= ctx.src_h && chroma_y > 0 {
                (chroma_y - 1, chroma_y)
            } else {
                (chroma_y, chroma_y)
            };
            nv_to_rgb24_row_neon(
                row_ptr(src[0], ss[0], y), row_ptr(src[1], ss[1], row_a), row_ptr(src[1], ss[1], row_b),
                ctx.src_fmt == PIXFMT_NV21, row_mut(dst[0], ds[0], y), ctx.dst_fmt, ctx.dst_w,
            );
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    if ctx.src_fmt == PIXFMT_YUV444P
        && kind(ctx.dst_fmt) == Kind::Rgb
        && ctx.src_w == ctx.dst_w
        && ctx.src_h == ctx.dst_h
    {
        for y in 0..ctx.dst_h {
            yuv444p_to_rgb24_neon(
                row_ptr(src[0], ss[0], y), row_ptr(src[1], ss[1], y), row_ptr(src[2], ss[2], y),
                row_mut(dst[0], ds[0], y), ctx.dst_fmt, ctx.dst_w,
            );
        }
        return;
    }
    for y in 0..ctx.dst_h {
        let sy = if ctx.src_h == ctx.dst_h { y } else { scale_nearest_pos(y, ctx.src_h, ctx.dst_h) };
        let dr = row_mut(dst[0], ds[0], y);
        for x in 0..ctx.dst_w {
            let sx = if ctx.src_w == ctx.dst_w { x } else { scale_nearest_pos(x, ctx.src_w, ctx.dst_w) };
            let (yy, u, v) = sample_yuv_for_rgb(src, ss, ctx.src_fmt, sx, sy, ctx.src_h);
            if ctx.dst_fmt == PIXFMT_GRAY8 {
                *dr.add(x) = yuv_luma_to_gray(yy);
            } else {
                let (r, g, b) = yuv_to_rgb_for_fmt(ctx.src_fmt, yy, u, v);
                write_packed_rgb(dr, ctx.dst_fmt, x, r, g, b, 255);
            }
        }
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn yuv_luma_to_gray_neon(source: *const u8, output: *mut u8, width: usize) {
    let mut x = 0;
    while x + 8 <= width {
        let values = vmovl_u8(vld1_u8(source.add(x)));
        let calculate = |value: uint16x4_t| {
            let value = vreinterpretq_s32_u32(vmovl_u16(value));
            let value = vshrq_n_s32::<16>(vaddq_s32(vmulq_n_s32(vsubq_s32(value, vdupq_n_s32(16)), 76309), vdupq_n_s32(32768)));
            vminq_s32(vmaxq_s32(value, vdupq_n_s32(0)), vdupq_n_s32(255))
        };
        let low = calculate(vget_low_u16(values));
        let high = calculate(vget_high_u16(values));
        vst1_u8(output.add(x), vqmovun_s16(vcombine_s16(vqmovn_s32(low), vqmovn_s32(high))));
        x += 8;
    }
    while x < width {
        *output.add(x) = yuv_luma_to_gray(*source.add(x));
        x += 1;
    }
}

#[inline]
unsafe fn yuv420_block_scalar(y0: *const u8, y1: *const u8, u: *const u8, v: *const u8, d0: *mut u8, d1: *mut u8, fmt: c_int, cx: usize) {
    let x = cx * 2;
    let uu = *u.add(cx) as i32;
    let vv = *v.add(cx) as i32;
    let red_offset = -(YUV_RGB_CRV >> 9) + ((vv * YUV_RGB_CRV) >> 16);
    let green_offset = -(YUV_RGB_CGU >> 9) + ((uu * YUV_RGB_CGU) >> 16) - (YUV_RGB_CGV >> 9) + ((vv * YUV_RGB_CGV) >> 16);
    let blue_offset = -(YUV_RGB_CBU >> 9) + ((uu * YUV_RGB_CBU) >> 16);
    let luma = [*y0.add(x), *y0.add(x + 1), *y1.add(x), *y1.add(x + 1)];
    let bpp = bytes_per_pixel(fmt);
    let output = [d0.add(x * bpp), d0.add((x + 1) * bpp), d1.add(x * bpp), d1.add((x + 1) * bpp)];
    for pixel in 0..4 {
        let yy = luma[pixel] as i32 + 838;
        let red = *YUV_RGB_TABLE.get_unchecked((yy + red_offset) as usize);
        let green = *YUV_RGB_TABLE.get_unchecked((yy + green_offset) as usize);
        let blue = *YUV_RGB_TABLE.get_unchecked((yy + blue_offset) as usize);
        write_packed_rgb(output[pixel], fmt, 0, red, green, blue, 255);
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn expand_u8_to_i32x4(values: uint8x16_t) -> [int32x4_t; 4] {
    let low = vmovl_u8(vget_low_u8(values));
    let high = vmovl_u8(vget_high_u8(values));
    [
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(low))),
        vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(low))),
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(high))),
        vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(high))),
    ]
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn yuv_table_values_neon(luma: uint8x16_t, offsets: [int32x4_t; 4]) -> uint8x16_t {
    const TABLE_BIAS: i32 = -(384 << 16) - 512 * YUV_RGB_CY - (16 << 16) + 0x8000;
    let luma = expand_u8_to_i32x4(luma);
    let mut values = [vdupq_n_s32(0); 4];
    for group in 0..4 {
        let index = vaddq_s32(vaddq_s32(luma[group], offsets[group]), vdupq_n_s32(838));
        let value = vshrq_n_s32::<16>(vaddq_s32(vmulq_n_s32(index, YUV_RGB_CY), vdupq_n_s32(TABLE_BIAS)));
        values[group] = vminq_s32(vmaxq_s32(value, vdupq_n_s32(0)), vdupq_n_s32(255));
    }
    let low = vcombine_s16(vqmovn_s32(values[0]), vqmovn_s32(values[1]));
    let high = vcombine_s16(vqmovn_s32(values[2]), vqmovn_s32(values[3]));
    vcombine_u8(vqmovun_s16(low), vqmovun_s16(high))
}

#[cfg(target_arch = "aarch64")]
unsafe fn yuv_table_row16_neon(
    luma: *const u8, output: *mut u8, fmt: c_int,
    red_offsets: [int32x4_t; 4], green_offsets: [int32x4_t; 4], blue_offsets: [int32x4_t; 4],
) {
    let luma = vld1q_u8(luma);
    let red = yuv_table_values_neon(luma, red_offsets);
    let green = yuv_table_values_neon(luma, green_offsets);
    let blue = yuv_table_values_neon(luma, blue_offsets);
    match fmt {
        PIXFMT_RGB24 => vst3q_u8(output, uint8x16x3_t(red, green, blue)),
        PIXFMT_BGR24 => vst3q_u8(output, uint8x16x3_t(blue, green, red)),
        PIXFMT_RGBA => vst4q_u8(output, uint8x16x4_t(red, green, blue, vdupq_n_u8(255))),
        PIXFMT_BGRA => vst4q_u8(output, uint8x16x4_t(blue, green, red, vdupq_n_u8(255))),
        _ => {}
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn yuv420_row_neon(
    luma: *const u8, u: *const u8, v: *const u8, output: *mut u8, fmt: c_int, width: usize,
) {
    let mut cx = 0;
    while cx + 8 <= (width >> 1) {
        let uu = expand_u8_to_i32x4(vzip1q_u8(vcombine_u8(vld1_u8(u.add(cx)), vdup_n_u8(0)), vcombine_u8(vld1_u8(u.add(cx)), vdup_n_u8(0))));
        let vv = expand_u8_to_i32x4(vzip1q_u8(vcombine_u8(vld1_u8(v.add(cx)), vdup_n_u8(0)), vcombine_u8(vld1_u8(v.add(cx)), vdup_n_u8(0))));
        let mut red_offsets = [vdupq_n_s32(0); 4];
        let mut green_offsets = [vdupq_n_s32(0); 4];
        let mut blue_offsets = [vdupq_n_s32(0); 4];
        for group in 0..4 {
            red_offsets[group] = vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(vv[group], YUV_RGB_CRV)), vdupq_n_s32(-(YUV_RGB_CRV >> 9)));
            green_offsets[group] = vaddq_s32(
                vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(uu[group], YUV_RGB_CGU)), vdupq_n_s32(-(YUV_RGB_CGU >> 9))),
                vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(vv[group], YUV_RGB_CGV)), vdupq_n_s32(-(YUV_RGB_CGV >> 9))),
            );
            blue_offsets[group] = vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(uu[group], YUV_RGB_CBU)), vdupq_n_s32(-(YUV_RGB_CBU >> 9)));
        }
        yuv_table_row16_neon(
            luma.add(cx * 2), output.add(cx * 2 * bytes_per_pixel(fmt)), fmt,
            red_offsets, green_offsets, blue_offsets,
        );
        cx += 8;
    }
    for x in cx * 2..width {
        let (red, green, blue) = yuv_to_rgb_table(*luma.add(x), *u.add(x >> 1), *v.add(x >> 1));
        write_packed_rgb(output, fmt, x, red, green, blue, 255);
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn nv_to_rgb24_row_neon(
    luma: *const u8, chroma_a: *const u8, chroma_b: *const u8,
    reverse: bool, output: *mut u8, fmt: c_int, width: usize,
) {
    let mut x = 0;
    while x + 16 <= width {
        let first = vld2_u8(chroma_a.add(x));
        let second = vld2_u8(chroma_b.add(x));
        let (u, v) = if reverse {
            (vrhadd_u8(first.1, second.1), vrhadd_u8(first.0, second.0))
        } else {
            (vrhadd_u8(first.0, second.0), vrhadd_u8(first.1, second.1))
        };
        let u = vcombine_u8(u, vdup_n_u8(0));
        let v = vcombine_u8(v, vdup_n_u8(0));
        let u = expand_u8_to_i32x4(vzip1q_u8(u, u));
        let v = expand_u8_to_i32x4(vzip1q_u8(v, v));
        let mut red_offsets = [vdupq_n_s32(0); 4];
        let mut green_offsets = [vdupq_n_s32(0); 4];
        let mut blue_offsets = [vdupq_n_s32(0); 4];
        for group in 0..4 {
            red_offsets[group] = vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(v[group], YUV_RGB_CRV)), vdupq_n_s32(-(YUV_RGB_CRV >> 9)));
            green_offsets[group] = vaddq_s32(
                vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(u[group], YUV_RGB_CGU)), vdupq_n_s32(-(YUV_RGB_CGU >> 9))),
                vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(v[group], YUV_RGB_CGV)), vdupq_n_s32(-(YUV_RGB_CGV >> 9))),
            );
            blue_offsets[group] = vaddq_s32(vshrq_n_s32::<16>(vmulq_n_s32(u[group], YUV_RGB_CBU)), vdupq_n_s32(-(YUV_RGB_CBU >> 9)));
        }
        yuv_table_row16_neon(luma.add(x), output.add(x * bytes_per_pixel(fmt)), fmt, red_offsets, green_offsets, blue_offsets);
        x += 16;
    }
    while x < width {
        let chroma = x & !1;
        let (a0, a1) = (*chroma_a.add(chroma), *chroma_a.add(chroma + 1));
        let (b0, b1) = (*chroma_b.add(chroma), *chroma_b.add(chroma + 1));
        let (u, v) = if reverse {
            (((a1 as u16 + b1 as u16 + 1) >> 1) as u8, ((a0 as u16 + b0 as u16 + 1) >> 1) as u8)
        } else {
            (((a0 as u16 + b0 as u16 + 1) >> 1) as u8, ((a1 as u16 + b1 as u16 + 1) >> 1) as u8)
        };
        let (red, green, blue) = yuv_to_rgb_table(*luma.add(x), u, v);
        write_packed_rgb(output, fmt, x, red, green, blue, 255);
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn full_chroma_rgb4_neon(y: uint16x4_t, u: uint16x4_t, v: uint16x4_t) -> (uint16x4_t, uint16x4_t, uint16x4_t) {
    let y = vreinterpretq_s32_u32(vmovl_u16(y));
    let u = vreinterpretq_s32_u32(vmovl_u16(u));
    let v = vreinterpretq_s32_u32(vmovl_u16(v));
    let y = vsubq_s32(vshlq_n_s32::<9>(y), vdupq_n_s32(8192));
    let u = vshlq_n_s32::<9>(vsubq_s32(u, vdupq_n_s32(128)));
    let v = vshlq_n_s32::<9>(vsubq_s32(v, vdupq_n_s32(128)));
    let base = vaddq_s32(vmulq_n_s32(y, 9539), vdupq_n_s32(1 << 21));
    let clip = |value: int32x4_t| {
        let value = vmaxq_s32(value, vdupq_n_s32(0));
        let value = vminq_s32(value, vdupq_n_s32(0x3fff_ffff));
        vmovn_u32(vshrq_n_u32::<22>(vreinterpretq_u32_s32(value)))
    };
    (
        clip(vmlaq_n_s32(base, v, 13075)),
        clip(vmlaq_n_s32(vmlaq_n_s32(base, v, -6660), u, -3209)),
        clip(vmlaq_n_s32(base, u, 16525)),
    )
}

#[cfg(target_arch = "aarch64")]
unsafe fn yuv444p_to_rgb24_neon(y: *const u8, u: *const u8, v: *const u8, output: *mut u8, fmt: c_int, width: usize) {
    let mut x = 0;
    while x + 8 <= width {
        let yy = vmovl_u8(vld1_u8(y.add(x)));
        let uu = vmovl_u8(vld1_u8(u.add(x)));
        let vv = vmovl_u8(vld1_u8(v.add(x)));
        let low = full_chroma_rgb4_neon(vget_low_u16(yy), vget_low_u16(uu), vget_low_u16(vv));
        let high = full_chroma_rgb4_neon(vget_high_u16(yy), vget_high_u16(uu), vget_high_u16(vv));
        let red = vmovn_u16(vcombine_u16(low.0, high.0));
        let green = vmovn_u16(vcombine_u16(low.1, high.1));
        let blue = vmovn_u16(vcombine_u16(low.2, high.2));
        match fmt {
            PIXFMT_RGB24 => vst3_u8(output.add(x * 3), uint8x8x3_t(red, green, blue)),
            PIXFMT_BGR24 => vst3_u8(output.add(x * 3), uint8x8x3_t(blue, green, red)),
            PIXFMT_RGBA => vst4_u8(output.add(x * 4), uint8x8x4_t(red, green, blue, vdup_n_u8(255))),
            PIXFMT_BGRA => vst4_u8(output.add(x * 4), uint8x8x4_t(blue, green, red, vdup_n_u8(255))),
            _ => {}
        }
        x += 8;
    }
    while x < width {
        let (red, green, blue) = yuv_to_rgb_full_chroma(*y.add(x), *u.add(x), *v.add(x));
        write_packed_rgb(output, fmt, x, red, green, blue, 255);
        x += 1;
    }
}

unsafe fn convert_packed_to_yuv_same_size(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let (xs, ys) = chroma_shift(ctx.dst_fmt);
    let bgr24_yv12 = ctx.src_fmt == PIXFMT_BGR24 && ctx.dst_fmt == PIXFMT_YUV420P;
    for y in 0..ctx.dst_h {
        let sr = row_ptr(src[0], ss[0], y);
        let dy = row_mut(dst[0], ds[0], y);
        #[cfg(target_arch = "aarch64")]
        if kind(ctx.src_fmt) == Kind::Rgb && ctx.dst_fmt != PIXFMT_GRAY8 {
            packed_to_luma_neon(sr, ctx.src_fmt, dy, ctx.dst_w, bgr24_yv12);
            continue;
        }
        for x in 0..ctx.dst_w {
            let (r, g, b, _) = read_packed_rgb(sr, ctx.src_fmt, x);
            *dy.add(x) = if ctx.dst_fmt == PIXFMT_GRAY8 {
                rgb_to_gray(r, g, b)
            } else if bgr24_yv12 {
                let yv = ((RY * r as i32 + GY * g as i32 + BY * b as i32) >> 15) + 16;
                clip_u8(yv)
            } else {
                rgb_to_y(r, g, b)
            };
        }
    }
    if ctx.dst_fmt == PIXFMT_GRAY8 {
        return;
    }

    let cw = (ctx.dst_w + (1 << xs) - 1) >> xs;
    let ch = (ctx.dst_h + (1 << ys) - 1) >> ys;

    if bgr24_yv12 {
        for cy in 0..ch {
            let sr0 = row_ptr(src[0], ss[0], (cy * 2).min(ctx.dst_h - 1));
            let sr1 = row_ptr(src[0], ss[0], (cy * 2 + 1).min(ctx.dst_h - 1));
            for cx in 0..cw {
                let x0 = cx * 2;
                let x1 = (x0 + 1).min(ctx.dst_w - 1);
                let (r11, g11, b11, _) = read_packed_rgb(sr0, ctx.src_fmt, x0);
                let (r12, g12, b12, _) = read_packed_rgb(sr0, ctx.src_fmt, x1);
                let (r21, g21, b21, _) = read_packed_rgb(sr1, ctx.src_fmt, x0);
                let (r22, g22, b22, _) = read_packed_rgb(sr1, ctx.src_fmt, x1);
                let r = ((r11 as i32 + r12 as i32 + r21 as i32 + r22 as i32) >> 2) as u8;
                let g = ((g11 as i32 + g12 as i32 + g21 as i32 + g22 as i32) >> 2) as u8;
                let b = ((b11 as i32 + b12 as i32 + b21 as i32 + b22 as i32) >> 2) as u8;
                let u = clip_u8(((RU * r as i32 + GU * g as i32 + BU * b as i32) >> 15) + 128);
                let v = clip_u8(((RV * r as i32 + GV * g as i32 + BV * b as i32) >> 15) + 128);
                *row_mut(dst[1], ds[1], cy).add(cx) = u;
                *row_mut(dst[2], ds[2], cy).add(cx) = v;
            }
        }
        return;
    }

    if xs == 1 && ys == 1 {
        let mut u_rows = vec![0i32; ctx.dst_h * cw];
        let mut v_rows = vec![0i32; ctx.dst_h * cw];
        for y in 0..ctx.dst_h {
            let sr = row_ptr(src[0], ss[0], y);
            #[cfg(target_arch = "aarch64")]
            if kind(ctx.src_fmt) == Kind::Rgb && !bgr24_yv12 {
                packed_chroma_pairs_neon(
                    sr, ctx.src_fmt,
                    u_rows.as_mut_ptr().add(y * cw),
                    v_rows.as_mut_ptr().add(y * cw),
                    cw,
                );
                continue;
            }
            for cx in 0..cw {
                let x0 = (cx * 2).min(ctx.dst_w - 1);
                let x1 = (x0 + 1).min(ctx.dst_w - 1);
                let (r0, g0, b0, _) = read_packed_rgb(sr, ctx.src_fmt, x0);
                let (r1, g1, b1, _) = read_packed_rgb(sr, ctx.src_fmt, x1);
                let r = r0 as i32 + r1 as i32;
                let g = g0 as i32 + g1 as i32;
                let b = b0 as i32 + b1 as i32;
                u_rows[y * cw + cx] = rgb_pair_to_u_scaled(r, g, b);
                v_rows[y * cw + cx] = rgb_pair_to_v_scaled(r, g, b);
            }
        }
        for cy in 0..ch {
            #[cfg(target_arch = "aarch64")]
            {
                let y0 = (cy * 2).saturating_sub(1);
                let y1 = cy * 2;
                let y2 = (cy * 2 + 1).min(ctx.dst_h - 1);
                let y3 = (cy * 2 + 2).min(ctx.dst_h - 1);
                let u_base = [
                    u_rows.as_ptr().add(y0 * cw), u_rows.as_ptr().add(y1 * cw),
                    u_rows.as_ptr().add(y2 * cw), u_rows.as_ptr().add(y3 * cw),
                ];
                let v_base = [
                    v_rows.as_ptr().add(y0 * cw), v_rows.as_ptr().add(y1 * cw),
                    v_rows.as_ptr().add(y2 * cw), v_rows.as_ptr().add(y3 * cw),
                ];
                let mut cx = 0;
                while cx + 8 <= cw {
                    let u = filter_chroma8_neon(u_base, cx);
                    let v = filter_chroma8_neon(v_base, cx);
                    match ctx.dst_fmt {
                        PIXFMT_NV12 => vst2_u8(row_mut(dst[1], ds[1], cy).add(cx * 2), uint8x8x2_t(u, v)),
                        PIXFMT_NV21 => vst2_u8(row_mut(dst[1], ds[1], cy).add(cx * 2), uint8x8x2_t(v, u)),
                        _ => {
                            vst1_u8(row_mut(dst[1], ds[1], cy).add(cx), u);
                            vst1_u8(row_mut(dst[2], ds[2], cy).add(cx), v);
                        }
                    }
                    cx += 8;
                }
                while cx < cw {
                    let u = filtered_chroma_to_u8((1 << 18) + u_rows[y0 * cw + cx] * 1024 + u_rows[y1 * cw + cx] * 3072 + u_rows[y2 * cw + cx] * 3072 + u_rows[y3 * cw + cx] * 1024);
                    let v = filtered_chroma_to_u8((1 << 18) + v_rows[y0 * cw + cx] * 1024 + v_rows[y1 * cw + cx] * 3072 + v_rows[y2 * cw + cx] * 3072 + v_rows[y3 * cw + cx] * 1024);
                    match ctx.dst_fmt {
                        PIXFMT_NV12 => { let d = row_mut(dst[1], ds[1], cy).add(cx * 2); *d = u; *d.add(1) = v; }
                        PIXFMT_NV21 => { let d = row_mut(dst[1], ds[1], cy).add(cx * 2); *d = v; *d.add(1) = u; }
                        _ => { *row_mut(dst[1], ds[1], cy).add(cx) = u; *row_mut(dst[2], ds[2], cy).add(cx) = v; }
                    }
                    cx += 1;
                }
                continue;
            }
            #[cfg(not(target_arch = "aarch64"))]
            for cx in 0..cw {
                let y0 = (cy * 2).saturating_sub(1);
                let y1 = (cy * 2).min(ctx.dst_h - 1);
                let y2 = (cy * 2 + 1).min(ctx.dst_h - 1);
                let y3 = (cy * 2 + 2).min(ctx.dst_h - 1);
                let u = filtered_chroma_to_u8(
                    (1 << 18)
                        + u_rows[y0 * cw + cx] * 1024
                        + u_rows[y1 * cw + cx] * 3072
                        + u_rows[y2 * cw + cx] * 3072
                        + u_rows[y3 * cw + cx] * 1024,
                );
                let v = filtered_chroma_to_u8(
                    (1 << 18)
                        + v_rows[y0 * cw + cx] * 1024
                        + v_rows[y1 * cw + cx] * 3072
                        + v_rows[y2 * cw + cx] * 3072
                        + v_rows[y3 * cw + cx] * 1024,
                );
                match ctx.dst_fmt {
                    PIXFMT_NV12 => {
                        let d = row_mut(dst[1], ds[1], cy).add(cx * 2);
                        *d = u;
                        *d.add(1) = v;
                    }
                    PIXFMT_NV21 => {
                        let d = row_mut(dst[1], ds[1], cy).add(cx * 2);
                        *d = v;
                        *d.add(1) = u;
                    }
                    _ => {
                        *row_mut(dst[1], ds[1], cy).add(cx) = u;
                        *row_mut(dst[2], ds[2], cy).add(cx) = v;
                    }
                }
            }
        }
        return;
    }

    if xs == 1 && ys == 0 {
        #[cfg(target_arch = "aarch64")]
        if kind(ctx.src_fmt) == Kind::Rgb {
            let mut temp_u = vec![0i32; cw];
            let mut temp_v = vec![0i32; cw];
            for y in 0..ctx.dst_h {
                packed_chroma_pairs_neon(row_ptr(src[0], ss[0], y), ctx.src_fmt, temp_u.as_mut_ptr(), temp_v.as_mut_ptr(), cw);
                scaled_chroma_rows_to_u8_neon(temp_u.as_ptr(), temp_v.as_ptr(), row_mut(dst[1], ds[1], y), row_mut(dst[2], ds[2], y), cw);
            }
            return;
        }
        for y in 0..ctx.dst_h {
            let sr = row_ptr(src[0], ss[0], y);
            for cx in 0..cw {
                let x0 = cx * 2;
                let x1 = (x0 + 1).min(ctx.dst_w - 1);
                let (r0, g0, b0, _) = read_packed_rgb(sr, ctx.src_fmt, x0);
                let (r1, g1, b1, _) = read_packed_rgb(sr, ctx.src_fmt, x1);
                let u = scaled_chroma_to_u8(rgb_pair_to_u_scaled(
                    r0 as i32 + r1 as i32,
                    g0 as i32 + g1 as i32,
                    b0 as i32 + b1 as i32,
                ));
                let v = scaled_chroma_to_u8(rgb_pair_to_v_scaled(
                    r0 as i32 + r1 as i32,
                    g0 as i32 + g1 as i32,
                    b0 as i32 + b1 as i32,
                ));
                *row_mut(dst[1], ds[1], y).add(cx) = u;
                *row_mut(dst[2], ds[2], y).add(cx) = v;
            }
        }
        return;
    }

    if xs == 0 && ys == 0 {
        #[cfg(target_arch = "aarch64")]
        if kind(ctx.src_fmt) == Kind::Rgb {
            for y in 0..ctx.dst_h {
                packed_chroma444_neon(
                    row_ptr(src[0], ss[0], y), ctx.src_fmt, row_mut(dst[1], ds[1], y),
                    row_mut(dst[2], ds[2], y), ctx.dst_w,
                );
            }
            return;
        }
        for y in 0..ctx.dst_h {
            let sr = row_ptr(src[0], ss[0], y);
            for x in 0..ctx.dst_w {
                let (r, g, b, _) = read_packed_rgb(sr, ctx.src_fmt, x);
                *row_mut(dst[1], ds[1], y).add(x) = scaled_chroma_to_u8(rgb_to_u_scaled(r, g, b));
                *row_mut(dst[2], ds[2], y).add(x) = scaled_chroma_to_u8(rgb_to_v_scaled(r, g, b));
            }
        }
        return;
    }

    for cy in 0..ch {
        for cx in 0..cw {
            let sx = (cx << xs).min(ctx.dst_w - 1);
            let sy = (cy << ys).min(ctx.dst_h - 1);
            let sr = row_ptr(src[0], ss[0], sy);
            let (r, g, b, _) = read_packed_rgb(sr, ctx.src_fmt, sx);
            let u = scaled_chroma_to_u8(rgb_to_u_scaled(r, g, b));
            let v = scaled_chroma_to_u8(rgb_to_v_scaled(r, g, b));
            match ctx.dst_fmt {
                PIXFMT_NV12 => {
                    let d = row_mut(dst[1], ds[1], cy).add(cx * 2);
                    *d = u;
                    *d.add(1) = v;
                }
                PIXFMT_NV21 => {
                    let d = row_mut(dst[1], ds[1], cy).add(cx * 2);
                    *d = v;
                    *d.add(1) = u;
                }
                _ => {
                    *row_mut(dst[1], ds[1], cy).add(cx) = u;
                    *row_mut(dst[2], ds[2], cy).add(cx) = v;
                }
            }
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn filter_chroma8_neon(rows: [*const i32; 4], offset: usize) -> uint8x8_t {
    let calculate = |position: usize| {
        let a = vld1q_s32(rows[0].add(position));
        let b = vld1q_s32(rows[1].add(position));
        let c = vld1q_s32(rows[2].add(position));
        let d = vld1q_s32(rows[3].add(position));
        let sum = vaddq_s32(vaddq_s32(a, d), vmulq_n_s32(vaddq_s32(b, c), 3));
        vshrq_n_s32::<9>(vaddq_s32(sum, vdupq_n_s32(256)))
    };
    vqmovun_s16(vcombine_s16(vqmovn_s32(calculate(offset)), vqmovn_s32(calculate(offset + 4))))
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn chroma_coefficients_neon(red: int32x4_t, green: int32x4_t, blue: int32x4_t, u: bool) -> int32x4_t {
    let (cr, cg, cb) = if u { (RU, GU, BU) } else { (RV, GV, BV) };
    let sum = vmlaq_n_s32(vmlaq_n_s32(vmulq_n_s32(red, cr), green, cg), blue, cb);
    vshrq_n_s32::<10>(vaddq_s32(sum, vdupq_n_s32((256 << 15) + (1 << 9))))
}

#[cfg(target_arch = "aarch64")]
unsafe fn packed_chroma_pairs_neon(source: *const u8, fmt: c_int, output_u: *mut i32, output_v: *mut i32, pairs: usize) {
    let mut pair = 0;
    while pair + 8 <= pairs {
        let (red, green, blue) = if bytes_per_pixel(fmt) == 3 {
            let values = vld3q_u8(source.add(pair * 6));
            if fmt == PIXFMT_RGB24 { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        } else {
            let values = vld4q_u8(source.add(pair * 8));
            if fmt == PIXFMT_RGBA { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        };
        let red = vpaddlq_u8(red);
        let green = vpaddlq_u8(green);
        let blue = vpaddlq_u8(blue);
        let red_low = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(red)));
        let red_high = vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(red)));
        let green_low = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(green)));
        let green_high = vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(green)));
        let blue_low = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(blue)));
        let blue_high = vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(blue)));
        vst1q_s32(output_u.add(pair), chroma_coefficients_neon(red_low, green_low, blue_low, true));
        vst1q_s32(output_u.add(pair + 4), chroma_coefficients_neon(red_high, green_high, blue_high, true));
        vst1q_s32(output_v.add(pair), chroma_coefficients_neon(red_low, green_low, blue_low, false));
        vst1q_s32(output_v.add(pair + 4), chroma_coefficients_neon(red_high, green_high, blue_high, false));
        pair += 8;
    }
    while pair < pairs {
        let (r0, g0, b0, _) = read_packed_rgb(source, fmt, pair * 2);
        let (r1, g1, b1, _) = read_packed_rgb(source, fmt, pair * 2 + 1);
        let red = r0 as i32 + r1 as i32;
        let green = g0 as i32 + g1 as i32;
        let blue = b0 as i32 + b1 as i32;
        *output_u.add(pair) = rgb_pair_to_u_scaled(red, green, blue);
        *output_v.add(pair) = rgb_pair_to_v_scaled(red, green, blue);
        pair += 1;
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn scaled_chroma_to_u8_neon(low: int32x4_t, high: int32x4_t) -> uint8x8_t {
    let low = vshrq_n_s32::<6>(vaddq_s32(low, vdupq_n_s32(32)));
    let high = vshrq_n_s32::<6>(vaddq_s32(high, vdupq_n_s32(32)));
    vqmovun_s16(vcombine_s16(vqmovn_s32(low), vqmovn_s32(high)))
}

#[cfg(target_arch = "aarch64")]
unsafe fn scaled_chroma_rows_to_u8_neon(
    source_u: *const i32, source_v: *const i32, output_u: *mut u8, output_v: *mut u8, length: usize,
) {
    let mut offset = 0;
    while offset + 8 <= length {
        vst1_u8(output_u.add(offset), scaled_chroma_to_u8_neon(vld1q_s32(source_u.add(offset)), vld1q_s32(source_u.add(offset + 4))));
        vst1_u8(output_v.add(offset), scaled_chroma_to_u8_neon(vld1q_s32(source_v.add(offset)), vld1q_s32(source_v.add(offset + 4))));
        offset += 8;
    }
    while offset < length {
        *output_u.add(offset) = scaled_chroma_to_u8(*source_u.add(offset));
        *output_v.add(offset) = scaled_chroma_to_u8(*source_v.add(offset));
        offset += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn packed_chroma444_neon(source: *const u8, fmt: c_int, output_u: *mut u8, output_v: *mut u8, width: usize) {
    let calculate = |red: int32x4_t, green: int32x4_t, blue: int32x4_t, u: bool| {
        let (cr, cg, cb) = if u { (RU, GU, BU) } else { (RV, GV, BV) };
        let sum = vmlaq_n_s32(vmlaq_n_s32(vmulq_n_s32(red, cr), green, cg), blue, cb);
        vshrq_n_s32::<9>(vaddq_s32(sum, vdupq_n_s32((256 << 14) + (1 << 8))))
    };
    let mut x = 0;
    while x + 8 <= width {
        let (red, green, blue) = if bytes_per_pixel(fmt) == 3 {
            let values = vld3_u8(source.add(x * 3));
            if fmt == PIXFMT_RGB24 { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        } else {
            let values = vld4_u8(source.add(x * 4));
            if fmt == PIXFMT_RGBA { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        };
        let red = vmovl_u8(red);
        let green = vmovl_u8(green);
        let blue = vmovl_u8(blue);
        let red_low = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(red)));
        let red_high = vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(red)));
        let green_low = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(green)));
        let green_high = vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(green)));
        let blue_low = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(blue)));
        let blue_high = vreinterpretq_s32_u32(vmovl_u16(vget_high_u16(blue)));
        vst1_u8(output_u.add(x), scaled_chroma_to_u8_neon(calculate(red_low, green_low, blue_low, true), calculate(red_high, green_high, blue_high, true)));
        vst1_u8(output_v.add(x), scaled_chroma_to_u8_neon(calculate(red_low, green_low, blue_low, false), calculate(red_high, green_high, blue_high, false)));
        x += 8;
    }
    while x < width {
        let (red, green, blue, _) = read_packed_rgb(source, fmt, x);
        *output_u.add(x) = scaled_chroma_to_u8(rgb_to_u_scaled(red, green, blue));
        *output_v.add(x) = scaled_chroma_to_u8(rgb_to_v_scaled(red, green, blue));
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn packed_to_luma_neon(source: *const u8, fmt: c_int, output: *mut u8, width: usize, truncate: bool) {
    let mut x = 0;
    while x + 8 <= width {
        let (red, green, blue) = if bytes_per_pixel(fmt) == 3 {
            let values = vld3_u8(source.add(x * 3));
            if fmt == PIXFMT_RGB24 { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        } else {
            let values = vld4_u8(source.add(x * 4));
            if fmt == PIXFMT_RGBA { (values.0, values.1, values.2) } else { (values.2, values.1, values.0) }
        };
        let red = vmovl_u8(red);
        let green = vmovl_u8(green);
        let blue = vmovl_u8(blue);
        let calculate = |r: uint16x4_t, g: uint16x4_t, b: uint16x4_t| {
            let sum = vmlal_n_u16(vmlal_n_u16(vmull_n_u16(r, RY as u16), g, GY as u16), b, BY as u16);
            let sum = if truncate { sum } else { vaddq_u32(sum, vdupq_n_u32(1 << 14)) };
            vadd_u16(vshrn_n_u32::<15>(sum), vdup_n_u16(16))
        };
        let low = calculate(vget_low_u16(red), vget_low_u16(green), vget_low_u16(blue));
        let high = calculate(vget_high_u16(red), vget_high_u16(green), vget_high_u16(blue));
        vst1_u8(output.add(x), vmovn_u16(vcombine_u16(low, high)));
        x += 8;
    }
    while x < width {
        let (red, green, blue, _) = read_packed_rgb(source, fmt, x);
        *output.add(x) = if truncate {
            clip_u8(((RY * red as i32 + GY * green as i32 + BY * blue as i32) >> 15) + 16)
        } else {
            rgb_to_y(red, green, blue)
        };
        x += 1;
    }
}

unsafe fn scale_rgb_to_rgb(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    if ctx.src_fmt == PIXFMT_RGB24
        && ctx.dst_fmt == PIXFMT_RGB24
        && ctx.src_w == ctx.dst_w * 2
        && ctx.src_h == ctx.dst_h * 2
        && (ctx.algo == ALGO_NEAREST || ctx.algo == ALGO_BILINEAR)
    {
        scale_rgb24_to_rgb24_down2_sws(ctx, src, ss, dst, ds);
        return;
    }

    if ctx.src_fmt == ctx.dst_fmt
        && matches!(ctx.src_fmt, PIXFMT_RGB24 | PIXFMT_BGR24)
        && ctx.algo == ALGO_BILINEAR
        && ctx.dst_w == ctx.src_w * 2
        && ctx.dst_h == ctx.src_h * 2
    {
        scale_rgb24_up2_bilinear(ctx, src, ss, dst, ds);
        return;
    }
    if ctx.src_fmt == ctx.dst_fmt
        && matches!(ctx.src_fmt, PIXFMT_RGBA | PIXFMT_BGRA)
        && ctx.algo == ALGO_BILINEAR
        && ctx.dst_w == ctx.src_w * 2
        && ctx.dst_h == ctx.src_h * 2
    {
        scale_packed4_up2_bilinear(ctx, src, ss, dst, ds);
        return;
    }
    if ctx.src_fmt == PIXFMT_RGB24
        && ctx.dst_fmt == PIXFMT_RGB24
        && ctx.algo == ALGO_BICUBIC
        && ctx.dst_w == ctx.src_w * 2
        && ctx.dst_h == ctx.src_h * 2
    {
        scale_rgb24_up2_bicubic_separable(ctx, src, ss, dst, ds);
        return;
    }

    if ctx.algo == ALGO_BILINEAR && (ctx.src_w > ctx.dst_w || ctx.src_h > ctx.dst_h) {
        let mut tmp = vec![0u8; ctx.dst_h * ctx.src_w * 4];
        for y in 0..ctx.dst_h {
            let scale = ctx.src_h as f64 / ctx.dst_h as f64;
            let center = (y as f64 + 0.5) * scale - 0.5;
            let radius = scale.max(1.0);
            let start = (center - radius).floor() as isize;
            let end = (center + radius).ceil() as isize;
            for x in 0..ctx.src_w {
                let mut sum = [0.0f64; 4];
                let mut wsum = 0.0f64;
                for syi in start..=end {
                    let w = 1.0 - ((syi as f64 - center).abs() / radius);
                    if w <= 0.0 {
                        continue;
                    }
                    let sy = syi.clamp(0, ctx.src_h as isize - 1) as usize;
                    let sr = row_ptr(src[0], ss[0], sy);
                    let (r, g, b, a) = read_packed_rgb(sr, ctx.src_fmt, x);
                    sum[0] += r as f64 * w;
                    sum[1] += g as f64 * w;
                    sum[2] += b as f64 * w;
                    sum[3] += a as f64 * w;
                    wsum += w;
                }
                let off = (y * ctx.src_w + x) * 4;
                let inv = 1.0 / wsum;
                tmp[off] = (sum[0] * inv).round().clamp(0.0, 255.0) as u8;
                tmp[off + 1] = (sum[1] * inv).round().clamp(0.0, 255.0) as u8;
                tmp[off + 2] = (sum[2] * inv).round().clamp(0.0, 255.0) as u8;
                tmp[off + 3] = (sum[3] * inv).round().clamp(0.0, 255.0) as u8;
            }
        }
        for y in 0..ctx.dst_h {
            let dr = row_mut(dst[0], ds[0], y);
            let scale = ctx.src_w as f64 / ctx.dst_w as f64;
            let radius = scale.max(1.0);
            for x in 0..ctx.dst_w {
                let center = (x as f64 + 0.5) * scale - 0.5;
                let start = (center - radius).floor() as isize;
                let end = (center + radius).ceil() as isize;
                let mut sum = [0.0f64; 4];
                let mut wsum = 0.0f64;
                for sxi in start..=end {
                    let w = 1.0 - ((sxi as f64 - center).abs() / radius);
                    if w <= 0.0 {
                        continue;
                    }
                    let sx = sxi.clamp(0, ctx.src_w as isize - 1) as usize;
                    let off = (y * ctx.src_w + sx) * 4;
                    sum[0] += tmp[off] as f64 * w;
                    sum[1] += tmp[off + 1] as f64 * w;
                    sum[2] += tmp[off + 2] as f64 * w;
                    sum[3] += tmp[off + 3] as f64 * w;
                    wsum += w;
                }
                let inv = 1.0 / wsum;
                write_packed_rgb(
                    dr,
                    ctx.dst_fmt,
                    x,
                    (sum[0] * inv).round().clamp(0.0, 255.0) as u8,
                    (sum[1] * inv).round().clamp(0.0, 255.0) as u8,
                    (sum[2] * inv).round().clamp(0.0, 255.0) as u8,
                    (sum[3] * inv).round().clamp(0.0, 255.0) as u8,
                );
            }
        }
        return;
    }
    if ctx.src_fmt == PIXFMT_RGB24 && ctx.dst_fmt == PIXFMT_RGB24 && ctx.algo == ALGO_BILINEAR {
        for y in 0..ctx.dst_h {
            let (y0, y1, fy) = *ctx.linear_y.get_unchecked(y);
            let row0 = row_ptr(src[0], ss[0], y0);
            let row1 = row_ptr(src[0], ss[0], y1);
            let dr = row_mut(dst[0], ds[0], y);
            for x in 0..ctx.dst_w {
                let (x0, x1, fx) = *ctx.linear_x.get_unchecked(x);
                let p00 = row0.add(x0 * 3);
                let p01 = row0.add(x1 * 3);
                let p10 = row1.add(x0 * 3);
                let p11 = row1.add(x1 * 3);
                let out = dr.add(x * 3);
                *out = lerp_u8(lerp_u8(*p00, *p01, fx), lerp_u8(*p10, *p11, fx), fy);
                *out.add(1) = lerp_u8(
                    lerp_u8(*p00.add(1), *p01.add(1), fx),
                    lerp_u8(*p10.add(1), *p11.add(1), fx),
                    fy,
                );
                *out.add(2) = lerp_u8(
                    lerp_u8(*p00.add(2), *p01.add(2), fx),
                    lerp_u8(*p10.add(2), *p11.add(2), fx),
                    fy,
                );
            }
        }
        return;
    }
    for y in 0..ctx.dst_h {
        let dr = row_mut(dst[0], ds[0], y);
        if ctx.algo == ALGO_NEAREST {
            let sy = *ctx.nearest_y.get_unchecked(y);
            let sr = row_ptr(src[0], ss[0], sy);
            for x in 0..ctx.dst_w {
                let sx = *ctx.nearest_x.get_unchecked(x);
                let (r, g, b, a) = read_packed_rgb(sr, ctx.src_fmt, sx);
                write_packed_rgb(dr, ctx.dst_fmt, x, r, g, b, a);
            }
        } else if ctx.algo == ALGO_BICUBIC {
            let (base_y, fy) = cubic_pos(y, ctx.src_h, ctx.dst_h);
            let mut wy = [0.0f64; 4];
            for i in 0..4 {
                wy[i] = cubic_weight((i as f64 - 1.0) - fy);
            }
            for x in 0..ctx.dst_w {
                let (base_x, fx) = cubic_pos(x, ctx.src_w, ctx.dst_w);
                let mut wx = [0.0f64; 4];
                for i in 0..4 {
                    wx[i] = cubic_weight((i as f64 - 1.0) - fx);
                }
                let mut sum = [0.0f64; 4];
                let mut wsum = 0.0f64;
                for ky in 0..4 {
                    let sy = (base_y + ky as isize - 1).clamp(0, ctx.src_h as isize - 1) as usize;
                    let sr = row_ptr(src[0], ss[0], sy);
                    for kx in 0..4 {
                        let sx = (base_x + kx as isize - 1).clamp(0, ctx.src_w as isize - 1) as usize;
                        let w = wy[ky] * wx[kx];
                        let (r, g, b, a) = read_packed_rgb(sr, ctx.src_fmt, sx);
                        sum[0] += r as f64 * w;
                        sum[1] += g as f64 * w;
                        sum[2] += b as f64 * w;
                        sum[3] += a as f64 * w;
                        wsum += w;
                    }
                }
                let inv = if wsum != 0.0 { 1.0 / wsum } else { 1.0 };
                write_packed_rgb(
                    dr,
                    ctx.dst_fmt,
                    x,
                    (sum[0] * inv).round().clamp(0.0, 255.0) as u8,
                    (sum[1] * inv).round().clamp(0.0, 255.0) as u8,
                    (sum[2] * inv).round().clamp(0.0, 255.0) as u8,
                    (sum[3] * inv).round().clamp(0.0, 255.0) as u8,
                );
            }
        } else {
            let (y0, y1, fy) = scale_linear_pos(y, ctx.src_h, ctx.dst_h);
            let r0 = row_ptr(src[0], ss[0], y0);
            let r1 = row_ptr(src[0], ss[0], y1);
            for x in 0..ctx.dst_w {
                let (x0, x1, fx) = scale_linear_pos(x, ctx.src_w, ctx.dst_w);
                let (r00, g00, b00, a00) = read_packed_rgb(r0, ctx.src_fmt, x0);
                let (r01, g01, b01, a01) = read_packed_rgb(r0, ctx.src_fmt, x1);
                let (r10, g10, b10, a10) = read_packed_rgb(r1, ctx.src_fmt, x0);
                let (r11, g11, b11, a11) = read_packed_rgb(r1, ctx.src_fmt, x1);
                let r = lerp_u8(lerp_u8(r00, r01, fx), lerp_u8(r10, r11, fx), fy);
                let g = lerp_u8(lerp_u8(g00, g01, fx), lerp_u8(g10, g11, fx), fy);
                let b = lerp_u8(lerp_u8(b00, b01, fx), lerp_u8(b10, b11, fx), fy);
                let a = lerp_u8(lerp_u8(a00, a01, fx), lerp_u8(a10, a11, fx), fy);
                write_packed_rgb(dr, ctx.dst_fmt, x, r, g, b, a);
            }
        }
    }
}

unsafe fn scale_rgb24_up2_bilinear(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let row_bytes = ctx.dst_w * 3;
    let mut horizontal = vec![0u8; ctx.src_h * row_bytes];
    for y in 0..ctx.src_h {
        let source = row_ptr(src[0], ss[0], y);
        let output = horizontal.as_mut_ptr().add(y * row_bytes);
        #[cfg(target_arch = "aarch64")]
        {
            scale_rgb24_up2_horizontal_neon(source, output, ctx.src_w);
            continue;
        }
        #[cfg(not(target_arch = "aarch64"))]
        for x in 0..ctx.src_w {
            let previous = source.add(x.saturating_sub(1) * 3);
            let current = source.add(x * 3);
            let next = source.add((x + 1).min(ctx.src_w - 1) * 3);
            let even = output.add(x * 6);
            let odd = even.add(3);
            for channel in 0..3 {
                let before = *previous.add(channel) as u16;
                let value = *current.add(channel) as u16;
                let after = *next.add(channel) as u16;
                *even.add(channel) = ((before + 3 * value + 2) >> 2) as u8;
                *odd.add(channel) = ((3 * value + after + 2) >> 2) as u8;
            }
        }
    }
    for y in 0..ctx.src_h {
        let previous = horizontal.as_ptr().add(y.saturating_sub(1) * row_bytes);
        let current = horizontal.as_ptr().add(y * row_bytes);
        let next = horizontal.as_ptr().add((y + 1).min(ctx.src_h - 1) * row_bytes);
        let even = row_mut(dst[0], ds[0], y * 2);
        let odd = row_mut(dst[0], ds[0], y * 2 + 1);
        #[cfg(target_arch = "aarch64")]
        {
            scale_rgb24_up2_vertical_neon(previous, current, next, even, odd, row_bytes);
            continue;
        }
        #[cfg(not(target_arch = "aarch64"))]
        for offset in 0..row_bytes {
            let before = *previous.add(offset) as u16;
            let value = *current.add(offset) as u16;
            let after = *next.add(offset) as u16;
            *even.add(offset) = ((before + 3 * value + 2) >> 2) as u8;
            *odd.add(offset) = ((3 * value + after + 2) >> 2) as u8;
        }
    }
}

unsafe fn scale_packed4_up2_bilinear(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let row_bytes = ctx.dst_w * 4;
    let mut horizontal = vec![0u8; ctx.src_h * row_bytes];
    for y in 0..ctx.src_h {
        let source = row_ptr(src[0], ss[0], y);
        let output = horizontal.as_mut_ptr().add(y * row_bytes);
        #[cfg(target_arch = "aarch64")]
        {
            scale_packed4_up2_horizontal_neon(source, output, ctx.src_w);
            continue;
        }
        #[cfg(not(target_arch = "aarch64"))]
        for x in 0..ctx.src_w {
            let previous = source.add(x.saturating_sub(1) * 4);
            let current = source.add(x * 4);
            let next = source.add((x + 1).min(ctx.src_w - 1) * 4);
            let even = output.add(x * 8);
            let odd = even.add(4);
            for channel in 0..4 {
                let before = *previous.add(channel) as u16;
                let value = *current.add(channel) as u16;
                let after = *next.add(channel) as u16;
                *even.add(channel) = ((before + 3 * value + 2) >> 2) as u8;
                *odd.add(channel) = ((3 * value + after + 2) >> 2) as u8;
            }
        }
    }
    for y in 0..ctx.src_h {
        let previous = horizontal.as_ptr().add(y.saturating_sub(1) * row_bytes);
        let current = horizontal.as_ptr().add(y * row_bytes);
        let next = horizontal.as_ptr().add((y + 1).min(ctx.src_h - 1) * row_bytes);
        let even = row_mut(dst[0], ds[0], y * 2);
        let odd = row_mut(dst[0], ds[0], y * 2 + 1);
        #[cfg(target_arch = "aarch64")]
        {
            scale_rgb24_up2_vertical_neon(previous, current, next, even, odd, row_bytes);
            continue;
        }
        #[cfg(not(target_arch = "aarch64"))]
        for offset in 0..row_bytes {
            let before = *previous.add(offset) as u16;
            let value = *current.add(offset) as u16;
            let after = *next.add(offset) as u16;
            *even.add(offset) = ((before + 3 * value + 2) >> 2) as u8;
            *odd.add(offset) = ((3 * value + after + 2) >> 2) as u8;
        }
    }
}

unsafe fn scale_rgb24_up2_bicubic_separable(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let mut x_filters = Vec::with_capacity(ctx.dst_w);
    for x in 0..ctx.dst_w {
        let (base, fraction) = cubic_pos(x, ctx.src_w, ctx.dst_w);
        let mut indices = [0usize; 4];
        let mut weights = [0.0f64; 4];
        let mut sum = 0.0;
        for tap in 0..4 {
            indices[tap] = (base + tap as isize - 1).clamp(0, ctx.src_w as isize - 1) as usize;
            weights[tap] = cubic_weight((tap as f64 - 1.0) - fraction);
            sum += weights[tap];
        }
        x_filters.push((indices, weights, sum));
    }
    let mut y_filters = Vec::with_capacity(ctx.dst_h);
    for y in 0..ctx.dst_h {
        let (base, fraction) = cubic_pos(y, ctx.src_h, ctx.dst_h);
        let mut indices = [0usize; 4];
        let mut weights = [0.0f64; 4];
        let mut sum = 0.0;
        for tap in 0..4 {
            indices[tap] = (base + tap as isize - 1).clamp(0, ctx.src_h as isize - 1) as usize;
            weights[tap] = cubic_weight((tap as f64 - 1.0) - fraction);
            sum += weights[tap];
        }
        y_filters.push((indices, weights, sum));
    }

    let row_values = ctx.dst_w * 3;
    let mut horizontal = vec![0.0f64; ctx.src_h * row_values];
    for y in 0..ctx.src_h {
        let source = row_ptr(src[0], ss[0], y);
        let output = horizontal.as_mut_ptr().add(y * row_values);
        for x in 0..ctx.dst_w {
            let (indices, weights, weight_sum) = x_filters.get_unchecked(x);
            for channel in 0..3 {
                let mut sum = 0.0;
                for tap in 0..4 {
                    sum += *source.add(indices[tap] * 3 + channel) as f64 * weights[tap];
                }
                *output.add(x * 3 + channel) = sum / weight_sum;
            }
        }
    }
    for y in 0..ctx.dst_h {
        let (indices, weights, weight_sum) = y_filters.get_unchecked(y);
        let output = row_mut(dst[0], ds[0], y);
        for offset in 0..row_values {
            let mut sum = 0.0;
            for tap in 0..4 {
                sum += *horizontal.as_ptr().add(indices[tap] * row_values + offset) * weights[tap];
            }
            *output.add(offset) = (sum / weight_sum).round().clamp(0.0, 255.0) as u8;
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn quarter_weight_neon(a: uint8x16_t, b: uint8x16_t) -> uint8x16_t {
    let low = vaddq_u16(vmovl_u8(vget_low_u8(a)), vmulq_n_u16(vmovl_u8(vget_low_u8(b)), 3));
    let high = vaddq_u16(vmovl_u8(vget_high_u8(a)), vmulq_n_u16(vmovl_u8(vget_high_u8(b)), 3));
    vcombine_u8(vrshrn_n_u16::<2>(low), vrshrn_n_u16::<2>(high))
}

#[cfg(target_arch = "aarch64")]
unsafe fn scale_rgb24_up2_horizontal_neon(source: *const u8, output: *mut u8, width: usize) {
    let scalar = |x: usize| {
        let previous = unsafe { source.add(x.saturating_sub(1) * 3) };
        let current = unsafe { source.add(x * 3) };
        let next = unsafe { source.add((x + 1).min(width - 1) * 3) };
        let even = unsafe { output.add(x * 6) };
        let odd = unsafe { even.add(3) };
        for channel in 0..3 {
            let before = unsafe { *previous.add(channel) as u16 };
            let value = unsafe { *current.add(channel) as u16 };
            let after = unsafe { *next.add(channel) as u16 };
            unsafe {
                *even.add(channel) = ((before + 3 * value + 2) >> 2) as u8;
                *odd.add(channel) = ((3 * value + after + 2) >> 2) as u8;
            }
        }
    };
    if width == 0 {
        return;
    }
    scalar(0);
    let mut x = 1;
    while x + 16 < width {
        let previous = vld3q_u8(source.add((x - 1) * 3));
        let current = vld3q_u8(source.add(x * 3));
        let next = vld3q_u8(source.add((x + 1) * 3));
        let even_r = quarter_weight_neon(previous.0, current.0);
        let even_g = quarter_weight_neon(previous.1, current.1);
        let even_b = quarter_weight_neon(previous.2, current.2);
        let odd_r = quarter_weight_neon(next.0, current.0);
        let odd_g = quarter_weight_neon(next.1, current.1);
        let odd_b = quarter_weight_neon(next.2, current.2);
        vst3q_u8(
            output.add(x * 6),
            uint8x16x3_t(vzip1q_u8(even_r, odd_r), vzip1q_u8(even_g, odd_g), vzip1q_u8(even_b, odd_b)),
        );
        vst3q_u8(
            output.add(x * 6 + 48),
            uint8x16x3_t(vzip2q_u8(even_r, odd_r), vzip2q_u8(even_g, odd_g), vzip2q_u8(even_b, odd_b)),
        );
        x += 16;
    }
    while x < width {
        scalar(x);
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn scale_packed4_up2_horizontal_neon(source: *const u8, output: *mut u8, width: usize) {
    let scalar = |x: usize| {
        let previous = unsafe { source.add(x.saturating_sub(1) * 4) };
        let current = unsafe { source.add(x * 4) };
        let next = unsafe { source.add((x + 1).min(width - 1) * 4) };
        let even = unsafe { output.add(x * 8) };
        let odd = unsafe { even.add(4) };
        for channel in 0..4 {
            let before = unsafe { *previous.add(channel) as u16 };
            let value = unsafe { *current.add(channel) as u16 };
            let after = unsafe { *next.add(channel) as u16 };
            unsafe {
                *even.add(channel) = ((before + 3 * value + 2) >> 2) as u8;
                *odd.add(channel) = ((3 * value + after + 2) >> 2) as u8;
            }
        }
    };
    if width == 0 {
        return;
    }
    scalar(0);
    let mut x = 1;
    while x + 16 < width {
        let previous = vld4q_u8(source.add((x - 1) * 4));
        let current = vld4q_u8(source.add(x * 4));
        let next = vld4q_u8(source.add((x + 1) * 4));
        let e0 = quarter_weight_neon(previous.0, current.0);
        let e1 = quarter_weight_neon(previous.1, current.1);
        let e2 = quarter_weight_neon(previous.2, current.2);
        let e3 = quarter_weight_neon(previous.3, current.3);
        let o0 = quarter_weight_neon(next.0, current.0);
        let o1 = quarter_weight_neon(next.1, current.1);
        let o2 = quarter_weight_neon(next.2, current.2);
        let o3 = quarter_weight_neon(next.3, current.3);
        vst4q_u8(output.add(x * 8), uint8x16x4_t(vzip1q_u8(e0, o0), vzip1q_u8(e1, o1), vzip1q_u8(e2, o2), vzip1q_u8(e3, o3)));
        vst4q_u8(output.add(x * 8 + 64), uint8x16x4_t(vzip2q_u8(e0, o0), vzip2q_u8(e1, o1), vzip2q_u8(e2, o2), vzip2q_u8(e3, o3)));
        x += 16;
    }
    while x < width {
        scalar(x);
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn scale_rgb24_up2_vertical_neon(
    previous: *const u8,
    current: *const u8,
    next: *const u8,
    even: *mut u8,
    odd: *mut u8,
    length: usize,
) {
    let mut offset = 0;
    while offset + 16 <= length {
        let before = vld1q_u8(previous.add(offset));
        let value = vld1q_u8(current.add(offset));
        let after = vld1q_u8(next.add(offset));
        vst1q_u8(even.add(offset), quarter_weight_neon(before, value));
        vst1q_u8(odd.add(offset), quarter_weight_neon(after, value));
        offset += 16;
    }
    while offset < length {
        let before = *previous.add(offset) as u16;
        let value = *current.add(offset) as u16;
        let after = *next.add(offset) as u16;
        *even.add(offset) = ((before + 3 * value + 2) >> 2) as u8;
        *odd.add(offset) = ((3 * value + after + 2) >> 2) as u8;
        offset += 1;
    }
}

#[inline]
unsafe fn rgb24_y16(row: *const u8, x: usize) -> i32 {
    let p = row.add(x * 3);
    let r = *p as i32;
    let g = *p.add(1) as i32;
    let b = *p.add(2) as i32;
    (RY * r + GY * g + BY * b + (32 << 14) + (1 << 8)) >> 9
}

#[inline]
unsafe fn rgb24_uv16_half(row: *const u8, cx: usize) -> (i32, i32) {
    let p = row.add(cx * 6);
    let r = *p as i32 + *p.add(3) as i32;
    let g = *p.add(1) as i32 + *p.add(4) as i32;
    let b = *p.add(2) as i32 + *p.add(5) as i32;
    (
        (RU * r + GU * g + BU * b + (256 << 15) + (1 << 9)) >> 10,
        (RV * r + GV * g + BV * b + (256 << 15) + (1 << 9)) >> 10,
    )
}

#[inline]
fn down2_pos(out: usize, limit: usize) -> usize {
    if out == 0 {
        0
    } else if out + 1 == limit {
        out * 2 - 3
    } else {
        out * 2 - 1
    }
}

#[inline]
fn down2_h16_to15(vals: &[i32], out: usize, out_len: usize) -> i32 {
    if out == 0 {
        (vals[0] * 8192 + vals[1] * 6144 + vals[2] * 2048) >> 13
    } else if out + 1 == out_len {
        let p = out * 2 - 3;
        (vals[p + 1] * 2048 + vals[p + 2] * 6144 + vals[p + 3] * 8192) >> 13
    } else {
        let p = out * 2 - 1;
        (vals[p] * 2048 + vals[p + 1] * 6144 + vals[p + 2] * 6144 + vals[p + 3] * 2048) >> 13
    }
}

#[inline]
fn down2_v15_to15(rows: [&[i32]; 4], x: usize, out_y: usize, out_h: usize) -> i32 {
    if out_y == 0 {
        (rows[0][x] * 2048 + rows[1][x] * 1536 + rows[2][x] * 512) >> 12
    } else if out_y + 1 == out_h {
        (rows[1][x] * 512 + rows[2][x] * 1536 + rows[3][x] * 2048) >> 12
    } else {
        (rows[0][x] * 512 + rows[1][x] * 1536 + rows[2][x] * 1536 + rows[3][x] * 512) >> 12
    }
}

unsafe fn scale_rgb24_to_rgb24_down2_sws(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    if ctx.algo == ALGO_NEAREST {
        for y in 0..ctx.dst_h {
            let sy = y * 2 + 1;
            let sr = row_ptr(src[0], ss[0], sy);
            let dr = row_mut(dst[0], ds[0], y);
            for x in 0..ctx.dst_w {
                let sx = x * 2 + 1;
                let yv = rgb24_y16(sr, sx) * 2;
                let (u0, v0) = rgb24_uv16_half(sr, x);
                let uv = u0 * 2 - (128 << 7);
                let vv = v0 * 2 - (128 << 7);
                let (r, g, b) = yuv_to_rgb_full_values(yv * 4, uv * 4, vv * 4);
                write_packed_rgb(dr, PIXFMT_RGB24, x, r, g, b, 255);
            }
        }
        return;
    }

    let row_values = ctx.dst_w;
    let mut y_rows = vec![0i32; ctx.src_h * row_values];
    let mut u_rows = vec![0i32; ctx.src_h * row_values];
    let mut v_rows = vec![0i32; ctx.src_h * row_values];
    let mut full_y = vec![0i32; ctx.src_w];
    for sy in 0..ctx.src_h {
        let source = row_ptr(src[0], ss[0], sy);
        for sx in 0..ctx.src_w {
            full_y[sx] = rgb24_y16(source, sx);
        }
        for x in 0..ctx.dst_w {
            y_rows[sy * row_values + x] = down2_h16_to15(&full_y, x, ctx.dst_w);
            let (u, v) = rgb24_uv16_half(source, x);
            u_rows[sy * row_values + x] = u * 2;
            v_rows[sy * row_values + x] = v * 2;
        }
    }

    for y in 0..ctx.dst_h {
        let base = down2_pos(y, ctx.dst_h);
        let rows = [
            base.min(ctx.src_h - 1),
            (base + 1).min(ctx.src_h - 1),
            (base + 2).min(ctx.src_h - 1),
            (base + 3).min(ctx.src_h - 1),
        ];
        let yr = [
            &y_rows[rows[0] * row_values..(rows[0] + 1) * row_values],
            &y_rows[rows[1] * row_values..(rows[1] + 1) * row_values],
            &y_rows[rows[2] * row_values..(rows[2] + 1) * row_values],
            &y_rows[rows[3] * row_values..(rows[3] + 1) * row_values],
        ];
        let ur = [
            &u_rows[rows[0] * row_values..(rows[0] + 1) * row_values],
            &u_rows[rows[1] * row_values..(rows[1] + 1) * row_values],
            &u_rows[rows[2] * row_values..(rows[2] + 1) * row_values],
            &u_rows[rows[3] * row_values..(rows[3] + 1) * row_values],
        ];
        let vr = [
            &v_rows[rows[0] * row_values..(rows[0] + 1) * row_values],
            &v_rows[rows[1] * row_values..(rows[1] + 1) * row_values],
            &v_rows[rows[2] * row_values..(rows[2] + 1) * row_values],
            &v_rows[rows[3] * row_values..(rows[3] + 1) * row_values],
        ];
        let output = row_mut(dst[0], ds[0], y);
        for x in 0..ctx.dst_w {
            let yv = down2_v15_to15(yr, x, y, ctx.dst_h);
            let uv = down2_v15_to15(ur, x, y, ctx.dst_h) - (128 << 7);
            let vv = down2_v15_to15(vr, x, y, ctx.dst_h) - (128 << 7);
            let (red, green, blue) = yuv_to_rgb_full_values(yv * 4, uv * 4, vv * 4);
            write_packed_rgb(output, PIXFMT_RGB24, x, red, green, blue, 255);
        }
    }
}

#[inline]
fn sws_down2_h8_to15(src_row: *const u8, x: usize, out_len: usize) -> i32 {
    unsafe {
        if x == 0 {
            ((*src_row as i32) * 8192
                + (*src_row.add(1) as i32) * 6144
                + (*src_row.add(2) as i32) * 2048)
                >> 7
        } else if x + 1 == out_len {
            let sx = x * 2 - 2;
            ((*src_row.add(sx + 1) as i32) * 2048
                + (*src_row.add(sx + 2) as i32) * 6144
                + (*src_row.add(sx + 3) as i32) * 8192)
                >> 7
        } else {
            let sx = x * 2 - 1;
            ((*src_row.add(sx) as i32) * 2048
                + (*src_row.add(sx + 1) as i32) * 6144
                + (*src_row.add(sx + 2) as i32) * 6144
                + (*src_row.add(sx + 3) as i32) * 2048)
                >> 7
        }
    }
}

#[inline]
fn sws_down2_h8_to_u8(src_row: *const u8, x: usize, out_len: usize) -> u8 {
    clip_u8((sws_down2_h8_to15(src_row, x, out_len) + 64) >> 7)
}

unsafe fn scale_yuv420p_to_rgb24_down2_bilinear(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let chr_w = ctx.dst_w >> 1;
    let mut y_rows = vec![0i32; 4 * ctx.dst_w];
    let mut u_row = vec![0u8; chr_w];
    let mut v_row = vec![0u8; chr_w];

    for y in 0..ctx.dst_h {
        let lum_base = if y == 0 {
            0usize
        } else if y + 1 == ctx.dst_h {
            ctx.src_h - 4
        } else {
            y * 2 - 1
        };
        for ky in 0..4 {
            let yr = row_ptr(src[0], ss[0], lum_base + ky);
            for x in 0..ctx.dst_w {
                y_rows[ky * ctx.dst_w + x] = sws_down2_h8_to15(yr, x, ctx.dst_w);
            }
        }

        let ur = row_ptr(src[1], ss[1], y);
        let vr = row_ptr(src[2], ss[2], y);
        for cx in 0..chr_w {
            u_row[cx] = sws_down2_h8_to_u8(ur, cx, chr_w);
            v_row[cx] = sws_down2_h8_to_u8(vr, cx, chr_w);
        }

        let dr = row_mut(dst[0], ds[0], y);
        for cx in 0..chr_w {
            let u = u_row[cx];
            let v = v_row[cx];
            for dx in 0..2 {
                let x = cx * 2 + dx;
                let yy = if y == 0 {
                    ((1 << 18)
                        + y_rows[x] * 2048
                        + y_rows[ctx.dst_w + x] * 1536
                        + y_rows[ctx.dst_w * 2 + x] * 512)
                        >> 19
                } else if y + 1 == ctx.dst_h {
                    ((1 << 18)
                        + y_rows[ctx.dst_w + x] * 512
                        + y_rows[ctx.dst_w * 2 + x] * 1536
                        + y_rows[ctx.dst_w * 3 + x] * 2048)
                        >> 19
                } else {
                    ((1 << 18)
                        + y_rows[x] * 512
                        + y_rows[ctx.dst_w + x] * 1536
                        + y_rows[ctx.dst_w * 2 + x] * 1536
                        + y_rows[ctx.dst_w * 3 + x] * 512)
                        >> 19
                };
                let (r, g, b) = yuv_to_rgb_table(clip_u8(yy), u, v);
                write_packed_rgb(dr, ctx.dst_fmt, x, r, g, b, 255);
            }
        }
    }
}

unsafe fn scale_yuv420p_to_rgb24_down3_bilinear(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let mut rgb = vec![0u8; ctx.src_w * ctx.src_h * 3];
    for y in (0..ctx.src_h).step_by(2) {
        let y0 = row_ptr(src[0], ss[0], y);
        let y1 = row_ptr(src[0], ss[0], y + 1);
        let ur = row_ptr(src[1], ss[1], y >> 1);
        let vr = row_ptr(src[2], ss[2], y >> 1);
        let d0 = rgb.as_mut_ptr().add(y * ctx.src_w * 3);
        let d1 = d0.add(ctx.src_w * 3);
        for cx in 0..(ctx.src_w >> 1) {
            let x = cx * 2;
            let uu = *ur.add(cx) as i32;
            let vv = *vr.add(cx) as i32;
            let ro = -(YUV_RGB_CRV >> 9) + ((vv * YUV_RGB_CRV) >> 16);
            let go = -(YUV_RGB_CGU >> 9) + ((uu * YUV_RGB_CGU) >> 16)
                - (YUV_RGB_CGV >> 9) + ((vv * YUV_RGB_CGV) >> 16);
            let bo = -(YUV_RGB_CBU >> 9) + ((uu * YUV_RGB_CBU) >> 16);
            let luma = [*y0.add(x), *y0.add(x + 1), *y1.add(x), *y1.add(x + 1)];
            let output = [d0.add(x * 3), d0.add(x * 3 + 3), d1.add(x * 3), d1.add(x * 3 + 3)];
            for pixel in 0..4 {
                let yy = luma[pixel] as i32 + 838;
                *output[pixel] = *YUV_RGB_TABLE.get_unchecked((yy + ro) as usize);
                *output[pixel].add(1) = *YUV_RGB_TABLE.get_unchecked((yy + go) as usize);
                *output[pixel].add(2) = *YUV_RGB_TABLE.get_unchecked((yy + bo) as usize);
            }
        }
    }

    #[cfg(not(target_arch = "aarch64"))]
    let weights = [1i32, 2, 3, 2, 1];
    let mut mid = vec![0u8; ctx.src_w * 3];
    for y in 0..ctx.dst_h {
        let center_y = y * 3 + 1;
        let sy0 = (center_y as isize - 2).clamp(0, ctx.src_h as isize - 1) as usize;
        let sy1 = (center_y as isize - 1).clamp(0, ctx.src_h as isize - 1) as usize;
        let sy2 = center_y.min(ctx.src_h - 1);
        let sy3 = (center_y + 1).min(ctx.src_h - 1);
        let sy4 = (center_y + 2).min(ctx.src_h - 1);
        #[cfg(target_arch = "aarch64")]
        filter_down3_vertical_neon(
            rgb.as_ptr().add(sy0 * ctx.src_w * 3),
            rgb.as_ptr().add(sy1 * ctx.src_w * 3),
            rgb.as_ptr().add(sy2 * ctx.src_w * 3),
            rgb.as_ptr().add(sy3 * ctx.src_w * 3),
            rgb.as_ptr().add(sy4 * ctx.src_w * 3),
            mid.as_mut_ptr(),
            ctx.src_w * 3,
        );
        #[cfg(not(target_arch = "aarch64"))]
        for x in 0..ctx.src_w {
            let offset = x * 3;
            let mut sums = [0i32; 3];
            for tap in 0..5 {
                let sy = (center_y as isize + tap as isize - 2)
                    .clamp(0, ctx.src_h as isize - 1) as usize;
                let source = rgb.as_ptr().add((sy * ctx.src_w + x) * 3);
                sums[0] += *source as i32 * weights[tap];
                sums[1] += *source.add(1) as i32 * weights[tap];
                sums[2] += *source.add(2) as i32 * weights[tap];
            }
            mid[offset] = ((sums[0] + 4) / 9) as u8;
            mid[offset + 1] = ((sums[1] + 4) / 9) as u8;
            mid[offset + 2] = ((sums[2] + 4) / 9) as u8;
        }
        let dr = row_mut(dst[0], ds[0], y);
        #[cfg(target_arch = "aarch64")]
        {
            filter_down3_horizontal_neon(mid.as_ptr(), dr, ctx.src_w, ctx.dst_w);
            continue;
        }
        #[cfg(not(target_arch = "aarch64"))]
        for x in 0..ctx.dst_w {
            let center_x = x * 3 + 1;
            let mut sums = [0i32; 3];
            for tap in 0..5 {
                let sx = (center_x as isize + tap as isize - 2)
                    .clamp(0, ctx.src_w as isize - 1) as usize;
                let source = mid.as_ptr().add(sx * 3);
                sums[0] += *source as i32 * weights[tap];
                sums[1] += *source.add(1) as i32 * weights[tap];
                sums[2] += *source.add(2) as i32 * weights[tap];
            }
            *dr.add(x * 3) = ((sums[0] + 4) / 9) as u8;
            *dr.add(x * 3 + 1) = ((sums[1] + 4) / 9) as u8;
            *dr.add(x * 3 + 2) = ((sums[2] + 4) / 9) as u8;
        }
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn filter_down3_vertical_neon(
    row0: *const u8,
    row1: *const u8,
    row2: *const u8,
    row3: *const u8,
    row4: *const u8,
    output: *mut u8,
    length: usize,
) {
    let mut offset = 0;
    while offset + 16 <= length {
        let a = vld1q_u8(row0.add(offset));
        let b = vld1q_u8(row1.add(offset));
        let c = vld1q_u8(row2.add(offset));
        let d = vld1q_u8(row3.add(offset));
        let e = vld1q_u8(row4.add(offset));
        let low = vaddq_u16(
            vaddq_u16(vmovl_u8(vget_low_u8(a)), vmovl_u8(vget_low_u8(e))),
            vaddq_u16(
                vmulq_n_u16(vaddq_u16(vmovl_u8(vget_low_u8(b)), vmovl_u8(vget_low_u8(d))), 2),
                vmulq_n_u16(vmovl_u8(vget_low_u8(c)), 3),
            ),
        );
        let high = vaddq_u16(
            vaddq_u16(vmovl_u8(vget_high_u8(a)), vmovl_u8(vget_high_u8(e))),
            vaddq_u16(
                vmulq_n_u16(vaddq_u16(vmovl_u8(vget_high_u8(b)), vmovl_u8(vget_high_u8(d))), 2),
                vmulq_n_u16(vmovl_u8(vget_high_u8(c)), 3),
            ),
        );
        let low = neon_divide_9(vaddq_u16(low, vdupq_n_u16(4)));
        let high = neon_divide_9(vaddq_u16(high, vdupq_n_u16(4)));
        vst1q_u8(output.add(offset), vcombine_u8(vmovn_u16(low), vmovn_u16(high)));
        offset += 16;
    }
    while offset < length {
        *output.add(offset) = ((*row0.add(offset) as u32
            + 2 * *row1.add(offset) as u32
            + 3 * *row2.add(offset) as u32
            + 2 * *row3.add(offset) as u32
            + *row4.add(offset) as u32
            + 4)
            / 9) as u8;
        offset += 1;
    }
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn neon_divide_9(values: uint16x8_t) -> uint16x8_t {
    let low = vmull_n_u16(vget_low_u16(values), 7282);
    let high = vmull_n_u16(vget_high_u16(values), 7282);
    vcombine_u16(vshrn_n_u32::<16>(low), vshrn_n_u32::<16>(high))
}

#[cfg(target_arch = "aarch64")]
#[inline]
unsafe fn neon_weighted_12321(
    a: uint8x16_t,
    b: uint8x16_t,
    c: uint8x16_t,
    d: uint8x16_t,
    e: uint8x16_t,
) -> uint8x16_t {
    let low = vaddq_u16(
        vaddq_u16(vmovl_u8(vget_low_u8(a)), vmovl_u8(vget_low_u8(e))),
        vaddq_u16(
            vmulq_n_u16(vaddq_u16(vmovl_u8(vget_low_u8(b)), vmovl_u8(vget_low_u8(d))), 2),
            vmulq_n_u16(vmovl_u8(vget_low_u8(c)), 3),
        ),
    );
    let high = vaddq_u16(
        vaddq_u16(vmovl_u8(vget_high_u8(a)), vmovl_u8(vget_high_u8(e))),
        vaddq_u16(
            vmulq_n_u16(vaddq_u16(vmovl_u8(vget_high_u8(b)), vmovl_u8(vget_high_u8(d))), 2),
            vmulq_n_u16(vmovl_u8(vget_high_u8(c)), 3),
        ),
    );
    vcombine_u8(
        vmovn_u16(neon_divide_9(vaddq_u16(low, vdupq_n_u16(4)))),
        vmovn_u16(neon_divide_9(vaddq_u16(high, vdupq_n_u16(4)))),
    )
}

#[cfg(target_arch = "aarch64")]
unsafe fn filter_down3_horizontal_neon(source: *const u8, output: *mut u8, src_w: usize, dst_w: usize) {
    const BASE: [u8; 16] = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33, 36, 39, 42, 45];

    let scalar = |x: usize| {
        for channel in 0..3 {
            let center = x * 3 + 1;
            let mut sum = 0u32;
            for (tap, weight) in [1u32, 2, 3, 2, 1].iter().enumerate() {
                let sx = (center as isize + tap as isize - 2).clamp(0, src_w as isize - 1) as usize;
                sum += unsafe { *source.add(sx * 3 + channel) as u32 } * weight;
            }
            unsafe { *output.add(x * 3 + channel) = ((sum + 4) / 9) as u8 };
        }
    };

    if dst_w == 0 {
        return;
    }
    scalar(0);
    let base_indices = vld1q_u8(BASE.as_ptr());
    let mut x = 1;
    while x + 16 <= dst_w && x * 3 - 1 + 64 <= src_w {
        let base = x * 3 - 1;
        let p0 = vld3q_u8(source.add(base * 3));
        let p1 = vld3q_u8(source.add((base + 16) * 3));
        let p2 = vld3q_u8(source.add((base + 32) * 3));
        let p3 = vld3q_u8(source.add((base + 48) * 3));
        let indices = [
            base_indices,
            vaddq_u8(base_indices, vdupq_n_u8(1)),
            vaddq_u8(base_indices, vdupq_n_u8(2)),
            vaddq_u8(base_indices, vdupq_n_u8(3)),
            vaddq_u8(base_indices, vdupq_n_u8(4)),
        ];
        let red = uint8x16x4_t(p0.0, p1.0, p2.0, p3.0);
        let green = uint8x16x4_t(p0.1, p1.1, p2.1, p3.1);
        let blue = uint8x16x4_t(p0.2, p1.2, p2.2, p3.2);
        let gather = |table: uint8x16x4_t| {
            neon_weighted_12321(
                vqtbl4q_u8(table, indices[0]),
                vqtbl4q_u8(table, indices[1]),
                vqtbl4q_u8(table, indices[2]),
                vqtbl4q_u8(table, indices[3]),
                vqtbl4q_u8(table, indices[4]),
            )
        };
        vst3q_u8(output.add(x * 3), uint8x16x3_t(gather(red), gather(green), gather(blue)));
        x += 16;
    }
    while x < dst_w {
        scalar(x);
        x += 1;
    }
}

unsafe fn generic_rgb_pipeline(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let mut tmp = vec![0u8; ctx.dst_w * ctx.dst_h * 3];
    if ctx.algo == ALGO_BILINEAR && (ctx.src_w > ctx.dst_w || ctx.src_h > ctx.dst_h) {
        let mut mid = vec![0u8; ctx.dst_h * ctx.src_w * 3];
        for y in 0..ctx.dst_h {
            let scale = ctx.src_h as f64 / ctx.dst_h as f64;
            let center = (y as f64 + 0.5) * scale - 0.5;
            let radius = scale.max(1.0);
            let start = (center - radius).floor() as isize;
            let end = (center + radius).ceil() as isize;
            for x in 0..ctx.src_w {
                let mut sum = [0.0f64; 3];
                let mut wsum = 0.0f64;
                for syi in start..=end {
                    let w = 1.0 - ((syi as f64 - center).abs() / radius);
                    if w <= 0.0 {
                        continue;
                    }
                    let sy = syi.clamp(0, ctx.src_h as isize - 1) as usize;
                    let (r, g, b) = sample_rgb(src, ss, ctx.src_fmt, x, sy);
                    sum[0] += r as f64 * w;
                    sum[1] += g as f64 * w;
                    sum[2] += b as f64 * w;
                    wsum += w;
                }
                let off = (y * ctx.src_w + x) * 3;
                let inv = 1.0 / wsum;
                mid[off] = (sum[0] * inv).round().clamp(0.0, 255.0) as u8;
                mid[off + 1] = (sum[1] * inv).round().clamp(0.0, 255.0) as u8;
                mid[off + 2] = (sum[2] * inv).round().clamp(0.0, 255.0) as u8;
            }
        }
        for y in 0..ctx.dst_h {
            let scale = ctx.src_w as f64 / ctx.dst_w as f64;
            let radius = scale.max(1.0);
            for x in 0..ctx.dst_w {
                let center = (x as f64 + 0.5) * scale - 0.5;
                let start = (center - radius).floor() as isize;
                let end = (center + radius).ceil() as isize;
                let mut sum = [0.0f64; 3];
                let mut wsum = 0.0f64;
                for sxi in start..=end {
                    let w = 1.0 - ((sxi as f64 - center).abs() / radius);
                    if w <= 0.0 {
                        continue;
                    }
                    let sx = sxi.clamp(0, ctx.src_w as isize - 1) as usize;
                    let off = (y * ctx.src_w + sx) * 3;
                    sum[0] += mid[off] as f64 * w;
                    sum[1] += mid[off + 1] as f64 * w;
                    sum[2] += mid[off + 2] as f64 * w;
                    wsum += w;
                }
                let off = (y * ctx.dst_w + x) * 3;
                let inv = 1.0 / wsum;
                tmp[off] = (sum[0] * inv).round().clamp(0.0, 255.0) as u8;
                tmp[off + 1] = (sum[1] * inv).round().clamp(0.0, 255.0) as u8;
                tmp[off + 2] = (sum[2] * inv).round().clamp(0.0, 255.0) as u8;
            }
        }
    } else {
        for y in 0..ctx.dst_h {
            let (sy0, sy1, fy) = if ctx.algo == ALGO_NEAREST {
                let sy = *ctx.nearest_y.get_unchecked(y);
                (sy, sy, 0)
            } else {
                scale_linear_pos(y, ctx.src_h, ctx.dst_h)
            };
            for x in 0..ctx.dst_w {
                if ctx.algo == ALGO_NEAREST {
                    let sx = *ctx.nearest_x.get_unchecked(x);
                    let (r, g, b) = sample_rgb(src, ss, ctx.src_fmt, sx, sy0);
                    let off = (y * ctx.dst_w + x) * 3;
                    tmp[off] = r;
                    tmp[off + 1] = g;
                    tmp[off + 2] = b;
                    continue;
                }
                let (sx0, sx1, fx) = if ctx.algo == ALGO_NEAREST {
                    let sx = scale_nearest_pos(x, ctx.src_w, ctx.dst_w);
                    (sx, sx, 0)
                } else {
                    scale_linear_pos(x, ctx.src_w, ctx.dst_w)
                };
                let (r00, g00, b00) = sample_rgb(src, ss, ctx.src_fmt, sx0, sy0);
                let (r01, g01, b01) = sample_rgb(src, ss, ctx.src_fmt, sx1, sy0);
                let (r10, g10, b10) = sample_rgb(src, ss, ctx.src_fmt, sx0, sy1);
                let (r11, g11, b11) = sample_rgb(src, ss, ctx.src_fmt, sx1, sy1);
                let off = (y * ctx.dst_w + x) * 3;
                tmp[off] = lerp_u8(lerp_u8(r00, r01, fx), lerp_u8(r10, r11, fx), fy);
                tmp[off + 1] = lerp_u8(lerp_u8(g00, g01, fx), lerp_u8(g10, g11, fx), fy);
                tmp[off + 2] = lerp_u8(lerp_u8(b00, b01, fx), lerp_u8(b10, b11, fx), fy);
            }
        }
    }

    if is_yuv(ctx.dst_fmt) || ctx.dst_fmt == PIXFMT_GRAY8 {
        let fake_src = [tmp.as_ptr(), ptr::null(), ptr::null(), ptr::null()];
        let fake_ss = [(ctx.dst_w * 3) as c_int, 0, 0, 0];
        let fake_ctx = SwsContext { src_w: ctx.dst_w, src_h: ctx.dst_h, src_fmt: PIXFMT_RGB24, dst_w: ctx.dst_w, dst_h: ctx.dst_h, dst_fmt: ctx.dst_fmt, algo: ALGO_BILINEAR, linear_x: Vec::new(), linear_y: Vec::new(), nearest_x: Vec::new(), nearest_y: Vec::new() };
        convert_packed_to_yuv_same_size(&fake_ctx, &fake_src, &fake_ss, dst, ds);
    } else {
        for y in 0..ctx.dst_h {
            let dr = row_mut(dst[0], ds[0], y);
            let sr = tmp.as_ptr().add(y * ctx.dst_w * 3);
            for x in 0..ctx.dst_w {
                let p = sr.add(x * 3);
                write_packed_rgb(dr, ctx.dst_fmt, x, *p, *p.add(1), *p.add(2), 255);
            }
        }
    }
}

unsafe fn scale_rgb24_to_yuv420p_down2_nearest(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    let chroma_w = ctx.dst_w >> 1;
    let chroma_h = ctx.dst_h >> 1;
    let mut u_rows = vec![0i32; ctx.dst_h * chroma_w];
    let mut v_rows = vec![0i32; ctx.dst_h * chroma_w];
    for y in 0..ctx.dst_h {
        let source = row_ptr(src[0], ss[0], y * 2 + 1);
        let luma = row_mut(dst[0], ds[0], y);
        for x in 0..ctx.dst_w {
            let pixel = source.add((x * 2 + 1) * 3);
            *luma.add(x) = rgb_to_y(*pixel, *pixel.add(1), *pixel.add(2));
        }
        for cx in 0..chroma_w {
            let left = source.add((cx * 4 + 1) * 3);
            let right = source.add((cx * 4 + 3) * 3);
            let red = *left as i32 + *right as i32;
            let green = *left.add(1) as i32 + *right.add(1) as i32;
            let blue = *left.add(2) as i32 + *right.add(2) as i32;
            u_rows[y * chroma_w + cx] = rgb_pair_to_u_scaled(red, green, blue);
            v_rows[y * chroma_w + cx] = rgb_pair_to_v_scaled(red, green, blue);
        }
    }
    for cy in 0..chroma_h {
        let y0 = (cy * 2).saturating_sub(1);
        let y1 = cy * 2;
        let y2 = (cy * 2 + 1).min(ctx.dst_h - 1);
        let y3 = (cy * 2 + 2).min(ctx.dst_h - 1);
        let output_u = row_mut(dst[1], ds[1], cy);
        let output_v = row_mut(dst[2], ds[2], cy);
        for cx in 0..chroma_w {
            *output_u.add(cx) = filtered_chroma_to_u8(
                (1 << 18)
                    + u_rows[y0 * chroma_w + cx] * 1024
                    + u_rows[y1 * chroma_w + cx] * 3072
                    + u_rows[y2 * chroma_w + cx] * 3072
                    + u_rows[y3 * chroma_w + cx] * 1024,
            );
            *output_v.add(cx) = filtered_chroma_to_u8(
                (1 << 18)
                    + v_rows[y0 * chroma_w + cx] * 1024
                    + v_rows[y1 * chroma_w + cx] * 3072
                    + v_rows[y2 * chroma_w + cx] * 3072
                    + v_rows[y3 * chroma_w + cx] * 1024,
            );
        }
    }
}

#[inline]
unsafe fn read_chroma_sample(
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    fmt: c_int,
    cx: usize,
    cy: usize,
) -> (u8, u8) {
    match fmt {
        PIXFMT_NV12 => {
            let p = row_ptr(src[1], ss[1], cy).add(cx * 2);
            (*p, *p.add(1))
        }
        PIXFMT_NV21 => {
            let p = row_ptr(src[1], ss[1], cy).add(cx * 2);
            (*p.add(1), *p)
        }
        _ => (
            *row_ptr(src[1], ss[1], cy).add(cx),
            *row_ptr(src[2], ss[2], cy).add(cx),
        ),
    }
}

#[inline]
fn axis_filter(pos: usize, src_shift: usize, dst_shift: usize, src_n: usize) -> ([usize; 4], [i32; 4]) {
    if src_shift == dst_shift {
        return ([pos.min(src_n - 1), 0, 0, 0], [256, 0, 0, 0]);
    }
    if src_shift < dst_shift {
        let base = (pos * 2) as isize - 1;
        let mut idx = [0usize; 4];
        for i in 0..4 {
            idx[i] = (base + i as isize).clamp(0, src_n as isize - 1) as usize;
        }
        return (idx, [32, 96, 96, 32]);
    }
    let cur = (pos >> 1).min(src_n - 1);
    if pos & 1 == 0 {
        if cur == 0 {
            ([cur, cur, 0, 0], [256, 0, 0, 0])
        } else {
            ([cur - 1, cur, 0, 0], [64, 192, 0, 0])
        }
    } else if cur + 1 >= src_n {
        ([cur, cur, 0, 0], [256, 0, 0, 0])
    } else {
        ([cur, cur + 1, 0, 0], [192, 64, 0, 0])
    }
}

unsafe fn sample_chroma_resampled(
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    fmt: c_int,
    dx: usize,
    dy: usize,
    sxs: usize,
    sys: usize,
    dxs: usize,
    dys: usize,
    src_cw: usize,
    src_ch: usize,
) -> (u8, u8) {
    let (xi, xw) = axis_filter(dx, sxs, dxs, src_cw);
    let (yi, yw) = axis_filter(dy, sys, dys, src_ch);
    let mut us = 0i32;
    let mut vs = 0i32;
    for ky in 0..4 {
        if yw[ky] == 0 {
            continue;
        }
        for kx in 0..4 {
            if xw[kx] == 0 {
                continue;
            }
            let (u, v) = read_chroma_sample(src, ss, fmt, xi[kx], yi[ky]);
            let w = xw[kx] * yw[ky];
            us += u as i32 * w;
            vs += v as i32 * w;
        }
    }
    let u = (us + 32768) >> 16;
    let v = (vs + 32768) >> 16;
    (clip_u8(u), clip_u8(v))
}

unsafe fn yuv_to_yuv(
    ctx: &SwsContext,
    src: &[*const u8; 4],
    ss: &[c_int; 4],
    dst: &[*mut u8; 4],
    ds: &[c_int; 4],
) {
    if ctx.src_w == ctx.dst_w
        && ctx.src_h == ctx.dst_h
        && matches!((ctx.src_fmt, ctx.dst_fmt), (PIXFMT_YUV420P, PIXFMT_YUV422P) | (PIXFMT_YUV422P, PIXFMT_YUV420P))
    {
        planar_420_422_neon(ctx, src, ss, dst, ds);
        return;
    }
    if ctx.algo == ALGO_BILINEAR && (ctx.src_w != ctx.dst_w || ctx.src_h != ctx.dst_h) {
        yuv_to_yuv_bilinear(ctx, src, ss, dst, ds);
        return;
    }
    if ctx.src_w == ctx.dst_w
        && ctx.src_h == ctx.dst_h
        && matches!((ctx.src_fmt, ctx.dst_fmt), (PIXFMT_YUV422P, PIXFMT_YUV444P) | (PIXFMT_YUV444P, PIXFMT_YUV422P))
    {
        planar_422_444(ctx, src, ss, dst, ds);
        return;
    }
    if ctx.src_w == ctx.dst_w
        && ctx.src_h == ctx.dst_h
        && matches!((ctx.src_fmt, ctx.dst_fmt), (PIXFMT_YUV420P, PIXFMT_YUV444P) | (PIXFMT_YUV444P, PIXFMT_YUV420P))
    {
        planar_420_444(ctx, src, ss, dst, ds);
        return;
    }
    for y in 0..ctx.dst_h {
        let sy = if ctx.src_h == ctx.dst_h { y } else { scale_nearest_pos(y, ctx.src_h, ctx.dst_h) };
        let dr = row_mut(dst[0], ds[0], y);
        for x in 0..ctx.dst_w {
            let sx = if ctx.src_w == ctx.dst_w { x } else { scale_nearest_pos(x, ctx.src_w, ctx.dst_w) };
            let (yy, _, _) = sample_yuv(src, ss, ctx.src_fmt, sx, sy);
            *dr.add(x) = yy;
        }
    }
    let (dxs, dys) = chroma_shift(ctx.dst_fmt);
    let (sxs, sys) = chroma_shift(ctx.src_fmt);
    let cw = (ctx.dst_w + (1 << dxs) - 1) >> dxs;
    let ch = (ctx.dst_h + (1 << dys) - 1) >> dys;
    let src_cw = (ctx.src_w + (1 << sxs) - 1) >> sxs;
    let src_ch = (ctx.src_h + (1 << sys) - 1) >> sys;
    for cy in 0..ch {
        for cx in 0..cw {
            let (u, v) = if ctx.src_w == ctx.dst_w && ctx.src_h == ctx.dst_h {
                sample_chroma_resampled(src, ss, ctx.src_fmt, cx, cy, sxs, sys, dxs, dys, src_cw, src_ch)
            } else {
                let dst_y = ((cy << dys) + ((1 << dys) >> 1)).min(ctx.dst_h - 1);
                let dst_x = ((cx << dxs) + ((1 << dxs) >> 1)).min(ctx.dst_w - 1);
                let sx = scale_nearest_pos(dst_x, ctx.src_w, ctx.dst_w);
                let sy = scale_nearest_pos(dst_y, ctx.src_h, ctx.dst_h);
                let (_, u, v) = sample_yuv(src, ss, ctx.src_fmt, sx, sy);
                (u, v)
            };
            match ctx.dst_fmt {
                PIXFMT_NV12 => {
                    let d = row_mut(dst[1], ds[1], cy).add(cx * 2);
                    *d = u;
                    *d.add(1) = v;
                }
                PIXFMT_NV21 => {
                    let d = row_mut(dst[1], ds[1], cy).add(cx * 2);
                    *d = v;
                    *d.add(1) = u;
                }
                _ => {
                    *row_mut(dst[1], ds[1], cy).add(cx) = u;
                    *row_mut(dst[2], ds[2], cy).add(cx) = v;
                }
            }
        }
    }
}

unsafe fn yuv_to_yuv_bilinear(
    ctx: &SwsContext, src: &[*const u8; 4], ss: &[c_int; 4], dst: &[*mut u8; 4], ds: &[c_int; 4],
) {
    for y in 0..ctx.dst_h {
        let (y0, y1, fy) = *ctx.linear_y.get_unchecked(y);
        let row0 = row_ptr(src[0], ss[0], y0);
        let row1 = row_ptr(src[0], ss[0], y1);
        let output = row_mut(dst[0], ds[0], y);
        for x in 0..ctx.dst_w {
            let (x0, x1, fx) = *ctx.linear_x.get_unchecked(x);
            let top = lerp_u8(*row0.add(x0), *row0.add(x1), fx);
            let bottom = lerp_u8(*row1.add(x0), *row1.add(x1), fx);
            *output.add(x) = lerp_u8(top, bottom, fy);
        }
    }
    let (source_x_shift, source_y_shift) = chroma_shift(ctx.src_fmt);
    let (dest_x_shift, dest_y_shift) = chroma_shift(ctx.dst_fmt);
    let source_w = (ctx.src_w + (1 << source_x_shift) - 1) >> source_x_shift;
    let source_h = (ctx.src_h + (1 << source_y_shift) - 1) >> source_y_shift;
    let dest_w = (ctx.dst_w + (1 << dest_x_shift) - 1) >> dest_x_shift;
    let dest_h = (ctx.dst_h + (1 << dest_y_shift) - 1) >> dest_y_shift;
    let x_map: Vec<_> = (0..dest_w).map(|x| scale_linear_pos(x, source_w, dest_w)).collect();
    let y_map: Vec<_> = (0..dest_h).map(|y| scale_linear_pos(y, source_h, dest_h)).collect();
    for y in 0..dest_h {
        let (y0, y1, fy) = *y_map.get_unchecked(y);
        for x in 0..dest_w {
            let (x0, x1, fx) = *x_map.get_unchecked(x);
            let (u00, v00) = read_chroma_sample(src, ss, ctx.src_fmt, x0, y0);
            let (u01, v01) = read_chroma_sample(src, ss, ctx.src_fmt, x1, y0);
            let (u10, v10) = read_chroma_sample(src, ss, ctx.src_fmt, x0, y1);
            let (u11, v11) = read_chroma_sample(src, ss, ctx.src_fmt, x1, y1);
            let u = lerp_u8(lerp_u8(u00, u01, fx), lerp_u8(u10, u11, fx), fy);
            let v = lerp_u8(lerp_u8(v00, v01, fx), lerp_u8(v10, v11, fx), fy);
            match ctx.dst_fmt {
                PIXFMT_NV12 => { let p = row_mut(dst[1], ds[1], y).add(x * 2); *p = u; *p.add(1) = v; }
                PIXFMT_NV21 => { let p = row_mut(dst[1], ds[1], y).add(x * 2); *p = v; *p.add(1) = u; }
                _ => { *row_mut(dst[1], ds[1], y).add(x) = u; *row_mut(dst[2], ds[2], y).add(x) = v; }
            }
        }
    }
}

unsafe fn yuv_to_packed_bilinear(
    ctx: &SwsContext, src: &[*const u8; 4], ss: &[c_int; 4], dst: &[*mut u8; 4], ds: &[c_int; 4],
) {
    let (source_x_shift, source_y_shift) = chroma_shift(ctx.src_fmt);
    let source_cw = (ctx.src_w + (1 << source_x_shift) - 1) >> source_x_shift;
    let source_ch = (ctx.src_h + (1 << source_y_shift) - 1) >> source_y_shift;
    let dest_cw = (ctx.dst_w + (1 << source_x_shift) - 1) >> source_x_shift;
    let dest_ch = ctx.dst_h;
    let chroma_x: Vec<_> = (0..dest_cw)
        .map(|x| scale_linear_pos(x, source_cw, dest_cw))
        .collect();
    let chroma_y: Vec<_> = (0..dest_ch)
        .map(|y| scale_linear_pos(y, source_ch, dest_ch))
        .collect();

    let mut scaled_luma = vec![0u8; ctx.dst_w];
    let mut scaled_u = vec![0u8; dest_cw];
    let mut scaled_v = vec![0u8; dest_cw];
    for y in 0..ctx.dst_h {
        let (y0, y1, fy) = *ctx.linear_y.get_unchecked(y);
        let luma0 = row_ptr(src[0], ss[0], y0);
        let luma1 = row_ptr(src[0], ss[0], y1);
        let output = row_mut(dst[0], ds[0], y);
        let (cy0, cy1, cfy) = *chroma_y.get_unchecked(y);
        for x in 0..ctx.dst_w {
            let (x0, x1, fx) = *ctx.linear_x.get_unchecked(x);
            let yy = lerp_u8(
                lerp_u8(*luma0.add(x0), *luma0.add(x1), fx),
                lerp_u8(*luma1.add(x0), *luma1.add(x1), fx),
                fy,
            );
            if ctx.dst_fmt == PIXFMT_GRAY8 {
                *output.add(x) = yuv_luma_to_gray(yy);
            } else {
                scaled_luma[x] = yy;
            }
        }
        if ctx.dst_fmt == PIXFMT_GRAY8 {
            continue;
        }
        for cx in 0..dest_cw {
            let (cx0, cx1, cfx) = *chroma_x.get_unchecked(cx);
            let (u00, v00) = read_chroma_sample(src, ss, ctx.src_fmt, cx0, cy0);
            let (u01, v01) = read_chroma_sample(src, ss, ctx.src_fmt, cx1, cy0);
            let (u10, v10) = read_chroma_sample(src, ss, ctx.src_fmt, cx0, cy1);
            let (u11, v11) = read_chroma_sample(src, ss, ctx.src_fmt, cx1, cy1);
            scaled_u[cx] = lerp_u8(lerp_u8(u00, u01, cfx), lerp_u8(u10, u11, cfx), cfy);
            scaled_v[cx] = lerp_u8(lerp_u8(v00, v01, cfx), lerp_u8(v10, v11, cfx), cfy);
        }
        #[cfg(target_arch = "aarch64")]
        {
            if source_x_shift == 0 {
                yuv444p_to_rgb24_neon(
                    scaled_luma.as_ptr(), scaled_u.as_ptr(), scaled_v.as_ptr(), output,
                    ctx.dst_fmt, ctx.dst_w,
                );
            } else {
                yuv420_row_neon(
                    scaled_luma.as_ptr(), scaled_u.as_ptr(), scaled_v.as_ptr(), output,
                    ctx.dst_fmt, ctx.dst_w,
                );
            }
            continue;
        }
        #[cfg(not(target_arch = "aarch64"))]
        for x in 0..ctx.dst_w {
            let (red, green, blue) = yuv_to_rgb_for_fmt(
                ctx.src_fmt, scaled_luma[x], scaled_u[x >> source_x_shift], scaled_v[x >> source_x_shift],
            );
            write_packed_rgb(output, ctx.dst_fmt, x, red, green, blue, 255);
        }
    }
}

unsafe fn planar_420_422_neon(
    ctx: &SwsContext, src: &[*const u8; 4], ss: &[c_int; 4], dst: &[*mut u8; 4], ds: &[c_int; 4],
) {
    for y in 0..ctx.src_h {
        ptr::copy_nonoverlapping(row_ptr(src[0], ss[0], y), row_mut(dst[0], ds[0], y), ctx.src_w);
    }
    let width = ctx.src_w >> 1;
    for plane in 1..=2 {
        if ctx.src_fmt == PIXFMT_YUV420P {
            let source_h = ctx.src_h >> 1;
            for y in 0..ctx.dst_h {
                let current_y = y >> 1;
                let output = row_mut(dst[plane], ds[plane], y);
                if y == 0 || (y & 1 == 1 && current_y + 1 >= source_h) {
                    ptr::copy_nonoverlapping(row_ptr(src[plane], ss[plane], current_y), output, width);
                    continue;
                }
                let (a_y, b_y, a_weighted) = if y & 1 == 0 {
                    (current_y - 1, current_y, false)
                } else {
                    (current_y, current_y + 1, true)
                };
                let a = row_ptr(src[plane], ss[plane], a_y);
                let b = row_ptr(src[plane], ss[plane], b_y);
                #[cfg(target_arch = "aarch64")]
                {
                    quarter_rows_neon(a, b, output, width, a_weighted);
                    continue;
                }
                #[cfg(not(target_arch = "aarch64"))]
                for x in 0..width {
                    let (first, second) = if a_weighted { (*a.add(x), *b.add(x)) } else { (*b.add(x), *a.add(x)) };
                    *output.add(x) = ((3 * first as u16 + second as u16 + 2) >> 2) as u8;
                }
            }
        } else {
            for y in 0..(ctx.dst_h >> 1) {
                let base = y * 2;
                let rows = [base.saturating_sub(1), base, (base + 1).min(ctx.src_h - 1), (base + 2).min(ctx.src_h - 1)];
                let pointers = rows.map(|row| row_ptr(src[plane], ss[plane], row));
                let output = row_mut(dst[plane], ds[plane], y);
                #[cfg(target_arch = "aarch64")]
                {
                    downsample_422_row_neon(pointers, output, width);
                    continue;
                }
                #[cfg(not(target_arch = "aarch64"))]
                for x in 0..width {
                    *output.add(x) = ((*pointers[0].add(x) as u16 + 3 * *pointers[1].add(x) as u16 + 3 * *pointers[2].add(x) as u16 + *pointers[3].add(x) as u16 + 4) >> 3) as u8;
                }
            }
        }
    }
}

unsafe fn planar_422_444(
    ctx: &SwsContext, src: &[*const u8; 4], ss: &[c_int; 4], dst: &[*mut u8; 4], ds: &[c_int; 4],
) {
    for y in 0..ctx.src_h {
        ptr::copy_nonoverlapping(row_ptr(src[0], ss[0], y), row_mut(dst[0], ds[0], y), ctx.src_w);
    }
    for plane in 1..=2 {
        for y in 0..ctx.src_h {
            let source = row_ptr(src[plane], ss[plane], y);
            let output = row_mut(dst[plane], ds[plane], y);
            if ctx.src_fmt == PIXFMT_YUV422P {
                #[cfg(target_arch = "aarch64")]
                upsample_chroma_row2_neon(source, output, ctx.src_w >> 1);
                #[cfg(not(target_arch = "aarch64"))]
                upsample_chroma_row2_scalar(source, output, ctx.src_w >> 1);
            } else {
                #[cfg(target_arch = "aarch64")]
                downsample_chroma_row2_neon(source, output, ctx.src_w >> 1);
                #[cfg(not(target_arch = "aarch64"))]
                downsample_chroma_row2_scalar(source, output, ctx.src_w >> 1);
            }
        }
    }
}

unsafe fn planar_420_444(
    ctx: &SwsContext, src: &[*const u8; 4], ss: &[c_int; 4], dst: &[*mut u8; 4], ds: &[c_int; 4],
) {
    for y in 0..ctx.src_h {
        ptr::copy_nonoverlapping(row_ptr(src[0], ss[0], y), row_mut(dst[0], ds[0], y), ctx.src_w);
    }
    for plane in 1..=2 {
        if ctx.src_fmt == PIXFMT_YUV420P {
            let source_w = ctx.src_w >> 1;
            let source_h = ctx.src_h >> 1;
            let mut horizontal = vec![0i32; source_h * ctx.dst_w];
            for y in 0..source_h {
                let row = row_ptr(src[plane], ss[plane], y);
                for x in 0..ctx.dst_w {
                    let current = x >> 1;
                    horizontal[y * ctx.dst_w + x] = if x & 1 == 0 {
                        if current == 0 { *row as i32 * 256 } else { *row.add(current - 1) as i32 * 64 + *row.add(current) as i32 * 192 }
                    } else if current + 1 >= source_w {
                        *row.add(current) as i32 * 256
                    } else {
                        *row.add(current) as i32 * 192 + *row.add(current + 1) as i32 * 64
                    };
                }
            }
            for y in 0..ctx.dst_h {
                let current = y >> 1;
                let output = row_mut(dst[plane], ds[plane], y);
                for x in 0..ctx.dst_w {
                    let value = if y & 1 == 0 {
                        if current == 0 { horizontal[x] * 256 } else { horizontal[(current - 1) * ctx.dst_w + x] * 64 + horizontal[current * ctx.dst_w + x] * 192 }
                    } else if current + 1 >= source_h {
                        horizontal[current * ctx.dst_w + x] * 256
                    } else {
                        horizontal[current * ctx.dst_w + x] * 192 + horizontal[(current + 1) * ctx.dst_w + x] * 64
                    };
                    *output.add(x) = clip_u8((value + 32768) >> 16);
                }
            }
        } else {
            let output_w = ctx.dst_w >> 1;
            let output_h = ctx.dst_h >> 1;
            let mut horizontal = vec![0i32; ctx.src_h * output_w];
            for y in 0..ctx.src_h {
                let row = row_ptr(src[plane], ss[plane], y);
                for x in 0..output_w {
                    let base = x * 2;
                    let indices = [base.saturating_sub(1), base, (base + 1).min(ctx.src_w - 1), (base + 2).min(ctx.src_w - 1)];
                    horizontal[y * output_w + x] = *row.add(indices[0]) as i32 * 32 + *row.add(indices[1]) as i32 * 96 + *row.add(indices[2]) as i32 * 96 + *row.add(indices[3]) as i32 * 32;
                }
            }
            for y in 0..output_h {
                let base = y * 2;
                let rows = [base.saturating_sub(1), base, (base + 1).min(ctx.src_h - 1), (base + 2).min(ctx.src_h - 1)];
                let output = row_mut(dst[plane], ds[plane], y);
                for x in 0..output_w {
                    let value = horizontal[rows[0] * output_w + x] * 32 + horizontal[rows[1] * output_w + x] * 96 + horizontal[rows[2] * output_w + x] * 96 + horizontal[rows[3] * output_w + x] * 32;
                    *output.add(x) = clip_u8((value + 32768) >> 16);
                }
            }
        }
    }
}

#[cfg(not(target_arch = "aarch64"))]
unsafe fn upsample_chroma_row2_scalar(source: *const u8, output: *mut u8, source_w: usize) {
    for x in 0..source_w {
        let previous = *source.add(x.saturating_sub(1)) as u16;
        let current = *source.add(x) as u16;
        let next = *source.add((x + 1).min(source_w - 1)) as u16;
        *output.add(x * 2) = ((previous + 3 * current + 2) >> 2) as u8;
        *output.add(x * 2 + 1) = ((3 * current + next + 2) >> 2) as u8;
    }
}

#[cfg(not(target_arch = "aarch64"))]
unsafe fn downsample_chroma_row2_scalar(source: *const u8, output: *mut u8, output_w: usize) {
    for x in 0..output_w {
        let base = x * 2;
        let a = *source.add(base.saturating_sub(1)) as u16;
        let b = *source.add(base) as u16;
        let c = *source.add((base + 1).min(output_w * 2 - 1)) as u16;
        let d = *source.add((base + 2).min(output_w * 2 - 1)) as u16;
        *output.add(x) = ((a + 3 * b + 3 * c + d + 4) >> 3) as u8;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn upsample_chroma_row2_neon(source: *const u8, output: *mut u8, source_w: usize) {
    if source_w == 0 { return; }
    let first = *source as u16;
    let next = *source.add(1.min(source_w - 1)) as u16;
    *output = first as u8;
    *output.add(1) = ((3 * first + next + 2) >> 2) as u8;
    let mut x = 1;
    while x + 16 < source_w {
        let previous = vld1q_u8(source.add(x - 1));
        let current = vld1q_u8(source.add(x));
        let next = vld1q_u8(source.add(x + 1));
        let even = quarter_weight_neon(previous, current);
        let odd = quarter_weight_neon(next, current);
        vst1q_u8(output.add(x * 2), vzip1q_u8(even, odd));
        vst1q_u8(output.add(x * 2 + 16), vzip2q_u8(even, odd));
        x += 16;
    }
    while x < source_w {
        let previous = *source.add(x - 1) as u16;
        let current = *source.add(x) as u16;
        let next = *source.add((x + 1).min(source_w - 1)) as u16;
        *output.add(x * 2) = ((previous + 3 * current + 2) >> 2) as u8;
        *output.add(x * 2 + 1) = ((3 * current + next + 2) >> 2) as u8;
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn downsample_chroma_row2_neon(source: *const u8, output: *mut u8, output_w: usize) {
    if output_w == 0 { return; }
    let source_w = output_w * 2;
    *output = ((4 * *source as u16
        + 3 * *source.add(1.min(source_w - 1)) as u16
        + *source.add(2.min(source_w - 1)) as u16
        + 4) >> 3) as u8;
    let weighted = |a: uint8x16_t, b: uint8x16_t, c: uint8x16_t, d: uint8x16_t| {
        let calculate = |a: uint8x8_t, b: uint8x8_t, c: uint8x8_t, d: uint8x8_t| {
            let sum = vaddq_u16(vaddq_u16(vmovl_u8(a), vmovl_u8(d)), vmulq_n_u16(vaddq_u16(vmovl_u8(b), vmovl_u8(c)), 3));
            vrshrn_n_u16::<3>(sum)
        };
        vcombine_u8(calculate(vget_low_u8(a), vget_low_u8(b), vget_low_u8(c), vget_low_u8(d)), calculate(vget_high_u8(a), vget_high_u8(b), vget_high_u8(c), vget_high_u8(d)))
    };
    let mut x = 1;
    while x + 16 < output_w {
        let first = vld2q_u8(source.add(x * 2 - 1));
        let second = vld2q_u8(source.add(x * 2 - 1 + 32));
        let c = vextq_u8::<1>(first.0, second.0);
        let d = vextq_u8::<1>(first.1, second.1);
        vst1q_u8(output.add(x), weighted(first.0, first.1, c, d));
        x += 16;
    }
    while x < output_w {
        let base = x * 2;
        let a = *source.add(base - 1) as u16;
        let b = *source.add(base) as u16;
        let c = *source.add((base + 1).min(output_w * 2 - 1)) as u16;
        let d = *source.add((base + 2).min(output_w * 2 - 1)) as u16;
        *output.add(x) = ((a + 3 * b + 3 * c + d + 4) >> 3) as u8;
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn quarter_rows_neon(a: *const u8, b: *const u8, output: *mut u8, length: usize, a_weighted: bool) {
    let mut x = 0;
    while x + 16 <= length {
        let a = vld1q_u8(a.add(x));
        let b = vld1q_u8(b.add(x));
        let value = if a_weighted { quarter_weight_neon(b, a) } else { quarter_weight_neon(a, b) };
        vst1q_u8(output.add(x), value);
        x += 16;
    }
    while x < length {
        let (first, second) = if a_weighted { (*a.add(x), *b.add(x)) } else { (*b.add(x), *a.add(x)) };
        *output.add(x) = ((3 * first as u16 + second as u16 + 2) >> 2) as u8;
        x += 1;
    }
}

#[cfg(target_arch = "aarch64")]
unsafe fn downsample_422_row_neon(rows: [*const u8; 4], output: *mut u8, length: usize) {
    let mut x = 0;
    while x + 16 <= length {
        let a = vld1q_u8(rows[0].add(x));
        let b = vld1q_u8(rows[1].add(x));
        let c = vld1q_u8(rows[2].add(x));
        let d = vld1q_u8(rows[3].add(x));
        let calculate = |a: uint8x8_t, b: uint8x8_t, c: uint8x8_t, d: uint8x8_t| {
            let sum = vaddq_u16(vaddq_u16(vmovl_u8(a), vmovl_u8(d)), vmulq_n_u16(vaddq_u16(vmovl_u8(b), vmovl_u8(c)), 3));
            vrshrn_n_u16::<3>(sum)
        };
        vst1q_u8(output.add(x), vcombine_u8(
            calculate(vget_low_u8(a), vget_low_u8(b), vget_low_u8(c), vget_low_u8(d)),
            calculate(vget_high_u8(a), vget_high_u8(b), vget_high_u8(c), vget_high_u8(d)),
        ));
        x += 16;
    }
    while x < length {
        *output.add(x) = ((*rows[0].add(x) as u16 + 3 * *rows[1].add(x) as u16 + 3 * *rows[2].add(x) as u16 + *rows[3].add(x) as u16 + 4) >> 3) as u8;
        x += 1;
    }
}

#[no_mangle]
pub extern "C" fn swscale_create(
    src_w: c_int,
    src_h: c_int,
    src_fmt: c_int,
    dst_w: c_int,
    dst_h: c_int,
    dst_fmt: c_int,
    algo: c_int,
) -> *mut c_void {
    if src_w <= 0
        || src_h <= 0
        || dst_w <= 0
        || dst_h <= 0
        || !valid_fmt(src_fmt)
        || !valid_fmt(dst_fmt)
        || !(ALGO_NEAREST..=ALGO_BICUBIC).contains(&algo)
    {
        return ptr::null_mut();
    }
    let scaling = src_w != dst_w || src_h != dst_h;
    let linear_x = if scaling && algo == ALGO_BILINEAR {
        (0..dst_w as usize).map(|x| scale_linear_pos(x, src_w as usize, dst_w as usize)).collect()
    } else {
        Vec::new()
    };
    let linear_y = if scaling && algo == ALGO_BILINEAR {
        (0..dst_h as usize).map(|y| scale_linear_pos(y, src_h as usize, dst_h as usize)).collect()
    } else {
        Vec::new()
    };
    let nearest_x = if scaling && algo == ALGO_NEAREST {
        (0..dst_w as usize).map(|x| scale_nearest_pos(x, src_w as usize, dst_w as usize)).collect()
    } else {
        Vec::new()
    };
    let nearest_y = if scaling && algo == ALGO_NEAREST {
        (0..dst_h as usize).map(|y| scale_nearest_pos(y, src_h as usize, dst_h as usize)).collect()
    } else {
        Vec::new()
    };
    let ctx = Box::new(SwsContext {
        src_w: src_w as usize,
        src_h: src_h as usize,
        src_fmt,
        dst_w: dst_w as usize,
        dst_h: dst_h as usize,
        dst_fmt,
        algo,
        linear_x,
        linear_y,
        nearest_x,
        nearest_y,
    });
    Box::into_raw(ctx) as *mut c_void
}

#[no_mangle]
pub extern "C" fn swscale_process(
    opaque: *mut c_void,
    src_data: *const *const u8,
    src_stride: *const c_int,
    dst_data: *const *mut u8,
    dst_stride: *const c_int,
) -> c_int {
    if opaque.is_null() || src_data.is_null() || src_stride.is_null() || dst_data.is_null() || dst_stride.is_null() {
        return -1;
    }
    let ctx = unsafe { &*(opaque as *const SwsContext) };
    unsafe {
        let src = [
            *src_data.add(0),
            *src_data.add(1),
            *src_data.add(2),
            *src_data.add(3),
        ];
        let dst = [
            *dst_data.add(0),
            *dst_data.add(1),
            *dst_data.add(2),
            *dst_data.add(3),
        ];
        let ss = [
            *src_stride.add(0),
            *src_stride.add(1),
            *src_stride.add(2),
            *src_stride.add(3),
        ];
        let ds = [
            *dst_stride.add(0),
            *dst_stride.add(1),
            *dst_stride.add(2),
            *dst_stride.add(3),
        ];
        if src[0].is_null() || dst[0].is_null() {
            return -2;
        }
        if ctx.src_w == ctx.dst_w && ctx.src_h == ctx.dst_h {
            if ctx.src_fmt == ctx.dst_fmt {
                copy_same(ctx.src_fmt, ctx.src_w, ctx.src_h, &src, &ss, &dst, &ds);
                return 0;
            }
            if planar_nv_convert(ctx.src_fmt, ctx.dst_fmt, ctx.src_w, ctx.src_h, &src, &ss, &dst, &ds) {
                return 0;
            }
            if exact_rgb_convert(ctx.src_fmt, ctx.dst_fmt, ctx.src_w, ctx.src_h, src[0], ss[0], dst[0], ds[0]) {
                return 0;
            }
            if (is_yuv(ctx.src_fmt) || ctx.src_fmt == PIXFMT_GRAY8) && (kind(ctx.dst_fmt) == Kind::Rgb || ctx.dst_fmt == PIXFMT_GRAY8) {
                convert_yuv_to_packed(ctx, &src, &ss, &dst, &ds);
                return 0;
            }
            if (kind(ctx.src_fmt) == Kind::Rgb || ctx.src_fmt == PIXFMT_GRAY8) && (is_yuv(ctx.dst_fmt) || ctx.dst_fmt == PIXFMT_GRAY8) {
                convert_packed_to_yuv_same_size(ctx, &src, &ss, &dst, &ds);
                return 0;
            }
            if is_yuv(ctx.src_fmt) && is_yuv(ctx.dst_fmt) {
                yuv_to_yuv(ctx, &src, &ss, &dst, &ds);
                return 0;
            }
        }

        if (kind(ctx.src_fmt) == Kind::Rgb || ctx.src_fmt == PIXFMT_GRAY8)
            && (kind(ctx.dst_fmt) == Kind::Rgb || ctx.dst_fmt == PIXFMT_GRAY8)
        {
            scale_rgb_to_rgb(ctx, &src, &ss, &dst, &ds);
        } else if is_yuv(ctx.src_fmt) && is_yuv(ctx.dst_fmt) {
            yuv_to_yuv(ctx, &src, &ss, &dst, &ds);
        } else if is_yuv(ctx.src_fmt)
            && (kind(ctx.dst_fmt) == Kind::Rgb || ctx.dst_fmt == PIXFMT_GRAY8)
            && ctx.algo == ALGO_BILINEAR
            && !(ctx.src_fmt == PIXFMT_YUV420P
                && ctx.dst_fmt == PIXFMT_RGB24
                && ctx.src_w == ctx.dst_w * 2
                && ctx.src_h == ctx.dst_h * 2)
            && !(ctx.src_fmt == PIXFMT_YUV420P
                && ctx.dst_fmt == PIXFMT_RGB24
                && ctx.src_w == ctx.dst_w * 3
                && ctx.src_h == ctx.dst_h * 3)
        {
            yuv_to_packed_bilinear(ctx, &src, &ss, &dst, &ds);
        } else if ctx.src_fmt == PIXFMT_YUV420P
            && ctx.dst_fmt == PIXFMT_RGB24
            && ctx.algo == ALGO_BILINEAR
            && ctx.src_w == ctx.dst_w * 2
            && ctx.src_h == ctx.dst_h * 2
        {
            scale_yuv420p_to_rgb24_down2_bilinear(ctx, &src, &ss, &dst, &ds);
        } else if ctx.src_fmt == PIXFMT_YUV420P
            && ctx.dst_fmt == PIXFMT_RGB24
            && ctx.algo == ALGO_BILINEAR
            && ctx.src_w == ctx.dst_w * 3
            && ctx.src_h == ctx.dst_h * 3
        {
            scale_yuv420p_to_rgb24_down3_bilinear(ctx, &src, &ss, &dst, &ds);
        } else if ctx.src_fmt == PIXFMT_RGB24
            && ctx.dst_fmt == PIXFMT_YUV420P
            && ctx.algo == ALGO_NEAREST
            && ctx.src_w == ctx.dst_w * 2
            && ctx.src_h == ctx.dst_h * 2
        {
            scale_rgb24_to_yuv420p_down2_nearest(ctx, &src, &ss, &dst, &ds);
        } else {
            generic_rgb_pipeline(ctx, &src, &ss, &dst, &ds);
        }
    }
    0
}

#[no_mangle]
pub extern "C" fn swscale_destroy(opaque: *mut c_void) {
    if !opaque.is_null() {
        unsafe {
            drop(Box::from_raw(opaque as *mut SwsContext));
        }
    }
}
