"""Constant-plane comparison: saturating and out-of-gamut inputs.

Noise and gradients rarely pin a whole frame at 0 or 255, so the clamping
branches in the colour transforms only get exercised deterministically here.
"""
import sys, math
sys.path.insert(0,"/app/workspace")
import numpy as np
from pixel_formats import (PIXFMT_DESCS,PIXFMT_NAMES,load_swscale_library, allocate_image,
                           image_to_bytes, fill_image_from_bytes)
b=load_swscale_library("/app/libswscale_public_baseline.so")
c=load_swscale_library("/home/workspace/swscale-impl/target/release/libswscale_candidate.so")
def psnr(x,y):
    if x==y: return 999.0
    a=np.frombuffer(x,np.uint8).astype(np.int32); d=np.frombuffer(y,np.uint8).astype(np.int32)
    m=float(np.mean((a-d)**2)); return 999.0 if m==0 else 10*math.log10(65025/m)
vals=[(0,0,0),(255,255,255),(0,255,255),(255,0,0),(16,128,128),(235,128,128),(128,16,240),(1,254,1)]
sizes=[(64,64,64,64),(64,64,32,32),(64,64,128,128),(66,34,22,90)]
fails=0; n=0
for sf in range(10):
  d0=PIXFMT_DESCS[sf]
  for (v0,v1,v2) in vals:
    pv=[v0,v1,v2,v1]
    for (sw,sh,dw,dh) in sizes:
      if (sf in (0,1,3,4) and (sw&1 or dw&1)) or (sf in (0,3,4) and (sh&1 or dh&1)): continue
      sp=[]
      for i in range(d0.num_planes):
          pw=d0.plane_width(i,sw)*d0.planes[i].bpp; ph=d0.plane_height(i,sh)
          if d0.planes[i].bpp==2:   # NV chroma: alternate the two values
              row=bytes([pv[1],pv[2]]*(pw//2))
          elif d0.planes[i].bpp==3:
              row=bytes([pv[0],pv[1],pv[2]]*(pw//3))
          elif d0.planes[i].bpp==4:
              row=bytes([pv[0],pv[1],pv[2],pv[3]]*(pw//4))
          else:
              row=bytes([pv[min(i,2)]]*pw)
          sp.append(row*ph)
      for df in range(10):
        if (df in (0,1,3,4) and (dw&1)) or (df in (0,3,4) and (dh&1)): continue
        for algo in range(3):
          n+=1
          sd,ss,_=allocate_image(sf,sw,sh,32); fill_image_from_bytes(sf,sw,sh,sd,ss,sp)
          o=[]
          for lib in (b,c):
            dd,ds,_=allocate_image(df,dw,dh,32)
            ctx=lib.swscale_create(sw,sh,sf,dw,dh,df,algo)
            if not ctx: o.append(None); continue
            lib.swscale_process(ctx,sd,ss,dd,ds); o.append(image_to_bytes(df,dw,dh,dd,ds)); lib.swscale_destroy(ctx)
          if (o[0] is None)!=(o[1] is None): print("NULLCTX"); fails+=1; continue
          if o[0] is None: continue
          w=min(psnr(x,y) for x,y in zip(*o))
          thr=60.0 if (sw==dw and sh==dh) else 40.0
          if w<thr:
            fails+=1
            print(f"FAIL {PIXFMT_NAMES[sf]}->{PIXFMT_NAMES[df]} {sw}x{sh}->{dw}x{dh} a{algo} v={pv}: {w:.2f}")
print(f"extreme-values: {n-fails}/{n} pass")
