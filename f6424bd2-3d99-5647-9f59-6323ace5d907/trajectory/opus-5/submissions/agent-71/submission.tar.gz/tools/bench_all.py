#!/usr/bin/env python3
"""Broad benchmark: candidate vs baseline across many format pairs / scalings."""
from __future__ import annotations
import math, sys, time, random, argparse
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_DESCS, PIXFMT_NAMES, ALGO_NAMES, load_swscale_library,
                           allocate_image, fill_image_from_bytes)

BASE = "/app/libswscale_public_baseline.so"
CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"


def gen(fmt, w, h, seed=5):
    desc = PIXFMT_DESCS[fmt]
    rng = random.Random(seed)
    out = []
    for i in range(desc.num_planes):
        pw = desc.plane_width(i, w) * desc.planes[i].bpp
        ph = desc.plane_height(i, h)
        out.append(bytes(rng.getrandbits(8) for _ in range(pw * ph)))
    return out


def bench(lib, wl, iters, warm=3):
    sf, df = wl["sf"], wl["df"]
    sw, sh, dw, dh, algo = wl["sw"], wl["sh"], wl["dw"], wl["dh"], wl["algo"]
    sp = gen(sf, sw, sh)
    sd, ss, sb = allocate_image(sf, sw, sh)
    fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
    dd, ds, db = allocate_image(df, dw, dh)
    t0 = time.perf_counter()
    ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
    create_t = time.perf_counter() - t0
    if not ctx:
        return None
    for _ in range(warm):
        lib.swscale_process(ctx, sd, ss, dd, ds)
    ts = []
    for _ in range(iters):
        t0 = time.perf_counter()
        lib.swscale_process(ctx, sd, ss, dd, ds)
        ts.append(time.perf_counter() - t0)
    lib.swscale_destroy(ctx)
    ts.sort()
    return ts[len(ts) // 2], create_t


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--iters", type=int, default=7)
    ap.add_argument("--w", type=int, default=1280)
    ap.add_argument("--h", type=int, default=720)
    ap.add_argument("--full", action="store_true")
    args = ap.parse_args()
    cand = load_swscale_library(CAND)
    base = load_swscale_library(BASE)

    W, H = args.w, args.h
    # Heavier downscales are included because they are where the vertical and
    # packed-RGB filters run out of const-generic tap specialisations.
    cfgs = [(W, H, W, H, 1), (W, H, W // 2, H // 2, 1), (W, H, W * 2, H * 2, 1),
            (W, H, W // 2, H // 2, 2), (W, H, W * 2, H * 2, 2), (W, H, W // 2, H // 2, 0),
            (W, H, 640, 360, 1), (W, H, W // 4, H // 4, 2), (W, H, W // 8, H // 8, 2),
            (W, H, W // 4, H // 4, 1), (W, H, W, H // 4, 2)]
    rows = []
    speeds = []
    for algo_cfg in cfgs:
        sw, sh, dw, dh, algo = algo_cfg
        for sf in range(10):
            for df in range(10):
                wl = dict(sf=sf, df=df, sw=sw, sh=sh, dw=dw, dh=dh, algo=algo)
                try:
                    b = bench(base, wl, args.iters)
                    c = bench(cand, wl, args.iters)
                except Exception as e:
                    print("ERR", e)
                    continue
                if not b or not c:
                    continue
                sp = b[0] / max(c[0], 1e-12)
                speeds.append(sp)
                rows.append((sp, f"{PIXFMT_NAMES[sf]}->{PIXFMT_NAMES[df]} {sw}x{sh}->{dw}x{dh} {ALGO_NAMES[algo]}",
                             b[0] * 1e3, c[0] * 1e3, b[1] * 1e3, c[1] * 1e3))
    rows.sort()
    print(f"{'speedup':>8}  {'base_ms':>8} {'cand_ms':>8} {'bcreate':>8} {'ccreate':>8}  label")
    for sp, lbl, bm, cm, bc, cc in rows:
        print(f"{sp:8.3f}  {bm:8.3f} {cm:8.3f} {bc:8.2f} {cc:8.2f}  {lbl}")
    g = math.exp(sum(math.log(max(s, 1e-9)) for s in speeds) / len(speeds))
    print(f"\nGeomean: {g:.4f}  over {len(speeds)}")


if __name__ == "__main__":
    main()
