//! Colour conversion constants, matching FFmpeg's BT.601 defaults.

// input_rgb2yuv_table (RGB2YUV_SHIFT = 15) — always limited range
// (fill_rgb2yuv_table forces dstRange = 0).
pub const RY: i32 = 8414;
pub const GY: i32 = 16519;
pub const BY: i32 = 3208;
pub const RU: i32 = -4865;
pub const GU: i32 = -9528;
pub const BU: i32 = 14392;
pub const RV: i32 = 14392;
pub const GV: i32 = -12061;
pub const BV: i32 = -2332;

/// yuv2rgb coefficients; the variant depends on `srcRange`.
#[derive(Clone, Copy)]
pub struct Cf {
    pub y_offset: i32,
    pub y_coeff: i32,
    pub v2r: i32,
    pub v2g: i32,
    pub u2g: i32,
    pub u2b: i32,
    pub cy: i32,
    pub kr0: i32,
    pub kg0: i32,
    pub kb0: i32,
    pub tcrv: i32,
    pub tcbu: i32,
    pub tcgu: i32,
    pub tcgv: i32,
}

const fn mk(
    y_offset: i32,
    y_coeff: i32,
    v2r: i32,
    v2g: i32,
    u2g: i32,
    u2b: i32,
    cy: i32,
    crv: i32,
    cbu: i32,
    cgu: i32,
    cgv: i32,
    yoffs: i32,
    oy: i32,
) -> Cf {
    let yb0 = -(384 << 16) - 512 * cy - oy;
    Cf {
        y_offset,
        y_coeff,
        v2r,
        v2g,
        u2g,
        u2b,
        cy,
        kr0: yb0 + 32768 + (yoffs - (crv >> 9)) * cy,
        kg0: yb0 + 32768 + (yoffs - (cgu >> 9) - (cgv >> 9)) * cy,
        kb0: yb0 + 32768 + (yoffs - (cbu >> 9)) * cy,
        tcrv: crv,
        tcbu: cbu,
        tcgu: cgu,
        tcgv: cgv,
    }
}

/// srcRange == 0 (limited / MPEG range input)
pub const CF_LIMITED: Cf = mk(
    8192, 9539, 13075, -6660, -3209, 16525, 76309, 89830, 113537, -22049, -45756, 838, 16 << 16,
);
/// srcRange == 1 (full / JPEG range input)
pub const CF_FULL: Cf = mk(
    0, 8192, 11485, -5850, -2819, 14516, 65536, 91881, 116129, -22553, -46801, 896, 0,
);

#[inline(always)]
pub fn clip_u8(v: i32) -> u8 {
    if v < 0 {
        0
    } else if v > 255 {
        255
    } else {
        v as u8
    }
}

#[inline(always)]
pub fn clip_uintp2_30(v: i32) -> i32 {
    if v < 0 {
        0
    } else if v > 0x3FFF_FFFF {
        0x3FFF_FFFF
    } else {
        v
    }
}

/// Constant terms of the y-table lookups for a given chroma pair.
#[inline(always)]
pub fn rgb_bases(cf: &Cf, u: i32, v: i32) -> (i32, i32, i32) {
    let uu = u.clamp(0, 255);
    let vv = v.clamp(0, 255);
    (
        cf.kr0 + ((vv * cf.tcrv) >> 16) * cf.cy,
        cf.kg0 + (((uu * cf.tcgu) >> 16) + ((vv * cf.tcgv) >> 16)) * cf.cy,
        cf.kb0 + ((uu * cf.tcbu) >> 16) * cf.cy,
    )
}

#[inline(always)]
pub fn ytab(cf: &Cf, k: i32, y: i32) -> u8 {
    clip_u8((k + y * cf.cy) >> 16)
}

// ── limited/full range conversion of 15-bit intermediates ───────────────────

#[inline(always)]
pub unsafe fn lum_range_to_jpeg(dst: *mut i16, n: usize) {
    for i in 0..n {
        let v = (*dst.add(i) as i32).min(30189);
        *dst.add(i) = ((v * 19077 - 39057361) >> 14) as i16;
    }
}

#[inline(always)]
pub unsafe fn lum_range_from_jpeg(dst: *mut i16, n: usize) {
    for i in 0..n {
        let v = *dst.add(i) as i32;
        *dst.add(i) = ((v * 14071 + 33561947) >> 14) as i16;
    }
}

#[inline(always)]
pub unsafe fn chr_range_to_jpeg(dst: *mut i16, n: usize) {
    for i in 0..n {
        let v = (*dst.add(i) as i32).min(30775);
        *dst.add(i) = ((v * 4663 - 9289992) >> 12) as i16;
    }
}

#[inline(always)]
pub unsafe fn chr_range_from_jpeg(dst: *mut i16, n: usize) {
    for i in 0..n {
        let v = *dst.add(i) as i32;
        *dst.add(i) = ((v * 1799 + 4081085) >> 11) as i16;
    }
}
