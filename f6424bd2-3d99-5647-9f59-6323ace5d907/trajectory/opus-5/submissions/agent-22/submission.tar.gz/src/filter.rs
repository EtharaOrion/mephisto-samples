//! Port of FFmpeg libswscale `initFilter()` (utils.c) — filter coefficient generation.
//!
//! The verifier compares against FFmpeg's C scalar swscale, so filter positions and
//! weights have to match bit-for-bit; this is a direct transliteration.

pub const ALGO_NEAREST: i32 = 0;
pub const ALGO_BICUBIC: i32 = 2;

const CUTOFF: f64 = 0.002; // SWS_MAX_REDUCE_CUTOFF

#[derive(Clone, Debug)]
pub struct Filter {
    pub coeffs: Vec<i16>, // dst_len * size
    pub pos: Vec<i32>,    // dst_len
    pub size: usize,
    /// true when the filter is the identity: size == 1, pos[i] == i, coeffs[i] == one
    pub identity: bool,
    /// max over i of pos[i] + size — how far past the row start a tap may read
    pub max_read: usize,
    /// coefficients zero-padded to `size_p` taps per output (SIMD friendly)
    pub coeffs_p: Vec<i16>,
    pub size_p: usize,
    /// single-tap unit-weight filter (point sampling): each output is one source
    /// sample, so whole groups can be gathered with a table lookup.
    pub point: bool,
    /// per group of 16 outputs: window start, or -1 when the 64-byte window
    /// would run past the end of the row.
    pub gbase: Vec<i32>,
    /// per group of 16 outputs: byte offsets within the window
    pub gidx: Vec<u8>,
    /// same idea for 16-bit sources: groups of 8 outputs over a 32-sample window
    pub gbase16: Vec<i32>,
    pub gidx16: Vec<u8>,
}

#[inline]
fn av_log2(v: u32) -> i32 {
    if v == 0 {
        0
    } else {
        31 - v.leading_zeros() as i32
    }
}

#[inline]
fn rounded_div(a: i64, b: i64) -> i64 {
    if a >= 0 {
        (a + (b >> 1)) / b
    } else {
        (a - (b >> 1)) / b
    }
}

/// `get_local_pos(s, chr_subsample, pos, dir)` with pos == -1 (unspecified chroma position).
pub fn get_local_pos(chr_subsample: u32) -> i32 {
    let pos = (128i32 << chr_subsample) - 128;
    (pos + 128) >> chr_subsample
}

pub fn init_filter(
    x_inc: i64,
    src_w: usize,
    dst_w: usize,
    one: i64,
    algo: i32,
    src_pos: i32,
    dst_pos: i32,
) -> Filter {
    let dst_w_i = dst_w as i64;
    let src_w_i = src_w as i64;
    let ratio = if dst_w == 0 { 0 } else { src_w / dst_w };
    let shift = av_log2(ratio as u32).min(8);
    let fone: i64 = 1i64 << (54 - shift);

    let mut filter_pos: Vec<i32> = vec![0; dst_w + 3];
    let filter_size: usize;
    let mut filter: Vec<i64>;

    if (x_inc - 0x10000).abs() < 10 && src_pos == dst_pos {
        filter_size = 1;
        filter = vec![0i64; dst_w * filter_size];
        for i in 0..dst_w {
            filter[i] = fone;
            filter_pos[i] = i as i32;
        }
    } else if algo == ALGO_NEAREST {
        filter_size = 1;
        filter = vec![0i64; dst_w * filter_size];
        let mut x_dst_in_src: i64 = ((dst_pos as i64 * x_inc) >> 8) - ((src_pos as i64 * 0x8000) >> 7);
        for i in 0..dst_w {
            let xx = (x_dst_in_src - ((filter_size as i64 - 1) << 15) + (1 << 15)) >> 16;
            filter_pos[i] = xx as i32;
            filter[i] = fone;
            x_dst_in_src += x_inc;
        }
    } else {
        let size_factor: i64 = if algo == ALGO_BICUBIC { 4 } else { 2 };
        let mut fs: i64 = if x_inc <= (1 << 16) {
            1 + size_factor
        } else {
            1 + (size_factor * src_w_i + dst_w_i - 1) / dst_w_i
        };
        fs = fs.min(src_w_i - 2).max(1);
        filter_size = fs as usize;
        filter = vec![0i64; dst_w * filter_size];

        let mut x_dst_in_src: i64 =
            ((dst_pos as i64 * x_inc) >> 7) - ((src_pos as i64 * 0x10000) >> 7);
        let c_param: i64 = (0.6f64 * (1 << 24) as f64) as i64;

        for i in 0..dst_w {
            let mut xx: i64 = (x_dst_in_src - (fs - 2) * (1i64 << 16)) / (1 << 17);
            filter_pos[i] = xx as i32;
            for j in 0..filter_size {
                let mut d: i64 = ((xx * (1i64 << 17)) - x_dst_in_src).abs() << 13;
                if x_inc > (1 << 16) {
                    d = d * dst_w_i / src_w_i;
                }
                let coeff: i64;
                if algo == ALGO_BICUBIC {
                    let b: i64 = 0;
                    let cc: i64 = c_param;
                    if d >= 1i64 << 31 {
                        coeff = 0;
                    } else {
                        let dd = (d * d) >> 30;
                        let ddd = (dd * d) >> 30;
                        let raw = if d < 1i64 << 30 {
                            (12 * (1 << 24) - 9 * b - 6 * cc) * ddd
                                + (-18 * (1 << 24) + 12 * b + 6 * cc) * dd
                                + (6 * (1 << 24) - 2 * b) * (1i64 << 30)
                        } else {
                            (-b - 6 * cc) * ddd
                                + (6 * b + 30 * cc) * dd
                                + (-12 * b - 48 * cc) * d
                                + (8 * b + 24 * cc) * (1i64 << 30)
                        };
                        coeff = raw / ((1i64 << 54) / fone);
                    }
                } else {
                    // bilinear
                    let mut c2 = (1i64 << 30) - d;
                    if c2 < 0 {
                        c2 = 0;
                    }
                    coeff = c2 * (fone >> 30);
                }
                filter[i * filter_size + j] = coeff;
                xx += 1;
            }
            x_dst_in_src += 2 * x_inc;
        }
    }

    // filter2 == filter (no srcFilter / dstFilter)
    let filter2_size = filter_size;
    let mut filter2 = filter;

    // try to reduce the filter-size (step1 find size and shift left)
    let mut min_filter_size = 0usize;
    let cut = CUTOFF * fone as f64;
    for i in (0..dst_w).rev() {
        let mut min = filter2_size;
        let mut cut_off: i64 = 0;
        for _j in 0..filter2_size {
            cut_off += filter2[i * filter2_size].abs();
            if (cut_off as f64) > cut {
                break;
            }
            if i < dst_w - 1 && filter_pos[i] >= filter_pos[i + 1] {
                break;
            }
            for k in 1..filter2_size {
                filter2[i * filter2_size + k - 1] = filter2[i * filter2_size + k];
            }
            filter2[i * filter2_size + filter2_size - 1] = 0;
            filter_pos[i] += 1;
        }

        cut_off = 0;
        let mut j = filter2_size as i64 - 1;
        while j > 0 {
            cut_off += filter2[i * filter2_size + j as usize].abs();
            if (cut_off as f64) > cut {
                break;
            }
            min -= 1;
            j -= 1;
        }
        if min > min_filter_size {
            min_filter_size = min;
        }
    }
    if min_filter_size == 0 {
        min_filter_size = 1;
    }
    let out_size = min_filter_size;

    let mut f: Vec<i64> = vec![0; dst_w * out_size];
    for i in 0..dst_w {
        for j in 0..out_size {
            f[i * out_size + j] = if j >= filter2_size {
                0
            } else {
                filter2[i * filter2_size + j]
            };
        }
    }

    // fix borders
    let srcw = src_w as i32;
    let osz = out_size as i32;
    for i in 0..dst_w {
        if filter_pos[i] < 0 {
            for j in 1..out_size {
                let left = (j as i32 + filter_pos[i]).max(0) as usize;
                f[i * out_size + left] += f[i * out_size + j];
                f[i * out_size + j] = 0;
            }
            filter_pos[i] = 0;
        }
        if filter_pos[i] + osz > srcw {
            let shift = filter_pos[i] + (osz - srcw).min(0);
            let mut acc: i64 = 0;
            for j in (0..out_size).rev() {
                if filter_pos[i] + j as i32 >= srcw {
                    acc += f[i * out_size + j];
                    f[i * out_size + j] = 0;
                }
            }
            for j in (0..out_size).rev() {
                if (j as i32) < shift {
                    f[i * out_size + j] = 0;
                } else {
                    f[i * out_size + j] = f[i * out_size + j - shift as usize];
                }
            }
            filter_pos[i] -= shift;
            let idx = (srcw - 1 - filter_pos[i]) as usize;
            f[i * out_size + idx] += acc;
        }
    }

    // normalize & store
    let mut out: Vec<i16> = vec![0; out_size * (dst_w + 3)];
    for i in 0..dst_w {
        let mut error: i64 = 0;
        let mut sum: i64 = 0;
        for j in 0..out_size {
            sum += f[i * out_size + j];
        }
        sum = (sum + one / 2) / one;
        if sum == 0 {
            sum = 1;
        }
        for j in 0..out_size {
            let v = f[i * out_size + j] + error;
            let int_v = rounded_div(v, sum);
            out[i * out_size + j] = int_v as i16;
            error = v - int_v * sum;
        }
    }
    for i in 0..out_size {
        let k = (dst_w - 1) * out_size + i;
        out[k + out_size] = out[k];
        out[k + 2 * out_size] = out[k];
        out[k + 3 * out_size] = out[k];
    }
    filter_pos[dst_w] = filter_pos[dst_w - 1];
    filter_pos[dst_w + 1] = filter_pos[dst_w - 1];
    filter_pos[dst_w + 2] = filter_pos[dst_w - 1];

    let mut identity = out_size == 1;
    if identity {
        for i in 0..dst_w {
            if filter_pos[i] != i as i32 || out[i] as i64 != one {
                identity = false;
                break;
            }
        }
    }

    filter_pos.truncate(dst_w);
    let mut max_read = 0usize;
    for i in 0..dst_w {
        max_read = max_read.max(filter_pos[i] as usize + out_size);
    }
    let size_p = if out_size <= 4 {
        4
    } else {
        (out_size + 7) & !7
    };
    let mut coeffs_p = vec![0i16; size_p * (dst_w + 3)];
    for i in 0..dst_w {
        for j in 0..out_size {
            coeffs_p[i * size_p + j] = out[i * out_size + j];
        }
    }

    let mut point = out_size == 1;
    if point {
        for i in 0..dst_w {
            if out[i] as i64 != one {
                point = false;
                break;
            }
        }
    }
    let ngroups = if point { dst_w / 16 } else { 0 };
    let mut gbase = vec![-1i32; ngroups];
    let mut gidx = vec![0u8; ngroups * 16];
    for g in 0..ngroups {
        let b = filter_pos[g * 16];
        let last = filter_pos[g * 16 + 15];
        if last - b < 64 && (b as usize) + 64 <= src_w {
            gbase[g] = b;
            for j in 0..16 {
                gidx[g * 16 + j] = (filter_pos[g * 16 + j] - b) as u8;
            }
        }
    }

    let ngroups16 = if point { dst_w / 8 } else { 0 };
    let mut gbase16 = vec![-1i32; ngroups16];
    let mut gidx16 = vec![0u8; ngroups16 * 16];
    for g in 0..ngroups16 {
        let b = filter_pos[g * 8];
        let last = filter_pos[g * 8 + 7];
        if last - b < 32 && (b as usize) + 32 <= src_w {
            gbase16[g] = b;
            for j in 0..8 {
                let d = ((filter_pos[g * 8 + j] - b) * 2) as u8;
                gidx16[g * 16 + 2 * j] = d;
                gidx16[g * 16 + 2 * j + 1] = d + 1;
            }
        }
    }

    Filter {
        coeffs: out,
        pos: filter_pos,
        size: out_size,
        identity,
        max_read,
        coeffs_p,
        size_p,
        point,
        gbase,
        gidx,
        gbase16,
        gidx16,
    }
}
