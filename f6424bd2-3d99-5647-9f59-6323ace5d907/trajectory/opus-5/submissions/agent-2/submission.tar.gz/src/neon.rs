//! AArch64 NEON kernels.
#![cfg(target_arch = "aarch64")]

use crate::colors::*;
use crate::fmt::*;
use std::arch::aarch64::*;

#[inline]
pub unsafe fn widen_shl7_neon(src: *const u8, dst: *mut i16, n: usize) {
    let mut i = 0usize;
    while i + 16 <= n {
        let v = vld1q_u8(src.add(i));
        let lo = vshll_n_u8(vget_low_u8(v), 7);
        let hi = vshll_high_n_u8(v, 7);
        vst1q_s16(dst.add(i), vreinterpretq_s16_u16(lo));
        vst1q_s16(dst.add(i + 8), vreinterpretq_s16_u16(hi));
        i += 16;
    }
    while i < n {
        *dst.add(i) = (*src.add(i) as i16) << 7;
        i += 1;
    }
}

#[inline]
pub unsafe fn deinterleave_neon(src: *const u8, du: *mut u8, dv: *mut u8, n: usize) {
    let mut i = 0usize;
    while i + 16 <= n {
        let v = vld2q_u8(src.add(2 * i));
        vst1q_u8(du.add(i), v.0);
        vst1q_u8(dv.add(i), v.1);
        i += 16;
    }
    while i < n {
        *du.add(i) = *src.add(2 * i);
        *dv.add(i) = *src.add(2 * i + 1);
        i += 1;
    }
}

#[inline(always)]
unsafe fn load_rgb8(fmt: i32, src: *const u8, i: usize) -> (uint8x8_t, uint8x8_t, uint8x8_t) {
    match fmt {
        RGB24 => {
            let v = vld3_u8(src.add(i * 3));
            (v.0, v.1, v.2)
        }
        BGR24 => {
            let v = vld3_u8(src.add(i * 3));
            (v.2, v.1, v.0)
        }
        RGBA => {
            let v = vld4_u8(src.add(i * 4));
            (v.0, v.1, v.2)
        }
        _ => {
            let v = vld4_u8(src.add(i * 4));
            (v.2, v.1, v.0)
        }
    }
}

/// 8 pixels: (c0*r + c1*g + c2*b + rnd) >> 9  → i16
#[inline(always)]
unsafe fn dot3_shr9(
    r: uint8x8_t,
    g: uint8x8_t,
    b: uint8x8_t,
    c0: i32,
    c1: i32,
    c2: i32,
    rnd: i32,
) -> int16x8_t {
    let r16 = vreinterpretq_s16_u16(vmovl_u8(r));
    let g16 = vreinterpretq_s16_u16(vmovl_u8(g));
    let b16 = vreinterpretq_s16_u16(vmovl_u8(b));
    let acc_lo = vdupq_n_s32(rnd);
    let acc_hi = vdupq_n_s32(rnd);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(r16), c0 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, r16, c0 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(g16), c1 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, g16, c1 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(b16), c2 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, b16, c2 as i16);
    vcombine_s16(vshrn_n_s32(acc_lo, 9), vshrn_n_s32(acc_hi, 9))
}

pub unsafe fn rgb_to_y16_neon(fmt: i32, src: *const u8, dst: *mut i16, n: usize) {
    const RND: i32 = (32 << 14) + (1 << 8);
    let mut i = 0usize;
    while i + 8 <= n {
        let (r, g, b) = load_rgb8(fmt, src, i);
        vst1q_s16(dst.add(i), dot3_shr9(r, g, b, RY, GY, BY, RND));
        i += 8;
    }
    if i < n {
        let step = bpp(fmt);
        let (ro, go, bo) = rgb_order(fmt);
        while i < n {
            let p = src.add(i * step);
            let r = *p.add(ro) as i32;
            let g = *p.add(go) as i32;
            let b = *p.add(bo) as i32;
            *dst.add(i) = ((RY * r + GY * g + BY * b + RND) >> 9) as i16;
            i += 1;
        }
    }
}

pub unsafe fn rgb_to_uv16_neon(
    fmt: i32,
    src: *const u8,
    du: *mut i16,
    dv: *mut i16,
    n: usize,
    half: bool,
    src_w: usize,
) {
    let step = bpp(fmt);
    let (ro, go, bo) = rgb_order(fmt);
    if !half {
        const RND: i32 = (256 << 14) + (1 << 8);
        let mut i = 0usize;
        while i + 8 <= n {
            let (r, g, b) = load_rgb8(fmt, src, i);
            vst1q_s16(du.add(i), dot3_shr9(r, g, b, RU, GU, BU, RND));
            vst1q_s16(dv.add(i), dot3_shr9(r, g, b, RV, GV, BV, RND));
            i += 8;
        }
        while i < n {
            let p = src.add(i * step);
            let r = *p.add(ro) as i32;
            let g = *p.add(go) as i32;
            let b = *p.add(bo) as i32;
            *du.add(i) = ((RU * r + GU * g + BU * b + RND) >> 9) as i16;
            *dv.add(i) = ((RV * r + GV * g + BV * b + RND) >> 9) as i16;
            i += 1;
        }
    } else {
        const RND: i32 = (256 << 15) + (1 << 9);
        let mut i = 0usize;
        if 2 * n <= src_w {
            while i + 8 <= n {
                let (r0, g0, b0, r1, g1, b1) = load_rgb_pairs8(fmt, src, i);
                let rs = vaddl_u8(r0, r1);
                let gs = vaddl_u8(g0, g1);
                let bs = vaddl_u8(b0, b1);
                vst1q_s16(du.add(i), dot3_shr10_u16(rs, gs, bs, RU, GU, BU, RND));
                vst1q_s16(dv.add(i), dot3_shr10_u16(rs, gs, bs, RV, GV, BV, RND));
                i += 8;
            }
        }
        while i < n {
            let i0 = 2 * i;
            let i1 = if 2 * i + 1 < src_w { 2 * i + 1 } else { i0 };
            let p0 = src.add(i0 * step);
            let p1 = src.add(i1 * step);
            let r = *p0.add(ro) as i32 + *p1.add(ro) as i32;
            let g = *p0.add(go) as i32 + *p1.add(go) as i32;
            let b = *p0.add(bo) as i32 + *p1.add(bo) as i32;
            *du.add(i) = ((RU * r + GU * g + BU * b + RND) >> 10) as i16;
            *dv.add(i) = ((RV * r + GV * g + BV * b + RND) >> 10) as i16;
            i += 1;
        }
    }
}

/// Load 16 consecutive pixels as 8 even/odd pairs.
#[inline(always)]
unsafe fn load_rgb_pairs8(
    fmt: i32,
    src: *const u8,
    i: usize,
) -> (uint8x8_t, uint8x8_t, uint8x8_t, uint8x8_t, uint8x8_t, uint8x8_t) {
    match fmt {
        RGB24 | BGR24 => {
            let v = vld3q_u8(src.add(i * 6));
            let (a, bq, c) = (v.0, v.1, v.2);
            // de-interleave even/odd pixels
            let ae = vuzp1q_u8(a, a);
            let ao = vuzp2q_u8(a, a);
            let be = vuzp1q_u8(bq, bq);
            let bo = vuzp2q_u8(bq, bq);
            let ce = vuzp1q_u8(c, c);
            let co = vuzp2q_u8(c, c);
            if fmt == RGB24 {
                (
                    vget_low_u8(ae),
                    vget_low_u8(be),
                    vget_low_u8(ce),
                    vget_low_u8(ao),
                    vget_low_u8(bo),
                    vget_low_u8(co),
                )
            } else {
                (
                    vget_low_u8(ce),
                    vget_low_u8(be),
                    vget_low_u8(ae),
                    vget_low_u8(co),
                    vget_low_u8(bo),
                    vget_low_u8(ao),
                )
            }
        }
        _ => {
            let v = vld4q_u8(src.add(i * 8));
            let (a, bq, c) = if fmt == RGBA {
                (v.0, v.1, v.2)
            } else {
                (v.2, v.1, v.0)
            };
            let ae = vuzp1q_u8(a, a);
            let ao = vuzp2q_u8(a, a);
            let be = vuzp1q_u8(bq, bq);
            let bo = vuzp2q_u8(bq, bq);
            let ce = vuzp1q_u8(c, c);
            let co = vuzp2q_u8(c, c);
            (
                vget_low_u8(ae),
                vget_low_u8(be),
                vget_low_u8(ce),
                vget_low_u8(ao),
                vget_low_u8(bo),
                vget_low_u8(co),
            )
        }
    }
}

#[inline(always)]
unsafe fn dot3_shr10_u16(
    r: uint16x8_t,
    g: uint16x8_t,
    b: uint16x8_t,
    c0: i32,
    c1: i32,
    c2: i32,
    rnd: i32,
) -> int16x8_t {
    let r16 = vreinterpretq_s16_u16(r);
    let g16 = vreinterpretq_s16_u16(g);
    let b16 = vreinterpretq_s16_u16(b);
    let acc_lo = vdupq_n_s32(rnd);
    let acc_hi = vdupq_n_s32(rnd);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(r16), c0 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, r16, c0 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(g16), c1 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, g16, c1 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(b16), c2 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, b16, c2 as i16);
    vcombine_s16(vshrn_n_s32(acc_lo, 10), vshrn_n_s32(acc_hi, 10))
}

pub unsafe fn yuv2plane1_neon(src: *const i16, dst: *mut u8, n: usize) {
    let mut i = 0usize;
    let bias = vdupq_n_s16(64);
    while i + 16 <= n {
        let a = vqaddq_s16(vld1q_s16(src.add(i)), bias);
        let b = vqaddq_s16(vld1q_s16(src.add(i + 8)), bias);
        let r = vcombine_u8(vqshrun_n_s16(a, 7), vqshrun_n_s16(b, 7));
        vst1q_u8(dst.add(i), r);
        i += 16;
    }
    while i < n {
        *dst.add(i) = clip_u8((*src.add(i) as i32 + 64) >> 7);
        i += 1;
    }
}

pub unsafe fn yuv2plane_x_neon(f: &[i16], srcs: &[*const i16], dst: *mut u8, n: usize) {
    let fs = f.len();
    let mut i = 0usize;
    while i + 8 <= n {
        let mut lo = vdupq_n_s32(64 << 12);
        let mut hi = vdupq_n_s32(64 << 12);
        for j in 0..fs {
            let v = vld1q_s16(srcs[j].add(i));
            lo = vmlal_n_s16(lo, vget_low_s16(v), f[j]);
            hi = vmlal_high_n_s16(hi, v, f[j]);
        }
        let s = vcombine_s16(vshrn_n_s32(lo, 16), vshrn_n_s32(hi, 16));
        vst1_u8(dst.add(i), vqshrun_n_s16(s, 3));
        i += 8;
    }
    while i < n {
        let mut val: i32 = 64 << 12;
        for j in 0..fs {
            val += *srcs[j].add(i) as i32 * f[j] as i32;
        }
        *dst.add(i) = clip_u8(val >> 19);
        i += 1;
    }
}

// ── packed RGB, half-res chroma ──────────────────────────────────────────────

pub unsafe fn rgb_full_1_neon(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    ubuf0: *const i16,
    vbuf0: *const i16,
    dst: *mut u8,
    w: usize,
) {
    let step = bpp(fmt);
    for i in 0..w {
        let y = *buf0.add(i) as i32 * 4;
        let u = (*ubuf0.add(i) as i32 - (128 << 7)) * 4;
        let v = (*vbuf0.add(i) as i32 - (128 << 7)) * 4;
        crate::simd::write_full(cf, fmt, dst.add(i * step), y, u, v);
    }
}

pub unsafe fn interleave_neon(a: *const u8, b: *const u8, dst: *mut u8, n: usize) {
    let mut i = 0usize;
    while i + 16 <= n {
        let v = uint8x16x2_t(vld1q_u8(a.add(i)), vld1q_u8(b.add(i)));
        vst2q_u8(dst.add(2 * i), v);
        i += 16;
    }
    while i < n {
        *dst.add(2 * i) = *a.add(i);
        *dst.add(2 * i + 1) = *b.add(i);
        i += 1;
    }
}

/// Packed RGB channel shuffle / width conversion.
pub unsafe fn rgb_shuffle(src: *const u8, dst: *mut u8, n: usize, sb: usize, db: usize, swap: bool) {
    let mut i = 0usize;
    if sb == 3 && db == 3 {
        if swap {
            while i + 16 <= n {
                let v = vld3q_u8(src.add(i * 3));
                vst3q_u8(dst.add(i * 3), uint8x16x3_t(v.2, v.1, v.0));
                i += 16;
            }
        } else {
            std::ptr::copy_nonoverlapping(src, dst, n * 3);
            return;
        }
    } else if sb == 3 && db == 4 {
        let a = vdupq_n_u8(255);
        while i + 16 <= n {
            let v = vld3q_u8(src.add(i * 3));
            let o = if swap {
                uint8x16x4_t(v.2, v.1, v.0, a)
            } else {
                uint8x16x4_t(v.0, v.1, v.2, a)
            };
            vst4q_u8(dst.add(i * 4), o);
            i += 16;
        }
    } else if sb == 4 && db == 3 {
        while i + 16 <= n {
            let v = vld4q_u8(src.add(i * 4));
            let o = if swap {
                uint8x16x3_t(v.2, v.1, v.0)
            } else {
                uint8x16x3_t(v.0, v.1, v.2)
            };
            vst3q_u8(dst.add(i * 3), o);
            i += 16;
        }
    } else {
        if !swap {
            std::ptr::copy_nonoverlapping(src, dst, n * 4);
            return;
        }
        while i + 16 <= n {
            let v = vld4q_u8(src.add(i * 4));
            vst4q_u8(dst.add(i * 4), uint8x16x4_t(v.2, v.1, v.0, v.3));
            i += 16;
        }
    }
    while i < n {
        let s = src.add(i * sb);
        let d = dst.add(i * db);
        let (c0, c1, c2) = (*s, *s.add(1), *s.add(2));
        if swap {
            *d = c2;
            *d.add(1) = c1;
            *d.add(2) = c0;
        } else {
            *d = c0;
            *d.add(1) = c1;
            *d.add(2) = c2;
        }
        if db == 4 {
            *d.add(3) = if sb == 4 { *s.add(3) } else { 255 };
        }
        i += 1;
    }
}

// ── YUV -> packed RGB core ───────────────────────────────────────────────────

/// Per-chroma-sample constant terms for 8 chroma samples (already 0..255 clamped).
#[inline(always)]
unsafe fn kbases8(cf: &Cf, u: uint16x8_t, v: uint16x8_t) -> [int32x4_t; 6] {
    let ul = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(u)));
    let uh = vreinterpretq_s32_u32(vmovl_high_u16(u));
    let vl = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(v)));
    let vh = vreinterpretq_s32_u32(vmovl_high_u16(v));
    let cy = cf.cy;
    [
        vmlaq_n_s32(
            vdupq_n_s32(cf.kr0),
            vshrq_n_s32(vmulq_n_s32(vl, cf.tcrv), 16),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kr0),
            vshrq_n_s32(vmulq_n_s32(vh, cf.tcrv), 16),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kg0),
            vaddq_s32(
                vshrq_n_s32(vmulq_n_s32(ul, cf.tcgu), 16),
                vshrq_n_s32(vmulq_n_s32(vl, cf.tcgv), 16),
            ),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kg0),
            vaddq_s32(
                vshrq_n_s32(vmulq_n_s32(uh, cf.tcgu), 16),
                vshrq_n_s32(vmulq_n_s32(vh, cf.tcgv), 16),
            ),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kb0),
            vshrq_n_s32(vmulq_n_s32(ul, cf.tcbu), 16),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kb0),
            vshrq_n_s32(vmulq_n_s32(uh, cf.tcbu), 16),
            cy,
        ),
    ]
}

#[inline(always)]
unsafe fn chan16(k: &[int32x4_t; 6], idx: usize, y: &[int32x4_t; 4], cy: i32) -> uint8x16_t {
    let (a, b) = (k[idx], k[idx + 1]);
    let d0 = vzip1q_s32(a, a);
    let d1 = vzip2q_s32(a, a);
    let d2 = vzip1q_s32(b, b);
    let d3 = vzip2q_s32(b, b);
    let r0 = vmlaq_n_s32(d0, y[0], cy);
    let r1 = vmlaq_n_s32(d1, y[1], cy);
    let r2 = vmlaq_n_s32(d2, y[2], cy);
    let r3 = vmlaq_n_s32(d3, y[3], cy);
    let lo = vcombine_s16(vshrn_n_s32(r0, 16), vshrn_n_s32(r1, 16));
    let hi = vcombine_s16(vshrn_n_s32(r2, 16), vshrn_n_s32(r3, 16));
    vcombine_u8(vqmovun_s16(lo), vqmovun_s16(hi))
}

#[inline(always)]
unsafe fn widen_y(y: uint8x16_t) -> [int32x4_t; 4] {
    let lo = vmovl_u8(vget_low_u8(y));
    let hi = vmovl_high_u8(y);
    [
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(lo))),
        vreinterpretq_s32_u32(vmovl_high_u16(lo)),
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(hi))),
        vreinterpretq_s32_u32(vmovl_high_u16(hi)),
    ]
}

#[inline(always)]
unsafe fn store_rgb16(fmt: i32, d: *mut u8, r: uint8x16_t, g: uint8x16_t, b: uint8x16_t) {
    match fmt {
        RGB24 => vst3q_u8(d, uint8x16x3_t(r, g, b)),
        BGR24 => vst3q_u8(d, uint8x16x3_t(b, g, r)),
        RGBA => vst4q_u8(d, uint8x16x4_t(r, g, b, vdupq_n_u8(255))),
        _ => vst4q_u8(d, uint8x16x4_t(b, g, r, vdupq_n_u8(255))),
    }
}

/// Emits 16 pixels from packed chroma bases + 16 luma samples.
#[inline(always)]
unsafe fn emit16(cf: &Cf, fmt: i32, k: &[int32x4_t; 6], yv: uint8x16_t, d: *mut u8) {
    let y = widen_y(yv);
    let r = chan16(k, 0, &y, cf.cy);
    let g = chan16(k, 2, &y, cf.cy);
    let b = chan16(k, 4, &y, cf.cy);
    store_rgb16(fmt, d, r, g, b);
}

pub unsafe fn yuv2rgb_row2(
    cf: &Cf,
    df: i32,
    py1: *const u8,
    py2: *const u8,
    pu1: *const u8,
    pv1: *const u8,
    pu2: *const u8,
    pv2: *const u8,
    d1: *mut u8,
    d2: *mut u8,
    n: usize,
    step: usize,
) {
    let same = pu1 == pu2;
    let mut i = 0usize;
    while i + 8 <= n {
        let u = vmovl_u8(vld1_u8(pu1.add(i)));
        let v = vmovl_u8(vld1_u8(pv1.add(i)));
        let k = kbases8(cf, u, v);
        emit16(cf, df, &k, vld1q_u8(py1.add(2 * i)), d1.add(2 * i * step));
        if same {
            emit16(cf, df, &k, vld1q_u8(py2.add(2 * i)), d2.add(2 * i * step));
        } else {
            let u2 = vmovl_u8(vld1_u8(pu2.add(i)));
            let v2 = vmovl_u8(vld1_u8(pv2.add(i)));
            let k2 = kbases8(cf, u2, v2);
            emit16(cf, df, &k2, vld1q_u8(py2.add(2 * i)), d2.add(2 * i * step));
        }
        i += 8;
    }
    while i < n {
        crate::fast::yuv2rgb_pair(
            cf,
            df,
            d1,
            i,
            step,
            *py1.add(2 * i) as i32,
            *py1.add(2 * i + 1) as i32,
            *pu1.add(i) as i32,
            *pv1.add(i) as i32,
        );
        crate::fast::yuv2rgb_pair(
            cf,
            df,
            d2,
            i,
            step,
            *py2.add(2 * i) as i32,
            *py2.add(2 * i + 1) as i32,
            *pu2.add(i) as i32,
            *pv2.add(i) as i32,
        );
        i += 1;
    }
}

/// `yuv2packed1` with uvalpha < 2048: 15-bit luma/chroma buffers, half-res chroma.
pub unsafe fn rgb_1_neon(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    ubuf0: *const i16,
    vbuf0: *const i16,
    dst: *mut u8,
    n: usize,
) {
    let step = bpp(fmt);
    let bias = vdupq_n_s16(64);
    let mut i = 0usize;
    while i + 8 <= n {
        // 8 chroma samples -> 16 pixels
        let uu = vqaddq_s16(vld1q_s16(ubuf0.add(i)), bias);
        let vv = vqaddq_s16(vld1q_s16(vbuf0.add(i)), bias);
        let u8v = vqshrun_n_s16(uu, 7);
        let v8v = vqshrun_n_s16(vv, 7);
        let k = kbases8(cf, vmovl_u8(u8v), vmovl_u8(v8v));
        let y0 = vqaddq_s16(vld1q_s16(buf0.add(2 * i)), bias);
        let y1 = vqaddq_s16(vld1q_s16(buf0.add(2 * i + 8)), bias);
        let yv = vcombine_u8(vqshrun_n_s16(y0, 7), vqshrun_n_s16(y1, 7));
        emit16(cf, fmt, &k, yv, dst.add(2 * i * step));
        i += 8;
    }
    while i < n {
        let y1 = (*buf0.add(2 * i) as i32 + 64) >> 7;
        let y2 = (*buf0.add(2 * i + 1) as i32 + 64) >> 7;
        let u = (*ubuf0.add(i) as i32 + 64) >> 7;
        let v = (*vbuf0.add(i) as i32 + 64) >> 7;
        crate::fast::yuv2rgb_pair(cf, fmt, dst, i, step, y1, y2, u, v);
        i += 1;
    }
}
