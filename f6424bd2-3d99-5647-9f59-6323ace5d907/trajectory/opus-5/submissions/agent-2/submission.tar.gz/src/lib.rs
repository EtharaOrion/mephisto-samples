//! libswscale-compatible image scaler / pixel-format converter.
//!
//! Re-implements FFmpeg's swscale semantics (BT.601 limited range, the same
//! fixed-point filter generation and the same unscaled special-case converters)
//! with AArch64 NEON kernels.

mod colors;
mod fast;
mod filter;
mod fmt;
mod general;
mod neon;
mod simd;

use fmt::*;
use std::ffi::c_void;
use std::os::raw::c_int;

pub struct Ctx {
    src_w: usize,
    src_h: usize,
    dst_w: usize,
    dst_h: usize,
    src_fmt: c_int,
    dst_fmt: c_int,
    fast: fast::Fast,
    gen: Option<Box<general::General>>,
}

#[inline]
fn valid_fmt(f: c_int) -> bool {
    (0..=9).contains(&f)
}

#[no_mangle]
pub extern "C" fn swscale_create(
    src_w: c_int,
    src_h: c_int,
    src_fmt: c_int,
    dst_w: c_int,
    dst_h: c_int,
    dst_fmt: c_int,
    algo: c_int,
) -> *mut c_void {
    if src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0 {
        return std::ptr::null_mut();
    }
    if !valid_fmt(src_fmt) || !valid_fmt(dst_fmt) || !(0..=2).contains(&algo) {
        return std::ptr::null_mut();
    }
    let (sw, sh, dw, dh) = (
        src_w as usize,
        src_h as usize,
        dst_w as usize,
        dst_h as usize,
    );
    let unscaled = sw == dw && sh == dh;
    let f = if unscaled {
        fast::pick(src_fmt, dst_fmt, dw, dh)
    } else {
        fast::Fast::None
    };
    let gen = if f == fast::Fast::None {
        Some(Box::new(general::General::new(
            sw, sh, src_fmt, dw, dh, dst_fmt, algo,
        )))
    } else {
        None
    };
    let ctx = Box::new(Ctx {
        src_w: sw,
        src_h: sh,
        dst_w: dw,
        dst_h: dh,
        src_fmt,
        dst_fmt,
        fast: f,
        gen,
    });
    Box::into_raw(ctx) as *mut c_void
}

#[no_mangle]
pub unsafe extern "C" fn swscale_process(
    ctx: *mut c_void,
    src_data: *const *const u8,
    src_stride: *const c_int,
    dst_data: *const *mut u8,
    dst_stride: *const c_int,
) -> c_int {
    if ctx.is_null() || src_data.is_null() || dst_data.is_null() {
        return -1;
    }
    let c = &mut *(ctx as *mut Ctx);
    let mut src = [std::ptr::null::<u8>(); 4];
    let mut dst = [std::ptr::null_mut::<u8>(); 4];
    let mut ss = [0i32; 4];
    let mut ds = [0i32; 4];
    for i in 0..4 {
        src[i] = *src_data.add(i);
        dst[i] = *dst_data.add(i);
        ss[i] = *src_stride.add(i);
        ds[i] = *dst_stride.add(i);
    }

    if c.fast != fast::Fast::None {
        fast::run(
            c.fast, c.src_fmt, c.dst_fmt, c.dst_w, c.dst_h, &src, &ss, &dst, &ds,
        );
    } else if let Some(g) = c.gen.as_mut() {
        g.process(&src, &ss, &dst, &ds);
    } else {
        return -1;
    }
    let _ = (c.src_w, c.src_h);
    0
}

#[no_mangle]
pub unsafe extern "C" fn swscale_destroy(ctx: *mut c_void) {
    if ctx.is_null() {
        return;
    }
    drop(Box::from_raw(ctx as *mut Ctx));
}
