#!/usr/bin/env python3
import sys
sys.path.insert(0, "/app/workspace")
sys.path.insert(0, "/home/workspace/swscale-impl/tools")
from cmp import gen_planes, run, BASE, CAND
from pixel_formats import load_swscale_library, PIXFMT_FROM_NAME

sf = PIXFMT_FROM_NAME[sys.argv[1]]
df = PIXFMT_FROM_NAME[sys.argv[2]]
sw, sh = int(sys.argv[3]), int(sys.argv[4])
dw, dh = int(sys.argv[5]), int(sys.argv[6])
algo = int(sys.argv[7]) if len(sys.argv) > 7 else 1
mode = sys.argv[8] if len(sys.argv) > 8 else "noise"

wl = dict(sf=sf, df=df, sw=sw, sh=sh, dw=dw, dh=dh, algo=algo)
sp = gen_planes(sf, sw, sh, seed=7, mode=mode)
base = load_swscale_library(BASE)
cand = load_swscale_library(CAND)
bo = run(base, wl, sp)
co = run(cand, wl, sp)
for pi, (b, c) in enumerate(zip(bo, co)):
    diffs = [(i, b[i], c[i]) for i in range(len(b)) if b[i] != c[i]]
    print(f"plane {pi}: len={len(b)} ndiff={len(diffs)}")
    print("  base:", list(b[:24]))
    print("  cand:", list(c[:24]))
    if diffs:
        print("  first diffs:", diffs[:12])
