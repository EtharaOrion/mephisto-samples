#!/usr/bin/env python3
"""Compare candidate lib output against the public baseline lib (same as verifier)."""
from __future__ import annotations
import argparse, math, os, sys, random, itertools, time
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_DESCS, PIXFMT_NAMES, ALGO_NAMES, load_swscale_library,
                           allocate_image, image_to_bytes, fill_image_from_bytes)

BASE = "/app/libswscale_public_baseline.so"
CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"


def gen_planes(fmt, w, h, seed, mode="noise"):
    desc = PIXFMT_DESCS[fmt]
    rng = random.Random(seed)
    planes = []
    for i in range(desc.num_planes):
        pw = desc.plane_width(i, w) * desc.planes[i].bpp
        ph = desc.plane_height(i, h)
        n = pw * ph
        if mode == "noise":
            planes.append(bytes(rng.getrandbits(8) for _ in range(n)))
        else:
            planes.append(bytes(((x * 7 + y * 3) & 0xFF) for y in range(ph) for x in range(pw)))
    return planes


def psnr(a: bytes, b: bytes) -> float:
    if len(a) != len(b):
        return -1.0
    if a == b:
        return 999.0
    se = 0
    for x, y in zip(a, b):
        d = x - y
        se += d * d
    mse = se / len(a)
    return 10 * math.log10(255 * 255 / mse)


def run(lib, wl, src_planes):
    sf, df = wl["sf"], wl["df"]
    sw, sh, dw, dh, algo = wl["sw"], wl["sh"], wl["dw"], wl["dh"], wl["algo"]
    sd, ss, sb = allocate_image(sf, sw, sh)
    fill_image_from_bytes(sf, sw, sh, sd, ss, src_planes)
    dd, ds, db = allocate_image(df, dw, dh)
    ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
    if not ctx:
        return None
    r = lib.swscale_process(ctx, sd, ss, dd, ds)
    out = image_to_bytes(df, dw, dh, dd, ds)
    lib.swscale_destroy(ctx)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidate", default=CAND)
    ap.add_argument("--filter", default="")
    ap.add_argument("--full", action="store_true")
    ap.add_argument("--size", default="")
    args = ap.parse_args()
    cand = load_swscale_library(args.candidate)
    base = load_swscale_library(BASE)

    fmts = list(range(10))
    wls = []
    # format-only, all pairs
    W, H = 96, 64
    for sf in fmts:
        for df in fmts:
            wls.append(dict(sf=sf, df=df, sw=W, sh=H, dw=W, dh=H, algo=1, thr=60.0))
    # scaling
    sizes = [(64, 48, 32, 24), (64, 48, 128, 96), (100, 60, 50, 30), (96, 64, 40, 70), (32, 32, 96, 96)]
    for algo in (0, 1, 2):
        for (sw, sh, dw, dh) in sizes:
            for sf in fmts:
                for df in fmts:
                    if not args.full and (sf % 3 != df % 3) and (sf + df) % 2:
                        continue
                    wls.append(dict(sf=sf, df=df, sw=sw, sh=sh, dw=dw, dh=dh, algo=algo, thr=40.0))

    fails = []
    npass = 0
    for wl in wls:
        label = f"{PIXFMT_NAMES[wl['sf']]}->{PIXFMT_NAMES[wl['df']]} {wl['sw']}x{wl['sh']}->{wl['dw']}x{wl['dh']} {ALGO_NAMES[wl['algo']]}"
        if args.filter and args.filter not in label:
            continue
        sp = gen_planes(wl["sf"], wl["sw"], wl["sh"], seed=hash(label) & 0xFFFF)
        try:
            bo = run(base, wl, sp)
            co = run(cand, wl, sp)
        except Exception as e:
            fails.append((label, f"exception {e}"))
            continue
        if bo is None or co is None:
            fails.append((label, "null ctx"))
            continue
        worst = 999.0
        for i, (b, c) in enumerate(zip(bo, co)):
            p = psnr(b, c)
            worst = min(worst, p)
        if worst < wl["thr"]:
            fails.append((label, f"psnr={worst:.2f} thr={wl['thr']}"))
        else:
            npass += 1
    print(f"PASS {npass}  FAIL {len(fails)}")
    for l, r in fails:
        print(f"  FAIL {l}: {r}")


if __name__ == "__main__":
    main()
