#!/usr/bin/env python3
"""Focused 1080p-class benchmark over a representative workload set."""
from __future__ import annotations
import math, sys, time, random
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_DESCS, PIXFMT_NAMES, ALGO_NAMES, load_swscale_library,
                           allocate_image, fill_image_from_bytes)

BASE = "/app/libswscale_public_baseline.so"
CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"
_GC = {}


def gen(fmt, w, h, seed=5):
    key = (fmt, w, h)
    if key in _GC:
        return _GC[key]
    d = PIXFMT_DESCS[fmt]
    rng = random.Random(seed)
    out = [rng.randbytes(d.plane_width(i, w) * d.planes[i].bpp * d.plane_height(i, h))
           for i in range(d.num_planes)]
    _GC[key] = out
    return out


def bench(lib, wl, iters=7):
    sf, df = wl[0], wl[1]
    sw, sh, dw, dh, algo = wl[2], wl[3], wl[4], wl[5], wl[6]
    sp = gen(sf, sw, sh)
    sd, ss, sb = allocate_image(sf, sw, sh)
    fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
    dd, ds, db = allocate_image(df, dw, dh)
    ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
    if not ctx:
        return None
    for _ in range(3):
        lib.swscale_process(ctx, sd, ss, dd, ds)
    ts = []
    for _ in range(iters):
        t0 = time.perf_counter()
        lib.swscale_process(ctx, sd, ss, dd, ds)
        ts.append(time.perf_counter() - t0)
    lib.swscale_destroy(ctx)
    ts.sort()
    return ts[len(ts) // 2]


FMTS = [0, 1, 2, 3, 5, 6, 7, 8, 9]
CFGS = [(1920, 1080, 1920, 1080, 1), (1920, 1080, 960, 540, 1), (1280, 720, 1920, 1080, 1),
        (1920, 1080, 640, 360, 2), (1280, 720, 1920, 1080, 2), (1920, 1080, 960, 540, 0)]


def main():
    cand = load_swscale_library(CAND)
    base = load_swscale_library(BASE)
    rows, speeds = [], []
    for (sw, sh, dw, dh, algo) in CFGS:
        for sf in FMTS:
            for df in FMTS:
                wl = (sf, df, sw, sh, dw, dh, algo)
                b = bench(base, wl)
                c = bench(cand, wl)
                if not b or not c:
                    continue
                s = b / max(c, 1e-12)
                speeds.append(s)
                rows.append((s, f"{PIXFMT_NAMES[sf]}->{PIXFMT_NAMES[df]} {sw}x{sh}->{dw}x{dh} {ALGO_NAMES[algo]}", b * 1e3, c * 1e3))
    rows.sort()
    for s, l, b, c in rows:
        print(f"{s:8.3f}  {b:8.3f} {c:8.3f}  {l}")
    print(f"\nGeomean: {math.exp(sum(math.log(max(s,1e-9)) for s in speeds)/len(speeds)):.4f} over {len(speeds)}")


if __name__ == "__main__":
    main()
