#!/usr/bin/env python3
"""Randomised stress test: many contexts, odd sizes, repeated calls."""
from __future__ import annotations
import random, sys
sys.path.insert(0, "/app/workspace")
from pixel_formats import PIXFMT_DESCS, load_swscale_library, allocate_image, fill_image_from_bytes

CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"


def main():
    lib = load_swscale_library(CAND)
    rng = random.Random(int(sys.argv[1]) if len(sys.argv) > 1 else 1)
    live = []
    for it in range(4000):
        sw = rng.choice([2, 4, 16, 32, 64, 100, 128, 176, 256, 322, 640, 720, 1024, 1280])
        sh = rng.choice([2, 4, 16, 32, 48, 90, 128, 144, 240, 322, 480, 540, 720])
        dw = rng.choice([2, 4, 16, 32, 64, 100, 128, 176, 256, 322, 640, 720, 1024, 1280])
        dh = rng.choice([2, 4, 16, 32, 48, 90, 128, 144, 240, 322, 480, 540, 720])
        # subsampled formats need even dimensions
        sw &= ~1; sh &= ~1; dw &= ~1; dh &= ~1
        sw = max(sw, 2); sh = max(sh, 2); dw = max(dw, 2); dh = max(dh, 2)
        sf = rng.randrange(10)
        df = rng.randrange(10)
        algo = rng.randrange(3)
        # non-subsampled formats may legitimately have odd dimensions
        if sf in (2, 5, 6, 7, 8, 9) and df in (2, 5, 6, 7, 8, 9) and rng.random() < 0.5:
            sw += rng.randrange(2); sh += rng.randrange(2)
            dw += rng.randrange(2); dh += rng.randrange(2)
        d = PIXFMT_DESCS[sf]
        sp = [rng.randbytes(d.plane_width(i, sw) * d.planes[i].bpp * d.plane_height(i, sh))
              for i in range(d.num_planes)]
        sd, ss, sb = allocate_image(sf, sw, sh)
        fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
        dd, ds, db = allocate_image(df, dw, dh)
        ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
        if not ctx:
            print("NULL ctx", sw, sh, sf, dw, dh, df, algo)
            continue
        for _ in range(rng.randrange(1, 4)):
            r = lib.swscale_process(ctx, sd, ss, dd, ds)
            if r != 0:
                print("ERR", r, sw, sh, sf, dw, dh, df, algo)
        live.append((ctx, sd, ss, sb, dd, ds, db))
        if len(live) > 12:
            c = live.pop(0)
            lib.swscale_destroy(c[0])
        if it % 500 == 0:
            print("iter", it, flush=True)
    for c in live:
        lib.swscale_destroy(c[0])
    print("STRESS OK")


if __name__ == "__main__":
    main()
