#!/usr/bin/env python3
"""Correctness sweep at sizes large enough to exercise the multi-threaded band split."""
from __future__ import annotations
import argparse, math, sys, random
import numpy as np
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_DESCS, PIXFMT_NAMES, ALGO_NAMES, load_swscale_library,
                           allocate_image, image_to_bytes, fill_image_from_bytes)

BASE = "/app/libswscale_public_baseline.so"
CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"
_GC = {}


def gen(fmt, w, h, seed=11):
    key = (fmt, w, h, seed)
    if key in _GC:
        return _GC[key]
    d = PIXFMT_DESCS[fmt]
    rng = random.Random(seed)
    out = [rng.randbytes(d.plane_width(i, w) * d.planes[i].bpp * d.plane_height(i, h))
           for i in range(d.num_planes)]
    _GC[key] = out
    return out


def psnr(a: bytes, b: bytes) -> float:
    if len(a) != len(b):
        return -1.0
    if a == b:
        return 999.0
    x = np.frombuffer(a, dtype=np.uint8).astype(np.int32)
    y = np.frombuffer(b, dtype=np.uint8).astype(np.int32)
    mse = float(np.mean((x - y) ** 2))
    if mse == 0:
        return 999.0
    return 10 * math.log10(255 * 255 / mse)


def run(lib, wl, sp):
    sf, df, sw, sh, dw, dh, algo = wl
    sd, ss, sb = allocate_image(sf, sw, sh)
    fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
    dd, ds, db = allocate_image(df, dw, dh)
    ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
    if not ctx:
        return None
    lib.swscale_process(ctx, sd, ss, dd, ds)
    out = image_to_bytes(df, dw, dh, dd, ds)
    lib.swscale_destroy(ctx)
    return out


CFGS = [(640, 480, 640, 480, 1), (640, 480, 320, 240, 1), (320, 240, 640, 480, 1),
        (640, 480, 424, 238, 2), (500, 300, 640, 482, 2), (640, 480, 322, 240, 0),
        (640, 480, 640, 240, 1), (642, 482, 642, 482, 1)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidate", default=CAND)
    args = ap.parse_args()
    cand = load_swscale_library(args.candidate)
    base = load_swscale_library(BASE)
    fails, npass = [], 0
    for (sw, sh, dw, dh, algo) in CFGS:
        unscaled = (sw == dw and sh == dh)
        thr = 60.0 if unscaled else 40.0
        for sf in range(10):
            for df in range(10):
                wl = (sf, df, sw, sh, dw, dh, algo)
                lbl = f"{PIXFMT_NAMES[sf]}->{PIXFMT_NAMES[df]} {sw}x{sh}->{dw}x{dh} {ALGO_NAMES[algo]}"
                sp = gen(sf, sw, sh)
                bo = run(base, wl, sp)
                co = run(cand, wl, sp)
                if bo is None or co is None:
                    fails.append((lbl, "null"))
                    continue
                worst = min(psnr(b, c) for b, c in zip(bo, co))
                if worst < thr:
                    fails.append((lbl, f"psnr={worst:.2f} thr={thr}"))
                else:
                    npass += 1
    print(f"PASS {npass}  FAIL {len(fails)}")
    for l, r in fails:
        print(f"  FAIL {l}: {r}")


if __name__ == "__main__":
    main()
