#!/usr/bin/env python3
"""Speedup vs baseline at a range of frame sizes (to tune the threading threshold)."""
from __future__ import annotations
import math, sys, time, random
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_DESCS, PIXFMT_NAMES, load_swscale_library,
                           allocate_image, fill_image_from_bytes)

BASE = "/app/libswscale_public_baseline.so"
CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"
_GC = {}


def gen(fmt, w, h):
    key = (fmt, w, h)
    if key not in _GC:
        d = PIXFMT_DESCS[fmt]
        rng = random.Random(3)
        _GC[key] = [rng.randbytes(d.plane_width(i, w) * d.planes[i].bpp * d.plane_height(i, h))
                    for i in range(d.num_planes)]
    return _GC[key]


def bench(lib, sf, df, sw, sh, dw, dh, algo, iters=31):
    sp = gen(sf, sw, sh)
    sd, ss, sb = allocate_image(sf, sw, sh)
    fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
    dd, ds, db = allocate_image(df, dw, dh)
    ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
    for _ in range(5):
        lib.swscale_process(ctx, sd, ss, dd, ds)
    ts = []
    for _ in range(iters):
        t0 = time.perf_counter()
        lib.swscale_process(ctx, sd, ss, dd, ds)
        ts.append(time.perf_counter() - t0)
    lib.swscale_destroy(ctx)
    ts.sort()
    return ts[len(ts) // 2]


SIZES = [(64, 64), (128, 96), (176, 144), (256, 192), (320, 240), (426, 240), (640, 360), (640, 480), (960, 540)]
PAIRS = [(0, 5), (5, 0), (5, 8), (0, 2), (3, 5), (5, 9)]


def main():
    cand = load_swscale_library(CAND)
    base = load_swscale_library(BASE)
    for (w, h) in SIZES:
        sp = []
        for (sf, df) in PAIRS:
            b = bench(base, sf, df, w, h, w, h, 1)
            c = bench(cand, sf, df, w, h, w, h, 1)
            sp.append(b / c)
        g = math.exp(sum(math.log(x) for x in sp) / len(sp))
        print(f"{w}x{h}: geo {g:7.2f}   " + "  ".join(f"{PIXFMT_NAMES[a]}->{PIXFMT_NAMES[b]}:{s:.2f}" for (a, b), s in zip(PAIRS, sp)))


if __name__ == "__main__":
    main()
