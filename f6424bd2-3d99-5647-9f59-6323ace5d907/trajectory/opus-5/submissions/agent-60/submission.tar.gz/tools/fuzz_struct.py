#!/usr/bin/env python3
"""Randomised correctness fuzz on *structured* content.

`fuzz.py` fills the source with uniform noise, which averages to grey under any
sizeable downscale and so hides errors in the chroma path. This harness builds
frames with gradients, colour blocks and single-pixel combs instead, which keep
their structure all the way down.
"""
from __future__ import annotations
import math, random, sys
import numpy as np
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_DESCS, PIXFMT_NAMES, ALGO_NAMES, load_swscale_library,
                           allocate_image, image_to_bytes, fill_image_from_bytes)

BASE = "/app/libswscale_public_baseline.so"
CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"


def psnr(x: bytes, y: bytes) -> float:
    if len(x) != len(y):
        return -1.0
    if x == y:
        return 999.0
    a = np.frombuffer(x, dtype=np.uint8).astype(np.int32)
    b = np.frombuffer(y, dtype=np.uint8).astype(np.int32)
    m = float(np.mean((a - b) ** 2))
    return 999.0 if m == 0 else 10 * math.log10(65025 / m)


def source(lib, fmt: int, w: int, h: int, variant: int):
    """Structured RGB content, converted to `fmt` by the reference."""
    x = np.arange(w)[None, :]
    y = np.arange(h)[:, None]
    img = np.zeros((h, w, 3), np.uint8)
    if variant == 0:
        img[:, :, 0] = ((x * 255 // max(w - 1, 1)) + y * 3) % 256
        img[:, :, 1] = ((np.sin(x / 17.0) * 90 + 128) + y * 5) % 256
        img[:, :, 2] = (((x // max(w // 7, 1)) + (y // max(h // 5, 1))) % 2) * 200 + 30
    elif variant == 1:
        img[:, :, 0] = np.where(x < w // 2, 230, 20)
        img[:, :, 1] = np.where(y < h // 2, 40, 200)
        img[:, :, 2] = np.where((x + y) % 32 < 16, 20, 240)
    else:
        img[:, :, 0] = (x * 3) % 256
        img[:, :, 1] = 255 - (y * 7) % 256
        img[:, :, 2] = ((x ^ y) * 5) % 256
    img[:, :: max(w // 37, 1), :] = np.array([250, 250, 10], np.uint8)
    img[:: max(h // 11, 1), :, :] = np.array([10, 240, 240], np.uint8)
    sd, ss, _ = allocate_image(5, w, h, 32)
    fill_image_from_bytes(5, w, h, sd, ss, [img.tobytes()])
    if fmt == 5:
        return image_to_bytes(5, w, h, sd, ss)
    dd, ds, _ = allocate_image(fmt, w, h, 32)
    ctx = lib.swscale_create(w, h, 5, w, h, fmt, 1)
    lib.swscale_process(ctx, sd, ss, dd, ds)
    lib.swscale_destroy(ctx)
    return image_to_bytes(fmt, w, h, dd, ds)


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    iters = int(sys.argv[2]) if len(sys.argv) > 2 else 200
    rng = random.Random(seed)
    b = load_swscale_library(BASE)
    c = load_swscale_library(CAND)
    fails = 0
    for it in range(iters):
        sf = rng.randrange(10)
        df = rng.randrange(10)
        algo = rng.randrange(3)
        even_w = sf in (0, 1, 3, 4) or df in (0, 1, 3, 4)
        even_h = sf in (0, 3, 4) or df in (0, 3, 4)

        def dim(hi, even):
            v = rng.randrange(2, hi)
            return max(v & ~1 if even else v, 2)

        sw, sh = dim(1400, even_w), dim(900, even_h)
        dw, dh = dim(1400, even_w), dim(900, even_h)
        align = rng.choice([1, 4, 32, 64])
        sp = source(b, sf, sw, sh, it % 3)
        sd, ss, sb = allocate_image(sf, sw, sh, align)
        fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
        outs = []
        for lib in (b, c):
            dd, ds, db = allocate_image(df, dw, dh, align)
            ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
            if not ctx:
                outs.append(None)
                continue
            lib.swscale_process(ctx, sd, ss, dd, ds)
            outs.append(image_to_bytes(df, dw, dh, dd, ds))
            lib.swscale_destroy(ctx)
        lbl = (f"{PIXFMT_NAMES[sf]}->{PIXFMT_NAMES[df]} {sw}x{sh}->{dw}x{dh} "
               f"{ALGO_NAMES[algo]} align={align} v{it % 3}")
        if (outs[0] is None) != (outs[1] is None):
            print("NULLCTX", lbl)
            fails += 1
            continue
        if outs[0] is None:
            continue
        worst = min(psnr(x, y) for x, y in zip(*outs))
        thr = 60.0 if (sw == dw and sh == dh) else 40.0
        if worst < thr:
            fails += 1
            print(f"FAIL {lbl}: psnr={worst:.2f} thr={thr}")
    print(f"struct-fuzz seed={seed}: {iters - fails}/{iters} pass")


if __name__ == "__main__":
    main()
