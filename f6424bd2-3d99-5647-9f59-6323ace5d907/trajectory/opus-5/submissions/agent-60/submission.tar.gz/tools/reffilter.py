#!/usr/bin/env python3
"""Independent transliteration of FFmpeg's initFilter(), used to diff against
the Rust port when they disagree."""
from __future__ import annotations
import ctypes, sys

CUTOFF = 0.002


def av_log2(v: int) -> int:
    return 0 if v <= 0 else v.bit_length() - 1


def cdiv(a: int, b: int) -> int:
    """C integer division: truncate toward zero."""
    q = abs(a) // abs(b)
    return q if (a >= 0) == (b >= 0) else -q


def sar(a: int, n: int) -> int:
    """arithmetic shift right (floor)"""
    return a >> n


def rounded_div(a: int, b: int) -> int:
    return cdiv(a + (b >> 1), b) if a >= 0 else cdiv(a - (b >> 1), b)


def init_filter(x_inc, src_w, dst_w, one, algo, src_pos, dst_pos):
    shift = min(av_log2(src_w // dst_w), 8)
    fone = 1 << (54 - shift)
    filter_pos = [0] * (dst_w + 3)

    if abs(x_inc - 0x10000) < 10 and src_pos == dst_pos:
        fsize = 1
        filt = [fone] * dst_w
        for i in range(dst_w):
            filter_pos[i] = i
    elif algo == 0:  # point
        fsize = 1
        filt = [0] * dst_w
        x = sar(dst_pos * x_inc, 8) - sar(src_pos * 0x8000, 7)
        for i in range(dst_w):
            filter_pos[i] = sar(x - ((fsize - 1) << 15) + (1 << 15), 16)
            filt[i] = fone
            x += x_inc
    else:
        sf = 4 if algo == 2 else 2
        fsize = 1 + sf if x_inc <= (1 << 16) else 1 + cdiv(sf * src_w + dst_w - 1, dst_w)
        fsize = max(min(fsize, src_w - 2), 1)
        filt = [0] * (dst_w * fsize)
        x = sar(dst_pos * x_inc, 7) - sar(src_pos * 0x10000, 7)
        cpar = int(0.6 * (1 << 24))
        for i in range(dst_w):
            xx = cdiv(x - (fsize - 2) * (1 << 16), 1 << 17)
            filter_pos[i] = xx
            for j in range(fsize):
                d = abs(xx * (1 << 17) - x) << 13
                if x_inc > (1 << 16):
                    d = cdiv(d * dst_w, src_w)
                if algo == 2:
                    b, c = 0, cpar
                    if d >= 1 << 31:
                        coeff = 0
                    else:
                        dd = sar(d * d, 30)
                        ddd = sar(dd * d, 30)
                        if d < 1 << 30:
                            coeff = ((12 * (1 << 24) - 9 * b - 6 * c) * ddd
                                     + (-18 * (1 << 24) + 12 * b + 6 * c) * dd
                                     + (6 * (1 << 24) - 2 * b) * (1 << 30))
                        else:
                            coeff = ((-b - 6 * c) * ddd + (6 * b + 30 * c) * dd
                                     + (-12 * b - 48 * c) * d + (8 * b + 24 * c) * (1 << 30))
                        coeff = cdiv(coeff, (1 << 54) // fone)
                else:
                    coeff = max((1 << 30) - d, 0) * (fone >> 30)
                filt[i * fsize + j] = coeff
                xx += 1
            x += 2 * x_inc

    f2size = fsize
    f2 = filt
    cut = CUTOFF * fone

    min_fsize = 0
    for i in range(dst_w - 1, -1, -1):
        mn = f2size
        cut_off = 0
        for _ in range(f2size):
            cut_off += abs(f2[i * f2size])
            if cut_off > cut:
                break
            if i < dst_w - 1 and filter_pos[i] >= filter_pos[i + 1]:
                break
            for k in range(1, f2size):
                f2[i * f2size + k - 1] = f2[i * f2size + k]
            f2[i * f2size + f2size - 1] = 0
            filter_pos[i] += 1
        cut_off = 0
        for j in range(f2size - 1, 0, -1):
            cut_off += abs(f2[i * f2size + j])
            if cut_off > cut:
                break
            mn -= 1
        min_fsize = max(min_fsize, mn)

    osz = max(min_fsize, 1)
    f = [0] * (dst_w * osz)
    for i in range(dst_w):
        for j in range(osz):
            f[i * osz + j] = f2[i * f2size + j] if j < f2size else 0

    for i in range(dst_w):
        if filter_pos[i] < 0:
            for j in range(1, osz):
                left = max(j + filter_pos[i], 0)
                f[i * osz + left] += f[i * osz + j]
                f[i * osz + j] = 0
            filter_pos[i] = 0
        if filter_pos[i] + osz > src_w:
            sh = filter_pos[i] + min(osz - src_w, 0)
            acc = 0
            for j in range(osz - 1, -1, -1):
                if filter_pos[i] + j >= src_w:
                    acc += f[i * osz + j]
                    f[i * osz + j] = 0
            for j in range(osz - 1, -1, -1):
                f[i * osz + j] = 0 if j < sh else f[i * osz + j - sh]
            filter_pos[i] -= sh
            f[i * osz + src_w - 1 - filter_pos[i]] += acc

    out = [0] * (dst_w * osz)
    for i in range(dst_w):
        error = 0
        s = sum(f[i * osz + j] for j in range(osz))
        s = cdiv(s + one // 2, one)
        if s == 0:
            s = 1
        for j in range(osz):
            v = f[i * osz + j] + error
            iv = rounded_div(v, s)
            out[i * osz + j] = ctypes.c_int16(iv & 0xFFFF).value
            error = v - iv * s
    return osz, filter_pos[:dst_w], out


def main():
    sw, dw, algo = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    lib = ctypes.CDLL("/home/workspace/swscale-impl/target/release/libswscale_candidate.so")
    lib.swscale_debug_hfilter.argtypes = [ctypes.c_int] * 3 + [
        ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_int),
        ctypes.POINTER(ctypes.c_int16), ctypes.c_int]
    size = ctypes.c_int()
    pos = (ctypes.c_int * (dw + 8))()
    coef = (ctypes.c_int16 * (dw * 4096))()
    lib.swscale_debug_hfilter(sw, dw, algo, ctypes.byref(size), pos, coef, dw)
    rsz = size.value
    rpos = [pos[i] for i in range(dw)]
    rcoef = [coef[i] for i in range(dw * rsz)]

    psz, ppos, pcoef = init_filter(((sw << 16) + (dw >> 1)) // dw, sw, dw, 1 << 14, algo, 128, 128)
    print(f"rust size={rsz} ref size={psz}")
    print(f"rust pos={rpos[:6]}  ref pos={ppos[:6]}")
    if rsz == psz:
        diffs = [(i, j, rcoef[i * rsz + j], pcoef[i * psz + j])
                 for i in range(dw) for j in range(rsz)
                 if rcoef[i * rsz + j] != pcoef[i * psz + j]]
        print(f"coef diffs: {len(diffs)}", diffs[:10])


if __name__ == "__main__":
    main()
