#!/usr/bin/env python3
"""Randomised correctness fuzz: compare against the baseline over random
formats, sizes, algorithms and stride paddings."""
from __future__ import annotations
import math, random, sys
import numpy as np
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_DESCS, PIXFMT_NAMES, ALGO_NAMES, load_swscale_library,
                           allocate_image, image_to_bytes, fill_image_from_bytes)

BASE = "/app/libswscale_public_baseline.so"
CAND = "/home/workspace/swscale-impl/target/release/libswscale_candidate.so"
SUBSAMPLED = (0, 1, 3, 4)


def psnr(x: bytes, y: bytes) -> float:
    if len(x) != len(y):
        return -1.0
    if x == y:
        return 999.0
    a = np.frombuffer(x, dtype=np.uint8).astype(np.int32)
    b = np.frombuffer(y, dtype=np.uint8).astype(np.int32)
    m = float(np.mean((a - b) ** 2))
    return 999.0 if m == 0 else 10 * math.log10(65025 / m)


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    iters = int(sys.argv[2]) if len(sys.argv) > 2 else 400
    rng = random.Random(seed)
    b = load_swscale_library(BASE)
    c = load_swscale_library(CAND)
    fails = 0
    for it in range(iters):
        sf = rng.randrange(10)
        df = rng.randrange(10)
        algo = rng.randrange(3)
        # 4:2:0 needs both dimensions even; 4:2:2 only the width
        even_w = sf in (0, 1, 3, 4) or df in (0, 1, 3, 4)
        even_h = sf in (0, 3, 4) or df in (0, 3, 4)
        def dim(hi, even):
            v = rng.randrange(2, hi)
            return max(v & ~1 if even else v, 2)
        sw, sh = dim(900, even_w), dim(700, even_h)
        dw, dh = dim(900, even_w), dim(700, even_h)
        align = rng.choice([1, 4, 16, 32, 64, 128])
        d = PIXFMT_DESCS[sf]
        sp = [rng.randbytes(d.plane_width(i, sw) * d.planes[i].bpp * d.plane_height(i, sh))
              for i in range(d.num_planes)]
        sd, ss, sb = allocate_image(sf, sw, sh, align)
        fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
        outs = []
        for lib in (b, c):
            dd, ds, db = allocate_image(df, dw, dh, align)
            ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
            if not ctx:
                outs.append(None)
                continue
            lib.swscale_process(ctx, sd, ss, dd, ds)
            outs.append(image_to_bytes(df, dw, dh, dd, ds))
            lib.swscale_destroy(ctx)
        lbl = (f"{PIXFMT_NAMES[sf]}->{PIXFMT_NAMES[df]} {sw}x{sh}->{dw}x{dh} "
               f"{ALGO_NAMES[algo]} align={align}")
        if outs[0] is None or outs[1] is None:
            print("NULLCTX", lbl)
            fails += 1
            continue
        worst = min(psnr(x, y) for x, y in zip(*outs))
        thr = 60.0 if (sw == dw and sh == dh) else 40.0
        if worst < thr:
            fails += 1
            print(f"FAIL {lbl}: psnr={worst:.2f} thr={thr}")
    print(f"fuzz seed={seed}: {iters - fails}/{iters} pass")


if __name__ == "__main__":
    main()
