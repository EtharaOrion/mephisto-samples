//! Pixel-format metadata mirroring the SWS_PIXFMT_* ids from swscale_api.h.

pub const YUV420P: i32 = 0;
pub const YUV422P: i32 = 1;
pub const YUV444P: i32 = 2;
pub const NV12: i32 = 3;
pub const NV21: i32 = 4;
pub const RGB24: i32 = 5;
pub const BGR24: i32 = 6;
pub const RGBA: i32 = 7;
pub const BGRA: i32 = 8;
pub const GRAY8: i32 = 9;

#[inline]
pub fn is_rgb(f: i32) -> bool {
    matches!(f, RGB24 | BGR24 | RGBA | BGRA)
}

#[inline]
pub fn is_gray(f: i32) -> bool {
    f == GRAY8
}

#[inline]
pub fn is_semi_planar(f: i32) -> bool {
    f == NV12 || f == NV21
}

#[inline]
pub fn is_planar_yuv(f: i32) -> bool {
    matches!(f, YUV420P | YUV422P | YUV444P | NV12 | NV21 | GRAY8)
}

/// bytes per pixel for packed formats (1 for planar)
#[inline]
pub fn bpp(f: i32) -> usize {
    match f {
        RGB24 | BGR24 => 3,
        RGBA | BGRA => 4,
        _ => 1,
    }
}

/// (log2 chroma w subsample, log2 chroma h subsample) as reported by libavutil
#[inline]
pub fn chroma_sub(f: i32) -> (u32, u32) {
    match f {
        YUV420P | NV12 | NV21 => (1, 1),
        YUV422P => (1, 0),
        _ => (0, 0),
    }
}

/// Byte offsets of R, G, B inside a packed pixel.
#[inline]
pub fn rgb_order(f: i32) -> (usize, usize, usize) {
    match f {
        RGB24 | RGBA => (0, 1, 2),
        BGR24 | BGRA => (2, 1, 0),
        _ => (0, 1, 2),
    }
}

pub fn num_planes(f: i32) -> usize {
    match f {
        YUV420P | YUV422P | YUV444P => 3,
        NV12 | NV21 => 2,
        _ => 1,
    }
}

/// (width, height, bytes-per-sample) of a plane
pub fn plane_dims(f: i32, p: usize, w: usize, h: usize) -> (usize, usize, usize) {
    match f {
        YUV420P => {
            if p == 0 {
                (w, h, 1)
            } else {
                ((w + 1) >> 1, (h + 1) >> 1, 1)
            }
        }
        YUV422P => {
            if p == 0 {
                (w, h, 1)
            } else {
                ((w + 1) >> 1, h, 1)
            }
        }
        YUV444P => (w, h, 1),
        NV12 | NV21 => {
            if p == 0 {
                (w, h, 1)
            } else {
                ((w + 1) >> 1, (h + 1) >> 1, 2)
            }
        }
        RGB24 | BGR24 => (w, h, 3),
        RGBA | BGRA => (w, h, 4),
        GRAY8 => (w, h, 1),
        _ => (0, 0, 0),
    }
}
