//! Minimal persistent worker pool used to split a frame into horizontal bands.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Condvar, Mutex, OnceLock};

pub type BandFn = unsafe fn(usize, usize, usize, usize);

struct Job {
    generation: u64,
    ctx: usize,
    func: usize,
    bands: Vec<(usize, usize)>,
    done: usize,
}

struct Shared {
    state: Mutex<Job>,
    work: Condvar,
    finished: Condvar,
    shutdown: AtomicBool,
}

pub struct Pool {
    shared: &'static Shared,
    workers: usize,
}

static POOL: OnceLock<Pool> = OnceLock::new();

fn worker_loop(shared: &'static Shared, idx: usize) {
    let mut seen = 0u64;
    loop {
        let (ctx, func, band) = {
            let mut g = shared.state.lock().unwrap();
            while g.generation == seen && !shared.shutdown.load(Ordering::Relaxed) {
                g = shared.work.wait(g).unwrap();
            }
            if shared.shutdown.load(Ordering::Relaxed) {
                return;
            }
            seen = g.generation;
            let band = g.bands.get(idx).copied().unwrap_or((0, 0));
            (g.ctx, g.func, band)
        };
        if band.1 > band.0 && func != 0 {
            let f: BandFn = unsafe { std::mem::transmute(func) };
            unsafe { f(ctx, idx, band.0, band.1) };
        }
        let mut g = shared.state.lock().unwrap();
        g.done += 1;
        shared.finished.notify_all();
    }
}

pub fn pool() -> &'static Pool {
    POOL.get_or_init(|| {
        let hw = std::thread::available_parallelism()
            .map(|v| v.get())
            .unwrap_or(1);
        let workers = hw.clamp(1, 8);
        let shared: &'static Shared = Box::leak(Box::new(Shared {
            state: Mutex::new(Job {
                generation: 0,
                ctx: 0,
                func: 0,
                bands: Vec::new(),
                done: 0,
            }),
            work: Condvar::new(),
            finished: Condvar::new(),
            shutdown: AtomicBool::new(false),
        }));
        for i in 1..workers {
            std::thread::Builder::new()
                .name(format!("sws{}", i))
                .stack_size(256 * 1024)
                .spawn(move || worker_loop(shared, i))
                .ok();
        }
        Pool { shared, workers }
    })
}

impl Pool {
    pub fn threads(&self) -> usize {
        self.workers
    }

    /// Runs `f(ctx, worker_index, y0, y1)` for each band; band 0 runs on this thread.
    pub unsafe fn dispatch(&self, ctx: usize, f: BandFn, bands: Vec<(usize, usize)>) {
        let helpers = bands.len().saturating_sub(1);
        let band0 = bands[0];
        {
            let mut g = self.shared.state.lock().unwrap();
            g.ctx = ctx;
            g.func = f as usize;
            g.bands = bands;
            g.done = 0;
            g.generation = g.generation.wrapping_add(1);
        }
        self.shared.work.notify_all();

        if band0.1 > band0.0 {
            f(ctx, 0, band0.0, band0.1);
        }

        if helpers > 0 {
            let mut g = self.shared.state.lock().unwrap();
            while g.done < helpers {
                g = self.shared.finished.wait(g).unwrap();
            }
        }
    }
}

/// Split `total` rows into at most `n` bands whose boundaries are multiples of `granule`.
pub fn split(total: usize, n: usize, granule: usize) -> Vec<(usize, usize)> {
    let units = total.div_ceil(granule);
    let n = n.min(units).max(1);
    let per = units.div_ceil(n);
    let mut v = Vec::with_capacity(n);
    let mut y = 0usize;
    for _ in 0..n {
        let e = (y + per * granule).min(total);
        v.push((y, e));
        y = e;
        if y >= total {
            break;
        }
    }
    v
}
