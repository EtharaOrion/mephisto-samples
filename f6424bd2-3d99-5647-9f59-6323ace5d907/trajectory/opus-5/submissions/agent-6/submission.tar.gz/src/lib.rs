//! libswscale-compatible image scaler / pixel-format converter.
//!
//! Re-implements FFmpeg's swscale semantics (BT.601, the same fixed-point filter
//! generation and the same unscaled special-case converters) with AArch64 NEON
//! kernels, splitting large frames into horizontal bands across a worker pool.

mod colors;
mod fast;
mod filter;
mod fmt;
mod general;
mod neon;
mod pool;
mod simd;

use std::ffi::c_void;
use std::os::raw::c_int;

/// Below this many pixels the thread hand-off costs more than it saves.
const PARALLEL_MIN_PIXELS: usize = 120_000;

pub struct Ctx {
    src_w: usize,
    src_h: usize,
    dst_w: usize,
    dst_h: usize,
    src_fmt: c_int,
    dst_fmt: c_int,
    fast: fast::Fast,
    gens: Vec<Box<general::General>>,
    bands: Vec<(usize, usize)>,
    src: [*const u8; 4],
    dst: [*mut u8; 4],
    ss: [i32; 4],
    ds: [i32; 4],
}

#[inline]
fn valid_fmt(f: c_int) -> bool {
    (0..=9).contains(&f)
}

#[no_mangle]
pub extern "C" fn swscale_create(
    src_w: c_int,
    src_h: c_int,
    src_fmt: c_int,
    dst_w: c_int,
    dst_h: c_int,
    dst_fmt: c_int,
    algo: c_int,
) -> *mut c_void {
    if src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0 {
        return std::ptr::null_mut();
    }
    if !valid_fmt(src_fmt) || !valid_fmt(dst_fmt) || !(0..=2).contains(&algo) {
        return std::ptr::null_mut();
    }
    let (sw, sh, dw, dh) = (
        src_w as usize,
        src_h as usize,
        dst_w as usize,
        dst_h as usize,
    );
    let unscaled = sw == dw && sh == dh;
    let f = if unscaled {
        fast::pick(src_fmt, dst_fmt, dw, dh)
    } else {
        fast::Fast::None
    };

    let granule = if f == fast::Fast::None {
        1 << fmt::chroma_sub(dst_fmt).1
    } else {
        fast::granule(f, dst_fmt)
    };

    let work = dw * dh + sw * sh;
    let want = if work >= PARALLEL_MIN_PIXELS {
        pool::pool().threads()
    } else {
        1
    };
    let bands = pool::split(dh, want, granule);

    let mut gens: Vec<Box<general::General>> = Vec::new();
    if f == fast::Fast::None {
        let g = general::General::new(sw, sh, src_fmt, dw, dh, dst_fmt, algo);
        for _ in 1..bands.len() {
            gens.push(Box::new(g.clone()));
        }
        gens.insert(0, Box::new(g));
    }

    let ctx = Box::new(Ctx {
        src_w: sw,
        src_h: sh,
        dst_w: dw,
        dst_h: dh,
        src_fmt,
        dst_fmt,
        fast: f,
        gens,
        bands,
        src: [std::ptr::null(); 4],
        dst: [std::ptr::null_mut(); 4],
        ss: [0; 4],
        ds: [0; 4],
    });
    Box::into_raw(ctx) as *mut c_void
}

unsafe fn run_band(ctx: usize, worker: usize, y0: usize, y1: usize) {
    let c = &mut *(ctx as *mut Ctx);
    if c.fast != fast::Fast::None {
        fast::run(
            c.fast, c.src_fmt, c.dst_fmt, c.dst_w, c.dst_h, &c.src, &c.ss, &c.dst, &c.ds, y0, y1,
        );
    } else {
        let g = &mut *(c.gens[worker].as_mut() as *mut general::General);
        g.process_band(&c.src, &c.ss, &c.dst, &c.ds, y0, y1);
    }
}

#[no_mangle]
pub unsafe extern "C" fn swscale_process(
    ctx: *mut c_void,
    src_data: *const *const u8,
    src_stride: *const c_int,
    dst_data: *const *mut u8,
    dst_stride: *const c_int,
) -> c_int {
    if ctx.is_null() || src_data.is_null() || dst_data.is_null() {
        return -1;
    }
    let c = &mut *(ctx as *mut Ctx);
    for i in 0..4 {
        c.src[i] = *src_data.add(i);
        c.dst[i] = *dst_data.add(i);
        c.ss[i] = *src_stride.add(i);
        c.ds[i] = *dst_stride.add(i);
    }
    let _ = (c.src_w, c.src_h);

    if c.bands.len() <= 1 {
        run_band(ctx as usize, 0, 0, c.dst_h);
    } else {
        let bands = c.bands.clone();
        pool::pool().dispatch(ctx as usize, run_band, bands);
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn swscale_destroy(ctx: *mut c_void) {
    if ctx.is_null() {
        return;
    }
    drop(Box::from_raw(ctx as *mut Ctx));
}
