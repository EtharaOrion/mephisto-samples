//! libswscale-compatible image scaler / pixel-format converter.
//!
//! Re-implements FFmpeg's swscale semantics (BT.601, the same fixed-point filter
//! generation and the same unscaled special-case converters) with AArch64 NEON
//! kernels, splitting large frames into horizontal bands across a worker pool.

mod colors;
mod fast;
mod filter;
mod fmt;
mod general;
mod neon;
mod pool;
mod simd;

use std::ffi::c_void;
use std::os::raw::c_int;

/// Pixels of work per thread, by converter cost: cheap byte shuffles need a much
/// larger frame before the hand-off pays for itself than a full YUV<->RGB pass.
fn pixels_per_thread(kind: fast::Fast) -> usize {
    match kind {
        fast::Fast::None => 4_000,
        fast::Fast::Yuv2RgbNearest | fast::Fast::Bgr24ToYv12 => 5_000,
        fast::Fast::GrayToRgb | fast::Fast::Rgb2Rgb => 5_000,
        _ => 30_000,
    }
}

/// Two-stage fallback for scale factors whose filters exceed 256 taps, matching
/// FFmpeg's cascaded-context path.
struct Cascade {
    first: *mut c_void,
    second: *mut c_void,
    _buf: Vec<u8>,
    data: [*mut u8; 4],
    stride: [i32; 4],
    /// The intermediate is YUV420P, which carries no alpha, so an alpha-bearing
    /// source keeps its own single-plane scaling chain alongside the colour one.
    alpha: Option<AlphaChain>,
}

struct AlphaChain {
    ctx: *mut c_void,
    src: Vec<u8>,
    dst: Vec<u8>,
    sw: usize,
    sh: usize,
    dw: usize,
    dh: usize,
}

pub struct Ctx {
    src_w: usize,
    src_h: usize,
    dst_w: usize,
    dst_h: usize,
    src_fmt: c_int,
    dst_fmt: c_int,
    fast: fast::Fast,
    gens: Vec<Box<general::General>>,
    bands: Vec<(usize, usize)>,
    src: [*const u8; 4],
    dst: [*mut u8; 4],
    ss: [i32; 4],
    ds: [i32; 4],
    cascade: Option<Box<Cascade>>,
}

fn isqrt(v: u64) -> usize {
    if v == 0 {
        return 0;
    }
    let mut x = (v as f64).sqrt() as u64;
    while x * x > v {
        x -= 1;
    }
    while (x + 1) * (x + 1) <= v {
        x += 1;
    }
    x as usize
}

/// Allocate planes for `fmt` at `w`x`h` with 64-byte aligned rows.
fn alloc_image(fmt: c_int, w: usize, h: usize) -> (Vec<u8>, [*mut u8; 4], [i32; 4]) {
    let np = fmt::num_planes(fmt);
    let mut strides = [0i32; 4];
    let mut sizes = [0usize; 4];
    let mut total = 0usize;
    for p in 0..np {
        let (pw, ph, bps) = fmt::plane_dims(fmt, p, w, h);
        let ls = (pw * bps + 63) & !63;
        strides[p] = ls as i32;
        sizes[p] = ls * ph;
        total += sizes[p] + 64;
    }
    let mut buf = vec![0u8; total + 64];
    let base = buf.as_mut_ptr();
    let mut off = base.align_offset(64);
    let mut data = [std::ptr::null_mut(); 4];
    for p in 0..np {
        data[p] = unsafe { base.add(off) };
        off += sizes[p] + 64;
        off = (off + 63) & !63;
    }
    (buf, data, strides)
}

#[inline]
fn valid_fmt(f: c_int) -> bool {
    (0..=9).contains(&f)
}

/// FFmpeg scales through an intermediate YUV420P frame when a single pass would
/// need more than 256 filter taps.
fn build_cascade(
    sw: usize,
    sh: usize,
    src_fmt: c_int,
    dw: usize,
    dh: usize,
    dst_fmt: c_int,
    algo: c_int,
) -> Option<Box<Cascade>> {
    if (sw as u64) * (sh as u64) <= 4 * (dw as u64) * (dh as u64) {
        return None;
    }
    if std::env::var_os("SW_NOCASC").is_some() {
        return None;
    }
    let mut tw = isqrt((sw as u64) * (dw as u64)).max(1);
    let mut th = isqrt((sh as u64) * (dh as u64)).max(1);
    if let Some(v) = std::env::var_os("SW_TW") {
        tw = v.to_string_lossy().parse().unwrap_or(tw);
    }
    if let Some(v) = std::env::var_os("SW_TH") {
        th = v.to_string_lossy().parse().unwrap_or(th);
    }
    if (tw == sw && th == sh) || (tw == dw && th == dh) {
        return None;
    }
    let tmp_fmt = fmt::YUV420P;
    let first = swscale_create(
        sw as c_int, sh as c_int, src_fmt, tw as c_int, th as c_int, tmp_fmt, algo,
    );
    let second = swscale_create(
        tw as c_int, th as c_int, tmp_fmt, dw as c_int, dh as c_int, dst_fmt, algo,
    );
    if first.is_null() || second.is_null() {
        unsafe {
            swscale_destroy(first);
            swscale_destroy(second);
        }
        return None;
    }
    let (buf, data, stride) = alloc_image(tmp_fmt, tw, th);
    let has_alpha = matches!(src_fmt, fmt::RGBA | fmt::BGRA)
        && matches!(dst_fmt, fmt::RGBA | fmt::BGRA);
    let alpha = if has_alpha {
        let actx = swscale_create(
            sw as c_int,
            sh as c_int,
            fmt::GRAY8,
            dw as c_int,
            dh as c_int,
            fmt::GRAY8,
            algo,
        );
        if actx.is_null() {
            None
        } else {
            Some(AlphaChain {
                ctx: actx,
                src: vec![0u8; sw * sh],
                dst: vec![0u8; dw * dh],
                sw,
                sh,
                dw,
                dh,
            })
        }
    } else {
        None
    };
    Some(Box::new(Cascade {
        first,
        second,
        _buf: buf,
        data,
        stride,
        alpha,
    }))
}

#[no_mangle]
pub extern "C" fn swscale_create(
    src_w: c_int,
    src_h: c_int,
    src_fmt: c_int,
    dst_w: c_int,
    dst_h: c_int,
    dst_fmt: c_int,
    algo: c_int,
) -> *mut c_void {
    if src_w <= 0 || src_h <= 0 || dst_w <= 0 || dst_h <= 0 {
        return std::ptr::null_mut();
    }
    if !valid_fmt(src_fmt) || !valid_fmt(dst_fmt) || !(0..=2).contains(&algo) {
        return std::ptr::null_mut();
    }
    let (sw, sh, dw, dh) = (
        src_w as usize,
        src_h as usize,
        dst_w as usize,
        dst_h as usize,
    );
    let unscaled = sw == dw && sh == dh;
    let f = if unscaled {
        fast::pick(src_fmt, dst_fmt, dw, dh)
    } else {
        fast::Fast::None
    };

    let granule = if f == fast::Fast::None {
        1 << fmt::chroma_sub(dst_fmt).1
    } else {
        fast::granule(f, dst_fmt)
    };

    let work = dw * dh + sw * sh;
    let ppt = pixels_per_thread(f);
    let want = if work >= 2 * ppt {
        (work / ppt).clamp(1, pool::pool().threads())
    } else {
        1
    };
    let bands = pool::split(dh, want, granule);

    let mut gens: Vec<Box<general::General>> = Vec::new();
    let mut cascade = None;
    if f == fast::Fast::None {
        let g = general::General::new(sw, sh, src_fmt, dw, dh, dst_fmt, algo);
        if g.needs_cascade() {
            cascade = match build_cascade(sw, sh, src_fmt, dw, dh, dst_fmt, algo) {
                Some(c) => Some(c),
                None => return std::ptr::null_mut(),
            };
        } else {
            for _ in 1..bands.len() {
                gens.push(Box::new(g.clone_worker()));
            }
            gens.insert(0, Box::new(g));
        }
    }

    let ctx = Box::new(Ctx {
        src_w: sw,
        src_h: sh,
        dst_w: dw,
        dst_h: dh,
        src_fmt,
        dst_fmt,
        fast: f,
        gens,
        bands,
        src: [std::ptr::null(); 4],
        dst: [std::ptr::null_mut(); 4],
        ss: [0; 4],
        ds: [0; 4],
        cascade,
    });
    Box::into_raw(ctx) as *mut c_void
}

unsafe fn run_band(ctx: usize, worker: usize, y0: usize, y1: usize) {
    let c = &mut *(ctx as *mut Ctx);
    if c.fast != fast::Fast::None {
        fast::run(
            c.fast, c.src_fmt, c.dst_fmt, c.dst_w, c.dst_h, &c.src, &c.ss, &c.dst, &c.ds, y0, y1,
        );
    } else {
        let g = &mut *(c.gens[worker].as_mut() as *mut general::General);
        g.process_band(&c.src, &c.ss, &c.dst, &c.ds, y0, y1);
    }
}

#[no_mangle]
pub unsafe extern "C" fn swscale_process(
    ctx: *mut c_void,
    src_data: *const *const u8,
    src_stride: *const c_int,
    dst_data: *const *mut u8,
    dst_stride: *const c_int,
) -> c_int {
    if ctx.is_null() || src_data.is_null() || dst_data.is_null() {
        return -1;
    }
    let c = &mut *(ctx as *mut Ctx);
    for i in 0..4 {
        c.src[i] = *src_data.add(i);
        c.dst[i] = *dst_data.add(i);
        c.ss[i] = *src_stride.add(i);
        c.ds[i] = *dst_stride.add(i);
    }
    let src = c.src;
    let dst = c.dst;
    let _ = (c.src_w, c.src_h);

    if c.cascade.is_some() {
        let cas = c.cascade.as_mut().unwrap();
        let mid: [*const u8; 4] = [cas.data[0], cas.data[1], cas.data[2], cas.data[3]];
        if let Some(a) = cas.alpha.as_mut() {
            for y in 0..a.sh {
                let row = src[0].add(y * c.ss[0] as usize);
                let out = a.src.as_mut_ptr().add(y * a.sw);
                for x in 0..a.sw {
                    *out.add(x) = *row.add(x * 4 + 3);
                }
            }
        }
        let r = swscale_process(
            cas.first,
            src.as_ptr(),
            c.ss.as_ptr(),
            cas.data.as_ptr(),
            cas.stride.as_ptr(),
        );
        if r != 0 {
            return r;
        }
        let r = swscale_process(
            cas.second,
            mid.as_ptr(),
            cas.stride.as_ptr(),
            dst.as_ptr(),
            c.ds.as_ptr(),
        );
        if r != 0 {
            return r;
        }
        if let Some(a) = cas.alpha.as_mut() {
            let asrc: [*const u8; 4] = [a.src.as_ptr(), std::ptr::null(), std::ptr::null(), std::ptr::null()];
            let astride: [i32; 4] = [a.sw as i32, 0, 0, 0];
            let adst: [*mut u8; 4] = [a.dst.as_mut_ptr(), std::ptr::null_mut(), std::ptr::null_mut(), std::ptr::null_mut()];
            let adstride: [i32; 4] = [a.dw as i32, 0, 0, 0];
            swscale_process(a.ctx, asrc.as_ptr(), astride.as_ptr(), adst.as_ptr(), adstride.as_ptr());
            for y in 0..a.dh {
                let row = dst[0].add(y * c.ds[0] as usize);
                let inp = a.dst.as_ptr().add(y * a.dw);
                for x in 0..a.dw {
                    *row.add(x * 4 + 3) = *inp.add(x);
                }
            }
        }
        return 0;
    }

    if c.bands.len() <= 1 {
        run_band(ctx as usize, 0, 0, c.dst_h);
    } else {
        let bands = &*(&c.bands as *const Vec<(usize, usize)>);
        pool::pool().dispatch(ctx as usize, run_band, bands);
    }
    0
}

#[no_mangle]
pub unsafe extern "C" fn swscale_destroy(ctx: *mut c_void) {
    if ctx.is_null() {
        return;
    }
    let boxed = Box::from_raw(ctx as *mut Ctx);
    if let Some(cas) = boxed.cascade.as_ref() {
        swscale_destroy(cas.first);
        swscale_destroy(cas.second);
        if let Some(a) = cas.alpha.as_ref() {
            swscale_destroy(a.ctx);
        }
    }
    drop(boxed);
}
