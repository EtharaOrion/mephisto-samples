//! Minimal persistent worker pool used to split a frame into horizontal bands.
//!
//! Workers spin briefly before parking so that the hand-off for a sub-millisecond
//! frame stays cheap, but an idle pool still costs nothing.

use std::sync::atomic::{AtomicU64, AtomicUsize, Ordering};
use std::sync::{Condvar, Mutex, OnceLock};
use std::time::Duration;

pub type BandFn = unsafe fn(usize, usize, usize, usize);

const SPIN: u32 = 8_000;

/// Completion counters are sharded across cache lines: with a hundred workers a
/// single counter turns the hand-off into a hundred serialised invalidations.
const SHARDS: usize = 8;

#[repr(align(64))]
struct Shard(AtomicUsize);

struct Shared {
    generation: AtomicU64,
    ctx: AtomicUsize,
    func: AtomicUsize,
    bands: AtomicUsize, // *const Vec<(usize, usize)>
    done: [Shard; SHARDS],
    mtx: Mutex<u64>,
    cv: Condvar,
}

unsafe impl Send for Shared {}
unsafe impl Sync for Shared {}

pub struct Pool {
    shared: &'static Shared,
    workers: usize,
    /// Only one dispatch may own the shared hand-off slots at a time; callers
    /// that lose the race run their bands inline instead of waiting.
    gate: Mutex<()>,
}

static POOL: OnceLock<Pool> = OnceLock::new();

fn worker_loop(shared: &'static Shared, idx: usize) {
    let mut seen = 0u64;
    loop {
        let mut spins = 0u32;
        loop {
            let g = shared.generation.load(Ordering::Acquire);
            if g != seen {
                seen = g;
                break;
            }
            spins += 1;
            if spins < SPIN {
                std::hint::spin_loop();
            } else {
                let lk = shared.mtx.lock().unwrap();
                if *lk == seen {
                    let _ = shared.cv.wait_timeout(lk, Duration::from_millis(2));
                }
                spins = 0;
            }
        }

        let bands_ptr = shared.bands.load(Ordering::Acquire) as *const Vec<(usize, usize)>;
        let func = shared.func.load(Ordering::Relaxed);
        let ctx = shared.ctx.load(Ordering::Relaxed);
        // Only workers that actually own a band report completion; the dispatcher
        // waits for exactly that many acknowledgements.
        if !bands_ptr.is_null() && func != 0 {
            let bands = unsafe { &*bands_ptr };
            if let Some(&(a, b)) = bands.get(idx) {
                if b > a {
                    let f: BandFn = unsafe { std::mem::transmute(func) };
                    unsafe { f(ctx, idx, a, b) };
                }
                shared.done[idx % SHARDS].0.fetch_add(1, Ordering::Release);
            }
        }
    }
}

pub fn pool() -> &'static Pool {
    POOL.get_or_init(|| {
        let hw = std::thread::available_parallelism()
            .map(|v| v.get())
            .unwrap_or(1);
        // SWS_THREADS is a development knob for measuring single-thread kernels.
        let want = std::env::var("SWS_THREADS")
            .ok()
            .and_then(|v| v.parse::<usize>().ok())
            .unwrap_or(hw);
        let workers = want.min(hw).clamp(1, 256);
        let shared: &'static Shared = Box::leak(Box::new(Shared {
            generation: AtomicU64::new(0),
            ctx: AtomicUsize::new(0),
            func: AtomicUsize::new(0),
            bands: AtomicUsize::new(0),
            done: [
                Shard(AtomicUsize::new(0)),
                Shard(AtomicUsize::new(0)),
                Shard(AtomicUsize::new(0)),
                Shard(AtomicUsize::new(0)),
                Shard(AtomicUsize::new(0)),
                Shard(AtomicUsize::new(0)),
                Shard(AtomicUsize::new(0)),
                Shard(AtomicUsize::new(0)),
            ],
            mtx: Mutex::new(0),
            cv: Condvar::new(),
        }));
        for i in 1..workers {
            std::thread::Builder::new()
                .name(format!("sws{}", i))
                .stack_size(128 * 1024)
                .spawn(move || worker_loop(shared, i))
                .ok();
        }
        Pool {
            shared,
            workers,
            gate: Mutex::new(()),
        }
    })
}

impl Pool {
    pub fn threads(&self) -> usize {
        self.workers
    }

    /// Runs `f(ctx, worker_index, y0, y1)` for each band; band 0 runs on this
    /// thread. Returns false without doing anything if another thread is
    /// already dispatching, in which case the caller must run the bands itself.
    ///
    /// `bands` must outlive the call (it lives in the caller's context).
    pub unsafe fn dispatch(&self, ctx: usize, f: BandFn, bands: &Vec<(usize, usize)>) -> bool {
        let _gate = match self.gate.try_lock() {
            Ok(g) => g,
            Err(_) => return false,
        };
        debug_assert!(bands.len() <= self.workers);
        let helpers = bands.len() - 1;
        let s = self.shared;
        s.ctx.store(ctx, Ordering::Relaxed);
        s.func.store(f as usize, Ordering::Relaxed);
        s.bands
            .store(bands as *const Vec<(usize, usize)> as usize, Ordering::Release);
        for sh in s.done.iter() {
            sh.0.store(0, Ordering::Release);
        }
        {
            let mut lk = s.mtx.lock().unwrap();
            *lk += 1;
            s.generation.store(*lk, Ordering::Release);
        }
        s.cv.notify_all();

        let (a, b) = bands[0];
        if b > a {
            f(ctx, 0, a, b);
        }

        let mut spins = 0u32;
        let acked = || s.done.iter().map(|sh| sh.0.load(Ordering::Acquire)).sum::<usize>();
        while acked() < helpers {
            spins += 1;
            if spins < SPIN {
                std::hint::spin_loop();
            } else {
                std::thread::yield_now();
            }
        }
        true
    }
}

/// Split `total` rows into at most `n` bands whose boundaries are multiples of `granule`.
pub fn split(total: usize, n: usize, granule: usize) -> Vec<(usize, usize)> {
    let units = total.div_ceil(granule);
    let n = n.min(units).max(1);
    let per = units.div_ceil(n);
    let mut v = Vec::with_capacity(n);
    let mut y = 0usize;
    while y < total {
        let e = (y + per * granule).min(total);
        v.push((y, e));
        y = e;
    }
    v
}
