#!/usr/bin/env python3
"""Compare against the baseline on the real sample frames.

Colour bars and gradients keep their chroma structure under downscaling, so
this is the closest local stand-in for the hidden workloads.
"""
from __future__ import annotations
import argparse, json, math, os, sys
import numpy as np
sys.path.insert(0, "/app/workspace")
from pixel_formats import (PIXFMT_NAMES, ALGO_NAMES, load_swscale_library,
                           allocate_image, image_to_bytes, fill_image_from_bytes,
                           PIXFMT_DESCS)

BASE = "/app/libswscale_public_baseline.so"
MEDIA_DIR = "/app/workspace/media"
NAME_TO_FMT = {n: i for i, n in PIXFMT_NAMES.items()}


def psnr(x: bytes, y: bytes) -> float:
    if len(x) != len(y):
        return -1.0
    if x == y:
        return 999.0
    a = np.frombuffer(x, dtype=np.uint8).astype(np.int32)
    b = np.frombuffer(y, dtype=np.uint8).astype(np.int32)
    m = float(np.mean((a - b) ** 2))
    return 999.0 if m == 0 else 10 * math.log10(65025 / m)


def load(entry):
    fmt = NAME_TO_FMT[entry["fmt"]]
    w, h = entry["w"], entry["h"]
    path = os.path.join(MEDIA_DIR, os.path.basename(entry["path"]))
    raw = open(path, "rb").read()
    d = PIXFMT_DESCS[fmt]
    planes, off = [], 0
    for i in range(d.num_planes):
        n = d.plane_width(i, w) * d.planes[i].bpp * d.plane_height(i, h)
        planes.append(raw[off:off + n])
        off += n
    return fmt, w, h, planes


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidate",
                    default="/home/workspace/swscale-impl/target/release/libswscale_candidate.so")
    args = ap.parse_args()
    b = load_swscale_library(BASE)
    c = load_swscale_library(args.candidate)
    entries = json.load(open(os.path.join(MEDIA_DIR, "manifest.json")))
    npass = nfail = 0
    for entry in entries:
        sf, sw, sh, sp = load(entry)
        for df in range(10):
            for scale in ((1, 1), (2, 2), (1, 2), (2, 1), (4, 4), (8, 8), (1, 3)):
                dw = max(sw * scale[1] // scale[0] // 1, 2)
                dh = max(sh * scale[1] // scale[0] // 1, 2)
                if sf in (0, 1, 3, 4) or df in (0, 1, 3, 4):
                    dw &= ~1
                if sf in (0, 3, 4) or df in (0, 3, 4):
                    dh &= ~1
                dw, dh = max(dw, 2), max(dh, 2)
                for algo in range(3):
                    sd, ss, _ = allocate_image(sf, sw, sh, 32)
                    fill_image_from_bytes(sf, sw, sh, sd, ss, sp)
                    outs = []
                    for lib in (b, c):
                        dd, ds, _ = allocate_image(df, dw, dh, 32)
                        ctx = lib.swscale_create(sw, sh, sf, dw, dh, df, algo)
                        if not ctx:
                            outs.append(None)
                            continue
                        lib.swscale_process(ctx, sd, ss, dd, ds)
                        outs.append(image_to_bytes(df, dw, dh, dd, ds))
                        lib.swscale_destroy(ctx)
                    lbl = (f"{entry['name']} {PIXFMT_NAMES[sf]}->{PIXFMT_NAMES[df]} "
                           f"{sw}x{sh}->{dw}x{dh} {ALGO_NAMES[algo]}")
                    if (outs[0] is None) != (outs[1] is None):
                        print("NULLCTX", lbl)
                        nfail += 1
                        continue
                    if outs[0] is None:
                        continue
                    worst = min(psnr(x, y) for x, y in zip(*outs))
                    thr = 60.0 if (sw == dw and sh == dh) else 40.0
                    if worst < thr:
                        nfail += 1
                        print(f"FAIL {lbl}: psnr={worst:.2f} thr={thr}")
                    else:
                        npass += 1
    print(f"PASS {npass}  FAIL {nfail}")


if __name__ == "__main__":
    main()
