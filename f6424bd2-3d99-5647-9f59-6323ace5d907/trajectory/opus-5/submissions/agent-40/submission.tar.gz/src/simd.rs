//! Row kernels. Scalar reference implementations; NEON specialisations live in `neon.rs`.

use crate::colors::*;
use crate::fmt::*;

#[inline(always)]
pub unsafe fn widen_shl7(src: *const u8, dst: *mut i16, n: usize) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::widen_shl7_neon(src, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        *dst.add(i) = (*src.add(i) as i16) << 7;
    }
}

pub unsafe fn deinterleave(src: *const u8, du: *mut u8, dv: *mut u8, n: usize) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::deinterleave_neon(src, du, dv, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        *du.add(i) = *src.add(2 * i);
        *dv.add(i) = *src.add(2 * i + 1);
    }
}

pub unsafe fn rgba_to_a16(_fmt: i32, src: *const u8, dst: *mut i16, n: usize) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgba_to_a16_neon(src, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        let a = *src.add(i * 4 + 3) as i32;
        *dst.add(i) = ((a << 6) | (a >> 2)) as i16;
    }
}

pub unsafe fn rgb_to_y16(fmt: i32, src: *const u8, dst: *mut i16, n: usize) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_to_y16_neon(fmt, src, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    {
        let step = bpp(fmt);
        let (ro, go, bo) = rgb_order(fmt);
        for i in 0..n {
            let p = src.add(i * step);
            let r = *p.add(ro) as i32;
            let g = *p.add(go) as i32;
            let b = *p.add(bo) as i32;
            *dst.add(i) = ((RY * r + GY * g + BY * b + (32 << 14) + (1 << 8)) >> 9) as i16;
        }
    }
}

pub unsafe fn rgb_to_uv16(
    fmt: i32,
    src: *const u8,
    du: *mut i16,
    dv: *mut i16,
    n: usize,
    half: bool,
    src_w: usize,
) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_to_uv16_neon(fmt, src, du, dv, n, half, src_w);
        return;
    }
    #[allow(unreachable_code)]
    {
        let step = bpp(fmt);
        let (ro, go, bo) = rgb_order(fmt);
        if !half {
            for i in 0..n {
                let p = src.add(i * step);
                let r = *p.add(ro) as i32;
                let g = *p.add(go) as i32;
                let b = *p.add(bo) as i32;
                *du.add(i) = ((RU * r + GU * g + BU * b + (256 << 14) + (1 << 8)) >> 9) as i16;
                *dv.add(i) = ((RV * r + GV * g + BV * b + (256 << 14) + (1 << 8)) >> 9) as i16;
            }
        } else {
            for i in 0..n {
                let i0 = 2 * i;
                let i1 = if 2 * i + 1 < src_w { 2 * i + 1 } else { i0 };
                let p0 = src.add(i0 * step);
                let p1 = src.add(i1 * step);
                let r = *p0.add(ro) as i32 + *p1.add(ro) as i32;
                let g = *p0.add(go) as i32 + *p1.add(go) as i32;
                let b = *p0.add(bo) as i32 + *p1.add(bo) as i32;
                *du.add(i) = ((RU * r + GU * g + BU * b + (256 << 15) + (1 << 9)) >> 10) as i16;
                *dv.add(i) = ((RV * r + GV * g + BV * b + (256 << 15) + (1 << 9)) >> 10) as i16;
            }
        }
    }
}

// ── vertical / output ────────────────────────────────────────────────────────

pub unsafe fn yuv2plane1(src: *const i16, dst: *mut u8, n: usize) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::yuv2plane1_neon(src, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        *dst.add(i) = clip_u8((*src.add(i) as i32 + 64) >> 7);
    }
}

pub unsafe fn yuv2plane_x(f: &[i16], srcs: &[*const i16], dst: *mut u8, n: usize) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::yuv2plane_x_neon(f, srcs, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        let mut val: i32 = 64 << 12;
        for j in 0..f.len() {
            val += *srcs[j].add(i) as i32 * f[j] as i32;
        }
        *dst.add(i) = clip_u8(val >> 19);
    }
}

pub unsafe fn yuv2nv12cx(
    swap: bool,
    f: &[i16],
    su: &[*const i16],
    sv: &[*const i16],
    dst: *mut u8,
    n: usize,
) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::yuv2nv12cx_neon(swap, f, su, sv, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        let mut u: i32 = 64 << 12;
        let mut v: i32 = 64 << 12;
        for j in 0..f.len() {
            u += *su[j].add(i) as i32 * f[j] as i32;
            v += *sv[j].add(i) as i32 * f[j] as i32;
        }
        let (a, b) = if swap {
            (clip_u8(v >> 19), clip_u8(u >> 19))
        } else {
            (clip_u8(u >> 19), clip_u8(v >> 19))
        };
        *dst.add(2 * i) = a;
        *dst.add(2 * i + 1) = b;
    }
}

// ── packed RGB output (chroma at half horizontal resolution) ─────────────────

#[inline(always)]
unsafe fn write2(fmt: i32, dst: *mut u8, i: usize, p1: (u8, u8, u8), p2: (u8, u8, u8)) {
    match fmt {
        RGB24 => {
            let d = dst.add(i * 6);
            *d = p1.0;
            *d.add(1) = p1.1;
            *d.add(2) = p1.2;
            *d.add(3) = p2.0;
            *d.add(4) = p2.1;
            *d.add(5) = p2.2;
        }
        BGR24 => {
            let d = dst.add(i * 6);
            *d = p1.2;
            *d.add(1) = p1.1;
            *d.add(2) = p1.0;
            *d.add(3) = p2.2;
            *d.add(4) = p2.1;
            *d.add(5) = p2.0;
        }
        RGBA => {
            let d = dst.add(i * 8);
            *d = p1.0;
            *d.add(1) = p1.1;
            *d.add(2) = p1.2;
            *d.add(3) = 255;
            *d.add(4) = p2.0;
            *d.add(5) = p2.1;
            *d.add(6) = p2.2;
            *d.add(7) = 255;
        }
        _ => {
            let d = dst.add(i * 8);
            *d = p1.2;
            *d.add(1) = p1.1;
            *d.add(2) = p1.0;
            *d.add(3) = 255;
            *d.add(4) = p2.2;
            *d.add(5) = p2.1;
            *d.add(6) = p2.0;
            *d.add(7) = 255;
        }
    }
}

#[inline(always)]
unsafe fn emit_pair(cf: &Cf, fmt: i32, dst: *mut u8, i: usize, y1: i32, y2: i32, u: i32, v: i32) {
    let (kr, kg, kb) = rgb_bases(cf, u, v);
    let p1 = (ytab(cf, kr, y1), ytab(cf, kg, y1), ytab(cf, kb, y1));
    let p2 = (ytab(cf, kr, y2), ytab(cf, kg, y2), ytab(cf, kb, y2));
    write2(fmt, dst, i, p1, p2);
}

/// `yuv2rgb_full_1` straight off three 8-bit planes.
pub unsafe fn rgb_full_1_u8(
    cf: &Cf,
    fmt: i32,
    yp: *const u8,
    up: *const u8,
    vp: *const u8,
    dst: *mut u8,
    w: usize,
) {
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_full_1_u8_neon(cf, fmt, yp, up, vp, dst, w);
        return;
    }
    #[allow(unreachable_code)]
    {
        let step = bpp(fmt);
        for i in 0..w {
            let y = (*yp.add(i) as i32) << 9;
            let u = (*up.add(i) as i32 - 128) << 9;
            let v = (*vp.add(i) as i32 - 128) << 9;
            write_full(cf, fmt, dst.add(i * step), y, u, v);
        }
    }
}

/// `yuv2packed1` straight off an NV12/NV21 frame: with unit horizontal filters
/// the whole 15-bit pipeline collapses to a rounding average of two chroma rows.
pub unsafe fn rgb_1_nv(
    cf: &Cf,
    fmt: i32,
    yp: *const u8,
    uv0: *const u8,
    uv1: *const u8,
    swap: bool,
    two: bool,
    dst: *mut u8,
    w: usize,
) {
    let n = (w + 1) >> 1;
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_1_nv_neon(cf, fmt, yp, uv0, uv1, swap, two, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    {
        let (uo, vo) = if swap { (1usize, 0usize) } else { (0usize, 1usize) };
        for i in 0..n {
            let y1 = *yp.add(2 * i) as i32;
            let y2 = *yp.add(2 * i + 1) as i32;
            let (u, v) = if two {
                (
                    (*uv0.add(2 * i + uo) as i32 + *uv1.add(2 * i + uo) as i32 + 1) >> 1,
                    (*uv0.add(2 * i + vo) as i32 + *uv1.add(2 * i + vo) as i32 + 1) >> 1,
                )
            } else {
                (*uv0.add(2 * i + uo) as i32, *uv0.add(2 * i + vo) as i32)
            };
            emit_pair(cf, fmt, dst, i, y1, y2, u, v);
        }
    }
}

/// `yuv2packed1` reading 8-bit luma straight from the source plane.
pub unsafe fn rgb_1_u8(
    cf: &Cf,
    fmt: i32,
    yp: *const u8,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    dst: *mut u8,
    w: usize,
    uvalpha: i32,
) {
    let n = (w + 1) >> 1;
    let two = uvalpha >= 2048;
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_1_u8_neon(cf, fmt, yp, ubuf0, ubuf1, vbuf0, vbuf1, two, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        let y1 = *yp.add(2 * i) as i32;
        let y2 = *yp.add(2 * i + 1) as i32;
        let (u, v) = if two {
            (
                (*ubuf0.add(i) as i32 + *ubuf1.add(i) as i32 + 128) >> 8,
                (*vbuf0.add(i) as i32 + *vbuf1.add(i) as i32 + 128) >> 8,
            )
        } else {
            (
                (*ubuf0.add(i) as i32 + 64) >> 7,
                (*vbuf0.add(i) as i32 + 64) >> 7,
            )
        };
        emit_pair(cf, fmt, dst, i, y1, y2, u, v);
    }
}

pub unsafe fn rgb_1(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    dst: *mut u8,
    w: usize,
    uvalpha: i32,
) {
    let n = (w + 1) >> 1;
    let two = uvalpha >= 2048;
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_1_neon(cf, fmt, buf0, ubuf0, ubuf1, vbuf0, vbuf1, two, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        let y1 = (*buf0.add(2 * i) as i32 + 64) >> 7;
        let y2 = (*buf0.add(2 * i + 1) as i32 + 64) >> 7;
        let (u, v) = if two {
            (
                (*ubuf0.add(i) as i32 + *ubuf1.add(i) as i32 + 128) >> 8,
                (*vbuf0.add(i) as i32 + *vbuf1.add(i) as i32 + 128) >> 8,
            )
        } else {
            (
                (*ubuf0.add(i) as i32 + 64) >> 7,
                (*vbuf0.add(i) as i32 + 64) >> 7,
            )
        };
        emit_pair(cf, fmt, dst, i, y1, y2, u, v);
    }
}

pub unsafe fn rgb_2(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    buf1: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    dst: *mut u8,
    w: usize,
    yalpha: i32,
    uvalpha: i32,
) {
    let n = (w + 1) >> 1;
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_2_neon(
            cf, fmt, buf0, buf1, ubuf0, ubuf1, vbuf0, vbuf1, dst, n, yalpha, uvalpha,
        );
        return;
    }
    #[allow(unreachable_code)]
    let ya1 = 4096 - yalpha;
    let ua1 = 4096 - uvalpha;
    for i in 0..n {
        let y1 = (*buf0.add(2 * i) as i32 * ya1 + *buf1.add(2 * i) as i32 * yalpha) >> 19;
        let y2 = (*buf0.add(2 * i + 1) as i32 * ya1 + *buf1.add(2 * i + 1) as i32 * yalpha) >> 19;
        let u = (*ubuf0.add(i) as i32 * ua1 + *ubuf1.add(i) as i32 * uvalpha) >> 19;
        let v = (*vbuf0.add(i) as i32 * ua1 + *vbuf1.add(i) as i32 * uvalpha) >> 19;
        emit_pair(cf, fmt, dst, i, y1, y2, u, v);
    }
}

pub unsafe fn rgb_x(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    dst: *mut u8,
    w: usize,
) {
    let n = (w + 1) >> 1;
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_x_neon(cf, fmt, lf, lsrc, chf, usrc, vsrc, dst, n);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..n {
        let mut y1: i32 = 1 << 18;
        let mut y2: i32 = 1 << 18;
        let mut u: i32 = 1 << 18;
        let mut v: i32 = 1 << 18;
        for j in 0..lf.len() {
            let c = lf[j] as i32;
            y1 += *lsrc[j].add(2 * i) as i32 * c;
            y2 += *lsrc[j].add(2 * i + 1) as i32 * c;
        }
        for j in 0..chf.len() {
            let c = chf[j] as i32;
            u += *usrc[j].add(i) as i32 * c;
            v += *vsrc[j].add(i) as i32 * c;
        }
        emit_pair(cf, fmt, dst, i, y1 >> 19, y2 >> 19, u >> 19, v >> 19);
    }
}

// ── packed RGB output, full chroma interpolation ─────────────────────────────

#[inline(always)]
#[allow(dead_code)]
pub unsafe fn write_full(cf: &Cf, fmt: i32, dst: *mut u8, y: i32, u: i32, v: i32) {
    write_full_a(cf, fmt, dst, y, u, v, 255)
}

#[inline(always)]
pub unsafe fn write_full_a(cf: &Cf, fmt: i32, dst: *mut u8, y: i32, u: i32, v: i32, a: i32) {
    let yy = (y - cf.y_offset).wrapping_mul(cf.y_coeff).wrapping_add(1 << 21);
    let r = clip_uintp2_30(yy.wrapping_add(v.wrapping_mul(cf.v2r))) >> 22;
    let g = clip_uintp2_30(
        yy.wrapping_add(v.wrapping_mul(cf.v2g))
            .wrapping_add(u.wrapping_mul(cf.u2g)),
    ) >> 22;
    let b = clip_uintp2_30(yy.wrapping_add(u.wrapping_mul(cf.u2b))) >> 22;
    match fmt {
        RGB24 => {
            *dst = r as u8;
            *dst.add(1) = g as u8;
            *dst.add(2) = b as u8;
        }
        BGR24 => {
            *dst = b as u8;
            *dst.add(1) = g as u8;
            *dst.add(2) = r as u8;
        }
        RGBA => {
            *dst = r as u8;
            *dst.add(1) = g as u8;
            *dst.add(2) = b as u8;
            *dst.add(3) = a as u8;
        }
        _ => {
            *dst = b as u8;
            *dst.add(1) = g as u8;
            *dst.add(2) = r as u8;
            *dst.add(3) = a as u8;
        }
    }
}

pub unsafe fn rgb_full_1(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    abuf0: *const i16,
    dst: *mut u8,
    w: usize,
    uvalpha: i32,
) {
    let step = bpp(fmt);
    let _ = step;
    let two = uvalpha >= 2048;
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_full_1_neon(
            cf, fmt, buf0, ubuf0, ubuf1, vbuf0, vbuf1, two, abuf0, dst, w,
        );
        return;
    }
    #[allow(unreachable_code)]
    if !two {
        for i in 0..w {
            let y = *buf0.add(i) as i32 * 4;
            let u = (*ubuf0.add(i) as i32 - (128 << 7)) * 4;
            let v = (*vbuf0.add(i) as i32 - (128 << 7)) * 4;
            let a = if abuf0.is_null() {
                255
            } else {
                clip_u8((*abuf0.add(i) as i32 + 64) >> 7) as i32
            };
            write_full_a(cf, fmt, dst.add(i * step), y, u, v, a);
        }
    } else {
        for i in 0..w {
            let y = *buf0.add(i) as i32 * 4;
            let u = (*ubuf0.add(i) as i32 + *ubuf1.add(i) as i32 - (128 << 8)) * 2;
            let v = (*vbuf0.add(i) as i32 + *vbuf1.add(i) as i32 - (128 << 8)) * 2;
            let a = if abuf0.is_null() {
                255
            } else {
                clip_u8((*abuf0.add(i) as i32 + 64) >> 7) as i32
            };
            write_full_a(cf, fmt, dst.add(i * step), y, u, v, a);
        }
    }
}

pub unsafe fn rgb_full_2(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    buf1: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    abuf0: *const i16,
    abuf1: *const i16,
    dst: *mut u8,
    w: usize,
    yalpha: i32,
    uvalpha: i32,
) {
    #[allow(unused_variables)]
    let step = bpp(fmt);
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_full_2_neon(
            cf, fmt, buf0, buf1, ubuf0, ubuf1, vbuf0, vbuf1, abuf0, abuf1, dst, w, yalpha, uvalpha,
        );
        return;
    }
    #[allow(unreachable_code)]
    let ya1 = 4096 - yalpha;
    let ua1 = 4096 - uvalpha;
    for i in 0..w {
        let y = (*buf0.add(i) as i32 * ya1 + *buf1.add(i) as i32 * yalpha) >> 10;
        let u = (*ubuf0.add(i) as i32 * ua1 + *ubuf1.add(i) as i32 * uvalpha - (128 << 19)) >> 10;
        let v = (*vbuf0.add(i) as i32 * ua1 + *vbuf1.add(i) as i32 * uvalpha - (128 << 19)) >> 10;
        let a = if abuf0.is_null() {
            255
        } else {
            clip_u8((*abuf0.add(i) as i32 * ya1 + *abuf1.add(i) as i32 * yalpha + (1 << 18)) >> 19)
                as i32
        };
        write_full_a(cf, fmt, dst.add(i * step), y, u, v, a);
    }
}

pub unsafe fn rgb_full_x(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    asrc: &[*const i16],
    dst: *mut u8,
    w: usize,
) {
    #[allow(unused_variables)]
    let step = bpp(fmt);
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::rgb_full_x_neon(cf, fmt, lf, lsrc, chf, usrc, vsrc, asrc, dst, w);
        return;
    }
    #[allow(unreachable_code)]
    for i in 0..w {
        let mut y: i32 = 1 << 9;
        let mut u: i32 = (1 << 9) - (128 << 19);
        let mut v: i32 = (1 << 9) - (128 << 19);
        for j in 0..lf.len() {
            y += *lsrc[j].add(i) as i32 * lf[j] as i32;
        }
        for j in 0..chf.len() {
            let c = chf[j] as i32;
            u += *usrc[j].add(i) as i32 * c;
            v += *vsrc[j].add(i) as i32 * c;
        }
        let a = if asrc.is_empty() {
            255
        } else {
            let mut aa: i32 = 1 << 18;
            for j in 0..lf.len() {
                aa += *asrc[j].add(i) as i32 * lf[j] as i32;
            }
            clip_u8(aa >> 19) as i32
        };
        write_full_a(cf, fmt, dst.add(i * step), y >> 10, u >> 10, v >> 10, a);
    }
}
