//! Unscaled special-case converters mirroring FFmpeg's `ff_get_unscaled_swscale` set.

use crate::colors::*;
use crate::fmt::*;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Fast {
    None,
    PlanarCopy,
    PackedCopy,
    Rgb2Rgb,
    Yuv2RgbNearest, // YUV420P / YUV422P -> packed RGB
    Bgr24ToYv12,
    PlanarToNv,
    NvToPlanar,
    NvToNv,
    GrayToRgb,
}

pub fn pick(src_fmt: i32, dst_fmt: i32, w: usize, h: usize) -> Fast {
    // GRAY8 is flagged full-range by handle_jpeg(); mismatched ranges disable
    // the unscaled special converters entirely (unless the destination is RGB).
    if is_gray(src_fmt) != is_gray(dst_fmt) && !is_rgb(dst_fmt) {
        return Fast::None;
    }
    // ordering matches ff_get_unscaled_swscale (later assignments win)
    let mut f = Fast::None;
    if src_fmt == YUV420P && (dst_fmt == NV12 || dst_fmt == NV21) {
        f = Fast::PlanarToNv;
    }
    if dst_fmt == YUV420P && (src_fmt == NV12 || src_fmt == NV21) {
        f = Fast::NvToPlanar;
    }
    if (src_fmt == YUV420P || src_fmt == YUV422P) && is_rgb(dst_fmt) && (h & 1) == 0 {
        f = Fast::Yuv2RgbNearest;
    }
    if src_fmt == BGR24 && dst_fmt == YUV420P && (w & 1) == 0 {
        f = Fast::Bgr24ToYv12;
    }
    if is_rgb(src_fmt) && is_rgb(dst_fmt) {
        f = Fast::Rgb2Rgb;
    }
    // simple copy
    if src_fmt == dst_fmt {
        f = if is_rgb(src_fmt) {
            Fast::PackedCopy
        } else {
            Fast::PlanarCopy
        };
    } else if (is_planar_yuv(src_fmt) && is_gray(dst_fmt))
        || (is_planar_yuv(dst_fmt) && is_gray(src_fmt))
        || (is_planar_yuv(src_fmt)
            && is_planar_yuv(dst_fmt)
            && chroma_sub(src_fmt) == chroma_sub(dst_fmt)
            && !is_semi_planar(src_fmt)
            && !is_semi_planar(dst_fmt))
    {
        f = Fast::PlanarCopy;
    }
    if is_gray(src_fmt) && is_rgb(dst_fmt) {
        // GRAY8 is full-range, so yuv2rgb_full reduces to a channel broadcast.
        f = Fast::GrayToRgb;
    }
    if (src_fmt == NV12 && dst_fmt == NV21) || (src_fmt == NV21 && dst_fmt == NV12) {
        // not an FFmpeg unscaled path; general engine handles it identically
        f = Fast::None;
    }
    f
}

#[inline]
unsafe fn copy_rows(src: *const u8, ss: isize, dst: *mut u8, ds: isize, n: usize, rows: usize) {
    if ss == n as isize && ds == n as isize {
        std::ptr::copy_nonoverlapping(src, dst, n * rows);
        return;
    }
    for y in 0..rows {
        std::ptr::copy_nonoverlapping(
            src.offset(y as isize * ss),
            dst.offset(y as isize * ds),
            n,
        );
    }
}

/// Row granularity required when splitting this converter into bands.
pub fn granule(kind: Fast, dst_fmt: i32) -> usize {
    match kind {
        Fast::Yuv2RgbNearest | Fast::Bgr24ToYv12 | Fast::PlanarToNv | Fast::NvToPlanar => 2,
        Fast::PlanarCopy => 1 << chroma_sub(dst_fmt).1,
        _ => 1,
    }
}

pub unsafe fn run(
    kind: Fast,
    src_fmt: i32,
    dst_fmt: i32,
    w: usize,
    h: usize,
    src: &[*const u8; 4],
    ss: &[i32; 4],
    dst: &[*mut u8; 4],
    ds: &[i32; 4],
    y0: usize,
    y1: usize,
) {
    let h_all = h;
    let h = y1 - y0;
    match kind {
        Fast::PackedCopy => {
            let n = w * bpp(src_fmt);
            copy_rows(
                src[0].offset(y0 as isize * ss[0] as isize),
                ss[0] as isize,
                dst[0].offset(y0 as isize * ds[0] as isize),
                ds[0] as isize,
                n,
                h,
            );
        }
        Fast::PlanarCopy => {
            let np_dst = num_planes(dst_fmt);
            let np_src = num_planes(src_fmt);
            for p in 0..np_dst {
                // mirrors planarCopyWrapper: `if (plane == 1 && !dst[2]) continue;`
                if p == 1 && dst[2].is_null() {
                    continue;
                }
                let (pw, _ph, bps) = plane_dims(dst_fmt, p, w, h_all);
                let sub = if p == 0 { 0 } else { chroma_sub(dst_fmt).1 };
                let r0 = y0 >> sub;
                let r1 = (y1 + (1 << sub) - 1) >> sub;
                let ph = r1 - r0;
                let n = pw * bps;
                if p < np_src && !src[p].is_null() && !(p == 1 && src[2].is_null()) {
                    copy_rows(
                        src[p].offset(r0 as isize * ss[p] as isize),
                        ss[p] as isize,
                        dst[p].offset(r0 as isize * ds[p] as isize),
                        ds[p] as isize,
                        n,
                        ph,
                    );
                } else {
                    for y in r0..r1 {
                        std::ptr::write_bytes(dst[p].offset(y as isize * ds[p] as isize), 128, n);
                    }
                }
            }
        }
        Fast::Rgb2Rgb => rgb2rgb(src_fmt, dst_fmt, w, y0, y1, src[0], ss[0], dst[0], ds[0]),
        Fast::Yuv2RgbNearest => {
            yuv2rgb_nearest(src_fmt, dst_fmt, w, y0, y1, src, ss, dst[0], ds[0])
        }
        Fast::Bgr24ToYv12 => bgr24_to_yv12(w, y0, y1, src[0], ss[0], dst, ds),
        Fast::GrayToRgb => {
            for y in y0..y1 {
                crate::neon::gray_to_rgb(
                    dst_fmt,
                    src[0].offset(y as isize * ss[0] as isize),
                    dst[0].offset(y as isize * ds[0] as isize),
                    w,
                );
            }
        }
        Fast::PlanarToNv => {
            copy_rows(
                src[0].offset(y0 as isize * ss[0] as isize),
                ss[0] as isize,
                dst[0].offset(y0 as isize * ds[0] as isize),
                ds[0] as isize,
                w,
                h,
            );
            let cw = (w + 1) >> 1;
            let swap = dst_fmt == NV21;
            for y in (y0 >> 1)..((y1 + 1) >> 1) {
                let u = src[1].offset(y as isize * ss[1] as isize);
                let v = src[2].offset(y as isize * ss[2] as isize);
                let d = dst[1].offset(y as isize * ds[1] as isize);
                if swap {
                    crate::neon::interleave_neon(v, u, d, cw);
                } else {
                    crate::neon::interleave_neon(u, v, d, cw);
                }
            }
        }
        Fast::NvToPlanar => {
            copy_rows(
                src[0].offset(y0 as isize * ss[0] as isize),
                ss[0] as isize,
                dst[0].offset(y0 as isize * ds[0] as isize),
                ds[0] as isize,
                w,
                h,
            );
            let cw = (w + 1) >> 1;
            let swap = src_fmt == NV21;
            for y in (y0 >> 1)..((y1 + 1) >> 1) {
                let s = src[1].offset(y as isize * ss[1] as isize);
                let u = dst[1].offset(y as isize * ds[1] as isize);
                let v = dst[2].offset(y as isize * ds[2] as isize);
                if swap {
                    crate::simd::deinterleave(s, v, u, cw);
                } else {
                    crate::simd::deinterleave(s, u, v, cw);
                }
            }
        }
        _ => {}
    }
}

pub unsafe fn rgb2rgb(
    sf: i32,
    df: i32,
    w: usize,
    y0: usize,
    y1: usize,
    src: *const u8,
    ss: i32,
    dst: *mut u8,
    ds: i32,
) {
    let sb = bpp(sf);
    let db = bpp(df);
    let swap = matches!(sf, RGB24 | RGBA) != matches!(df, RGB24 | RGBA);
    for y in y0..y1 {
        let s = src.offset(y as isize * ss as isize);
        let d = dst.offset(y as isize * ds as isize);
        crate::neon::rgb_shuffle(s, d, w, sb, db, swap);
    }
}

pub unsafe fn yuv2rgb_nearest(
    sf: i32,
    df: i32,
    w: usize,
    y0: usize,
    y1: usize,
    src: &[*const u8; 4],
    ss: &[i32; 4],
    dst: *mut u8,
    ds: i32,
) {
    let yuv422 = sf == YUV422P;
    let n = w >> 1;
    let step = bpp(df);
    let mut y = y0;
    while y + 1 < y1 {
        let py1 = src[0].offset(y as isize * ss[0] as isize);
        let py2 = py1.offset(ss[0] as isize);
        let crow = if yuv422 { y } else { y >> 1 };
        let pu1 = src[1].offset(crow as isize * ss[1] as isize);
        let pv1 = src[2].offset(crow as isize * ss[2] as isize);
        let (pu2, pv2) = if yuv422 {
            (pu1.offset(ss[1] as isize), pv1.offset(ss[2] as isize))
        } else {
            (pu1, pv1)
        };
        let d1 = dst.offset(y as isize * ds as isize);
        let d2 = d1.offset(ds as isize);
        crate::neon::yuv2rgb_row2(&CF_LIMITED, df, py1, py2, pu1, pv1, pu2, pv2, d1, d2, n, step);
        y += 2;
    }
}

pub unsafe fn bgr24_to_yv12(
    w: usize,
    y0: usize,
    y1: usize,
    src: *const u8,
    ss: i32,
    dst: &[*mut u8; 4],
    ds: &[i32; 4],
) {
    let cw = w >> 1;
    let mut y = y0;
    while y + 1 < y1 {
        let s1 = src.offset(y as isize * ss as isize);
        let s2 = s1.offset(ss as isize);
        let y1 = dst[0].offset(y as isize * ds[0] as isize);
        let y2 = y1.offset(ds[0] as isize);
        let u = dst[1].offset((y >> 1) as isize * ds[1] as isize);
        let v = dst[2].offset((y >> 1) as isize * ds[2] as isize);
        crate::neon::bgr24_to_yv12_neon(s1, s2, y1, y2, u, v, cw);
        let _ = 0;
        for i in 0..0 {
            let b11 = *s1.add(6 * i) as i32;
            let g11 = *s1.add(6 * i + 1) as i32;
            let r11 = *s1.add(6 * i + 2) as i32;
            let b12 = *s1.add(6 * i + 3) as i32;
            let g12 = *s1.add(6 * i + 4) as i32;
            let r12 = *s1.add(6 * i + 5) as i32;
            let b21 = *s2.add(6 * i) as i32;
            let g21 = *s2.add(6 * i + 1) as i32;
            let r21 = *s2.add(6 * i + 2) as i32;
            let b22 = *s2.add(6 * i + 3) as i32;
            let g22 = *s2.add(6 * i + 4) as i32;
            let r22 = *s2.add(6 * i + 5) as i32;

            *y1.add(2 * i) = (((RY * r11 + GY * g11 + BY * b11) >> 15) + 16) as u8;
            *y1.add(2 * i + 1) = (((RY * r12 + GY * g12 + BY * b12) >> 15) + 16) as u8;
            *y2.add(2 * i) = (((RY * r21 + GY * g21 + BY * b21) >> 15) + 16) as u8;
            *y2.add(2 * i + 1) = (((RY * r22 + GY * g22 + BY * b22) >> 15) + 16) as u8;

            let bx = (b11 + b12 + b21 + b22) >> 2;
            let gx = (g11 + g12 + g21 + g22) >> 2;
            let rx = (r11 + r12 + r21 + r22) >> 2;
            *u.add(i) = (((RU * rx + GU * gx + BU * bx) >> 15) + 128) as u8;
            *v.add(i) = (((RV * rx + GV * gx + BV * bx) >> 15) + 128) as u8;
        }
        y += 2;
    }
}

#[inline(always)]
pub unsafe fn yuv2rgb_pair(
    cf: &Cf,
    df: i32,
    d: *mut u8,
    i: usize,
    step: usize,
    y1: i32,
    y2: i32,
    u: i32,
    v: i32,
) {
    let (kr, kg, kb) = rgb_bases(cf, u, v);
    let p = d.add(2 * i * step);
    match df {
        RGB24 => {
            *p = ytab(cf, kr, y1);
            *p.add(1) = ytab(cf, kg, y1);
            *p.add(2) = ytab(cf, kb, y1);
            *p.add(3) = ytab(cf, kr, y2);
            *p.add(4) = ytab(cf, kg, y2);
            *p.add(5) = ytab(cf, kb, y2);
        }
        BGR24 => {
            *p = ytab(cf, kb, y1);
            *p.add(1) = ytab(cf, kg, y1);
            *p.add(2) = ytab(cf, kr, y1);
            *p.add(3) = ytab(cf, kb, y2);
            *p.add(4) = ytab(cf, kg, y2);
            *p.add(5) = ytab(cf, kr, y2);
        }
        RGBA => {
            *p = ytab(cf, kr, y1);
            *p.add(1) = ytab(cf, kg, y1);
            *p.add(2) = ytab(cf, kb, y1);
            *p.add(3) = 255;
            *p.add(4) = ytab(cf, kr, y2);
            *p.add(5) = ytab(cf, kg, y2);
            *p.add(6) = ytab(cf, kb, y2);
            *p.add(7) = 255;
        }
        _ => {
            *p = ytab(cf, kb, y1);
            *p.add(1) = ytab(cf, kg, y1);
            *p.add(2) = ytab(cf, kr, y1);
            *p.add(3) = 255;
            *p.add(4) = ytab(cf, kb, y2);
            *p.add(5) = ytab(cf, kg, y2);
            *p.add(6) = ytab(cf, kr, y2);
            *p.add(7) = 255;
        }
    }
}
