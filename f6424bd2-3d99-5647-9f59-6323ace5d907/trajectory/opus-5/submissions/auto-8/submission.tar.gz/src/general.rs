//! Faithful re-implementation of FFmpeg's general (scaled) swscale pipeline:
//!   input format conversion -> horizontal scale to 15-bit -> vertical scale + output.

use crate::colors::*;
use crate::filter::*;
use crate::fmt::*;
use crate::simd;

/// Filter coefficients are read-only and identical for every worker.
pub struct Filters {
    pub hl: Filter,
    pub hc: Filter,
    pub vl: Filter,
    pub vc: Filter,
}

pub struct General {
    pub src_w: usize,
    pub src_h: usize,
    pub dst_w: usize,
    pub dst_h: usize,
    pub src_fmt: i32,
    pub dst_fmt: i32,
    pub cd_h: u32,
    pub cd_v: u32,
    pub cs_h: u32,
    pub cs_v: u32,
    pub chr_src_w: usize,
    pub chr_src_h: usize,
    pub chr_dst_w: usize,
    pub chr_dst_h: usize,
    pub full_chr: bool,
    pub needs_hc: bool,
    pub cf: Cf,
    pub range_mode: i32, // 0 = none, 1 = limited->full, 2 = full->limited
    pub alpha: bool,
    /// 0 = go through the 15-bit pipeline, 1 = row copy, 2 = point gather.
    lum_direct: u8,
    chr_direct: u8,
    /// packed-RGB output can read 8-bit luma straight from the source row
    lum_u8: bool,
    /// ...and 8-bit chroma straight from an interleaved NV12/NV21 plane
    chr_nv_u8: bool,
    /// full-chroma packed-RGB output straight off three 8-bit planes
    full_u8: bool,
    /// RGB source written straight into 8-bit planar luma / chroma
    lum_rgb8: bool,
    chr_rgb8: bool,

    pub f: std::sync::Arc<Filters>,

    lstride: usize,
    lring: usize,
    lum: Vec<i16>,
    alp: Vec<i16>,
    lrow: Vec<i32>,

    cstride: usize,
    cring: usize,
    chr: Vec<i16>, // slot layout: [slot][0=U,1=V][cstride]
    crow: Vec<i32>,

    pad8: Vec<u8>,
    pad8b: Vec<u8>,
    tmp16: Vec<i16>,
    tmp16u: Vec<i16>,
    tmp16v: Vec<i16>,
    srcs: Vec<*const i16>,
    srcs2: Vec<*const i16>,
    srcs3: Vec<*const i16>,
    srcs4: Vec<*const i16>,
}

#[inline(always)]
fn align16(x: usize) -> usize {
    (x + 15) & !15
}

impl General {
    pub fn new(
        src_w: usize,
        src_h: usize,
        src_fmt: i32,
        dst_w: usize,
        dst_h: usize,
        dst_fmt: i32,
        algo: i32,
    ) -> General {
        let (mut cs_h, cs_v) = chroma_sub(src_fmt);
        let (mut cd_h, cd_v) = chroma_sub(dst_fmt);

        // FULL_CHR_H_INT decision uses the *descriptor* chroma subsampling
        let mut full_chr = false;
        if is_rgb(dst_fmt) {
            if dst_w & 1 != 0 {
                full_chr = true;
            }
            if cs_h == 0 && cs_v == 0 {
                full_chr = true;
            }
        }
        if is_rgb(dst_fmt) && !full_chr {
            cd_h = 1;
        }
        // "drop every other pixel for chroma calculation" for RGB input
        if is_rgb(src_fmt) && ((dst_w >> cd_h) <= (src_w >> 1)) {
            cs_h = 1;
        }

        let chr_src_w = (src_w + (1 << cs_h) - 1) >> cs_h;
        let chr_src_h = (src_h + (1 << cs_v) - 1) >> cs_v;
        let chr_dst_w = (dst_w + (1 << cd_h) - 1) >> cd_h;
        let chr_dst_h = (dst_h + (1 << cd_v) - 1) >> cd_v;

        let lum_x_inc = (((src_w as i64) << 16) + (dst_w as i64 >> 1)) / dst_w as i64;
        let lum_y_inc = (((src_h as i64) << 16) + (dst_h as i64 >> 1)) / dst_h as i64;
        let chr_x_inc =
            (((chr_src_w as i64) << 16) + (chr_dst_w as i64 >> 1)) / chr_dst_w.max(1) as i64;
        let chr_y_inc =
            (((chr_src_h as i64) << 16) + (chr_dst_h as i64 >> 1)) / chr_dst_h.max(1) as i64;

        let lp = get_local_pos(0);
        let hl = init_filter(lum_x_inc, src_w, dst_w, 1 << 14, algo, lp, lp);
        let hc = init_filter(
            chr_x_inc,
            chr_src_w.max(1),
            chr_dst_w.max(1),
            1 << 14,
            algo,
            get_local_pos(cs_h),
            get_local_pos(cd_h),
        );
        let vl = init_filter(lum_y_inc, src_h, dst_h, 1 << 12, algo, lp, lp);
        let vc = init_filter(
            chr_y_inc,
            chr_src_h.max(1),
            chr_dst_h.max(1),
            1 << 12,
            algo,
            get_local_pos(cs_v),
            get_local_pos(cd_v),
        );

        let needs_hc = !(is_gray(src_fmt) || is_gray(dst_fmt));
        let src_range = is_gray(src_fmt);
        let dst_range = is_gray(dst_fmt);
        let cf = if src_range { CF_FULL } else { CF_LIMITED };
        let range_mode = if src_range != dst_range && !is_rgb(dst_fmt) {
            if src_range {
                2
            } else {
                1
            }
        } else {
            0
        };
        let alpha = matches!(src_fmt, RGBA | BGRA) && matches!(dst_fmt, RGBA | BGRA);

        // When the pipeline degenerates to `dst = src` (unit vertical tap, unit
        // horizontal weights, no range conversion) the 15-bit round trip can be
        // replaced by a plain copy or a byte gather.
        let planar_dst = !is_rgb(dst_fmt);
        let planar_src = !is_rgb(src_fmt);
        let direct = |fh: &Filter, fv: &Filter| -> u8 {
            if !planar_dst || !planar_src || range_mode != 0 || fv.size != 1 {
                0
            } else if fh.identity {
                1
            } else if fh.point {
                2
            } else {
                0
            }
        };
        let lum_direct = direct(&hl, &vl);
        // The packed-RGB single-tap path can take luma straight from the source
        // plane; other output modes still need the 15-bit ring.
        let mut lum_u8 = planar_src
            && !planar_dst
            && !full_chr
            && range_mode == 0
            && hl.identity
            && vl.size == 1
            && (vc.size == 1 || vc.size == 2);
        if lum_u8 && vc.size == 2 {
            // every row must hit the two-tap `yuv2packed1` case, otherwise the
            // fallback would need the 15-bit ring we are about to skip
            for y in 0..chr_dst_h {
                let c0 = vc.coeffs[y * 2] as u16 as i32;
                let c1 = vc.coeffs[y * 2 + 1] as u16 as i32;
                if c0 + c1 != 4096 || c1 > 4096 {
                    lum_u8 = false;
                    break;
                }
            }
        }
        let chr_direct = if is_semi_planar(dst_fmt)
            || is_gray(dst_fmt)
            || is_semi_planar(src_fmt)
            || is_gray(src_fmt)
            || !needs_hc
        {
            0
        } else {
            direct(&hc, &vc)
        };

        let chr_nv_u8 = lum_u8 && is_semi_planar(src_fmt) && hc.identity && chr_dst_w == chr_src_w;
        // YUV444P-style sources with unit filters everywhere feed the full-chroma
        // writer directly from the three 8-bit planes.
        let full_u8 = full_chr
            && planar_src
            && !planar_dst
            && !is_semi_planar(src_fmt)
            && needs_hc
            && range_mode == 0
            && hl.identity
            && hc.identity
            && vl.size == 1
            && vc.size == 1;

        // RGB -> planar YUV with unit filters: convert straight to 8 bits.
        let rgb_src = is_rgb(src_fmt);
        let lum_rgb8 = rgb_src && planar_dst && range_mode == 0 && hl.identity && vl.size == 1;
        let chr_rgb8 = lum_rgb8
            && !is_semi_planar(dst_fmt)
            && !is_gray(dst_fmt)
            && needs_hc
            && hc.identity
            && vc.size == 1;

        let lstride = align16(dst_w) + 16;
        let lring = vl.size.max(1);
        let cstride = align16(chr_dst_w) + 16;
        let cring = vc.size.max(1);

        let mut chr = vec![0i16; cring * 2 * cstride];
        if !needs_hc {
            for v in chr.iter_mut() {
                *v = 1 << 14;
            }
        }

        let maxf = hl
            .size_p
            .max(hc.size_p)
            .max(hl.max_read.saturating_sub(src_w))
            .max(hc.max_read.saturating_sub(chr_src_w));
        let pad_len = src_w.max(chr_src_w) + 4 * maxf + 128;
        let sz = hl.size.max(hc.size).max(vl.size).max(vc.size) + 4;

        General {
            src_w,
            src_h,
            dst_w,
            dst_h,
            src_fmt,
            dst_fmt,
            cd_h,
            cd_v,
            cs_h,
            cs_v,
            chr_src_w,
            chr_src_h,
            chr_dst_w,
            chr_dst_h,
            full_chr,
            needs_hc,
            cf,
            range_mode,
            alpha,
            lum_direct,
            chr_direct,
            lum_u8,
            chr_nv_u8,
            full_u8,
            lum_rgb8,
            chr_rgb8,
            f: std::sync::Arc::new(Filters { hl, hc, vl, vc }),
            lstride,
            lring,
            lum: vec![0i16; lring * lstride],
            alp: vec![0i16; if alpha { lring * lstride } else { 0 }],
            lrow: vec![-1; lring],
            cstride,
            cring,
            chr,
            crow: vec![-1; cring],
            pad8: vec![0u8; pad_len],
            pad8b: vec![0u8; pad_len],
            tmp16: vec![0i16; pad_len],
            tmp16u: vec![0i16; pad_len],
            tmp16v: vec![0i16; pad_len],
            srcs: vec![std::ptr::null(); sz],
            srcs2: vec![std::ptr::null(); sz],
            srcs3: vec![std::ptr::null(); sz],
            srcs4: vec![std::ptr::null(); sz],
        }
    }

    /// A per-worker copy: filters are shared, scratch buffers are private.
    pub fn clone_worker(&self) -> General {
        General {
            f: self.f.clone(),
            lum: vec![0i16; self.lum.len()],
            alp: vec![0i16; self.alp.len()],
            lrow: vec![-1; self.lrow.len()],
            chr: self.chr.clone(),
            crow: vec![-1; self.crow.len()],
            pad8: vec![0u8; self.pad8.len()],
            pad8b: vec![0u8; self.pad8b.len()],
            tmp16: vec![0i16; self.tmp16.len()],
            tmp16u: vec![0i16; self.tmp16u.len()],
            tmp16v: vec![0i16; self.tmp16v.len()],
            srcs: self.srcs.clone(),
            srcs2: self.srcs2.clone(),
            srcs3: self.srcs3.clone(),
            srcs4: self.srcs4.clone(),
            src_w: self.src_w,
            src_h: self.src_h,
            dst_w: self.dst_w,
            dst_h: self.dst_h,
            src_fmt: self.src_fmt,
            dst_fmt: self.dst_fmt,
            cd_h: self.cd_h,
            cd_v: self.cd_v,
            cs_h: self.cs_h,
            cs_v: self.cs_v,
            chr_src_w: self.chr_src_w,
            chr_src_h: self.chr_src_h,
            chr_dst_w: self.chr_dst_w,
            chr_dst_h: self.chr_dst_h,
            full_chr: self.full_chr,
            needs_hc: self.needs_hc,
            cf: self.cf,
            range_mode: self.range_mode,
            alpha: self.alpha,
            lum_direct: self.lum_direct,
            chr_direct: self.chr_direct,
            lum_u8: self.lum_u8,
            chr_nv_u8: self.chr_nv_u8,
            full_u8: self.full_u8,
            lum_rgb8: self.lum_rgb8,
            chr_rgb8: self.chr_rgb8,
            lstride: self.lstride,
            lring: self.lring,
            cstride: self.cstride,
            cring: self.cring,
        }
    }

    pub unsafe fn process_band(
        &mut self,
        src: &[*const u8; 4],
        ss: &[i32; 4],
        dst: &[*mut u8; 4],
        ds: &[i32; 4],
        y0: usize,
        y1: usize,
    ) {
        for v in self.lrow.iter_mut() {
            *v = -1;
        }
        for v in self.crow.iter_mut() {
            *v = -1;
        }

        let cd_v = self.cd_v;
        let vl_size = self.f.vl.size;
        let vc_size = self.f.vc.size;
        let chr_mask = (1usize << cd_v) - 1;
        let dst_planar = !is_rgb(self.dst_fmt);
        let has_chroma_out = dst_planar && !is_gray(self.dst_fmt);
        let need_chroma = !dst_planar || has_chroma_out;
        let chr_dst_h = self.chr_dst_h;
        let needs_hc = self.needs_hc;

        for dst_y in y0..y1 {
            let lp = self.f.vl.pos[dst_y] as usize;
            if self.lum_direct == 0
                && !(self.lum_u8 && !dst_planar)
                && !self.full_u8
                && !self.lum_rgb8
            {
                for k in 0..vl_size {
                    self.ensure_lum(lp + k, src, ss);
                }
            }

            let cdy = dst_y >> cd_v;
            let do_chr = need_chroma && (dst_y & chr_mask) == 0;
            let mut cp = 0usize;
            if do_chr {
                cp = self.f.vc.pos[cdy.min(chr_dst_h - 1)] as usize;
                if needs_hc
                    && self.chr_direct == 0
                    && !self.chr_nv_u8
                    && !self.full_u8
                    && !self.chr_rgb8
                {
                    for k in 0..vc_size {
                        self.ensure_chr(cp + k, src, ss);
                    }
                }
            }

            if dst_planar {
                self.out_planar_direct(dst_y, cdy, lp, cp, do_chr, src, ss, dst, ds);
            } else {
                self.out_packed(dst_y, lp, cp, src, ss, dst, ds);
            }
        }
    }

    #[inline]
    fn lum_slot(&self, row: usize) -> usize {
        row % self.lring
    }
    #[inline]
    fn chr_slot(&self, row: usize) -> usize {
        row % self.cring
    }

    unsafe fn ensure_lum(&mut self, row: usize, src: &[*const u8; 4], ss: &[i32; 4]) {
        let row = row.min(self.src_h - 1);
        let slot = self.lum_slot(row);
        if self.lrow[slot] == row as i32 {
            return;
        }
        self.lrow[slot] = row as i32;
        let dst_w = self.dst_w;
        let base = slot * self.lstride;
        let sp: *const u8 = src[0].add(row * ss[0] as usize);

        if is_rgb(self.src_fmt) {
            let n = self.src_w;
            let f = &self.f.hl;
            if f.identity {
                // fold the unit horizontal scaler into the input conversion
                simd::rgb_to_y16::<true>(
                    self.src_fmt,
                    sp,
                    self.lum.as_mut_ptr().add(base),
                    dst_w,
                );
                if self.alpha {
                    simd::rgba_to_a16(self.src_fmt, sp, self.tmp16.as_mut_ptr(), n);
                    for i in 0..dst_w {
                        self.alp[base + i] =
                            ((self.tmp16[i] as i32 * 2).min(32767)) as i16;
                    }
                }
                match self.range_mode {
                    1 => lum_range_to_jpeg(self.lum.as_mut_ptr().add(base), dst_w),
                    2 => lum_range_from_jpeg(self.lum.as_mut_ptr().add(base), dst_w),
                    _ => {}
                }
                return;
            }
            simd::rgb_to_y16::<false>(self.src_fmt, sp, self.tmp16.as_mut_ptr(), n);
            let safe = f.max_read.max(n) + f.size_p;
            for i in n..safe {
                self.tmp16[i] = 0;
            }
            hscale16to15(
                &mut self.lum[base..base + dst_w],
                dst_w,
                self.tmp16.as_ptr(),
                f,
                safe,
            );
            if self.alpha {
                simd::rgba_to_a16(self.src_fmt, sp, self.tmp16.as_mut_ptr(), n);
                for i in n..safe {
                    self.tmp16[i] = 0;
                }
                hscale16to15(
                    &mut self.alp[base..base + dst_w],
                    dst_w,
                    self.tmp16.as_ptr(),
                    f,
                    safe,
                );
            }
        } else {
            let n = self.src_w;
            let f = &self.f.hl;
            let (p, safe) = if f.max_read > n {
                let lim = f.max_read + f.size_p;
                std::ptr::copy_nonoverlapping(sp, self.pad8.as_mut_ptr(), n);
                for i in n..lim {
                    self.pad8[i] = 0;
                }
                (self.pad8.as_ptr(), lim)
            } else {
                (sp, n)
            };
            hscale8to15(&mut self.lum[base..base + dst_w], dst_w, p, f, safe);
        }
        match self.range_mode {
            1 => lum_range_to_jpeg(self.lum.as_mut_ptr().add(base), dst_w),
            2 => lum_range_from_jpeg(self.lum.as_mut_ptr().add(base), dst_w),
            _ => {}
        }
    }

    unsafe fn ensure_chr(&mut self, row: usize, src: &[*const u8; 4], ss: &[i32; 4]) {
        let row = row.min(self.chr_src_h - 1);
        let slot = self.chr_slot(row);
        if self.crow[slot] == row as i32 {
            return;
        }
        self.crow[slot] = row as i32;
        let cdw = self.chr_dst_w;
        let cbase = slot * 2 * self.cstride;
        let csw = self.chr_src_w;
        let f_max = self.f.hc.max_read;

        match self.src_fmt {
            RGB24 | BGR24 | RGBA | BGRA if self.f.hc.identity => {
                let sp: *const u8 = src[0].add(row * ss[0] as usize);
                let (a, b) = self.chr.split_at_mut(cbase + self.cstride);
                simd::rgb_to_uv16::<true>(
                    self.src_fmt,
                    sp,
                    a.as_mut_ptr().add(cbase),
                    b.as_mut_ptr(),
                    cdw,
                    self.cs_h == 1,
                    self.src_w,
                );
                match self.range_mode {
                    1 => {
                        chr_range_to_jpeg(self.chr.as_mut_ptr().add(cbase), cdw);
                        chr_range_to_jpeg(self.chr.as_mut_ptr().add(cbase + self.cstride), cdw);
                    }
                    2 => {
                        chr_range_from_jpeg(self.chr.as_mut_ptr().add(cbase), cdw);
                        chr_range_from_jpeg(self.chr.as_mut_ptr().add(cbase + self.cstride), cdw);
                    }
                    _ => {}
                }
                return;
            }
            RGB24 | BGR24 | RGBA | BGRA => {
                let sp: *const u8 = src[0].add(row * ss[0] as usize);
                simd::rgb_to_uv16::<false>(
                    self.src_fmt,
                    sp,
                    self.tmp16u.as_mut_ptr(),
                    self.tmp16v.as_mut_ptr(),
                    csw,
                    self.cs_h == 1,
                    self.src_w,
                );
                let safe = f_max.max(csw) + self.f.hc.size_p;
                for i in csw..safe {
                    self.tmp16u[i] = 0;
                    self.tmp16v[i] = 0;
                }
                let (a, b) = self.chr.split_at_mut(cbase + self.cstride);
                hscale16to15(
                    &mut a[cbase..cbase + cdw],
                    cdw,
                    self.tmp16u.as_ptr(),
                    &self.f.hc,
                    safe,
                );
                hscale16to15(&mut b[0..cdw], cdw, self.tmp16v.as_ptr(), &self.f.hc, safe);
            }
            NV12 | NV21 => {
                let sp: *const u8 = src[1].add(row * ss[1] as usize);
                let (du, dv) = if self.src_fmt == NV12 {
                    (self.pad8.as_mut_ptr(), self.pad8b.as_mut_ptr())
                } else {
                    (self.pad8b.as_mut_ptr(), self.pad8.as_mut_ptr())
                };
                simd::deinterleave(sp, du, dv, csw);
                let safe = f_max.max(csw) + self.f.hc.size_p;
                for i in csw..safe {
                    *self.pad8.as_mut_ptr().add(i) = 0;
                    *self.pad8b.as_mut_ptr().add(i) = 0;
                }
                let (a, b) = self.chr.split_at_mut(cbase + self.cstride);
                hscale8to15(
                    &mut a[cbase..cbase + cdw],
                    cdw,
                    self.pad8.as_ptr(),
                    &self.f.hc,
                    safe,
                );
                hscale8to15(&mut b[0..cdw], cdw, self.pad8b.as_ptr(), &self.f.hc, safe);
            }
            _ => {
                let up: *const u8 = src[1].add(row * ss[1] as usize);
                let vp: *const u8 = src[2].add(row * ss[2] as usize);
                let (pu, pv, safe) = if f_max > csw {
                    let lim = f_max + self.f.hc.size_p;
                    std::ptr::copy_nonoverlapping(up, self.pad8.as_mut_ptr(), csw);
                    std::ptr::copy_nonoverlapping(vp, self.pad8b.as_mut_ptr(), csw);
                    for i in csw..lim {
                        self.pad8[i] = 0;
                        self.pad8b[i] = 0;
                    }
                    (self.pad8.as_ptr(), self.pad8b.as_ptr(), lim)
                } else {
                    (up, vp, csw)
                };
                let (a, b) = self.chr.split_at_mut(cbase + self.cstride);
                hscale8to15(&mut a[cbase..cbase + cdw], cdw, pu, &self.f.hc, safe);
                hscale8to15(&mut b[0..cdw], cdw, pv, &self.f.hc, safe);
            }
        }
        match self.range_mode {
            1 => {
                chr_range_to_jpeg(self.chr.as_mut_ptr().add(cbase), cdw);
                chr_range_to_jpeg(self.chr.as_mut_ptr().add(cbase + self.cstride), cdw);
            }
            2 => {
                chr_range_from_jpeg(self.chr.as_mut_ptr().add(cbase), cdw);
                chr_range_from_jpeg(self.chr.as_mut_ptr().add(cbase + self.cstride), cdw);
            }
            _ => {}
        }
    }

    unsafe fn out_planar_direct(
        &mut self,
        dst_y: usize,
        cdy: usize,
        lp: usize,
        cp: usize,
        do_chr: bool,
        src: &[*const u8; 4],
        ss: &[i32; 4],
        dst: &[*mut u8; 4],
        ds: &[i32; 4],
    ) {
        if self.lum_rgb8 {
            let sp = src[0].add(lp.min(self.src_h - 1) * ss[0] as usize);
            simd::rgb_to_y8(
                self.src_fmt,
                sp,
                dst[0].add(dst_y * ds[0] as usize),
                self.dst_w,
            );
            if do_chr && self.chr_rgb8 {
                let cs = src[0].add(cp.min(self.chr_src_h - 1) * ss[0] as usize);
                simd::rgb_to_uv8(
                    self.src_fmt,
                    cs,
                    dst[1].add(cdy * ds[1] as usize),
                    dst[2].add(cdy * ds[2] as usize),
                    self.chr_dst_w,
                    self.cs_h == 1,
                    self.src_w,
                );
            }
            if !do_chr || self.chr_rgb8 {
                return;
            }
            self.out_planar(dst_y, cdy, lp, cp, false, true, dst, ds);
            return;
        }
        if self.lum_direct != 0 {
            let srow = lp.min(self.src_h - 1);
            let sp = src[0].add(srow * ss[0] as usize);
            let dp = dst[0].add(dst_y * ds[0] as usize);
            if self.lum_direct == 1 {
                std::ptr::copy_nonoverlapping(sp, dp, self.dst_w);
            } else {
                crate::neon::gather_point(sp, dp, self.dst_w, &self.f.hl);
            }
        }
        if do_chr && self.chr_direct != 0 {
            let srow = cp.min(self.chr_src_h - 1);
            let cw = self.chr_dst_w;
            for (pl, off) in [(1usize, 1usize), (2, 2)] {
                let sp = src[off].add(srow * ss[off] as usize);
                let dp = dst[pl].add(cdy * ds[pl] as usize);
                if self.chr_direct == 1 {
                    std::ptr::copy_nonoverlapping(sp, dp, cw);
                } else {
                    crate::neon::gather_point(sp, dp, cw, &self.f.hc);
                }
            }
        }
        let need_lum = self.lum_direct == 0;
        let need_chr = do_chr && self.chr_direct == 0;
        if need_lum || need_chr {
            self.out_planar(dst_y, cdy, lp, cp, need_lum, need_chr, dst, ds);
        }
    }

    unsafe fn out_planar(
        &mut self,
        dst_y: usize,
        cdy: usize,
        lp: usize,
        cp: usize,
        do_lum: bool,
        do_chr: bool,
        dst: &[*mut u8; 4],
        ds: &[i32; 4],
    ) {
        let dst_w = self.dst_w;
        let dp = dst[0].add(dst_y * ds[0] as usize);
        if !do_lum {
        } else if self.f.vl.size == 1 {
            let slot = self.lum_slot(lp.min(self.src_h - 1));
            simd::yuv2plane1(self.lum.as_ptr().add(slot * self.lstride), dp, dst_w);
        } else {
            let n = self.f.vl.size;
            for k in 0..n {
                let slot = self.lum_slot((lp + k).min(self.src_h - 1));
                self.srcs[k] = self.lum.as_ptr().add(slot * self.lstride);
            }
            let f = &self.f.vl.coeffs[dst_y * n..dst_y * n + n];
            simd::yuv2plane_x(f, &self.srcs[0..n], dp, dst_w);
        }

        if !do_chr {
            return;
        }
        let cdw = self.chr_dst_w;
        let n = self.f.vc.size;
        for k in 0..n {
            let slot = self.chr_slot((cp + k).min(self.chr_src_h - 1));
            self.srcs2[k] = self.chr.as_ptr().add(slot * 2 * self.cstride);
            self.srcs3[k] = self.chr.as_ptr().add(slot * 2 * self.cstride + self.cstride);
        }
        let f = &self.f.vc.coeffs[cdy * n..cdy * n + n];

        if is_semi_planar(self.dst_fmt) {
            let dpc = dst[1].add(cdy * ds[1] as usize);
            simd::yuv2nv12cx(
                self.dst_fmt == NV21,
                f,
                &self.srcs2[0..n],
                &self.srcs3[0..n],
                dpc,
                cdw,
            );
        } else {
            let du = dst[1].add(cdy * ds[1] as usize);
            let dv = dst[2].add(cdy * ds[2] as usize);
            if n == 1 {
                simd::yuv2plane1(self.srcs2[0], du, cdw);
                simd::yuv2plane1(self.srcs3[0], dv, cdw);
            } else {
                simd::yuv2plane_x(f, &self.srcs2[0..n], du, cdw);
                simd::yuv2plane_x(f, &self.srcs3[0..n], dv, cdw);
            }
        }
    }

    unsafe fn out_packed(
        &mut self,
        dst_y: usize,
        lp: usize,
        cp: usize,
        src: &[*const u8; 4],
        ss: &[i32; 4],
        dst: &[*mut u8; 4],
        ds: &[i32; 4],
    ) {
        let dst_w = self.dst_w;
        let dp = dst[0].add(dst_y * ds[0] as usize);
        let ln = self.f.vl.size;
        let cn = self.f.vc.size;
        for k in 0..ln {
            let slot = self.lum_slot((lp + k).min(self.src_h - 1));
            self.srcs[k] = self.lum.as_ptr().add(slot * self.lstride);
        }
        for k in 0..cn {
            let slot = self.chr_slot((cp + k).min(self.chr_src_h - 1));
            self.srcs2[k] = self.chr.as_ptr().add(slot * 2 * self.cstride);
            self.srcs3[k] = self.chr.as_ptr().add(slot * 2 * self.cstride + self.cstride);
        }
        for k in 0..ln {
            let slot = self.lum_slot((lp + k).min(self.src_h - 1));
            self.srcs4[k] = if self.alpha {
                self.alp.as_ptr().add(slot * self.lstride)
            } else {
                std::ptr::null()
            };
        }
        let lf = &self.f.vl.coeffs[dst_y * ln..dst_y * ln + ln];
        let chf = &self.f.vc.coeffs[dst_y * cn..dst_y * cn + cn];
        let cf = &self.cf;

        // dispatch mirroring packed_vscale()
        let mode1 = ln == 1 && cn == 1;
        let mode1b = ln == 1
            && cn == 2
            && (chf[0] as u16 as i32 + chf[1] as u16 as i32) == 4096
            && (chf[1] as u16 as i32) <= 4096;
        let mode2 = ln == 2
            && cn == 2
            && (lf[0] as u16 as i32 + lf[1] as u16 as i32) == 4096
            && (lf[1] as u16 as i32) <= 4096
            && (chf[0] as u16 as i32 + chf[1] as u16 as i32) == 4096
            && (chf[1] as u16 as i32) <= 4096;
        let u1 = if cn > 1 { self.srcs2[1] } else { self.srcs2[0] };
        let v1 = if cn > 1 { self.srcs3[1] } else { self.srcs3[0] };

        if self.full_u8 {
            simd::rgb_full_1_u8(
                cf,
                self.dst_fmt,
                src[0].add(lp.min(self.src_h - 1) * ss[0] as usize),
                src[1].add(cp.min(self.chr_src_h - 1) * ss[1] as usize),
                src[2].add(cp.min(self.chr_src_h - 1) * ss[2] as usize),
                dp,
                dst_w,
            );
            return;
        }
        if self.full_chr {
            if mode1 || mode1b {
                let uvalpha = if mode1 { 0 } else { chf[1] as u16 as i32 };
                simd::rgb_full_1(
                    cf,
                    self.dst_fmt,
                    self.srcs[0],
                    self.srcs2[0],
                    u1,
                    self.srcs3[0],
                    v1,
                    self.srcs4[0],
                    dp,
                    dst_w,
                    uvalpha,
                );
            } else if mode2 {
                simd::rgb_full_2(
                    cf,
                    self.dst_fmt,
                    self.srcs[0],
                    self.srcs[1],
                    self.srcs2[0],
                    self.srcs2[1],
                    self.srcs3[0],
                    self.srcs3[1],
                    self.srcs4[0],
                    self.srcs4[1],
                    dp,
                    dst_w,
                    lf[1] as u16 as i32,
                    chf[1] as u16 as i32,
                );
            } else {
                simd::rgb_full_x(
                    cf,
                    self.dst_fmt,
                    lf,
                    &self.srcs[0..ln],
                    chf,
                    &self.srcs2[0..cn],
                    &self.srcs3[0..cn],
                    if self.alpha { &self.srcs4[0..ln] } else { &[] },
                    dp,
                    dst_w,
                );
            }
        } else if mode1 || mode1b {
            let uvalpha = if mode1 { 0 } else { chf[1] as u16 as i32 };
            if self.chr_nv_u8 {
                let yp = src[0].add(lp.min(self.src_h - 1) * ss[0] as usize);
                let c0 = cp.min(self.chr_src_h - 1);
                let c1 = (cp + 1).min(self.chr_src_h - 1);
                simd::rgb_1_nv(
                    cf,
                    self.dst_fmt,
                    yp,
                    src[1].add(c0 * ss[1] as usize),
                    src[1].add(c1 * ss[1] as usize),
                    self.src_fmt == NV21,
                    uvalpha >= 2048,
                    dp,
                    dst_w,
                );
                return;
            }
            if self.lum_u8 {
                let yp = src[0].add(lp.min(self.src_h - 1) * ss[0] as usize);
                simd::rgb_1_u8(
                    cf,
                    self.dst_fmt,
                    yp,
                    self.srcs2[0],
                    u1,
                    self.srcs3[0],
                    v1,
                    dp,
                    dst_w,
                    uvalpha,
                );
                return;
            }
            simd::rgb_1(
                cf,
                self.dst_fmt,
                self.srcs[0],
                self.srcs2[0],
                u1,
                self.srcs3[0],
                v1,
                dp,
                dst_w,
                uvalpha,
            );
        } else if mode2 {
            simd::rgb_2(
                cf,
                self.dst_fmt,
                self.srcs[0],
                self.srcs[1],
                self.srcs2[0],
                self.srcs2[1],
                self.srcs3[0],
                self.srcs3[1],
                dp,
                dst_w,
                lf[1] as u16 as i32,
                chf[1] as u16 as i32,
            );
        } else {
            simd::rgb_x(
                cf,
                self.dst_fmt,
                lf,
                &self.srcs[0..ln],
                chf,
                &self.srcs2[0..cn],
                &self.srcs3[0..cn],
                dp,
                dst_w,
            );
        }
    }
}

// ── horizontal scalers ───────────────────────────────────────────────────────

pub unsafe fn hscale8to15(dst: &mut [i16], dst_w: usize, src: *const u8, f: &Filter, src_w: usize) {
    if f.identity {
        simd::widen_shl7(src, dst.as_mut_ptr(), dst_w);
        return;
    }
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::hscale8to15_neon(dst.as_mut_ptr(), dst_w, src, f, src_w);
        return;
    }
    #[allow(unreachable_code)]
    let sz = f.size;
    let co = f.coeffs.as_ptr();
    let po = f.pos.as_ptr();
    for i in 0..dst_w {
        let p = *po.add(i) as usize;
        let mut val = 0i32;
        let c = co.add(i * sz);
        for j in 0..sz {
            val += *src.add(p + j) as i32 * *c.add(j) as i32;
        }
        *dst.get_unchecked_mut(i) = (val >> 7).min(32767) as i16;
    }
}

pub unsafe fn hscale16to15(dst: &mut [i16], dst_w: usize, src: *const i16, f: &Filter, src_w: usize) {
    if f.identity {
        for i in 0..dst_w {
            *dst.get_unchecked_mut(i) = ((*src.add(i) as i32 * 2).min(32767)) as i16;
        }
        return;
    }
    #[cfg(target_arch = "aarch64")]
    {
        crate::neon::hscale16to15_neon(dst.as_mut_ptr(), dst_w, src, f, src_w);
        return;
    }
    #[allow(unreachable_code)]
    let sz = f.size;
    let co = f.coeffs.as_ptr();
    let po = f.pos.as_ptr();
    for i in 0..dst_w {
        let p = *po.add(i) as usize;
        let mut val = 0i32;
        let c = co.add(i * sz);
        for j in 0..sz {
            val += *src.add(p + j) as i32 * *c.add(j) as i32;
        }
        *dst.get_unchecked_mut(i) = (val >> 13).min(32767) as i16;
    }
}
