//! AArch64 NEON kernels.
#![cfg(target_arch = "aarch64")]

use crate::colors::*;
use crate::fmt::*;
use std::arch::aarch64::*;

#[inline]
pub unsafe fn widen_shl7_neon(src: *const u8, dst: *mut i16, n: usize) {
    let mut i = 0usize;
    while i + 16 <= n {
        let v = vld1q_u8(src.add(i));
        let lo = vshll_n_u8(vget_low_u8(v), 7);
        let hi = vshll_high_n_u8(v, 7);
        vst1q_s16(dst.add(i), vreinterpretq_s16_u16(lo));
        vst1q_s16(dst.add(i + 8), vreinterpretq_s16_u16(hi));
        i += 16;
    }
    while i < n {
        *dst.add(i) = (*src.add(i) as i16) << 7;
        i += 1;
    }
}

#[inline]
pub unsafe fn deinterleave_neon(src: *const u8, du: *mut u8, dv: *mut u8, n: usize) {
    let mut i = 0usize;
    while i + 16 <= n {
        let v = vld2q_u8(src.add(2 * i));
        vst1q_u8(du.add(i), v.0);
        vst1q_u8(dv.add(i), v.1);
        i += 16;
    }
    while i < n {
        *du.add(i) = *src.add(2 * i);
        *dv.add(i) = *src.add(2 * i + 1);
        i += 1;
    }
}

#[inline(always)]
unsafe fn load_rgb8(fmt: i32, src: *const u8, i: usize) -> (uint8x8_t, uint8x8_t, uint8x8_t) {
    match fmt {
        RGB24 => {
            let v = vld3_u8(src.add(i * 3));
            (v.0, v.1, v.2)
        }
        BGR24 => {
            let v = vld3_u8(src.add(i * 3));
            (v.2, v.1, v.0)
        }
        RGBA => {
            let v = vld4_u8(src.add(i * 4));
            (v.0, v.1, v.2)
        }
        _ => {
            let v = vld4_u8(src.add(i * 4));
            (v.2, v.1, v.0)
        }
    }
}

/// 8 pixels: (c0*r + c1*g + c2*b + rnd) >> 9  → i16
#[inline(always)]
unsafe fn dot3_shr9(
    r: uint8x8_t,
    g: uint8x8_t,
    b: uint8x8_t,
    c0: i32,
    c1: i32,
    c2: i32,
    rnd: i32,
) -> int16x8_t {
    let r16 = vreinterpretq_s16_u16(vmovl_u8(r));
    let g16 = vreinterpretq_s16_u16(vmovl_u8(g));
    let b16 = vreinterpretq_s16_u16(vmovl_u8(b));
    let acc_lo = vdupq_n_s32(rnd);
    let acc_hi = vdupq_n_s32(rnd);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(r16), c0 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, r16, c0 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(g16), c1 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, g16, c1 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(b16), c2 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, b16, c2 as i16);
    vcombine_s16(vshrn_n_s32(acc_lo, 9), vshrn_n_s32(acc_hi, 9))
}

#[inline(always)]
unsafe fn load_rgb16(fmt: i32, src: *const u8, i: usize) -> (uint8x16_t, uint8x16_t, uint8x16_t) {
    match fmt {
        RGB24 => {
            let v = vld3q_u8(src.add(i * 3));
            (v.0, v.1, v.2)
        }
        BGR24 => {
            let v = vld3q_u8(src.add(i * 3));
            (v.2, v.1, v.0)
        }
        RGBA => {
            let v = vld4q_u8(src.add(i * 4));
            (v.0, v.1, v.2)
        }
        _ => {
            let v = vld4q_u8(src.add(i * 4));
            (v.2, v.1, v.0)
        }
    }
}

pub unsafe fn rgb_to_y16_neon(fmt: i32, src: *const u8, dst: *mut i16, n: usize) {
    const RND: i32 = (32 << 14) + (1 << 8);
    let mut i = 0usize;
    while i + 16 <= n {
        let (r, g, b) = load_rgb16(fmt, src, i);
        vst1q_s16(
            dst.add(i),
            dot3_shr9(vget_low_u8(r), vget_low_u8(g), vget_low_u8(b), RY, GY, BY, RND),
        );
        vst1q_s16(
            dst.add(i + 8),
            dot3_shr9(
                vget_high_u8(r),
                vget_high_u8(g),
                vget_high_u8(b),
                RY,
                GY,
                BY,
                RND,
            ),
        );
        i += 16;
    }
    while i + 8 <= n {
        let (r, g, b) = load_rgb8(fmt, src, i);
        vst1q_s16(dst.add(i), dot3_shr9(r, g, b, RY, GY, BY, RND));
        i += 8;
    }
    if i < n {
        let step = bpp(fmt);
        let (ro, go, bo) = rgb_order(fmt);
        while i < n {
            let p = src.add(i * step);
            let r = *p.add(ro) as i32;
            let g = *p.add(go) as i32;
            let b = *p.add(bo) as i32;
            *dst.add(i) = ((RY * r + GY * g + BY * b + RND) >> 9) as i16;
            i += 1;
        }
    }
}

pub unsafe fn rgb_to_uv16_neon(
    fmt: i32,
    src: *const u8,
    du: *mut i16,
    dv: *mut i16,
    n: usize,
    half: bool,
    src_w: usize,
) {
    let step = bpp(fmt);
    let (ro, go, bo) = rgb_order(fmt);
    if !half {
        const RND: i32 = (256 << 14) + (1 << 8);
        let mut i = 0usize;
        while i + 16 <= n {
            let (r, g, b) = load_rgb16(fmt, src, i);
            let (rl, gl, bl) = (vget_low_u8(r), vget_low_u8(g), vget_low_u8(b));
            let (rh, gh, bh) = (vget_high_u8(r), vget_high_u8(g), vget_high_u8(b));
            vst1q_s16(du.add(i), dot3_shr9(rl, gl, bl, RU, GU, BU, RND));
            vst1q_s16(du.add(i + 8), dot3_shr9(rh, gh, bh, RU, GU, BU, RND));
            vst1q_s16(dv.add(i), dot3_shr9(rl, gl, bl, RV, GV, BV, RND));
            vst1q_s16(dv.add(i + 8), dot3_shr9(rh, gh, bh, RV, GV, BV, RND));
            i += 16;
        }
        while i + 8 <= n {
            let (r, g, b) = load_rgb8(fmt, src, i);
            vst1q_s16(du.add(i), dot3_shr9(r, g, b, RU, GU, BU, RND));
            vst1q_s16(dv.add(i), dot3_shr9(r, g, b, RV, GV, BV, RND));
            i += 8;
        }
        while i < n {
            let p = src.add(i * step);
            let r = *p.add(ro) as i32;
            let g = *p.add(go) as i32;
            let b = *p.add(bo) as i32;
            *du.add(i) = ((RU * r + GU * g + BU * b + RND) >> 9) as i16;
            *dv.add(i) = ((RV * r + GV * g + BV * b + RND) >> 9) as i16;
            i += 1;
        }
    } else {
        const RND: i32 = (256 << 15) + (1 << 9);
        let mut i = 0usize;
        if 2 * n <= src_w {
            while i + 8 <= n {
                let (r0, g0, b0, r1, g1, b1) = load_rgb_pairs8(fmt, src, i);
                let rs = vaddl_u8(r0, r1);
                let gs = vaddl_u8(g0, g1);
                let bs = vaddl_u8(b0, b1);
                vst1q_s16(du.add(i), dot3_shr10_u16(rs, gs, bs, RU, GU, BU, RND));
                vst1q_s16(dv.add(i), dot3_shr10_u16(rs, gs, bs, RV, GV, BV, RND));
                i += 8;
            }
        }
        while i < n {
            let i0 = 2 * i;
            let i1 = if 2 * i + 1 < src_w { 2 * i + 1 } else { i0 };
            let p0 = src.add(i0 * step);
            let p1 = src.add(i1 * step);
            let r = *p0.add(ro) as i32 + *p1.add(ro) as i32;
            let g = *p0.add(go) as i32 + *p1.add(go) as i32;
            let b = *p0.add(bo) as i32 + *p1.add(bo) as i32;
            *du.add(i) = ((RU * r + GU * g + BU * b + RND) >> 10) as i16;
            *dv.add(i) = ((RV * r + GV * g + BV * b + RND) >> 10) as i16;
            i += 1;
        }
    }
}

/// Load 16 consecutive pixels as 8 even/odd pairs.
#[inline(always)]
unsafe fn load_rgb_pairs8(
    fmt: i32,
    src: *const u8,
    i: usize,
) -> (uint8x8_t, uint8x8_t, uint8x8_t, uint8x8_t, uint8x8_t, uint8x8_t) {
    match fmt {
        RGB24 | BGR24 => {
            let v = vld3q_u8(src.add(i * 6));
            let (a, bq, c) = (v.0, v.1, v.2);
            // de-interleave even/odd pixels
            let ae = vuzp1q_u8(a, a);
            let ao = vuzp2q_u8(a, a);
            let be = vuzp1q_u8(bq, bq);
            let bo = vuzp2q_u8(bq, bq);
            let ce = vuzp1q_u8(c, c);
            let co = vuzp2q_u8(c, c);
            if fmt == RGB24 {
                (
                    vget_low_u8(ae),
                    vget_low_u8(be),
                    vget_low_u8(ce),
                    vget_low_u8(ao),
                    vget_low_u8(bo),
                    vget_low_u8(co),
                )
            } else {
                (
                    vget_low_u8(ce),
                    vget_low_u8(be),
                    vget_low_u8(ae),
                    vget_low_u8(co),
                    vget_low_u8(bo),
                    vget_low_u8(ao),
                )
            }
        }
        _ => {
            let v = vld4q_u8(src.add(i * 8));
            let (a, bq, c) = if fmt == RGBA {
                (v.0, v.1, v.2)
            } else {
                (v.2, v.1, v.0)
            };
            let ae = vuzp1q_u8(a, a);
            let ao = vuzp2q_u8(a, a);
            let be = vuzp1q_u8(bq, bq);
            let bo = vuzp2q_u8(bq, bq);
            let ce = vuzp1q_u8(c, c);
            let co = vuzp2q_u8(c, c);
            (
                vget_low_u8(ae),
                vget_low_u8(be),
                vget_low_u8(ce),
                vget_low_u8(ao),
                vget_low_u8(bo),
                vget_low_u8(co),
            )
        }
    }
}

#[inline(always)]
unsafe fn dot3_shr10_u16(
    r: uint16x8_t,
    g: uint16x8_t,
    b: uint16x8_t,
    c0: i32,
    c1: i32,
    c2: i32,
    rnd: i32,
) -> int16x8_t {
    let r16 = vreinterpretq_s16_u16(r);
    let g16 = vreinterpretq_s16_u16(g);
    let b16 = vreinterpretq_s16_u16(b);
    let acc_lo = vdupq_n_s32(rnd);
    let acc_hi = vdupq_n_s32(rnd);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(r16), c0 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, r16, c0 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(g16), c1 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, g16, c1 as i16);
    let acc_lo = vmlal_n_s16(acc_lo, vget_low_s16(b16), c2 as i16);
    let acc_hi = vmlal_high_n_s16(acc_hi, b16, c2 as i16);
    vcombine_s16(vshrn_n_s32(acc_lo, 10), vshrn_n_s32(acc_hi, 10))
}

pub unsafe fn yuv2plane1_neon(src: *const i16, dst: *mut u8, n: usize) {
    let mut i = 0usize;
    let bias = vdupq_n_s16(64);
    while i + 16 <= n {
        let a = vqaddq_s16(vld1q_s16(src.add(i)), bias);
        let b = vqaddq_s16(vld1q_s16(src.add(i + 8)), bias);
        let r = vcombine_u8(vqshrun_n_s16(a, 7), vqshrun_n_s16(b, 7));
        vst1q_u8(dst.add(i), r);
        i += 16;
    }
    while i < n {
        *dst.add(i) = clip_u8((*src.add(i) as i32 + 64) >> 7);
        i += 1;
    }
}

#[inline(always)]
unsafe fn plane_x_n<const FS: usize>(f: &[i16], srcs: &[*const i16], dst: *mut u8, n: usize) {
    let mut fc = [0i16; FS];
    let mut sp = [std::ptr::null::<i16>(); FS];
    for j in 0..FS {
        fc[j] = f[j];
        sp[j] = srcs[j];
    }
    let mut i = 0usize;
    while i + 8 <= n {
        let mut lo = vdupq_n_s32(64 << 12);
        let mut hi = vdupq_n_s32(64 << 12);
        for j in 0..FS {
            let v = vld1q_s16(sp[j].add(i));
            lo = vmlal_n_s16(lo, vget_low_s16(v), fc[j]);
            hi = vmlal_high_n_s16(hi, v, fc[j]);
        }
        let s = vcombine_s16(vshrn_n_s32(lo, 16), vshrn_n_s32(hi, 16));
        vst1_u8(dst.add(i), vqshrun_n_s16(s, 3));
        i += 8;
    }
    while i < n {
        let mut val: i32 = 64 << 12;
        for j in 0..FS {
            val += *sp[j].add(i) as i32 * fc[j] as i32;
        }
        *dst.add(i) = clip_u8(val >> 19);
        i += 1;
    }
}

pub unsafe fn yuv2plane_x_neon(f: &[i16], srcs: &[*const i16], dst: *mut u8, n: usize) {
    match f.len() {
        2 => return plane_x_n::<2>(f, srcs, dst, n),
        3 => return plane_x_n::<3>(f, srcs, dst, n),
        4 => return plane_x_n::<4>(f, srcs, dst, n),
        5 => return plane_x_n::<5>(f, srcs, dst, n),
        6 => return plane_x_n::<6>(f, srcs, dst, n),
        8 => return plane_x_n::<8>(f, srcs, dst, n),
        _ => {}
    }
    let fs = f.len();
    let fp = f.as_ptr();
    let sp = srcs.as_ptr();
    let mut i = 0usize;
    while i + 8 <= n {
        let mut lo = vdupq_n_s32(64 << 12);
        let mut hi = vdupq_n_s32(64 << 12);
        for j in 0..fs {
            let v = vld1q_s16((*sp.add(j)).add(i));
            lo = vmlal_n_s16(lo, vget_low_s16(v), *fp.add(j));
            hi = vmlal_high_n_s16(hi, v, *fp.add(j));
        }
        let s = vcombine_s16(vshrn_n_s32(lo, 16), vshrn_n_s32(hi, 16));
        vst1_u8(dst.add(i), vqshrun_n_s16(s, 3));
        i += 8;
    }
    while i < n {
        let mut val: i32 = 64 << 12;
        for j in 0..fs {
            val += *(*sp.add(j)).add(i) as i32 * *fp.add(j) as i32;
        }
        *dst.add(i) = clip_u8(val >> 19);
        i += 1;
    }
}

// ── packed RGB, half-res chroma ──────────────────────────────────────────────

pub unsafe fn interleave_neon(a: *const u8, b: *const u8, dst: *mut u8, n: usize) {
    let mut i = 0usize;
    while i + 16 <= n {
        let v = uint8x16x2_t(vld1q_u8(a.add(i)), vld1q_u8(b.add(i)));
        vst2q_u8(dst.add(2 * i), v);
        i += 16;
    }
    while i < n {
        *dst.add(2 * i) = *a.add(i);
        *dst.add(2 * i + 1) = *b.add(i);
        i += 1;
    }
}

const fn idx43(swap: bool) -> [u8; 48] {
    let mut t = [0u8; 48];
    let mut j = 0;
    while j < 48 {
        let px = j / 3;
        let c = j % 3;
        t[j] = (px * 4 + if swap { 2 - c } else { c }) as u8;
        j += 1;
    }
    t
}

const fn idx34(swap: bool) -> [u8; 64] {
    let mut t = [0u8; 64];
    let mut j = 0;
    while j < 64 {
        let px = j / 4;
        let c = j % 4;
        t[j] = if c == 3 {
            255
        } else {
            (px * 3 + if swap { 2 - c } else { c }) as u8
        };
        j += 1;
    }
    t
}

const fn idx33() -> [u8; 48] {
    let mut t = [0u8; 48];
    let mut j = 0;
    while j < 48 {
        t[j] = (j - j % 3 + (2 - j % 3)) as u8;
        j += 1;
    }
    t
}

const fn idx_g3() -> [u8; 48] {
    let mut t = [0u8; 48];
    let mut j = 0;
    while j < 48 {
        t[j] = (j / 3) as u8;
        j += 1;
    }
    t
}

const fn idx_g4() -> [u8; 64] {
    let mut t = [0u8; 64];
    let mut j = 0;
    while j < 64 {
        t[j] = if j % 4 == 3 { 255 } else { (j / 4) as u8 };
        j += 1;
    }
    t
}

static I43: [[u8; 48]; 2] = [idx43(false), idx43(true)];
static I34: [[u8; 64]; 2] = [idx34(false), idx34(true)];
static I33: [u8; 48] = idx33();
static IG3: [u8; 48] = idx_g3();
static IG4: [u8; 64] = idx_g4();

/// Packed RGB channel shuffle / width conversion.
pub unsafe fn rgb_shuffle(src: *const u8, dst: *mut u8, n: usize, sb: usize, db: usize, swap: bool) {
    let mut i = 0usize;
    if sb == 3 && db == 3 {
        if swap {
            let ip = I33.as_ptr();
            while i + 16 <= n {
                let p = src.add(i * 3);
                let t = uint8x16x3_t(vld1q_u8(p), vld1q_u8(p.add(16)), vld1q_u8(p.add(32)));
                let q = dst.add(i * 3);
                for k in 0..3 {
                    vst1q_u8(q.add(k * 16), vqtbl3q_u8(t, vld1q_u8(ip.add(k * 16))));
                }
                i += 16;
            }
        } else {
            std::ptr::copy_nonoverlapping(src, dst, n * 3);
            return;
        }
    } else if sb == 3 && db == 4 {
        let ip = I34[swap as usize].as_ptr();
        let amask = vreinterpretq_u8_u32(vdupq_n_u32(0xFF00_0000));
        while i + 16 <= n {
            let p = src.add(i * 3);
            let t = uint8x16x3_t(vld1q_u8(p), vld1q_u8(p.add(16)), vld1q_u8(p.add(32)));
            let q = dst.add(i * 4);
            for k in 0..4 {
                vst1q_u8(
                    q.add(k * 16),
                    vorrq_u8(vqtbl3q_u8(t, vld1q_u8(ip.add(k * 16))), amask),
                );
            }
            i += 16;
        }
    } else if sb == 4 && db == 3 {
        let ip = I43[swap as usize].as_ptr();
        while i + 16 <= n {
            let p = src.add(i * 4);
            let t = uint8x16x4_t(
                vld1q_u8(p),
                vld1q_u8(p.add(16)),
                vld1q_u8(p.add(32)),
                vld1q_u8(p.add(48)),
            );
            let q = dst.add(i * 3);
            for k in 0..3 {
                vst1q_u8(q.add(k * 16), vqtbl4q_u8(t, vld1q_u8(ip.add(k * 16))));
            }
            i += 16;
        }
    } else {
        if !swap {
            std::ptr::copy_nonoverlapping(src, dst, n * 4);
            return;
        }
        // R<->B inside each 32-bit pixel is a pure byte permutation
        const SW: [u8; 16] = [2, 1, 0, 3, 6, 5, 4, 7, 10, 9, 8, 11, 14, 13, 12, 15];
        let idx = vld1q_u8(SW.as_ptr());
        while i + 16 <= n {
            let p = src.add(i * 4);
            let q = dst.add(i * 4);
            vst1q_u8(q, vqtbl1q_u8(vld1q_u8(p), idx));
            vst1q_u8(q.add(16), vqtbl1q_u8(vld1q_u8(p.add(16)), idx));
            vst1q_u8(q.add(32), vqtbl1q_u8(vld1q_u8(p.add(32)), idx));
            vst1q_u8(q.add(48), vqtbl1q_u8(vld1q_u8(p.add(48)), idx));
            i += 16;
        }
    }
    while i < n {
        let s = src.add(i * sb);
        let d = dst.add(i * db);
        let (c0, c1, c2) = (*s, *s.add(1), *s.add(2));
        if swap {
            *d = c2;
            *d.add(1) = c1;
            *d.add(2) = c0;
        } else {
            *d = c0;
            *d.add(1) = c1;
            *d.add(2) = c2;
        }
        if db == 4 {
            *d.add(3) = if sb == 4 { *s.add(3) } else { 255 };
        }
        i += 1;
    }
}

// ── YUV -> packed RGB core ───────────────────────────────────────────────────

/// Per-chroma-sample constant terms for 8 chroma samples (already 0..255 clamped).
#[inline(always)]
unsafe fn kbases8(cf: &Cf, u: uint16x8_t, v: uint16x8_t) -> [int32x4_t; 6] {
    kbases8_i32(
        cf,
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(u))),
        vreinterpretq_s32_u32(vmovl_high_u16(u)),
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(v))),
        vreinterpretq_s32_u32(vmovl_high_u16(v)),
    )
}

#[inline(always)]
unsafe fn kbases8_i32(
    cf: &Cf,
    ul: int32x4_t,
    uh: int32x4_t,
    vl: int32x4_t,
    vh: int32x4_t,
) -> [int32x4_t; 6] {
    let cy = cf.cy;
    [
        vmlaq_n_s32(
            vdupq_n_s32(cf.kr0),
            vshrq_n_s32(vmulq_n_s32(vl, cf.tcrv), 16),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kr0),
            vshrq_n_s32(vmulq_n_s32(vh, cf.tcrv), 16),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kg0),
            vaddq_s32(
                vshrq_n_s32(vmulq_n_s32(ul, cf.tcgu), 16),
                vshrq_n_s32(vmulq_n_s32(vl, cf.tcgv), 16),
            ),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kg0),
            vaddq_s32(
                vshrq_n_s32(vmulq_n_s32(uh, cf.tcgu), 16),
                vshrq_n_s32(vmulq_n_s32(vh, cf.tcgv), 16),
            ),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kb0),
            vshrq_n_s32(vmulq_n_s32(ul, cf.tcbu), 16),
            cy,
        ),
        vmlaq_n_s32(
            vdupq_n_s32(cf.kb0),
            vshrq_n_s32(vmulq_n_s32(uh, cf.tcbu), 16),
            cy,
        ),
    ]
}

#[inline(always)]
unsafe fn widen_y(y: uint8x16_t) -> [int32x4_t; 4] {
    let lo = vmovl_u8(vget_low_u8(y));
    let hi = vmovl_high_u8(y);
    [
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(lo))),
        vreinterpretq_s32_u32(vmovl_high_u16(lo)),
        vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(hi))),
        vreinterpretq_s32_u32(vmovl_high_u16(hi)),
    ]
}

/// Expand the 8 per-chroma bases to 16 per-pixel lanes (each base covers 2 pixels).
#[inline(always)]
unsafe fn kdup(k: &[int32x4_t; 6]) -> [int32x4_t; 12] {
    let mut o = [vdupq_n_s32(0); 12];
    for c in 0..3 {
        let (a, b) = (k[2 * c], k[2 * c + 1]);
        o[4 * c] = vzip1q_s32(a, a);
        o[4 * c + 1] = vzip2q_s32(a, a);
        o[4 * c + 2] = vzip1q_s32(b, b);
        o[4 * c + 3] = vzip2q_s32(b, b);
    }
    o
}

/// One output channel for 16 pixels.
#[inline(always)]
unsafe fn chan16(kd: &[int32x4_t; 12], c: usize, y: &[int32x4_t; 4], cy: i32) -> uint8x16_t {
    let r0 = vmlaq_n_s32(kd[4 * c], y[0], cy);
    let r1 = vmlaq_n_s32(kd[4 * c + 1], y[1], cy);
    let r2 = vmlaq_n_s32(kd[4 * c + 2], y[2], cy);
    let r3 = vmlaq_n_s32(kd[4 * c + 3], y[3], cy);
    let lo = vshrn_high_n_s32(vshrn_n_s32(r0, 16), r1, 16);
    let hi = vshrn_high_n_s32(vshrn_n_s32(r2, 16), r3, 16);
    vqmovun_high_s16(vqmovun_s16(lo), hi)
}

#[inline(always)]
unsafe fn store_rgb16(fmt: i32, d: *mut u8, r: uint8x16_t, g: uint8x16_t, b: uint8x16_t) {
    match fmt {
        RGB24 => vst3q_u8(d, uint8x16x3_t(r, g, b)),
        BGR24 => vst3q_u8(d, uint8x16x3_t(b, g, r)),
        RGBA => vst4q_u8(d, uint8x16x4_t(r, g, b, vdupq_n_u8(255))),
        _ => vst4q_u8(d, uint8x16x4_t(b, g, r, vdupq_n_u8(255))),
    }
}

/// Emits 16 pixels from packed chroma bases + 16 luma samples.
#[inline(always)]
unsafe fn emit16(cf: &Cf, fmt: i32, k: &[int32x4_t; 6], yv: uint8x16_t, d: *mut u8) {
    emit16d(cf, fmt, &kdup(k), yv, d)
}

#[inline(always)]
unsafe fn emit16d(cf: &Cf, fmt: i32, kd: &[int32x4_t; 12], yv: uint8x16_t, d: *mut u8) {
    emit16y(cf, fmt, kd, &widen_y(yv), d)
}

/// Luma already in 32-bit lanes (the vertical filter output), so no round trip
/// through 8-bit — which also avoids clamping Y before the colour transform.
#[inline(always)]
unsafe fn emit16y(cf: &Cf, fmt: i32, kd: &[int32x4_t; 12], y: &[int32x4_t; 4], d: *mut u8) {
    let r = chan16(kd, 0, y, cf.cy);
    let g = chan16(kd, 1, y, cf.cy);
    let b = chan16(kd, 2, y, cf.cy);
    store_rgb16(fmt, d, r, g, b);
}

pub unsafe fn yuv2rgb_row2(
    cf: &Cf,
    df: i32,
    py1: *const u8,
    py2: *const u8,
    pu1: *const u8,
    pv1: *const u8,
    pu2: *const u8,
    pv2: *const u8,
    d1: *mut u8,
    d2: *mut u8,
    n: usize,
    step: usize,
) {
    let same = pu1 == pu2;
    let mut i = 0usize;
    while i + 8 <= n {
        let u = vmovl_u8(vld1_u8(pu1.add(i)));
        let v = vmovl_u8(vld1_u8(pv1.add(i)));
        let k = kdup(&kbases8(cf, u, v));
        emit16d(cf, df, &k, vld1q_u8(py1.add(2 * i)), d1.add(2 * i * step));
        if same {
            emit16d(cf, df, &k, vld1q_u8(py2.add(2 * i)), d2.add(2 * i * step));
        } else {
            let u2 = vmovl_u8(vld1_u8(pu2.add(i)));
            let v2 = vmovl_u8(vld1_u8(pv2.add(i)));
            let k2 = kbases8(cf, u2, v2);
            emit16(cf, df, &k2, vld1q_u8(py2.add(2 * i)), d2.add(2 * i * step));
        }
        i += 8;
    }
    while i < n {
        crate::fast::yuv2rgb_pair(
            cf,
            df,
            d1,
            i,
            step,
            *py1.add(2 * i) as i32,
            *py1.add(2 * i + 1) as i32,
            *pu1.add(i) as i32,
            *pv1.add(i) as i32,
        );
        crate::fast::yuv2rgb_pair(
            cf,
            df,
            d2,
            i,
            step,
            *py2.add(2 * i) as i32,
            *py2.add(2 * i + 1) as i32,
            *pu2.add(i) as i32,
            *pv2.add(i) as i32,
        );
        i += 1;
    }
}

/// (a[i] + b[i] + 128) >> 8, clamped to 0..255 — the two-row chroma average
/// `yuv2packed1` uses when the vertical filter has two taps.
#[inline(always)]
unsafe fn chroma_avg8(a: *const i16, b: *const i16) -> uint16x8_t {
    let x = vld1q_s16(a);
    let y = vld1q_s16(b);
    let r = vdupq_n_s32(128);
    let lo = vshrq_n_s32(
        vaddq_s32(
            vaddq_s32(vmovl_s16(vget_low_s16(x)), vmovl_s16(vget_low_s16(y))),
            r,
        ),
        8,
    );
    let hi = vshrq_n_s32(vaddq_s32(vaddq_s32(vmovl_high_s16(x), vmovl_high_s16(y)), r), 8);
    vminq_u16(
        vcombine_u16(vqmovun_s32(lo), vqmovun_s32(hi)),
        vdupq_n_u16(255),
    )
}

pub unsafe fn rgb_full_1_u8_neon(
    cf: &Cf,
    fmt: i32,
    yp: *const u8,
    up: *const u8,
    vp: *const u8,
    dst: *mut u8,
    w: usize,
) {
    let step = bpp(fmt);
    let alpha = vdupq_n_u8(255);
    let c128 = vdupq_n_s16(128);
    let mut i = 0usize;
    while i + 16 <= w {
        let y = vld1q_u8(yp.add(i));
        let u = vsubq_s16(
            vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(vld1q_u8(up.add(i))))),
            c128,
        );
        let uh = vsubq_s16(vreinterpretq_s16_u16(vmovl_high_u8(vld1q_u8(up.add(i)))), c128);
        let v = vsubq_s16(
            vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(vld1q_u8(vp.add(i))))),
            c128,
        );
        let vh = vsubq_s16(vreinterpretq_s16_u16(vmovl_high_u8(vld1q_u8(vp.add(i)))), c128);
        let yl = vmovl_u8(vget_low_u8(y));
        let yhh = vmovl_high_u8(y);
        let mut rr = [vdupq_n_s32(0); 4];
        let mut gg = [vdupq_n_s32(0); 4];
        let mut bb = [vdupq_n_s32(0); 4];
        let ys = [
            vshlq_n_s32(vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(yl))), 9),
            vshlq_n_s32(vreinterpretq_s32_u32(vmovl_high_u16(yl)), 9),
            vshlq_n_s32(vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(yhh))), 9),
            vshlq_n_s32(vreinterpretq_s32_u32(vmovl_high_u16(yhh)), 9),
        ];
        let us = [
            vshlq_n_s32(vmovl_s16(vget_low_s16(u)), 9),
            vshlq_n_s32(vmovl_high_s16(u), 9),
            vshlq_n_s32(vmovl_s16(vget_low_s16(uh)), 9),
            vshlq_n_s32(vmovl_high_s16(uh), 9),
        ];
        let vs = [
            vshlq_n_s32(vmovl_s16(vget_low_s16(v)), 9),
            vshlq_n_s32(vmovl_high_s16(v), 9),
            vshlq_n_s32(vmovl_s16(vget_low_s16(vh)), 9),
            vshlq_n_s32(vmovl_high_s16(vh), 9),
        ];
        for k in 0..4 {
            let o = full_rgb(cf, ys[k], us[k], vs[k]);
            rr[k] = o[0];
            gg[k] = o[1];
            bb[k] = o[2];
        }
        store_rgba16(
            fmt,
            dst.add(i * step),
            pack16(&rr),
            pack16(&gg),
            pack16(&bb),
            alpha,
        );
        i += 16;
    }
    while i < w {
        let y = (*yp.add(i) as i32) << 9;
        let u = (*up.add(i) as i32 - 128) << 9;
        let v = (*vp.add(i) as i32 - 128) << 9;
        crate::simd::write_full(cf, fmt, dst.add(i * step), y, u, v);
        i += 1;
    }
}

pub unsafe fn rgb_1_nv_neon(
    cf: &Cf,
    fmt: i32,
    yp: *const u8,
    uv0: *const u8,
    uv1: *const u8,
    swap: bool,
    two: bool,
    dst: *mut u8,
    n: usize,
) {
    let step = bpp(fmt);
    let mut i = 0usize;
    while i + 8 <= n {
        let a = vld2_u8(uv0.add(2 * i));
        let (mut u, mut v) = if swap { (a.1, a.0) } else { (a.0, a.1) };
        if two {
            let b = vld2_u8(uv1.add(2 * i));
            let (u1, v1) = if swap { (b.1, b.0) } else { (b.0, b.1) };
            u = vrhadd_u8(u, u1);
            v = vrhadd_u8(v, v1);
        }
        let k = kbases8(cf, vmovl_u8(u), vmovl_u8(v));
        emit16(cf, fmt, &k, vld1q_u8(yp.add(2 * i)), dst.add(2 * i * step));
        i += 8;
    }
    let (uo, vo) = if swap { (1usize, 0usize) } else { (0usize, 1usize) };
    while i < n {
        let y1 = *yp.add(2 * i) as i32;
        let y2 = *yp.add(2 * i + 1) as i32;
        let (u, v) = if two {
            (
                (*uv0.add(2 * i + uo) as i32 + *uv1.add(2 * i + uo) as i32 + 1) >> 1,
                (*uv0.add(2 * i + vo) as i32 + *uv1.add(2 * i + vo) as i32 + 1) >> 1,
            )
        } else {
            (*uv0.add(2 * i + uo) as i32, *uv0.add(2 * i + vo) as i32)
        };
        crate::fast::yuv2rgb_pair(cf, fmt, dst, i, step, y1, y2, u, v);
        i += 1;
    }
}

/// `yuv2packed1` with the luma read straight from an 8-bit source row.
pub unsafe fn rgb_1_u8_neon(
    cf: &Cf,
    fmt: i32,
    yp: *const u8,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    two: bool,
    dst: *mut u8,
    n: usize,
) {
    let step = bpp(fmt);
    let bias = vdupq_n_s16(64);
    let mut i = 0usize;
    if two {
        while i + 8 <= n {
            let k = kbases8(
                cf,
                chroma_avg8(ubuf0.add(i), ubuf1.add(i)),
                chroma_avg8(vbuf0.add(i), vbuf1.add(i)),
            );
            emit16(cf, fmt, &k, vld1q_u8(yp.add(2 * i)), dst.add(2 * i * step));
            i += 8;
        }
    } else {
        while i + 8 <= n {
            let uu = vqaddq_s16(vld1q_s16(ubuf0.add(i)), bias);
            let vv = vqaddq_s16(vld1q_s16(vbuf0.add(i)), bias);
            let k = kbases8(cf, vmovl_u8(vqshrun_n_s16(uu, 7)), vmovl_u8(vqshrun_n_s16(vv, 7)));
            emit16(cf, fmt, &k, vld1q_u8(yp.add(2 * i)), dst.add(2 * i * step));
            i += 8;
        }
    }
    while i < n {
        let y1 = *yp.add(2 * i) as i32;
        let y2 = *yp.add(2 * i + 1) as i32;
        let (u, v) = if two {
            (
                (*ubuf0.add(i) as i32 + *ubuf1.add(i) as i32 + 128) >> 8,
                (*vbuf0.add(i) as i32 + *vbuf1.add(i) as i32 + 128) >> 8,
            )
        } else {
            (
                (*ubuf0.add(i) as i32 + 64) >> 7,
                (*vbuf0.add(i) as i32 + 64) >> 7,
            )
        };
        crate::fast::yuv2rgb_pair(cf, fmt, dst, i, step, y1, y2, u, v);
        i += 1;
    }
}

/// `yuv2packed1`: 15-bit luma/chroma buffers, half-res chroma.
pub unsafe fn rgb_1_neon(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    two: bool,
    dst: *mut u8,
    n: usize,
) {
    let step = bpp(fmt);
    let bias = vdupq_n_s16(64);
    let mut i = 0usize;
    if two {
        while i + 8 <= n {
            let k = kbases8(
                cf,
                chroma_avg8(ubuf0.add(i), ubuf1.add(i)),
                chroma_avg8(vbuf0.add(i), vbuf1.add(i)),
            );
            let y0 = vqaddq_s16(vld1q_s16(buf0.add(2 * i)), bias);
            let y1 = vqaddq_s16(vld1q_s16(buf0.add(2 * i + 8)), bias);
            let yv = vcombine_u8(vqshrun_n_s16(y0, 7), vqshrun_n_s16(y1, 7));
            emit16(cf, fmt, &k, yv, dst.add(2 * i * step));
            i += 8;
        }
    } else {
        while i + 8 <= n {
            // 8 chroma samples -> 16 pixels
            let uu = vqaddq_s16(vld1q_s16(ubuf0.add(i)), bias);
            let vv = vqaddq_s16(vld1q_s16(vbuf0.add(i)), bias);
            let k = kbases8(cf, vmovl_u8(vqshrun_n_s16(uu, 7)), vmovl_u8(vqshrun_n_s16(vv, 7)));
            let y0 = vqaddq_s16(vld1q_s16(buf0.add(2 * i)), bias);
            let y1 = vqaddq_s16(vld1q_s16(buf0.add(2 * i + 8)), bias);
            let yv = vcombine_u8(vqshrun_n_s16(y0, 7), vqshrun_n_s16(y1, 7));
            emit16(cf, fmt, &k, yv, dst.add(2 * i * step));
            i += 8;
        }
    }
    while i < n {
        let y1 = (*buf0.add(2 * i) as i32 + 64) >> 7;
        let y2 = (*buf0.add(2 * i + 1) as i32 + 64) >> 7;
        let (u, v) = if two {
            (
                (*ubuf0.add(i) as i32 + *ubuf1.add(i) as i32 + 128) >> 8,
                (*vbuf0.add(i) as i32 + *vbuf1.add(i) as i32 + 128) >> 8,
            )
        } else {
            (
                (*ubuf0.add(i) as i32 + 64) >> 7,
                (*vbuf0.add(i) as i32 + 64) >> 7,
            )
        };
        crate::fast::yuv2rgb_pair(cf, fmt, dst, i, step, y1, y2, u, v);
        i += 1;
    }
}

// ── horizontal scalers ───────────────────────────────────────────────────────

#[inline(always)]
unsafe fn hsum4(a: int32x4_t, b: int32x4_t, c: int32x4_t, d: int32x4_t) -> int32x4_t {
    vpaddq_s32(vpaddq_s32(a, b), vpaddq_s32(c, d))
}

pub unsafe fn hscale8to15_neon(
    dst: *mut i16,
    dst_w: usize,
    src: *const u8,
    f: &crate::filter::Filter,
    src_w: usize,
) {
    let szp = f.size_p;
    let sz = f.size;
    let co = f.coeffs_p.as_ptr();
    let po = f.pos.as_ptr();
    let lim = vdupq_n_s32(32767);
    let mut i = 0usize;
    if f.point {
        // gather 16 samples per group straight out of a 64-byte window
        let gb = f.gbase.as_ptr();
        let gi = f.gidx.as_ptr();
        for g in 0..f.gbase.len() {
            let b = *gb.add(g);
            if b < 0 {
                break;
            }
            let p = src.add(b as usize);
            let t = uint8x16x4_t(
                vld1q_u8(p),
                vld1q_u8(p.add(16)),
                vld1q_u8(p.add(32)),
                vld1q_u8(p.add(48)),
            );
            let v = vqtbl4q_u8(t, vld1q_u8(gi.add(g * 16)));
            vst1q_s16(
                dst.add(g * 16),
                vreinterpretq_s16_u16(vshll_n_u8(vget_low_u8(v), 7)),
            );
            vst1q_s16(
                dst.add(g * 16 + 8),
                vreinterpretq_s16_u16(vshll_high_n_u8(v, 7)),
            );
            i = g * 16 + 16;
        }
        while i < dst_w {
            *dst.add(i) = (*src.add(*po.add(i) as usize) as i16) << 7;
            i += 1;
        }
        return;
    }
    if !f.coeffs_t.is_empty() {
        i = match sz {
            2 => hscale8_gather::<2>(dst, src, f),
            3 => hscale8_gather::<3>(dst, src, f),
            4 => hscale8_gather::<4>(dst, src, f),
            5 => hscale8_gather::<5>(dst, src, f),
            6 => hscale8_gather::<6>(dst, src, f),
            7 => hscale8_gather::<7>(dst, src, f),
            8 => hscale8_gather::<8>(dst, src, f),
            9 => hscale8_gather::<9>(dst, src, f),
            10 => hscale8_gather::<10>(dst, src, f),
            11 => hscale8_gather::<11>(dst, src, f),
            12 => hscale8_gather::<12>(dst, src, f),
            13 => hscale8_gather::<13>(dst, src, f),
            14 => hscale8_gather::<14>(dst, src, f),
            15 => hscale8_gather::<15>(dst, src, f),
            16 => hscale8_gather::<16>(dst, src, f),
            _ => 0,
        };
    }
    if i + 4 <= dst_w && szp == 4 {
        while i + 4 <= dst_w {
            let p0 = *po.add(i) as usize;
            let p3 = *po.add(i + 3) as usize;
            if p3 + 4 > src_w {
                break;
            }
            let p1 = *po.add(i + 1) as usize;
            let p2 = *po.add(i + 2) as usize;
            let a = vmull_s16(
                vget_low_s16(vreinterpretq_s16_u16(vmovl_u8(vld1_u8(src.add(p0))))),
                vld1_s16(co.add(i * 4)),
            );
            let b = vmull_s16(
                vget_low_s16(vreinterpretq_s16_u16(vmovl_u8(vld1_u8(src.add(p1))))),
                vld1_s16(co.add(i * 4 + 4)),
            );
            let c = vmull_s16(
                vget_low_s16(vreinterpretq_s16_u16(vmovl_u8(vld1_u8(src.add(p2))))),
                vld1_s16(co.add(i * 4 + 8)),
            );
            let d = vmull_s16(
                vget_low_s16(vreinterpretq_s16_u16(vmovl_u8(vld1_u8(src.add(p3))))),
                vld1_s16(co.add(i * 4 + 12)),
            );
            let s = vminq_s32(vshrq_n_s32(hsum4(a, b, c, d), 7), lim);
            vst1_s16(dst.add(i), vmovn_s32(s));
            i += 4;
        }
    } else if i + 4 <= dst_w {
        {
            i = match szp {
                8 => hscale8_taps::<8>(dst, dst_w, src, co, po, src_w, i),
                16 => hscale8_taps::<16>(dst, dst_w, src, co, po, src_w, i),
                24 => hscale8_taps::<24>(dst, dst_w, src, co, po, src_w, i),
                32 => hscale8_taps::<32>(dst, dst_w, src, co, po, src_w, i),
                40 => hscale8_taps::<40>(dst, dst_w, src, co, po, src_w, i),
                48 => hscale8_taps::<48>(dst, dst_w, src, co, po, src_w, i),
                _ => hscale8_generic(dst, dst_w, src, co, po, src_w, szp, i),
            };
        }
    }
    let cs = f.coeffs.as_ptr();
    while i < dst_w {
        let p = *po.add(i) as usize;
        let mut val = 0i32;
        for j in 0..sz {
            val += *src.add(p + j) as i32 * *cs.add(i * sz + j) as i32;
        }
        *dst.add(i) = (val >> 7).min(32767) as i16;
        i += 1;
    }
}

/// Gathered horizontal scaler: 16 outputs at a time, one 64-byte source window
/// shared by every tap, coefficients read tap-major so the whole thing is a
/// plain vertical dot product. Returns the number of outputs produced.
#[inline(always)]
unsafe fn hscale8_gather<const NT: usize>(dst: *mut i16, src: *const u8, f: &crate::filter::Filter) -> usize {
    let tb = f.tbase.as_ptr();
    let gi = f.gidx.as_ptr();
    let ct = f.coeffs_t.as_ptr();
    let gw = f.gw;
    let lim = vdupq_n_s32(32767);
    let one = vdupq_n_u8(1);
    let mut done = 0usize;
    for g in 0..f.tbase.len() {
        let b = *tb.add(g);
        if b < 0 {
            break;
        }
        let p = src.add(b as usize);
        let tbl = uint8x16x4_t(
            vld1q_u8(p),
            vld1q_u8(p.add(16)),
            vld1q_u8(p.add(32)),
            vld1q_u8(p.add(48)),
        );
        let mut idx = vld1q_u8(gi.add(g * 16));
        let mut a0 = vdupq_n_s32(0);
        let mut a1 = vdupq_n_s32(0);
        let mut a2 = vdupq_n_s32(0);
        let mut a3 = vdupq_n_s32(0);
        for j in 0..NT {
            let t = vqtbl4q_u8(tbl, idx);
            idx = vaddq_u8(idx, one);
            let tl = vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(t)));
            let th = vreinterpretq_s16_u16(vmovl_high_u8(t));
            let cl = vld1q_s16(ct.add(j * gw + g * 16));
            let ch = vld1q_s16(ct.add(j * gw + g * 16 + 8));
            a0 = vmlal_s16(a0, vget_low_s16(tl), vget_low_s16(cl));
            a1 = vmlal_high_s16(a1, tl, cl);
            a2 = vmlal_s16(a2, vget_low_s16(th), vget_low_s16(ch));
            a3 = vmlal_high_s16(a3, th, ch);
        }
        let o = dst.add(g * 16);
        vst1q_s16(
            o,
            vcombine_s16(
                vmovn_s32(vminq_s32(vshrq_n_s32(a0, 7), lim)),
                vmovn_s32(vminq_s32(vshrq_n_s32(a1, 7), lim)),
            ),
        );
        vst1q_s16(
            o.add(8),
            vcombine_s16(
                vmovn_s32(vminq_s32(vshrq_n_s32(a2, 7), lim)),
                vmovn_s32(vminq_s32(vshrq_n_s32(a3, 7), lim)),
            ),
        );
        done = g * 16 + 16;
    }
    done
}

#[inline(always)]
unsafe fn hscale8_taps<const NT: usize>(
    dst: *mut i16,
    dst_w: usize,
    src: *const u8,
    co: *const i16,
    po: *const i32,
    src_w: usize,
    start: usize,
) -> usize {
    let lim = vdupq_n_s32(32767);
    let mut i = start;
    while i + 4 <= dst_w {
        if *po.add(i + 3) as usize + NT > src_w {
            break;
        }
        let mut acc = [vdupq_n_s32(0); 4];
        for k in 0..4 {
            let p = *po.add(i + k) as usize;
            let cb = co.add((i + k) * NT);
            let mut a = vdupq_n_s32(0);
            let mut j = 0usize;
            while j < NT {
                let sv = vreinterpretq_s16_u16(vmovl_u8(vld1_u8(src.add(p + j))));
                let cv = vld1q_s16(cb.add(j));
                a = vmlal_s16(a, vget_low_s16(sv), vget_low_s16(cv));
                a = vmlal_high_s16(a, sv, cv);
                j += 8;
            }
            acc[k] = a;
        }
        let s = vminq_s32(vshrq_n_s32(hsum4(acc[0], acc[1], acc[2], acc[3]), 7), lim);
        vst1_s16(dst.add(i), vmovn_s32(s));
        i += 4;
    }
    i
}

unsafe fn hscale8_generic(
    dst: *mut i16,
    dst_w: usize,
    src: *const u8,
    co: *const i16,
    po: *const i32,
    src_w: usize,
    szp: usize,
    start: usize,
) -> usize {
    let lim = vdupq_n_s32(32767);
    let mut i = start;
    while i + 4 <= dst_w {
        if *po.add(i + 3) as usize + szp > src_w {
            break;
        }
        let mut acc = [vdupq_n_s32(0); 4];
        for k in 0..4 {
            let p = *po.add(i + k) as usize;
            let cb = co.add((i + k) * szp);
            let mut a = vdupq_n_s32(0);
            let mut j = 0usize;
            while j < szp {
                let sv = vreinterpretq_s16_u16(vmovl_u8(vld1_u8(src.add(p + j))));
                let cv = vld1q_s16(cb.add(j));
                a = vmlal_s16(a, vget_low_s16(sv), vget_low_s16(cv));
                a = vmlal_high_s16(a, sv, cv);
                j += 8;
            }
            acc[k] = a;
        }
        let s = vminq_s32(vshrq_n_s32(hsum4(acc[0], acc[1], acc[2], acc[3]), 7), lim);
        vst1_s16(dst.add(i), vmovn_s32(s));
        i += 4;
    }
    i
}

/// 16-bit source variant of the gathered scaler: 8 outputs per 32-sample window.
#[inline(always)]
unsafe fn hscale16_gather<const NT: usize>(
    dst: *mut i16,
    src: *const i16,
    f: &crate::filter::Filter,
) -> usize {
    let tb = f.tbase16.as_ptr();
    let gi = f.gidx16.as_ptr();
    let ct = f.coeffs_t.as_ptr();
    let gw = f.gw;
    let lim = vdupq_n_s32(32767);
    let two = vdupq_n_u8(2);
    let mut done = 0usize;
    for g in 0..f.tbase16.len() {
        let b = *tb.add(g);
        if b < 0 {
            break;
        }
        let p = src.add(b as usize) as *const u8;
        let tbl = uint8x16x4_t(
            vld1q_u8(p),
            vld1q_u8(p.add(16)),
            vld1q_u8(p.add(32)),
            vld1q_u8(p.add(48)),
        );
        let mut idx = vld1q_u8(gi.add(g * 16));
        let mut a0 = vdupq_n_s32(0);
        let mut a1 = vdupq_n_s32(0);
        for j in 0..NT {
            let t = vreinterpretq_s16_u8(vqtbl4q_u8(tbl, idx));
            idx = vaddq_u8(idx, two);
            let c = vld1q_s16(ct.add(j * gw + g * 8));
            a0 = vmlal_s16(a0, vget_low_s16(t), vget_low_s16(c));
            a1 = vmlal_high_s16(a1, t, c);
        }
        vst1q_s16(
            dst.add(g * 8),
            vcombine_s16(
                vmovn_s32(vminq_s32(vshrq_n_s32(a0, 13), lim)),
                vmovn_s32(vminq_s32(vshrq_n_s32(a1, 13), lim)),
            ),
        );
        done = g * 8 + 8;
    }
    done
}

#[inline(always)]
unsafe fn hscale16_taps<const NT: usize>(
    dst: *mut i16,
    dst_w: usize,
    src: *const i16,
    co: *const i16,
    po: *const i32,
    src_w: usize,
    start: usize,
) -> usize {
    let lim = vdupq_n_s32(32767);
    let mut i = start;
    while i + 4 <= dst_w {
        if *po.add(i + 3) as usize + NT > src_w {
            break;
        }
        let mut acc = [vdupq_n_s32(0); 4];
        for k in 0..4 {
            let p = *po.add(i + k) as usize;
            let cb = co.add((i + k) * NT);
            let mut a = vdupq_n_s32(0);
            let mut j = 0usize;
            while j < NT {
                let sv = vld1q_s16(src.add(p + j));
                let cv = vld1q_s16(cb.add(j));
                a = vmlal_s16(a, vget_low_s16(sv), vget_low_s16(cv));
                a = vmlal_high_s16(a, sv, cv);
                j += 8;
            }
            acc[k] = a;
        }
        let s = vminq_s32(vshrq_n_s32(hsum4(acc[0], acc[1], acc[2], acc[3]), 13), lim);
        vst1_s16(dst.add(i), vmovn_s32(s));
        i += 4;
    }
    i
}

unsafe fn hscale16_generic(
    dst: *mut i16,
    dst_w: usize,
    src: *const i16,
    co: *const i16,
    po: *const i32,
    src_w: usize,
    szp: usize,
    start: usize,
) -> usize {
    let lim = vdupq_n_s32(32767);
    let mut i = start;
    while i + 4 <= dst_w {
        if *po.add(i + 3) as usize + szp > src_w {
            break;
        }
        let mut acc = [vdupq_n_s32(0); 4];
        for k in 0..4 {
            let p = *po.add(i + k) as usize;
            let cb = co.add((i + k) * szp);
            let mut a = vdupq_n_s32(0);
            let mut j = 0usize;
            while j < szp {
                let sv = vld1q_s16(src.add(p + j));
                let cv = vld1q_s16(cb.add(j));
                a = vmlal_s16(a, vget_low_s16(sv), vget_low_s16(cv));
                a = vmlal_high_s16(a, sv, cv);
                j += 8;
            }
            acc[k] = a;
        }
        let s = vminq_s32(vshrq_n_s32(hsum4(acc[0], acc[1], acc[2], acc[3]), 13), lim);
        vst1_s16(dst.add(i), vmovn_s32(s));
        i += 4;
    }
    i
}

pub unsafe fn hscale16to15_neon(
    dst: *mut i16,
    dst_w: usize,
    src: *const i16,
    f: &crate::filter::Filter,
    src_w: usize,
) {
    let szp = f.size_p;
    let sz = f.size;
    let co = f.coeffs_p.as_ptr();
    let po = f.pos.as_ptr();
    let lim = vdupq_n_s32(32767);
    let mut i = 0usize;
    if f.point {
        let gb = f.gbase16.as_ptr();
        let gi = f.gidx16.as_ptr();
        for g in 0..f.gbase16.len() {
            let b = *gb.add(g);
            if b < 0 {
                break;
            }
            let p = src.add(b as usize) as *const u8;
            let t = uint8x16x4_t(
                vld1q_u8(p),
                vld1q_u8(p.add(16)),
                vld1q_u8(p.add(32)),
                vld1q_u8(p.add(48)),
            );
            let v = vreinterpretq_s16_u8(vqtbl4q_u8(t, vld1q_u8(gi.add(g * 16))));
            vst1q_s16(dst.add(g * 8), vqshlq_n_s16(v, 1));
            i = g * 8 + 8;
        }
        let cs = f.coeffs.as_ptr();
        while i < dst_w {
            let v = *src.add(*po.add(i) as usize) as i32 * *cs.add(i) as i32;
            *dst.add(i) = (v >> 13).min(32767) as i16;
            i += 1;
        }
        return;
    }
    if !f.coeffs_t.is_empty() && sz <= 8 {
        i = match sz {
            2 => hscale16_gather::<2>(dst, src, f),
            3 => hscale16_gather::<3>(dst, src, f),
            4 => hscale16_gather::<4>(dst, src, f),
            5 => hscale16_gather::<5>(dst, src, f),
            6 => hscale16_gather::<6>(dst, src, f),
            7 => hscale16_gather::<7>(dst, src, f),
            8 => hscale16_gather::<8>(dst, src, f),
            _ => 0,
        };
    }
    if szp == 4 && i + 4 <= dst_w {
        while i + 4 <= dst_w {
            let p3 = *po.add(i + 3) as usize;
            if p3 + 4 > src_w {
                break;
            }
            let p0 = *po.add(i) as usize;
            let p1 = *po.add(i + 1) as usize;
            let p2 = *po.add(i + 2) as usize;
            let a = vmull_s16(vld1_s16(src.add(p0)), vld1_s16(co.add(i * 4)));
            let b = vmull_s16(vld1_s16(src.add(p1)), vld1_s16(co.add(i * 4 + 4)));
            let c = vmull_s16(vld1_s16(src.add(p2)), vld1_s16(co.add(i * 4 + 8)));
            let d = vmull_s16(vld1_s16(src.add(p3)), vld1_s16(co.add(i * 4 + 12)));
            let s = vminq_s32(vshrq_n_s32(hsum4(a, b, c, d), 13), lim);
            vst1_s16(dst.add(i), vmovn_s32(s));
            i += 4;
        }
    } else if i + 4 <= dst_w {
        {
        i = match szp {
            8 => hscale16_taps::<8>(dst, dst_w, src, co, po, src_w, i),
            16 => hscale16_taps::<16>(dst, dst_w, src, co, po, src_w, i),
            24 => hscale16_taps::<24>(dst, dst_w, src, co, po, src_w, i),
            32 => hscale16_taps::<32>(dst, dst_w, src, co, po, src_w, i),
            40 => hscale16_taps::<40>(dst, dst_w, src, co, po, src_w, i),
            48 => hscale16_taps::<48>(dst, dst_w, src, co, po, src_w, i),
            _ => hscale16_generic(dst, dst_w, src, co, po, src_w, szp, i),
        };
        }
    }
    let cs = f.coeffs.as_ptr();
    while i < dst_w {
        let p = *po.add(i) as usize;
        let mut val = 0i32;
        for j in 0..sz {
            val += *src.add(p + j) as i32 * *cs.add(i * sz + j) as i32;
        }
        *dst.add(i) = (val >> 13).min(32767) as i16;
        i += 1;
    }
}

// ── full-chroma packed RGB output ───────────────────────────────────────────

/// `yuv2rgb_write_full` for 4 pixels. The C code clips to 30 bits then shifts by
/// 22; the saturating narrowing shift plus the later u16->u8 saturation is
/// numerically identical and two instructions shorter per channel.
#[inline(always)]
unsafe fn full_rgb(cf: &Cf, y: int32x4_t, u: int32x4_t, v: int32x4_t) -> [int32x4_t; 3] {
    let yy = vaddq_s32(
        vmulq_n_s32(vsubq_s32(y, vdupq_n_s32(cf.y_offset)), cf.y_coeff),
        vdupq_n_s32(1 << 21),
    );
    let r = vmlaq_n_s32(yy, v, cf.v2r);
    let g = vmlaq_n_s32(vmlaq_n_s32(yy, v, cf.v2g), u, cf.u2g);
    let b = vmlaq_n_s32(yy, u, cf.u2b);
    // The C code clips to 30 bits before shifting by 22; an arithmetic shift
    // leaves the result in [-512, 511], and the saturating u8 narrow in pack16
    // maps exactly the same values to 0 and 255.
    [vshrq_n_s32(r, 22), vshrq_n_s32(g, 22), vshrq_n_s32(b, 22)]
}

#[inline(always)]
unsafe fn pack16(a: &[int32x4_t; 4]) -> uint8x16_t {
    let lo = vcombine_s16(vmovn_s32(a[0]), vmovn_s32(a[1]));
    let hi = vcombine_s16(vmovn_s32(a[2]), vmovn_s32(a[3]));
    vcombine_u8(vqmovun_s16(lo), vqmovun_s16(hi))
}

#[inline(always)]
unsafe fn store_rgba16(
    fmt: i32,
    d: *mut u8,
    r: uint8x16_t,
    g: uint8x16_t,
    b: uint8x16_t,
    a: uint8x16_t,
) {
    match fmt {
        RGB24 => vst3q_u8(d, uint8x16x3_t(r, g, b)),
        BGR24 => vst3q_u8(d, uint8x16x3_t(b, g, r)),
        RGBA => vst4q_u8(d, uint8x16x4_t(r, g, b, a)),
        _ => vst4q_u8(d, uint8x16x4_t(b, g, r, a)),
    }
}

#[inline(always)]
unsafe fn widen16(v: int16x8_t) -> (int32x4_t, int32x4_t) {
    (vmovl_s16(vget_low_s16(v)), vmovl_high_s16(v))
}

pub unsafe fn rgb_full_1_neon(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    two: bool,
    abuf0: *const i16,
    dst: *mut u8,
    w: usize,
) {
    if two {
        rgb_full_1_impl::<true>(cf, fmt, buf0, ubuf0, ubuf1, vbuf0, vbuf1, abuf0, dst, w)
    } else {
        rgb_full_1_impl::<false>(cf, fmt, buf0, ubuf0, ubuf1, vbuf0, vbuf1, abuf0, dst, w)
    }
}

#[inline(always)]
unsafe fn rgb_full_1_impl<const TWO: bool>(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    abuf0: *const i16,
    dst: *mut u8,
    w: usize,
) {
    let step = bpp(fmt);
    let coff = vdupq_n_s32(128 << 7);
    let coff2 = vdupq_n_s32(128 << 8);
    let mut i = 0usize;
    let mut alpha = vdupq_n_u8(255);
    let bias = vdupq_n_s16(64);
    while i + 16 <= w {
        if !abuf0.is_null() {
            let a0 = vqaddq_s16(vld1q_s16(abuf0.add(i)), bias);
            let a1 = vqaddq_s16(vld1q_s16(abuf0.add(i + 8)), bias);
            alpha = vcombine_u8(vqshrun_n_s16(a0, 7), vqshrun_n_s16(a1, 7));
        }
        let mut rr = [vdupq_n_s32(0); 4];
        let mut gg = [vdupq_n_s32(0); 4];
        let mut bb = [vdupq_n_s32(0); 4];
        for k in 0..2 {
            let p = i + k * 8;
            let yv = vld1q_s16(buf0.add(p));
            let (yl, yh) = widen16(yv);
            let (ul, uh, vl, vh) = if TWO {
                let (a, b) = widen16(vld1q_s16(ubuf0.add(p)));
                let (c, d) = widen16(vld1q_s16(ubuf1.add(p)));
                let (e, f2) = widen16(vld1q_s16(vbuf0.add(p)));
                let (g2, h2) = widen16(vld1q_s16(vbuf1.add(p)));
                (
                    vshlq_n_s32(vsubq_s32(vaddq_s32(a, c), coff2), 1),
                    vshlq_n_s32(vsubq_s32(vaddq_s32(b, d), coff2), 1),
                    vshlq_n_s32(vsubq_s32(vaddq_s32(e, g2), coff2), 1),
                    vshlq_n_s32(vsubq_s32(vaddq_s32(f2, h2), coff2), 1),
                )
            } else {
                let (a, b) = widen16(vld1q_s16(ubuf0.add(p)));
                let (c, d) = widen16(vld1q_s16(vbuf0.add(p)));
                (
                    vshlq_n_s32(vsubq_s32(a, coff), 2),
                    vshlq_n_s32(vsubq_s32(b, coff), 2),
                    vshlq_n_s32(vsubq_s32(c, coff), 2),
                    vshlq_n_s32(vsubq_s32(d, coff), 2),
                )
            };
            let o = full_rgb(cf, vshlq_n_s32(yl, 2), ul, vl);
            rr[k * 2] = o[0];
            gg[k * 2] = o[1];
            bb[k * 2] = o[2];
            let o = full_rgb(cf, vshlq_n_s32(yh, 2), uh, vh);
            rr[k * 2 + 1] = o[0];
            gg[k * 2 + 1] = o[1];
            bb[k * 2 + 1] = o[2];
        }
        store_rgba16(
            fmt,
            dst.add(i * step),
            pack16(&rr),
            pack16(&gg),
            pack16(&bb),
            alpha,
        );
        i += 16;
    }
    while i < w {
        let y = *buf0.add(i) as i32 * 4;
        let (u, v) = if TWO {
            (
                (*ubuf0.add(i) as i32 + *ubuf1.add(i) as i32 - (128 << 8)) * 2,
                (*vbuf0.add(i) as i32 + *vbuf1.add(i) as i32 - (128 << 8)) * 2,
            )
        } else {
            (
                (*ubuf0.add(i) as i32 - (128 << 7)) * 4,
                (*vbuf0.add(i) as i32 - (128 << 7)) * 4,
            )
        };
        let a = if abuf0.is_null() {
            255
        } else {
            clip_u8((*abuf0.add(i) as i32 + 64) >> 7) as i32
        };
        crate::simd::write_full_a(cf, fmt, dst.add(i * step), y, u, v, a);
        i += 1;
    }
}

pub unsafe fn rgb_full_2_neon(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    buf1: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    abuf0: *const i16,
    abuf1: *const i16,
    dst: *mut u8,
    w: usize,
    yalpha: i32,
    uvalpha: i32,
) {
    let step = bpp(fmt);
    let ya1 = (4096 - yalpha) as i16;
    let ya = yalpha as i16;
    let ua1 = (4096 - uvalpha) as i16;
    let ua = uvalpha as i16;
    let coff = vdupq_n_s32(128 << 19);
    let mut alpha = vdupq_n_u8(255);
    let mut i = 0usize;
    while i + 16 <= w {
        let mut rr = [vdupq_n_s32(0); 4];
        let mut gg = [vdupq_n_s32(0); 4];
        let mut bb = [vdupq_n_s32(0); 4];
        if !abuf0.is_null() {
            let mut aa = [vdupq_n_s32(0); 4];
            for k in 0..4 {
                let o = i + k * 4;
                aa[k] = vshrq_n_s32(
                    vaddq_s32(
                        vmlal_n_s16(vmull_n_s16(vld1_s16(abuf0.add(o)), ya1), vld1_s16(abuf1.add(o)), ya),
                        vdupq_n_s32(1 << 18),
                    ),
                    19,
                );
            }
            alpha = pack16(&aa);
        }
        for k in 0..4 {
            let o = i + k * 4;
            let y0 = vld1_s16(buf0.add(o));
            let y1 = vld1_s16(buf1.add(o));
            let u0 = vld1_s16(ubuf0.add(o));
            let u1 = vld1_s16(ubuf1.add(o));
            let v0 = vld1_s16(vbuf0.add(o));
            let v1 = vld1_s16(vbuf1.add(o));
            let y = vshrq_n_s32(vmlal_n_s16(vmull_n_s16(y0, ya1), y1, ya), 10);
            let u = vshrq_n_s32(
                vsubq_s32(vmlal_n_s16(vmull_n_s16(u0, ua1), u1, ua), coff),
                10,
            );
            let v = vshrq_n_s32(
                vsubq_s32(vmlal_n_s16(vmull_n_s16(v0, ua1), v1, ua), coff),
                10,
            );
            let out = full_rgb(cf, y, u, v);
            rr[k] = out[0];
            gg[k] = out[1];
            bb[k] = out[2];
        }
        store_rgba16(
            fmt,
            dst.add(i * step),
            pack16(&rr),
            pack16(&gg),
            pack16(&bb),
            alpha,
        );
        i += 16;
    }
    let ya1 = 4096 - yalpha;
    let ua1i = 4096 - uvalpha;
    while i < w {
        let y = (*buf0.add(i) as i32 * ya1 + *buf1.add(i) as i32 * yalpha) >> 10;
        let u = (*ubuf0.add(i) as i32 * ua1i + *ubuf1.add(i) as i32 * uvalpha - (128 << 19)) >> 10;
        let v = (*vbuf0.add(i) as i32 * ua1i + *vbuf1.add(i) as i32 * uvalpha - (128 << 19)) >> 10;
        let a = if abuf0.is_null() {
            255
        } else {
            clip_u8((*abuf0.add(i) as i32 * ya1 + *abuf1.add(i) as i32 * yalpha + (1 << 18)) >> 19)
                as i32
        };
        crate::simd::write_full_a(cf, fmt, dst.add(i * step), y, u, v, a);
        i += 1;
    }
}

#[inline(always)]
unsafe fn rgb_full_x_n<const LN: usize, const CN: usize>(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    asrc: &[*const i16],
    dst: *mut u8,
    w: usize,
) {
    let step = bpp(fmt);
    let mut alpha = vdupq_n_u8(255);
    let coff = vdupq_n_s32((1 << 9) - (128 << 19));
    let ybase = vdupq_n_s32(1 << 9);
    let abase = vdupq_n_s32(1 << 18);
    let mut lfc = [0i16; LN];
    let mut lsp = [std::ptr::null::<i16>(); LN];
    let mut asp = [std::ptr::null::<i16>(); LN];
    for j in 0..LN {
        lfc[j] = lf[j];
        lsp[j] = lsrc[j];
        asp[j] = if asrc.is_empty() {
            std::ptr::null()
        } else {
            asrc[j]
        };
    }
    let mut cfc = [0i16; CN];
    let mut usp = [std::ptr::null::<i16>(); CN];
    let mut vsp = [std::ptr::null::<i16>(); CN];
    for j in 0..CN {
        cfc[j] = chf[j];
        usp[j] = usrc[j];
        vsp[j] = vsrc[j];
    }
    let has_a = !asrc.is_empty();
    let mut i = 0usize;
    while i + 16 <= w {
        let mut rr = [vdupq_n_s32(0); 4];
        let mut gg = [vdupq_n_s32(0); 4];
        let mut bb = [vdupq_n_s32(0); 4];
        if has_a {
            let mut aa = [vdupq_n_s32(0); 4];
            for k in 0..4 {
                let o = i + k * 4;
                let mut a = abase;
                for j in 0..LN {
                    a = vmlal_n_s16(a, vld1_s16(asp[j].add(o)), lfc[j]);
                }
                aa[k] = vshrq_n_s32(a, 19);
            }
            alpha = pack16(&aa);
        }
        for k in 0..4 {
            let o = i + k * 4;
            let mut y = ybase;
            for j in 0..LN {
                y = vmlal_n_s16(y, vld1_s16(lsp[j].add(o)), lfc[j]);
            }
            let mut u = coff;
            let mut v = coff;
            for j in 0..CN {
                u = vmlal_n_s16(u, vld1_s16(usp[j].add(o)), cfc[j]);
                v = vmlal_n_s16(v, vld1_s16(vsp[j].add(o)), cfc[j]);
            }
            let out = full_rgb(
                cf,
                vshrq_n_s32(y, 10),
                vshrq_n_s32(u, 10),
                vshrq_n_s32(v, 10),
            );
            rr[k] = out[0];
            gg[k] = out[1];
            bb[k] = out[2];
        }
        store_rgba16(
            fmt,
            dst.add(i * step),
            pack16(&rr),
            pack16(&gg),
            pack16(&bb),
            alpha,
        );
        i += 16;
    }
    while i < w {
        let mut y: i32 = 1 << 9;
        let mut u: i32 = (1 << 9) - (128 << 19);
        let mut v: i32 = (1 << 9) - (128 << 19);
        for j in 0..LN {
            y += *lsp[j].add(i) as i32 * lfc[j] as i32;
        }
        for j in 0..CN {
            let c = cfc[j] as i32;
            u += *usp[j].add(i) as i32 * c;
            v += *vsp[j].add(i) as i32 * c;
        }
        let a = if !has_a {
            255
        } else {
            let mut aa: i32 = 1 << 18;
            for j in 0..LN {
                aa += *asp[j].add(i) as i32 * lfc[j] as i32;
            }
            clip_u8(aa >> 19) as i32
        };
        crate::simd::write_full_a(cf, fmt, dst.add(i * step), y >> 10, u >> 10, v >> 10, a);
        i += 1;
    }
}

pub unsafe fn rgb_full_x_neon(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    asrc: &[*const i16],
    dst: *mut u8,
    w: usize,
) {
    macro_rules! d {
        ($ln:literal) => {
            match chf.len() {
                1 => return rgb_full_x_n::<$ln, 1>(cf, fmt, lf, lsrc, chf, usrc, vsrc, asrc, dst, w),
                2 => return rgb_full_x_n::<$ln, 2>(cf, fmt, lf, lsrc, chf, usrc, vsrc, asrc, dst, w),
                3 => return rgb_full_x_n::<$ln, 3>(cf, fmt, lf, lsrc, chf, usrc, vsrc, asrc, dst, w),
                4 => return rgb_full_x_n::<$ln, 4>(cf, fmt, lf, lsrc, chf, usrc, vsrc, asrc, dst, w),
                _ => {}
            }
        };
    }
    match lf.len() {
        1 => d!(1),
        2 => d!(2),
        3 => d!(3),
        4 => d!(4),
        _ => {}
    }
    rgb_full_x_generic(cf, fmt, lf, lsrc, chf, usrc, vsrc, asrc, dst, w)
}

unsafe fn rgb_full_x_generic(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    asrc: &[*const i16],
    dst: *mut u8,
    w: usize,
) {
    let step = bpp(fmt);
    let mut alpha = vdupq_n_u8(255);
    let coff = vdupq_n_s32((1 << 9) - (128 << 19));
    let ybase = vdupq_n_s32(1 << 9);
    let abase = vdupq_n_s32(1 << 18);
    let mut i = 0usize;
    while i + 16 <= w {
        let mut rr = [vdupq_n_s32(0); 4];
        let mut gg = [vdupq_n_s32(0); 4];
        let mut bb = [vdupq_n_s32(0); 4];
        if !asrc.is_empty() {
            let mut aa = [vdupq_n_s32(0); 4];
            for k in 0..4 {
                let o = i + k * 4;
                let mut a = abase;
                for j in 0..lf.len() {
                    a = vmlal_n_s16(a, vld1_s16(asrc[j].add(o)), lf[j]);
                }
                aa[k] = vshrq_n_s32(a, 19);
            }
            alpha = pack16(&aa);
        }
        for k in 0..4 {
            let o = i + k * 4;
            let mut y = ybase;
            for j in 0..lf.len() {
                y = vmlal_n_s16(y, vld1_s16(lsrc[j].add(o)), lf[j]);
            }
            let mut u = coff;
            let mut v = coff;
            for j in 0..chf.len() {
                u = vmlal_n_s16(u, vld1_s16(usrc[j].add(o)), chf[j]);
                v = vmlal_n_s16(v, vld1_s16(vsrc[j].add(o)), chf[j]);
            }
            let out = full_rgb(
                cf,
                vshrq_n_s32(y, 10),
                vshrq_n_s32(u, 10),
                vshrq_n_s32(v, 10),
            );
            rr[k] = out[0];
            gg[k] = out[1];
            bb[k] = out[2];
        }
        store_rgba16(
            fmt,
            dst.add(i * step),
            pack16(&rr),
            pack16(&gg),
            pack16(&bb),
            alpha,
        );
        i += 16;
    }
    while i < w {
        let mut y: i32 = 1 << 9;
        let mut u: i32 = (1 << 9) - (128 << 19);
        let mut v: i32 = (1 << 9) - (128 << 19);
        for j in 0..lf.len() {
            y += *lsrc[j].add(i) as i32 * lf[j] as i32;
        }
        for j in 0..chf.len() {
            let c = chf[j] as i32;
            u += *usrc[j].add(i) as i32 * c;
            v += *vsrc[j].add(i) as i32 * c;
        }
        let a = if asrc.is_empty() {
            255
        } else {
            let mut aa: i32 = 1 << 18;
            for j in 0..lf.len() {
                aa += *asrc[j].add(i) as i32 * lf[j] as i32;
            }
            clip_u8(aa >> 19) as i32
        };
        crate::simd::write_full_a(cf, fmt, dst.add(i * step), y >> 10, u >> 10, v >> 10, a);
        i += 1;
    }
}

// ── half-chroma packed RGB output, multi-tap ────────────────────────────────

pub unsafe fn rgb_2_neon(
    cf: &Cf,
    fmt: i32,
    buf0: *const i16,
    buf1: *const i16,
    ubuf0: *const i16,
    ubuf1: *const i16,
    vbuf0: *const i16,
    vbuf1: *const i16,
    dst: *mut u8,
    n: usize,
    yalpha: i32,
    uvalpha: i32,
) {
    let step = bpp(fmt);
    let ya1 = (4096 - yalpha) as i16;
    let ya = yalpha as i16;
    let ua1 = (4096 - uvalpha) as i16;
    let ua = uvalpha as i16;
    let mut i = 0usize;
    while i + 8 <= n {
        let ul = vshrq_n_s32(
            vmlal_n_s16(vmull_n_s16(vld1_s16(ubuf0.add(i)), ua1), vld1_s16(ubuf1.add(i)), ua),
            19,
        );
        let uh = vshrq_n_s32(
            vmlal_n_s16(
                vmull_n_s16(vld1_s16(ubuf0.add(i + 4)), ua1),
                vld1_s16(ubuf1.add(i + 4)),
                ua,
            ),
            19,
        );
        let vl = vshrq_n_s32(
            vmlal_n_s16(vmull_n_s16(vld1_s16(vbuf0.add(i)), ua1), vld1_s16(vbuf1.add(i)), ua),
            19,
        );
        let vh = vshrq_n_s32(
            vmlal_n_s16(
                vmull_n_s16(vld1_s16(vbuf0.add(i + 4)), ua1),
                vld1_s16(vbuf1.add(i + 4)),
                ua,
            ),
            19,
        );
        let uu = vcombine_u16(vqmovun_s32(ul), vqmovun_s32(uh));
        let vv = vcombine_u16(vqmovun_s32(vl), vqmovun_s32(vh));
        let uu = vminq_u16(uu, vdupq_n_u16(255));
        let vv = vminq_u16(vv, vdupq_n_u16(255));
        let k = kbases8(cf, uu, vv);
        let mut ys = [vdupq_n_s32(0); 4];
        for j in 0..4 {
            let o = 2 * i + j * 4;
            ys[j] = vshrq_n_s32(
                vmlal_n_s16(vmull_n_s16(vld1_s16(buf0.add(o)), ya1), vld1_s16(buf1.add(o)), ya),
                19,
            );
        }
        emit16y(cf, fmt, &kdup(&k), &ys, dst.add(2 * i * step));
        i += 8;
    }
    let ya1 = 4096 - yalpha;
    let ua1i = 4096 - uvalpha;
    while i < n {
        let y1 = (*buf0.add(2 * i) as i32 * ya1 + *buf1.add(2 * i) as i32 * yalpha) >> 19;
        let y2 = (*buf0.add(2 * i + 1) as i32 * ya1 + *buf1.add(2 * i + 1) as i32 * yalpha) >> 19;
        let u = (*ubuf0.add(i) as i32 * ua1i + *ubuf1.add(i) as i32 * uvalpha) >> 19;
        let v = (*vbuf0.add(i) as i32 * ua1i + *vbuf1.add(i) as i32 * uvalpha) >> 19;
        crate::fast::yuv2rgb_pair(cf, fmt, dst, i, step, y1, y2, u, v);
        i += 1;
    }
}

#[inline(always)]
unsafe fn rgb_x_n<const LN: usize, const CN: usize>(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    dst: *mut u8,
    n: usize,
) {
    let step = bpp(fmt);
    let base = vdupq_n_s32(1 << 18);
    let zero = vdupq_n_s32(0);
    let c255 = vdupq_n_s32(255);
    let mut lfc = [0i16; LN];
    let mut lsp = [std::ptr::null::<i16>(); LN];
    for j in 0..LN {
        lfc[j] = lf[j];
        lsp[j] = lsrc[j];
    }
    let mut cfc = [0i16; CN];
    let mut usp = [std::ptr::null::<i16>(); CN];
    let mut vsp = [std::ptr::null::<i16>(); CN];
    for j in 0..CN {
        cfc[j] = chf[j];
        usp[j] = usrc[j];
        vsp[j] = vsrc[j];
    }
    let mut i = 0usize;
    while i + 8 <= n {
        let mut us = [vdupq_n_s32(0); 2];
        let mut vs = [vdupq_n_s32(0); 2];
        for k in 0..2 {
            let o = i + k * 4;
            let mut u = base;
            let mut v = base;
            for j in 0..CN {
                u = vmlal_n_s16(u, vld1_s16(usp[j].add(o)), cfc[j]);
                v = vmlal_n_s16(v, vld1_s16(vsp[j].add(o)), cfc[j]);
            }
            us[k] = vminq_s32(vmaxq_s32(vshrq_n_s32(u, 19), zero), c255);
            vs[k] = vminq_s32(vmaxq_s32(vshrq_n_s32(v, 19), zero), c255);
        }
        let k = kdup(&kbases8_i32(cf, us[0], us[1], vs[0], vs[1]));
        let mut ys = [vdupq_n_s32(0); 4];
        for j2 in 0..4 {
            let o = 2 * i + j2 * 4;
            let mut y = base;
            for j in 0..LN {
                y = vmlal_n_s16(y, vld1_s16(lsp[j].add(o)), lfc[j]);
            }
            ys[j2] = vshrq_n_s32(y, 19);
        }
        emit16y(cf, fmt, &k, &ys, dst.add(2 * i * step));
        i += 8;
    }
    while i < n {
        let mut y1: i32 = 1 << 18;
        let mut y2: i32 = 1 << 18;
        let mut u: i32 = 1 << 18;
        let mut v: i32 = 1 << 18;
        for j in 0..LN {
            let c = lfc[j] as i32;
            y1 += *lsp[j].add(2 * i) as i32 * c;
            y2 += *lsp[j].add(2 * i + 1) as i32 * c;
        }
        for j in 0..CN {
            let c = cfc[j] as i32;
            u += *usp[j].add(i) as i32 * c;
            v += *vsp[j].add(i) as i32 * c;
        }
        crate::fast::yuv2rgb_pair(cf, fmt, dst, i, step, y1 >> 19, y2 >> 19, u >> 19, v >> 19);
        i += 1;
    }
}

pub unsafe fn rgb_x_neon(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    dst: *mut u8,
    n: usize,
) {
    macro_rules! d {
        ($ln:literal) => {
            match chf.len() {
                2 => return rgb_x_n::<$ln, 2>(cf, fmt, lf, lsrc, chf, usrc, vsrc, dst, n),
                3 => return rgb_x_n::<$ln, 3>(cf, fmt, lf, lsrc, chf, usrc, vsrc, dst, n),
                4 => return rgb_x_n::<$ln, 4>(cf, fmt, lf, lsrc, chf, usrc, vsrc, dst, n),
                _ => {}
            }
        };
    }
    match lf.len() {
        2 => d!(2),
        3 => d!(3),
        4 => d!(4),
        _ => {}
    }
    rgb_x_generic(cf, fmt, lf, lsrc, chf, usrc, vsrc, dst, n)
}

unsafe fn rgb_x_generic(
    cf: &Cf,
    fmt: i32,
    lf: &[i16],
    lsrc: &[*const i16],
    chf: &[i16],
    usrc: &[*const i16],
    vsrc: &[*const i16],
    dst: *mut u8,
    n: usize,
) {
    let step = bpp(fmt);
    let base = vdupq_n_s32(1 << 18);
    let mut i = 0usize;
    while i + 8 <= n {
        let mut us = [vdupq_n_s32(0); 2];
        let mut vs = [vdupq_n_s32(0); 2];
        for k in 0..2 {
            let o = i + k * 4;
            let mut u = base;
            let mut v = base;
            for j in 0..chf.len() {
                u = vmlal_n_s16(u, vld1_s16(usrc[j].add(o)), chf[j]);
                v = vmlal_n_s16(v, vld1_s16(vsrc[j].add(o)), chf[j]);
            }
            us[k] = vshrq_n_s32(u, 19);
            vs[k] = vshrq_n_s32(v, 19);
        }
        let uu = vminq_u16(
            vcombine_u16(vqmovun_s32(us[0]), vqmovun_s32(us[1])),
            vdupq_n_u16(255),
        );
        let vv = vminq_u16(
            vcombine_u16(vqmovun_s32(vs[0]), vqmovun_s32(vs[1])),
            vdupq_n_u16(255),
        );
        let k = kdup(&kbases8(cf, uu, vv));
        let mut ys = [vdupq_n_s32(0); 4];
        for j2 in 0..4 {
            let o = 2 * i + j2 * 4;
            let mut y = base;
            for j in 0..lf.len() {
                y = vmlal_n_s16(y, vld1_s16(lsrc[j].add(o)), lf[j]);
            }
            ys[j2] = vshrq_n_s32(y, 19);
        }
        emit16y(cf, fmt, &k, &ys, dst.add(2 * i * step));
        i += 8;
    }
    while i < n {
        let mut y1: i32 = 1 << 18;
        let mut y2: i32 = 1 << 18;
        let mut u: i32 = 1 << 18;
        let mut v: i32 = 1 << 18;
        for j in 0..lf.len() {
            let c = lf[j] as i32;
            y1 += *lsrc[j].add(2 * i) as i32 * c;
            y2 += *lsrc[j].add(2 * i + 1) as i32 * c;
        }
        for j in 0..chf.len() {
            let c = chf[j] as i32;
            u += *usrc[j].add(i) as i32 * c;
            v += *vsrc[j].add(i) as i32 * c;
        }
        crate::fast::yuv2rgb_pair(cf, fmt, dst, i, step, y1 >> 19, y2 >> 19, u >> 19, v >> 19);
        i += 1;
    }
}

pub unsafe fn yuv2nv12cx_neon(
    swap: bool,
    f: &[i16],
    su: &[*const i16],
    sv: &[*const i16],
    dst: *mut u8,
    n: usize,
) {
    match f.len() {
        1 => return nv12cx_n::<1>(swap, f, su, sv, dst, n),
        2 => return nv12cx_n::<2>(swap, f, su, sv, dst, n),
        3 => return nv12cx_n::<3>(swap, f, su, sv, dst, n),
        4 => return nv12cx_n::<4>(swap, f, su, sv, dst, n),
        _ => {}
    }
    let base = vdupq_n_s32(64 << 12);
    let mut i = 0usize;
    while i + 8 <= n {
        let mut uu = [vdupq_n_s32(0); 2];
        let mut vv = [vdupq_n_s32(0); 2];
        for k in 0..2 {
            let o = i + k * 4;
            let mut u = base;
            let mut v = base;
            for j in 0..f.len() {
                u = vmlal_n_s16(u, vld1_s16(su[j].add(o)), f[j]);
                v = vmlal_n_s16(v, vld1_s16(sv[j].add(o)), f[j]);
            }
            uu[k] = vshrq_n_s32(u, 16);
            vv[k] = vshrq_n_s32(v, 16);
        }
        let u8v = vqshrun_n_s16(vcombine_s16(vmovn_s32(uu[0]), vmovn_s32(uu[1])), 3);
        let v8v = vqshrun_n_s16(vcombine_s16(vmovn_s32(vv[0]), vmovn_s32(vv[1])), 3);
        if swap {
            vst2_u8(dst.add(2 * i), uint8x8x2_t(v8v, u8v));
        } else {
            vst2_u8(dst.add(2 * i), uint8x8x2_t(u8v, v8v));
        }
        i += 8;
    }
    while i < n {
        let mut u: i32 = 64 << 12;
        let mut v: i32 = 64 << 12;
        for j in 0..f.len() {
            u += *su[j].add(i) as i32 * f[j] as i32;
            v += *sv[j].add(i) as i32 * f[j] as i32;
        }
        let (a, b) = if swap {
            (clip_u8(v >> 19), clip_u8(u >> 19))
        } else {
            (clip_u8(u >> 19), clip_u8(v >> 19))
        };
        *dst.add(2 * i) = a;
        *dst.add(2 * i + 1) = b;
        i += 1;
    }
}

pub unsafe fn rgba_to_a16_neon(src: *const u8, dst: *mut i16, n: usize) {
    let mut i = 0usize;
    while i + 16 <= n {
        let v = vld4q_u8(src.add(i * 4));
        let a = v.3;
        let lo = vmovl_u8(vget_low_u8(a));
        let hi = vmovl_high_u8(a);
        vst1q_s16(
            dst.add(i),
            vreinterpretq_s16_u16(vorrq_u16(vshlq_n_u16(lo, 6), vshrq_n_u16(lo, 2))),
        );
        vst1q_s16(
            dst.add(i + 8),
            vreinterpretq_s16_u16(vorrq_u16(vshlq_n_u16(hi, 6), vshrq_n_u16(hi, 2))),
        );
        i += 16;
    }
    while i < n {
        let a = *src.add(i * 4 + 3) as i32;
        *dst.add(i) = ((a << 6) | (a >> 2)) as i16;
        i += 1;
    }
}

/// BGR24 -> YUV420P, matching `ff_rgb24toyv12_c`.
pub unsafe fn bgr24_to_yv12_neon(
    s1: *const u8,
    s2: *const u8,
    y1: *mut u8,
    y2: *mut u8,
    u: *mut u8,
    v: *mut u8,
    cw: usize,
) {
    let mut i = 0usize;
    while i + 8 <= cw {
        let px = 2 * i;
        let a = vld3q_u8(s1.add(px * 3));
        let b = vld3q_u8(s2.add(px * 3));
        // luma
        for (row, dstp) in [(a, y1), (b, y2)] {
            let (bb, gg, rr) = (row.0, row.1, row.2);
            let rl = vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(rr)));
            let rh = vreinterpretq_s16_u16(vmovl_high_u8(rr));
            let gl = vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(gg)));
            let gh = vreinterpretq_s16_u16(vmovl_high_u8(gg));
            let bl = vreinterpretq_s16_u16(vmovl_u8(vget_low_u8(bb)));
            let bh = vreinterpretq_s16_u16(vmovl_high_u8(bb));
            let a0 = vmlal_n_s16(
                vmlal_n_s16(
                    vmull_n_s16(vget_low_s16(rl), RY as i16),
                    vget_low_s16(gl),
                    GY as i16,
                ),
                vget_low_s16(bl),
                BY as i16,
            );
            let a1 = vmlal_high_n_s16(
                vmlal_high_n_s16(vmull_high_n_s16(rl, RY as i16), gl, GY as i16),
                bl,
                BY as i16,
            );
            let a2 = vmlal_n_s16(
                vmlal_n_s16(
                    vmull_n_s16(vget_low_s16(rh), RY as i16),
                    vget_low_s16(gh),
                    GY as i16,
                ),
                vget_low_s16(bh),
                BY as i16,
            );
            let a3 = vmlal_high_n_s16(
                vmlal_high_n_s16(vmull_high_n_s16(rh, RY as i16), gh, GY as i16),
                bh,
                BY as i16,
            );
            let sixteen = vdupq_n_s16(16);
            let lo = vaddq_s16(
                vcombine_s16(vshrn_n_s32(a0, 15), vshrn_n_s32(a1, 15)),
                sixteen,
            );
            let hi = vaddq_s16(
                vcombine_s16(vshrn_n_s32(a2, 15), vshrn_n_s32(a3, 15)),
                sixteen,
            );
            vst1q_u8(
                dstp.add(px),
                vcombine_u8(vqmovun_s16(lo), vqmovun_s16(hi)),
            );
        }
        // chroma: 2x2 average
        let rs = vshrq_n_u16(vaddq_u16(vpaddlq_u8(a.2), vpaddlq_u8(b.2)), 2);
        let gs = vshrq_n_u16(vaddq_u16(vpaddlq_u8(a.1), vpaddlq_u8(b.1)), 2);
        let bs = vshrq_n_u16(vaddq_u16(vpaddlq_u8(a.0), vpaddlq_u8(b.0)), 2);
        let r16 = vreinterpretq_s16_u16(rs);
        let g16 = vreinterpretq_s16_u16(gs);
        let b16 = vreinterpretq_s16_u16(bs);
        let cu0 = vmlal_n_s16(
            vmlal_n_s16(
                vmull_n_s16(vget_low_s16(r16), RU as i16),
                vget_low_s16(g16),
                GU as i16,
            ),
            vget_low_s16(b16),
            BU as i16,
        );
        let cu1 = vmlal_high_n_s16(
            vmlal_high_n_s16(vmull_high_n_s16(r16, RU as i16), g16, GU as i16),
            b16,
            BU as i16,
        );
        let cv0 = vmlal_n_s16(
            vmlal_n_s16(
                vmull_n_s16(vget_low_s16(r16), RV as i16),
                vget_low_s16(g16),
                GV as i16,
            ),
            vget_low_s16(b16),
            BV as i16,
        );
        let cv1 = vmlal_high_n_s16(
            vmlal_high_n_s16(vmull_high_n_s16(r16, RV as i16), g16, GV as i16),
            b16,
            BV as i16,
        );
        let c128 = vdupq_n_s16(128);
        let uu = vaddq_s16(
            vcombine_s16(vshrn_n_s32(cu0, 15), vshrn_n_s32(cu1, 15)),
            c128,
        );
        let vv = vaddq_s16(
            vcombine_s16(vshrn_n_s32(cv0, 15), vshrn_n_s32(cv1, 15)),
            c128,
        );
        vst1_u8(u.add(i), vqmovun_s16(uu));
        vst1_u8(v.add(i), vqmovun_s16(vv));
        i += 8;
    }
    while i < cw {
        let b11 = *s1.add(6 * i) as i32;
        let g11 = *s1.add(6 * i + 1) as i32;
        let r11 = *s1.add(6 * i + 2) as i32;
        let b12 = *s1.add(6 * i + 3) as i32;
        let g12 = *s1.add(6 * i + 4) as i32;
        let r12 = *s1.add(6 * i + 5) as i32;
        let b21 = *s2.add(6 * i) as i32;
        let g21 = *s2.add(6 * i + 1) as i32;
        let r21 = *s2.add(6 * i + 2) as i32;
        let b22 = *s2.add(6 * i + 3) as i32;
        let g22 = *s2.add(6 * i + 4) as i32;
        let r22 = *s2.add(6 * i + 5) as i32;
        *y1.add(2 * i) = (((RY * r11 + GY * g11 + BY * b11) >> 15) + 16) as u8;
        *y1.add(2 * i + 1) = (((RY * r12 + GY * g12 + BY * b12) >> 15) + 16) as u8;
        *y2.add(2 * i) = (((RY * r21 + GY * g21 + BY * b21) >> 15) + 16) as u8;
        *y2.add(2 * i + 1) = (((RY * r22 + GY * g22 + BY * b22) >> 15) + 16) as u8;
        let bx = (b11 + b12 + b21 + b22) >> 2;
        let gx = (g11 + g12 + g21 + g22) >> 2;
        let rx = (r11 + r12 + r21 + r22) >> 2;
        *u.add(i) = (((RU * rx + GU * gx + BU * bx) >> 15) + 128) as u8;
        *v.add(i) = (((RV * rx + GV * gx + BV * bx) >> 15) + 128) as u8;
        i += 1;
    }
}

/// GRAY8 -> packed RGB (unscaled, full-range luma) is an exact channel broadcast.
pub unsafe fn gray_to_rgb(fmt: i32, src: *const u8, dst: *mut u8, n: usize) {
    let step = bpp(fmt);
    let amask = vreinterpretq_u8_u32(vdupq_n_u32(0xFF00_0000));
    let mut i = 0usize;
    while i + 16 <= n {
        let g = vld1q_u8(src.add(i));
        let q = dst.add(i * step);
        if step == 3 {
            let ip = IG3.as_ptr();
            for k in 0..3 {
                vst1q_u8(q.add(k * 16), vqtbl1q_u8(g, vld1q_u8(ip.add(k * 16))));
            }
        } else {
            let ip = IG4.as_ptr();
            for k in 0..4 {
                vst1q_u8(
                    q.add(k * 16),
                    vorrq_u8(vqtbl1q_u8(g, vld1q_u8(ip.add(k * 16))), amask),
                );
            }
        }
        i += 16;
    }
    while i < n {
        let g = *src.add(i);
        let d = dst.add(i * step);
        *d = g;
        *d.add(1) = g;
        *d.add(2) = g;
        if step == 4 {
            *d.add(3) = 255;
        }
        i += 1;
    }
}

#[inline(always)]
unsafe fn nv12cx_n<const FS: usize>(
    swap: bool,
    f: &[i16],
    su: &[*const i16],
    sv: &[*const i16],
    dst: *mut u8,
    n: usize,
) {
    let base = vdupq_n_s32(64 << 12);
    let mut fc = [0i16; FS];
    let mut up = [std::ptr::null::<i16>(); FS];
    let mut vp = [std::ptr::null::<i16>(); FS];
    for j in 0..FS {
        fc[j] = f[j];
        up[j] = su[j];
        vp[j] = sv[j];
    }
    let mut i = 0usize;
    while i + 8 <= n {
        let mut uu = [vdupq_n_s32(0); 2];
        let mut vv = [vdupq_n_s32(0); 2];
        for k in 0..2 {
            let o = i + k * 4;
            let mut u = base;
            let mut v = base;
            for j in 0..FS {
                u = vmlal_n_s16(u, vld1_s16(up[j].add(o)), fc[j]);
                v = vmlal_n_s16(v, vld1_s16(vp[j].add(o)), fc[j]);
            }
            uu[k] = vshrq_n_s32(u, 16);
            vv[k] = vshrq_n_s32(v, 16);
        }
        let u8v = vqshrun_n_s16(vcombine_s16(vmovn_s32(uu[0]), vmovn_s32(uu[1])), 3);
        let v8v = vqshrun_n_s16(vcombine_s16(vmovn_s32(vv[0]), vmovn_s32(vv[1])), 3);
        if swap {
            vst2_u8(dst.add(2 * i), uint8x8x2_t(v8v, u8v));
        } else {
            vst2_u8(dst.add(2 * i), uint8x8x2_t(u8v, v8v));
        }
        i += 8;
    }
    while i < n {
        let mut u: i32 = 64 << 12;
        let mut v: i32 = 64 << 12;
        for j in 0..FS {
            u += *up[j].add(i) as i32 * fc[j] as i32;
            v += *vp[j].add(i) as i32 * fc[j] as i32;
        }
        let (a, b) = if swap {
            (clip_u8(v >> 19), clip_u8(u >> 19))
        } else {
            (clip_u8(u >> 19), clip_u8(v >> 19))
        };
        *dst.add(2 * i) = a;
        *dst.add(2 * i + 1) = b;
        i += 1;
    }
}

/// Point-sampled byte gather: dst[i] = src[pos[i]].
pub unsafe fn gather_point(src: *const u8, dst: *mut u8, n: usize, f: &crate::filter::Filter) {
    let gb = f.gbase.as_ptr();
    let gi = f.gidx.as_ptr();
    let po = f.pos.as_ptr();
    let mut i = 0usize;
    for g in 0..f.gbase.len() {
        let b = *gb.add(g);
        if b < 0 {
            break;
        }
        let p = src.add(b as usize);
        let t = uint8x16x4_t(
            vld1q_u8(p),
            vld1q_u8(p.add(16)),
            vld1q_u8(p.add(32)),
            vld1q_u8(p.add(48)),
        );
        vst1q_u8(dst.add(g * 16), vqtbl4q_u8(t, vld1q_u8(gi.add(g * 16))));
        i = g * 16 + 16;
    }
    while i < n {
        *dst.add(i) = *src.add(*po.add(i) as usize);
        i += 1;
    }
}

// ── limited/full range conversion of the 15-bit intermediates ───────────────

#[inline(always)]
unsafe fn range_scale(dst: *mut i16, n: usize, clamp: i16, mul: i16, add: i32, sh: i32) {
    let mut i = 0usize;
    let lim = vdupq_n_s16(clamp);
    let off = vdupq_n_s32(add);
    while i + 8 <= n {
        let v = vld1q_s16(dst.add(i));
        let v = if clamp > 0 { vminq_s16(v, lim) } else { v };
        let lo = vaddq_s32(vmull_n_s16(vget_low_s16(v), mul), off);
        let hi = vaddq_s32(vmull_high_n_s16(v, mul), off);
        let r = if sh == 14 {
            vcombine_s16(vshrn_n_s32(lo, 14), vshrn_n_s32(hi, 14))
        } else if sh == 12 {
            vcombine_s16(vshrn_n_s32(lo, 12), vshrn_n_s32(hi, 12))
        } else {
            vcombine_s16(vshrn_n_s32(lo, 11), vshrn_n_s32(hi, 11))
        };
        vst1q_s16(dst.add(i), r);
        i += 8;
    }
    while i < n {
        let mut v = *dst.add(i) as i32;
        if clamp > 0 {
            v = v.min(clamp as i32);
        }
        *dst.add(i) = ((v * mul as i32 + add) >> sh) as i16;
        i += 1;
    }
}

pub unsafe fn lum_range_to_jpeg_neon(dst: *mut i16, n: usize) {
    range_scale(dst, n, 30189, 19077, -39057361, 14);
}

pub unsafe fn lum_range_from_jpeg_neon(dst: *mut i16, n: usize) {
    range_scale(dst, n, 0, 14071, 33561947, 14);
}

pub unsafe fn chr_range_to_jpeg_neon(dst: *mut i16, n: usize) {
    range_scale(dst, n, 30775, 4663, -9289992, 12);
}

pub unsafe fn chr_range_from_jpeg_neon(dst: *mut i16, n: usize) {
    range_scale(dst, n, 0, 1799, 4081085, 11);
}
