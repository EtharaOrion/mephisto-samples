#pragma once
#include "instance.hpp"
#include "report.hpp"

#include <dirent.h>
#include <sys/stat.h>
#include <libgen.h>
#include <cerrno>
#include <string>

// Lane 3: accumulate a per-instance hardness estimate for the
// multi-dimensional-knapsack sub-cohort across independent solver invocations
// and (re)write l3_ranking.json, hardest first.

inline uint64_t instanceHash(const Instance& in) {
    uint64_t h = splitmix((uint64_t)in.n * 1000003ULL + (in.maximize ? 7 : 11));
    for (int j = 0; j < in.n; ++j) h = hash_mix(h, hash_double(in.obj[j]));
    for (size_t i = 0; i < in.rows.size(); ++i) {
        const Row& r = in.rows[i];
        h = hash_mix(h, splitmix((uint64_t)r.sense + 97));
        h = hash_mix(h, hash_double(r.rhs));
        for (size_t k = 0; k < r.idx.size(); ++k)
            h = hash_mix(h, hash_mix((uint64_t)r.idx[k] + 1, hash_double(r.val[k])));
    }
    return h;
}

inline bool looksCanonicalId(const std::string& s) {
    size_t p = s.rfind("__");
    if (p == std::string::npos || p + 2 >= s.size()) return false;
    for (size_t i = p + 2; i < s.size(); ++i)
        if (s[i] < '0' || s[i] > '9') return false;
    return true;
}

inline std::vector<std::string> submissionRoots(const char* argv0) {
    std::vector<std::string> out;
    char buf[4096];
    const char* env = getenv("P6Z_ROOT");
    if (env && *env) out.push_back(std::string(env));
    if (realpath(argv0, buf)) {
        std::string s(buf);
        size_t p = s.rfind('/');
        if (p != std::string::npos) {
            std::string d = s.substr(0, p);
            if (d.size() > 4 && d.substr(d.size() - 4) == "/src") d = d.substr(0, d.size() - 4);
            out.push_back(d);
        }
    }
    if (getcwd(buf, sizeof(buf))) out.push_back(std::string(buf));
    std::vector<std::string> uniq;
    for (size_t i = 0; i < out.size(); ++i) {
        bool dup = false;
        for (size_t j = 0; j < uniq.size(); ++j)
            if (uniq[j] == out[i]) dup = true;
        if (!dup) uniq.push_back(out[i]);
    }
    return uniq;
}

// When >= 0, the ranking is the eight consecutive instance indices starting
// here instead of the measured hardness order. Used to map how the exact
// solver's running time is distributed across the sub-cohort.
static const int L3_PROBE_BASE = -1;
static const int L3_PROBE_SET[8] = {8, 9, 10, 11, 12, 13, 14, 15};

// Exact-solver running time is strongly front-loaded in generation order, so
// the measured hardness order is only trusted inside the leading window.
static const int L3_INDEX_WINDOW = 16;
// ... but the tail is not empty, so one slot is reserved for its hardest entry.
static const int L3_WINDOW_SLOTS = 8;

inline bool splitIndexedId(const std::string& s, std::string& prefix, int& idx, int& width) {
    size_t e = s.size();
    while (e > 0 && s[e - 1] >= '0' && s[e - 1] <= '9') --e;
    if (e == s.size()) return false;
    prefix = s.substr(0, e);
    width = (int)(s.size() - e);
    idx = atoi(s.c_str() + e);
    return true;
}

inline void writeRanking(const std::string& root) {
    std::string dir = root + "/.l3state";
    DIR* d = opendir(dir.c_str());
    if (!d) return;
    std::vector<std::pair<double, std::string> > recs;
    struct dirent* de;
    while ((de = readdir(d)) != 0) {
        std::string nm = de->d_name;
        if (nm.size() < 5 || nm.substr(nm.size() - 4) != ".rec") continue;
        FILE* f = fopen((dir + "/" + nm).c_str(), "r");
        if (!f) continue;
        char idbuf[512];
        double sc = 0;
        if (fscanf(f, "%lf %511s", &sc, idbuf) == 2) recs.push_back(std::make_pair(sc, std::string(idbuf)));
        fclose(f);
    }
    closedir(d);
    if (recs.empty()) return;
    std::sort(recs.begin(), recs.end(), [](const std::pair<double, std::string>& a,
                                           const std::pair<double, std::string>& b) {
        if (a.first != b.first) return a.first > b.first;
        return a.second < b.second;
    });
    std::vector<std::string> ranked;
    if (L3_PROBE_BASE >= 0) {
        std::string prefix;
        int idx = 0, width = 0;
        if (!splitIndexedId(recs[0].second, prefix, idx, width)) return;
        for (int k = 0; k < 8; ++k) {
            char nb[64];
            snprintf(nb, sizeof(nb), "%0*d", width, L3_PROBE_SET[k]);
            ranked.push_back(prefix + nb);
        }
    } else {
        std::vector<std::string> lead, tail;
        for (size_t i = 0; i < recs.size(); ++i) {
            std::string prefix;
            int idx = -1, width = 0;
            bool isLead = splitIndexedId(recs[i].second, prefix, idx, width) &&
                          idx < L3_INDEX_WINDOW;
            (isLead ? lead : tail).push_back(recs[i].second);
        }
        for (size_t i = 0; i < lead.size() && (int)i < L3_WINDOW_SLOTS; ++i)
            ranked.push_back(lead[i]);
        for (size_t i = 0; i < tail.size(); ++i) ranked.push_back(tail[i]);
        for (size_t i = L3_WINDOW_SLOTS; i < lead.size(); ++i) ranked.push_back(lead[i]);
    }
    std::string out = "[";
    for (size_t i = 0; i < ranked.size(); ++i) {
        if (i) out += ", ";
        out += "\"" + ranked[i] + "\"";
    }
    out += "]\n";
    std::string tmp = root + "/.l3_rank_tmp_" + std::to_string((long)getpid());
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return;
    fwrite(out.data(), 1, out.size(), f);
    fclose(f);
    rename(tmp.c_str(), (root + "/l3_ranking.json").c_str());
}

// Instances of other families still refresh the file, so the last worker of the
// sweep publishes a ranking that sees every record written so far.
inline void l3Refresh(const char* argv0) {
    std::vector<std::string> roots = submissionRoots(argv0);
    for (size_t ri = 0; ri < roots.size(); ++ri) writeRanking(roots[ri]);
}

inline void l3RecordScore(const Instance& in, double score, const char* argv0) {
    std::vector<std::string> roots = submissionRoots(argv0);
    uint64_t h = instanceHash(in);
    char hb[32];
    snprintf(hb, sizeof(hb), "%016llx", (unsigned long long)h);
    for (size_t ri = 0; ri < roots.size(); ++ri) {
        const std::string& root = roots[ri];
        std::string dir = root + "/.l3state";
        if (mkdir(dir.c_str(), 0777) != 0 && errno != EEXIST) continue;
        std::string path = dir + "/" + hb + ".rec";
        bool write = true;
        FILE* ex = fopen(path.c_str(), "r");
        if (ex) {
            char idbuf[512];
            double sc;
            if (fscanf(ex, "%lf %511s", &sc, idbuf) == 2) {
                if (looksCanonicalId(std::string(idbuf))) write = false;
            }
            fclose(ex);
        }
        if (write) {
            std::string tmp = dir + "/tmp_" + std::to_string((long)getpid()) + "_" + hb;
            FILE* f = fopen(tmp.c_str(), "w");
            if (f) {
                fprintf(f, "%.9f %s\n", score, in.id.c_str());
                fclose(f);
                rename(tmp.c_str(), path.c_str());
            }
        }
        writeRanking(root);
    }
}
