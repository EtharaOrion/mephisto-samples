#pragma once
#include "util.hpp"

// Bounded-variable primal simplex for   max c'x  s.t.  Ax <= b, 0 <= x <= 1
// with a small number of rows (dense basis inverse).

struct BoundedLP {
    int n = 0, m = 0;
    const std::vector<std::vector<double> >* A = 0;  // m x n
    std::vector<double> b, c;
    std::vector<double> loB, upB;  // per-variable bounds; empty means [0,1]

    std::vector<double> x;   // primal values, length n
    std::vector<double> y;   // row duals (>= 0), length m
    std::vector<double> dj;  // reduced costs, length n
    double obj = 0.0;
    bool ok = false;

    std::vector<int> basis;     // length m, variable index (j<n: x, n+i: slack i)
    std::vector<char> atUpper;  // for nonbasic variables
    std::vector<char> isBasic;
    std::vector<double> Binv;   // m x m
    std::vector<double> xB;

    double lo(int j) const { return (j < n && !loB.empty()) ? loB[j] : 0.0; }
    double up(int j) const {
        if (j >= n) return 1e30;
        return upB.empty() ? 1.0 : upB[j];
    }
    bool frozen(int j) const { return j < n && up(j) - lo(j) < 1e-12; }
    double cost(int j) const { return j < n ? c[j] : 0.0; }

    void colOf(int j, std::vector<double>& out) const {
        out.assign(m, 0.0);
        if (j < n) {
            for (int i = 0; i < m; ++i) out[i] = (*A)[i][j];
        } else out[j - n] = 1.0;
    }

    bool refactor() {
        // Binv = inverse of basis matrix
        std::vector<double> Mx((size_t)m * 2 * m, 0.0);
        std::vector<double> colbuf;
        for (int k = 0; k < m; ++k) {
            colOf(basis[k], colbuf);
            for (int i = 0; i < m; ++i) Mx[(size_t)i * 2 * m + k] = colbuf[i];
        }
        for (int i = 0; i < m; ++i) Mx[(size_t)i * 2 * m + m + i] = 1.0;
        for (int col = 0; col < m; ++col) {
            int piv = -1;
            double bestv = 1e-9;
            for (int r = col; r < m; ++r) {
                double v = std::fabs(Mx[(size_t)r * 2 * m + col]);
                if (v > bestv) { bestv = v; piv = r; }
            }
            if (piv < 0) return false;
            if (piv != col)
                for (int k = 0; k < 2 * m; ++k)
                    std::swap(Mx[(size_t)col * 2 * m + k], Mx[(size_t)piv * 2 * m + k]);
            double p = Mx[(size_t)col * 2 * m + col];
            for (int k = 0; k < 2 * m; ++k) Mx[(size_t)col * 2 * m + k] /= p;
            for (int r = 0; r < m; ++r) {
                if (r == col) continue;
                double f = Mx[(size_t)r * 2 * m + col];
                if (f == 0.0) continue;
                for (int k = 0; k < 2 * m; ++k)
                    Mx[(size_t)r * 2 * m + k] -= f * Mx[(size_t)col * 2 * m + k];
            }
        }
        Binv.assign((size_t)m * m, 0.0);
        for (int i = 0; i < m; ++i)
            for (int k = 0; k < m; ++k) Binv[(size_t)i * m + k] = Mx[(size_t)i * 2 * m + m + k];
        return true;
    }

    void computeXB() {
        std::vector<double> rhs(m);
        for (int i = 0; i < m; ++i) rhs[i] = b[i];
        for (int j = 0; j < n + m; ++j) {
            if (isBasic[j]) continue;
            double v = atUpper[j] ? up(j) : lo(j);
            if (v == 0.0) continue;
            if (j < n) {
                for (int i = 0; i < m; ++i) rhs[i] -= (*A)[i][j] * v;
            } else rhs[j - n] -= v;
        }
        xB.assign(m, 0.0);
        for (int i = 0; i < m; ++i) {
            double s = 0.0;
            for (int k = 0; k < m; ++k) s += Binv[(size_t)i * m + k] * rhs[k];
            xB[i] = s;
        }
    }

    std::vector<double> At;  // n x m, column-major copy of A for fast pricing

    void buildAt() {
        At.assign((size_t)n * m, 0.0);
        for (int i = 0; i < m; ++i)
            for (int j = 0; j < n; ++j) At[(size_t)j * m + i] = (*A)[i][j];
    }

    // Rank-one update of Binv and xB for a pivot on row `leave`.
    bool pivotOn(int leave, int enter, const std::vector<double>& alpha) {
        double piv = alpha[leave];
        if (std::fabs(piv) < 1e-12) return false;
        for (int k = 0; k < m; ++k) Binv[(size_t)leave * m + k] /= piv;
        for (int i = 0; i < m; ++i) {
            if (i == leave) continue;
            double f = alpha[i];
            if (f == 0.0) continue;
            for (int k = 0; k < m; ++k)
                Binv[(size_t)i * m + k] -= f * Binv[(size_t)leave * m + k];
        }
        (void)enter;
        return true;
    }

    void computeDuals(std::vector<double>& cB) {
        for (int i = 0; i < m; ++i) cB[i] = cost(basis[i]);
        y.assign(m, 0.0);
        for (int k = 0; k < m; ++k) {
            double s = 0.0;
            for (int i = 0; i < m; ++i) s += cB[i] * Binv[(size_t)i * m + k];
            y[k] = s;
        }
        dj.assign(n, 0.0);
        const double* pAt = At.data();
        for (int j = 0; j < n; ++j) {
            if (isBasic[j]) continue;
            const double* col = pAt + (size_t)j * m;
            double d = c[j];
            for (int i = 0; i < m; ++i) d -= y[i] * col[i];
            dj[j] = d;
        }
    }

    // Dual simplex: the loaded basis is dual feasible but bound changes may have
    // pushed basic variables outside their range. Returns false if the node is
    // primal infeasible.
    // 1 = primal feasible, 0 = proved infeasible, -1 = iteration limit
    int dualIterate(int maxIter) {
        std::vector<double> cB(m), rho(m), alpha(m), colbuf(m);
        for (int iter = 0; iter < maxIter; ++iter) {
            int r = -1;
            double worst = 1e-7, sgn = 0;
            for (int i = 0; i < m; ++i) {
                int bj = basis[i];
                double v = lo(bj) - xB[i];
                if (v > worst) { worst = v; r = i; sgn = 1.0; }
                double w = xB[i] - up(bj);
                if (w > worst) { worst = w; r = i; sgn = -1.0; }
            }
            if (r < 0) return 1;
            computeDuals(cB);
            for (int k = 0; k < m; ++k) rho[k] = Binv[(size_t)r * m + k];
            int enter = -1;
            double bestRatio = 1e300, bestPiv = 0.0;
            const double* pAt = At.data();
            for (int j = 0; j < n + m; ++j) {
                if (isBasic[j] || frozen(j)) continue;
                double aj;
                if (j < n) {
                    const double* col = pAt + (size_t)j * m;
                    double s = 0.0;
                    for (int i = 0; i < m; ++i) s += rho[i] * col[i];
                    aj = s;
                } else aj = rho[j - n];
                if (std::fabs(aj) < 1e-9) continue;
                double want = atUpper[j] ? aj : -aj;  // sign of the xB[r] change
                if (want * sgn <= 0) continue;
                double d = j < n ? dj[j] : -y[j - n];
                double ratio = std::fabs(d) / std::fabs(aj);
                if (ratio < bestRatio - 1e-12 ||
                    (ratio < bestRatio + 1e-12 && std::fabs(aj) > bestPiv)) {
                    bestRatio = ratio;
                    bestPiv = std::fabs(aj);
                    enter = j;
                }
            }
            if (enter < 0) return 0;
            colOf(enter, colbuf);
            for (int i = 0; i < m; ++i) {
                double s = 0.0;
                for (int k = 0; k < m; ++k) s += Binv[(size_t)i * m + k] * colbuf[k];
                alpha[i] = s;
            }
            int lv = basis[r];
            double target = sgn > 0 ? lo(lv) : up(lv);
            double step = (target - xB[r]) / (atUpper[enter] ? alpha[r] : -alpha[r]);
            double enterVal = (atUpper[enter] ? up(enter) : lo(enter)) +
                              (atUpper[enter] ? -step : step);
            for (int i = 0; i < m; ++i)
                xB[i] -= (atUpper[enter] ? -step : step) * alpha[i];
            isBasic[lv] = 0;
            atUpper[lv] = sgn > 0 ? 0 : 1;
            basis[r] = enter;
            isBasic[enter] = 1;
            atUpper[enter] = 0;
            if (!pivotOn(r, enter, alpha)) {
                if (!refactor()) return -1;
                computeXB();
            } else xB[r] = enterVal;
        }
        return -1;
    }

    void finishSolution() {
        x.assign(n, 0.0);
        for (int j = 0; j < n; ++j)
            if (!isBasic[j]) x[j] = atUpper[j] ? up(j) : lo(j);
        for (int i = 0; i < m; ++i)
            if (basis[i] < n) x[basis[i]] = xB[i];
        for (int j = 0; j < n; ++j) {
            if (x[j] < lo(j)) x[j] = lo(j);
            if (x[j] > up(j)) x[j] = up(j);
        }
        obj = 0.0;
        for (int j = 0; j < n; ++j) obj += c[j] * x[j];
        for (int i = 0; i < m; ++i)
            if (y[i] < 0) y[i] = 0.0;
        ok = true;
    }

    // Re-optimise from the basis currently held after a bound change.
    bool resolveWarm(int maxIter) {
        if (At.size() != (size_t)n * m) buildAt();
        if ((int)basis.size() != m) return solve(maxIter);
        for (int j = 0; j < n; ++j)
            if (!isBasic[j] && frozen(j)) atUpper[j] = 0;
        if (!refactor()) return solve(maxIter);
        computeXB();
        int st = dualIterate(4 * m + 200);
        if (st == 0) { ok = false; return false; }
        if (st < 0) return solve(maxIter);
        return primalIterate(maxIter);
    }

    bool solve(int maxIter = 20000) {
        if (At.size() != (size_t)n * m) buildAt();
        int N = n + m;
        basis.resize(m);
        isBasic.assign(N, 0);
        atUpper.assign(N, 0);
        for (int i = 0; i < m; ++i) {
            basis[i] = n + i;
            isBasic[n + i] = 1;
        }
        Binv.assign((size_t)m * m, 0.0);
        for (int i = 0; i < m; ++i) Binv[(size_t)i * m + i] = 1.0;
        computeXB();
        return primalIterate(maxIter);
    }

    bool primalIterate(int maxIter) {
        std::vector<double> alpha(m), colbuf(m), cB(m);
        int sinceRef = 0;
        for (int iter = 0; iter < maxIter; ++iter) {
            for (int i = 0; i < m; ++i) cB[i] = cost(basis[i]);
            y.assign(m, 0.0);
            for (int k = 0; k < m; ++k) {
                double s = 0.0;
                for (int i = 0; i < m; ++i) s += cB[i] * Binv[(size_t)i * m + k];
                y[k] = s;
            }
            int enter = -1;
            double bestd = 1e-7;
            dj.assign(n, 0.0);
            const double* pAt = At.data();
            for (int j = 0; j < n; ++j) {
                if (isBasic[j] || frozen(j)) continue;
                const double* col = pAt + (size_t)j * m;
                double d = c[j];
                for (int i = 0; i < m; ++i) d -= y[i] * col[i];
                dj[j] = d;
                double score = atUpper[j] ? -d : d;
                if (score > bestd) { bestd = score; enter = j; }
            }
            for (int i = 0; i < m; ++i) {
                if (isBasic[n + i]) continue;
                double d = -y[i];
                double score = atUpper[n + i] ? -d : d;
                if (score > bestd) { bestd = score; enter = n + i; }
            }
            if (enter < 0) break;
            colOf(enter, colbuf);
            for (int i = 0; i < m; ++i) {
                double s = 0.0;
                for (int k = 0; k < m; ++k) s += Binv[(size_t)i * m + k] * colbuf[k];
                alpha[i] = s;
            }
            double delta = atUpper[enter] ? -1.0 : 1.0;
            double t = up(enter) - lo(enter);
            int leave = -1;
            bool leaveAtUpper = false;
            for (int i = 0; i < m; ++i) {
                double a = delta * alpha[i];
                int bj = basis[i];
                if (a > 1e-9) {
                    double lim = (xB[i] - lo(bj)) / a;
                    if (lim < t - 1e-12) { t = lim; leave = i; leaveAtUpper = false; }
                } else if (a < -1e-9) {
                    double ub = up(bj);
                    if (ub > 1e29) continue;
                    double lim = (ub - xB[i]) / (-a);
                    if (lim < t - 1e-12) { t = lim; leave = i; leaveAtUpper = true; }
                }
            }
            if (t > 1e29) { ok = false; return false; }
            if (t < 0) t = 0;
            for (int i = 0; i < m; ++i) xB[i] -= delta * alpha[i] * t;
            if (leave < 0) {
                atUpper[enter] = atUpper[enter] ? 0 : 1;
            } else {
                int lv = basis[leave];
                isBasic[lv] = 0;
                atUpper[lv] = leaveAtUpper ? 1 : 0;
                basis[leave] = enter;
                isBasic[enter] = 1;
                atUpper[enter] = 0;
                double xnew = (delta > 0 ? lo(enter) : up(enter)) + delta * t;
                xB[leave] = xnew;
                double piv = alpha[leave];
                if (std::fabs(piv) < 1e-12) {
                    if (!refactor()) { ok = false; return false; }
                    computeXB();
                    sinceRef = 0;
                    continue;
                }
                for (int k = 0; k < m; ++k) Binv[(size_t)leave * m + k] /= piv;
                for (int i = 0; i < m; ++i) {
                    if (i == leave) continue;
                    double f = alpha[i];
                    if (f == 0.0) continue;
                    for (int k = 0; k < m; ++k)
                        Binv[(size_t)i * m + k] -= f * Binv[(size_t)leave * m + k];
                }
                if (++sinceRef >= 40) {
                    if (refactor()) computeXB();
                    sinceRef = 0;
                }
            }
        }
        finishSolution();
        return true;
    }
};
