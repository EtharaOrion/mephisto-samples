#pragma once
#include "instance.hpp"
#include "report.hpp"
#include "lp.hpp"

// Multi-dimensional knapsack.
//   * LP relaxation (bounded simplex) -> duals, upper bound, reduced-cost fixing
//   * iterated greedy / exchange local search for a strong incumbent
//   * surrogate-bounded depth-first branch and bound, used either on the whole
//     reduced core (proves optimality) or as the repair step of a large
//     neighbourhood search.

static double g_mdkpDiff = 0.0;
static bool g_mdkpHave = false;

struct MkpData {
    int n = 0, m = 0;
    std::vector<std::vector<double> > A;  // m x n
    std::vector<double> b, p;
    std::vector<double> y;
    double ub = 1e300;
};

inline bool extractMKP(const Instance& in, MkpData& M) {
    if (!in.maximize) return false;
    int n = in.n;
    int m = (int)in.rows.size();
    if (m < 1) return false;
    for (int i = 0; i < m; ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_LE) return false;
        for (size_t k = 0; k < r.val.size(); ++k)
            if (r.val[k] < 0) return false;
        if (r.rhs < 0) return false;
    }
    for (int j = 0; j < n; ++j)
        if (in.obj[j] < 0) return false;
    M.n = n;
    M.m = m;
    M.A.assign(m, std::vector<double>(n, 0.0));
    M.b.resize(m);
    M.p.resize(n);
    for (int i = 0; i < m; ++i) {
        const Row& r = in.rows[i];
        for (size_t k = 0; k < r.idx.size(); ++k) M.A[i][r.idx[k]] = r.val[k];
        M.b[i] = r.rhs;
    }
    for (int j = 0; j < n; ++j) M.p[j] = in.obj[j];
    return true;
}

inline double lagrangianBound(const MkpData& M, const std::vector<double>& y) {
    double v = 0.0;
    for (int i = 0; i < M.m; ++i) v += y[i] * M.b[i];
    for (int j = 0; j < M.n; ++j) {
        double rc = M.p[j];
        for (int i = 0; i < M.m; ++i) rc -= y[i] * M.A[i][j];
        if (rc > 0) v += rc;
    }
    return v;
}

inline void lagrangianSolve(MkpData& M, double incumbent, double deadline, int iters) {
    int n = M.n, m = M.m;
    M.y.assign(m, 0.0);
    double sump = 0.0;
    for (int j = 0; j < n; ++j) sump += M.p[j];
    for (int i = 0; i < m; ++i) {
        double sa = 0.0;
        for (int j = 0; j < n; ++j) sa += M.A[i][j];
        M.y[i] = (sa > 0) ? (sump / (sa * m)) * 0.5 : 0.0;
    }
    std::vector<double> best = M.y;
    double bestUB = lagrangianBound(M, M.y);
    double lambda = 2.0;
    std::vector<int> xb(n);
    std::vector<double> g(m);
    int noImp = 0;
    for (int it = 0; it < iters; ++it) {
        if ((it & 15) == 0 && now_s() > deadline) break;
        for (int j = 0; j < n; ++j) {
            double rc = M.p[j];
            for (int i = 0; i < m; ++i) rc -= M.y[i] * M.A[i][j];
            xb[j] = rc > 0 ? 1 : 0;
        }
        double ub = lagrangianBound(M, M.y);
        if (ub < bestUB) {
            bestUB = ub;
            best = M.y;
            noImp = 0;
        } else if (++noImp > 20) {
            lambda *= 0.7;
            noImp = 0;
            if (lambda < 1e-4) break;
        }
        double gn = 0.0;
        for (int i = 0; i < m; ++i) {
            double s = -M.b[i];
            for (int j = 0; j < n; ++j)
                if (xb[j]) s += M.A[i][j];
            g[i] = s;
            gn += s * s;
        }
        if (gn < 1e-12) break;
        double target = incumbent > 0 ? incumbent : ub * 0.9;
        double step = lambda * (ub - target) / gn;
        if (step <= 0) step = lambda * std::fabs(ub) * 1e-6 / gn;
        for (int i = 0; i < m; ++i) {
            M.y[i] += step * g[i];
            if (M.y[i] < 0) M.y[i] = 0.0;
        }
    }
    M.y = best;
    if (bestUB < M.ub) M.ub = bestUB;
}

// --------------------------------------------------------------- incumbent LS

struct MkpLS {
    const MkpData* M;
    std::vector<int> x;
    std::vector<double> use;
    double val = 0.0;

    void init(const MkpData& m) {
        M = &m;
        x.assign(M->n, 0);
        use.assign(M->m, 0.0);
        val = 0.0;
    }
    bool fits(int j) const {
        for (int i = 0; i < M->m; ++i)
            if (use[i] + M->A[i][j] > M->b[i] + 1e-9) return false;
        return true;
    }
    void add(int j) {
        for (int i = 0; i < M->m; ++i) use[i] += M->A[i][j];
        val += M->p[j];
        x[j] = 1;
    }
    void del(int j) {
        for (int i = 0; i < M->m; ++i) use[i] -= M->A[i][j];
        val -= M->p[j];
        x[j] = 0;
    }
};

// -------------------------------------------------- surrogate-bounded B&B core

struct MkpBB {
    int m = 0, K = 0;
    std::vector<double> sw, sp;
    std::vector<std::vector<double> > col;  // m x K
    std::vector<double> PW, PP;
    std::vector<double> cap;
    std::vector<int> pick, bestPick;
    double Csur = 0.0, best = 0.0, curProfit = 0.0;
    bool integral = false, timeout = false, improved = false;
    long long nodes = 0, nodeCap = (long long)9e18;
    double deadline = 1e18;

    // items: item ids, order must already be by surrogate ratio (descending)
    void prepare(const MkpData& M, const std::vector<int>& items, const std::vector<double>& swAll,
                 const std::vector<double>& capLeft, const std::vector<double>& yy) {
        m = M.m;
        K = (int)items.size();
        sw.resize(K);
        sp.resize(K);
        col.assign(m, std::vector<double>(K, 0.0));
        for (int k = 0; k < K; ++k) {
            int j = items[k];
            sw[k] = swAll[j];
            sp[k] = M.p[j];
            for (int i = 0; i < m; ++i) col[i][k] = M.A[i][j];
        }
        PW.assign(K + 1, 0.0);
        PP.assign(K + 1, 0.0);
        for (int k = 0; k < K; ++k) {
            PW[k + 1] = PW[k] + sw[k];
            PP[k + 1] = PP[k] + sp[k];
        }
        cap = capLeft;
        Csur = 0.0;
        for (int i = 0; i < m; ++i) Csur += yy[i] * capLeft[i];
        pick.assign(K, 0);
        bestPick.clear();
        curProfit = 0.0;
        nodes = 0;
        timeout = false;
        improved = false;
    }

    double dantzig(int k, double capS) const {
        if (capS <= 1e-9) return 0.0;
        double target = PW[k] + capS;
        int lo = k, hi = K, s = k;
        while (lo <= hi) {
            int mid = (lo + hi) >> 1;
            if (PW[mid] <= target + 1e-9) { s = mid; lo = mid + 1; }
            else hi = mid - 1;
        }
        double v = PP[s] - PP[k];
        if (s < K && sw[s] > 1e-12) v += sp[s] * ((target - PW[s]) / sw[s]);
        return v;
    }

    void dfs(int k, double surUsed) {
        if (timeout) return;
        if ((++nodes & 511) == 0) {
            if (nodes > nodeCap || now_s() > deadline) { timeout = true; return; }
        }
        double bnd = curProfit + dantzig(k, Csur - surUsed);
        if (integral) bnd = std::floor(bnd + 1e-6);
        if (bnd <= best + 1e-9) return;
        if (k == K) {
            best = curProfit;
            bestPick = pick;
            improved = true;
            return;
        }
        bool ok = true;
        for (int i = 0; i < m; ++i)
            if (col[i][k] > cap[i] + 1e-9) { ok = false; break; }
        if (ok) {
            for (int i = 0; i < m; ++i) cap[i] -= col[i][k];
            curProfit += sp[k];
            pick[k] = 1;
            dfs(k + 1, surUsed + sw[k]);
            pick[k] = 0;
            curProfit -= sp[k];
            for (int i = 0; i < m; ++i) cap[i] += col[i][k];
            if (timeout) return;
        }
        dfs(k + 1, surUsed);
    }
};

// ----------------------------------------------- LP-based branch and bound
// Best-bound search with LP relaxations at every node. Doubles as the hardness
// probe for lane 3: the dual gap still open after a fixed budget is the
// closest available analogue of an exact solver's remaining work.

struct BnBResult {
    bool solved = false;
    long long nodes = 0;
    double dualBound = 1e300;
    double rootBound = 1e300;
    double seconds = 0.0;
};

struct BnBNode {
    int parent;
    int var;
    char val;
};

inline BnBResult mkpBranchAndBound(const MkpData& M, double& incumbent, std::vector<int>& bestX,
                                   bool integral, double deadline, Reporter* rep,
                                   const Instance* in, const std::vector<int>* rootFix) {
    BnBResult R;
    int n = M.n, m = M.m;
    BoundedLP lp;
    lp.n = n;
    lp.m = m;
    lp.A = &M.A;
    lp.b = M.b;
    lp.c = M.p;
    lp.loB.assign(n, 0.0);
    lp.upB.assign(n, 1.0);
    std::vector<double> baseCap = M.b;
    if (rootFix) {
        for (int j = 0; j < n; ++j) {
            int v = (*rootFix)[j];
            if (v < 0) continue;
            lp.loB[j] = lp.upB[j] = (double)v;
            if (v == 1)
                for (int i = 0; i < m; ++i) baseCap[i] -= M.A[i][j];
        }
        for (int i = 0; i < m; ++i)
            if (baseCap[i] < -1e-9) {
                R.solved = true;
                R.dualBound = incumbent;
                return R;
            }
    }

    std::vector<BnBNode> tree;
    tree.push_back(BnBNode{-1, -1, 0});
    // open list: (bound, node)
    std::vector<std::pair<double, int> > open;
    open.push_back(std::make_pair(1e300, 0));
    auto cmp = [](const std::pair<double, int>& a, const std::pair<double, int>& b) {
        return a.first < b.first;  // max-heap on bound
    };
    std::make_heap(open.begin(), open.end(), cmp);

    std::vector<int> fixv(n, -1);
    std::vector<int> touched;
    std::vector<double> capLeft(m);
    std::vector<int> nx(n, 0);
    bool noWarm = getenv("P6Z_NOWARM") != 0;

    while (!open.empty()) {
        if (now_s() > deadline) break;
        std::pop_heap(open.begin(), open.end(), cmp);
        std::pair<double, int> top = open.back();
        open.pop_back();
        if (top.first <= incumbent + (integral ? 1.0 - 1e-6 : 1e-9)) {
            R.solved = true;
            break;
        }
        // materialise fixings of the popped node
        touched.clear();
        for (int q = top.second; q > 0; q = tree[q].parent) {
            if (fixv[tree[q].var] < 0) {
                fixv[tree[q].var] = tree[q].val;
                touched.push_back(tree[q].var);
            }
        }
        for (int i = 0; i < m; ++i) capLeft[i] = baseCap[i];
        for (size_t t = 0; t < touched.size(); ++t) {
            int j = touched[t];
            lp.loB[j] = lp.upB[j] = (double)fixv[j];
            if (fixv[j] == 1)
                for (int i = 0; i < m; ++i) capLeft[i] -= M.A[i][j];
        }

        // Dive: each step fixes one more variable and re-optimises from the
        // basis in hand, so only the first node of a dive pays a cold solve.
        int cur = top.second;
        bool warm = false;
        while (now_s() <= deadline) {
            bool infeasible = false;
            for (int i = 0; i < m; ++i)
                if (capLeft[i] < -1e-9) infeasible = true;
            if (infeasible) break;
            bool solved = (warm && !noWarm) ? lp.resolveWarm(20000) : lp.solve(20000);
            if (!solved) break;
            ++R.nodes;
            warm = true;
            double bound = lp.obj;
            if (cur == 0) R.rootBound = bound;
            double cut = incumbent + (integral ? 1.0 - 1e-6 : 1e-9);
            if (bound <= cut) break;
            int frac = -1;
            double bestd = 0.5 - 1e-7;
            for (int j = 0; j < n; ++j) {
                if (fixv[j] >= 0 || (rootFix && (*rootFix)[j] >= 0)) continue;
                double v = lp.x[j];
                if (v > 1e-7 && v < 1 - 1e-7) {
                    double d = std::fabs(v - 0.5);
                    if (d < bestd) { bestd = d; frac = j; }
                }
            }
            if (frac < 0) {
                if (lp.obj > incumbent + 1e-9) {
                    for (int j = 0; j < n; ++j) nx[j] = lp.x[j] > 0.5 ? 1 : 0;
                    if (in && isFeasible(*in, nx)) {
                        incumbent = objValue(*in, nx);
                        bestX = nx;
                        if (rep) rep->update(bestX, incumbent);
                    }
                }
                break;
            }
            int down = (int)tree.size();
            tree.push_back(BnBNode{cur, frac, 0});
            int up = (int)tree.size();
            tree.push_back(BnBNode{cur, frac, 1});
            // dive towards 1, defer the 0 branch to the global frontier
            open.push_back(std::make_pair(bound, down));
            std::push_heap(open.begin(), open.end(), cmp);
            cur = up;
            fixv[frac] = 1;
            touched.push_back(frac);
            lp.loB[frac] = lp.upB[frac] = 1.0;
            for (int i = 0; i < m; ++i) capLeft[i] -= M.A[i][frac];
            if (tree.size() > 6000000u) break;
        }

        for (size_t t = 0; t < touched.size(); ++t) {
            lp.loB[touched[t]] = 0.0;
            lp.upB[touched[t]] = 1.0;
            fixv[touched[t]] = -1;
        }
        if (rootFix)
            for (int j = 0; j < n; ++j) {
                int v = (*rootFix)[j];
                if (v >= 0) lp.loB[j] = lp.upB[j] = (double)v;
            }
        if (tree.size() > 6000000u) break;
    }
    if (open.empty()) R.solved = true;
    R.dualBound = incumbent;
    for (size_t q = 0; q < open.size(); ++q) R.dualBound = std::max(R.dualBound, open[q].first);
    if (R.solved) R.dualBound = incumbent;
    return R;
}

inline bool tryMDKP(const Instance& in, double deadline, Reporter& rep) {
    if (!in.family.empty() && in.family != "multi-dimensional-knapsack") return false;
    MkpData M;
    if (!extractMKP(in, M)) return false;
    int n = M.n, m = M.m;
    if (n < 1) return false;

    Rng rng(20240517ULL);
    bool integral = true;
    for (int j = 0; j < n && integral; ++j)
        if (std::fabs(M.p[j] - std::floor(M.p[j] + 0.5)) > 1e-9) integral = false;

    auto greedyFill = [&](MkpLS& s, const std::vector<double>& sc, double noise) {
        std::vector<int> o(n);
        for (int j = 0; j < n; ++j) o[j] = j;
        std::vector<double> key(n);
        for (int j = 0; j < n; ++j) key[j] = sc[j] * (1.0 + noise * (rng.d01() - 0.5));
        std::sort(o.begin(), o.end(), [&](int a, int b) {
            if (key[a] != key[b]) return key[a] > key[b];
            return a < b;
        });
        for (int t = 0; t < n; ++t) {
            int j = o[t];
            if (!s.x[j] && s.fits(j)) s.add(j);
        }
    };

    MkpLS S;
    S.init(M);
    {
        std::vector<double> norm(n, 0.0);
        for (int j = 0; j < n; ++j) {
            double w = 0.0;
            for (int i = 0; i < m; ++i)
                if (M.b[i] > 0) w += M.A[i][j] / M.b[i];
            norm[j] = M.p[j] / (w + 1e-12);
        }
        greedyFill(S, norm, 0.0);
    }
    std::vector<int> bx = S.x;
    double bestVal = S.val;
    rep.update(bx, bestVal);

    // ------------------------------------------------------------ LP relaxation
    BoundedLP lp;
    lp.n = n;
    lp.m = m;
    lp.A = &M.A;
    lp.b = M.b;
    lp.c = M.p;
    bool lpOk = lp.solve(60000);
    if (dbg() && lpOk) {
        double worst = 0.0;
        for (int i = 0; i < m; ++i) {
            double a = 0.0;
            for (int j = 0; j < n; ++j) a += M.A[i][j] * lp.x[j];
            worst = std::max(worst, a - M.b[i]);
        }
        fprintf(stderr, "# lp obj=%.4f dualbound=%.4f maxviol=%.3g\n", lp.obj,
                lagrangianBound(M, lp.y), worst);
    }
    if (lpOk && lp.obj >= bestVal - 1e-6) {
        M.y = lp.y;
        M.ub = lp.obj;
    } else {
        lpOk = false;
        lagrangianSolve(M, bestVal, std::min(deadline, now_s() + 2.0), 5000);
    }

    std::vector<double> score(n);
    for (int j = 0; j < n; ++j) {
        double w = 0.0;
        for (int i = 0; i < m; ++i) w += M.y[i] * M.A[i][j];
        score[j] = M.p[j] / (w + 1e-9);
    }
    {
        MkpLS s2;
        s2.init(M);
        greedyFill(s2, score, 0.0);
        if (s2.val > bestVal) { bestVal = s2.val; bx = s2.x; S = s2; rep.update(bx, bestVal); }
    }
    if (lpOk) {
        MkpLS s3;
        s3.init(M);
        std::vector<double> byLp(n);
        for (int j = 0; j < n; ++j) byLp[j] = lp.x[j] * 1e9 + score[j];
        greedyFill(s3, byLp, 0.0);
        if (s3.val > bestVal) { bestVal = s3.val; bx = s3.x; S = s3; rep.update(bx, bestVal); }
    }

    std::vector<int> selected, unselected;
    auto descent = [&](MkpLS& s, double dl) {
        bool imp = true;
        while (imp) {
            imp = false;
            if (now_s() > dl) return;
            for (int j = 0; j < n; ++j)
                if (!s.x[j] && s.fits(j)) { s.add(j); imp = true; }
            selected.clear();
            unselected.clear();
            for (int j = 0; j < n; ++j) (s.x[j] ? selected : unselected).push_back(j);
            for (size_t a = 0; a < selected.size(); ++a) {
                int j = selected[a];
                if (!s.x[j]) continue;
                s.del(j);
                int bestk = -1;
                double bestg = 1e-9;
                for (size_t bq = 0; bq < unselected.size(); ++bq) {
                    int k = unselected[bq];
                    if (s.x[k]) continue;
                    double g = M.p[k] - M.p[j];
                    if (g <= bestg) continue;
                    if (!s.fits(k)) continue;
                    bestg = g;
                    bestk = k;
                }
                if (bestk >= 0) { s.add(bestk); imp = true; }
                else s.add(j);
            }
        }
    };

    descent(S, deadline);
    if (S.val > bestVal) { bestVal = S.val; bx = S.x; rep.update(bx, bestVal); }

    // ------------------------------------------------------ short ILS warm-up
    double phase1 = std::min(deadline, now_s() + (deadline - now_s()) * 0.15);
    MkpLS cur = S;
    while (now_s() < phase1) {
        MkpLS s = cur;
        int nsel = 0;
        for (int j = 0; j < n; ++j) nsel += s.x[j];
        if (nsel == 0) break;
        int d = 1 + rng.below(std::max(1, std::min(nsel, 1 + nsel / 4)));
        for (int t = 0; t < d; ++t) {
            int tries = 0;
            while (tries++ < 30) {
                int j = rng.below(n);
                if (s.x[j]) { s.del(j); break; }
            }
        }
        std::vector<double> sc(n);
        int mode = rng.below(3);
        for (int j = 0; j < n; ++j) {
            double w = 0.0;
            if (mode == 0) {
                for (int i = 0; i < m; ++i) w += M.y[i] * M.A[i][j];
            } else if (mode == 1) {
                for (int i = 0; i < m; ++i) {
                    double slack = M.b[i] - s.use[i];
                    w += M.A[i][j] / (slack > 1e-9 ? slack : 1e-9);
                }
            } else {
                for (int i = 0; i < m; ++i)
                    if (M.b[i] > 0) w += M.A[i][j] / M.b[i];
            }
            sc[j] = M.p[j] / (w + 1e-9);
        }
        greedyFill(s, sc, 0.15);
        descent(s, deadline);
        if (s.val > bestVal + 1e-9) {
            bestVal = s.val;
            bx = s.x;
            rep.update(bx, bestVal);
            cur = s;
        } else if (s.val >= cur.val - 1e-9 || rng.d01() < 0.02) cur = s;
    }

    // ---------------------------------------------------------- exact machinery
    std::vector<double> sw(n, 0.0);
    for (int j = 0; j < n; ++j) {
        double v = 0.0;
        for (int i = 0; i < m; ++i) v += M.y[i] * M.A[i][j];
        sw[j] = v;
    }
    std::vector<int> ratioOrd(n);
    for (int j = 0; j < n; ++j) ratioOrd[j] = j;
    std::sort(ratioOrd.begin(), ratioOrd.end(), [&](int a, int b) {
        double ra = sw[a] > 1e-12 ? M.p[a] / sw[a] : (M.p[a] > 0 ? 1e300 : -1.0);
        double rb = sw[b] > 1e-12 ? M.p[b] / sw[b] : (M.p[b] > 0 ? 1e300 : -1.0);
        if (ra != rb) return ra > rb;
        return a < b;
    });

    auto reducedCostCore = [&](double Z, std::vector<int>& fixVal) {
        fixVal.assign(n, -1);
        if (lpOk) {
            for (int j = 0; j < n; ++j) {
                if (lp.isBasic[j]) continue;
                double bnd;
                int v;
                if (lp.atUpper[j]) { bnd = lp.obj - std::max(0.0, lp.dj[j]); v = 1; }
                else { bnd = lp.obj + std::min(0.0, lp.dj[j]); v = 0; }
                if (integral) bnd = std::floor(bnd + 1e-6);
                if (bnd <= Z + 1e-9) fixVal[j] = v;
            }
        }
    };

    std::vector<int> fixVal;
    reducedCostCore(bestVal, fixVal);
    std::vector<int> core;
    for (int t = 0; t < n; ++t)
        if (fixVal[ratioOrd[t]] < 0) core.push_back(ratioOrd[t]);
    int coreSize = (int)core.size();

    bool proved = false;
    long long bbNodes = 0;
    double bbT0 = now_s();

    if (coreSize <= 70) {
        std::vector<double> capLeft = M.b;
        double baseProfit = 0.0;
        bool infeas = false;
        for (int j = 0; j < n; ++j)
            if (fixVal[j] == 1) {
                baseProfit += M.p[j];
                for (int i = 0; i < m; ++i) capLeft[i] -= M.A[i][j];
            }
        for (int i = 0; i < m; ++i)
            if (capLeft[i] < -1e-9) infeas = true;
        if (infeas) proved = true;
        else {
            MkpBB bb;
            bb.integral = integral;
            bb.deadline = deadline;
            bb.prepare(M, core, sw, capLeft, M.y);
            bb.best = bestVal - baseProfit;
            bb.dfs(0, 0.0);
            bbNodes = bb.nodes;
            proved = !bb.timeout;
            if (bb.improved && !bb.bestPick.empty()) {
                std::vector<int> nx(n, 0);
                for (int j = 0; j < n; ++j)
                    if (fixVal[j] == 1) nx[j] = 1;
                for (int k = 0; k < (int)core.size(); ++k)
                    if (bb.bestPick[k]) nx[core[k]] = 1;
                double nv = objValue(in, nx);
                if (nv > bestVal && isFeasible(in, nx)) {
                    bestVal = nv;
                    bx = nx;
                    rep.update(bx, bestVal);
                }
            }
        }
    }

    // -------------------------------------- large neighbourhood with exact repair
    double lnsEnd = std::min(deadline, now_s() + (deadline - now_s()) * 0.55);
    if (getenv("P6Z_EXACT")) lnsEnd = std::min(lnsEnd, now_s() + 8.0);
    int winSize = std::min(coreSize, 48);
    long long lnsRounds = 0, lnsImp = 0;
    std::vector<char> inWin(n, 0);
    std::vector<int> win;
    MkpBB bb;
    bb.integral = integral;
    while (!proved && now_s() < lnsEnd && coreSize > 0) {
        ++lnsRounds;
        win.clear();
        int W = std::min(coreSize, winSize);
        if (W < 4) break;
        int mode = rng.below(3);
        if (mode < 2) {
            int c = rng.below(coreSize);
            int lo = std::max(0, c - W / 2);
            int hi = std::min(coreSize, lo + W);
            lo = std::max(0, hi - W);
            for (int t = lo; t < hi; ++t) win.push_back(core[t]);
        } else {
            int guard = 0;
            while ((int)win.size() < W && guard < 20 * W) {
                ++guard;
                int j = core[rng.below(coreSize)];
                if (inWin[j]) continue;
                inWin[j] = 1;
                win.push_back(j);
            }
            for (size_t q = 0; q < win.size(); ++q) inWin[win[q]] = 0;
        }
        if (win.size() < 4) continue;
        std::sort(win.begin(), win.end(), [&](int a, int b) {
            double ra = sw[a] > 1e-12 ? M.p[a] / sw[a] : (M.p[a] > 0 ? 1e300 : -1.0);
            double rb = sw[b] > 1e-12 ? M.p[b] / sw[b] : (M.p[b] > 0 ? 1e300 : -1.0);
            if (ra != rb) return ra > rb;
            return a < b;
        });
        std::vector<double> capLeft = M.b;
        double winProfit = 0.0;
        for (size_t q = 0; q < win.size(); ++q) inWin[win[q]] = 1;
        for (int j = 0; j < n; ++j) {
            if (!bx[j]) continue;
            if (inWin[j]) { winProfit += M.p[j]; continue; }
            for (int i = 0; i < m; ++i) capLeft[i] -= M.A[i][j];
        }
        for (size_t q = 0; q < win.size(); ++q) inWin[win[q]] = 0;
        bool bad = false;
        for (int i = 0; i < m; ++i)
            if (capLeft[i] < -1e-9) bad = true;
        if (bad) continue;
        bb.deadline = deadline;
        bb.nodeCap = 3000000;
        bb.prepare(M, win, sw, capLeft, M.y);
        bb.best = winProfit;
        bb.dfs(0, 0.0);
        if (bb.timeout && bb.nodes > 2500000) winSize = std::max(12, winSize - 4);
        else if (!bb.timeout && bb.nodes < 200000) winSize = std::min(coreSize, winSize + 2);
        if (bb.improved && !bb.bestPick.empty()) {
            std::vector<int> nx = bx;
            for (size_t q = 0; q < win.size(); ++q) nx[win[q]] = 0;
            for (int k = 0; k < (int)win.size(); ++k)
                if (bb.bestPick[k]) nx[win[k]] = 1;
            double nv = objValue(in, nx);
            if (nv > bestVal + 1e-9 && isFeasible(in, nx)) {
                bestVal = nv;
                bx = nx;
                rep.update(bx, bestVal);
                ++lnsImp;
                reducedCostCore(bestVal, fixVal);
                core.clear();
                for (int t = 0; t < n; ++t)
                    if (fixVal[ratioOrd[t]] < 0) core.push_back(ratioOrd[t]);
                coreSize = (int)core.size();
            }
        }
    }

    // ---------------------------------- LP-based branch and bound / hardness probe
    BnBResult BR;
    if (!proved) {
        reducedCostCore(bestVal, fixVal);
        double bnbEnd = std::min(deadline, now_s() + (deadline - now_s()) * 0.85);
        const char* ex = getenv("P6Z_EXACT");
        if (ex) bnbEnd = now_s() + atof(ex);
        BR = mkpBranchAndBound(M, bestVal, bx, integral, bnbEnd, &rep, &in, &fixVal);
        if (BR.solved) proved = true;
        else if (BR.dualBound < M.ub) M.ub = BR.dualBound;
    }

    // leftover time back to the local search
    while (!proved && now_s() < deadline) {
        MkpLS s = cur;
        int nsel = 0;
        for (int j = 0; j < n; ++j) nsel += s.x[j];
        if (nsel == 0) break;
        int d = 1 + rng.below(std::max(1, std::min(nsel, 1 + nsel / 4)));
        for (int t = 0; t < d; ++t) {
            int tries = 0;
            while (tries++ < 30) {
                int j = rng.below(n);
                if (s.x[j]) { s.del(j); break; }
            }
        }
        greedyFill(s, score, 0.2);
        descent(s, deadline);
        if (s.val > bestVal + 1e-9) {
            bestVal = s.val;
            bx = s.x;
            rep.update(bx, bestVal);
            cur = s;
        } else if (s.val >= cur.val - 1e-9) cur = s;
    }

    double relgap = (M.ub - bestVal) / std::max(1.0, std::fabs(bestVal));
    if (relgap < 0) relgap = 0;
    if (getenv("P6Z_EXACT"))
        fprintf(stderr, "# exact n=%d m=%d solved=%d nodes=%lld t=%.3f gap=%.6f obj=%.1f\n", n, m,
                (int)proved, BR.nodes, now_s(), relgap, bestVal);
    if (dbg())
        fprintf(stderr,
                "# mdkp n=%d m=%d best=%.1f ub=%.3f gap=%.4f%% core=%d proved=%d bbnodes=%lld "
                "lns=%lld/%lld win=%d lpnodes=%lld t=%.2f\n",
                n, m, bestVal, M.ub, 100 * relgap, coreSize, (int)proved, bbNodes, lnsImp,
                lnsRounds, winSize, BR.nodes, now_s());

    // Lane-3 hardness: dual gap still open after the branch and bound budget is
    // the primary signal, instance size the tie-breaker.
    if (proved)
        g_mdkpDiff = -1000.0 + std::log10((double)(BR.nodes + bbNodes + 10));
    else
        g_mdkpDiff = 2000.0 * relgap + 2.0 * std::log((double)std::max(2, n)) +
                     std::log((double)std::max(2, m));
    g_mdkpHave = true;
    (void)bbT0;
    return true;
}
