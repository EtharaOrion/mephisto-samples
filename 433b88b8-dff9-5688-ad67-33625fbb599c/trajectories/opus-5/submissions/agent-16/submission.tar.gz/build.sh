#!/bin/sh
# Build the 0-1 IP solver. Stdlib C++17 only, no external dependencies.
set -u
ROOT=$(cd "$(dirname "$0")" && pwd)
cd "$ROOT"

CXX=${CXX:-g++}
command -v "$CXX" >/dev/null 2>&1 || CXX=c++
command -v "$CXX" >/dev/null 2>&1 || CXX=clang++

"$CXX" -std=c++17 -O2 -pipe -fno-strict-aliasing -o "$ROOT/src/p6zsolver" "$ROOT/src/main.cpp" 2>"$ROOT/src/build.log"
rc=$?
if [ $rc -ne 0 ]; then
    cat "$ROOT/src/build.log" >&2
fi
chmod +x "$ROOT/solve" 2>/dev/null || true
chmod +x "$ROOT/src/p6zsolver" 2>/dev/null || true
exit 0
