#pragma once
#include "instance.hpp"
#include "report.hpp"

// Full-subtour-row TSP: recognise degree rows (== 2, unit coefficients) to
// recover the edge/vertex incidence, then solve exactly with Held-Karp when the
// city count allows it, otherwise 2-opt / Or-opt multi-start.

struct TspData {
    int V = 0;
    std::vector<int> eu, ev;                    // per variable
    std::vector<std::vector<int> > edgeOf;      // V x V -> var id (-1)
    std::vector<std::vector<double> > d;
};

inline bool extractTSP(const Instance& in, TspData& t) {
    if (!in.family.empty() && in.family != "tsp-cutting-plane-ip") return false;
    if (in.maximize) return false;
    std::vector<int> degRows;
    for (size_t i = 0; i < in.rows.size(); ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_EQ) continue;
        if (std::fabs(r.rhs - 2.0) > 1e-9) continue;
        bool unit = true;
        for (size_t k = 0; k < r.val.size(); ++k)
            if (std::fabs(r.val[k] - 1.0) > 1e-9) { unit = false; break; }
        if (!unit) continue;
        degRows.push_back((int)i);
    }
    int V = (int)degRows.size();
    if (V < 3) return false;
    std::vector<int> cnt(in.n, 0);
    std::vector<std::pair<int, int> > endp(in.n, std::make_pair(-1, -1));
    for (int a = 0; a < V; ++a) {
        const Row& r = in.rows[degRows[a]];
        for (size_t k = 0; k < r.idx.size(); ++k) {
            int j = r.idx[k];
            if (cnt[j] == 0) endp[j].first = a;
            else if (cnt[j] == 1) endp[j].second = a;
            cnt[j]++;
        }
    }
    for (int j = 0; j < in.n; ++j)
        if (cnt[j] != 2) return false;
    t.V = V;
    t.eu.resize(in.n);
    t.ev.resize(in.n);
    t.edgeOf.assign(V, std::vector<int>(V, -1));
    t.d.assign(V, std::vector<double>(V, 1e18));
    for (int j = 0; j < in.n; ++j) {
        int a = endp[j].first, b = endp[j].second;
        if (a == b) return false;
        t.eu[j] = a;
        t.ev[j] = b;
        if (t.edgeOf[a][b] >= 0) return false;
        t.edgeOf[a][b] = t.edgeOf[b][a] = j;
        t.d[a][b] = t.d[b][a] = in.obj[j];
    }
    return true;
}

inline double tourCost(const TspData& t, const std::vector<int>& tour) {
    double s = 0.0;
    int V = t.V;
    for (int i = 0; i < V; ++i) s += t.d[tour[i]][tour[(i + 1) % V]];
    return s;
}

inline void tourToX(const TspData& t, const std::vector<int>& tour, std::vector<int>& x) {
    std::fill(x.begin(), x.end(), 0);
    int V = t.V;
    for (int i = 0; i < V; ++i) {
        int e = t.edgeOf[tour[i]][tour[(i + 1) % V]];
        if (e >= 0) x[e] = 1;
    }
}

inline void twoOpt(const TspData& t, std::vector<int>& tour) {
    int V = t.V;
    bool imp = true;
    while (imp) {
        imp = false;
        for (int i = 0; i < V - 1; ++i)
            for (int k = i + 1; k < V; ++k) {
                int a = tour[i], b = tour[(i + 1) % V];
                int c = tour[k], e = tour[(k + 1) % V];
                if (a == c || b == e || b == c) continue;
                double delta = t.d[a][c] + t.d[b][e] - t.d[a][b] - t.d[c][e];
                if (delta < -1e-9) {
                    std::reverse(tour.begin() + i + 1, tour.begin() + k + 1);
                    imp = true;
                }
            }
    }
}

inline bool tryTSP(const Instance& in, double deadline, Reporter& rep) {
    TspData t;
    if (!extractTSP(in, t)) return false;
    int V = t.V;
    std::vector<int> x(in.n, 0), bestTour;
    double bestCost = 1e300;
    Rng rng(777);

    // multi-start nearest neighbour + 2-opt for an early incumbent
    for (int s = 0; s < V && now_s() < deadline * 0.4; ++s) {
        std::vector<int> tour;
        std::vector<char> used(V, 0);
        int cur = s;
        used[cur] = 1;
        tour.push_back(cur);
        for (int step = 1; step < V; ++step) {
            int bn = -1;
            double bd = 1e300;
            for (int v = 0; v < V; ++v)
                if (!used[v] && t.d[cur][v] < bd) { bd = t.d[cur][v]; bn = v; }
            if (bn < 0) break;
            used[bn] = 1;
            tour.push_back(bn);
            cur = bn;
        }
        if ((int)tour.size() != V) continue;
        twoOpt(t, tour);
        double c = tourCost(t, tour);
        if (c < bestCost) {
            bestCost = c;
            bestTour = tour;
            tourToX(t, tour, x);
            if (isFeasible(in, x)) rep.update(x, objValue(in, x));
        }
    }

    if (V <= 20) {
        // Held-Karp exact
        int full = 1 << (V - 1);  // subsets over cities 1..V-1
        size_t cells = (size_t)full * (size_t)(V - 1);
        if (cells <= 40000000ULL) {
            std::vector<float> dp(cells, 1e30f);
            std::vector<unsigned char> par(cells, 255);
            for (int j = 1; j < V; ++j) {
                if (t.d[0][j] < 1e17) dp[(size_t)(1 << (j - 1)) * (V - 1) + (j - 1)] = (float)t.d[0][j];
            }
            for (int mask = 1; mask < full; ++mask) {
                size_t base = (size_t)mask * (V - 1);
                for (int j = 1; j < V; ++j) {
                    if (!(mask & (1 << (j - 1)))) continue;
                    float cur = dp[base + (j - 1)];
                    if (cur > 1e29f) continue;
                    for (int k = 1; k < V; ++k) {
                        if (mask & (1 << (k - 1))) continue;
                        double dd = t.d[j][k];
                        if (dd > 1e17) continue;
                        int nm = mask | (1 << (k - 1));
                        size_t pos = (size_t)nm * (V - 1) + (k - 1);
                        float nv = cur + (float)dd;
                        if (nv < dp[pos]) {
                            dp[pos] = nv;
                            par[pos] = (unsigned char)j;
                        }
                    }
                }
            }
            int fm = full - 1;
            double best = 1e300;
            int bj = -1;
            for (int j = 1; j < V; ++j) {
                double v = dp[(size_t)fm * (V - 1) + (j - 1)];
                if (v > 1e29) continue;
                if (t.d[j][0] > 1e17) continue;
                double tot = v + t.d[j][0];
                if (tot < best) { best = tot; bj = j; }
            }
            if (bj > 0) {
                std::vector<int> tour;
                int mask = fm, j = bj;
                while (j > 0) {
                    tour.push_back(j);
                    int pj = par[(size_t)mask * (V - 1) + (j - 1)];
                    mask ^= (1 << (j - 1));
                    if (pj == 255) break;
                    j = pj;
                }
                tour.push_back(0);
                std::reverse(tour.begin(), tour.end());
                if ((int)tour.size() == V) {
                    tourToX(t, tour, x);
                    if (isFeasible(in, x)) {
                        rep.update(x, objValue(in, x));
                        return true;
                    }
                }
            }
        }
    }

    // heuristic refinement loop
    if (bestTour.empty()) return false;
    std::vector<int> tour = bestTour;
    while (now_s() < deadline) {
        std::vector<int> cand = bestTour;
        for (int p = 0; p < 3; ++p) {
            int a = rng.below(V), b = rng.below(V);
            if (a > b) std::swap(a, b);
            if (a < b) std::reverse(cand.begin() + a, cand.begin() + b);
        }
        twoOpt(t, cand);
        double c = tourCost(t, cand);
        if (c < bestCost - 1e-9) {
            bestCost = c;
            bestTour = cand;
            tourToX(t, cand, x);
            if (isFeasible(in, x)) rep.update(x, objValue(in, x));
        }
    }
    return rep.has;
}
