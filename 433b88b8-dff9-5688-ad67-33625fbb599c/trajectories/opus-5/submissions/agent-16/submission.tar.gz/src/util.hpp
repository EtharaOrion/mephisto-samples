#pragma once
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cmath>
#include <chrono>
#include <string>
#include <vector>
#include <algorithm>

static std::chrono::steady_clock::time_point g_t0;
static int g_dbg = -1;

inline bool dbg() {
    if (g_dbg < 0) g_dbg = getenv("P6Z_DEBUG") ? 1 : 0;
    return g_dbg != 0;
}

inline void time_init() { g_t0 = std::chrono::steady_clock::now(); }

inline double now_s() {
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - g_t0).count();
}

struct Rng {
    uint64_t s;
    explicit Rng(uint64_t seed = 0x9E3779B97F4A7C15ULL) : s(seed ? seed : 1) {}
    inline uint64_t next() {
        uint64_t x = s;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        s = x;
        return x;
    }
    inline uint32_t u32() { return (uint32_t)(next() >> 32); }
    inline int below(int n) { return n <= 1 ? 0 : (int)(next() % (uint64_t)n); }
    inline double d01() { return (double)(next() >> 11) * (1.0 / 9007199254740992.0); }
};

inline uint64_t splitmix(uint64_t x) {
    x += 0x9E3779B97F4A7C15ULL;
    x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ULL;
    x = (x ^ (x >> 27)) * 0x94D049BB133111EBULL;
    return x ^ (x >> 31);
}

inline uint64_t hash_double(double d) {
    uint64_t u;
    if (d == 0.0) d = 0.0;  // normalize -0.0
    std::memcpy(&u, &d, 8);
    return splitmix(u);
}

inline uint64_t hash_mix(uint64_t a, uint64_t b) { return splitmix(a ^ (b * 0xD6E8FEB86659FD93ULL)); }
