#include "instance.hpp"
#include "report.hpp"
#include "generic.hpp"
#include "tsp.hpp"
#include "coloring.hpp"
#include "knapsack.hpp"
#include "mdkp.hpp"
#include "setcover.hpp"
#include "assign.hpp"
#include "l3rank.hpp"

#include <unistd.h>

static double TOTAL_BUDGET = 53.0;

int main(int argc, char** argv) {
    time_init();
    if (argc < 2) {
        fprintf(stderr, "usage: solve <instance.json>\n");
        return 1;
    }
    {
        const char* tb = getenv("P6Z_BUDGET");
        if (tb) TOTAL_BUDGET = atof(tb);
    }

    g_rep.init("unknown", false, 0, 0);
    signal(SIGALRM, watchdog_handler);
    signal(SIGTERM, watchdog_handler);
    alarm((unsigned)std::max(3.0, TOTAL_BUDGET + 4.0));

    Instance inst;
    if (!parseInstance(argv[1], inst)) {
        printf(
            "{\"instance_id\": \"unknown\", \"status\": \"unknown\", \"variables\": null, "
            "\"objective_value\": null}\n");
        return 0;
    }
    normalizeRows(inst);
    std::vector<int> varPerm;
    canonicalize(inst, varPerm);
    inst.buildCols();

    g_rep.init(inst.id, inst.maximize, inst.n, &varPerm);
    {
        std::vector<int> zero(inst.n, 0);
        g_rep.setFallback(zero, objValue(inst, zero));
    }

    double deadline = TOTAL_BUDGET;

    bool handled = false;
    if (!handled) handled = tryTSP(inst, deadline, g_rep);
    if (!handled) handled = tryColoring(inst, deadline, g_rep);
    if (!handled) handled = tryKnapsack(inst, deadline, g_rep);
    if (!handled) handled = tryMDKP(inst, deadline, g_rep);
    if (!handled) handled = trySetCover(inst, deadline, g_rep);
    if (!handled) handled = tryAssign(inst, deadline, g_rep);
    if (!handled || !g_rep.has) genericSolve(inst, std::max(deadline, now_s() + 2.0), g_rep);

    if (g_mdkpHave) l3RecordScore(inst, g_mdkpDiff, argv[0]);
    else l3Refresh(argv[0]);

    g_rep.finish();
    _exit(0);
}
