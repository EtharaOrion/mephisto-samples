#pragma once
#include "instance.hpp"
#include "report.hpp"

// Set covering: greedy + Lagrangian pricing + iterated local search.

struct ScData {
    int n = 0, m = 0;
    std::vector<std::vector<int> > colRows, rowCols;
    std::vector<double> c;
    std::vector<int> need;  // required coverage per row
};

inline bool extractSC(const Instance& in, ScData& D) {
    if (in.maximize) return false;
    int n = in.n, m = (int)in.rows.size();
    if (m < 1) return false;
    for (int i = 0; i < m; ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_GE) return false;
        double rv = std::floor(r.rhs + 0.5);
        if (std::fabs(r.rhs - rv) > 1e-9 || rv < 1) return false;
        for (size_t k = 0; k < r.val.size(); ++k)
            if (std::fabs(r.val[k] - 1.0) > 1e-9) return false;
        if ((int)r.idx.size() < (int)rv) return false;
    }
    for (int j = 0; j < n; ++j)
        if (in.obj[j] < 0) return false;
    D.n = n;
    D.m = m;
    D.c.resize(n);
    for (int j = 0; j < n; ++j) D.c[j] = in.obj[j];
    D.colRows.assign(n, std::vector<int>());
    D.rowCols.assign(m, std::vector<int>());
    D.need.resize(m);
    for (int i = 0; i < m; ++i) {
        const Row& r = in.rows[i];
        D.need[i] = (int)std::floor(r.rhs + 0.5);
        for (size_t k = 0; k < r.idx.size(); ++k) {
            D.rowCols[i].push_back(r.idx[k]);
            D.colRows[r.idx[k]].push_back(i);
        }
    }
    return true;
}

struct ScSol {
    const ScData* D;
    std::vector<int> x;
    std::vector<int> cov;  // coverage count per row
    double cost = 0.0;
    int uncovered = 0;

    void init(const ScData& d) {
        D = &d;
        x.assign(D->n, 0);
        cov.assign(D->m, 0);
        cost = 0.0;
        uncovered = 0;
        for (int i = 0; i < D->m; ++i)
            if (cov[i] < D->need[i]) ++uncovered;
    }
    void add(int j) {
        if (x[j]) return;
        x[j] = 1;
        cost += D->c[j];
        for (size_t k = 0; k < D->colRows[j].size(); ++k) {
            int i = D->colRows[j][k];
            if (cov[i] < D->need[i]) --uncovered;
            ++cov[i];
        }
    }
    void del(int j) {
        if (!x[j]) return;
        x[j] = 0;
        cost -= D->c[j];
        for (size_t k = 0; k < D->colRows[j].size(); ++k) {
            int i = D->colRows[j][k];
            --cov[i];
            if (cov[i] < D->need[i]) ++uncovered;
        }
    }
    int gain(int j) const {  // rows newly satisfied
        int g = 0;
        for (size_t k = 0; k < D->colRows[j].size(); ++k) {
            int i = D->colRows[j][k];
            if (cov[i] < D->need[i]) ++g;
        }
        return g;
    }
    bool redundant(int j) const {
        for (size_t k = 0; k < D->colRows[j].size(); ++k) {
            int i = D->colRows[j][k];
            if (cov[i] <= D->need[i]) return false;
        }
        return true;
    }
};

inline void scGreedy(ScSol& s, const std::vector<double>& price, double noise, Rng& rng) {
    const ScData& D = *s.D;
    while (s.uncovered > 0) {
        int bestj = -1;
        double bestr = 1e300;
        for (int j = 0; j < D.n; ++j) {
            if (s.x[j]) continue;
            int g = s.gain(j);
            if (g <= 0) continue;
            double r = (price[j] <= 0 ? -1e-6 : price[j]) / (double)g;
            if (noise > 0) r *= (1.0 + noise * (rng.d01() - 0.5));
            if (r < bestr) { bestr = r; bestj = j; }
        }
        if (bestj < 0) break;
        s.add(bestj);
    }
}

inline void scPrune(ScSol& s, Rng& rng) {
    const ScData& D = *s.D;
    std::vector<int> sel;
    for (int j = 0; j < D.n; ++j)
        if (s.x[j]) sel.push_back(j);
    std::sort(sel.begin(), sel.end(), [&](int a, int b) {
        if (D.c[a] != D.c[b]) return D.c[a] > D.c[b];
        return a < b;
    });
    for (size_t t = 0; t < sel.size(); ++t)
        if (s.redundant(sel[t])) s.del(sel[t]);
}

// Row-weighting local search (RWLS): add/remove single columns guided by
// gain/loss over dynamically weighted rows. Strong on (near-)unicost covers.
struct ScRwls {
    const ScData* D;
    int n, m;
    std::vector<int> S, cov, covSum;
    std::vector<double> w, gain, loss;
    std::vector<int> uncovered, uncovPos;
    std::vector<long long> tabu;
    double cost = 0.0;

    void init(const ScData& d) {
        D = &d;
        n = D->n;
        m = D->m;
        S.assign(n, 0);
        cov.assign(m, 0);
        covSum.assign(m, 0);
        w.assign(m, 1.0);
        gain.assign(n, 0.0);
        loss.assign(n, 0.0);
        tabu.assign(n, -1);
        uncovered.clear();
        uncovPos.assign(m, -1);
        cost = 0.0;
        for (int i = 0; i < m; ++i) addUncov(i);
        for (int j = 0; j < n; ++j) {
            double g = 0.0;
            for (size_t k = 0; k < D->colRows[j].size(); ++k) g += w[D->colRows[j][k]];
            gain[j] = g;
        }
    }
    void addUncov(int i) {
        uncovPos[i] = (int)uncovered.size();
        uncovered.push_back(i);
    }
    void delUncov(int i) {
        int p = uncovPos[i];
        int last = uncovered.back();
        uncovered[p] = last;
        uncovPos[last] = p;
        uncovered.pop_back();
        uncovPos[i] = -1;
    }
    void add(int j) {
        S[j] = 1;
        cost += D->c[j];
        loss[j] = 0.0;
        for (size_t k = 0; k < D->colRows[j].size(); ++k) {
            int i = D->colRows[j][k];
            ++cov[i];
            covSum[i] += j;
            if (cov[i] == 1) {
                delUncov(i);
                const std::vector<int>& rc = D->rowCols[i];
                for (size_t q = 0; q < rc.size(); ++q)
                    if (!S[rc[q]]) gain[rc[q]] -= w[i];
                loss[j] += w[i];
            } else if (cov[i] == 2) {
                loss[covSum[i] - j] -= w[i];
            }
        }
        gain[j] = 0.0;
    }
    void remove(int j) {
        S[j] = 0;
        cost -= D->c[j];
        gain[j] = 0.0;
        for (size_t k = 0; k < D->colRows[j].size(); ++k) {
            int i = D->colRows[j][k];
            --cov[i];
            covSum[i] -= j;
            if (cov[i] == 0) {
                addUncov(i);
                const std::vector<int>& rc = D->rowCols[i];
                for (size_t q = 0; q < rc.size(); ++q)
                    if (!S[rc[q]]) gain[rc[q]] += w[i];
            } else if (cov[i] == 1) {
                loss[covSum[i]] += w[i];
            }
        }
        loss[j] = 0.0;
    }
    void bumpWeights() {
        for (size_t t = 0; t < uncovered.size(); ++t) {
            int i = uncovered[t];
            w[i] += 1.0;
            const std::vector<int>& rc = D->rowCols[i];
            for (size_t q = 0; q < rc.size(); ++q)
                if (!S[rc[q]]) gain[rc[q]] += 1.0;
        }
    }
};

inline void scRwls(const ScData& D, std::vector<int>& bx, double& bestCost, double deadline,
                   Reporter& rep, Rng& rng, double bestLB) {
    int n = D.n, m = D.m;
    ScRwls R;
    R.init(D);
    for (int j = 0; j < n; ++j)
        if (bx[j]) R.add(j);
    long long iter = 0;
    int lastAdd = -1;
    double dbgLast = -1e9;
    std::vector<int> curSel;
    while (now_s() < deadline) {
        ++iter;
        if ((iter & 127) == 0 && now_s() > deadline) break;
        if (R.uncovered.empty()) {
            bool any = true;
            while (any) {
                any = false;
                for (int j = 0; j < n; ++j)
                    if (R.S[j] && R.loss[j] <= 1e-12) { R.remove(j); any = true; }
            }
            if (R.cost < bestCost - 1e-9) {
                bestCost = R.cost;
                bx = R.S;
                rep.update(bx, bestCost);
            }
            curSel.clear();
            for (int j = 0; j < n; ++j)
                if (R.S[j]) curSel.push_back(j);
            if (curSel.empty()) break;
            int bj = -1;
            double bs = 1e300;
            for (size_t q = 0; q < curSel.size(); ++q) {
                int j = curSel[q];
                double s = R.loss[j] / std::max(1e-9, D.c[j]);
                if (s < bs) { bs = s; bj = j; }
            }
            R.remove(bj);
            R.tabu[bj] = iter + 1;
            lastAdd = -1;
            continue;
        }
        curSel.clear();
        for (int j = 0; j < n; ++j)
            if (R.S[j] && j != lastAdd) curSel.push_back(j);
        if (!curSel.empty()) {
            int bj = -1;
            double bs = 1e300;
            int trials = (int)curSel.size() <= 50 ? (int)curSel.size() : 50;
            for (int t = 0; t < trials; ++t) {
                int j = (int)curSel.size() <= 50 ? curSel[t] : curSel[rng.below((int)curSel.size())];
                double s = R.loss[j] / std::max(1e-9, D.c[j]);
                if (s < bs) { bs = s; bj = j; }
            }
            R.remove(bj);
            R.tabu[bj] = iter + 1 + rng.below(6);
        }
        int r = R.uncovered[rng.below((int)R.uncovered.size())];
        const std::vector<int>& rc = D.rowCols[r];
        int aj = -1;
        double as = -1e300;
        for (size_t q = 0; q < rc.size(); ++q) {
            int j = rc[q];
            if (R.S[j] || R.tabu[j] > iter) continue;
            double s = R.gain[j] / std::max(1e-9, D.c[j]);
            if (s > as) { as = s; aj = j; }
        }
        if (aj < 0)
            for (size_t q = 0; q < rc.size(); ++q) {
                int j = rc[q];
                if (R.S[j]) continue;
                double s = R.gain[j] / std::max(1e-9, D.c[j]);
                if (s > as) { as = s; aj = j; }
            }
        if (aj >= 0) {
            R.add(aj);
            lastAdd = aj;
        }
        R.bumpWeights();
        if ((iter & 16383) == 0) {
            double mx = 0.0;
            for (int i = 0; i < m; ++i) mx = std::max(mx, R.w[i]);
            if (mx > 1e8) {
                std::vector<int> keep = R.S;
                std::vector<double> ws = R.w;
                R.init(D);
                for (int i = 0; i < m; ++i) R.w[i] = 1.0 + (ws[i] - 1.0) * 0.2;
                for (int j = 0; j < n; ++j) {
                    double g = 0.0;
                    for (size_t k = 0; k < D.colRows[j].size(); ++k) g += R.w[D.colRows[j][k]];
                    R.gain[j] = g;
                }
                for (int j = 0; j < n; ++j)
                    if (keep[j]) R.add(j);
            }
            if (dbg() && now_s() - dbgLast > 8.0) {
                dbgLast = now_s();
                fprintf(stderr, "# sc rwls ub=%.1f lb=%.3f iter=%lld t=%.1f\n", bestCost, bestLB,
                        iter, now_s());
            }
        }
    }
}

inline bool trySetCover(const Instance& in, double deadline, Reporter& rep) {
    if (!in.family.empty() && in.family != "set-cover") return false;
    ScData D;
    if (!extractSC(in, D)) return false;
    int n = D.n, m = D.m;
    Rng rng(31337);

    ScSol s;
    s.init(D);
    scGreedy(s, D.c, 0.0, rng);
    scPrune(s, rng);
    if (s.uncovered > 0) return false;
    std::vector<int> bx = s.x;
    double bestCost = s.cost;
    rep.update(bx, bestCost);

    // Lagrangian multipliers for pricing
    std::vector<double> u(m, 0.0), bestU(m, 0.0);
    double bestLB = -1e300;
    {
        for (int i = 0; i < m; ++i) {
            double mn = 1e300;
            for (size_t k = 0; k < D.rowCols[i].size(); ++k) {
                int j = D.rowCols[i][k];
                double v = D.c[j] / (double)D.colRows[j].size();
                if (v < mn) mn = v;
            }
            u[i] = (mn < 1e299) ? mn : 0.0;
        }
        double lambda = 2.0;
        int noImp = 0;
        std::vector<double> cbar(n);
        std::vector<int> sub(m);
        double tEnd = std::min(deadline, now_s() + 3.0);
        for (int it = 0; it < 2000; ++it) {
            if ((it & 15) == 0 && now_s() > tEnd) break;
            double lb = 0.0;
            for (int i = 0; i < m; ++i) lb += u[i] * D.need[i];
            for (int j = 0; j < n; ++j) {
                double v = D.c[j];
                for (size_t k = 0; k < D.colRows[j].size(); ++k) v -= u[D.colRows[j][k]];
                cbar[j] = v;
                if (v < 0) lb += v;
            }
            if (lb > bestLB) {
                bestLB = lb;
                bestU = u;
                noImp = 0;
            } else if (++noImp > 30) {
                lambda *= 0.7;
                noImp = 0;
                if (lambda < 1e-4) break;
            }
            double gn = 0.0;
            for (int i = 0; i < m; ++i) {
                int cnt = 0;
                for (size_t k = 0; k < D.rowCols[i].size(); ++k)
                    if (cbar[D.rowCols[i][k]] < 0) ++cnt;
                sub[i] = D.need[i] - cnt;
                gn += (double)sub[i] * sub[i];
            }
            if (gn < 1e-12) break;
            double step = lambda * (bestCost - lb) / gn;
            if (step <= 0) step = 1e-6;
            for (int i = 0; i < m; ++i) {
                u[i] += step * sub[i];
                if (u[i] < 0) u[i] = 0.0;
            }
        }
        u = bestU;
    }

    std::vector<double> lagPrice(n);
    for (int j = 0; j < n; ++j) {
        double v = D.c[j];
        for (size_t k = 0; k < D.colRows[j].size(); ++k) v -= u[D.colRows[j][k]];
        lagPrice[j] = v;
    }
    {
        ScSol s2;
        s2.init(D);
        for (int j = 0; j < n; ++j)
            if (lagPrice[j] < -1e-9) s2.add(j);
        std::vector<double> pr(n);
        for (int j = 0; j < n; ++j) pr[j] = std::max(lagPrice[j], 0.0) + 1e-6;
        scGreedy(s2, pr, 0.0, rng);
        scPrune(s2, rng);
        if (s2.uncovered == 0 && s2.cost < bestCost) {
            bestCost = s2.cost;
            bx = s2.x;
            rep.update(bx, bestCost);
        }
    }

    bool unicover = true;
    for (int i = 0; i < m; ++i)
        if (D.need[i] != 1) unicover = false;
    double ilsEnd = unicover ? now_s() + (deadline - now_s()) * 0.45 : deadline;

    // iterated local search
    ScSol cur;
    cur.init(D);
    for (int j = 0; j < n; ++j)
        if (bx[j]) cur.add(j);
    double curCost = cur.cost;
    std::vector<int> sel;
    long long iter = 0;
    int stall = 0;
    double dbgLast = -1e9;
    while (now_s() < ilsEnd) {
        ++iter;
        ScSol s2 = cur;
        s2.D = &D;
        sel.clear();
        for (int j = 0; j < n; ++j)
            if (s2.x[j]) sel.push_back(j);
        if (sel.empty()) break;
        int k = 1 + rng.below(std::max(1, std::min((int)sel.size(), 2 + (int)sel.size() / 6)));
        for (int t = 0; t < k; ++t) {
            int j = sel[rng.below((int)sel.size())];
            if (s2.x[j]) s2.del(j);
        }
        // also drop a random row's covering column to diversify
        std::vector<double> pr(n);
        int mode = rng.below(2);
        for (int j = 0; j < n; ++j) pr[j] = (mode == 0) ? D.c[j] : std::max(lagPrice[j], 0.0) + 1e-3;
        scGreedy(s2, pr, 0.3, rng);
        scPrune(s2, rng);
        if (s2.uncovered > 0) continue;
        if (s2.cost < bestCost - 1e-9) {
            bestCost = s2.cost;
            bx = s2.x;
            rep.update(bx, bestCost);
            cur = s2;
            curCost = s2.cost;
            stall = 0;
        } else if (s2.cost <= curCost + 1e-9) {
            cur = s2;
            curCost = s2.cost;
            ++stall;
        } else {
            ++stall;
        }
        if (dbgLast + 5.0 < now_s() && dbg()) {
            dbgLast = now_s();
            fprintf(stderr, "# sc n=%d m=%d ub=%.1f lb=%.3f t=%.1f\n", n, m, bestCost, bestLB,
                    now_s());
        }
        if (stall > 4000) {
            cur.init(D);
            std::vector<double> pr2(n);
            for (int j = 0; j < n; ++j) pr2[j] = D.c[j];
            scGreedy(cur, pr2, 0.8, rng);
            scPrune(cur, rng);
            curCost = cur.cost;
            stall = 0;
        }
    }
    if (unicover) scRwls(D, bx, bestCost, deadline, rep, rng, bestLB);
    if (dbg())
        fprintf(stderr, "# sc final n=%d m=%d ub=%.1f lb=%.3f\n", n, m, bestCost, bestLB);
    return true;
}
