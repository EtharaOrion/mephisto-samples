#pragma once
#include "util.hpp"

enum { S_LE = 0, S_GE = 1, S_EQ = 2 };

struct Row {
    int sense = S_LE;
    double rhs = 0.0;
    std::vector<int> idx;
    std::vector<double> val;
};

struct Instance {
    std::string id;
    std::string family;
    int n = 0;
    bool maximize = false;
    std::vector<double> obj;
    std::vector<Row> rows;
    // column-wise
    std::vector<std::vector<int> > colRows;
    std::vector<std::vector<double> > colVals;

    void buildCols() {
        colRows.assign(n, std::vector<int>());
        colVals.assign(n, std::vector<double>());
        std::vector<int> cnt(n, 0);
        for (size_t i = 0; i < rows.size(); ++i)
            for (size_t k = 0; k < rows[i].idx.size(); ++k) cnt[rows[i].idx[k]]++;
        for (int j = 0; j < n; ++j) {
            colRows[j].reserve(cnt[j]);
            colVals[j].reserve(cnt[j]);
        }
        for (size_t i = 0; i < rows.size(); ++i)
            for (size_t k = 0; k < rows[i].idx.size(); ++k) {
                colRows[rows[i].idx[k]].push_back((int)i);
                colVals[rows[i].idx[k]].push_back(rows[i].val[k]);
            }
    }
};

// ---------------------------------------------------------------- JSON parse

struct JParser {
    const char* p;
    const char* e;
    bool ok = true;

    inline void ws() {
        while (p < e) {
            char c = *p;
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') ++p;
            else break;
        }
    }
    inline bool lit(char c) {
        ws();
        if (p < e && *p == c) { ++p; return true; }
        return false;
    }
    std::string str() {
        ws();
        std::string out;
        if (p >= e || *p != '"') { ok = false; return out; }
        ++p;
        while (p < e && *p != '"') {
            if (*p == '\\') {
                ++p;
                if (p >= e) break;
                char c = *p++;
                switch (c) {
                    case 'n': out.push_back('\n'); break;
                    case 't': out.push_back('\t'); break;
                    case 'r': out.push_back('\r'); break;
                    case 'b': out.push_back('\b'); break;
                    case 'f': out.push_back('\f'); break;
                    case 'u': {
                        unsigned code = 0;
                        for (int k = 0; k < 4 && p < e; ++k) {
                            char h = *p++;
                            code <<= 4;
                            if (h >= '0' && h <= '9') code |= (unsigned)(h - '0');
                            else if (h >= 'a' && h <= 'f') code |= (unsigned)(h - 'a' + 10);
                            else if (h >= 'A' && h <= 'F') code |= (unsigned)(h - 'A' + 10);
                        }
                        if (code < 0x80) out.push_back((char)code);
                        else if (code < 0x800) {
                            out.push_back((char)(0xC0 | (code >> 6)));
                            out.push_back((char)(0x80 | (code & 0x3F)));
                        } else {
                            out.push_back((char)(0xE0 | (code >> 12)));
                            out.push_back((char)(0x80 | ((code >> 6) & 0x3F)));
                            out.push_back((char)(0x80 | (code & 0x3F)));
                        }
                        break;
                    }
                    default: out.push_back(c);
                }
            } else out.push_back(*p++);
        }
        if (p < e) ++p;
        return out;
    }
    double num() {
        ws();
        const char* st = p;
        bool neg = false;
        if (p < e && (*p == '-' || *p == '+')) { neg = (*p == '-'); ++p; }
        unsigned long long ip = 0;
        int nd = 0;
        while (p < e && *p >= '0' && *p <= '9') { ip = ip * 10 + (unsigned)(*p - '0'); ++p; ++nd; }
        double v = (double)ip;
        if (p < e && *p == '.') {
            ++p;
            unsigned long long fp = 0;
            int fd = 0;
            while (p < e && *p >= '0' && *p <= '9') {
                if (fd < 18) { fp = fp * 10 + (unsigned)(*p - '0'); ++fd; }
                ++p;
            }
            static const double pw[19] = {1e0, 1e1, 1e2, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9,
                                          1e10, 1e11, 1e12, 1e13, 1e14, 1e15, 1e16, 1e17, 1e18};
            v += (double)fp / pw[fd];
        }
        if ((p < e && (*p == 'e' || *p == 'E')) || nd > 18) {
            char* end = 0;
            double d = strtod(st, &end);
            p = end;
            return d;
        }
        return neg ? -v : v;
    }
    void skipValue() {
        ws();
        if (p >= e) return;
        char c = *p;
        if (c == '"') { str(); return; }
        if (c == '{') {
            ++p;
            ws();
            if (p < e && *p == '}') { ++p; return; }
            while (p < e) {
                str();
                lit(':');
                skipValue();
                ws();
                if (p < e && *p == ',') { ++p; continue; }
                if (p < e && *p == '}') { ++p; }
                break;
            }
            return;
        }
        if (c == '[') {
            ++p;
            ws();
            if (p < e && *p == ']') { ++p; return; }
            while (p < e) {
                skipValue();
                ws();
                if (p < e && *p == ',') { ++p; continue; }
                if (p < e && *p == ']') { ++p; }
                break;
            }
            return;
        }
        if (c == 't' || c == 'f' || c == 'n') {
            while (p < e && ((*p >= 'a' && *p <= 'z'))) ++p;
            return;
        }
        num();
    }
};

inline bool parseInstance(const char* path, Instance& inst) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    std::vector<char> buf((size_t)sz + 1);
    size_t rd = fread(buf.data(), 1, (size_t)sz, f);
    buf[rd] = 0;
    fclose(f);

    JParser J;
    J.p = buf.data();
    J.e = buf.data() + rd;
    long long nvars = -1;
    std::string senseStr;
    if (!J.lit('{')) return false;
    J.ws();
    if (J.p < J.e && *J.p == '}') return false;
    while (J.p < J.e) {
        std::string key = J.str();
        J.lit(':');
        if (key == "instance_id") inst.id = J.str();
        else if (key == "family") inst.family = J.str();
        else if (key == "objective_sense") senseStr = J.str();
        else if (key == "n_vars") nvars = (long long)J.num();
        else if (key == "objective_coefficients") {
            J.lit('[');
            J.ws();
            if (J.p < J.e && *J.p == ']') ++J.p;
            else
                while (J.p < J.e) {
                    inst.obj.push_back(J.num());
                    J.ws();
                    if (J.p < J.e && *J.p == ',') { ++J.p; continue; }
                    if (J.p < J.e && *J.p == ']') ++J.p;
                    break;
                }
        } else if (key == "constraints") {
            J.lit('[');
            J.ws();
            if (J.p < J.e && *J.p == ']') ++J.p;
            else
                while (J.p < J.e) {
                    // one constraint object
                    Row r;
                    int ncoef = 0;
                    J.lit('{');
                    J.ws();
                    if (J.p < J.e && *J.p == '}') ++J.p;
                    else
                        while (J.p < J.e) {
                            std::string ck = J.str();
                            J.lit(':');
                            if (ck == "coefficients") {
                                J.lit('[');
                                J.ws();
                                if (J.p < J.e && *J.p == ']') ++J.p;
                                else
                                    while (J.p < J.e) {
                                        double v = J.num();
                                        if (v != 0.0) {
                                            r.idx.push_back(ncoef);
                                            r.val.push_back(v);
                                        }
                                        ++ncoef;
                                        J.ws();
                                        if (J.p < J.e && *J.p == ',') { ++J.p; continue; }
                                        if (J.p < J.e && *J.p == ']') ++J.p;
                                        break;
                                    }
                            } else if (ck == "rhs") r.rhs = J.num();
                            else if (ck == "sense") {
                                std::string s = J.str();
                                r.sense = (s == "<=") ? S_LE : (s == ">=") ? S_GE : S_EQ;
                            } else J.skipValue();
                            J.ws();
                            if (J.p < J.e && *J.p == ',') { ++J.p; continue; }
                            if (J.p < J.e && *J.p == '}') ++J.p;
                            break;
                        }
                    if (ncoef > nvars) nvars = ncoef;
                    inst.rows.push_back(Row());
                    inst.rows.back().sense = r.sense;
                    inst.rows.back().rhs = r.rhs;
                    inst.rows.back().idx.swap(r.idx);
                    inst.rows.back().val.swap(r.val);
                    J.ws();
                    if (J.p < J.e && *J.p == ',') { ++J.p; continue; }
                    if (J.p < J.e && *J.p == ']') ++J.p;
                    break;
                }
        } else J.skipValue();
        J.ws();
        if (J.p < J.e && *J.p == ',') { ++J.p; continue; }
        break;
    }
    if (nvars < 0) nvars = (long long)inst.obj.size();
    inst.n = (int)nvars;
    if ((int)inst.obj.size() < inst.n) inst.obj.resize(inst.n, 0.0);
    inst.maximize = (senseStr == "max");
    return inst.n > 0;
}

// ------------------------------------------------------- row gcd normalization

inline long long dgcd(long long a, long long b) {
    while (b) { long long t = a % b; a = b; b = t; }
    return a < 0 ? -a : a;
}

inline void normalizeRows(Instance& inst) {
    for (size_t i = 0; i < inst.rows.size(); ++i) {
        Row& r = inst.rows[i];
        long long g = 0;
        bool intOk = true;
        for (size_t k = 0; k < r.val.size() && intOk; ++k) {
            double v = r.val[k];
            double rv = std::floor(v + 0.5);
            if (std::fabs(v - rv) > 1e-7 || std::fabs(rv) > 4.0e18) { intOk = false; break; }
            long long iv = (long long)rv;
            if (iv) g = dgcd(g, iv < 0 ? -iv : iv);
        }
        if (intOk) {
            double rv = std::floor(r.rhs + 0.5);
            if (std::fabs(r.rhs - rv) > 1e-7 || std::fabs(rv) > 4.0e18) intOk = false;
            else {
                long long iv = (long long)rv;
                if (iv) g = dgcd(g, iv < 0 ? -iv : iv);
            }
        }
        if (intOk && g > 1) {
            double gd = (double)g;
            for (size_t k = 0; k < r.val.size(); ++k) r.val[k] /= gd;
            r.rhs /= gd;
        }
    }
}

// ---------------------------------------------------------- canonical ordering

// Produces varPerm: canonical position -> original index; and reorders instance
// in place. Caller maps solution back with varPerm.
inline void canonicalize(Instance& inst, std::vector<int>& varPerm) {
    int n = inst.n;
    size_t m = inst.rows.size();
    std::vector<uint64_t> vk(n), rk(m);
    for (int j = 0; j < n; ++j) vk[j] = hash_double(inst.obj[j]);
    for (size_t i = 0; i < m; ++i)
        rk[i] = hash_mix(splitmix((uint64_t)inst.rows[i].sense + 1315423911ULL), hash_double(inst.rows[i].rhs));

    std::vector<uint64_t> acc_r(m), acc_v(n);
    for (int it = 0; it < 3; ++it) {
        for (size_t i = 0; i < m; ++i) acc_r[i] = 0;
        for (int j = 0; j < n; ++j) acc_v[j] = 0;
        for (size_t i = 0; i < m; ++i) {
            const Row& r = inst.rows[i];
            uint64_t s = 0;
            for (size_t k = 0; k < r.idx.size(); ++k) {
                uint64_t h = hash_mix(vk[r.idx[k]], hash_double(r.val[k]));
                s += h;
                acc_v[r.idx[k]] += hash_mix(rk[i], hash_double(r.val[k]));
            }
            acc_r[i] = s;
        }
        for (size_t i = 0; i < m; ++i) rk[i] = hash_mix(rk[i], acc_r[i]);
        for (int j = 0; j < n; ++j) vk[j] = hash_mix(vk[j], acc_v[j]);
    }

    varPerm.resize(n);
    for (int j = 0; j < n; ++j) varPerm[j] = j;
    {
        const std::vector<uint64_t>& K = vk;
        std::sort(varPerm.begin(), varPerm.end(), [&](int a, int b) {
            if (K[a] != K[b]) return K[a] < K[b];
            return a < b;
        });
    }
    std::vector<int> inv(n);
    for (int c = 0; c < n; ++c) inv[varPerm[c]] = c;

    std::vector<double> nobj(n);
    for (int c = 0; c < n; ++c) nobj[c] = inst.obj[varPerm[c]];
    inst.obj.swap(nobj);

    std::vector<std::pair<int, double> > tmp;
    for (size_t i = 0; i < m; ++i) {
        Row& r = inst.rows[i];
        tmp.clear();
        tmp.reserve(r.idx.size());
        for (size_t k = 0; k < r.idx.size(); ++k) tmp.push_back(std::make_pair(inv[r.idx[k]], r.val[k]));
        std::sort(tmp.begin(), tmp.end());
        for (size_t k = 0; k < tmp.size(); ++k) { r.idx[k] = tmp[k].first; r.val[k] = tmp[k].second; }
    }

    std::vector<int> rowPerm(m);
    for (size_t i = 0; i < m; ++i) rowPerm[i] = (int)i;
    std::sort(rowPerm.begin(), rowPerm.end(), [&](int a, int b) {
        if (rk[a] != rk[b]) return rk[a] < rk[b];
        return a < b;
    });
    std::vector<Row> nrows(m);
    for (size_t i = 0; i < m; ++i) nrows[i].idx.swap(inst.rows[rowPerm[i]].idx),
        nrows[i].val.swap(inst.rows[rowPerm[i]].val), nrows[i].sense = inst.rows[rowPerm[i]].sense,
        nrows[i].rhs = inst.rows[rowPerm[i]].rhs;
    inst.rows.swap(nrows);
}

// ------------------------------------------------------------- feasibility

inline double objValue(const Instance& inst, const std::vector<int>& x) {
    double s = 0.0;
    for (int j = 0; j < inst.n; ++j)
        if (x[j]) s += inst.obj[j];
    return s;
}

inline bool isFeasible(const Instance& inst, const std::vector<int>& x, double tol = 1e-9) {
    for (size_t i = 0; i < inst.rows.size(); ++i) {
        const Row& r = inst.rows[i];
        double a = 0.0;
        for (size_t k = 0; k < r.idx.size(); ++k)
            if (x[r.idx[k]]) a += r.val[k];
        if (r.sense == S_LE) { if (a > r.rhs + tol) return false; }
        else if (r.sense == S_GE) { if (a < r.rhs - tol) return false; }
        else if (std::fabs(a - r.rhs) > tol) return false;
    }
    return true;
}
