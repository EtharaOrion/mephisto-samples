#pragma once
#include "instance.hpp"
#include "report.hpp"

// Generic 0-1 IP local search: adaptive-weight min-conflicts for feasibility
// plus objective-guided flips.  Used as the safety net for any instance whose
// structure we do not recognise, and as a polisher.

struct GenericLS {
    const Instance* in;
    int n, m;
    std::vector<double> c;      // minimisation-direction objective
    std::vector<int> x;
    std::vector<double> act;
    std::vector<double> w;      // row weights
    double W = 0.0;             // weighted violation
    double cost = 0.0;
    Rng rng;

    // SOS1 groups: exactly-one rows over disjoint supports with unit coeffs
    std::vector<int> groupOf;   // var -> group id (-1 none)
    std::vector<std::vector<int> > groups;

    double viol(int i, double a) const {
        const Row& r = in->rows[i];
        if (r.sense == S_LE) return a > r.rhs ? a - r.rhs : 0.0;
        if (r.sense == S_GE) return a < r.rhs ? r.rhs - a : 0.0;
        return std::fabs(a - r.rhs);
    }

    void init(const Instance& inst, uint64_t seed) {
        in = &inst;
        n = inst.n;
        m = (int)inst.rows.size();
        rng = Rng(seed);
        c.resize(n);
        for (int j = 0; j < n; ++j) c[j] = inst.maximize ? -inst.obj[j] : inst.obj[j];
        w.assign(m, 1.0);
        x.assign(n, 0);
        detectGroups();
    }

    void detectGroups() {
        groupOf.assign(n, -1);
        groups.clear();
        for (int i = 0; i < m; ++i) {
            const Row& r = in->rows[i];
            if (r.sense != S_EQ) continue;
            if (std::fabs(r.rhs - 1.0) > 1e-9) continue;
            if (r.idx.size() < 2) continue;
            bool unit = true;
            for (size_t k = 0; k < r.val.size(); ++k)
                if (std::fabs(r.val[k] - 1.0) > 1e-9) { unit = false; break; }
            if (!unit) continue;
            bool free_ = true;
            for (size_t k = 0; k < r.idx.size(); ++k)
                if (groupOf[r.idx[k]] >= 0) { free_ = false; break; }
            if (!free_) continue;
            int gid = (int)groups.size();
            groups.push_back(r.idx);
            for (size_t k = 0; k < r.idx.size(); ++k) groupOf[r.idx[k]] = gid;
        }
    }

    void recompute() {
        act.assign(m, 0.0);
        for (int i = 0; i < m; ++i) {
            const Row& r = in->rows[i];
            double a = 0.0;
            for (size_t k = 0; k < r.idx.size(); ++k)
                if (x[r.idx[k]]) a += r.val[k];
            act[i] = a;
        }
        W = 0.0;
        for (int i = 0; i < m; ++i) W += w[i] * viol(i, act[i]);
        cost = 0.0;
        for (int j = 0; j < n; ++j)
            if (x[j]) cost += c[j];
    }

    double deltaW(int j) const {
        double s = x[j] ? -1.0 : 1.0;
        const std::vector<int>& cr = in->colRows[j];
        const std::vector<double>& cv = in->colVals[j];
        double d = 0.0;
        for (size_t k = 0; k < cr.size(); ++k) {
            int i = cr[k];
            d += w[i] * (viol(i, act[i] + s * cv[k]) - viol(i, act[i]));
        }
        return d;
    }

    void doFlip(int j) {
        double s = x[j] ? -1.0 : 1.0;
        const std::vector<int>& cr = in->colRows[j];
        const std::vector<double>& cv = in->colVals[j];
        for (size_t k = 0; k < cr.size(); ++k) {
            int i = cr[k];
            W -= w[i] * viol(i, act[i]);
            act[i] += s * cv[k];
            W += w[i] * viol(i, act[i]);
        }
        cost += s * c[j];
        x[j] = x[j] ? 0 : 1;
    }

    double rawViolation() const {
        double v = 0.0;
        for (int i = 0; i < m; ++i) v += viol(i, act[i]);
        return v;
    }

    void run(double deadline, Reporter& rep, double lambda0 = 1.0) {
        // greedy start: satisfy groups by cheapest member
        for (size_t g = 0; g < groups.size(); ++g) {
            int bestv = groups[g][0];
            for (size_t k = 1; k < groups[g].size(); ++k)
                if (c[groups[g][k]] < c[bestv]) bestv = groups[g][k];
            x[bestv] = 1;
        }
        recompute();
        double lambda = lambda0;
        double scaleC = 0.0;
        for (int j = 0; j < n; ++j) scaleC += std::fabs(c[j]);
        scaleC = scaleC / std::max(1, n);
        if (scaleC <= 0) scaleC = 1.0;
        lambda = scaleC * 100.0;

        std::vector<int> viRows;
        long long iter = 0;
        int noImp = 0;
        std::vector<int> bestFeas;
        double bestFeasCost = 1e300;

        while (true) {
            if ((iter & 127) == 0 && now_s() > deadline) break;
            ++iter;
            viRows.clear();
            for (int i = 0; i < m; ++i)
                if (viol(i, act[i]) > 1e-9) viRows.push_back(i);
            if (viRows.empty()) {
                if (cost < bestFeasCost - 1e-9) {
                    bestFeasCost = cost;
                    bestFeas = x;
                    rep.update(x, in->maximize ? -cost : cost);
                    noImp = 0;
                }
                // objective descent: try improving flips / group moves
                bool improved = descentStep(lambda);
                if (!improved) {
                    ++noImp;
                    perturb();
                }
                continue;
            }
            // repair one violated row
            int ri = viRows[rng.below((int)viRows.size())];
            const Row& r = in->rows[ri];
            int bestj = -1;
            double bestSc = 1e300;
            for (size_t k = 0; k < r.idx.size(); ++k) {
                int j = r.idx[k];
                double dv = deltaW(j);
                double dc = (x[j] ? -c[j] : c[j]);
                double sc = dv * lambda + dc + rng.d01() * 1e-6;
                if (sc < bestSc) { bestSc = sc; bestj = j; }
            }
            if (bestj < 0) break;
            if (rng.d01() < 0.05) bestj = r.idx[rng.below((int)r.idx.size())];
            doFlip(bestj);
            if ((iter & 1023) == 0) {
                for (int i = 0; i < m; ++i)
                    if (viol(i, act[i]) > 1e-9) w[i] += 1.0;
                recompute();
            }
        }
        if (bestFeasCost < 1e299) {
            x = bestFeas;
            recompute();
        }
    }

    bool descentStep(double lambda) {
        // single flips keeping feasibility
        bool any = false;
        for (int pass = 0; pass < 1; ++pass) {
            int bestj = -1;
            double bestSc = -1e-9;
            for (int j = 0; j < n; ++j) {
                if (groupOf[j] >= 0) continue;
                double dc = (x[j] ? -c[j] : c[j]);
                if (dc >= -1e-9) continue;
                if (deltaW(j) > 1e-9) continue;
                if (dc < bestSc) { bestSc = dc; bestj = j; }
            }
            if (bestj >= 0) { doFlip(bestj); any = true; }
        }
        // group re-assignment
        for (size_t g = 0; g < groups.size(); ++g) {
            int cur = -1;
            for (size_t k = 0; k < groups[g].size(); ++k)
                if (x[groups[g][k]]) { cur = groups[g][k]; break; }
            if (cur < 0) continue;
            int bestv = -1;
            double bestD = -1e-9;
            doFlip(cur);
            for (size_t k = 0; k < groups[g].size(); ++k) {
                int j = groups[g][k];
                if (j == cur) continue;
                double d = deltaW(j) * lambda + c[j] - c[cur];
                if (d < bestD) { bestD = d; bestv = j; }
            }
            doFlip(cur);
            if (bestv >= 0) {
                doFlip(cur);
                doFlip(bestv);
                if (W > 1e-9) { doFlip(bestv); doFlip(cur); }
                else any = true;
            }
        }
        return any;
    }

    void perturb() {
        int k = 1 + rng.below(3);
        for (int t = 0; t < k; ++t) {
            if (!groups.empty() && rng.d01() < 0.5) {
                int g = rng.below((int)groups.size());
                int cur = -1;
                for (size_t q = 0; q < groups[g].size(); ++q)
                    if (x[groups[g][q]]) { cur = groups[g][q]; break; }
                int nv = groups[g][rng.below((int)groups[g].size())];
                if (cur >= 0 && nv != cur) { doFlip(cur); doFlip(nv); }
            } else {
                doFlip(rng.below(n));
            }
        }
    }
};

inline void genericSolve(const Instance& inst, double deadline, Reporter& rep) {
    GenericLS ls;
    ls.init(inst, 12345);
    ls.run(deadline, rep);
}
