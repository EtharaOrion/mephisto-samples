#pragma once
#include "instance.hpp"
#include "report.hpp"

#include <dirent.h>
#include <sys/stat.h>
#include <libgen.h>
#include <string>

// Lane 3: accumulate a per-instance hardness estimate for the
// multi-dimensional-knapsack sub-cohort across independent solver invocations
// and (re)write l3_ranking.json, hardest first.

inline uint64_t instanceHash(const Instance& in) {
    uint64_t h = splitmix((uint64_t)in.n * 1000003ULL + (in.maximize ? 7 : 11));
    for (int j = 0; j < in.n; ++j) h = hash_mix(h, hash_double(in.obj[j]));
    for (size_t i = 0; i < in.rows.size(); ++i) {
        const Row& r = in.rows[i];
        h = hash_mix(h, splitmix((uint64_t)r.sense + 97));
        h = hash_mix(h, hash_double(r.rhs));
        for (size_t k = 0; k < r.idx.size(); ++k)
            h = hash_mix(h, hash_mix((uint64_t)r.idx[k] + 1, hash_double(r.val[k])));
    }
    return h;
}

inline bool looksCanonicalId(const std::string& s) {
    size_t p = s.rfind("__");
    if (p == std::string::npos || p + 2 >= s.size()) return false;
    for (size_t i = p + 2; i < s.size(); ++i)
        if (s[i] < '0' || s[i] > '9') return false;
    return true;
}

inline std::string exeDir(const char* argv0) {
    char buf[4096];
    if (realpath(argv0, buf)) {
        std::string s(buf);
        size_t p = s.rfind('/');
        if (p != std::string::npos) return s.substr(0, p);
    }
    if (getcwd(buf, sizeof(buf))) return std::string(buf);
    return std::string(".");
}

inline void writeRanking(const std::string& root) {
    std::string dir = root + "/.l3state";
    DIR* d = opendir(dir.c_str());
    if (!d) return;
    std::vector<std::pair<double, std::string> > recs;
    struct dirent* de;
    while ((de = readdir(d)) != 0) {
        std::string nm = de->d_name;
        if (nm.size() < 5 || nm.substr(nm.size() - 4) != ".rec") continue;
        FILE* f = fopen((dir + "/" + nm).c_str(), "r");
        if (!f) continue;
        char idbuf[512];
        double sc = 0;
        if (fscanf(f, "%lf %511s", &sc, idbuf) == 2) recs.push_back(std::make_pair(sc, std::string(idbuf)));
        fclose(f);
    }
    closedir(d);
    if (recs.empty()) return;
    std::sort(recs.begin(), recs.end(), [](const std::pair<double, std::string>& a,
                                           const std::pair<double, std::string>& b) {
        if (a.first != b.first) return a.first > b.first;
        return a.second < b.second;
    });
    std::string out = "[";
    for (size_t i = 0; i < recs.size(); ++i) {
        if (i) out += ", ";
        out += "\"" + recs[i].second + "\"";
    }
    out += "]\n";
    std::string tmp = root + "/.l3_rank_tmp_" + std::to_string((long)getpid());
    FILE* f = fopen(tmp.c_str(), "w");
    if (!f) return;
    fwrite(out.data(), 1, out.size(), f);
    fclose(f);
    rename(tmp.c_str(), (root + "/l3_ranking.json").c_str());
}

inline void l3RecordScore(const Instance& in, double score, const char* argv0) {
    std::string root = exeDir(argv0);
    std::string dir = root + "/.l3state";
    mkdir(dir.c_str(), 0777);
    uint64_t h = instanceHash(in);
    char hb[32];
    snprintf(hb, sizeof(hb), "%016llx", (unsigned long long)h);
    std::string path = dir + "/" + hb + ".rec";
    bool write = true;
    FILE* ex = fopen(path.c_str(), "r");
    if (ex) {
        char idbuf[512];
        double sc;
        if (fscanf(ex, "%lf %511s", &sc, idbuf) == 2) {
            if (looksCanonicalId(std::string(idbuf))) write = false;
        }
        fclose(ex);
    }
    if (write) {
        std::string tmp = dir + "/tmp_" + std::to_string((long)getpid()) + "_" + hb;
        FILE* f = fopen(tmp.c_str(), "w");
        if (f) {
            fprintf(f, "%.9f %s\n", score, in.id.c_str());
            fclose(f);
            rename(tmp.c_str(), path.c_str());
        }
    }
    writeRanking(root);
}
