#pragma once
#include "instance.hpp"
#include "report.hpp"

// graph-coloring-ip: minimise number of used colours subject to
//   sum_c x_vc == 1, x_uc + x_vc - w_c <= 0, w_{c+1} - w_c <= 0.

struct ColData {
    int V = 0, K = 0;
    std::vector<std::vector<int> > xvar;  // [v][colorSlot] -> var
    std::vector<int> wvar;                // [colorSlot] -> var  (priority order)
    std::vector<std::vector<int> > adj;
    std::vector<std::vector<char> > adjm;
};

inline bool extractColoring(const Instance& in, ColData& C) {
    if (!in.family.empty() && in.family != "graph-coloring-ip") return false;
    if (in.maximize) return false;
    int n = in.n;
    std::vector<int> vertOf(n, -1);
    std::vector<std::vector<int> > vrows;
    for (size_t i = 0; i < in.rows.size(); ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_EQ || std::fabs(r.rhs - 1.0) > 1e-9 || r.idx.size() < 2) continue;
        bool unit = true;
        for (size_t k = 0; k < r.val.size(); ++k)
            if (std::fabs(r.val[k] - 1.0) > 1e-9) { unit = false; break; }
        if (!unit) continue;
        bool fresh = true;
        for (size_t k = 0; k < r.idx.size(); ++k)
            if (vertOf[r.idx[k]] >= 0) { fresh = false; break; }
        if (!fresh) continue;
        int v = (int)vrows.size();
        vrows.push_back(r.idx);
        for (size_t k = 0; k < r.idx.size(); ++k) vertOf[r.idx[k]] = v;
    }
    int V = (int)vrows.size();
    if (V < 2) return false;
    int K = (int)vrows[0].size();
    for (int v = 0; v < V; ++v)
        if ((int)vrows[v].size() != K) return false;
    if (K < 1) return false;

    // colour identification via edge rows (+1,+1,-1) with rhs 0
    std::vector<int> colorOfW(n, -1);
    std::vector<int> wlist;
    std::vector<int> colorOfX(n, -1);
    std::vector<std::pair<int, int> > edges;
    int nEdgeRows = 0;
    for (size_t i = 0; i < in.rows.size(); ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_LE || std::fabs(r.rhs) > 1e-9 || r.idx.size() != 3) continue;
        int pos[3], np = 0, neg = -1;
        bool bad = false;
        for (int k = 0; k < 3; ++k) {
            if (std::fabs(r.val[k] - 1.0) < 1e-9) { if (np < 3) pos[np++] = r.idx[k]; }
            else if (std::fabs(r.val[k] + 1.0) < 1e-9) { if (neg >= 0) bad = true; neg = r.idx[k]; }
            else bad = true;
        }
        if (bad || np != 2 || neg < 0) continue;
        if (vertOf[pos[0]] < 0 || vertOf[pos[1]] < 0 || vertOf[neg] >= 0) continue;
        if (vertOf[pos[0]] == vertOf[pos[1]]) continue;
        if (colorOfW[neg] < 0) {
            colorOfW[neg] = (int)wlist.size();
            wlist.push_back(neg);
        }
        int cc = colorOfW[neg];
        for (int k = 0; k < 2; ++k) {
            if (colorOfX[pos[k]] >= 0 && colorOfX[pos[k]] != cc) return false;
            colorOfX[pos[k]] = cc;
        }
        edges.push_back(std::make_pair(vertOf[pos[0]], vertOf[pos[1]]));
        ++nEdgeRows;
    }
    if (nEdgeRows == 0) return false;
    if ((int)wlist.size() > K) return false;
    // colour slots not seen in edge rows
    while ((int)wlist.size() < K) {
        // find an unused variable that is a plausible w var: appears in no vertex row
        int found = -1;
        for (int j = 0; j < n; ++j) {
            if (vertOf[j] >= 0 || colorOfW[j] >= 0) continue;
            found = j;
            break;
        }
        if (found < 0) break;
        colorOfW[found] = (int)wlist.size();
        wlist.push_back(found);
    }
    int Kw = (int)wlist.size();
    if (Kw < 1) return false;

    // priority ordering from symmetry-breaking rows w_b - w_a <= 0  (a before b)
    std::vector<std::vector<int> > succ(Kw);
    std::vector<int> indeg(Kw, 0);
    for (size_t i = 0; i < in.rows.size(); ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_LE || std::fabs(r.rhs) > 1e-9 || r.idx.size() != 2) continue;
        int a = -1, b = -1;
        for (int k = 0; k < 2; ++k) {
            if (std::fabs(r.val[k] - 1.0) < 1e-9) b = r.idx[k];
            else if (std::fabs(r.val[k] + 1.0) < 1e-9) a = r.idx[k];
        }
        if (a < 0 || b < 0) continue;
        if (colorOfW[a] < 0 || colorOfW[b] < 0) continue;
        succ[colorOfW[a]].push_back(colorOfW[b]);
        indeg[colorOfW[b]]++;
    }
    std::vector<int> order;
    {
        std::vector<int> q;
        for (int c = 0; c < Kw; ++c)
            if (indeg[c] == 0) q.push_back(c);
        std::sort(q.begin(), q.end());
        while (!q.empty()) {
            int c = q.front();
            q.erase(q.begin());
            order.push_back(c);
            for (size_t t = 0; t < succ[c].size(); ++t)
                if (--indeg[succ[c][t]] == 0) q.push_back(succ[c][t]);
            std::sort(q.begin(), q.end());
        }
        if ((int)order.size() != Kw) {
            order.clear();
            for (int c = 0; c < Kw; ++c) order.push_back(c);
        }
    }

    C.V = V;
    C.K = Kw;
    C.wvar.resize(Kw);
    for (int s = 0; s < Kw; ++s) C.wvar[s] = wlist[order[s]];
    std::vector<int> slotOfColor(Kw, -1);
    for (int s = 0; s < Kw; ++s) slotOfColor[order[s]] = s;

    C.xvar.assign(V, std::vector<int>(Kw, -1));
    for (int v = 0; v < V; ++v) {
        std::vector<int> leftoverVars;
        std::vector<char> slotUsed(Kw, 0);
        for (size_t k = 0; k < vrows[v].size(); ++k) {
            int j = vrows[v][k];
            if (colorOfX[j] >= 0) {
                int s = slotOfColor[colorOfX[j]];
                if (s < 0 || C.xvar[v][s] >= 0) return false;
                C.xvar[v][s] = j;
                slotUsed[s] = 1;
            } else leftoverVars.push_back(j);
        }
        size_t p = 0;
        for (int s = 0; s < Kw && p < leftoverVars.size(); ++s)
            if (!slotUsed[s]) C.xvar[v][s] = leftoverVars[p++];
        for (int s = 0; s < Kw; ++s)
            if (C.xvar[v][s] < 0) return false;
    }

    C.adjm.assign(V, std::vector<char>(V, 0));
    for (size_t e = 0; e < edges.size(); ++e) {
        C.adjm[edges[e].first][edges[e].second] = 1;
        C.adjm[edges[e].second][edges[e].first] = 1;
    }
    C.adj.assign(V, std::vector<int>());
    for (int u = 0; u < V; ++u)
        for (int v = 0; v < V; ++v)
            if (C.adjm[u][v]) C.adj[u].push_back(v);
    return true;
}

// DSATUR greedy colouring; returns number of colours used
inline int dsatur(const ColData& C, std::vector<int>& col, Rng& rng, bool randomized) {
    int V = C.V;
    col.assign(V, -1);
    std::vector<std::vector<char> > used(V);
    std::vector<int> sat(V, 0), deg(V, 0);
    for (int v = 0; v < V; ++v) {
        used[v].assign(V + 1, 0);
        deg[v] = (int)C.adj[v].size();
    }
    int maxc = 0;
    for (int step = 0; step < V; ++step) {
        int best = -1;
        for (int v = 0; v < V; ++v) {
            if (col[v] >= 0) continue;
            if (best < 0) { best = v; continue; }
            if (sat[v] > sat[best] || (sat[v] == sat[best] && deg[v] > deg[best]) ||
                (randomized && sat[v] == sat[best] && deg[v] == deg[best] && rng.d01() < 0.5))
                best = v;
        }
        int c = 0;
        while (c < V && used[best][c]) ++c;
        col[best] = c;
        if (c + 1 > maxc) maxc = c + 1;
        for (size_t k = 0; k < C.adj[best].size(); ++k) {
            int u = C.adj[best][k];
            if (!used[u][c]) { used[u][c] = 1; sat[u]++; }
        }
    }
    return maxc;
}

// TabuCol: try to find a proper k-colouring. Returns true on success.
inline bool tabucol(const ColData& C, int k, std::vector<int>& col, double deadline, Rng& rng,
                    long long maxIter) {
    int V = C.V;
    if (k < 1) return false;
    std::vector<std::vector<int> > gamma(V, std::vector<int>(k, 0));
    for (int v = 0; v < V; ++v)
        if (col[v] >= k) col[v] = rng.below(k);
    for (int v = 0; v < V; ++v)
        for (size_t t = 0; t < C.adj[v].size(); ++t) gamma[v][col[C.adj[v][t]]]++;
    int conf = 0;
    for (int v = 0; v < V; ++v) conf += gamma[v][col[v]];
    conf /= 2;
    if (conf == 0) return true;
    std::vector<std::vector<long long> > tabu(V, std::vector<long long>(k, -1));
    int bestConf = conf;
    std::vector<int> bestCol = col;
    for (long long it = 0; it < maxIter; ++it) {
        if ((it & 255) == 0 && now_s() > deadline) break;
        int bv = -1, bc = -1, bd = 1 << 30;
        int ties = 0;
        for (int v = 0; v < V; ++v) {
            if (gamma[v][col[v]] == 0) continue;
            int cv = col[v];
            for (int c = 0; c < k; ++c) {
                if (c == cv) continue;
                int d = gamma[v][c] - gamma[v][cv];
                bool isTabu = tabu[v][c] > it;
                if (isTabu && !(conf + d < bestConf)) continue;
                if (d < bd) { bd = d; bv = v; bc = c; ties = 1; }
                else if (d == bd) {
                    ++ties;
                    if (rng.below(ties) == 0) { bv = v; bc = c; }
                }
            }
        }
        if (bv < 0) {
            // all moves tabu: random kick
            for (int t = 0; t < 3; ++t) {
                int v = rng.below(V);
                int c = rng.below(k);
                if (c == col[v]) continue;
                int cv = col[v];
                conf += gamma[v][c] - gamma[v][cv];
                for (size_t q = 0; q < C.adj[v].size(); ++q) {
                    gamma[C.adj[v][q]][cv]--;
                    gamma[C.adj[v][q]][c]++;
                }
                col[v] = c;
            }
            continue;
        }
        int cv = col[bv];
        conf += bd;
        for (size_t q = 0; q < C.adj[bv].size(); ++q) {
            gamma[C.adj[bv][q]][cv]--;
            gamma[C.adj[bv][q]][bc]++;
        }
        col[bv] = bc;
        tabu[bv][cv] = it + 10 + (long long)(0.6 * conf) + rng.below(10);
        if (conf < bestConf) {
            bestConf = conf;
            bestCol = col;
            if (conf == 0) return true;
        }
    }
    col = bestCol;
    return bestConf == 0;
}

// ------------------------------------------------------------- max clique B&B
struct CliqueBB {
    int V, W;
    std::vector<uint64_t> adj;  // V x W
    std::vector<int> best;
    std::vector<int> cur;
    double deadline;
    bool timeout = false;
    long long nodes = 0;

    void build(const ColData& C) {
        V = C.V;
        W = (V + 63) / 64;
        adj.assign((size_t)V * W, 0);
        for (int u = 0; u < V; ++u)
            for (size_t k = 0; k < C.adj[u].size(); ++k) {
                int v = C.adj[u][k];
                adj[(size_t)u * W + (v >> 6)] |= 1ULL << (v & 63);
            }
    }
    void expand(std::vector<int>& P) {
        if (++nodes % 1024 == 0 && now_s() > deadline) { timeout = true; return; }
        if (timeout) return;
        // greedy colouring bound
        int np = (int)P.size();
        std::vector<int> order(np), col(np);
        std::vector<uint64_t> avail((size_t)W, 0);
        std::vector<int> rest = P;
        int idx = 0, color = 0;
        while (!rest.empty()) {
            ++color;
            std::vector<uint64_t> banned((size_t)W, 0);
            std::vector<int> next;
            for (size_t t = 0; t < rest.size(); ++t) {
                int v = rest[t];
                if ((banned[v >> 6] >> (v & 63)) & 1ULL) { next.push_back(v); continue; }
                order[idx] = v;
                col[idx] = color;
                ++idx;
                for (int w = 0; w < W; ++w) banned[w] |= adj[(size_t)v * W + w];
            }
            rest.swap(next);
            if (color > np) break;
        }
        for (int i = idx - 1; i >= 0; --i) {
            if ((int)cur.size() + col[i] <= (int)best.size()) return;
            int v = order[i];
            cur.push_back(v);
            if (cur.size() > best.size()) best = cur;
            std::vector<int> Q;
            for (int t = 0; t < i; ++t) {
                int u = order[t];
                if ((adj[(size_t)v * W + (u >> 6)] >> (u & 63)) & 1ULL) Q.push_back(u);
            }
            if (!Q.empty()) expand(Q);
            cur.pop_back();
            if (timeout) return;
        }
    }
    int run(const ColData& C, double dl) {
        build(C);
        deadline = dl;
        std::vector<int> P(V);
        for (int v = 0; v < V; ++v) P[v] = v;
        expand(P);
        return (int)best.size();
    }
};

// ------------------------------------------------------------ DSATUR exact B&B
struct DsaturBB {
    const ColData* C;
    int V;
    int UB;
    std::vector<int> col, bestCol;
    std::vector<uint64_t> forb;   // per vertex bitmask of forbidden colours
    std::vector<int> sat, degU;
    double deadline;
    bool timeout = false;
    bool proved = false;
    long long nodes = 0;

    void rec(int done, int maxUsed) {
        if (timeout) return;
        if (++nodes % 512 == 0 && now_s() > deadline) { timeout = true; return; }
        if (done == V) {
            if (maxUsed < UB) { UB = maxUsed; bestCol = col; }
            return;
        }
        int v = -1;
        for (int u = 0; u < V; ++u) {
            if (col[u] >= 0) continue;
            if (v < 0 || sat[u] > sat[v] || (sat[u] == sat[v] && degU[u] > degU[v])) v = u;
        }
        int lim = std::min(maxUsed, UB - 2);
        for (int c = 0; c <= lim; ++c) {
            if ((forb[v] >> c) & 1ULL) continue;
            assign(v, c);
            rec(done + 1, maxUsed);
            unassign(v, c);
            if (timeout) return;
        }
        if (maxUsed + 1 <= UB - 1) {
            int c = maxUsed;
            if (!((forb[v] >> c) & 1ULL)) {
                assign(v, c);
                rec(done + 1, maxUsed + 1);
                unassign(v, c);
            }
        }
    }
    void assign(int v, int c) {
        col[v] = c;
        for (size_t k = 0; k < C->adj[v].size(); ++k) {
            int u = C->adj[v][k];
            if (col[u] < 0) {
                if (!((forb[u] >> c) & 1ULL)) { forb[u] |= 1ULL << c; sat[u]++; }
                degU[u]--;
            }
        }
    }
    void unassign(int v, int c) {
        col[v] = -1;
        for (size_t k = 0; k < C->adj[v].size(); ++k) {
            int u = C->adj[v][k];
            if (col[u] < 0) {
                degU[u]++;
                bool still = false;
                for (size_t q = 0; q < C->adj[u].size(); ++q)
                    if (col[C->adj[u][q]] == c) { still = true; break; }
                if (!still) { forb[u] &= ~(1ULL << c); sat[u]--; }
            }
        }
    }
    // returns true when the search completed (UB proved optimal)
    bool run(const ColData& c, int ub, const std::vector<int>& clique, double dl) {
        C = &c;
        V = C->V;
        UB = ub;
        if (UB > 62) return false;
        deadline = dl;
        col.assign(V, -1);
        forb.assign(V, 0);
        sat.assign(V, 0);
        degU.resize(V);
        for (int v = 0; v < V; ++v) degU[v] = (int)C->adj[v].size();
        int done = 0, maxUsed = 0;
        for (size_t t = 0; t < clique.size(); ++t) {
            int v = clique[t];
            if (col[v] >= 0) continue;
            if ((int)t >= UB - 1) break;
            assign(v, (int)t);
            ++done;
            maxUsed = (int)t + 1;
        }
        rec(done, maxUsed);
        return !timeout;
    }
};

inline int greedyClique(const ColData& C, Rng& rng) {
    int V = C.V;
    int best = 1;
    for (int rep = 0; rep < 200; ++rep) {
        std::vector<int> order(V);
        for (int v = 0; v < V; ++v) order[v] = v;
        for (int v = V - 1; v > 0; --v) std::swap(order[v], order[rng.below(v + 1)]);
        std::vector<int> cl;
        for (int t = 0; t < V; ++t) {
            int v = order[t];
            bool ok = true;
            for (size_t q = 0; q < cl.size(); ++q)
                if (!C.adjm[v][cl[q]]) { ok = false; break; }
            if (ok) cl.push_back(v);
        }
        if ((int)cl.size() > best) best = (int)cl.size();
    }
    return best;
}

inline bool tryColoring(const Instance& in, double deadline, Reporter& rep) {
    ColData C;
    if (!extractColoring(in, C)) return false;
    int V = C.V, K = C.K;
    Rng rng(4242);
    std::vector<int> x(in.n, 0);

    auto emit = [&](const std::vector<int>& col, int t) -> bool {
        std::fill(x.begin(), x.end(), 0);
        for (int v = 0; v < V; ++v) {
            int s = col[v];
            if (s < 0 || s >= K) return false;
            x[C.xvar[v][s]] = 1;
        }
        for (int s = 0; s < t; ++s) x[C.wvar[s]] = 1;
        if (!isFeasible(in, x)) return false;
        rep.update(x, objValue(in, x));
        return true;
    };

    std::vector<int> col, bestCol;
    int bestT = K + 1;
    int ub = dsatur(C, col, rng, false);
    if (ub <= K) {
        bestT = ub;
        bestCol = col;
        emit(col, ub);
    }
    for (int r = 0; r < 40 && now_s() < deadline * 0.1; ++r) {
        std::vector<int> c2;
        int u2 = dsatur(C, c2, rng, true);
        if (u2 < bestT && u2 <= K) {
            bestT = u2;
            bestCol = c2;
            emit(c2, u2);
        }
    }
    CliqueBB cbb;
    int lb = cbb.run(C, std::min(deadline, now_s() + 4.0));
    std::vector<int> clique = cbb.best;
    if (lb < 1) lb = greedyClique(C, rng);
    if (dbg())
        fprintf(stderr, "# coloring V=%d K=%d dsatur=%d lb=%d(exact=%d) t=%.2f\n", V, K, ub, lb,
                (int)!cbb.timeout, now_s());

    if (bestT <= lb && rep.has) return true;

    // descend; keep restarting on the current target until the budget is spent
    double heurEnd = now_s() + (deadline - now_s()) * (V <= 45 ? 0.45 : 0.85);
    int t = (bestT <= K ? bestT - 1 : K);
    int attempt = 0;
    while (t >= lb && now_s() < heurEnd) {
        std::vector<int> c2(V);
        if (attempt == 0 && !bestCol.empty()) {
            c2 = bestCol;
            for (int v = 0; v < V; ++v)
                if (c2[v] >= t) c2[v] = rng.below(t);
        } else if (attempt % 3 == 1 && !bestCol.empty()) {
            dsatur(C, c2, rng, true);
            for (int v = 0; v < V; ++v)
                if (c2[v] >= t) c2[v] = rng.below(t);
        } else {
            for (int v = 0; v < V; ++v) c2[v] = rng.below(t);
        }
        double chunk = std::min(heurEnd, now_s() + 0.5 + (heurEnd - now_s()) * 0.15);
        bool found = tabucol(C, t, c2, chunk, rng, 100000000LL);
        if (found) {
            bestT = t;
            bestCol = c2;
            emit(c2, t);
            if (dbg()) fprintf(stderr, "# coloring found t=%d at %.2f\n", t, now_s());
            --t;
            attempt = 0;
        } else {
            ++attempt;
        }
    }
    if (bestT > lb && now_s() < deadline && bestT <= 62) {
        DsaturBB bb;
        bool complete = bb.run(C, bestT, clique, deadline);
        if (bb.UB < bestT && !bb.bestCol.empty()) {
            bestT = bb.UB;
            bestCol = bb.bestCol;
            emit(bestCol, bestT);
        }
        if (dbg())
            fprintf(stderr, "# coloring bb complete=%d nodes=%lld ub=%d t=%.2f\n", (int)complete,
                    bb.nodes, bestT, now_s());
    }
    if (dbg()) fprintf(stderr, "# coloring final=%d lb=%d\n", bestT, lb);
    if (!rep.has) return false;
    return true;
}
