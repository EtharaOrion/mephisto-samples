#pragma once
#include "instance.hpp"
#include "report.hpp"

// Multi-dimensional knapsack: Lagrangian duals for a valid upper bound and
// pseudo-utility ordering, then iterated greedy + exchange local search.

static double g_mdkpDiff = 0.0;
static bool g_mdkpHave = false;

struct MkpData {
    int n = 0, m = 0;
    std::vector<std::vector<double> > A;  // m x n
    std::vector<double> b, p;
    std::vector<double> y;   // lagrange multipliers
    double ub = 1e300;
};

inline bool extractMKP(const Instance& in, MkpData& M) {
    if (!in.maximize) return false;
    int n = in.n;
    int m = (int)in.rows.size();
    if (m < 1) return false;
    for (int i = 0; i < m; ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_LE) return false;
        for (size_t k = 0; k < r.val.size(); ++k)
            if (r.val[k] < 0) return false;
        if (r.rhs < 0) return false;
    }
    for (int j = 0; j < n; ++j)
        if (in.obj[j] < 0) return false;
    M.n = n;
    M.m = m;
    M.A.assign(m, std::vector<double>(n, 0.0));
    M.b.resize(m);
    M.p.resize(n);
    for (int i = 0; i < m; ++i) {
        const Row& r = in.rows[i];
        for (size_t k = 0; k < r.idx.size(); ++k) M.A[i][r.idx[k]] = r.val[k];
        M.b[i] = r.rhs;
    }
    for (int j = 0; j < n; ++j) M.p[j] = in.obj[j];
    return true;
}

inline double lagrangianBound(const MkpData& M, const std::vector<double>& y) {
    double v = 0.0;
    for (int i = 0; i < M.m; ++i) v += y[i] * M.b[i];
    for (int j = 0; j < M.n; ++j) {
        double rc = M.p[j];
        for (int i = 0; i < M.m; ++i) rc -= y[i] * M.A[i][j];
        if (rc > 0) v += rc;
    }
    return v;
}

inline void lagrangianSolve(MkpData& M, double incumbent, double deadline, int iters) {
    int n = M.n, m = M.m;
    M.y.assign(m, 0.0);
    // initial multipliers: scale by profit density
    double sump = 0.0;
    for (int j = 0; j < n; ++j) sump += M.p[j];
    for (int i = 0; i < m; ++i) {
        double sa = 0.0;
        for (int j = 0; j < n; ++j) sa += M.A[i][j];
        M.y[i] = (sa > 0) ? (sump / (sa * m)) * 0.5 : 0.0;
    }
    std::vector<double> best = M.y;
    double bestUB = lagrangianBound(M, M.y);
    double lambda = 2.0;
    std::vector<int> xb(n);
    std::vector<double> g(m);
    int noImp = 0;
    for (int it = 0; it < iters; ++it) {
        if ((it & 15) == 0 && now_s() > deadline) break;
        for (int j = 0; j < n; ++j) {
            double rc = M.p[j];
            for (int i = 0; i < m; ++i) rc -= M.y[i] * M.A[i][j];
            xb[j] = rc > 0 ? 1 : 0;
        }
        double ub = 0.0;
        for (int i = 0; i < m; ++i) ub += M.y[i] * M.b[i];
        for (int j = 0; j < n; ++j)
            if (xb[j]) {
                double rc = M.p[j];
                for (int i = 0; i < m; ++i) rc -= M.y[i] * M.A[i][j];
                ub += rc;
            }
        if (ub < bestUB) {
            bestUB = ub;
            best = M.y;
            noImp = 0;
        } else if (++noImp > 20) {
            lambda *= 0.7;
            noImp = 0;
            if (lambda < 1e-4) break;
        }
        double gn = 0.0;
        for (int i = 0; i < m; ++i) {
            double s = -M.b[i];
            for (int j = 0; j < n; ++j)
                if (xb[j]) s += M.A[i][j];
            g[i] = s;
            gn += s * s;
        }
        if (gn < 1e-12) break;
        double target = incumbent > 0 ? incumbent : ub * 0.9;
        double step = lambda * (ub - target) / gn;
        if (step <= 0) step = lambda * std::fabs(ub) * 1e-6 / gn;
        for (int i = 0; i < m; ++i) {
            M.y[i] += step * g[i];
            if (M.y[i] < 0) M.y[i] = 0.0;
        }
    }
    M.y = best;
    M.ub = bestUB;
}

struct MkpLS {
    MkpData* M;
    std::vector<int> x;
    std::vector<double> use;
    double val = 0.0;

    void init(MkpData& m) {
        M = &m;
        x.assign(M->n, 0);
        use.assign(M->m, 0.0);
        val = 0.0;
    }
    bool fits(int j) const {
        for (int i = 0; i < M->m; ++i)
            if (use[i] + M->A[i][j] > M->b[i] + 1e-9) return false;
        return true;
    }
    void add(int j) {
        for (int i = 0; i < M->m; ++i) use[i] += M->A[i][j];
        val += M->p[j];
        x[j] = 1;
    }
    void del(int j) {
        for (int i = 0; i < M->m; ++i) use[i] -= M->A[i][j];
        val -= M->p[j];
        x[j] = 0;
    }
};

inline bool tryMDKP(const Instance& in, double deadline, Reporter& rep) {
    if (!in.family.empty() && in.family != "multi-dimensional-knapsack") return false;
    MkpData M;
    if (!extractMKP(in, M)) return false;
    int n = M.n, m = M.m;
    if (n < 1) return false;

    Rng rng(20240517ULL);
    MkpLS S;
    S.init(M);

    // initial greedy by profit / normalised weight
    std::vector<double> score(n);
    std::vector<int> ord(n);
    for (int j = 0; j < n; ++j) ord[j] = j;

    auto greedyFill = [&](MkpLS& s, const std::vector<double>& sc, double noise) {
        std::vector<int> o(n);
        for (int j = 0; j < n; ++j) o[j] = j;
        std::vector<double> key(n);
        for (int j = 0; j < n; ++j) key[j] = sc[j] * (1.0 + noise * (rng.d01() - 0.5));
        std::sort(o.begin(), o.end(), [&](int a, int b) {
            if (key[a] != key[b]) return key[a] > key[b];
            return a < b;
        });
        for (int t = 0; t < n; ++t) {
            int j = o[t];
            if (!s.x[j] && s.fits(j)) s.add(j);
        }
    };

    {
        std::vector<double> norm(n, 0.0);
        for (int j = 0; j < n; ++j) {
            double w = 0.0;
            for (int i = 0; i < m; ++i)
                if (M.b[i] > 0) w += M.A[i][j] / M.b[i];
            norm[j] = M.p[j] / (w + 1e-12);
        }
        greedyFill(S, norm, 0.0);
    }
    std::vector<int> bx = S.x;
    double bestVal = S.val;
    rep.update(S.x, bestVal);

    lagrangianSolve(M, bestVal, std::min(deadline, now_s() + 3.0), 3000);

    // pseudo-utility from duals
    for (int j = 0; j < n; ++j) {
        double w = 0.0;
        for (int i = 0; i < m; ++i) w += M.y[i] * M.A[i][j];
        score[j] = M.p[j] / (w + 1e-9);
    }
    {
        MkpLS s2;
        s2.init(M);
        greedyFill(s2, score, 0.0);
        if (s2.val > bestVal) {
            bestVal = s2.val;
            bx = s2.x;
            S = s2;
            rep.update(bx, bestVal);
        }
    }

    // local search: 1-1 / 2-1 exchange descent + destroy&repair
    std::vector<int> selected, unselected;
    auto descent = [&](MkpLS& s) {
        bool imp = true;
        while (imp) {
            imp = false;
            if (now_s() > deadline) return;
            // add anything that fits
            for (int j = 0; j < n; ++j)
                if (!s.x[j] && s.fits(j)) { s.add(j); imp = true; }
            // 1-1 swaps
            selected.clear();
            unselected.clear();
            for (int j = 0; j < n; ++j) (s.x[j] ? selected : unselected).push_back(j);
            for (size_t a = 0; a < selected.size(); ++a) {
                int j = selected[a];
                if (!s.x[j]) continue;
                s.del(j);
                int bestk = -1;
                double bestg = 1e-9;
                for (size_t bq = 0; bq < unselected.size(); ++bq) {
                    int k = unselected[bq];
                    if (s.x[k]) continue;
                    double g = M.p[k] - M.p[j];
                    if (g <= bestg) continue;
                    if (!s.fits(k)) continue;
                    bestg = g;
                    bestk = k;
                }
                if (bestk >= 0) {
                    s.add(bestk);
                    imp = true;
                } else s.add(j);
            }
        }
    };

    descent(S);
    if (S.val > bestVal) {
        bestVal = S.val;
        bx = S.x;
        rep.update(bx, bestVal);
    }

    MkpLS cur = S;
    double curVal = cur.val;
    long long iter = 0;
    while (now_s() < deadline) {
        ++iter;
        MkpLS s = cur;
        int nsel = 0;
        for (int j = 0; j < n; ++j) nsel += s.x[j];
        int d = 1 + rng.below(std::max(1, std::min(nsel, 1 + nsel / 4)));
        for (int t = 0; t < d; ++t) {
            int tries = 0;
            while (tries++ < 20) {
                int j = rng.below(n);
                if (s.x[j]) { s.del(j); break; }
            }
        }
        // repair with dynamic surrogate
        std::vector<double> sc(n);
        int mode = rng.below(3);
        for (int j = 0; j < n; ++j) {
            double w = 0.0;
            if (mode == 0) {
                for (int i = 0; i < m; ++i) w += M.y[i] * M.A[i][j];
            } else if (mode == 1) {
                for (int i = 0; i < m; ++i) {
                    double slack = M.b[i] - s.use[i];
                    w += M.A[i][j] / (slack > 1e-9 ? slack : 1e-9);
                }
            } else {
                for (int i = 0; i < m; ++i)
                    if (M.b[i] > 0) w += M.A[i][j] / M.b[i];
            }
            sc[j] = M.p[j] / (w + 1e-9);
        }
        greedyFill(s, sc, 0.15);
        descent(s);
        if (s.val > bestVal + 1e-9) {
            bestVal = s.val;
            bx = s.x;
            rep.update(bx, bestVal);
            cur = s;
            curVal = s.val;
        } else if (s.val >= curVal - 1e-9 || rng.d01() < 0.02) {
            cur = s;
            curVal = s.val;
        }
        if ((iter % 500) == 0) {
            cur.init(M);
            for (int j = 0; j < n; ++j) cur.x[j] = 0;
            cur.use.assign(m, 0.0);
            cur.val = 0;
            greedyFill(cur, score, 0.5);
            descent(cur);
            curVal = cur.val;
        }
    }
    double relgap = (M.ub - bestVal) / std::max(1.0, std::fabs(bestVal));
    if (relgap < 0) relgap = 0;
    g_mdkpDiff = 10.0 + 100.0 * relgap + 0.5 * std::log((double)std::max(2, n));
    g_mdkpHave = true;
    return true;
}
