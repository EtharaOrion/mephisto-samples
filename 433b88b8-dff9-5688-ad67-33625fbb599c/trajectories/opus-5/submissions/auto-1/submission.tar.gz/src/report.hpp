#pragma once
#include "instance.hpp"
#include <unistd.h>
#include <csignal>

// Global incumbent + output buffering so a watchdog signal can flush a valid
// answer even if a solver overruns.

struct Reporter {
    std::string id;
    bool maximize = false;
    int n = 0;
    const std::vector<int>* varPerm = 0;  // canonical pos -> original index
    bool has = false;
    double best = 0.0;
    std::vector<int> bestX;  // canonical order
    int tokens = 0;
    double lastFlush = -1e9;
    double lastToken = -1e9;
    bool pending = false;

    std::vector<char> buf;
    volatile size_t buflen = 0;

    void init(const std::string& id_, bool mx, int n_, const std::vector<int>* vp) {
        id = id_;
        maximize = mx;
        n = n_;
        varPerm = vp;
        buf.resize((size_t)n * 3 + id.size() + 256);
        renderNoSolution();
    }

    void renderNoSolution() {
        std::string s = "{\"instance_id\": \"" + id +
                        "\", \"status\": \"unknown\", \"variables\": null, \"objective_value\": null}\n";
        if (buf.size() < s.size() + 8) buf.resize(s.size() + 8);
        memcpy(buf.data(), s.data(), s.size());
        buflen = s.size();
    }

    void render() {
        std::vector<int> xo(n, 0);
        for (int c = 0; c < n; ++c) xo[(*varPerm)[c]] = bestX[c];
        size_t need = (size_t)n * 3 + id.size() + 256;
        if (buf.size() < need) buf.resize(need);
        char* w = buf.data();
        int k = snprintf(w, 64 + id.size(), "{\"instance_id\": \"%s\", \"status\": \"optimal\", \"variables\": [",
                         id.c_str());
        w += k;
        for (int j = 0; j < n; ++j) {
            if (j) *w++ = ',';
            *w++ = xo[j] ? '1' : '0';
        }
        *w++ = ']';
        double v = best;
        char num[64];
        double rv = std::floor(v + 0.5);
        if (std::fabs(v - rv) < 1e-6 && std::fabs(rv) < 9.0e15)
            snprintf(num, sizeof(num), "%lld", (long long)rv);
        else
            snprintf(num, sizeof(num), "%.10f", v);
        int k2 = snprintf(w, 128, ", \"objective_value\": %s}\n", num);
        w += k2;
        buflen = (size_t)(w - buf.data());
    }

    void token(double v) {
        fprintf(stderr, "BEST ts=%.3f obj=%.6f\n", now_s(), v);
        fflush(stderr);
        ++tokens;
    }

    bool better(double v) const {
        if (!has) return true;
        return maximize ? (v > best + 1e-9) : (v < best - 1e-9);
    }

    void update(const std::vector<int>& x, double v) {
        if (!better(v)) return;
        best = v;
        bestX = x;
        has = true;
        pending = true;
        double t = now_s();
        if (tokens == 0 || t - lastToken >= 0.03) {
            token(v);
            lastToken = t;
            pending = false;
        }
        if (t - lastFlush > 0.25) {
            render();
            lastFlush = t;
        }
    }

    void finish() {
        if (has) {
            render();
            if (pending) token(best);
            while (tokens < 2) token(best);
        }
        ssize_t r = write(1, buf.data(), buflen);
        (void)r;
    }

    void emergency() {
        if (has) {
            token(best);
        }
        ssize_t r = write(1, buf.data(), buflen);
        (void)r;
    }
};

static Reporter g_rep;

extern "C" void watchdog_handler(int) {
    g_rep.emergency();
    _exit(0);
}
