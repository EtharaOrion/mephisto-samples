#pragma once
#include "instance.hpp"
#include "report.hpp"

// Single 0-1 knapsack: greedy + exact meet-in-the-middle window local search
// (an exact K-opt neighbourhood), with a full DP when the capacity is small.

struct MitmSolver {
    int h1, h2;
    std::vector<double> aw, ap;
    std::vector<unsigned> am;
    std::vector<double> bw, bp;
    std::vector<unsigned> bm;
    std::vector<int> ordA;

    // returns best profit and fills chosen mask over window items
    double solve(const std::vector<double>& w, const std::vector<double>& p, double cap,
                 unsigned long long& chosen) {
        int K = (int)w.size();
        h1 = K / 2;
        h2 = K - h1;
        int NA = 1 << h1, NB = 1 << h2;
        aw.assign(NA, 0.0);
        ap.assign(NA, 0.0);
        bw.assign(NB, 0.0);
        bp.assign(NB, 0.0);
        for (int mask = 1; mask < NA; ++mask) {
            int b = __builtin_ctz((unsigned)mask);
            int pm = mask ^ (1 << b);
            aw[mask] = aw[pm] + w[b];
            ap[mask] = ap[pm] + p[b];
        }
        for (int mask = 1; mask < NB; ++mask) {
            int b = __builtin_ctz((unsigned)mask);
            int pm = mask ^ (1 << b);
            bw[mask] = bw[pm] + w[h1 + b];
            bp[mask] = bp[pm] + p[h1 + b];
        }
        ordA.resize(NA);
        int cntA = 0;
        for (int mask = 0; mask < NA; ++mask)
            if (aw[mask] <= cap + 1e-9) ordA[cntA++] = mask;
        ordA.resize(cntA);
        std::sort(ordA.begin(), ordA.end(), [&](int a, int b) { return aw[a] < aw[b]; });
        std::vector<double> pref(cntA);
        std::vector<int> prefIdx(cntA);
        double bp_ = -1e300;
        int bi = -1;
        for (int i = 0; i < cntA; ++i) {
            if (ap[ordA[i]] > bp_) { bp_ = ap[ordA[i]]; bi = ordA[i]; }
            pref[i] = bp_;
            prefIdx[i] = bi;
        }
        double best = -1e300;
        unsigned bestA = 0, bestB = 0;
        for (int mb = 0; mb < NB; ++mb) {
            double rem = cap - bw[mb];
            if (rem < -1e-9) continue;
            // binary search largest i with aw[ordA[i]] <= rem
            int lo = 0, hi = cntA - 1, pos = -1;
            while (lo <= hi) {
                int mid = (lo + hi) >> 1;
                if (aw[ordA[mid]] <= rem + 1e-9) { pos = mid; lo = mid + 1; }
                else hi = mid - 1;
            }
            if (pos < 0) continue;
            double tot = bp[mb] + pref[pos];
            if (tot > best) {
                best = tot;
                bestA = (unsigned)prefIdx[pos];
                bestB = (unsigned)mb;
            }
        }
        chosen = (unsigned long long)bestA | ((unsigned long long)bestB << h1);
        return best;
    }
};

inline bool tryKnapsack(const Instance& in, double deadline, Reporter& rep) {
    if (!in.family.empty() && in.family != "zero-one-knapsack") return false;
    if (!in.maximize) return false;
    if (in.rows.size() != 1) return false;
    const Row& r = in.rows[0];
    if (r.sense != S_LE) return false;
    int n = in.n;
    if ((int)r.idx.size() != n) return false;
    std::vector<double> w(n), p(n);
    for (int k = 0; k < n; ++k) {
        if (r.val[k] <= 0) return false;
        w[r.idx[k]] = r.val[k];
    }
    for (int j = 0; j < n; ++j) {
        p[j] = in.obj[j];
        if (p[j] < 0) return false;
    }
    double cap = r.rhs;
    if (cap < 0) return false;

    std::vector<int> x(n, 0);
    double totalW = 0;
    for (int j = 0; j < n; ++j) totalW += w[j];
    if (totalW <= cap + 1e-9) {
        for (int j = 0; j < n; ++j) x[j] = 1;
        rep.update(x, objValue(in, x));
        rep.update(x, objValue(in, x));
        return true;
    }

    // exact DP when capacity is small integral
    bool intW = true;
    for (int j = 0; j < n && intW; ++j)
        if (std::fabs(w[j] - std::floor(w[j] + 0.5)) > 1e-9) intW = false;
    if (intW && std::fabs(cap - std::floor(cap + 0.5)) < 1e-9 && cap <= 200000.0 &&
        (double)n * cap <= 4.0e8) {
        long long C = (long long)(cap + 0.5);
        std::vector<double> dp((size_t)C + 1, 0.0);
        std::vector<uint64_t> take((size_t)(n) * (size_t)((C + 64) / 64), 0);
        size_t stride = (size_t)((C + 64) / 64);
        for (int j = 0; j < n; ++j) {
            long long wj = (long long)(w[j] + 0.5);
            if (wj > C) continue;
            double pj = p[j];
            uint64_t* tk = &take[(size_t)j * stride];
            for (long long c = C; c >= wj; --c) {
                double v = dp[(size_t)(c - wj)] + pj;
                if (v > dp[(size_t)c] + 1e-12) {
                    dp[(size_t)c] = v;
                    tk[(size_t)(c >> 6)] |= (1ULL << (c & 63));
                }
            }
        }
        long long c = C;
        for (int j = n - 1; j >= 0; --j) {
            uint64_t* tk = &take[(size_t)j * stride];
            if (c >= 0 && (tk[(size_t)(c >> 6)] >> (c & 63)) & 1ULL) {
                x[j] = 1;
                c -= (long long)(w[j] + 0.5);
            }
        }
        rep.update(x, objValue(in, x));
        rep.update(x, objValue(in, x));
        return true;
    }

    // greedy by ratio
    std::vector<int> ord(n);
    for (int j = 0; j < n; ++j) ord[j] = j;
    std::sort(ord.begin(), ord.end(), [&](int a, int b) {
        double ra = p[a] / w[a], rb = p[b] / w[b];
        if (ra != rb) return ra > rb;
        if (w[a] != w[b]) return w[a] < w[b];
        return a < b;
    });
    double used = 0.0;
    int splitPos = n;
    for (int t = 0; t < n; ++t) {
        int j = ord[t];
        if (used + w[j] <= cap + 1e-9) {
            x[j] = 1;
            used += w[j];
        } else if (splitPos == n) splitPos = t;
    }
    double cur = objValue(in, x);
    rep.update(x, cur);

    Rng rng(9182736451ULL);
    MitmSolver ms;
    int K = 30;
    std::vector<int> win;
    std::vector<double> ww, pp;
    long long iters = 0;
    int coreW = std::min(n, 400);
    while (now_s() < deadline) {
        ++iters;
        win.clear();
        // pick K distinct items, biased toward the ratio split point
        static std::vector<char> mark;
        if ((int)mark.size() != n) mark.assign(n, 0);
        int guard = 0;
        while ((int)win.size() < K && guard < 20 * K) {
            ++guard;
            int t;
            if (rng.d01() < 0.75) {
                int lo = std::max(0, splitPos - coreW / 2);
                int hi = std::min(n - 1, splitPos + coreW / 2);
                t = lo + rng.below(hi - lo + 1);
            } else t = rng.below(n);
            int j = ord[t];
            if (mark[j]) continue;
            mark[j] = 1;
            win.push_back(j);
        }
        double freeCap = cap - used;
        ww.resize(win.size());
        pp.resize(win.size());
        for (size_t q = 0; q < win.size(); ++q) {
            int j = win[q];
            ww[q] = w[j];
            pp[q] = p[j];
            if (x[j]) freeCap += w[j];
        }
        unsigned long long chosen = 0;
        double bestP = ms.solve(ww, pp, freeCap, chosen);
        double oldP = 0.0;
        for (size_t q = 0; q < win.size(); ++q)
            if (x[win[q]]) oldP += p[win[q]];
        if (bestP > oldP + 1e-9) {
            for (size_t q = 0; q < win.size(); ++q) {
                int j = win[q];
                int nv = (chosen >> q) & 1ULL;
                if (nv != x[j]) {
                    used += nv ? w[j] : -w[j];
                    x[j] = nv;
                }
            }
            cur = objValue(in, x);
            rep.update(x, cur);
        }
        for (size_t q = 0; q < win.size(); ++q) mark[win[q]] = 0;
        if ((iters & 1023) == 0) {
            coreW = std::min(n, coreW + 100);
        }
    }
    return true;
}
