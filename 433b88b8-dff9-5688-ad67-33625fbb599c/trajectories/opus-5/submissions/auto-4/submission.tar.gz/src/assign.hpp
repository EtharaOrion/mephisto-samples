#pragma once
#include "instance.hpp"
#include "report.hpp"

// Generalised assignment / capacitated facility location.
//   groups   : exactly-one rows (job -> machine, customer -> facility)
//   resources: <= rows, optionally with a -cap * y indicator term
// Solved with penalty-based tabu search over the assignment vector.

struct AsgOpt {
    int var;
    int res;
    double w;
    double cost;
};

struct AsgData {
    int G = 0, R = 0;
    std::vector<std::vector<AsgOpt> > opt;
    std::vector<double> capClosed, capOpen, fixedCost;
    std::vector<int> yvar;
    std::vector<int> freeVars;  // vars in no row
    std::vector<double> freeCost;
};

inline bool extractAsg(const Instance& in, AsgData& D) {
    if (in.maximize) return false;
    int n = in.n, m = (int)in.rows.size();
    std::vector<int> groupOf(n, -1);
    std::vector<std::vector<int> > grows;
    std::vector<char> isGroupRow(m, 0);
    for (int i = 0; i < m; ++i) {
        const Row& r = in.rows[i];
        if (r.sense != S_EQ || std::fabs(r.rhs - 1.0) > 1e-9 || r.idx.size() < 2) continue;
        bool unit = true;
        for (size_t k = 0; k < r.val.size(); ++k)
            if (std::fabs(r.val[k] - 1.0) > 1e-9) { unit = false; break; }
        if (!unit) continue;
        bool fresh = true;
        for (size_t k = 0; k < r.idx.size(); ++k)
            if (groupOf[r.idx[k]] >= 0) { fresh = false; break; }
        if (!fresh) continue;
        int g = (int)grows.size();
        grows.push_back(r.idx);
        for (size_t k = 0; k < r.idx.size(); ++k) groupOf[r.idx[k]] = g;
        isGroupRow[i] = 1;
    }
    int G = (int)grows.size();
    if (G < 1) return false;

    std::vector<int> resOfVar(n, -1);
    std::vector<double> wOfVar(n, 0.0);
    D.capClosed.clear();
    D.capOpen.clear();
    D.fixedCost.clear();
    D.yvar.clear();
    std::vector<char> touched(n, 0);
    for (int i = 0; i < m; ++i) {
        if (isGroupRow[i]) continue;
        const Row& r = in.rows[i];
        if (r.sense != S_LE) return false;
        int yv = -1;
        double negc = 0.0;
        for (size_t k = 0; k < r.idx.size(); ++k) {
            int j = r.idx[k];
            double v = r.val[k];
            if (v < 0) {
                if (groupOf[j] >= 0) return false;
                if (yv >= 0) return false;
                yv = j;
                negc = -v;
            } else if (v > 0) {
                if (groupOf[j] < 0) return false;
                if (resOfVar[j] >= 0) return false;
                resOfVar[j] = (int)D.capClosed.size();
                wOfVar[j] = v;
            }
        }
        double cc = r.rhs;
        double co = r.rhs + (yv >= 0 ? negc : 0.0);
        D.capClosed.push_back(cc);
        D.capOpen.push_back(co);
        D.yvar.push_back(yv);
        D.fixedCost.push_back(yv >= 0 ? in.obj[yv] : 0.0);
        if (yv >= 0) touched[yv] = 1;
    }
    int R = (int)D.capClosed.size();
    // dummy unconstrained resource
    D.capClosed.push_back(1e300);
    D.capOpen.push_back(1e300);
    D.yvar.push_back(-1);
    D.fixedCost.push_back(0.0);
    int dummy = R;
    D.R = R + 1;

    D.G = G;
    D.opt.assign(G, std::vector<AsgOpt>());
    for (int g = 0; g < G; ++g) {
        for (size_t k = 0; k < grows[g].size(); ++k) {
            int j = grows[g][k];
            AsgOpt o;
            o.var = j;
            o.res = resOfVar[j] >= 0 ? resOfVar[j] : dummy;
            o.w = resOfVar[j] >= 0 ? wOfVar[j] : 0.0;
            o.cost = in.obj[j];
            D.opt[g].push_back(o);
        }
    }
    // remaining vars: must be untouched and appear in no rows
    D.freeVars.clear();
    D.freeCost.clear();
    for (int j = 0; j < n; ++j) {
        if (groupOf[j] >= 0 || touched[j]) continue;
        if (!in.colRows[j].empty()) return false;
        D.freeVars.push_back(j);
        D.freeCost.push_back(in.obj[j]);
    }
    return true;
}

struct AsgSearch {
    const AsgData* D;
    std::vector<int> a;     // group -> option index
    std::vector<double> load;
    double P = 1.0;
    double assignCost = 0.0;

    double resCost(int r, double ld) const {
        double v = 0.0;
        if (ld > D->capClosed[r] + 1e-9) v += D->fixedCost[r];
        else if (D->fixedCost[r] < 0) v += D->fixedCost[r];
        if (ld > D->capOpen[r] + 1e-9) v += P * (ld - D->capOpen[r]);
        return v;
    }
    double overload() const {
        double s = 0.0;
        for (int r = 0; r < D->R; ++r)
            if (load[r] > D->capOpen[r] + 1e-9) s += load[r] - D->capOpen[r];
        return s;
    }
    double totalCost() const {
        double v = assignCost;
        for (int r = 0; r < D->R; ++r) v += resCost(r, load[r]);
        return v;
    }
    double trueCost() const {
        double v = assignCost;
        for (int r = 0; r < D->R; ++r) {
            if (load[r] > D->capClosed[r] + 1e-9) v += D->fixedCost[r];
            else if (D->fixedCost[r] < 0) v += D->fixedCost[r];
        }
        return v;
    }
    void recompute() {
        load.assign(D->R, 0.0);
        assignCost = 0.0;
        for (int g = 0; g < D->G; ++g) {
            const AsgOpt& o = D->opt[g][a[g]];
            load[o.res] += o.w;
            assignCost += o.cost;
        }
    }
    void apply(int g, int no) {
        const AsgOpt& oo = D->opt[g][a[g]];
        const AsgOpt& nn = D->opt[g][no];
        load[oo.res] -= oo.w;
        load[nn.res] += nn.w;
        assignCost += nn.cost - oo.cost;
        a[g] = no;
    }
    double delta(int g, int no) const {
        const AsgOpt& oo = D->opt[g][a[g]];
        const AsgOpt& nn = D->opt[g][no];
        if (oo.res == nn.res) {
            double d = nn.cost - oo.cost;
            double l0 = load[oo.res];
            double l1 = l0 - oo.w + nn.w;
            return d + resCost(oo.res, l1) - resCost(oo.res, l0);
        }
        double d = nn.cost - oo.cost;
        d += resCost(oo.res, load[oo.res] - oo.w) - resCost(oo.res, load[oo.res]);
        d += resCost(nn.res, load[nn.res] + nn.w) - resCost(nn.res, load[nn.res]);
        return d;
    }
};

// Lagrangian relaxation of the resource rows: a valid lower bound used to
// decide when the incumbent is provably optimal.
inline double asgDualValue(const AsgData& D, const std::vector<double>& lam) {
    double lb = 0.0;
    for (int g = 0; g < D.G; ++g) {
        const std::vector<AsgOpt>& os = D.opt[g];
        double bv = 1e300;
        for (size_t k = 0; k < os.size(); ++k) {
            double v = os[k].cost + lam[os[k].res] * os[k].w;
            if (v < bv) bv = v;
        }
        lb += bv;
    }
    for (int r = 0; r < D.R; ++r) {
        if (D.capClosed[r] > 1e299) continue;
        double withY = D.fixedCost[r] - lam[r] * (D.capOpen[r] - D.capClosed[r]);
        lb -= lam[r] * D.capClosed[r];
        if (withY < 0) lb += withY;
    }
    for (size_t q = 0; q < D.freeCost.size(); ++q)
        if (D.freeCost[q] < 0) lb += D.freeCost[q];
    return lb;
}

inline double asgRefineDuals(const AsgData& D, std::vector<double>& lam, double deadline) {
    double cur = asgDualValue(D, lam);
    for (int sweep = 0; sweep < 40; ++sweep) {
        double before = cur;
        for (int r = 0; r < D.R; ++r) {
            if (D.capClosed[r] > 1e299) continue;
            if (now_s() > deadline) return cur;
            double lo = 0.0, hi = std::max(1.0, lam[r] * 4.0 + 1.0);
            double save = lam[r];
            for (int e = 0; e < 24; ++e) {
                lam[r] = hi;
                double fh = asgDualValue(D, lam);
                lam[r] = hi * 0.99;
                double fh2 = asgDualValue(D, lam);
                if (fh < fh2) break;
                hi *= 2.0;
            }
            lam[r] = save;
            for (int t = 0; t < 45 && hi - lo > 1e-10 * (1.0 + hi); ++t) {
                double a = lo + (hi - lo) / 3.0, b = hi - (hi - lo) / 3.0;
                lam[r] = a;
                double fa = asgDualValue(D, lam);
                lam[r] = b;
                double fb = asgDualValue(D, lam);
                lam[r] = save;
                if (fa > fb) hi = b;
                else lo = a;
            }
            lam[r] = 0.5 * (lo + hi);
            double f = asgDualValue(D, lam);
            if (f > cur) cur = f;
            else lam[r] = save;
        }
        if (cur - before < 1e-9 * (1.0 + std::fabs(cur))) break;
    }
    return cur;
}

inline double asgLowerBound(const AsgData& D, double ub, double deadline, int iters) {
    int R = D.R, G = D.G;
    std::vector<double> lam(R, 0.0), best(R, 0.0), sub(R);
    double bestLB = -1e300;
    double lambda = 2.0;
    int noImp = 0;
    std::vector<double> load(R);
    for (int it = 0; it < iters; ++it) {
        if ((it & 15) == 0 && now_s() > deadline) break;
        double lb = 0.0;
        for (int r = 0; r < R; ++r) load[r] = 0.0;
        for (int g = 0; g < G; ++g) {
            const std::vector<AsgOpt>& os = D.opt[g];
            int bi = 0;
            double bv = 1e300;
            for (size_t k = 0; k < os.size(); ++k) {
                double v = os[k].cost + lam[os[k].res] * os[k].w;
                if (v < bv) { bv = v; bi = (int)k; }
            }
            lb += bv;
            load[os[bi].res] += os[bi].w;
        }
        for (int r = 0; r < R; ++r) {
            if (D.capClosed[r] > 1e299) continue;
            double span = D.capOpen[r] - D.capClosed[r];
            double withY = D.fixedCost[r] - lam[r] * span;
            double use = D.capClosed[r];
            lb -= lam[r] * D.capClosed[r];
            if (withY < 0) {
                lb += withY;
                use = D.capOpen[r];
            }
            sub[r] = load[r] - use;
        }
        for (size_t q = 0; q < D.freeCost.size(); ++q)
            if (D.freeCost[q] < 0) lb += D.freeCost[q];
        if (lb > bestLB) {
            bestLB = lb;
            best = lam;
            noImp = 0;
        } else if (++noImp > 25) {
            lambda *= 0.75;
            noImp = 0;
            if (lambda < 1e-5) break;
        }
        double gn = 0.0;
        for (int r = 0; r < R; ++r) {
            if (D.capClosed[r] > 1e299) sub[r] = 0.0;
            gn += sub[r] * sub[r];
        }
        if (gn < 1e-12) break;
        double step = lambda * (ub - lb) / gn;
        if (step <= 0) step = 1e-9;
        for (int r = 0; r < R; ++r) {
            lam[r] += step * sub[r];
            if (lam[r] < 0) lam[r] = 0.0;
        }
    }
    lam = best;
    double refined = asgRefineDuals(D, lam, deadline);
    return std::max(bestLB, refined);
}

inline bool tryAssign(const Instance& in, double deadline, Reporter& rep) {
    if (!in.family.empty() && in.family != "generalized-assignment" &&
        in.family != "capacitated-facility-location")
        return false;
    AsgData D;
    if (!extractAsg(in, D)) return false;
    int G = D.G, R = D.R;
    Rng rng(556677);

    std::vector<int> x(in.n, 0);
    for (size_t t = 0; t < D.freeVars.size(); ++t)
        if (D.freeCost[t] < 0) x[D.freeVars[t]] = 1;

    AsgSearch S;
    S.D = &D;
    S.a.assign(G, 0);
    // greedy initial: cheapest option per group, processed by regret
    {
        std::vector<int> ord(G);
        for (int g = 0; g < G; ++g) ord[g] = g;
        std::vector<double> regret(G);
        for (int g = 0; g < G; ++g) {
            double b1 = 1e300, b2 = 1e300;
            for (size_t o = 0; o < D.opt[g].size(); ++o) {
                double c = D.opt[g][o].cost;
                if (c < b1) { b2 = b1; b1 = c; }
                else if (c < b2) b2 = c;
            }
            regret[g] = (b2 < 1e299 ? b2 - b1 : 0.0);
        }
        std::sort(ord.begin(), ord.end(), [&](int p, int q) {
            if (regret[p] != regret[q]) return regret[p] > regret[q];
            return p < q;
        });
        S.load.assign(R, 0.0);
        S.assignCost = 0.0;
        std::vector<char> assigned(G, 0);
        S.P = 1.0;
        for (int t = 0; t < G; ++t) {
            int g = ord[t];
            int bo = 0;
            double bv = 1e300;
            for (size_t o = 0; o < D.opt[g].size(); ++o) {
                const AsgOpt& oo = D.opt[g][o];
                double v = oo.cost;
                double nl = S.load[oo.res] + oo.w;
                if (nl > D.capOpen[oo.res] + 1e-9) v += 1e6 * (nl - D.capOpen[oo.res]);
                if (nl > D.capClosed[oo.res] + 1e-9 && S.load[oo.res] <= D.capClosed[oo.res] + 1e-9)
                    v += D.fixedCost[oo.res];
                if (v < bv) { bv = v; bo = (int)o; }
            }
            S.a[g] = bo;
            S.load[D.opt[g][bo].res] += D.opt[g][bo].w;
            S.assignCost += D.opt[g][bo].cost;
        }
    }
    S.recompute();

    double avgCost = 0.0;
    int cntOpt = 0;
    for (int g = 0; g < G; ++g)
        for (size_t o = 0; o < D.opt[g].size(); ++o) { avgCost += D.opt[g][o].cost; ++cntOpt; }
    avgCost = cntOpt ? avgCost / cntOpt : 1.0;
    S.P = std::max(1.0, avgCost);

    std::vector<int> bestA;
    double bestVal = 1e300;
    auto emit = [&](const std::vector<int>& aa) {
        std::fill(x.begin(), x.end(), 0);
        for (size_t t = 0; t < D.freeVars.size(); ++t)
            if (D.freeCost[t] < 0) x[D.freeVars[t]] = 1;
        std::vector<double> ld(R, 0.0);
        for (int g = 0; g < G; ++g) {
            const AsgOpt& o = D.opt[g][aa[g]];
            x[o.var] = 1;
            ld[o.res] += o.w;
        }
        for (int r = 0; r < R; ++r) {
            if (D.yvar[r] < 0) continue;
            if (ld[r] > D.capClosed[r] + 1e-9 || D.fixedCost[r] < 0) x[D.yvar[r]] = 1;
        }
        if (!isFeasible(in, x)) return;
        rep.update(x, objValue(in, x));
    };

    std::vector<int> openable;
    for (int r = 0; r < R; ++r)
        if (D.fixedCost[r] > 0 && D.capClosed[r] < 1e299) openable.push_back(r);
    int nOpenable = (int)openable.size();

    // tabu search
    std::vector<std::vector<long long> > tabu(G);
    for (int g = 0; g < G; ++g) tabu[g].assign(D.opt[g].size(), -1);
    long long it = 0;
    int feasStreak = 0, infStreak = 0;
    while (now_s() < deadline) {
        ++it;
        double ov = S.overload();
        if (ov < 1e-9) {
            double tv = S.trueCost();
            if (tv < bestVal - 1e-9) {
                bestVal = tv;
                bestA = S.a;
                emit(bestA);
            }
            ++feasStreak;
            infStreak = 0;
        } else {
            ++infStreak;
            feasStreak = 0;
        }
        if (feasStreak > 15) { S.P = std::max(avgCost * 0.05, S.P * 0.8); feasStreak = 0; }
        if (infStreak > 15) { S.P = std::min(avgCost * 1e5, S.P * 1.4); infStreak = 0; }

        int bg = -1, bo = -1;
        double bd = 1e300;
        int ties = 0;
        double curTot = S.totalCost();
        for (int g = 0; g < G; ++g) {
            int cu = S.a[g];
            for (size_t o = 0; o < D.opt[g].size(); ++o) {
                if ((int)o == cu) continue;
                double d = S.delta(g, (int)o);
                bool isT = tabu[g][o] > it;
                if (isT) {
                    bool asp = (curTot + d < bestVal - 1e-9) && (S.overload() < 1e-9);
                    if (!asp) continue;
                }
                if (d < bd - 1e-12) { bd = d; bg = g; bo = (int)o; ties = 1; }
                else if (d < bd + 1e-12) {
                    ++ties;
                    if (rng.below(ties) == 0) { bg = g; bo = (int)o; }
                }
            }
        }
        if (bg < 0) {
            int g = rng.below(G);
            int o = rng.below((int)D.opt[g].size());
            S.apply(g, o);
            continue;
        }
        int old = S.a[bg];
        S.apply(bg, bo);
        tabu[bg][old] = it + 5 + rng.below(std::max(2, G / 4));

        if ((it % 4000) == 0 && !bestA.empty()) {
            S.a = bestA;
            S.recompute();
            // Facility-level kick: evacuating a whole resource is unreachable by
            // single-group moves once its fixed cost is sunk.
            if (nOpenable > 0 && rng.below(4) == 0) {
                int r = openable[rng.below(nOpenable)];
                for (int g = 0; g < G; ++g) {
                    if (D.opt[g][S.a[g]].res != r) continue;
                    int bo = -1;
                    double bv = 1e300;
                    for (size_t o = 0; o < D.opt[g].size(); ++o) {
                        if (D.opt[g][o].res == r) continue;
                        double v = D.opt[g][o].cost;
                        if (v < bv) { bv = v; bo = (int)o; }
                    }
                    if (bo >= 0) S.apply(g, bo);
                }
            } else {
                for (int t = 0; t < std::max(2, G / 10); ++t) {
                    int g = rng.below(G);
                    S.apply(g, rng.below((int)D.opt[g].size()));
                }
            }
        }
    }
    if (dbg() && bestVal < 1e299) {
        double lb = asgLowerBound(D, bestVal, now_s() + 4.0, 20000);
        fprintf(stderr, "# asg G=%d R=%d ub=%.2f lb=%.3f gap=%.4f%% iters=%lld\n", G, D.R, bestVal,
                lb, 100.0 * (bestVal - lb) / std::max(1.0, std::fabs(bestVal)), it);
    }
    if (bestVal < 1e299) return true;
    return false;
}
