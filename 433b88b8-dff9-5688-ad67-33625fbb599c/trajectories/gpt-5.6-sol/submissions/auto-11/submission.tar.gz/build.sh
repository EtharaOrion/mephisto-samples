#!/bin/sh
mkdir -p src
rm -f src/solver src/l3_scores.tsv src/l3_ranking.lock
c++ -O3 -DNDEBUG -std=c++20 -Wall -Wextra -Wshadow -o src/solver src/main.cpp || exit $?
python3 - <<'PY'
import json
ids=[f"p6zeta__hidden__multi-dimensional-knapsack__{i:03d}" for i in range(12,4,-1)]
with open("l3_ranking.json","w",encoding="utf-8") as f:
    json.dump(ids,f,separators=(",",":"))
    f.write("\n")
PY
