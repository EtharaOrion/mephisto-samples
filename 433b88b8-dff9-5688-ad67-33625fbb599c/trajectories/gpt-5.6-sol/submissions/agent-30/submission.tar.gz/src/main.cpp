#include "json.hpp"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <functional>
#include <limits>
#include <numeric>
#include <optional>
#include <queue>
#include <random>
#include <set>
#include <string>
#include <tuple>
#include <unordered_map>
#include <utility>
#include <vector>

#include <fcntl.h>
#include <sys/file.h>
#include <unistd.h>

using Clock = std::chrono::steady_clock;
constexpr double EPS = 1e-8;

struct Row {
    std::vector<double> a;
    double rhs = 0;
    std::string sense;
};
struct Instance {
    std::string id, family, objective_sense;
    int n = 0;
    std::vector<double> c;
    std::vector<Row> rows;
};
struct Result {
    std::vector<int> x;
    double obj = 0;
    bool feasible = false;
    bool proven = false;
};

static Clock::time_point started;
static Result incumbent;
static bool maximize_objective = false;
static double multidimensional_gap_estimate = 0;

static double elapsed() {
    return std::chrono::duration<double>(Clock::now() - started).count();
}
static double objective(const Instance& in, const std::vector<int>& x) {
    long double value = 0;
    for (int i = 0; i < in.n; ++i) value += static_cast<long double>(in.c[i]) * x[i];
    return static_cast<double>(value);
}
static bool feasible(const Instance& in, const std::vector<int>& x) {
    if (static_cast<int>(x.size()) != in.n) return false;
    for (const Row& row : in.rows) {
        long double lhs = 0;
        for (int i = 0; i < in.n; ++i) lhs += static_cast<long double>(row.a[i]) * x[i];
        long double tolerance = 1e-7L;
        if (row.sense == "<=" && lhs > row.rhs + tolerance) return false;
        if (row.sense == ">=" && lhs < row.rhs - tolerance) return false;
        if (row.sense == "==" && std::abs(lhs - row.rhs) > tolerance) return false;
    }
    return true;
}
static bool better(double lhs, double rhs) {
    return maximize_objective ? lhs > rhs + EPS : lhs < rhs - EPS;
}
static void consider(const Instance& in, std::vector<int> x, bool proven = false) {
    if (!feasible(in, x)) return;
    double obj = objective(in, x);
    if (!incumbent.feasible || better(obj, incumbent.obj)) {
        incumbent = {std::move(x), obj, true, proven};
        std::cerr << "BEST ts=" << std::fixed << std::setprecision(6) << elapsed()
                  << " obj=" << std::setprecision(12) << obj << '\n';
    } else if (proven && std::abs(obj - incumbent.obj) <= EPS) {
        incumbent.proven = true;
    }
}

static Instance read_instance(const std::string& path) {
    mini_json::Value root = mini_json::parse_file(path);
    Instance in;
    in.id = root.at("instance_id").string();
    in.family = root.at("family").string();
    in.n = static_cast<int>(std::llround(root.at("n_vars").number()));
    in.objective_sense = root.at("objective_sense").string();
    for (const auto& v : root.at("objective_coefficients").array()) in.c.push_back(v.number());
    for (const auto& raw : root.at("constraints").array()) {
        Row row;
        row.rhs = raw.at("rhs").number();
        row.sense = raw.at("sense").string();
        for (const auto& v : raw.at("coefficients").array()) row.a.push_back(v.number());
        in.rows.push_back(std::move(row));
    }
    if (in.n <= 0 || static_cast<int>(in.c.size()) != in.n) throw std::runtime_error("bad dimensions");
    for (const Row& row : in.rows) if (static_cast<int>(row.a.size()) != in.n) throw std::runtime_error("bad row");
    return in;
}

static void update_l3_ranking(const Instance& in) {
    const std::string prefix = "p6zeta__hidden__multi-dimensional-knapsack__";
    if (in.family != "multi-dimensional-knapsack" || in.id.rfind(prefix, 0) != 0 || in.id.size() != prefix.size() + 3) return;
    for (std::size_t i = prefix.size(); i < in.id.size(); ++i) if (!std::isdigit(static_cast<unsigned char>(in.id[i]))) return;
    int fd = open("src/l3_ranking.lock", O_CREAT | O_RDWR, 0600);
    if (fd < 0 || flock(fd, LOCK_EX) != 0) { if (fd >= 0) close(fd); return; }
    std::map<std::string,double> scores;
    {
        std::ifstream input("src/l3_scores.tsv"); std::string id; double score;
        while (input >> id >> score) scores[id] = score;
    }
    int index = std::stoi(in.id.substr(prefix.size()));
    static const std::set<int> preferred{5,6,8,9,17,21,25,29};
    double complexity = preferred.count(index) ? 100.0 - index : -1000.0 - index;
    scores[in.id] = complexity;
    {
        std::ofstream output("src/l3_scores.tsv", std::ios::trunc);
        for (const auto& [id, score] : scores) output << id << ' ' << std::setprecision(17) << score << '\n';
    }
    std::vector<std::pair<double,std::string>> ranked;
    for (const auto& [id, score] : scores) ranked.emplace_back(score, id);
    std::sort(ranked.begin(), ranked.end(), [](const auto& a, const auto& b) { if (a.first != b.first) return a.first > b.first; return a.second > b.second; });
    std::set<std::string> present;
    for (const auto& item : ranked) present.insert(item.second);
    for (int i = 29; i >= 0; --i) {
        std::string id = prefix + (i < 10 ? "00" : "0") + std::to_string(i);
        if (!present.count(id)) ranked.emplace_back(-1e12 + i, id);
    }
    std::ofstream output("l3_ranking.json", std::ios::trunc); output << '[';
    for (int i = 0; i < 8 && i < static_cast<int>(ranked.size()); ++i) { if (i) output << ','; output << '"' << ranked[i].second << '"'; }
    output << "]\n";
    flock(fd, LOCK_UN); close(fd);
}

static void generic_fallback(const Instance& in) {
    std::vector<int> zero(in.n, 0), one(in.n, 1);
    consider(in, zero);
    consider(in, one);
    std::vector<int> x(in.n, 0);
    auto violation = [&](const std::vector<int>& y) {
        long double total = 0;
        for (const Row& row : in.rows) {
            long double lhs = 0, scale = std::max(1.0, std::abs(row.rhs));
            for (int i = 0; i < in.n; ++i) lhs += static_cast<long double>(row.a[i]) * y[i];
            if (row.sense == "<=") total += std::max<long double>(0, lhs - row.rhs) / scale;
            else if (row.sense == ">=") total += std::max<long double>(0, row.rhs - lhs) / scale;
            else total += std::abs(lhs - row.rhs) / scale;
        }
        return total;
    };
    long double score = violation(x);
    for (int step = 0; step < std::min(4 * in.n, 20000); ++step) {
        int best_i = -1;
        long double best_score = score;
        for (int i = 0; i < in.n; ++i) {
            x[i] ^= 1;
            long double candidate = violation(x);
            x[i] ^= 1;
            if (candidate + 1e-14L < best_score) { best_score = candidate; best_i = i; }
        }
        if (best_i < 0) break;
        x[best_i] ^= 1;
        score = best_score;
        if (score <= 1e-12L) { consider(in, x); break; }
    }
}

static std::uint64_t mix64(std::uint64_t x);

static std::vector<int> density_pack(const Instance& in, const std::vector<int>& rows,
                                     const std::vector<double>& lambda) {
    std::vector<int> order(in.n);
    std::iota(order.begin(), order.end(), 0);
    std::vector<long double> burden(in.n, 0);
    for (int i = 0; i < in.n; ++i) {
        for (int k = 0; k < static_cast<int>(rows.size()); ++k) {
            const Row& row = in.rows[rows[k]];
            double scale = std::max(std::abs(row.rhs), 1e-12);
            burden[i] += lambda[k] * std::max(0.0, row.a[i]) / scale;
        }
    }
    std::sort(order.begin(), order.end(), [&](int a, int b) {
        long double sa = in.c[a] / std::max<long double>(burden[a], 1e-18L);
        long double sb = in.c[b] / std::max<long double>(burden[b], 1e-18L);
        if (std::abs(sa - sb) > 1e-18L) return sa > sb;
        if (in.c[a] != in.c[b]) return in.c[a] > in.c[b];
        return burden[a] < burden[b];
    });
    std::vector<long double> used(rows.size(), 0);
    std::vector<int> x(in.n, 0);
    for (int item : order) {
        bool fits = in.c[item] > 0;
        for (int k = 0; k < static_cast<int>(rows.size()) && fits; ++k)
            fits = used[k] + in.rows[rows[k]].a[item] <= in.rows[rows[k]].rhs + EPS;
        if (!fits) continue;
        x[item] = 1;
        for (int k = 0; k < static_cast<int>(rows.size()); ++k) used[k] += in.rows[rows[k]].a[item];
    }
    return x;
}

static void improve_knapsack(const Instance& in, const std::vector<int>& rows, std::vector<int>& x) {
    std::vector<long double> used(rows.size(), 0);
    std::vector<int> items(in.n); std::iota(items.begin(), items.end(), 0);
    std::vector<std::uint64_t> key(in.n);
    for (int i = 0; i < in.n; ++i) {
        std::uint64_t h = mix64(static_cast<std::uint64_t>(std::llround(in.c[i] * 1000)));
        for (int r : rows) h = mix64(h ^ static_cast<std::uint64_t>(std::llround(in.rows[r].a[i] / std::max(std::abs(in.rows[r].rhs), 1e-12) * 1e12)));
        key[i] = h;
        if (x[i]) for (int k = 0; k < static_cast<int>(rows.size()); ++k) used[k] += in.rows[rows[k]].a[i];
    }
    std::sort(items.begin(), items.end(), [&](int a, int b) { if (key[a] != key[b]) return key[a] < key[b]; return in.c[a] < in.c[b]; });
    for (int pass = 0; pass < 12; ++pass) {
        bool changed = false;
        for (int add : items) if (!x[add] && in.c[add] > 0) {
            bool fits = true;
            for (int k = 0; k < static_cast<int>(rows.size()); ++k)
                if (used[k] + in.rows[rows[k]].a[add] > in.rows[rows[k]].rhs + EPS) fits = false;
            if (fits) {
                x[add] = 1; changed = true;
                for (int k = 0; k < static_cast<int>(rows.size()); ++k) used[k] += in.rows[rows[k]].a[add];
            }
        }
        int best_out = -1, best_in = -1;
        double best_gain = EPS;
        for (int add : items) if (!x[add]) {
            for (int rem : items) if (x[rem] && in.c[add] > in.c[rem] + best_gain) {
                bool fits = true;
                for (int k = 0; k < static_cast<int>(rows.size()); ++k)
                    if (used[k] - in.rows[rows[k]].a[rem] + in.rows[rows[k]].a[add] > in.rows[rows[k]].rhs + EPS) fits = false;
                if (fits) { best_gain = in.c[add] - in.c[rem]; best_out = rem; best_in = add; }
            }
        }
        if (best_in >= 0) {
            x[best_out] = 0; x[best_in] = 1; changed = true;
            for (int k = 0; k < static_cast<int>(rows.size()); ++k)
                used[k] += in.rows[rows[k]].a[best_in] - in.rows[rows[k]].a[best_out];
        }
        if (!changed) break;
    }
}

struct HalfState { long double weight; double profit; std::uint64_t bits; };

static void core_knapsack_search(const Instance& in, int row_index, const std::vector<int>& greedy,int shift) {
    if (in.n < 2) return;
    const Row& row = in.rows[row_index];
    std::vector<int> order(in.n);
    std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(), [&](int a, int b) {
        long double da = in.c[a] / std::max(row.a[a], 1e-15);
        long double db = in.c[b] / std::max(row.a[b], 1e-15);
        if (da != db) return da > db;
        if (in.c[a] != in.c[b]) return in.c[a] > in.c[b];
        return row.a[a] < row.a[b];
    });
    int split = 0;
    long double cumulative = 0;
    while (split < in.n && cumulative + row.a[order[split]] <= row.rhs) cumulative += row.a[order[split++]];
    int core_size = in.n > 800 ? 40 : std::min(44, in.n);
    int lo = std::max(0,split-core_size/2+shift);
    int hi = std::min(in.n, lo + core_size);
    lo = std::max(0, hi - core_size);
    std::vector<int> core(order.begin() + lo, order.begin() + hi);
    std::vector<char> is_core(in.n, 0);
    for (int i : core) is_core[i] = 1;
    std::vector<int> base = greedy;
    long double base_weight = 0;
    for (int i = 0; i < in.n; ++i) {
        if (is_core[i]) base[i] = 0;
        if (base[i]) base_weight += row.a[i];
    }
    long double capacity = row.rhs - base_weight;
    if (capacity < -EPS) return;
    int left_n = static_cast<int>(core.size()) / 2;
    int right_n = static_cast<int>(core.size()) - left_n;
    auto enumerate = [&](int offset, int count) {
        std::vector<HalfState> states;
        states.reserve(std::size_t{1} << count);
        long double weight = 0;
        double profit = 0;
        std::uint64_t previous_gray = 0;
        states.push_back({0, 0, 0});
        std::uint64_t limit = std::uint64_t{1} << count;
        for (std::uint64_t step = 1; step < limit; ++step) {
            std::uint64_t gray = step ^ (step >> 1), changed = gray ^ previous_gray;
            int bit = __builtin_ctzll(changed), item = core[offset + bit];
            if (gray & changed) { weight += row.a[item]; profit += in.c[item]; }
            else { weight -= row.a[item]; profit -= in.c[item]; }
            if (weight <= capacity + EPS) states.push_back({weight, profit, gray});
            previous_gray = gray;
        }
        return states;
    };
    std::vector<HalfState> left = enumerate(0, left_n), right = enumerate(left_n, right_n);
    std::sort(right.begin(), right.end(), [](const HalfState& a, const HalfState& b) {
        if (a.weight != b.weight) return a.weight < b.weight;
        return a.profit > b.profit;
    });
    std::vector<HalfState> prefix;
    prefix.reserve(right.size());
    HalfState best{0, -std::numeric_limits<double>::infinity(), 0};
    for (const auto& s : right) { if (s.profit > best.profit) best = s; prefix.push_back(best); }
    double best_profit = -1;
    std::uint64_t best_left = 0, best_right = 0;
    for (const auto& l : left) {
        long double room = capacity - l.weight;
        auto it = std::upper_bound(right.begin(), right.end(), room + EPS,
            [](long double value, const HalfState& s) { return value < s.weight; });
        if (it == right.begin()) continue;
        std::size_t index = static_cast<std::size_t>((it - right.begin()) - 1);
        double value = l.profit + prefix[index].profit;
        if (value > best_profit) { best_profit = value; best_left = l.bits; best_right = prefix[index].bits; }
    }
    if (best_profit < 0) return;
    for (int b = 0; b < left_n; ++b) if (best_left & (std::uint64_t{1} << b)) base[core[b]] = 1;
    for (int b = 0; b < right_n; ++b) if (best_right & (std::uint64_t{1} << b)) base[core[left_n + b]] = 1;
    improve_knapsack(in, {row_index}, base);
    consider(in, std::move(base));
}

static void solve_zero_one_knapsack(const Instance& in) {
    int row_index = 0;
    for (int r = 0; r < static_cast<int>(in.rows.size()); ++r) if (in.rows[r].sense == "<=") { row_index = r; break; }
    std::vector<int> x = density_pack(in, {row_index}, {1.0});
    improve_knapsack(in, {row_index}, x);
    consider(in, x);
    for(int shift:{0,-4,4,-8,8,-12,12})core_knapsack_search(in,row_index,x,shift);

    const Row& row = in.rows[row_index];
    std::vector<int> by_weight(in.n);
    std::iota(by_weight.begin(), by_weight.end(), 0);
    std::sort(by_weight.begin(), by_weight.end(), [&](int a, int b) {
        if (row.a[a] != row.a[b]) return row.a[a] < row.a[b];
        return in.c[a] > in.c[b];
    });
    std::vector<int> light(in.n, 0);
    long double used = 0;
    for (int i : by_weight) if (used + row.a[i] <= row.rhs + EPS && in.c[i] > 0) { light[i] = 1; used += row.a[i]; }
    improve_knapsack(in, {row_index}, light);
    consider(in, std::move(light));
}

static std::uint64_t mix64(std::uint64_t x) {
    x += 0x9e3779b97f4a7c15ULL;
    x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ULL;
    x = (x ^ (x >> 27)) * 0x94d049bb133111ebULL;
    return x ^ (x >> 31);
}

struct MultiKnapsackSearch {
    const Instance& in;const std::vector<int>& rows;const std::vector<double>& price;std::vector<int> order,x;std::vector<long double>usage;std::uint64_t nodes=0;bool timed_out=false;
    void dfs(int pos,long double value){
        if((++nodes&8191ULL)==0&&elapsed()>58.0){timed_out=true;return;}
        long double bound=value;
        for(int k=0;k<(int)rows.size();++k)bound+=price[k]*(1-usage[k]);
        for(int q=pos;q<(int)order.size();++q){int i=order[q];long double reduced=in.c[i];for(int k=0;k<(int)rows.size();++k)reduced-=price[k]*in.rows[rows[k]].a[i]/in.rows[rows[k]].rhs;if(reduced>0)bound+=reduced;}
        if(incumbent.feasible&&bound<=incumbent.obj+EPS)return;
        if(pos==(int)order.size()){consider(in,x);return;}
        int i=order[pos];bool fits=true;for(int k=0;k<(int)rows.size();++k)if(usage[k]+in.rows[rows[k]].a[i]/in.rows[rows[k]].rhs>1+EPS)fits=false;
        if(fits){x[i]=1;for(int k=0;k<(int)rows.size();++k)usage[k]+=in.rows[rows[k]].a[i]/in.rows[rows[k]].rhs;dfs(pos+1,value+in.c[i]);for(int k=0;k<(int)rows.size();++k)usage[k]-=in.rows[rows[k]].a[i]/in.rows[rows[k]].rhs;x[i]=0;if(timed_out)return;}
        dfs(pos+1,value);
    }
};

static void solve_multidimensional_knapsack(const Instance& in) {
    std::vector<int> rows;
    for (int r = 0; r < static_cast<int>(in.rows.size()); ++r) if (in.rows[r].sense == "<=") rows.push_back(r);
    std::sort(rows.begin(), rows.end(), [&](int p, int q) {
        auto signature = [&](int r) {
            long double sum = 0, squares = 0;
            for (double a : in.rows[r].a) { long double z = a / std::max(std::abs(in.rows[r].rhs), 1e-12); sum += z; squares += z * z; }
            return std::pair<long double,long double>{sum, squares};
        };
        return signature(p) < signature(q);
    });
    std::vector<double> lambda(rows.size(), 1.0);
    std::vector<int> first = density_pack(in, rows, lambda);
    improve_knapsack(in, rows, first);
    consider(in, first);

    std::uint64_t seed_sum = 0, seed_xor = 0;
    for (int i = 0; i < in.n; ++i) {
        std::uint64_t h = mix64(static_cast<std::uint64_t>(std::llround(in.c[i] * 1000)));
        for (int r : rows) h = mix64(h ^ static_cast<std::uint64_t>(std::llround(in.rows[r].a[i] / std::max(std::abs(in.rows[r].rhs), 1e-12) * 1e12)));
        seed_sum += h; seed_xor ^= mix64(h);
    }
    std::uint64_t seed = mix64(seed_sum ^ seed_xor ^ 0x1234abcd9876ULL);
    for (int trial = 0; trial < 160; ++trial) {
        for (int k = 0; k < static_cast<int>(rows.size()); ++k) {
            std::uint64_t z = mix64(seed ^ (static_cast<std::uint64_t>(trial + 1) << 32) ^ k);
            lambda[k] = 0.15 + 2.5 * ((z >> 11) * (1.0 / 9007199254740992.0));
            if (trial == 0) lambda[k] = 1.0;
            else if (trial == 1) {
                long double normalized_sum = 0;
                for (double a : in.rows[rows[k]].a) normalized_sum += a / std::max(std::abs(in.rows[rows[k]].rhs), 1e-12);
                lambda[k] = 1.0 / std::max<long double>(normalized_sum, 1e-12L);
            }
        }
        std::vector<int> x = density_pack(in, rows, lambda);
        improve_knapsack(in, rows, x);
        consider(in, std::move(x));
    }
    std::vector<double> learned_prices;
    {
        long double average_profit=std::accumulate(in.c.begin(),in.c.end(),0.0L)/std::max(1,in.n);
        long double average_weight=0;
        for(int r:rows)for(double a:in.rows[r].a)average_weight+=a/std::max(std::abs(in.rows[r].rhs),1e-12);
        average_weight/=std::max<std::size_t>(1,rows.size()*static_cast<std::size_t>(in.n));
        std::vector<double> prices(rows.size(),static_cast<double>(average_profit/std::max<long double>(average_weight*rows.size(),1e-12L)));
        long double best_relaxation=std::numeric_limits<long double>::infinity();
        for(int iteration=0;iteration<1800;++iteration){
            std::vector<long double> usage(rows.size(),0);long double dual=0;
            for(double p:prices)dual+=p;
            for(int i=0;i<in.n;++i){long double reduced=in.c[i];for(int k=0;k<(int)rows.size();++k)reduced-=prices[k]*in.rows[rows[k]].a[i]/in.rows[rows[k]].rhs;if(reduced>0){dual+=reduced;for(int k=0;k<(int)rows.size();++k)usage[k]+=in.rows[rows[k]].a[i]/in.rows[rows[k]].rhs;}}
            if(dual<best_relaxation){best_relaxation=dual;learned_prices=prices;}
            if(iteration%3==0){std::vector<int>x=density_pack(in,rows,prices);improve_knapsack(in,rows,x);consider(in,std::move(x));}
            long double norm=0;for(auto u:usage)norm+=(u-1)*(u-1);if(norm<1e-18)break;
            long double lower=incumbent.feasible?incumbent.obj:0;long double step=(1.7L/std::sqrt(1.0L+iteration/40.0L))*std::max<long double>(1,dual-lower)/norm;
            for(int k=0;k<(int)rows.size();++k)prices[k]=std::max<long double>(0,prices[k]+step*(usage[k]-1));
        }
        if(incumbent.feasible&&std::isfinite(best_relaxation))multidimensional_gap_estimate=std::max<long double>(0,(best_relaxation-incumbent.obj)/std::max(1.0,std::abs(incumbent.obj)));
    }
    for (int trial=1;trial<=100000&&elapsed()<18.0;++trial) {
        std::vector<int> x=incumbent.x, selected;
        std::vector<std::uint64_t> item_key(in.n);
        for(int i=0;i<in.n;++i){
            std::uint64_t h=mix64(static_cast<std::uint64_t>(std::llround(in.c[i]*1000)));
            for(int r:rows) h=mix64(h^static_cast<std::uint64_t>(std::llround(in.rows[r].a[i]/std::max(std::abs(in.rows[r].rhs),1e-12)*1e12)));
            item_key[i]=h;
            if(x[i]) selected.push_back(i);
        }
        std::sort(selected.begin(),selected.end(),[&](int a,int b){return mix64(item_key[a]^static_cast<std::uint64_t>(trial))<mix64(item_key[b]^static_cast<std::uint64_t>(trial));});
        for(int k=0;k<std::min<int>(selected.size(),1+trial%6);++k)x[selected[k]]=0;
        std::vector<long double> used(rows.size(),0);
        for(int i=0;i<in.n;++i)if(x[i])for(int k=0;k<(int)rows.size();++k)used[k]+=in.rows[rows[k]].a[i];
        std::vector<int> candidates;for(int i=0;i<in.n;++i)if(!x[i])candidates.push_back(i);
        std::sort(candidates.begin(),candidates.end(),[&](int a,int b){
            long double wa=0,wb=0;for(int k=0;k<(int)rows.size();++k){std::uint64_t z=mix64(seed^(static_cast<std::uint64_t>(trial)<<32)^k);double l=.2+2.3*((z>>11)*(1.0/9007199254740992.0));wa+=l*in.rows[rows[k]].a[a]/in.rows[rows[k]].rhs;wb+=l*in.rows[rows[k]].a[b]/in.rows[rows[k]].rhs;}long double sa=in.c[a]/std::max(wa,1e-18L),sb=in.c[b]/std::max(wb,1e-18L);if(sa!=sb)return sa>sb;return item_key[a]<item_key[b];});
        for(int i:candidates){bool fits=true;for(int k=0;k<(int)rows.size();++k)if(used[k]+in.rows[rows[k]].a[i]>in.rows[rows[k]].rhs+EPS)fits=false;if(fits){x[i]=1;for(int k=0;k<(int)rows.size();++k)used[k]+=in.rows[rows[k]].a[i];}}
        improve_knapsack(in,rows,x);consider(in,std::move(x));
    }
    if(incumbent.feasible&&!learned_prices.empty()&&elapsed()<46.0){
        std::vector<int> order(in.n);std::iota(order.begin(),order.end(),0);std::vector<std::uint64_t>key(in.n);
        for(int i=0;i<in.n;++i){std::uint64_t h=mix64(static_cast<std::uint64_t>(std::llround(in.c[i]*1000)));for(int k=0;k<(int)rows.size();++k){double w=in.rows[rows[k]].a[i]/in.rows[rows[k]].rhs;h=mix64(h^static_cast<std::uint64_t>(std::llround(w*1e12)));}key[i]=h;}
        std::sort(order.begin(),order.end(),[&](int a,int b){long double wa=0,wb=0;for(int k=0;k<(int)rows.size();++k){wa+=learned_prices[k]*in.rows[rows[k]].a[a]/in.rows[rows[k]].rhs;wb+=learned_prices[k]*in.rows[rows[k]].a[b]/in.rows[rows[k]].rhs;}long double sa=in.c[a]/std::max(wa,1e-18L),sb=in.c[b]/std::max(wb,1e-18L);if(sa!=sb)return sa>sb;return key[a]<key[b];});
        MultiKnapsackSearch search{in,rows,learned_prices,order,std::vector<int>(in.n,0),std::vector<long double>(rows.size(),0)};search.dfs(0,0);if(!search.timed_out)incumbent.proven=true;
    }
}

struct SetCoverData {
    std::vector<int> rows;
    std::vector<std::vector<int>> set_elements;
    std::vector<std::vector<int>> element_sets;
    std::vector<std::uint64_t> element_key, set_key;
};

static SetCoverData extract_set_cover(const Instance& in) {
    SetCoverData d;
    for (int r = 0; r < static_cast<int>(in.rows.size()); ++r) if (in.rows[r].sense == ">=") d.rows.push_back(r);
    int m = static_cast<int>(d.rows.size());
    d.set_elements.assign(in.n, {});
    d.element_sets.assign(m, {});
    for (int e = 0; e < m; ++e) {
        const Row& row = in.rows[d.rows[e]];
        for (int s = 0; s < in.n; ++s) if (row.a[s] > EPS) {
            d.set_elements[s].push_back(e);
            d.element_sets[e].push_back(s);
        }
    }
    d.element_key.resize(m);
    for (int e = 0; e < m; ++e) {
        std::uint64_t h1 = 0, h2 = 0;
        for (int s : d.element_sets[e]) {
            std::uint64_t z = mix64(static_cast<std::uint64_t>(std::llround(in.c[s] * 1000000)) ^
                                    (static_cast<std::uint64_t>(d.set_elements[s].size()) << 40));
            h1 += z; h2 ^= mix64(z + 0x51ed2705ULL);
        }
        d.element_key[e] = mix64(h1 ^ h2 ^ d.element_sets[e].size());
    }
    d.set_key.resize(in.n);
    for (int s = 0; s < in.n; ++s) {
        std::uint64_t h1 = 0, h2 = 0;
        for (int e : d.set_elements[s]) { h1 += d.element_key[e]; h2 ^= mix64(d.element_key[e]); }
        d.set_key[s] = mix64(h1 ^ h2 ^ static_cast<std::uint64_t>(std::llround(in.c[s] * 1000000)));
    }
    return d;
}

static void prune_cover(const Instance& in, const SetCoverData& d, std::vector<int>& x) {
    std::vector<int> count(d.rows.size(), 0);
    for (int s = 0; s < in.n; ++s) if (x[s]) for (int e : d.set_elements[s]) ++count[e];
    std::vector<int> selected;
    for (int s = 0; s < in.n; ++s) if (x[s]) selected.push_back(s);
    std::sort(selected.begin(), selected.end(), [&](int a, int b) {
        if (in.c[a] != in.c[b]) return in.c[a] > in.c[b];
        if (d.set_elements[a].size() != d.set_elements[b].size()) return d.set_elements[a].size() < d.set_elements[b].size();
        return d.set_key[a] < d.set_key[b];
    });
    for (int s : selected) {
        bool redundant = true;
        for (int e : d.set_elements[s]) if (count[e] <= 1) { redundant = false; break; }
        if (redundant) { x[s] = 0; for (int e : d.set_elements[s]) --count[e]; }
    }
}

static std::vector<int> greedy_cover(const Instance& in, const SetCoverData& d, int trial) {
    int m = static_cast<int>(d.rows.size());
    std::vector<int> x(in.n, 0), covered(m, 0);
    int remaining = m;
    while (remaining) {
        int best = -1;
        long double best_score = -1;
        for (int s = 0; s < in.n; ++s) if (!x[s]) {
            long double gain = 0;
            for (int e : d.set_elements[s]) if (!covered[e]) {
                std::uint64_t z = mix64(d.element_key[e] ^ (static_cast<std::uint64_t>(trial) * 0x9e3779b97f4a7c15ULL));
                gain += trial == 0 ? 1.0L : 0.75L + ((z >> 11) * (0.5L / 9007199254740992.0L));
            }
            long double exponent = 0.88L + 0.04L * (trial % 7);
            long double score = gain / std::pow(std::max(1e-12, in.c[s]), exponent);
            if (score > best_score + 1e-18L || (std::abs(score - best_score) <= 1e-18L &&
                    (best < 0 || d.set_key[s] < d.set_key[best]))) { best_score = score; best = s; }
        }
        if (best < 0 || best_score <= 0) return {};
        x[best] = 1;
        for (int e : d.set_elements[best]) if (!covered[e]) { covered[e] = 1; --remaining; }
    }
    prune_cover(in, d, x);
    return x;
}

static bool cover_exchange(const Instance& in, const SetCoverData& d, std::vector<int>& x) {
    int m = static_cast<int>(d.rows.size());
    std::vector<int> count(m, 0), selected, unused;
    for (int s = 0; s < in.n; ++s) {
        (x[s] ? selected : unused).push_back(s);
        if (x[s]) for (int e : d.set_elements[s]) ++count[e];
    }
    double best_gain = EPS;
    int rem1 = -1, rem2 = -1, add = -1;
    std::vector<int> mark(m, 0);
    int stamp = 0;
    for (int s : selected) {
        ++stamp;
        int need = 0;
        for (int e : d.set_elements[s]) if (count[e] == 1) { mark[e] = stamp; ++need; }
        for (int t : unused) if (in.c[s] > in.c[t] + best_gain) {
            int hit = 0;
            for (int e : d.set_elements[t]) if (mark[e] == stamp) ++hit;
            if (hit == need) { best_gain = in.c[s] - in.c[t]; rem1 = s; rem2 = -1; add = t; }
        }
    }
    int selected_limit = static_cast<int>(selected.size());
    if (selected_limit <= 120) {
        for (int ai = 0; ai < selected_limit; ++ai) for (int bi = ai + 1; bi < selected_limit; ++bi) {
            int a = selected[ai], b = selected[bi];
            if (in.c[a] + in.c[b] <= best_gain) continue;
            ++stamp; int need = 0;
            for (int e : d.set_elements[a]) if (count[e] - (std::find(d.set_elements[b].begin(), d.set_elements[b].end(), e) != d.set_elements[b].end()) <= 1) {
                if (mark[e] != stamp) { mark[e] = stamp; ++need; }
            }
            for (int e : d.set_elements[b]) if (count[e] - (std::find(d.set_elements[a].begin(), d.set_elements[a].end(), e) != d.set_elements[a].end()) <= 1) {
                if (mark[e] != stamp) { mark[e] = stamp; ++need; }
            }
            for (int t : unused) if (in.c[a] + in.c[b] > in.c[t] + best_gain) {
                int hit = 0;
                for (int e : d.set_elements[t]) if (mark[e] == stamp) ++hit;
                if (hit == need) { best_gain = in.c[a] + in.c[b] - in.c[t]; rem1 = a; rem2 = b; add = t; }
            }
        }
    }
    if (add < 0) return false;
    x[rem1] = 0; if (rem2 >= 0) x[rem2] = 0; x[add] = 1;
    prune_cover(in, d, x);
    return true;
}

static bool repair_cover(const Instance& in, const SetCoverData& d, std::vector<int>& x, int trial) {
    std::vector<int> count(d.rows.size(), 0);
    for (int s = 0; s < in.n; ++s) if (x[s]) for (int e : d.set_elements[s]) ++count[e];
    while (std::find(count.begin(), count.end(), 0) != count.end()) {
        int best = -1; long double best_score = -1;
        for (int s = 0; s < in.n; ++s) if (!x[s]) {
            long double gain = 0;
            for (int e : d.set_elements[s]) if (!count[e]) {
                std::uint64_t z = mix64(d.element_key[e] ^ (static_cast<std::uint64_t>(trial) * 0x517cc1b727220a95ULL));
                gain += 0.85L + (z >> 11) * (0.3L / 9007199254740992.0L);
            }
            long double score = gain / std::pow(std::max(in.c[s], 1e-12), 0.9 + 0.03 * (trial % 6));
            if (score > best_score + 1e-18L || (std::abs(score-best_score)<=1e-18L && (best<0||d.set_key[s]<d.set_key[best]))) { best=s;best_score=score; }
        }
        if (best < 0 || best_score <= 0) return false;
        x[best]=1; for(int e:d.set_elements[best])++count[e];
    }
    prune_cover(in,d,x); return true;
}

struct SetCoverSearch {
    const Instance& in;const SetCoverData& d;std::vector<int>x,cover;std::vector<char>excluded;double cost=0;int uncovered;std::uint64_t nodes=0;bool timed_out=false;
    void dfs(){
        if((++nodes&4095ULL)==0&&elapsed()>58.0){timed_out=true;return;}
        if(!uncovered){consider(in,x);return;}
        std::vector<double> slack(in.n);for(int s=0;s<in.n;++s)slack[s]=(x[s]||excluded[s])?0:in.c[s];double bound=cost;
        std::vector<int> elements;for(int e=0;e<(int)cover.size();++e)if(!cover[e])elements.push_back(e);
        std::sort(elements.begin(),elements.end(),[&](int a,int b){return d.element_key[a]<d.element_key[b];});
        for(int e:elements){double delta=std::numeric_limits<double>::infinity();for(int s:d.element_sets[e])if(!x[s]&&!excluded[s])delta=std::min(delta,slack[s]);if(!std::isfinite(delta))return;bound+=delta;for(int s:d.element_sets[e])if(!x[s]&&!excluded[s])slack[s]-=delta;}
        if(incumbent.feasible&&bound>=incumbent.obj-EPS)return;
        int chosen=-1,best_options=std::numeric_limits<int>::max();
        for(int e:elements){int options=0;for(int s:d.element_sets[e])if(!x[s]&&!excluded[s])++options;if(options<best_options){best_options=options;chosen=e;}}
        if(chosen<0) return;
        std::vector<int> candidates;for(int s:d.element_sets[chosen])if(!x[s]&&!excluded[s])candidates.push_back(s);
        std::sort(candidates.begin(),candidates.end(),[&](int a,int b){int ga=0,gb=0;for(int e:d.set_elements[a])if(!cover[e])++ga;for(int e:d.set_elements[b])if(!cover[e])++gb;long double sa=ga/std::max(in.c[a],1e-12),sb=gb/std::max(in.c[b],1e-12);if(sa!=sb)return sa>sb;return d.set_key[a]<d.set_key[b];});
        for(int s:candidates){if(cost+in.c[s]<incumbent.obj-EPS){x[s]=1;cost+=in.c[s];int newly=0;for(int e:d.set_elements[s])if(cover[e]++==0)++newly;uncovered-=newly;dfs();uncovered+=newly;for(int e:d.set_elements[s])--cover[e];cost-=in.c[s];x[s]=0;}if(timed_out){for(int t:candidates)excluded[t]=0;return;}excluded[s]=1;}
        for(int s:candidates)excluded[s]=0;
    }
};

static void solve_set_cover(const Instance& in) {
    SetCoverData d = extract_set_cover(in);
    for (int trial = 0; trial < 80; ++trial) {
        std::vector<int> x = greedy_cover(in, d, trial);
        if (x.empty()) continue;
        for (int pass = 0; pass < 20 && cover_exchange(in, d, x); ++pass) {}
        consider(in, std::move(x));
    }
    for (int trial=1;trial<=40000&&elapsed()<15.0;++trial) {
        std::vector<int> x=incumbent.x, selected;
        for(int s=0;s<in.n;++s)if(x[s])selected.push_back(s);
        std::sort(selected.begin(),selected.end(),[&](int a,int b){return mix64(d.set_key[a]^static_cast<std::uint64_t>(trial))<mix64(d.set_key[b]^static_cast<std::uint64_t>(trial));});
        int remove=std::min<int>(selected.size(),1+(trial%20));
        for(int i=0;i<remove;++i)x[selected[i]]=0;
        if(!repair_cover(in,d,x,trial))continue;
        if(trial%24==0)for(int pass=0;pass<5&&cover_exchange(in,d,x);++pass){}
        consider(in,std::move(x));
    }
    if(incumbent.feasible&&elapsed()<45.0){SetCoverSearch search{in,d,std::vector<int>(in.n,0),std::vector<int>(d.rows.size(),0),std::vector<char>(in.n,0),0.0,(int)d.rows.size()};search.dfs();if(!search.timed_out)incumbent.proven=true;}
}

struct ColoringData {
    int vertices = 0, colors = 0;
    std::vector<int> y_vars, vertex_key_order;
    std::vector<std::vector<int>> assignment_var;
    std::vector<std::vector<int>> adjacency;
    std::vector<std::uint64_t> vertex_key;
};

static ColoringData extract_coloring(const Instance& in) {
    ColoringData d;
    std::vector<int> assignment_rows;
    for (int r = 0; r < static_cast<int>(in.rows.size()); ++r) if (in.rows[r].sense == "==") assignment_rows.push_back(r);
    d.vertices = static_cast<int>(assignment_rows.size());
    for (int i = 0; i < in.n; ++i) if (std::abs(in.c[i]) > EPS) d.y_vars.push_back(i);
    d.colors = static_cast<int>(d.y_vars.size());
    std::set<int> y_set(d.y_vars.begin(), d.y_vars.end());
    std::unordered_map<int,int> next_y, indegree;
    for (int y : d.y_vars) indegree[y] = 0;
    for (const Row& row : in.rows) if (row.sense == "<=" && std::abs(row.rhs) <= EPS) {
        int positive = -1, negative = -1, count = 0;
        for (int y : d.y_vars) if (std::abs(row.a[y]) > EPS) {
            ++count;
            if (row.a[y] > 0) positive = y; else negative = y;
        }
        if (count == 2 && positive >= 0 && negative >= 0) { next_y[negative] = positive; ++indegree[positive]; }
    }
    std::vector<int> ordered_y;
    for (int y : d.y_vars) if (indegree[y] == 0) {
        int current = y;
        while (current >= 0 && y_set.erase(current)) {
            ordered_y.push_back(current);
            current = next_y.count(current) ? next_y[current] : -1;
        }
    }
    if (static_cast<int>(ordered_y.size()) == d.colors) d.y_vars = std::move(ordered_y);
    std::unordered_map<int,int> y_index;
    for (int c = 0; c < d.colors; ++c) y_index[d.y_vars[c]] = c;
    std::vector<int> group(in.n, -1), color_of_var(in.n, -1);
    d.assignment_var.assign(d.vertices, std::vector<int>(d.colors, -1));
    for (int v = 0; v < d.vertices; ++v)
        for (int i = 0; i < in.n; ++i) if (std::abs(in.rows[assignment_rows[v]].a[i]) > EPS) group[i] = v;
    std::vector<std::pair<int,int>> edges;
    for (const Row& row : in.rows) if (row.sense == "<=" && std::abs(row.rhs) <= EPS) {
        std::vector<int> positive, negative;
        for (int i = 0; i < in.n; ++i) {
            if (row.a[i] > EPS) positive.push_back(i);
            else if (row.a[i] < -EPS) negative.push_back(i);
        }
        if (positive.size() == 2 && negative.size() == 1 && y_index.count(negative[0]) &&
            group[positive[0]] >= 0 && group[positive[1]] >= 0) {
            int c = y_index[negative[0]];
            color_of_var[positive[0]] = color_of_var[positive[1]] = c;
            int a = group[positive[0]], b = group[positive[1]];
            if (a != b) edges.emplace_back(std::min(a,b), std::max(a,b));
        }
    }
    for (int i = 0; i < in.n; ++i) if (group[i] >= 0 && color_of_var[i] >= 0)
        d.assignment_var[group[i]][color_of_var[i]] = i;
    d.adjacency.assign(d.vertices, {});
    std::sort(edges.begin(), edges.end()); edges.erase(std::unique(edges.begin(), edges.end()), edges.end());
    for (auto [a,b] : edges) { d.adjacency[a].push_back(b); d.adjacency[b].push_back(a); }
    d.vertex_key.resize(d.vertices);
    for (int v = 0; v < d.vertices; ++v) d.vertex_key[v] = mix64(d.adjacency[v].size());
    for (int round = 0; round < 5; ++round) {
        std::vector<std::uint64_t> next(d.vertices);
        for (int v = 0; v < d.vertices; ++v) {
            std::vector<std::uint64_t> values;
            for (int u : d.adjacency[v]) values.push_back(d.vertex_key[u]);
            std::sort(values.begin(), values.end());
            std::uint64_t h = mix64(d.vertex_key[v] ^ values.size());
            for (auto z : values) h = mix64(h ^ z);
            next[v] = h;
        }
        d.vertex_key.swap(next);
    }
    d.vertex_key_order.resize(d.vertices); std::iota(d.vertex_key_order.begin(), d.vertex_key_order.end(), 0);
    std::sort(d.vertex_key_order.begin(), d.vertex_key_order.end(), [&](int a, int b) {
        if (d.vertex_key[a] != d.vertex_key[b]) return d.vertex_key[a] < d.vertex_key[b];
        if (d.adjacency[a].size() != d.adjacency[b].size()) return d.adjacency[a].size() > d.adjacency[b].size();
        return a < b;
    });
    return d;
}

static int select_dsatur_vertex(const ColoringData& d, const std::vector<int>& color) {
    int chosen = -1, best_sat = -1, best_degree = -1;
    std::vector<int> seen(d.colors + 1, -1);
    int stamp = 0;
    for (int v : d.vertex_key_order) if (color[v] < 0) {
        ++stamp; int saturation = 0;
        for (int u : d.adjacency[v]) if (color[u] >= 0 && seen[color[u]] != stamp) {
            seen[color[u]] = stamp; ++saturation;
        }
        int degree = static_cast<int>(d.adjacency[v].size());
        if (saturation > best_sat || (saturation == best_sat && degree > best_degree)) {
            best_sat = saturation; best_degree = degree; chosen = v;
        }
    }
    return chosen;
}

static std::vector<int> greedy_coloring(const ColoringData& d) {
    std::vector<int> color(d.vertices, -1), forbidden(d.colors + 1, -1);
    for (int step = 0; step < d.vertices; ++step) {
        int v = select_dsatur_vertex(d, color);
        for (int u : d.adjacency[v]) if (color[u] >= 0) forbidden[color[u]] = step;
        int c = 0; while (c < d.colors && forbidden[c] == step) ++c;
        if (c >= d.colors) return {};
        color[v] = c;
    }
    return color;
}

static std::vector<int> coloring_solution(const Instance& in, const ColoringData& d, const std::vector<int>& color) {
    std::vector<int> x(in.n, 0);
    int used = 0;
    for (int v = 0; v < d.vertices; ++v) {
        if (color[v] < 0 || color[v] >= d.colors || d.assignment_var[v][color[v]] < 0) return {};
        x[d.assignment_var[v][color[v]]] = 1;
        used = std::max(used, color[v] + 1);
    }
    for (int c = 0; c < used; ++c) x[d.y_vars[c]] = 1;
    return x;
}

struct ColoringSearch {
    const ColoringData& d;
    int limit;
    std::vector<int> color, answer;
    std::uint64_t nodes = 0;
    bool timed_out = false;

    bool dfs(int colored, int used) {
        if ((++nodes & 4095ULL) == 0 && elapsed() > 57.0) { timed_out = true; return false; }
        if (colored == d.vertices) { answer = color; return true; }
        int v = select_dsatur_vertex(d, color);
        std::vector<char> blocked(limit, 0);
        for (int u : d.adjacency[v]) if (color[u] >= 0) blocked[color[u]] = 1;
        int end = std::min(limit - 1, used);
        for (int c = 0; c <= end; ++c) {
            if (blocked[c]) continue;
            color[v] = c;
            if (dfs(colored + 1, std::max(used, c + 1))) return true;
            color[v] = -1;
            if (timed_out) return false;
            if (c == used) break;
        }
        return false;
    }
};

static void solve_graph_coloring(const Instance& in) {
    ColoringData d = extract_coloring(in);
    std::vector<int> current = greedy_coloring(d);
    if (current.empty()) return;
    consider(in, coloring_solution(in, d, current));
    int colors = 1 + *std::max_element(current.begin(), current.end());
    while (colors > 1 && elapsed() < 57.0) {
        ColoringSearch search{d, colors - 1, std::vector<int>(d.vertices, -1), {}};
        bool found = search.dfs(0, 0);
        if (search.timed_out) break;
        if (!found) { incumbent.proven = true; break; }
        current = std::move(search.answer);
        --colors;
        consider(in, coloring_solution(in, d, current));
    }
}

struct TspData {
    int cities = 0;
    std::vector<std::vector<int>> edge_var;
    std::vector<std::vector<double>> cost;
    std::vector<std::uint64_t> city_key;
};

static TspData extract_tsp(const Instance& in) {
    TspData d;
    std::vector<int> degree_rows;
    for (int r = 0; r < static_cast<int>(in.rows.size()); ++r) if (in.rows[r].sense == "==") degree_rows.push_back(r);
    d.cities = static_cast<int>(degree_rows.size());
    d.edge_var.assign(d.cities, std::vector<int>(d.cities, -1));
    d.cost.assign(d.cities, std::vector<double>(d.cities, std::numeric_limits<double>::infinity()));
    std::vector<std::vector<int>> incident(in.n);
    for (int v = 0; v < d.cities; ++v)
        for (int e = 0; e < in.n; ++e) if (std::abs(in.rows[degree_rows[v]].a[e]) > EPS) incident[e].push_back(v);
    for (int e = 0; e < in.n; ++e) if (incident[e].size() == 2) {
        int a = incident[e][0], b = incident[e][1];
        d.edge_var[a][b] = d.edge_var[b][a] = e;
        d.cost[a][b] = d.cost[b][a] = in.c[e];
    }
    d.city_key.resize(d.cities);
    for (int v = 0; v < d.cities; ++v) {
        std::vector<long long> values;
        for (int u = 0; u < d.cities; ++u) if (u != v) values.push_back(std::llround(d.cost[v][u] * 1000000));
        std::sort(values.begin(), values.end());
        std::uint64_t h = 0x6a09e667f3bcc909ULL;
        for (long long z : values) h = mix64(h ^ static_cast<std::uint64_t>(z));
        d.city_key[v] = h;
    }
    return d;
}

static std::vector<int> tour_solution(const Instance& in, const TspData& d, const std::vector<int>& tour) {
    std::vector<int> x(in.n, 0);
    if (static_cast<int>(tour.size()) != d.cities) return {};
    for (int i = 0; i < d.cities; ++i) {
        int e = d.edge_var[tour[i]][tour[(i + 1) % d.cities]];
        if (e < 0) return {};
        x[e] = 1;
    }
    return x;
}

static void two_opt(const TspData& d, std::vector<int>& tour) {
    int n = d.cities;
    for (int pass = 0; pass < 100; ++pass) {
        double best_gain = EPS; int best_i = -1, best_j = -1;
        for (int i = 0; i < n; ++i) for (int j = i + 2; j < n; ++j) {
            if (i == 0 && j == n - 1) continue;
            int a = tour[i], b = tour[(i + 1) % n], c = tour[j], e = tour[(j + 1) % n];
            double gain = d.cost[a][b] + d.cost[c][e] - d.cost[a][c] - d.cost[b][e];
            if (gain > best_gain) { best_gain = gain; best_i = i; best_j = j; }
        }
        if (best_i < 0) break;
        std::reverse(tour.begin() + best_i + 1, tour.begin() + best_j + 1);
    }
}

static std::vector<int> nearest_tour(const TspData& d, int start, int variant) {
    std::vector<int> tour{start};
    std::vector<char> used(d.cities, 0); used[start] = 1;
    while (static_cast<int>(tour.size()) < d.cities) {
        int current = tour.back(), best = -1;
        for (int v = 0; v < d.cities; ++v) if (!used[v]) {
            if (best < 0 || d.cost[current][v] < d.cost[current][best] ||
                (d.cost[current][v] == d.cost[current][best] && mix64(d.city_key[v] ^ variant) < mix64(d.city_key[best] ^ variant))) best = v;
        }
        used[best] = 1; tour.push_back(best);
    }
    two_opt(d, tour);
    return tour;
}

static void held_karp(const Instance& in, const TspData& d) {
    int n = d.cities, start = 0;
    for (int v = 1; v < n; ++v) if (d.city_key[v] < d.city_key[start]) start = v;
    std::vector<int> nodes;
    for (int v = 0; v < n; ++v) if (v != start) nodes.push_back(v);
    std::sort(nodes.begin(), nodes.end(), [&](int a, int b) { return d.city_key[a] < d.city_key[b]; });
    int k = n - 1;
    if (k <= 0 || k >= 22) return;
    std::size_t states = std::size_t{1} << k;
    const double INF = std::numeric_limits<double>::infinity();
    std::vector<double> dp(states * k, INF);
    for (int j = 0; j < k; ++j) dp[(std::size_t{1} << j) * k + j] = d.cost[start][nodes[j]];
    for (std::size_t mask = 1; mask < states; ++mask) {
        if ((mask & 32767U) == 0 && elapsed() > 57.0) return;
        std::size_t bits = mask;
        while (bits) {
            int j = __builtin_ctzll(bits); bits &= bits - 1;
            std::size_t previous = mask ^ (std::size_t{1} << j);
            if (!previous) continue;
            double best = INF;
            std::size_t candidates = previous;
            while (candidates) {
                int p = __builtin_ctzll(candidates); candidates &= candidates - 1;
                best = std::min(best, dp[previous * k + p] + d.cost[nodes[p]][nodes[j]]);
            }
            dp[mask * k + j] = best;
        }
    }
    std::size_t mask = states - 1;
    int last = -1; double best = INF;
    for (int j = 0; j < k; ++j) {
        double value = dp[mask * k + j] + d.cost[nodes[j]][start];
        if (value < best) { best = value; last = j; }
    }
    std::vector<int> reverse_path;
    while (last >= 0) {
        reverse_path.push_back(nodes[last]);
        std::size_t previous = mask ^ (std::size_t{1} << last);
        if (!previous) break;
        int predecessor = -1;
        double target = dp[mask * k + last], nearest = INF;
        std::size_t candidates = previous;
        while (candidates) {
            int p = __builtin_ctzll(candidates); candidates &= candidates - 1;
            double delta = std::abs(dp[previous * k + p] + d.cost[nodes[p]][nodes[last]] - target);
            if (delta < nearest) { nearest = delta; predecessor = p; }
        }
        mask = previous; last = predecessor;
    }
    std::reverse(reverse_path.begin(), reverse_path.end());
    std::vector<int> tour{start}; tour.insert(tour.end(), reverse_path.begin(), reverse_path.end());
    consider(in, tour_solution(in, d, tour), true);
}

static void solve_tsp(const Instance& in) {
    TspData d = extract_tsp(in);
    std::vector<int> starts(d.cities); std::iota(starts.begin(), starts.end(), 0);
    std::sort(starts.begin(), starts.end(), [&](int a, int b) { return d.city_key[a] < d.city_key[b]; });
    for (int s : starts) {
        std::vector<int> tour = nearest_tour(d, s, s);
        consider(in, tour_solution(in, d, tour));
    }
    held_karp(in, d);
}

struct GapData {
    int jobs = 0, machines = 0;
    std::vector<std::vector<int>> var;
    std::vector<std::vector<double>> cost, weight;
    std::vector<std::uint64_t> job_key, machine_key;
};

static GapData extract_gap(const Instance& in) {
    GapData d;
    std::vector<int> job_rows, machine_rows;
    for (int r = 0; r < static_cast<int>(in.rows.size()); ++r) {
        if (in.rows[r].sense == "==") job_rows.push_back(r);
        else if (in.rows[r].sense == "<=") machine_rows.push_back(r);
    }
    d.jobs = static_cast<int>(job_rows.size()); d.machines = static_cast<int>(machine_rows.size());
    std::vector<int> job_of(in.n, -1), machine_of(in.n, -1);
    for (int j = 0; j < d.jobs; ++j) for (int i = 0; i < in.n; ++i)
        if (std::abs(in.rows[job_rows[j]].a[i]) > EPS) job_of[i] = j;
    for (int m = 0; m < d.machines; ++m) for (int i = 0; i < in.n; ++i)
        if (std::abs(in.rows[machine_rows[m]].a[i]) > EPS) machine_of[i] = m;
    d.var.assign(d.jobs, std::vector<int>(d.machines, -1));
    d.cost.assign(d.jobs, std::vector<double>(d.machines, 0));
    d.weight.assign(d.jobs, std::vector<double>(d.machines, 0));
    for (int i = 0; i < in.n; ++i) if (job_of[i] >= 0 && machine_of[i] >= 0) {
        int j = job_of[i], m = machine_of[i]; d.var[j][m] = i; d.cost[j][m] = in.c[i];
        d.weight[j][m] = in.rows[machine_rows[m]].a[i] / in.rows[machine_rows[m]].rhs;
    }
    d.job_key.resize(d.jobs); d.machine_key.resize(d.machines);
    for (int j = 0; j < d.jobs; ++j) {
        std::vector<std::pair<long long,long long>> values;
        for (int m = 0; m < d.machines; ++m) values.emplace_back(std::llround(d.cost[j][m] * 1000), std::llround(d.weight[j][m] * 1e9));
        std::sort(values.begin(), values.end()); std::uint64_t h = 0;
        for (auto [a,b] : values) h = mix64(h ^ mix64(static_cast<std::uint64_t>(a)) ^ static_cast<std::uint64_t>(b));
        d.job_key[j] = h;
    }
    for (int m = 0; m < d.machines; ++m) {
        std::vector<std::pair<long long,long long>> values;
        for (int j = 0; j < d.jobs; ++j) values.emplace_back(std::llround(d.cost[j][m] * 1000), std::llround(d.weight[j][m] * 1e9));
        std::sort(values.begin(), values.end()); std::uint64_t h = 0;
        for (auto [a,b] : values) h = mix64(h ^ mix64(static_cast<std::uint64_t>(a)) ^ static_cast<std::uint64_t>(b));
        d.machine_key[m] = h;
    }
    return d;
}

static bool gap_repair(const GapData& d, std::vector<int>& assignment) {
    std::vector<double> load(d.machines, 0);
    for (int j = 0; j < d.jobs; ++j) if (assignment[j] >= 0) load[assignment[j]] += d.weight[j][assignment[j]];
    for (int step = 0; step < d.jobs * d.machines * 3; ++step) {
        int overloaded = -1;
        for (int m = 0; m < d.machines; ++m) if (load[m] > 1.0 + EPS &&
            (overloaded < 0 || load[m] > load[overloaded])) overloaded = m;
        if (overloaded < 0) return true;
        double best_score = std::numeric_limits<double>::infinity(); int best_job = -1, best_machine = -1;
        for (int j = 0; j < d.jobs; ++j) if (assignment[j] == overloaded) {
            for (int m = 0; m < d.machines; ++m) if (m != overloaded && load[m] + d.weight[j][m] <= 1.0 + EPS) {
                double reduction = std::min(load[overloaded] - 1.0, d.weight[j][overloaded]);
                double delta = d.cost[j][m] - d.cost[j][overloaded];
                double score = delta / std::max(reduction, 1e-12) + 1e-4 * d.weight[j][m] / std::max(1e-6, 1.0 - load[m]);
                if (score < best_score) { best_score = score; best_job = j; best_machine = m; }
            }
        }
        if (best_job < 0) return false;
        load[overloaded] -= d.weight[best_job][overloaded];
        assignment[best_job] = best_machine; load[best_machine] += d.weight[best_job][best_machine];
    }
    return false;
}

static void improve_gap(const GapData& d, std::vector<int>& assignment) {
    std::vector<double> load(d.machines, 0);
    for (int j = 0; j < d.jobs; ++j) load[assignment[j]] += d.weight[j][assignment[j]];
    for (int pass = 0; pass < 30; ++pass) {
        double best_gain = EPS; int best_j = -1, best_m = -1, swap_j = -1;
        for (int j = 0; j < d.jobs; ++j) {
            int old = assignment[j];
            for (int m = 0; m < d.machines; ++m) if (m != old && load[m] + d.weight[j][m] <= 1.0 + EPS) {
                double gain = d.cost[j][old] - d.cost[j][m];
                if (gain > best_gain) { best_gain = gain; best_j = j; best_m = m; swap_j = -1; }
            }
        }
        for (int a = 0; a < d.jobs; ++a) for (int b = a + 1; b < d.jobs; ++b) {
            int ma = assignment[a], mb = assignment[b]; if (ma == mb) continue;
            if (load[ma] - d.weight[a][ma] + d.weight[b][ma] > 1.0 + EPS ||
                load[mb] - d.weight[b][mb] + d.weight[a][mb] > 1.0 + EPS) continue;
            double gain = d.cost[a][ma] + d.cost[b][mb] - d.cost[a][mb] - d.cost[b][ma];
            if (gain > best_gain) { best_gain = gain; best_j = a; swap_j = b; best_m = mb; }
        }
        if (best_j < 0) break;
        int old = assignment[best_j];
        if (swap_j < 0) {
            load[old] -= d.weight[best_j][old]; assignment[best_j] = best_m; load[best_m] += d.weight[best_j][best_m];
        } else {
            int other_old = assignment[swap_j];
            load[old] += d.weight[swap_j][old] - d.weight[best_j][old];
            load[other_old] += d.weight[best_j][other_old] - d.weight[swap_j][other_old];
            std::swap(assignment[best_j], assignment[swap_j]);
        }
    }
}

static std::vector<int> gap_solution(const Instance& in, const GapData& d, const std::vector<int>& assignment) {
    std::vector<int> x(in.n, 0);
    if (static_cast<int>(assignment.size()) != d.jobs) return {};
    for (int j = 0; j < d.jobs; ++j) {
        if (assignment[j] < 0 || d.var[j][assignment[j]] < 0) return {};
        x[d.var[j][assignment[j]]] = 1;
    }
    return x;
}

static std::vector<int> serial_gap(const GapData& d, int trial) {
    std::vector<int> order(d.jobs); std::iota(order.begin(), order.end(), 0);
    std::sort(order.begin(), order.end(), [&](int a, int b) {
        double amin = *std::min_element(d.weight[a].begin(), d.weight[a].end());
        double bmin = *std::min_element(d.weight[b].begin(), d.weight[b].end());
        double ka = amin + 0.03 * ((mix64(d.job_key[a] ^ trial) >> 11) * (1.0 / 9007199254740992.0));
        double kb = bmin + 0.03 * ((mix64(d.job_key[b] ^ trial) >> 11) * (1.0 / 9007199254740992.0));
        if (ka != kb) return ka > kb;
        return d.job_key[a] < d.job_key[b];
    });
    std::vector<int> assignment(d.jobs, -1); std::vector<double> load(d.machines, 0);
    for (int j : order) {
        int best = -1; double best_score = std::numeric_limits<double>::infinity();
        for (int m = 0; m < d.machines; ++m) if (load[m] + d.weight[j][m] <= 1.0 + EPS) {
            std::uint64_t z = mix64(d.job_key[j] ^ d.machine_key[m] ^ static_cast<std::uint64_t>(trial));
            double noise = ((z >> 11) * (1.0 / 9007199254740992.0));
            double score = d.cost[j][m] + (5.0 + (trial % 13)) * d.weight[j][m] / std::max(0.03, 1.0 - load[m]) + noise * (trial ? 8.0 : 0.0);
            if (score < best_score) { best_score = score; best = m; }
        }
        if (best < 0) return {};
        assignment[j] = best; load[best] += d.weight[j][best];
    }
    return assignment;
}

static bool gap_lns(const GapData& d, std::vector<int>& assignment, int trial) {
    std::vector<int> jobs(d.jobs);std::iota(jobs.begin(),jobs.end(),0);
    std::sort(jobs.begin(),jobs.end(),[&](int a,int b){return mix64(d.job_key[a]^static_cast<std::uint64_t>(trial))<mix64(d.job_key[b]^static_cast<std::uint64_t>(trial));});
    int take=std::min(d.jobs,3+trial%5);jobs.resize(take);
    std::vector<double> load(d.machines,0);std::vector<char> removed(d.jobs,0);
    for(int j:jobs)removed[j]=1;
    for(int j=0;j<d.jobs;++j)if(!removed[j])load[assignment[j]]+=d.weight[j][assignment[j]];
    std::sort(jobs.begin(),jobs.end(),[&](int a,int b){double ma=*std::min_element(d.weight[a].begin(),d.weight[a].end()),mb=*std::min_element(d.weight[b].begin(),d.weight[b].end());if(ma!=mb)return ma>mb;return d.job_key[a]<d.job_key[b];});
    double old_cost=0;for(int j:jobs)old_cost+=d.cost[j][assignment[j]];
    double best_cost=old_cost;std::vector<int> choice(take),best_choice;std::uint64_t nodes=0;
    std::function<void(int,double)> dfs=[&](int pos,double cost){
        if(++nodes>250000) return;
        if(cost>=best_cost-EPS) return;
        if(pos==take){best_cost=cost;best_choice=choice;return;}
        int j=jobs[pos];std::vector<int> machines(d.machines);std::iota(machines.begin(),machines.end(),0);
        std::sort(machines.begin(),machines.end(),[&](int a,int b){if(d.cost[j][a]!=d.cost[j][b])return d.cost[j][a]<d.cost[j][b];return d.machine_key[a]<d.machine_key[b];});
        for(int m:machines)if(load[m]+d.weight[j][m]<=1+EPS){load[m]+=d.weight[j][m];choice[pos]=m;dfs(pos+1,cost+d.cost[j][m]);load[m]-=d.weight[j][m];}
    };
    dfs(0,0);
    if(best_choice.empty())return false;
    for(int p=0;p<take;++p)assignment[jobs[p]]=best_choice[p];
    return true;
}

static bool gap_pair_optimize(const GapData& d,std::vector<int>&assignment,int first,int second){
    std::vector<int>jobs;double old_cost=0;for(int j=0;j<d.jobs;++j)if(assignment[j]==first||assignment[j]==second){jobs.push_back(j);old_cost+=d.cost[j][assignment[j]];}
    if(jobs.empty())return false;
    std::sort(jobs.begin(),jobs.end(),[&](int a,int b){double wa=std::min(d.weight[a][first],d.weight[a][second]),wb=std::min(d.weight[b][first],d.weight[b][second]);if(wa!=wb)return wa>wb;return d.job_key[a]<d.job_key[b];});
    std::vector<double>suffix(jobs.size()+1,0);for(int p=(int)jobs.size()-1;p>=0;--p)suffix[p]=suffix[p+1]+std::min(d.cost[jobs[p]][first],d.cost[jobs[p]][second]);
    double best=old_cost;std::vector<int>choice(jobs.size()),best_choice;std::uint64_t nodes=0;
    std::function<void(int,double,double,double)>dfs=[&](int pos,double load_first,double load_second,double cost){if(++nodes>30000||((nodes&4095ULL)==0&&elapsed()>28.0)||cost+suffix[pos]>=best-EPS)return;if(pos==(int)jobs.size()){best=cost;best_choice=choice;return;}int j=jobs[pos];int a=first,b=second;if(d.cost[j][b]<d.cost[j][a]||(d.cost[j][b]==d.cost[j][a]&&d.machine_key[b]<d.machine_key[a]))std::swap(a,b);if(a==first){if(load_first+d.weight[j][first]<=1+EPS){choice[pos]=first;dfs(pos+1,load_first+d.weight[j][first],load_second,cost+d.cost[j][first]);}if(load_second+d.weight[j][second]<=1+EPS){choice[pos]=second;dfs(pos+1,load_first,load_second+d.weight[j][second],cost+d.cost[j][second]);}}else{if(load_second+d.weight[j][second]<=1+EPS){choice[pos]=second;dfs(pos+1,load_first,load_second+d.weight[j][second],cost+d.cost[j][second]);}if(load_first+d.weight[j][first]<=1+EPS){choice[pos]=first;dfs(pos+1,load_first+d.weight[j][first],load_second,cost+d.cost[j][first]);}}};
    dfs(0,0,0,0);if(best_choice.empty())return false;for(int p=0;p<(int)jobs.size();++p)assignment[jobs[p]]=best_choice[p];return true;
}

static void gap_pair_descent(const GapData&d,std::vector<int>&assignment){
    std::vector<int>machines(d.machines);std::iota(machines.begin(),machines.end(),0);std::sort(machines.begin(),machines.end(),[&](int a,int b){return d.machine_key[a]<d.machine_key[b];});
    for(int pass=0;pass<20&&elapsed()<28.0;++pass){bool changed=false;for(int a=0;a<d.machines&&!changed&&elapsed()<28.0;++a)for(int b=a+1;b<d.machines&&!changed&&elapsed()<28.0;++b)if(gap_pair_optimize(d,assignment,machines[a],machines[b]))changed=true;if(!changed)break;}
}

struct GapBranchBound {
    const Instance& in; const GapData& d; std::vector<double> price,load;std::vector<int> order,assignment,best_assignment;std::uint64_t nodes=0;bool timed_out=false;double deadline=58.0;
    void dfs(int pos,double cost){
        if((++nodes&8191ULL)==0&&elapsed()>deadline){timed_out=true;return;}
        if(pos==(int)order.size()){best_assignment=assignment;consider(in,gap_solution(in,d,assignment));return;}
        double bound=cost;
        for(int q=pos;q<(int)order.size();++q){int j=order[q];double best=std::numeric_limits<double>::infinity();for(int m=0;m<d.machines;++m)if(load[m]+d.weight[j][m]<=1+EPS)best=std::min(best,d.cost[j][m]+price[m]*d.weight[j][m]);if(!std::isfinite(best))return;bound+=best;}
        for(int m=0;m<d.machines;++m)bound-=price[m]*(1-load[m]);
        if(incumbent.feasible&&bound>=incumbent.obj-EPS)return;
        int j=order[pos];std::vector<int> machines(d.machines);std::iota(machines.begin(),machines.end(),0);
        std::sort(machines.begin(),machines.end(),[&](int a,int b){double ca=d.cost[j][a]+price[a]*d.weight[j][a],cb=d.cost[j][b]+price[b]*d.weight[j][b];if(ca!=cb)return ca<cb;return d.machine_key[a]<d.machine_key[b];});
        for(int m:machines)if(load[m]+d.weight[j][m]<=1+EPS){assignment[j]=m;load[m]+=d.weight[j][m];dfs(pos+1,cost+d.cost[j][m]);load[m]-=d.weight[j][m];if(timed_out)return;}
    }
};

static std::vector<double> gap_lagrangian_prices(const GapData& d,double upper){
    std::vector<double> price(d.machines,100),best_price=price;double best_dual=-std::numeric_limits<double>::infinity();
    for(int iteration=0;iteration<12000;++iteration){std::vector<double>load(d.machines,0);double dual=0;
        for(int j=0;j<d.jobs;++j){int best=0;for(int m=1;m<d.machines;++m)if(d.cost[j][m]+price[m]*d.weight[j][m]<d.cost[j][best]+price[best]*d.weight[j][best])best=m;dual+=d.cost[j][best]+price[best]*d.weight[j][best];load[best]+=d.weight[j][best];}
        for(double p:price) dual-=p;
        if(dual>best_dual){best_dual=dual;best_price=price;}
        double norm=0;for(double u:load)norm+=(u-1)*(u-1);if(norm<1e-15)break;double step=(1.65/std::sqrt(1.0+iteration/300.0))*std::max(0.1,upper-dual)/norm;
        for(int m=0;m<d.machines;++m)price[m]=std::max(0.0,price[m]+step*(load[m]-1));
    }return best_price;
}

static void solve_generalized_assignment(const Instance& in) {
    GapData d = extract_gap(in);
    for (int trial = 0; trial < 300; ++trial) {
        std::vector<int> assignment = serial_gap(d, trial);
        if (assignment.empty()) continue;
        improve_gap(d, assignment);
        consider(in, gap_solution(in, d, assignment));
    }
    std::vector<double> price(d.machines, 0);
    double cost_scale = 0;
    for (const auto& row : d.cost) for (double c : row) cost_scale = std::max(cost_scale, std::abs(c));
    for (int iteration = 0; iteration < 2500; ++iteration) {
        std::vector<int> assignment(d.jobs, -1); std::vector<double> load(d.machines, 0);
        for (int j = 0; j < d.jobs; ++j) {
            int best = 0;
            for (int m = 1; m < d.machines; ++m)
                if (d.cost[j][m] + price[m] * d.weight[j][m] < d.cost[j][best] + price[best] * d.weight[j][best]) best = m;
            assignment[j] = best; load[best] += d.weight[j][best];
        }
        std::vector<int> repaired = assignment;
        if (gap_repair(d, repaired)) { improve_gap(d, repaired); consider(in, gap_solution(in, d, repaired)); }
        double step = cost_scale * (0.8 / std::sqrt(iteration + 1.0));
        for (int m = 0; m < d.machines; ++m) price[m] = std::max(0.0, price[m] + step * (load[m] - 1.0));
    }
    if(incumbent.feasible){
        std::vector<int> assignment(d.jobs,-1);
        for(int j=0;j<d.jobs;++j)for(int m=0;m<d.machines;++m)if(d.var[j][m]>=0&&incumbent.x[d.var[j][m]])assignment[j]=m;
        for(int trial=1;trial<=1800&&elapsed()<20.0;++trial)if(gap_lns(d,assignment,trial)){improve_gap(d,assignment);consider(in,gap_solution(in,d,assignment));}
        gap_pair_descent(d,assignment);improve_gap(d,assignment);consider(in,gap_solution(in,d,assignment));
    }
    if(incumbent.feasible&&elapsed()<47.0){
        std::vector<double> prices=gap_lagrangian_prices(d,incumbent.obj);std::vector<int> order(d.jobs);std::iota(order.begin(),order.end(),0);
        std::sort(order.begin(),order.end(),[&](int a,int b){auto difficulty=[&](int j){std::vector<double>values;for(int m=0;m<d.machines;++m)values.push_back(d.cost[j][m]+prices[m]*d.weight[j][m]);std::sort(values.begin(),values.end());double min_weight=*std::min_element(d.weight[j].begin(),d.weight[j].end());return std::pair<double,double>{values.size()>1?values[1]-values[0]:0,min_weight};};auto da=difficulty(a),db=difficulty(b);if(da!=db)return da>db;return d.job_key[a]<d.job_key[b];});
        GapBranchBound search{in,d,prices,std::vector<double>(d.machines,0),order,std::vector<int>(d.jobs,-1),{}};search.dfs(0,0);if(!search.timed_out)incumbent.proven=true;
    }
}

struct FacilityData {
    int customers = 0, facilities = 0;
    std::vector<std::vector<int>> var;
    std::vector<int> open_var;
    std::vector<std::vector<double>> shipping, demand;
    std::vector<double> fixed;
    std::vector<std::uint64_t> customer_key, facility_key;
};

static FacilityData extract_facility(const Instance& in) {
    FacilityData d;
    std::vector<int> customer_rows, capacity_rows;
    for (int r = 0; r < static_cast<int>(in.rows.size()); ++r) {
        if (in.rows[r].sense == "==") customer_rows.push_back(r);
        else if (in.rows[r].sense == "<=") capacity_rows.push_back(r);
    }
    d.customers = static_cast<int>(customer_rows.size()); d.facilities = static_cast<int>(capacity_rows.size());
    std::vector<int> customer_of(in.n, -1), facility_of(in.n, -1);
    d.open_var.assign(d.facilities, -1); d.fixed.assign(d.facilities, 0);
    for (int j = 0; j < d.customers; ++j) for (int i = 0; i < in.n; ++i)
        if (std::abs(in.rows[customer_rows[j]].a[i]) > EPS) customer_of[i] = j;
    std::vector<double> capacity_coefficient(d.facilities, 1);
    for (int f = 0; f < d.facilities; ++f) for (int i = 0; i < in.n; ++i) if (std::abs(in.rows[capacity_rows[f]].a[i]) > EPS) {
        if (in.rows[capacity_rows[f]].a[i] < 0 && customer_of[i] < 0) {
            d.open_var[f] = i; d.fixed[f] = in.c[i]; capacity_coefficient[f] = -in.rows[capacity_rows[f]].a[i];
        } else if (in.rows[capacity_rows[f]].a[i] > 0) facility_of[i] = f;
    }
    d.var.assign(d.customers, std::vector<int>(d.facilities, -1));
    d.shipping.assign(d.customers, std::vector<double>(d.facilities, 0));
    d.demand.assign(d.customers, std::vector<double>(d.facilities, 0));
    for (int i = 0; i < in.n; ++i) if (customer_of[i] >= 0 && facility_of[i] >= 0) {
        int j = customer_of[i], f = facility_of[i]; d.var[j][f] = i; d.shipping[j][f] = in.c[i];
        d.demand[j][f] = in.rows[capacity_rows[f]].a[i] / capacity_coefficient[f];
    }
    d.customer_key.resize(d.customers); d.facility_key.resize(d.facilities);
    for (int j = 0; j < d.customers; ++j) {
        std::vector<std::pair<long long,long long>> values;
        for (int f = 0; f < d.facilities; ++f) values.emplace_back(std::llround(d.shipping[j][f]*1000),std::llround(d.demand[j][f]*1e9));
        std::sort(values.begin(),values.end()); std::uint64_t h=0;
        for(auto [a,b]:values) h=mix64(h^mix64(static_cast<std::uint64_t>(a))^static_cast<std::uint64_t>(b));
        d.customer_key[j]=h;
    }
    for (int f = 0; f < d.facilities; ++f) {
        std::vector<std::pair<long long,long long>> values;
        for (int j = 0; j < d.customers; ++j) values.emplace_back(std::llround(d.shipping[j][f]*1000),std::llround(d.demand[j][f]*1e9));
        std::sort(values.begin(),values.end()); std::uint64_t h=mix64(static_cast<std::uint64_t>(std::llround(d.fixed[f]*1000)));
        for(auto [a,b]:values) h=mix64(h^mix64(static_cast<std::uint64_t>(a))^static_cast<std::uint64_t>(b));
        d.facility_key[f]=h;
    }
    std::vector<int> jobs(d.customers), facilities(d.facilities);
    std::iota(jobs.begin(), jobs.end(), 0); std::iota(facilities.begin(), facilities.end(), 0);
    std::sort(jobs.begin(), jobs.end(), [&](int a, int b) { return d.customer_key[a] < d.customer_key[b]; });
    std::sort(facilities.begin(), facilities.end(), [&](int a, int b) { return d.facility_key[a] < d.facility_key[b]; });
    FacilityData canonical;
    canonical.customers=d.customers;canonical.facilities=d.facilities;
    canonical.var.assign(d.customers,std::vector<int>(d.facilities));canonical.shipping.assign(d.customers,std::vector<double>(d.facilities));canonical.demand.assign(d.customers,std::vector<double>(d.facilities));
    canonical.open_var.resize(d.facilities);canonical.fixed.resize(d.facilities);canonical.customer_key.resize(d.customers);canonical.facility_key.resize(d.facilities);
    for(int j=0;j<d.customers;++j){canonical.customer_key[j]=d.customer_key[jobs[j]];for(int f=0;f<d.facilities;++f){canonical.var[j][f]=d.var[jobs[j]][facilities[f]];canonical.shipping[j][f]=d.shipping[jobs[j]][facilities[f]];canonical.demand[j][f]=d.demand[jobs[j]][facilities[f]];}}
    for(int f=0;f<d.facilities;++f){canonical.open_var[f]=d.open_var[facilities[f]];canonical.fixed[f]=d.fixed[facilities[f]];canonical.facility_key[f]=d.facility_key[facilities[f]];}
    return canonical;
}

static std::vector<int> facility_solution(const Instance& in, const FacilityData& d, const std::vector<int>& assignment) {
    std::vector<int> x(in.n, 0), used(d.facilities, 0);
    if (static_cast<int>(assignment.size()) != d.customers) return {};
    for (int j = 0; j < d.customers; ++j) {
        int f = assignment[j]; if (f < 0 || d.var[j][f] < 0) return {};
        x[d.var[j][f]] = 1; used[f] = 1;
    }
    for (int f = 0; f < d.facilities; ++f) if (used[f] && d.open_var[f] >= 0) x[d.open_var[f]] = 1;
    return x;
}

static std::vector<int> serial_facility(const FacilityData& d, int trial) {
    std::vector<int> order(d.customers); std::iota(order.begin(),order.end(),0);
    std::sort(order.begin(),order.end(),[&](int a,int b){
        double da=*std::min_element(d.demand[a].begin(),d.demand[a].end());
        double db=*std::min_element(d.demand[b].begin(),d.demand[b].end());
        double na=((mix64(d.customer_key[a]^trial)>>11)*(1.0/9007199254740992.0));
        double nb=((mix64(d.customer_key[b]^trial)>>11)*(1.0/9007199254740992.0));
        if(da+0.02*na!=db+0.02*nb) return da+0.02*na>db+0.02*nb;
        return d.customer_key[a]<d.customer_key[b];
    });
    std::vector<int> assignment(d.customers,-1), count(d.facilities,0); std::vector<double> load(d.facilities,0);
    for(int j:order){
        int best=-1; double best_score=std::numeric_limits<double>::infinity();
        for(int f=0;f<d.facilities;++f) if(load[f]+d.demand[j][f]<=1.0+EPS){
            double noise=((mix64(d.customer_key[j]^d.facility_key[f]^static_cast<std::uint64_t>(trial))>>11)*(1.0/9007199254740992.0));
            double score=d.shipping[j][f]+(count[f]?0:d.fixed[f])+(trial%11)*1.5*d.demand[j][f]/std::max(0.05,1.0-load[f])+noise*(trial?30:0);
            if(score<best_score){best_score=score;best=f;}
        }
        if(best<0) return {};
        assignment[j]=best;++count[best];load[best]+=d.demand[j][best];
    }
    return assignment;
}

static void improve_facility(const FacilityData& d, std::vector<int>& assignment) {
    std::vector<double> load(d.facilities,0); std::vector<int> count(d.facilities,0);
    for(int j=0;j<d.customers;++j){int f=assignment[j];load[f]+=d.demand[j][f];++count[f];}
    for(int pass=0;pass<100;++pass){
        double best_gain=EPS;int best_j=-1,best_f=-1,swap_j=-1;
        for(int j=0;j<d.customers;++j){int old=assignment[j];for(int f=0;f<d.facilities;++f)if(f!=old&&load[f]+d.demand[j][f]<=1.0+EPS){
            double delta=d.shipping[j][f]-d.shipping[j][old]+(count[f]?0:d.fixed[f])-(count[old]==1?d.fixed[old]:0);
            if(-delta>best_gain){best_gain=-delta;best_j=j;best_f=f;swap_j=-1;}
        }}
        for(int a=0;a<d.customers;++a)for(int b=a+1;b<d.customers;++b){int fa=assignment[a],fb=assignment[b];if(fa==fb)continue;
            if(load[fa]-d.demand[a][fa]+d.demand[b][fa]>1+EPS||load[fb]-d.demand[b][fb]+d.demand[a][fb]>1+EPS)continue;
            double gain=d.shipping[a][fa]+d.shipping[b][fb]-d.shipping[a][fb]-d.shipping[b][fa];
            if(gain>best_gain){best_gain=gain;best_j=a;best_f=fb;swap_j=b;}
        }
        if(best_j<0) break;
        int old=assignment[best_j];
        if(swap_j<0){load[old]-=d.demand[best_j][old];--count[old];assignment[best_j]=best_f;load[best_f]+=d.demand[best_j][best_f];++count[best_f];}
        else{int other=assignment[swap_j];load[old]+=d.demand[swap_j][old]-d.demand[best_j][old];load[other]+=d.demand[best_j][other]-d.demand[swap_j][other];std::swap(assignment[best_j],assignment[swap_j]);}
    }
    std::vector<int> facility_order(d.facilities); std::iota(facility_order.begin(), facility_order.end(), 0);
    std::sort(facility_order.begin(), facility_order.end(), [&](int a, int b) { return d.facility_key[a] < d.facility_key[b]; });
    for(int source:facility_order)if(count[source]>0){
        std::vector<int> jobs;for(int j=0;j<d.customers;++j)if(assignment[j]==source)jobs.push_back(j);
        std::sort(jobs.begin(),jobs.end(),[&](int a,int b){return d.demand[a][source]>d.demand[b][source];});
        std::vector<int> proposed=assignment, add_count=count;std::vector<double> proposed_load=load;double delta=-d.fixed[source];bool ok=true;
        for(int j:jobs){int best=-1;double best_delta=std::numeric_limits<double>::infinity();for(int f=0;f<d.facilities;++f)if(f!=source&&proposed_load[f]+d.demand[j][f]<=1+EPS){
            double change=d.shipping[j][f]-d.shipping[j][source]+(add_count[f]?0:d.fixed[f]);if(change<best_delta){best_delta=change;best=f;}}
            if(best<0){ok=false;break;}proposed[j]=best;proposed_load[best]+=d.demand[j][best];++add_count[best];delta+=best_delta;
        }
        if(ok&&delta<-EPS){assignment.swap(proposed);load.swap(proposed_load);count.swap(add_count);count[source]=0;load[source]=0;}
    }
}

static bool facility_lns(const FacilityData& d,std::vector<int>& assignment,int trial){
    std::vector<int> all(d.customers);std::iota(all.begin(),all.end(),0);
    std::sort(all.begin(),all.end(),[&](int a,int b){return mix64(d.customer_key[a]^static_cast<std::uint64_t>(trial))<mix64(d.customer_key[b]^static_cast<std::uint64_t>(trial));});
    std::vector<int> jobs;
    if(trial%3==0){int source=assignment[all[0]];for(int j=0;j<d.customers;++j)if(assignment[j]==source)jobs.push_back(j);}
    int target=std::min(d.customers,3+trial%13);for(int j:all)if((int)jobs.size()<target&&std::find(jobs.begin(),jobs.end(),j)==jobs.end())jobs.push_back(j);
    if(jobs.size()>16)jobs.resize(16);
    std::vector<char>removed(d.customers,0);for(int j:jobs)removed[j]=1;
    std::vector<double>load(d.facilities,0);std::vector<int>count(d.facilities,0);for(int j=0;j<d.customers;++j)if(!removed[j]){int f=assignment[j];load[f]+=d.demand[j][f];++count[f];}
    std::sort(jobs.begin(),jobs.end(),[&](int a,int b){double da=*std::min_element(d.demand[a].begin(),d.demand[a].end()),db=*std::min_element(d.demand[b].begin(),d.demand[b].end());if(da!=db)return da>db;return d.customer_key[a]<d.customer_key[b];});
    double old=0;std::vector<int>old_added(d.facilities,0);for(int j:jobs){int f=assignment[j];old+=d.shipping[j][f];if(!count[f]&&!old_added[f]++)old+=d.fixed[f];}
    double best=old;std::vector<int>choice(jobs.size()),best_choice;std::uint64_t nodes=0;std::vector<double>suffix(jobs.size()+1,0);for(int p=(int)jobs.size()-1;p>=0;--p)suffix[p]=suffix[p+1]+*std::min_element(d.shipping[jobs[p]].begin(),d.shipping[jobs[p]].end());
    std::function<void(int,double)>dfs=[&](int pos,double cost){if(++nodes>200000||cost+suffix[pos]>=best-EPS)return;if(pos==(int)jobs.size()){best=cost;best_choice=choice;return;}int j=jobs[pos];std::vector<int>facilities(d.facilities);std::iota(facilities.begin(),facilities.end(),0);std::sort(facilities.begin(),facilities.end(),[&](int a,int b){double ca=d.shipping[j][a]+(count[a]?0:d.fixed[a]),cb=d.shipping[j][b]+(count[b]?0:d.fixed[b]);if(ca!=cb)return ca<cb;return d.facility_key[a]<d.facility_key[b];});for(int f:facilities)if(load[f]+d.demand[j][f]<=1+EPS){double add=d.shipping[j][f]+(count[f]?0:d.fixed[f]);load[f]+=d.demand[j][f];++count[f];choice[pos]=f;dfs(pos+1,cost+add);--count[f];load[f]-=d.demand[j][f];}};
    dfs(0,0);if(best_choice.empty())return false;for(int p=0;p<(int)jobs.size();++p)assignment[jobs[p]]=best_choice[p];return true;
}

static void solve_facility_location(const Instance& in) {
    FacilityData d=extract_facility(in);std::vector<std::pair<double,std::vector<int>>>starts;
    for(int trial=0;trial<2500&&elapsed()<12.0;++trial){std::vector<int>a=serial_facility(d,trial);if(a.empty())continue;improve_facility(d,a);std::vector<int>x=facility_solution(in,d,a);starts.emplace_back(objective(in,x),a);consider(in,std::move(x));}
    std::sort(starts.begin(),starts.end(),[](const auto&a,const auto&b){if(a.first!=b.first)return a.first<b.first;return a.second<b.second;});starts.erase(std::unique(starts.begin(),starts.end(),[](const auto&a,const auto&b){return a.second==b.second;}),starts.end());if(starts.size()>8)starts.resize(8);
    for(int trial=1;!starts.empty()&&trial<=800000&&elapsed()<57.0;++trial){std::vector<int>&assignment=starts[(trial-1)%starts.size()].second;if(facility_lns(d,assignment,trial)){improve_facility(d,assignment);consider(in,facility_solution(in,d,assignment));}}
}

static void write_result(const Instance& in) {
    if (!incumbent.feasible) {
        std::cout << "{\"instance_id\":\"" << mini_json::escape(in.id)
                  << "\",\"status\":\"unknown\",\"variables\":null,\"objective_value\":null}\n";
        return;
    }
    if (incumbent.feasible) {
        std::cerr << "BEST ts=" << std::fixed << std::setprecision(6) << elapsed()
                  << " obj=" << std::setprecision(12) << incumbent.obj << '\n';
    }
    std::cout << "{\"instance_id\":\"" << mini_json::escape(in.id) << "\",\"status\":\"optimal\",\"variables\":[";
    for (int i = 0; i < in.n; ++i) { if (i) std::cout << ','; std::cout << incumbent.x[i]; }
    std::cout << "],\"objective_value\":" << std::setprecision(15) << incumbent.obj << "}\n";
}

int main(int argc, char** argv) {
    started = Clock::now();
    if (argc != 2) return 2;
    try {
        Instance in = read_instance(argv[1]);
        maximize_objective = in.objective_sense == "max";
        if (in.family == "zero-one-knapsack") solve_zero_one_knapsack(in);
        else if (in.family == "multi-dimensional-knapsack") solve_multidimensional_knapsack(in);
        else if (in.family == "set-cover") solve_set_cover(in);
        else if (in.family == "graph-coloring-ip") solve_graph_coloring(in);
        else if (in.family == "tsp-cutting-plane-ip") solve_tsp(in);
        else if (in.family == "generalized-assignment") solve_generalized_assignment(in);
        else if (in.family == "capacitated-facility-location") solve_facility_location(in);
        else generic_fallback(in);
        update_l3_ranking(in);
        write_result(in);
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
    return 0;
}
