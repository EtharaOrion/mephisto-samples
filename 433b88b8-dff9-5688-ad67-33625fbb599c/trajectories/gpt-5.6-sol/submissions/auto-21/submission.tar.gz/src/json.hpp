#pragma once

#include <cctype>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <map>
#include <stdexcept>
#include <string>
#include <variant>
#include <vector>

namespace mini_json {

struct Value {
    using Array = std::vector<Value>;
    using Object = std::map<std::string, Value>;
    std::variant<std::nullptr_t, bool, double, std::string, Array, Object> data;

    bool is_null() const { return std::holds_alternative<std::nullptr_t>(data); }
    double number() const { return std::get<double>(data); }
    const std::string& string() const { return std::get<std::string>(data); }
    const Array& array() const { return std::get<Array>(data); }
    const Object& object() const { return std::get<Object>(data); }
    const Value& at(const std::string& key) const { return object().at(key); }
};

class Parser {
    const std::string& text_;
    std::size_t pos_ = 0;

    [[noreturn]] void fail(const std::string& message) const {
        throw std::runtime_error("JSON error at byte " + std::to_string(pos_) + ": " + message);
    }
    void whitespace() {
        while (pos_ < text_.size() && std::isspace(static_cast<unsigned char>(text_[pos_]))) ++pos_;
    }
    bool consume(char c) {
        whitespace();
        if (pos_ < text_.size() && text_[pos_] == c) { ++pos_; return true; }
        return false;
    }
    void expect(const char* word) {
        while (*word) {
            if (pos_ >= text_.size() || text_[pos_++] != *word++) fail("unexpected token");
        }
    }
    static void append_utf8(std::string& out, std::uint32_t cp) {
        if (cp <= 0x7f) out.push_back(static_cast<char>(cp));
        else if (cp <= 0x7ff) {
            out.push_back(static_cast<char>(0xc0 | (cp >> 6)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3f)));
        } else if (cp <= 0xffff) {
            out.push_back(static_cast<char>(0xe0 | (cp >> 12)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3f)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3f)));
        } else {
            out.push_back(static_cast<char>(0xf0 | (cp >> 18)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 12) & 0x3f)));
            out.push_back(static_cast<char>(0x80 | ((cp >> 6) & 0x3f)));
            out.push_back(static_cast<char>(0x80 | (cp & 0x3f)));
        }
    }
    std::string parse_string() {
        if (!consume('"')) fail("expected string");
        std::string out;
        while (pos_ < text_.size()) {
            char c = text_[pos_++];
            if (c == '"') return out;
            if (c != '\\') { out.push_back(c); continue; }
            if (pos_ >= text_.size()) fail("unfinished escape");
            char e = text_[pos_++];
            switch (e) {
                case '"': out.push_back('"'); break;
                case '\\': out.push_back('\\'); break;
                case '/': out.push_back('/'); break;
                case 'b': out.push_back('\b'); break;
                case 'f': out.push_back('\f'); break;
                case 'n': out.push_back('\n'); break;
                case 'r': out.push_back('\r'); break;
                case 't': out.push_back('\t'); break;
                case 'u': {
                    std::uint32_t cp = 0;
                    for (int i = 0; i < 4; ++i) {
                        if (pos_ >= text_.size()) fail("unfinished unicode escape");
                        char h = text_[pos_++];
                        cp <<= 4;
                        if (h >= '0' && h <= '9') cp += h - '0';
                        else if (h >= 'a' && h <= 'f') cp += h - 'a' + 10;
                        else if (h >= 'A' && h <= 'F') cp += h - 'A' + 10;
                        else fail("invalid unicode escape");
                    }
                    append_utf8(out, cp);
                    break;
                }
                default: fail("invalid escape");
            }
        }
        fail("unterminated string");
    }
    double parse_number() {
        whitespace();
        std::size_t start = pos_;
        if (pos_ < text_.size() && text_[pos_] == '-') ++pos_;
        if (pos_ < text_.size() && text_[pos_] == '0') ++pos_;
        else while (pos_ < text_.size() && std::isdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
        if (pos_ < text_.size() && text_[pos_] == '.') {
            ++pos_;
            while (pos_ < text_.size() && std::isdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
        }
        if (pos_ < text_.size() && (text_[pos_] == 'e' || text_[pos_] == 'E')) {
            ++pos_;
            if (pos_ < text_.size() && (text_[pos_] == '+' || text_[pos_] == '-')) ++pos_;
            while (pos_ < text_.size() && std::isdigit(static_cast<unsigned char>(text_[pos_]))) ++pos_;
        }
        try { return std::stod(text_.substr(start, pos_ - start)); }
        catch (...) { fail("invalid number"); }
    }
    Value parse_array() {
        consume('[');
        Value::Array out;
        if (consume(']')) return Value{std::move(out)};
        do { out.push_back(parse_value()); } while (consume(','));
        if (!consume(']')) fail("expected ]");
        return Value{std::move(out)};
    }
    Value parse_object() {
        consume('{');
        Value::Object out;
        if (consume('}')) return Value{std::move(out)};
        do {
            whitespace();
            std::string key = parse_string();
            if (!consume(':')) fail("expected colon");
            out.emplace(std::move(key), parse_value());
        } while (consume(','));
        if (!consume('}')) fail("expected }");
        return Value{std::move(out)};
    }
public:
    explicit Parser(const std::string& text) : text_(text) {}
    Value parse_value() {
        whitespace();
        if (pos_ >= text_.size()) fail("unexpected end");
        char c = text_[pos_];
        if (c == '{') return parse_object();
        if (c == '[') return parse_array();
        if (c == '"') return Value{parse_string()};
        if (c == 't') { expect("true"); return Value{true}; }
        if (c == 'f') { expect("false"); return Value{false}; }
        if (c == 'n') { expect("null"); return Value{nullptr}; }
        return Value{parse_number()};
    }
    Value parse() {
        Value value = parse_value();
        whitespace();
        if (pos_ != text_.size()) fail("trailing data");
        return value;
    }
};

inline Value parse_file(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("cannot open input");
    std::string text((std::istreambuf_iterator<char>(in)), std::istreambuf_iterator<char>());
    return Parser(text).parse();
}

inline std::string escape(const std::string& s) {
    std::string out;
    for (unsigned char c : s) {
        switch (c) {
            case '"': out += "\\\""; break;
            case '\\': out += "\\\\"; break;
            case '\b': out += "\\b"; break;
            case '\f': out += "\\f"; break;
            case '\n': out += "\\n"; break;
            case '\r': out += "\\r"; break;
            case '\t': out += "\\t"; break;
            default:
                if (c < 0x20) {
                    const char* hex = "0123456789abcdef";
                    out += "\\u00";
                    out.push_back(hex[c >> 4]); out.push_back(hex[c & 15]);
                } else out.push_back(static_cast<char>(c));
        }
    }
    return out;
}

}  // namespace mini_json
