/* lag.c - Lagrangian dual via the volume algorithm.
 *
 * Relaxing every row of a pure 0-1 program leaves a separable box subproblem,
 * so the Lagrangian dual value equals the LP relaxation bound.  The volume
 * algorithm additionally produces a primal estimate xbar in [0,1]^n that plays
 * the role of an LP solution for guiding rounding / diving heuristics.
 */
#include "ip.h"

static void clip_lambda(const Model *M, double *lam) {
    for (int r = 0; r < M->m; r++) {
        char s = M->sense[r];
        if (s == SENSE_LE) { if (lam[r] < 0.0) lam[r] = 0.0; }
        else if (s == SENSE_GE) { if (lam[r] > 0.0) lam[r] = 0.0; }
    }
}

/* subproblem: returns L(lam), fills rc and x */
static double subproblem(const Model *M, const double *lam, double *rc, signed char *x) {
    int n = M->n, m = M->m;
    for (int j = 0; j < n; j++) rc[j] = M->c[j];
    for (int r = 0; r < m; r++) {
        double lr = lam[r];
        if (lr == 0.0) continue;
        int e = M->rs[r + 1];
        for (int k = M->rs[r]; k < e; k++) rc[M->ri[k]] += lr * M->rv[k];
    }
    double val = 0.0;
    for (int r = 0; r < m; r++) val -= lam[r] * M->rhs[r];
    for (int j = 0; j < n; j++) {
        if (rc[j] < 0.0) { x[j] = 1; val += rc[j]; }
        else x[j] = 0;
    }
    return val;
}

void lagrangian_run(Ctx *C, LagInfo *L, double budget) {
    Model *M = C->M;
    int n = M->n, m = M->m;
    double tstart = now_sec();

    L->lam = (double *)xcalloc((size_t)(m > 0 ? m : 1), sizeof(double));
    L->xbar = (double *)xcalloc((size_t)(n > 0 ? n : 1), sizeof(double));
    L->rc = (double *)xcalloc((size_t)(n > 0 ? n : 1), sizeof(double));
    L->lb = -INFINITY;
    L->valid = 0;
    if (n == 0 || m == 0) { L->valid = 1; L->lb = 0.0; return; }

    double *lam = L->lam;
    double *lamt = (double *)xcalloc((size_t)m, sizeof(double));
    double *bestlam = (double *)xcalloc((size_t)m, sizeof(double));
    double *rc = (double *)xcalloc((size_t)n, sizeof(double));
    double *gbar = (double *)xcalloc((size_t)m, sizeof(double));
    double *xbar = L->xbar;
    signed char *xs = (signed char *)xcalloc((size_t)n, 1);

    /* warm start: for >= rows use a small positive multiplier magnitude */
    for (int r = 0; r < m; r++) lam[r] = 0.0;

    double z = subproblem(M, lam, rc, xs);
    double bestz = z;
    memcpy(bestlam, lam, (size_t)m * sizeof(double));
    for (int j = 0; j < n; j++) xbar[j] = xs[j];
    for (int r = 0; r < m; r++) {
        double act = 0.0;
        int e = M->rs[r + 1];
        for (int k = M->rs[r]; k < e; k++) act += M->rv[k] * xbar[M->ri[k]];
        gbar[r] = act - M->rhs[r];
    }

    /* upper bound estimate for the step rule */
    double ub;
    if (C->have) ub = C->bestint;
    else ub = bestz + fabs(bestz) * 0.2 + 1.0;

    double theta = 2.0;
    double alpha = 0.15;
    int noimp = 0;
    int iter = 0;
    int maxiter = 100000;
    /* keep the pass cost bounded */
    double work_per_iter = (double)(M->nnz + n + m);
    int itcap = (int)(4.0e8 / (work_per_iter + 1.0));
    if (itcap < 200) itcap = 200;
    if (itcap > 20000) itcap = 20000;
    if (maxiter > itcap) maxiter = itcap;

    for (iter = 0; iter < maxiter; iter++) {
        if ((iter & 15) == 0) {
            if (now_sec() - tstart > budget) break;
        }
        /* step direction: gbar (volume) */
        double gn = 0.0;
        for (int r = 0; r < m; r++) {
            double g = gbar[r];
            char sn = M->sense[r];
            /* complementary slackness: for inactive multipliers, only positive
               violation pushes */
            if (sn == SENSE_LE && lam[r] <= 0.0 && g < 0.0) g = 0.0;
            if (sn == SENSE_GE && lam[r] >= 0.0 && g > 0.0) g = 0.0;
            gn += g * g;
        }
        if (gn < 1e-14) break;
        double target = ub;
        if (C->have && C->bestint < target) target = C->bestint;
        double gapv = target - bestz;
        if (gapv < 1e-9 * (fabs(target) + 1.0)) gapv = 0.05 * (fabs(bestz) + 1.0);
        double step = theta * gapv / gn;

        for (int r = 0; r < m; r++) {
            double g = gbar[r];
            char sn = M->sense[r];
            if (sn == SENSE_LE && lam[r] <= 0.0 && g < 0.0) g = 0.0;
            if (sn == SENSE_GE && lam[r] >= 0.0 && g > 0.0) g = 0.0;
            lamt[r] = lam[r] + step * g;
        }
        clip_lambda(M, lamt);

        double zt = subproblem(M, lamt, rc, xs);

        /* volume update of the primal estimate */
        double a = alpha;
        for (int j = 0; j < n; j++) xbar[j] = a * (double)xs[j] + (1.0 - a) * xbar[j];
        for (int r = 0; r < m; r++) {
            double act = 0.0;
            int e = M->rs[r + 1];
            for (int k = M->rs[r]; k < e; k++) act += M->rv[k] * xbar[M->ri[k]];
            gbar[r] = act - M->rhs[r];
        }

        if (zt > bestz + 1e-12 * (fabs(bestz) + 1.0)) {
            bestz = zt;
            memcpy(bestlam, lamt, (size_t)m * sizeof(double));
            memcpy(lam, lamt, (size_t)m * sizeof(double));
            noimp = 0;
        } else {
            noimp++;
            /* green/yellow: still move partially towards lamt occasionally */
            if (zt > bestz - 0.02 * (fabs(bestz) + 1.0)) {
                memcpy(lam, lamt, (size_t)m * sizeof(double));
            }
            if (noimp >= 20) {
                theta *= 0.67;
                noimp = 0;
                if (alpha > 0.02) alpha *= 0.85;
                memcpy(lam, bestlam, (size_t)m * sizeof(double));
                if (theta < 5e-4) break;
            }
        }
        if (C->have && C->bestint < ub) ub = C->bestint;
    }

    memcpy(lam, bestlam, (size_t)m * sizeof(double));
    subproblem(M, lam, L->rc, xs);
    L->lb = bestz;
    L->valid = 1;

    for (int j = 0; j < n; j++) {
        if (xbar[j] < 0.0) xbar[j] = 0.0;
        if (xbar[j] > 1.0) xbar[j] = 1.0;
    }

    free(lamt); free(bestlam); free(rc); free(gbar); free(xs);
}

void lag_free(LagInfo *L) {
    free(L->lam); free(L->xbar); free(L->rc);
    L->lam = L->xbar = L->rc = NULL;
}
