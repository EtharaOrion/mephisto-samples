/* special.c - structure-specific exact routines.
 *
 * Every candidate produced here is handed to ctx_offer, which re-verifies it
 * against the *original* constraint set before accepting, so a mis-detected
 * structure can never yield an infeasible answer.
 */
#include "ip.h"

/* ---------- floating gcd: recover the coefficient grid ---------- */
static double fgcd(double a, double b) {
    a = fabs(a); b = fabs(b);
    if (a < b) { double t = a; a = b; b = t; }
    int guard = 0;
    while (b > 1e-9 * (a + 1.0) && guard++ < 200) {
        double r = fmod(a, b);
        a = b;
        b = r;
    }
    return a;
}

/* ---------- 0-1 knapsack: exact dynamic program ---------- */
static int try_knapsack(Ctx *C) {
    Model *M = C->M;
    if (M->m != 1) return 0;
    if (M->sense[0] != SENSE_LE) return 0;
    int n = M->n;
    if (n <= 0) return 0;
    /* dense support required: variables missing from the row are free */
    /* the DP works on the *original* (unnormalised) numbers so that integral
       weights stay integral */
    const double *RV = M->orig_rv;
    const double RHS = M->orig_rhs[0];
    double g = 0.0;
    for (int k = M->rs[0]; k < M->rs[1]; k++) {
        double v = RV[k];
        if (v < 0.0) return 0;
        g = (g == 0.0) ? v : fgcd(g, v);
    }
    if (RHS < 0.0) return 0;
    if (g <= 0.0) {
        /* all coefficients zero: pure unconstrained choice */
        int *x = (int *)xcalloc((size_t)n, sizeof(int));
        for (int j = 0; j < n; j++) x[j] = (M->c[j] < 0.0) ? 1 : 0;
        int r = ctx_offer(C, x);
        free(x);
        return r;
    }
    g = fgcd(g, RHS);
    if (g <= 0.0) return 0;
    /* integrality check */
    long long cap = 0;
    for (int k = M->rs[0]; k < M->rs[1]; k++) {
        double q = RV[k] / g;
        if (fabs(q - floor(q + 0.5)) > 1e-6) return 0;
    }
    {
        double q = RHS / g;
        if (q < 0.0) return 0;
        if (q > 4.0e8) return 0;
        cap = (long long)floor(q + 1e-6);
    }
    int nz = M->rs[1] - M->rs[0];
    if ((double)(cap + 1) * (double)(nz + 1) > 1.5e8) return 0;

    int *w = (int *)xmalloc((size_t)(nz ? nz : 1) * sizeof(int));
    int *idx = (int *)xmalloc((size_t)(nz ? nz : 1) * sizeof(int));
    double *p = (double *)xmalloc((size_t)(nz ? nz : 1) * sizeof(double));
    int nn = 0;
    int *x = (int *)xcalloc((size_t)n, sizeof(int));
    /* variables not in the row: set by objective sign alone */
    char *inrow = (char *)xcalloc((size_t)n, 1);
    for (int k = M->rs[0]; k < M->rs[1]; k++) inrow[M->ri[k]] = 1;
    for (int j = 0; j < n; j++) if (!inrow[j] && M->c[j] < 0.0) x[j] = 1;
    for (int k = M->rs[0]; k < M->rs[1]; k++) {
        int j = M->ri[k];
        long long wi = (long long)floor(RV[k] / g + 0.5);
        double pj = -M->c[j];   /* profit in maximisation terms */
        if (wi == 0) { if (pj > 0.0) x[j] = 1; continue; }
        if (pj <= 0.0) continue;          /* never worth taking */
        if (wi > cap) continue;           /* cannot fit */
        w[nn] = (int)wi; p[nn] = pj; idx[nn] = j; nn++;
    }
    if (nn == 0) {
        int r = ctx_offer(C, x);
        free(w); free(idx); free(p); free(x); free(inrow);
        return r;
    }
    size_t words = (size_t)((cap + 1 + 63) / 64);
    double *dp = (double *)xcalloc((size_t)cap + 1, sizeof(double));
    unsigned long long *take =
        (unsigned long long *)calloc(words * (size_t)nn, sizeof(unsigned long long));
    if (!take) { free(dp); free(w); free(idx); free(p); free(x); free(inrow); return 0; }
    for (int i = 0; i < nn; i++) {
        int wi = w[i];
        double pi = p[i];
        unsigned long long *row = take + words * (size_t)i;
        for (long long c = cap; c >= wi; c--) {
            double v = dp[c - wi] + pi;
            if (v > dp[c] + 1e-12) {
                dp[c] = v;
                row[c >> 6] |= 1ULL << (c & 63);
            }
        }
    }
    long long bc = 0;
    double bv = dp[0];
    for (long long c = 1; c <= cap; c++) if (dp[c] > bv) { bv = dp[c]; bc = c; }
    long long c = bc;
    for (int i = nn - 1; i >= 0; i--) {
        unsigned long long *row = take + words * (size_t)i;
        if ((row[c >> 6] >> (c & 63)) & 1ULL) { x[idx[i]] = 1; c -= w[i]; }
    }
    int r = ctx_offer(C, x);
    free(dp); free(take); free(w); free(idx); free(p); free(x); free(inrow);
    return r;
}

/* ---------- TSP: recover the graph and run Held-Karp ---------- */
static int try_tsp(Ctx *C) {
    Model *M = C->M;
    int n = M->n;
    if (n < 3 || n > 4000) return 0;
    /* degree rows: '==', rhs 2 (up to common scaling), all coefficients equal */
    int nnode = 0;
    int *degrow = (int *)xmalloc((size_t)(M->m ? M->m : 1) * sizeof(int));
    for (int r = 0; r < M->m; r++) {
        if (M->sense[r] != SENSE_EQ) continue;
        int len = M->rs[r + 1] - M->rs[r];
        if (len < 2) continue;
        double a0 = M->rv[M->rs[r]];
        if (a0 <= 0.0) continue;
        int ok = 1;
        for (int k = M->rs[r]; k < M->rs[r + 1]; k++)
            if (fabs(M->rv[k] - a0) > 1e-9 * a0) { ok = 0; break; }
        if (!ok) continue;
        if (fabs(M->rhs[r] / a0 - 2.0) > 1e-6) continue;
        degrow[nnode++] = r;
    }
    if (nnode < 4 || nnode > 19) { free(degrow); return 0; }
    /* every variable must appear in exactly two degree rows */
    int *cnt = (int *)xcalloc((size_t)n, sizeof(int));
    int *ea = (int *)xmalloc((size_t)n * sizeof(int));
    int *eb = (int *)xmalloc((size_t)n * sizeof(int));
    for (int i = 0; i < n; i++) { ea[i] = -1; eb[i] = -1; }
    for (int t = 0; t < nnode; t++) {
        int r = degrow[t];
        for (int k = M->rs[r]; k < M->rs[r + 1]; k++) {
            int j = M->ri[k];
            if (cnt[j] == 0) ea[j] = t;
            else if (cnt[j] == 1) eb[j] = t;
            cnt[j]++;
        }
    }
    int nedge = 0;
    for (int j = 0; j < n; j++) {
        if (cnt[j] != 2) { free(degrow); free(cnt); free(ea); free(eb); return 0; }
        nedge++;
    }
    if (nedge != n) { free(degrow); free(cnt); free(ea); free(eb); return 0; }

    int V = nnode;
    double *cost = (double *)xmalloc((size_t)V * (size_t)V * sizeof(double));
    int *evar = (int *)xmalloc((size_t)V * (size_t)V * sizeof(int));
    for (int i = 0; i < V * V; i++) { cost[i] = INFINITY; evar[i] = -1; }
    for (int j = 0; j < n; j++) {
        int u = ea[j], v = eb[j];
        if (u < 0 || v < 0 || u == v) { free(degrow); free(cnt); free(ea); free(eb); free(cost); free(evar); return 0; }
        double cc = M->c[j];
        if (cc < cost[u * V + v]) {
            cost[u * V + v] = cc; cost[v * V + u] = cc;
            evar[u * V + v] = j; evar[v * V + u] = j;
        }
    }
    /* Held-Karp */
    size_t full = (size_t)1 << V;
    double *dp = (double *)malloc(full * (size_t)V * sizeof(double));
    unsigned char *par = (unsigned char *)malloc(full * (size_t)V);
    if (!dp || !par) {
        free(dp); free(par);
        free(degrow); free(cnt); free(ea); free(eb); free(cost); free(evar);
        return 0;
    }
    for (size_t i = 0; i < full * (size_t)V; i++) dp[i] = INFINITY;
    dp[(size_t)1 * V + 0] = 0.0;
    for (size_t mask = 1; mask < full; mask++) {
        if (!(mask & 1)) continue;
        double *row = dp + mask * V;
        for (int last = 0; last < V; last++) {
            double cur = row[last];
            if (!isfinite(cur)) continue;
            if (!((mask >> last) & 1)) continue;
            for (int nx = 1; nx < V; nx++) {
                if ((mask >> nx) & 1) continue;
                double cc = cost[last * V + nx];
                if (!isfinite(cc)) continue;
                size_t nm = mask | ((size_t)1 << nx);
                if (cur + cc < dp[nm * V + nx]) {
                    dp[nm * V + nx] = cur + cc;
                    par[nm * V + nx] = (unsigned char)last;
                }
            }
        }
    }
    size_t fm = full - 1;
    double best = INFINITY;
    int bl = -1;
    for (int last = 1; last < V; last++) {
        double cc = cost[last * V + 0];
        if (!isfinite(cc) || !isfinite(dp[fm * V + last])) continue;
        double tot = dp[fm * V + last] + cc;
        if (tot < best) { best = tot; bl = last; }
    }
    int res = 0;
    if (bl >= 0) {
        int *x = (int *)xcalloc((size_t)n, sizeof(int));
        size_t mask = fm;
        int last = bl;
        int prevnode = 0;
        int tourlen = 0;
        while (mask != 1 && tourlen <= V) {
            int pv = par[mask * V + last];
            int e = evar[pv * V + last];
            if (e >= 0) x[e] = 1;
            mask ^= (size_t)1 << last;
            last = pv;
            tourlen++;
        }
        int e0 = evar[bl * V + 0];
        if (e0 >= 0) x[e0] = 1;
        (void)prevnode;
        res = ctx_offer(C, x);
        free(x);
    }
    free(dp); free(par);
    free(degrow); free(cnt); free(ea); free(eb); free(cost); free(evar);
    return res;
}

int special_run(Ctx *C, LagInfo *L) {
    (void)L;
    int any = 0;
    any |= try_knapsack(C);
    any |= try_tsp(C);
    return any;
}
