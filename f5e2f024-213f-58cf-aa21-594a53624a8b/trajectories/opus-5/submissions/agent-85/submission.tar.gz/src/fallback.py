#!/usr/bin/env python3
"""Pure-python fallback solver.

Only used when the C solver could not be compiled.  Implements a greedy
constructive pass plus a short penalty local search so that a feasible answer
and at least two BEST progression tokens are always produced.
"""
from __future__ import annotations

import json
import random
import sys
import time

T0 = time.time()
TIME_LIMIT = 25.0


def emit(obj):
    sys.stderr.write("BEST ts=%.4f obj=%.6f\n" % (time.time() - T0, obj))
    sys.stderr.flush()


def main() -> int:
    path = sys.argv[1] if len(sys.argv) > 1 else "-"
    with (open(path, "r", encoding="utf-8") if path != "-" else sys.stdin) as fh:
        inst = json.load(fh)

    n = int(inst["n_vars"])
    maximize = inst["objective_sense"] == "max"
    obj = [float(v) for v in inst["objective_coefficients"]]
    cons = inst["constraints"]
    rows = []
    for con in cons:
        nz = [(i, float(v)) for i, v in enumerate(con["coefficients"]) if v != 0.0]
        rows.append((nz, float(con["rhs"]), con["sense"]))
    cmin = [(-v if maximize else v) for v in obj]

    cols = [[] for _ in range(n)]
    for r, (nz, rhs, sense) in enumerate(rows):
        for i, v in nz:
            cols[i].append((r, v))

    def activities(x):
        return [sum(v for i, v in nz if x[i]) for nz, _, _ in rows]

    def viol_of(r, a):
        nz, rhs, sense = rows[r]
        if sense == "<=":
            return max(0.0, a - rhs)
        if sense == ">=":
            return max(0.0, rhs - a)
        return abs(a - rhs)

    scale = [max([abs(v) for _, v in nz] + [1.0]) for nz, _, _ in rows]
    cmag = max([abs(v) for v in cmin] + [1.0])
    w = [cmag for _ in rows]

    x = [0] * n
    act = activities(x)
    rng = random.Random(12345)

    def total_viol(act):
        return sum(w[r] * viol_of(r, act[r]) / scale[r] for r in range(len(rows)))

    def score(x, act):
        return sum(cmin[j] for j in range(n) if x[j]) + total_viol(act)

    def flip_delta(j, x, act):
        s = -1.0 if x[j] else 1.0
        d = s * cmin[j]
        for r, v in cols[j]:
            d += w[r] * (viol_of(r, act[r] + s * v) - viol_of(r, act[r])) / scale[r]
        return d

    def apply(j, x, act):
        s = -1.0 if x[j] else 1.0
        x[j] ^= 1
        for r, v in cols[j]:
            act[r] += s * v

    def feasible(x):
        act = activities(x)
        for r in range(len(rows)):
            if viol_of(r, act[r]) > 1e-9:
                return False
        return True

    best = None
    best_obj = None
    for _ in range(200000):
        if time.time() - T0 > TIME_LIMIT:
            break
        bj, bd = -1, 0.0
        for j in range(n):
            d = flip_delta(j, x, act)
            if d < bd - 1e-12:
                bd, bj = d, j
        if bj < 0:
            break
        apply(bj, x, act)
        if feasible(x):
            o = sum(obj[j] for j in range(n) if x[j])
            better = best_obj is None or (o > best_obj if maximize else o < best_obj)
            if better:
                best_obj = o
                best = list(x)
                emit(o)

    if best is None and feasible([0] * n):
        best = [0] * n
        best_obj = 0.0
        emit(0.0)

    if best is not None:
        emit(best_obj)
        out = {
            "instance_id": inst.get("instance_id", ""),
            "status": "optimal",
            "variables": [int(v) for v in best],
            "objective_value": best_obj,
        }
    else:
        out = {
            "instance_id": inst.get("instance_id", ""),
            "status": "unknown",
            "variables": None,
            "objective_value": None,
        }
    sys.stdout.write(json.dumps(out) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
