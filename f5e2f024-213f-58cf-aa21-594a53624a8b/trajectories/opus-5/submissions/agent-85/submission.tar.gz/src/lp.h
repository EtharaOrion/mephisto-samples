#ifndef LP_H
#define LP_H

#include "ip.h"

#define LP_OPTIMAL 0
#define LP_INFEASIBLE 1
#define LP_ITERLIMIT 2

typedef struct LP LP;

typedef struct {
    int status;
    double obj;
    double *x;     /* borrowed: value of every column (structural first) */
    double *d;     /* borrowed: reduced costs */
    long iters;
} LPResult;

LP *lp_create(Model *M);
void lp_free(LP *L);
int lp_solve(LP *L, const double *lo, const double *up, double tend, LPResult *R);
int lp_resolve(LP *L, double tend, LPResult *R);
void lp_set_bounds(LP *L, int j, double lo, double up);
void lp_get_bounds(LP *L, int j, double *lo, double *up);
double lp_var(LP *L, int j);
double lp_rc(LP *L, int j);
int lp_nstruct(LP *L);

#endif
