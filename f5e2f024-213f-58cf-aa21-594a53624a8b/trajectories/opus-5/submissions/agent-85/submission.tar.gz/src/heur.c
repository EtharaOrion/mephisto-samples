/* heur.c - penalty tabu search + exact large-neighbourhood search. */
#include "ip.h"

typedef struct {
    Ctx *C;
    Model *M;
    int n, m;
    int *x;
    double *act;      /* incremental row activities */
    double *w;        /* penalty weight per row (per unit normalised violation) */
    double *delta;    /* score change of flipping j */
    double cost;      /* internal (minimisation) objective */
    double pen;       /* weighted violation */
    int nviol;        /* number of violated rows */
    signed char *vio; /* per-row violated flag */
    int *tabu;
    int iter;
    Rng rng;
    int *stamp;
    int stampcur;
    int *touch;
    double cmag;
    int *bestx;       /* best (possibly infeasible) working solution */
    double bestscore;
} LS;

static inline double rawviol(const Model *M, int r, double a) {
    double b = M->rhs[r];
    char s = M->sense[r];
    if (s == SENSE_LE) { double d = a - b; return d > 0.0 ? d : 0.0; }
    if (s == SENSE_GE) { double d = b - a; return d > 0.0 ? d : 0.0; }
    double d = a - b;
    return d < 0.0 ? -d : d;
}

static inline double nviol(const Model *M, int r, double a) {
    return rawviol(M, r, a) / M->rscale[r];
}

static inline int is_viol(const Model *M, int r, double a) {
    return rawviol(M, r, a) > 1e-7 * M->rscale[r];
}

/* Keep the penalty weights in a sane band.  Without this the repeated
   multiplicative increases used to escape infeasible local optima overflow to
   +inf after a few thousand stalls, every delta becomes NaN and the search
   silently dies without ever producing a feasible point. */
static void ls_renorm_weights(LS *S) {
    double mx = 0.0;
    for (int r = 0; r < S->m; r++) if (S->w[r] > mx) mx = S->w[r];
    double lim = S->cmag * 1e6;
    if (!(mx > lim)) return;
    double f = lim / mx;
    for (int r = 0; r < S->m; r++) {
        S->w[r] *= f;
        if (S->w[r] < S->cmag * 1e-4) S->w[r] = S->cmag * 1e-4;
    }
}

static void ls_recompute(LS *S) {
    Model *M = S->M;
    int n = S->n, m = S->m;
    for (int r = 0; r < m; r++) S->act[r] = 0.0;
    for (int j = 0; j < n; j++) {
        if (!S->x[j]) continue;
        int e = M->cs[j + 1];
        for (int k = M->cs[j]; k < e; k++) S->act[M->ci[k]] += M->cv[k];
    }
    S->pen = 0.0;
    S->nviol = 0;
    for (int r = 0; r < m; r++) {
        S->pen += S->w[r] * nviol(M, r, S->act[r]);
        int v = is_viol(M, r, S->act[r]);
        S->vio[r] = (signed char)v;
        S->nviol += v;
    }
    S->cost = 0.0;
    for (int j = 0; j < n; j++) if (S->x[j]) S->cost += M->c[j];
    for (int j = 0; j < n; j++) {
        double s = S->x[j] ? -1.0 : 1.0;
        double d = s * M->c[j];
        int e = M->cs[j + 1];
        for (int k = M->cs[j]; k < e; k++) {
            int r = M->ci[k];
            double a = S->act[r];
            d += S->w[r] * (nviol(M, r, a + s * M->cv[k]) - nviol(M, r, a));
        }
        S->delta[j] = d;
    }
}

static void ls_update_delta(LS *S, int j) {
    Model *M = S->M;
    double s = S->x[j] ? -1.0 : 1.0;
    double d = s * M->c[j];
    int e = M->cs[j + 1];
    for (int k = M->cs[j]; k < e; k++) {
        int r = M->ci[k];
        double a = S->act[r];
        d += S->w[r] * (nviol(M, r, a + s * M->cv[k]) - nviol(M, r, a));
    }
    S->delta[j] = d;
}

static void ls_flip(LS *S, int j) {
    Model *M = S->M;
    double s = S->x[j] ? -1.0 : 1.0;
    S->x[j] ^= 1;
    S->cost += s * M->c[j];
    int e = M->cs[j + 1];
    S->stampcur++;
    int nt = 0;
    for (int k = M->cs[j]; k < e; k++) {
        int r = M->ci[k];
        double old = nviol(M, r, S->act[r]);
        S->act[r] += s * M->cv[k];
        double nw = nviol(M, r, S->act[r]);
        S->pen += S->w[r] * (nw - old);
        int v = is_viol(M, r, S->act[r]);
        if (v != S->vio[r]) { S->nviol += v ? 1 : -1; S->vio[r] = (signed char)v; }
        int re = M->rs[r + 1];
        for (int t = M->rs[r]; t < re; t++) {
            int jj = M->ri[t];
            if (S->stamp[jj] != S->stampcur) { S->stamp[jj] = S->stampcur; S->touch[nt++] = jj; }
        }
    }
    if (S->stamp[j] != S->stampcur) { S->stamp[j] = S->stampcur; S->touch[nt++] = j; }
    for (int t = 0; t < nt; t++) ls_update_delta(S, S->touch[t]);
}

static void ls_init(LS *S, Ctx *C, unsigned long long seed) {
    Model *M = C->M;
    S->C = C; S->M = M; S->n = M->n; S->m = M->m;
    S->x = (int *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(int));
    S->bestx = (int *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(int));
    S->act = (double *)xcalloc((size_t)(M->m ? M->m : 1), sizeof(double));
    S->w = (double *)xcalloc((size_t)(M->m ? M->m : 1), sizeof(double));
    S->delta = (double *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(double));
    S->vio = (signed char *)xcalloc((size_t)(M->m ? M->m : 1), 1);
    S->tabu = (int *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(int));
    S->stamp = (int *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(int));
    S->touch = (int *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(int));
    S->iter = 0;
    rng_seed(&S->rng, seed);
    double cm = 0.0;
    for (int j = 0; j < M->n; j++) { double a = fabs(M->c[j]); if (a > cm) cm = a; }
    if (cm <= 0.0) cm = 1.0;
    S->cmag = cm;
    for (int r = 0; r < M->m; r++) S->w[r] = cm;
    S->bestscore = INFINITY;
}

/* ------------------------------------------------------------------ */
/* Exact large-neighbourhood search over a small free set              */
/* ------------------------------------------------------------------ */

typedef struct {
    Model *M;
    int K;
    int *fv;            /* free variable indices, by depth */
    int *depth_of;      /* var -> depth or -1 */
    /* per free var: rows it touches */
    int *ent_start;     /* K+1 */
    int *ent_row;
    double *ent_coef;
    int *ent_pos;       /* position within the row's free list */
    /* per affected row */
    int nrows;
    int *rows;
    int *rowidx;        /* row -> local index or -1 */
    double *base;       /* activity from fixed vars */
    double *cur;        /* current activity (base + assigned free) */
    int *sufstart;      /* nrows+1 into sufmin/sufmax arrays (len = cnt+1) */
    double *sufmin;
    double *sufmax;
    double *sufcost;    /* K+1: suffix sum of min(0,c) */
    int *val;           /* current assignment of free vars */
    int *bestval;
    double bestcost;
    long nodes;
    long nodecap;
    int improved;
    double tol;
} SubP;

static void sub_dfs(SubP *P, int d, double curcost) {
    if (P->nodes++ > P->nodecap) return;
    if (d == P->K) {
        if (curcost < P->bestcost - 1e-9) {
            P->bestcost = curcost;
            memcpy(P->bestval, P->val, (size_t)P->K * sizeof(int));
            P->improved = 1;
        }
        return;
    }
    if (curcost + P->sufcost[d] >= P->bestcost - 1e-9) return;
    Model *M = P->M;
    int j = P->fv[d];
    double cj = M->c[j];
    /* try value order: cheaper objective first */
    int order[2];
    if (cj <= 0.0) { order[0] = 1; order[1] = 0; }
    else { order[0] = 0; order[1] = 1; }
    for (int t = 0; t < 2; t++) {
        if (P->nodes > P->nodecap) return;
        int v = order[t];
        int ok = 1;
        int es = P->ent_start[d], ee = P->ent_start[d + 1];
        if (v) {
            for (int k = es; k < ee; k++) {
                int li = P->rowidx[P->ent_row[k]];
                P->cur[li] += P->ent_coef[k];
            }
        }
        for (int k = es; k < ee; k++) {
            int r = P->ent_row[k];
            int li = P->rowidx[r];
            int pos = P->ent_pos[k];
            double a = P->cur[li];
            double lo = a + P->sufmin[P->sufstart[li] + pos + 1];
            double hi = a + P->sufmax[P->sufstart[li] + pos + 1];
            double b = M->rhs[r];
            double tol = P->tol * M->rscale[r];
            char sn = M->sense[r];
            if (sn == SENSE_LE) { if (lo > b + tol) { ok = 0; break; } }
            else if (sn == SENSE_GE) { if (hi < b - tol) { ok = 0; break; } }
            else { if (lo > b + tol || hi < b - tol) { ok = 0; break; } }
        }
        if (ok) {
            P->val[d] = v;
            sub_dfs(P, d + 1, curcost + (v ? cj : 0.0));
        }
        if (v) {
            for (int k = es; k < ee; k++) {
                int li = P->rowidx[P->ent_row[k]];
                P->cur[li] -= P->ent_coef[k];
            }
        }
    }
}

typedef struct {
    int cap;
    int *fv;
    int *depth_of;
    int *rowidx;
    int *rows;
    double *base;
    double *cur;
    int *sufstart;
    double *sufmin;
    double *sufmax;
    double *sufcost;
    int *val;
    int *bestval;
    int *ent_start;
    int *ent_row;
    double *ent_coef;
    int *ent_pos;
    int entcap;
    int sufcap;
    int *rowfreecnt;
} LnsWork;

static LnsWork *lns_alloc(Model *M, int maxK) {
    LnsWork *W = (LnsWork *)xcalloc(1, sizeof(LnsWork));
    W->cap = maxK;
    W->fv = (int *)xcalloc((size_t)maxK, sizeof(int));
    W->depth_of = (int *)xmalloc((size_t)(M->n ? M->n : 1) * sizeof(int));
    for (int j = 0; j < M->n; j++) W->depth_of[j] = -1;
    W->rowidx = (int *)xmalloc((size_t)(M->m ? M->m : 1) * sizeof(int));
    for (int r = 0; r < M->m; r++) W->rowidx[r] = -1;
    W->rows = (int *)xcalloc((size_t)(M->m ? M->m : 1), sizeof(int));
    W->base = (double *)xcalloc((size_t)(M->m ? M->m : 1), sizeof(double));
    W->cur = (double *)xcalloc((size_t)(M->m ? M->m : 1), sizeof(double));
    W->sufstart = (int *)xcalloc((size_t)(M->m ? M->m : 1) + 1, sizeof(int));
    W->rowfreecnt = (int *)xcalloc((size_t)(M->m ? M->m : 1), sizeof(int));
    W->val = (int *)xcalloc((size_t)maxK, sizeof(int));
    W->bestval = (int *)xcalloc((size_t)maxK, sizeof(int));
    W->sufcost = (double *)xcalloc((size_t)maxK + 1, sizeof(double));
    W->ent_start = (int *)xcalloc((size_t)maxK + 1, sizeof(int));
    W->entcap = 1024;
    W->ent_row = (int *)xmalloc((size_t)W->entcap * sizeof(int));
    W->ent_coef = (double *)xmalloc((size_t)W->entcap * sizeof(double));
    W->ent_pos = (int *)xmalloc((size_t)W->entcap * sizeof(int));
    W->sufcap = 1024;
    W->sufmin = (double *)xmalloc((size_t)W->sufcap * sizeof(double));
    W->sufmax = (double *)xmalloc((size_t)W->sufcap * sizeof(double));
    return W;
}

/* Run one exact LNS pass around the current LS solution.
   Returns 1 if the solution improved. */
static int lns_pass(LS *S, LnsWork *W, int K, long nodecap, const int *seedvars, int nseed,
                    long *nodes_used) {
    Model *M = S->M;
    int n = S->n;
    if (K > W->cap) K = W->cap;
    if (K <= 1) return 0;

    /* --- build the free set by BFS over the constraint graph --- */
    int nf = 0;
    int qh = 0;
    for (int i = 0; i < nseed && nf < K; i++) {
        int j = seedvars[i];
        if (j < 0 || j >= n) continue;
        if (W->depth_of[j] >= 0) continue;
        W->depth_of[j] = nf;
        W->fv[nf++] = j;
    }
    while (nf < K && qh < nf) {
        int j = W->fv[qh++];
        int rs = M->cs[j], re = M->cs[j + 1];
        int cntr = re - rs;
        if (cntr <= 0) continue;
        int start = rng_int(&S->rng, cntr);
        for (int t = 0; t < cntr && nf < K; t++) {
            int r = M->ci[rs + (start + t) % cntr];
            int rlen = M->rs[r + 1] - M->rs[r];
            if (rlen > 4 * K + 40) continue;
            int s2 = rng_int(&S->rng, rlen);
            for (int u = 0; u < rlen && nf < K; u++) {
                int jj = M->ri[M->rs[r] + (s2 + u) % rlen];
                if (W->depth_of[jj] >= 0) continue;
                W->depth_of[jj] = nf;
                W->fv[nf++] = jj;
            }
        }
    }
    /* the constraint graph may be too coarse (e.g. one dense row): top up
       with random variables so the neighbourhood always reaches size K */
    int guard = 0;
    while (nf < K && guard < 20 * K + 100) {
        guard++;
        int j = rng_int(&S->rng, n);
        if (W->depth_of[j] >= 0) continue;
        W->depth_of[j] = nf;
        W->fv[nf++] = j;
    }
    if (nf < 2) {
        for (int i = 0; i < nf; i++) W->depth_of[W->fv[i]] = -1;
        return 0;
    }
    K = nf;

    /* --- collect affected rows --- */
    int nrows = 0;
    for (int d = 0; d < K; d++) {
        int j = W->fv[d];
        for (int k = M->cs[j]; k < M->cs[j + 1]; k++) {
            int r = M->ci[k];
            if (W->rowidx[r] < 0) { W->rowidx[r] = nrows; W->rows[nrows++] = r; }
        }
    }
    /* base activity = current activity minus contributions of free vars */
    for (int i = 0; i < nrows; i++) { W->base[i] = S->act[W->rows[i]]; W->rowfreecnt[i] = 0; }
    for (int d = 0; d < K; d++) {
        int j = W->fv[d];
        if (!S->x[j]) continue;
        for (int k = M->cs[j]; k < M->cs[j + 1]; k++) {
            int li = W->rowidx[M->ci[k]];
            W->base[li] -= M->cv[k];
        }
    }
    for (int d = 0; d < K; d++) {
        int j = W->fv[d];
        for (int k = M->cs[j]; k < M->cs[j + 1]; k++) W->rowfreecnt[W->rowidx[M->ci[k]]]++;
    }
    /* suffix arrays layout */
    int tot = 0;
    for (int i = 0; i < nrows; i++) { W->sufstart[i] = tot; tot += W->rowfreecnt[i] + 1; }
    W->sufstart[nrows] = tot;
    if (tot > W->sufcap) {
        while (W->sufcap < tot) W->sufcap *= 2;
        W->sufmin = (double *)xrealloc(W->sufmin, (size_t)W->sufcap * sizeof(double));
        W->sufmax = (double *)xrealloc(W->sufmax, (size_t)W->sufcap * sizeof(double));
    }
    for (int i = 0; i < tot; i++) { W->sufmin[i] = 0.0; W->sufmax[i] = 0.0; }

    /* entries per free var, positions within each row's free list */
    int nent = 0;
    for (int d = 0; d < K; d++) nent += M->cs[W->fv[d] + 1] - M->cs[W->fv[d]];
    if (nent > W->entcap) {
        while (W->entcap < nent) W->entcap *= 2;
        W->ent_row = (int *)xrealloc(W->ent_row, (size_t)W->entcap * sizeof(int));
        W->ent_coef = (double *)xrealloc(W->ent_coef, (size_t)W->entcap * sizeof(double));
        W->ent_pos = (int *)xrealloc(W->ent_pos, (size_t)W->entcap * sizeof(int));
    }
    for (int i = 0; i < nrows; i++) W->rowfreecnt[i] = 0;
    int ep = 0;
    for (int d = 0; d < K; d++) {
        W->ent_start[d] = ep;
        int j = W->fv[d];
        for (int k = M->cs[j]; k < M->cs[j + 1]; k++) {
            int r = M->ci[k];
            int li = W->rowidx[r];
            int pos = W->rowfreecnt[li]++;
            W->ent_row[ep] = r;
            W->ent_coef[ep] = M->cv[k];
            W->ent_pos[ep] = pos;
            ep++;
        }
    }
    W->ent_start[K] = ep;
    /* fill suffix min/max per row (iterate entries backwards) */
    for (int k = ep - 1; k >= 0; k--) {
        int li = W->rowidx[W->ent_row[k]];
        int pos = W->ent_pos[k];
        int base = W->sufstart[li];
        double a = W->ent_coef[k];
        W->sufmin[base + pos] = W->sufmin[base + pos + 1] + (a < 0.0 ? a : 0.0);
        W->sufmax[base + pos] = W->sufmax[base + pos + 1] + (a > 0.0 ? a : 0.0);
    }
    W->sufcost[K] = 0.0;
    for (int d = K - 1; d >= 0; d--) {
        double c = M->c[W->fv[d]];
        W->sufcost[d] = W->sufcost[d + 1] + (c < 0.0 ? c : 0.0);
    }

    SubP P;
    P.M = M; P.K = K;
    P.fv = W->fv; P.depth_of = W->depth_of;
    P.ent_start = W->ent_start; P.ent_row = W->ent_row;
    P.ent_coef = W->ent_coef; P.ent_pos = W->ent_pos;
    P.nrows = nrows; P.rows = W->rows; P.rowidx = W->rowidx;
    P.base = W->base; P.cur = W->cur;
    P.sufstart = W->sufstart; P.sufmin = W->sufmin; P.sufmax = W->sufmax;
    P.sufcost = W->sufcost;
    P.val = W->val; P.bestval = W->bestval;
    P.nodes = 0; P.nodecap = nodecap; P.improved = 0;
    P.tol = 1e-9;
    for (int i = 0; i < nrows; i++) W->cur[i] = W->base[i];
    /* current cost contribution of the free vars */
    double curfree = 0.0;
    for (int d = 0; d < K; d++) if (S->x[W->fv[d]]) curfree += M->c[W->fv[d]];
    P.bestcost = curfree;
    for (int d = 0; d < K; d++) W->bestval[d] = S->x[W->fv[d]];

    sub_dfs(&P, 0, 0.0);
    if (nodes_used) *nodes_used = P.nodes;

    int improved = 0;
    if (P.improved) {
        for (int d = 0; d < K; d++) {
            int j = W->fv[d];
            if (S->x[j] != W->bestval[d]) ls_flip(S, j);
        }
        improved = 1;
    }
    for (int d = 0; d < K; d++) W->depth_of[W->fv[d]] = -1;
    for (int i = 0; i < nrows; i++) W->rowidx[W->rows[i]] = -1;
    return improved;
}

/* ------------------------------------------------------------------ */

static void ls_try_offer(LS *S) {
    if (S->nviol == 0) {
        Ctx *C = S->C;
        if (!C->have || S->cost < C->bestint - 1e-9) ctx_offer(C, S->x);
    }
}

/* one round of tabu search; returns number of improvements found */
static int tabu_round(LS *S, long iters, double tend) {
    Model *M = S->M;
    int n = S->n;
    int improvements = 0;
    double bestlocal = INFINITY;
    long sincebest = 0;
    for (long it = 0; it < iters; it++) {
        if ((it & 255) == 0 && now_sec() > tend) break;
        S->iter++;
        int bj = -1;
        double bd = INFINITY;
        double curscore = S->cost + S->pen;
        for (int j = 0; j < n; j++) {
            double d = S->delta[j];
            if (d >= bd) continue;
            if (S->tabu[j] > S->iter) {
                /* aspiration: accept if it beats the best score seen */
                if (curscore + d >= bestlocal - 1e-12) continue;
            }
            bd = d; bj = j;
        }
        if (bj < 0) {
            /* everything tabu; pick random */
            bj = rng_int(&S->rng, n);
            bd = S->delta[bj];
        }
        ls_flip(S, bj);
        S->tabu[bj] = S->iter + 4 + rng_int(&S->rng, 8) + (n > 500 ? n / 100 : 0);
        double sc = S->cost + S->pen;
        if (S->nviol == 0) {
            Ctx *C = S->C;
            if (!C->have || S->cost < C->bestint - 1e-9) {
                if (ctx_offer(C, S->x)) improvements++;
            }
        }
        if (sc < bestlocal - 1e-12) { bestlocal = sc; sincebest = 0; }
        else sincebest++;
        if (sincebest > 30 + n / 10) {
            /* stagnation: reweight */
            if (S->nviol > 0) {
                for (int r = 0; r < S->m; r++) if (S->vio[r]) S->w[r] *= 1.35;
                ls_renorm_weights(S);
            } else {
                for (int r = 0; r < S->m; r++) S->w[r] = S->w[r] * 0.9 + 0.1 * S->cmag;
            }
            ls_recompute(S);
            bestlocal = S->cost + S->pen;
            sincebest = 0;
        }
        (void)M;
    }
    return improvements;
}

/* greedy repair from the current point: drive to feasibility fast */
static void repair(LS *S, double tend) {
    int guard = 0;
    while (S->nviol > 0 && guard < 20 * (S->n + S->m) + 1000) {
        guard++;
        if ((guard & 127) == 0 && now_sec() > tend) break;
        /* pick best flip by penalty reduction with cost tiebreak */
        int bj = -1;
        double bd = INFINITY;
        for (int j = 0; j < S->n; j++) {
            double d = S->delta[j];
            if (S->tabu[j] > S->iter) continue;
            if (d < bd) { bd = d; bj = j; }
        }
        if (bj < 0) break;
        if (bd >= 0.0) {
            /* local optimum but infeasible: raise weights on violated rows */
            for (int r = 0; r < S->m; r++) if (S->vio[r]) S->w[r] *= 1.5;
            ls_renorm_weights(S);
            ls_recompute(S);
            continue;
        }
        S->iter++;
        ls_flip(S, bj);
        S->tabu[bj] = S->iter + 3 + rng_int(&S->rng, 5);
    }
}

/* strictly-improving descent that preserves feasibility (1-flips) */
static void descent(LS *S) {
    int improved = 1;
    while (improved) {
        improved = 0;
        for (int j = 0; j < S->n; j++) {
            if (S->delta[j] < -1e-12) {
                double before = S->cost;
                int wasfeas = (S->nviol == 0);
                ls_flip(S, j);
                if (wasfeas && S->nviol != 0) { ls_flip(S, j); continue; }
                if (S->cost < before - 1e-12 || S->nviol < 1) improved = 1;
            }
        }
        if (S->nviol == 0) ls_try_offer(S);
    }
}

/* Fast first-incumbent pass so a BEST token lands as early as possible. */
void heur_quick(Ctx *C) {
    Model *M = C->M;
    int n = M->n;
    LS S;
    ls_init(&S, C, 0x51ED17ULL);
    double tend = C->t0 + C->tlimit * 0.25;
    memset(S.x, 0, (size_t)n * sizeof(int));
    ls_recompute(&S);
    if (S.nviol == 0) {
        ls_try_offer(&S);
        descent(&S);
        ls_try_offer(&S);
    } else {
        repair(&S, tend);
        if (S.nviol == 0) { ls_try_offer(&S); descent(&S); ls_try_offer(&S); }
    }
    free(S.x); free(S.bestx); free(S.act); free(S.w); free(S.delta);
    free(S.vio); free(S.tabu); free(S.stamp); free(S.touch);
}

void heur_run(Ctx *C, LagInfo *L) {
    Model *M = C->M;
    int n = M->n;
    LS S;
    ls_init(&S, C, 0x1234ABCDULL);

    double tend_all = C->t0 + C->tlimit;

    /* ---- start 1: all zeros ---- */
    memset(S.x, 0, (size_t)n * sizeof(int));
    ls_recompute(&S);
    if (S.nviol == 0) ls_try_offer(&S);

    /* ---- start 2: LP-ish rounding of the volume primal ---- */
    if (L && L->valid && L->xbar) {
        for (int j = 0; j < n; j++) S.x[j] = (L->xbar[j] > 0.5) ? 1 : 0;
        ls_recompute(&S);
        repair(&S, tend_all);
        if (S.nviol == 0) { descent(&S); ls_try_offer(&S); }
    }

    /* ---- start 3: greedy from zeros with penalties ---- */
    if (!C->have || 1) {
        memset(S.x, 0, (size_t)n * sizeof(int));
        memset(S.tabu, 0, (size_t)n * sizeof(int));
        ls_recompute(&S);
        repair(&S, tend_all);
        if (S.nviol == 0) { descent(&S); ls_try_offer(&S); }
    }

    if (C->have) {
        memcpy(S.x, C->best, (size_t)n * sizeof(int));
        ls_recompute(&S);
    }

    int maxK = 24;
    LnsWork *W = lns_alloc(M, maxK);
    int K = 14;
    int *seed = (int *)xmalloc((size_t)(n ? n : 1) * sizeof(int));

    long round = 0;
    while (now_sec() < tend_all) {
        round++;
        /* alternate: LNS sweeps on the incumbent, then a tabu burst */
        if (C->have) {
            memcpy(S.x, C->best, (size_t)n * sizeof(int));
            ls_recompute(&S);
        }
        int noimp = 0;
        while (now_sec() < tend_all && noimp < 60) {
            int ns = 1;
            seed[0] = rng_int(&S.rng, n);
            long used = 0;
            int imp = lns_pass(&S, W, K, 60000, seed, ns, &used);
            if (imp) {
                noimp = 0;
                if (S.nviol == 0) ls_try_offer(&S);
            } else noimp++;
        }
        if (now_sec() >= tend_all) break;
        double burst_end = now_sec() + 0.35;
        if (burst_end > tend_all) burst_end = tend_all;
        tabu_round(&S, 2000000, burst_end);
    }

    free(seed);
    (void)W;
}
