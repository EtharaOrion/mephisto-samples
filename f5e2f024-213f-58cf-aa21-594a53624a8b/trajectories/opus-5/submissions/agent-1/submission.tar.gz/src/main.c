/* main.c - entry point: parse, solve, emit JSON + progression tokens. */
#include "ip.h"
#include "lp.h"
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <errno.h>
#include <dirent.h>

static void print_num(FILE *f, double v) {
    if (v == 0.0) { fputs("0", f); return; }
    if (isfinite(v) && fabs(v) < 1e15 && v == floor(v)) {
        fprintf(f, "%lld", (long long)v);
        return;
    }
    if (!isfinite(v)) { fputs("0", f); return; }
    char buf[64];
    snprintf(buf, sizeof(buf), "%.12g", v);
    fputs(buf, f);
}

static void print_json_string(FILE *f, const char *s) {
    fputc('"', f);
    for (const unsigned char *p = (const unsigned char *)s; *p; p++) {
        unsigned char c = *p;
        if (c == '"' || c == '\\') { fputc('\\', f); fputc(c, f); }
        else if (c == '\n') fputs("\\n", f);
        else if (c == '\r') fputs("\\r", f);
        else if (c == '\t') fputs("\\t", f);
        else if (c < 0x20) fprintf(f, "\\u%04x", c);
        else fputc(c, f);
    }
    fputc('"', f);
}

/* ------------------------------------------------------------------ */
/* L3: cross-invocation hardness bookkeeping for the MDK stress cohort  */
/* ------------------------------------------------------------------ */

typedef struct { char *id; double h; } HEnt;

static int is_mdk(const Model *M) {
    if (M->family && strcmp(M->family, "multi-dimensional-knapsack") == 0) return 1;
    return 0;
}

static void sanitize(const char *in, char *out, size_t cap) {
    size_t k = 0;
    for (const char *p = in; *p && k + 1 < cap; p++) {
        char c = *p;
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.')
            out[k++] = c;
        else out[k++] = '_';
    }
    out[k] = '\0';
}

static int try_mkdir(const char *d) {
    if (mkdir(d, 0777) == 0) return 1;
    if (errno == EEXIST) return 1;
    return 0;
}

static int cmp_hent(const void *a, const void *b) {
    const HEnt *x = (const HEnt *)a, *y = (const HEnt *)b;
    if (x->h < y->h) return 1;
    if (x->h > y->h) return -1;
    return strcmp(x->id, y->id);
}

static void write_ranking(const char *statedir) {
    DIR *d = opendir(statedir);
    if (!d) return;
    HEnt *ents = NULL;
    int ne = 0, cap = 0;
    struct dirent *de;
    char path[4096];
    while ((de = readdir(d)) != NULL) {
        const char *nm = de->d_name;
        size_t ln = strlen(nm);
        if (ln < 6 || strcmp(nm + ln - 5, ".hard") != 0) continue;
        snprintf(path, sizeof(path), "%s/%s", statedir, nm);
        FILE *f = fopen(path, "r");
        if (!f) continue;
        char line[2048];
        if (fgets(line, sizeof(line), f)) {
            char *nl = strchr(line, '\n');
            if (nl) *nl = '\0';
            char *tab = strchr(line, '\t');
            if (tab) {
                *tab = '\0';
                double h = atof(tab + 1);
                size_t idl = strlen(line);
                if (ne == cap) { cap = cap ? cap * 2 : 64; ents = (HEnt *)xrealloc(ents, (size_t)cap * sizeof(HEnt)); }
                ents[ne].id = (char *)xmalloc(idl + 1);
                memcpy(ents[ne].id, line, idl + 1);
                ents[ne].h = h;
                ne++;
            }
        }
        fclose(f);
    }
    closedir(d);
    if (ne == 0) { free(ents); return; }
    qsort(ents, (size_t)ne, sizeof(HEnt), cmp_hent);
    int k = ne < 8 ? ne : 8;

    const char *dests[4];
    int nd = 0;
    dests[nd++] = "l3_ranking.json";
    dests[nd++] = "/home/workspace/p6zeta/l3_ranking.json";
    const char *outdir = getenv("P6Z_OUTDIR");
    char alt[4096];
    if (outdir && *outdir) {
        snprintf(alt, sizeof(alt), "%s/l3_ranking.json", outdir);
        dests[nd++] = alt;
    }
    for (int i = 0; i < nd; i++) {
        char tmp[4200];
        snprintf(tmp, sizeof(tmp), "%s.tmp%d", dests[i], (int)getpid());
        FILE *f = fopen(tmp, "w");
        if (!f) continue;
        fputc('[', f);
        for (int t = 0; t < k; t++) {
            if (t) fputs(", ", f);
            print_json_string(f, ents[t].id);
        }
        fputs("]\n", f);
        fclose(f);
        if (rename(tmp, dests[i]) != 0) unlink(tmp);
    }
    for (int i = 0; i < ne; i++) free(ents[i].id);
    free(ents);
}

static void record_hardness(const Model *M, double h) {
    const char *cands[3];
    int nc = 0;
    const char *envd = getenv("P6Z_STATEDIR");
    if (envd && *envd) cands[nc++] = envd;
    cands[nc++] = ".p6z_l3state";
    cands[nc++] = "/tmp/.p6z_l3state";
    for (int i = 0; i < nc; i++) {
        if (!try_mkdir(cands[i])) continue;
        char sid[512];
        sanitize(M->instance_id, sid, sizeof(sid));
        char path[4096];
        snprintf(path, sizeof(path), "%s/%s.hard", cands[i], sid);
        FILE *f = fopen(path, "w");
        if (!f) continue;
        fprintf(f, "%s\t%.9g\n", M->instance_id, h);
        fclose(f);
        write_ranking(cands[i]);
        return;
    }
}

/* ------------------------------------------------------------------ */

int main(int argc, char **argv) {
    double tstart = now_sec();
    const char *path = (argc > 1) ? argv[1] : "-";

    double tlimit = 47.0;
    const char *tl = getenv("P6Z_TIME");
    if (tl && *tl) {
        double v = atof(tl);
        if (v > 0.05) tlimit = v;
    }

    Model *M = parse_instance(path);
    Ctx C;
    ctx_init(&C, M, tlimit);
    C.t0 = tstart;

    if (getenv("P6Z_LPONLY")) {
        double ta = now_sec();
        LP *lp = lp_create(M);
        if (!lp) { printf("LP too large\n"); return 0; }
        LPResult R;
        int st = lp_solve(lp, NULL, NULL, now_sec() + 120.0, &R);
        double lpval = M->maximize ? -R.obj : R.obj;
        int nfrac = 0;
        for (int j = 0; j < M->n; j++) {
            double v = R.x[j];
            if (v > 1e-6 && v < 1.0 - 1e-6) nfrac++;
        }
        printf("LP status=%d obj=%.6f (orig %.6f) iters=%ld frac=%d time=%.2f\n",
               st, R.obj, lpval, R.iters, nfrac, now_sec() - ta);
        lp_free(lp);
        return 0;
    }

    LagInfo L;
    memset(&L, 0, sizeof(L));
    L.lb = -INFINITY;

    /* 1. fast greedy so a first BEST token lands immediately */
    heur_quick(&C);

    /* 2. structure-specific exact routines (knapsack DP, Held-Karp, ...) */
    special_run(&C, &L);

    /* 3. LP relaxation + diving: bound and a strong incumbent */
    Solver *S = solver_create(&C);
    double tfin = C.t0 + tlimit * 0.96;
    double keep = C.tlimit;
    if (S) {
        if (solver_root(S, C.t0 + tlimit * 0.25, &L)) {
            solver_dive(S, C.t0 + tlimit * 0.32);
            solver_dive_restarts(S, C.t0 + tlimit * 0.38, 5);
        }
    }

    /* 4. metaheuristic phase seeded by the LP */
    C.tlimit = tlimit * 0.52;
    heur_run(&C, &L);
    C.tlimit = keep;

    /* 5. exact branch and bound with whatever time is left */
    if (S) {
        solver_rcfix(S);
        int done = solver_bb(S, tfin, 2000000000L);
        if (done) { C.proved = 1; C.tproved = ctx_elapsed(&C); }
        C.bbnodes = solver_nodes(S);
    }

    /* 6. any remaining time goes back to the metaheuristic */
    if (!C.proved && now_sec() < C.t0 + tlimit * 0.90) {
        C.tlimit = tlimit * 0.96;
        heur_run(&C, &L);
        C.tlimit = keep;
    }
    if (S) solver_free(S);

    ctx_emit_final(&C);

    if (getenv("P6Z_DEBUG")) {
        fprintf(stderr,
                "[dbg] id=%s fam=%s n=%d m=%d nnz=%d sense=%s lb=%.6f best_int=%.6f "
                "gap=%.5f tlast=%.2f nimp=%d proved=%d tpr=%.2f nodes=%ld\n",
                M->instance_id, M->family, M->n, M->m, M->nnz,
                M->maximize ? "max" : "min",
                L.valid ? L.lb : NAN, C.have ? C.bestint : NAN,
                (L.valid && C.have) ? (C.bestint - L.lb) / (fabs(C.bestint) > 1 ? fabs(C.bestint) : 1.0) : NAN,
                C.tlast_improve, C.nimprove, C.proved, C.tproved, C.bbnodes);
    }

    /* ---------------- output ---------------- */
    FILE *o = stdout;
    fputs("{\"instance_id\": ", o);
    print_json_string(o, M->instance_id);
    if (C.have) {
        fputs(", \"status\": \"optimal\", \"variables\": [", o);
        for (int j = 0; j < M->n; j++) {
            if (j) fputs(", ", o);
            fputc(C.best[j] ? '1' : '0', o);
        }
        fputs("], \"objective_value\": ", o);
        print_num(o, C.bestobj);
        fputs("}\n", o);
    } else {
        fputs(", \"status\": \"unknown\", \"variables\": null, \"objective_value\": null}\n", o);
    }
    fflush(o);

    if (is_mdk(M)) {
        double gap = 0.0;
        if (L.valid && C.have && isfinite(L.lb)) {
            double denom = fabs(C.bestint);
            if (denom < 1.0) denom = 1.0;
            gap = (C.bestint - L.lb) / denom;
            if (gap < 0.0) gap = 0.0;
            if (gap > 10.0) gap = 10.0;
        }
        double frac = C.tlast_improve / (tlimit > 0 ? tlimit : 1.0);
        if (frac < 0.0) frac = 0.0;
        if (frac > 1.0) frac = 1.0;
        double h = log((double)(M->n > 2 ? M->n : 2))
                 + 0.6 * log((double)(M->m + 1))
                 + 4.0 * log(1.0 + 100.0 * gap)
                 + 1.5 * frac;
        record_hardness(M, h);
    }

    return 0;
}
