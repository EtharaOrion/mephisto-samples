/* parse.c - minimal, fast, order-independent JSON reader for .ip.json files. */
#include "ip.h"

double now_sec(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + 1e-9 * (double)ts.tv_nsec;
}

void *xmalloc(size_t sz) {
    void *p = malloc(sz ? sz : 1);
    if (!p) { fprintf(stderr, "oom\n"); exit(3); }
    return p;
}
void *xcalloc(size_t nmemb, size_t sz) {
    void *p = calloc(nmemb ? nmemb : 1, sz ? sz : 1);
    if (!p) { fprintf(stderr, "oom\n"); exit(3); }
    return p;
}
void *xrealloc(void *p, size_t sz) {
    void *q = realloc(p, sz ? sz : 1);
    if (!q) { fprintf(stderr, "oom\n"); exit(3); }
    return q;
}

typedef struct {
    const char *p;
    const char *end;
} P;

static void skipws(P *s) {
    while (s->p < s->end) {
        unsigned char c = (unsigned char)*s->p;
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') s->p++;
        else break;
    }
}

static int peek(P *s) { skipws(s); return (s->p < s->end) ? (unsigned char)*s->p : -1; }

static void fail(const char *msg) {
    fprintf(stderr, "parse error: %s\n", msg);
    exit(2);
}

/* Parse a JSON string; returns a freshly allocated NUL-terminated buffer. */
static char *parse_string(P *s) {
    if (peek(s) != '"') fail("expected string");
    s->p++;
    size_t cap = 32, len = 0;
    char *out = (char *)xmalloc(cap);
    while (s->p < s->end) {
        unsigned char c = (unsigned char)*s->p++;
        if (c == '"') break;
        if (c == '\\') {
            if (s->p >= s->end) fail("bad escape");
            unsigned char e = (unsigned char)*s->p++;
            char rep = 0;
            switch (e) {
                case 'n': rep = '\n'; break;
                case 't': rep = '\t'; break;
                case 'r': rep = '\r'; break;
                case 'b': rep = '\b'; break;
                case 'f': rep = '\f'; break;
                case '/': rep = '/'; break;
                case '\\': rep = '\\'; break;
                case '"': rep = '"'; break;
                case 'u': {
                    /* decode \uXXXX (BMP only, encode as UTF-8) */
                    unsigned int cp = 0;
                    for (int k = 0; k < 4 && s->p < s->end; k++) {
                        unsigned char h = (unsigned char)*s->p++;
                        cp <<= 4;
                        if (h >= '0' && h <= '9') cp |= (unsigned)(h - '0');
                        else if (h >= 'a' && h <= 'f') cp |= (unsigned)(h - 'a' + 10);
                        else if (h >= 'A' && h <= 'F') cp |= (unsigned)(h - 'A' + 10);
                    }
                    char tmp[4]; int tn = 0;
                    if (cp < 0x80) { tmp[tn++] = (char)cp; }
                    else if (cp < 0x800) {
                        tmp[tn++] = (char)(0xC0 | (cp >> 6));
                        tmp[tn++] = (char)(0x80 | (cp & 0x3F));
                    } else {
                        tmp[tn++] = (char)(0xE0 | (cp >> 12));
                        tmp[tn++] = (char)(0x80 | ((cp >> 6) & 0x3F));
                        tmp[tn++] = (char)(0x80 | (cp & 0x3F));
                    }
                    while (len + (size_t)tn + 1 > cap) { cap *= 2; out = (char *)xrealloc(out, cap); }
                    for (int k = 0; k < tn; k++) out[len++] = tmp[k];
                    continue;
                }
                default: rep = (char)e; break;
            }
            if (len + 2 > cap) { cap *= 2; out = (char *)xrealloc(out, cap); }
            out[len++] = rep;
            continue;
        }
        if (len + 2 > cap) { cap *= 2; out = (char *)xrealloc(out, cap); }
        out[len++] = (char)c;
    }
    out[len] = '\0';
    return out;
}

/* Fast number scanner. Falls back to strtod for exotic forms. */
static double parse_number(P *s) {
    skipws(s);
    const char *q = s->p;
    int neg = 0;
    if (q < s->end && (*q == '-' || *q == '+')) { neg = (*q == '-'); q++; }
    long long ip = 0;
    int ndig = 0;
    while (q < s->end && *q >= '0' && *q <= '9') {
        if (ndig < 18) { ip = ip * 10 + (*q - '0'); ndig++; }
        else { ndig++; }
        q++;
    }
    if (ndig == 0) {
        /* could be nan/inf/null-ish; let strtod try */
        char *ep = NULL;
        double v = strtod(s->p, &ep);
        if (ep == s->p) fail("expected number");
        s->p = ep;
        return v;
    }
    if (ndig > 18) {
        char *ep = NULL;
        double v = strtod(s->p, &ep);
        s->p = ep;
        return v;
    }
    double val = (double)ip;
    int complex_tail = 0;
    if (q < s->end && *q == '.') {
        const char *r = q + 1;
        long long frac = 0; int fd = 0;
        while (r < s->end && *r >= '0' && *r <= '9') {
            if (fd < 18) { frac = frac * 10 + (*r - '0'); fd++; }
            else fd++;
            r++;
        }
        if (fd > 18) complex_tail = 1;
        else {
            static const double pw[19] = {1e0,1e1,1e2,1e3,1e4,1e5,1e6,1e7,1e8,1e9,
                                          1e10,1e11,1e12,1e13,1e14,1e15,1e16,1e17,1e18};
            val = val + (double)frac / pw[fd];
        }
        q = r;
    }
    if (q < s->end && (*q == 'e' || *q == 'E')) complex_tail = 1;
    if (complex_tail) {
        char *ep = NULL;
        double v = strtod(s->p, &ep);
        s->p = ep;
        return v;
    }
    s->p = q;
    return neg ? -val : val;
}

static void skip_value(P *s);

static void skip_array(P *s) {
    if (peek(s) != '[') fail("expected [");
    s->p++;
    if (peek(s) == ']') { s->p++; return; }
    for (;;) {
        skip_value(s);
        int c = peek(s);
        if (c == ',') { s->p++; continue; }
        if (c == ']') { s->p++; return; }
        fail("bad array");
    }
}

static void skip_object(P *s) {
    if (peek(s) != '{') fail("expected {");
    s->p++;
    if (peek(s) == '}') { s->p++; return; }
    for (;;) {
        char *k = parse_string(s);
        free(k);
        if (peek(s) != ':') fail("expected :");
        s->p++;
        skip_value(s);
        int c = peek(s);
        if (c == ',') { s->p++; continue; }
        if (c == '}') { s->p++; return; }
        fail("bad object");
    }
}

static void skip_value(P *s) {
    int c = peek(s);
    if (c == '{') { skip_object(s); return; }
    if (c == '[') { skip_array(s); return; }
    if (c == '"') { char *t = parse_string(s); free(t); return; }
    if (c == 't') { s->p += 4; return; }
    if (c == 'f') { s->p += 5; return; }
    if (c == 'n') { s->p += 4; return; }
    parse_number(s);
}

/* growable arrays for sparse triplets */
typedef struct {
    int *idx; double *val; size_t len, cap;
} SpBuf;

static void sp_push(SpBuf *b, int i, double v) {
    if (b->len == b->cap) {
        b->cap = b->cap ? b->cap * 2 : 1024;
        b->idx = (int *)xrealloc(b->idx, b->cap * sizeof(int));
        b->val = (double *)xrealloc(b->val, b->cap * sizeof(double));
    }
    b->idx[b->len] = i;
    b->val[b->len] = v;
    b->len++;
}

/* Parse an array of numbers, pushing nonzeros into buf. Returns element count. */
static int parse_coef_array(P *s, SpBuf *buf) {
    if (peek(s) != '[') fail("expected coefficient array");
    s->p++;
    int cnt = 0;
    if (peek(s) == ']') { s->p++; return 0; }
    for (;;) {
        double v = parse_number(s);
        if (v != 0.0) sp_push(buf, cnt, v);
        cnt++;
        int c = peek(s);
        if (c == ',') { s->p++; continue; }
        if (c == ']') { s->p++; break; }
        fail("bad coefficient array");
    }
    return cnt;
}

static char *read_all(const char *path, size_t *out_len) {
    FILE *f;
    if (path && strcmp(path, "-") != 0) {
        f = fopen(path, "rb");
        if (!f) { fprintf(stderr, "cannot open %s\n", path ? path : "(null)"); exit(2); }
    } else {
        f = stdin;
    }
    size_t cap = 1 << 20, len = 0;
    char *buf = (char *)xmalloc(cap);
    for (;;) {
        if (len + (1 << 16) + 1 > cap) { cap *= 2; buf = (char *)xrealloc(buf, cap); }
        size_t got = fread(buf + len, 1, 1 << 16, f);
        len += got;
        if (got == 0) break;
    }
    if (f != stdin) fclose(f);
    buf[len] = '\0';
    *out_len = len;
    return buf;
}

Model *parse_instance(const char *path) {
    size_t len = 0;
    char *text = read_all(path, &len);
    P sp;
    sp.p = text;
    sp.end = text + len;
    P *s = &sp;

    Model *M = (Model *)xcalloc(1, sizeof(Model));
    M->n = -1;
    M->maximize = 0;

    SpBuf objbuf;
    memset(&objbuf, 0, sizeof(objbuf));
    int objlen = -1;

    SpBuf rowbuf;
    memset(&rowbuf, 0, sizeof(rowbuf));
    size_t rcap = 64, rcount = 0;
    size_t *rowstart = (size_t *)xmalloc(rcap * sizeof(size_t));
    double *rrhs = (double *)xmalloc(rcap * sizeof(double));
    char *rsense = (char *)xmalloc(rcap);
    int *rlen = (int *)xmalloc(rcap * sizeof(int));

    if (peek(s) != '{') fail("top-level must be object");
    s->p++;
    if (peek(s) != '}') {
        for (;;) {
            char *key = parse_string(s);
            if (peek(s) != ':') fail("expected : after key");
            s->p++;
            if (strcmp(key, "instance_id") == 0) {
                M->instance_id = parse_string(s);
            } else if (strcmp(key, "family") == 0) {
                M->family = parse_string(s);
            } else if (strcmp(key, "comment") == 0) {
                if (peek(s) == '"') M->comment = parse_string(s);
                else skip_value(s);
            } else if (strcmp(key, "objective_sense") == 0) {
                char *v = parse_string(s);
                M->maximize = (strcmp(v, "max") == 0);
                free(v);
            } else if (strcmp(key, "n_vars") == 0) {
                M->n = (int)parse_number(s);
            } else if (strcmp(key, "objective_coefficients") == 0) {
                objlen = parse_coef_array(s, &objbuf);
            } else if (strcmp(key, "constraints") == 0) {
                if (peek(s) != '[') fail("constraints must be array");
                s->p++;
                if (peek(s) != ']') {
                    for (;;) {
                        if (peek(s) != '{') fail("constraint must be object");
                        s->p++;
                        if (rcount == rcap) {
                            rcap *= 2;
                            rowstart = (size_t *)xrealloc(rowstart, rcap * sizeof(size_t));
                            rrhs = (double *)xrealloc(rrhs, rcap * sizeof(double));
                            rsense = (char *)xrealloc(rsense, rcap);
                            rlen = (int *)xrealloc(rlen, rcap * sizeof(int));
                        }
                        rowstart[rcount] = rowbuf.len;
                        rrhs[rcount] = 0.0;
                        rsense[rcount] = SENSE_LE;
                        rlen[rcount] = -1;
                        if (peek(s) != '}') {
                            for (;;) {
                                char *ck = parse_string(s);
                                if (peek(s) != ':') fail("expected : in constraint");
                                s->p++;
                                if (strcmp(ck, "coefficients") == 0) {
                                    rlen[rcount] = parse_coef_array(s, &rowbuf);
                                } else if (strcmp(ck, "rhs") == 0) {
                                    rrhs[rcount] = parse_number(s);
                                } else if (strcmp(ck, "sense") == 0) {
                                    char *sv = parse_string(s);
                                    if (strcmp(sv, "<=") == 0) rsense[rcount] = SENSE_LE;
                                    else if (strcmp(sv, ">=") == 0) rsense[rcount] = SENSE_GE;
                                    else rsense[rcount] = SENSE_EQ;
                                    free(sv);
                                } else {
                                    skip_value(s);
                                }
                                free(ck);
                                int c2 = peek(s);
                                if (c2 == ',') { s->p++; continue; }
                                if (c2 == '}') { s->p++; break; }
                                fail("bad constraint object");
                            }
                        } else {
                            s->p++;
                        }
                        rcount++;
                        int c3 = peek(s);
                        if (c3 == ',') { s->p++; continue; }
                        if (c3 == ']') { s->p++; break; }
                        fail("bad constraints array");
                    }
                } else {
                    s->p++;
                }
            } else {
                skip_value(s);
            }
            free(key);
            int c = peek(s);
            if (c == ',') { s->p++; continue; }
            if (c == '}') { s->p++; break; }
            fail("bad top-level object");
        }
    } else {
        s->p++;
    }

    if (M->n < 0) M->n = objlen > 0 ? objlen : 0;
    if (M->instance_id == NULL) { M->instance_id = (char *)xmalloc(1); M->instance_id[0] = '\0'; }
    if (M->family == NULL) { M->family = (char *)xcalloc(1, 1); }

    int n = M->n;
    M->m = (int)rcount;
    M->obj = (double *)xcalloc((size_t)(n > 0 ? n : 1), sizeof(double));
    for (size_t k = 0; k < objbuf.len; k++) {
        int i = objbuf.idx[k];
        if (i >= 0 && i < n) M->obj[i] = objbuf.val[k];
    }
    free(objbuf.idx); free(objbuf.val);

    M->c = (double *)xmalloc((size_t)(n > 0 ? n : 1) * sizeof(double));
    for (int j = 0; j < n; j++) M->c[j] = M->maximize ? -M->obj[j] : M->obj[j];

    int m = M->m;
    M->rhs = (double *)xmalloc((size_t)(m > 0 ? m : 1) * sizeof(double));
    M->sense = (char *)xmalloc((size_t)(m > 0 ? m : 1));
    M->rs = (int *)xmalloc((size_t)(m + 1) * sizeof(int));
    M->rscale = (double *)xmalloc((size_t)(m > 0 ? m : 1) * sizeof(double));
    size_t total = rowbuf.len;
    M->ri = (int *)xmalloc((total ? total : 1) * sizeof(int));
    M->rv = (double *)xmalloc((total ? total : 1) * sizeof(double));

    int pos = 0;
    for (int r = 0; r < m; r++) {
        M->rs[r] = pos;
        M->rhs[r] = rrhs[r];
        M->sense[r] = rsense[r];
        size_t a = rowstart[r];
        size_t b = (r + 1 < m) ? rowstart[r + 1] : rowbuf.len;
        double sc = 0.0;
        for (size_t k = a; k < b; k++) {
            int idx = rowbuf.idx[k];
            if (idx < 0 || idx >= n) continue;
            M->ri[pos] = idx;
            M->rv[pos] = rowbuf.val[k];
            double av = fabs(rowbuf.val[k]);
            if (av > sc) sc = av;
            pos++;
        }
        if (sc <= 0.0) sc = 1.0;
        M->rscale[r] = sc;
    }
    M->rs[m] = pos;
    M->nnz = pos;
    free(rowbuf.idx); free(rowbuf.val);
    free(rowstart); free(rrhs); free(rsense); free(rlen);
    free(text);

    model_finalize(M);
    return M;
}

void model_finalize(Model *M) {
    int n = M->n, m = M->m;
    /* column-major */
    int *cnt = (int *)xcalloc((size_t)(n + 1), sizeof(int));
    for (int k = 0; k < M->nnz; k++) cnt[M->ri[k]]++;
    M->cs = (int *)xmalloc((size_t)(n + 1) * sizeof(int));
    int acc = 0;
    for (int j = 0; j < n; j++) { M->cs[j] = acc; acc += cnt[j]; }
    M->cs[n] = acc;
    M->ci = (int *)xmalloc((size_t)(M->nnz ? M->nnz : 1) * sizeof(int));
    M->cv = (double *)xmalloc((size_t)(M->nnz ? M->nnz : 1) * sizeof(double));
    int *fill = (int *)xmalloc((size_t)(n + 1) * sizeof(int));
    memcpy(fill, M->cs, (size_t)(n + 1) * sizeof(int));
    for (int r = 0; r < m; r++) {
        for (int k = M->rs[r]; k < M->rs[r + 1]; k++) {
            int j = M->ri[k];
            int p = fill[j]++;
            M->ci[p] = r;
            M->cv[p] = M->rv[k];
        }
    }
    free(fill);
    free(cnt);

    int cntobj = 0;
    for (int j = 0; j < n; j++) if (M->obj[j] != 0.0) cntobj++;
    M->objidx = (int *)xmalloc((size_t)(cntobj ? cntobj : 1) * sizeof(int));
    M->nobjidx = 0;
    for (int j = 0; j < n; j++) if (M->obj[j] != 0.0) M->objidx[M->nobjidx++] = j;
}
