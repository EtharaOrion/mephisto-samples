#!/bin/sh
# Build the from-scratch 0-1 IP solver. No external dependencies, C99 + libm.
set -e
here=$(cd "$(dirname "$0")" && pwd)
mkdir -p "$here/build"
CC=${CC:-cc}
if ! command -v "$CC" >/dev/null 2>&1; then
    for c in cc gcc clang tcc; do
        if command -v "$c" >/dev/null 2>&1; then CC=$c; break; fi
    done
fi
if command -v "$CC" >/dev/null 2>&1; then
    "$CC" -O2 -std=c99 -w -o "$here/build/p6zsolve" \
        "$here/src/parse.c" "$here/src/core.c" "$here/src/lag.c" \
        "$here/src/heur.c" "$here/src/special.c" "$here/src/main.c" -lm \
        || echo "warning: solver build failed; ./solve will fall back to python" >&2
else
    echo "warning: no C compiler found; ./solve will fall back to python" >&2
fi
exit 0
