/* bb.c - LP-based branch and bound, reduced-cost fixing and LP diving. */
#include "ip.h"
#include "lp.h"

typedef struct {
    Ctx *C;
    Model *M;
    LP *lp;
    double *lo, *up;
    double tend;
    long nodes;
    long nodelimit;
    int aborted;
    double gran;       /* objective granularity */
    int *order;        /* branching preference scratch */
    double *pcost_up, *pcost_dn;
    int *pcnt_up, *pcnt_dn;
} BB;

double obj_granularity(const Model *M) {
    double g = 0.0;
    for (int j = 0; j < M->n; j++) {
        double v = fabs(M->c[j]);
        if (v == 0.0) continue;
        if (g == 0.0) { g = v; continue; }
        double a = g, b = v;
        if (a < b) { double t = a; a = b; b = t; }
        int guard = 0;
        while (b > 1e-9 * (a + 1.0) && guard++ < 100) { double r = fmod(a, b); a = b; b = r; }
        g = a;
        if (g < 1e-7) return 0.0;
    }
    if (g <= 0.0) return 0.0;
    for (int j = 0; j < M->n; j++) {
        double q = M->c[j] / g;
        if (fabs(q - floor(q + 0.5)) > 1e-6) return 0.0;
    }
    return g;
}

/* --- try to convert an LP point into a feasible integer point --- */
static int try_round(BB *B, const double *xlp) {
    Model *M = B->M;
    int n = M->n;
    int *x = (int *)xmalloc((size_t)n * sizeof(int));
    for (int j = 0; j < n; j++) x[j] = (xlp[j] > 0.5) ? 1 : 0;
    int r = ctx_offer(B->C, x);
    free(x);
    return r;
}

/* --- LP diving heuristic: fix fractional variables one at a time --- */
static int lp_dive(BB *B, double tend) {
    Model *M = B->M;
    int n = M->n;
    double *slo = (double *)xmalloc((size_t)n * sizeof(double));
    double *sup = (double *)xmalloc((size_t)n * sizeof(double));
    for (int j = 0; j < n; j++) { slo[j] = B->lo[j]; sup[j] = B->up[j]; }
    LPResult R;
    int improved = 0;
    int rounds = 0;
    while (rounds++ < 4 * n + 50) {
        if (now_sec() > tend) break;
        if (lp_resolve(B->lp, tend, &R) != LP_OPTIMAL) break;
        int bj = -1;
        double bscore = -1.0;
        int bval = 0;
        for (int j = 0; j < n; j++) {
            if (slo[j] >= sup[j]) continue;
            double v = R.x[j];
            if (v < 1e-6 || v > 1.0 - 1e-6) continue;
            /* prefer the least fractional variable (fast dive) */
            double dist = fabs(v - 0.5);
            if (dist > bscore) { bscore = dist; bj = j; bval = (v > 0.5); }
        }
        if (bj < 0) {
            improved |= try_round(B, R.x);
            break;
        }
        slo[bj] = sup[bj] = (double)bval;
        lp_set_bounds(B->lp, bj, slo[bj], sup[bj]);
    }
    /* restore */
    for (int j = 0; j < n; j++) lp_set_bounds(B->lp, j, B->lo[j], B->up[j]);
    free(slo); free(sup);
    return improved;
}

/* --- reduced cost fixing at the root --- */
static int rc_fix(BB *B, double rootobj, const double *d) {
    if (!B->C->have) return 0;
    Model *M = B->M;
    double cutoff = B->C->bestint - (B->gran > 0 ? B->gran : 1e-9) + 1e-9;
    int nfix = 0;
    for (int j = 0; j < M->n; j++) {
        if (B->lo[j] >= B->up[j]) continue;
        double dj = d[j];
        double v = lp_var(B->lp, j);
        if (v < 1e-9 && dj > 1e-9) {
            if (rootobj + dj > cutoff) { B->up[j] = 0.0; lp_set_bounds(B->lp, j, 0.0, 0.0); nfix++; }
        } else if (v > 1.0 - 1e-9 && dj < -1e-9) {
            if (rootobj - dj > cutoff) { B->lo[j] = 1.0; lp_set_bounds(B->lp, j, 1.0, 1.0); nfix++; }
        }
    }
    return nfix;
}

/* --- depth-first branch and bound --- */
static int bb_node(BB *B, int depth) {
    if (B->aborted) return 0;
    if (++B->nodes > B->nodelimit) { B->aborted = 1; return 0; }
    if ((B->nodes & 15) == 0 && now_sec() > B->tend) { B->aborted = 1; return 0; }

    LPResult R;
    int st = lp_resolve(B->lp, B->tend, &R);
    if (st == LP_INFEASIBLE) return 1;
    if (st != LP_OPTIMAL) { B->aborted = 1; return 0; }

    double cutoff = B->C->have
        ? B->C->bestint - (B->gran > 0 ? B->gran : 0.0) + 1e-7
        : 1e300;
    if (R.obj > cutoff) return 1;

    Model *M = B->M;
    int n = M->n;
    int bj = -1;
    double bscore = -1.0;
    for (int j = 0; j < n; j++) {
        if (B->lo[j] >= B->up[j]) continue;
        double v = R.x[j];
        if (v < 1e-7 || v > 1.0 - 1e-7) continue;
        double frac = v < 0.5 ? v : 1.0 - v;
        double sc = frac * (1.0 + fabs(M->c[j]));
        if (sc > bscore) { bscore = sc; bj = j; }
    }
    if (bj < 0) {
        /* integral */
        int *x = (int *)xmalloc((size_t)n * sizeof(int));
        for (int j = 0; j < n; j++) x[j] = (R.x[j] > 0.5) ? 1 : 0;
        ctx_offer(B->C, x);
        free(x);
        return 1;
    }

    double v = R.x[bj];
    int first = (v > 0.5) ? 1 : 0;
    double olo = B->lo[bj], oup = B->up[bj];
    for (int t = 0; t < 2; t++) {
        int val = t == 0 ? first : 1 - first;
        B->lo[bj] = B->up[bj] = (double)val;
        lp_set_bounds(B->lp, bj, (double)val, (double)val);
        int r = bb_node(B, depth + 1);
        B->lo[bj] = olo; B->up[bj] = oup;
        lp_set_bounds(B->lp, bj, olo, oup);
        if (!r) return 0;
    }
    return 1;
}

/* returns 1 if the search completed (optimality proved) */
int bb_run(Ctx *C, double tend, long nodelimit, LagInfo *out, int do_dive) {
    Model *M = C->M;
    LP *lp = lp_create(M);
    if (!lp) return 0;
    BB B;
    memset(&B, 0, sizeof(B));
    B.C = C; B.M = M; B.lp = lp;
    B.tend = tend;
    B.nodelimit = nodelimit;
    B.gran = obj_granularity(M);
    B.lo = (double *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(double));
    B.up = (double *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(double));
    for (int j = 0; j < M->n; j++) { B.lo[j] = 0.0; B.up[j] = 1.0; }

    LPResult R;
    int st = lp_solve(lp, B.lo, B.up, tend, &R);
    if (st != LP_OPTIMAL) {
        lp_free(lp); free(B.lo); free(B.up);
        return 0;
    }
    if (out) {
        if (!out->xbar) out->xbar = (double *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(double));
        if (!out->rc) out->rc = (double *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(double));
        for (int j = 0; j < M->n; j++) { out->xbar[j] = R.x[j]; out->rc[j] = R.d[j]; }
        out->lb = R.obj;
        out->valid = 1;
    }
    try_round(&B, R.x);
    if (do_dive) lp_dive(&B, tend);

    int done = 0;
    if (nodelimit > 0) {
        rc_fix(&B, R.obj, R.d);
        done = bb_node(&B, 0);
        done = done && !B.aborted;
    }
    lp_free(lp);
    free(B.lo); free(B.up);
    return done;
}
