/* ip.h - shared declarations for the from-scratch 0-1 IP solver. */
#ifndef IP_H
#define IP_H

#ifndef _DEFAULT_SOURCE
#define _DEFAULT_SOURCE 1
#endif
#ifndef _POSIX_C_SOURCE
#define _POSIX_C_SOURCE 200809L
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define SENSE_LE 'L'
#define SENSE_GE 'G'
#define SENSE_EQ 'E'

/* Judge-side feasibility tolerance (absolute, matches p6zeta_lib). */
#define FEAS_TOL 1e-9

typedef struct {
    char *instance_id;
    char *family;
    char *comment;
    int n;              /* number of binary variables */
    int m;              /* number of rows */
    int maximize;       /* 1 if objective_sense == "max" */
    double *obj;        /* original objective coefficients, length n */
    double *c;          /* internal minimisation objective (obj or -obj) */

    /* row-major sparse (indices sorted ascending inside each row).
       rv/rhs are row-normalised (max |a_rj| == 1) so that every algorithm is
       invariant under a common rescaling of the input; orig_rv/orig_rhs keep
       the untouched numbers used for the judge-exact feasibility test. */
    int *rs;            /* length m+1 */
    int *ri;            /* nnz */
    double *rv;         /* nnz */
    double *rhs;        /* length m */
    double *orig_rv;    /* nnz */
    double *orig_rhs;   /* length m */
    char *sense;        /* length m */
    double *rscale;     /* per-row normalising scale, 1.0 after normalisation */
    double cscale;      /* objective normaliser: c = +-obj / cscale */

    /* column-major sparse */
    int *cs;            /* length n+1 */
    int *ci;            /* nnz */
    double *cv;         /* nnz */

    int nnz;

    /* objective support (indices with obj != 0, ascending) */
    int *objidx;
    int nobjidx;
} Model;

typedef struct {
    Model *M;
    int *best;          /* best feasible assignment (length n), valid if have */
    double bestobj;     /* objective in ORIGINAL sense at best */
    double bestint;     /* internal minimisation value at best */
    int have;
    double t0;
    double tlimit;
    int ntokens;
    double last_emitted;
    double last_emit_time;
    int emitted_any;
    double tlast_improve;   /* time (s) of the most recent incumbent improvement */
    int nimprove;
    int proved;             /* 1 if optimality was proved by a bound argument */
    double tproved;
    long bbnodes;
} Ctx;

/* ---- util ---- */
double now_sec(void);
void *xmalloc(size_t sz);
void *xcalloc(size_t nmemb, size_t sz);
void *xrealloc(void *p, size_t sz);

/* ---- parse.c ---- */
Model *parse_instance(const char *path);
void model_finalize(Model *M);

/* ---- core.c ---- */
double eval_obj_exact(const Model *M, const int *x);
double eval_int_obj(const Model *M, const int *x);
int check_feasible_exact(const Model *M, const int *x, double *worst);
void ctx_init(Ctx *C, Model *M, double tlimit);
/* returns 1 if the candidate was accepted as a new incumbent */
int ctx_offer(Ctx *C, const int *x);
void ctx_emit_final(Ctx *C);
double ctx_elapsed(const Ctx *C);
int ctx_out_of_time(const Ctx *C);

/* ---- rng ---- */
typedef struct { unsigned long long s; } Rng;
void rng_seed(Rng *r, unsigned long long seed);
unsigned int rng_next(Rng *r);
int rng_int(Rng *r, int n);
double rng_double(Rng *r);

/* ---- lag.c ---- */
typedef struct {
    double *lam;        /* row multipliers, length m */
    double *xbar;       /* fractional primal estimate in [0,1], length n */
    double *rc;         /* reduced costs (internal min sense) */
    double lb;          /* best lagrangian lower bound on internal min objective */
    int valid;
} LagInfo;
void lagrangian_run(Ctx *C, LagInfo *L, double budget);
void lag_free(LagInfo *L);

/* ---- heur.c ---- */
void heur_run(Ctx *C, LagInfo *L);
void heur_quick(Ctx *C);

/* ---- bb.c ---- */
typedef struct Solver Solver;
Solver *solver_create(Ctx *C);
void solver_free(Solver *S);
int solver_root(Solver *S, double tend, LagInfo *out);
double solver_root_obj(Solver *S);
void solver_dive(Solver *S, double tend);
void solver_dive_restarts(Solver *S, double tend, int maxrounds);
int solver_rcfix(Solver *S);
int solver_bb(Solver *S, double tend, long nodelimit);
int solver_rins(Solver *S, double tend, long nodelimit, double frac_extra);
long solver_nodes(Solver *S);
double obj_granularity(const Model *M);

/* ---- special.c ---- */
int special_run(Ctx *C, LagInfo *L);

#endif
