/* bb.c - LP-driven search: root relaxation, diving, RINS and branch & bound. */
#include "ip.h"
#include "lp.h"

struct Solver {
    Ctx *C;
    Model *M;
    LP *lp;
    double *lo, *up;      /* bounds of the *current* search root */
    double *slo, *sup;    /* scratch for sub-searches */
    double tend;
    long nodes;
    long nodelimit;
    int aborted;
    double gran;
    double rootobj;
    int rootok;
    double *rootx;
    double *rootd;
    Rng rng;
    int *xbuf;
    long dive_every;
    long next_dive;
};

double obj_granularity(const Model *M) {
    double g = 0.0;
    for (int j = 0; j < M->n; j++) {
        double v = fabs(M->c[j]);
        if (v == 0.0) continue;
        if (g == 0.0) { g = v; continue; }
        double a = g, b = v;
        if (a < b) { double t = a; a = b; b = t; }
        int guard = 0;
        while (b > 1e-9 * (a + 1.0) && guard++ < 100) { double r = fmod(a, b); a = b; b = r; }
        g = a;
        if (g < 1e-7) return 0.0;
    }
    if (g <= 0.0) return 0.0;
    for (int j = 0; j < M->n; j++) {
        double q = M->c[j] / g;
        if (fabs(q - floor(q + 0.5)) > 1e-6) return 0.0;
    }
    return g;
}

Solver *solver_create(Ctx *C) {
    Model *M = C->M;
    LP *lp = lp_create(M);
    if (!lp) return NULL;
    Solver *S = (Solver *)xcalloc(1, sizeof(Solver));
    S->C = C; S->M = M; S->lp = lp;
    S->gran = obj_granularity(M);
    int n = M->n ? M->n : 1;
    S->lo = (double *)xcalloc((size_t)n, sizeof(double));
    S->up = (double *)xcalloc((size_t)n, sizeof(double));
    S->slo = (double *)xcalloc((size_t)n, sizeof(double));
    S->sup = (double *)xcalloc((size_t)n, sizeof(double));
    S->rootx = (double *)xcalloc((size_t)n, sizeof(double));
    S->rootd = (double *)xcalloc((size_t)n, sizeof(double));
    S->xbuf = (int *)xcalloc((size_t)n, sizeof(int));
    for (int j = 0; j < M->n; j++) { S->lo[j] = 0.0; S->up[j] = 1.0; }
    rng_seed(&S->rng, 0xC0FFEEULL);
    S->rootok = 0;
    return S;
}

void solver_free(Solver *S) {
    if (!S) return;
    lp_free(S->lp);
    free(S->lo); free(S->up); free(S->slo); free(S->sup);
    free(S->rootx); free(S->rootd); free(S->xbuf);
    free(S);
}

static double cutoff_of(Solver *S) {
    if (!S->C->have) return 1e300;
    return S->C->bestint - (S->gran > 0 ? S->gran : 0.0) + 1e-7;
}

static int offer_lp_point(Solver *S, const double *xlp) {
    Model *M = S->M;
    for (int j = 0; j < M->n; j++) S->xbuf[j] = (xlp[j] > 0.5) ? 1 : 0;
    return ctx_offer(S->C, S->xbuf);
}

/* Solve the LP under bounds slo/sup (already applied); dive on fractionals. */
static int dive_from_here(Solver *S, double tend, int randomize) {
    Model *M = S->M;
    int n = M->n;
    LPResult R;
    int improved = 0;
    int rounds = 0;
    for (int j = 0; j < n; j++) { S->slo[j] = S->lo[j]; S->sup[j] = S->up[j]; }
    while (rounds++ < 2 * n + 60) {
        if (now_sec() > tend) break;
        if (lp_resolve(S->lp, tend, &R) != LP_OPTIMAL) break;
        if (S->C->have && R.obj > cutoff_of(S)) break;
        int bj = -1;
        double bscore = -1.0;
        int bval = 0;
        for (int j = 0; j < n; j++) {
            if (S->slo[j] >= S->sup[j]) continue;
            double v = R.x[j];
            if (v < 1e-6 || v > 1.0 - 1e-6) continue;
            double dist = fabs(v - 0.5);
            if (randomize) dist += 0.15 * rng_double(&S->rng);
            if (dist > bscore) { bscore = dist; bj = j; bval = (v > 0.5); }
        }
        if (bj < 0) { improved |= offer_lp_point(S, R.x); break; }
        S->slo[bj] = S->sup[bj] = (double)bval;
        lp_set_bounds(S->lp, bj, S->slo[bj], S->sup[bj]);
    }
    for (int j = 0; j < n; j++) lp_set_bounds(S->lp, j, S->lo[j], S->up[j]);
    return improved;
}

int solver_root(Solver *S, double tend, LagInfo *out) {
    Model *M = S->M;
    LPResult R;
    int st = lp_solve(S->lp, S->lo, S->up, tend, &R);
    if (st != LP_OPTIMAL) return 0;
    S->rootobj = R.obj;
    S->rootok = 1;
    for (int j = 0; j < M->n; j++) { S->rootx[j] = R.x[j]; S->rootd[j] = R.d[j]; }
    if (out) {
        if (!out->xbar) out->xbar = (double *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(double));
        if (!out->rc) out->rc = (double *)xcalloc((size_t)(M->n ? M->n : 1), sizeof(double));
        for (int j = 0; j < M->n; j++) { out->xbar[j] = R.x[j]; out->rc[j] = R.d[j]; }
        out->lb = R.obj;
        out->valid = 1;
    }
    offer_lp_point(S, R.x);
    return 1;
}

double solver_root_obj(Solver *S) { return S->rootok ? S->rootobj : -INFINITY; }

void solver_dive(Solver *S, double tend) { dive_from_here(S, tend, 0); }

long solver_nodes(Solver *S) { return S ? S->nodes : 0; }

/* reduced-cost fixing against the current incumbent */
int solver_rcfix(Solver *S) {
    if (!S->C->have || !S->rootok) return 0;
    Model *M = S->M;
    double cut = cutoff_of(S);
    int nfix = 0;
    for (int j = 0; j < M->n; j++) {
        if (S->lo[j] >= S->up[j]) continue;
        double dj = S->rootd[j];
        double v = S->rootx[j];
        if (v < 1e-9 && dj > 1e-9 && S->rootobj + dj > cut) {
            S->up[j] = 0.0; lp_set_bounds(S->lp, j, 0.0, 0.0); nfix++;
        } else if (v > 1.0 - 1e-9 && dj < -1e-9 && S->rootobj - dj > cut) {
            S->lo[j] = 1.0; lp_set_bounds(S->lp, j, 1.0, 1.0); nfix++;
        }
    }
    return nfix;
}

/* ---------------- branch and bound ---------------- */

static int bb_node(Solver *S, int depth) {
    if (S->aborted) return 0;
    if (++S->nodes > S->nodelimit) { S->aborted = 1; return 0; }
    if ((S->nodes & 15) == 0 && now_sec() > S->tend) { S->aborted = 1; return 0; }

    LPResult R;
    int st = lp_resolve(S->lp, S->tend, &R);
    if (st == LP_INFEASIBLE) return 1;
    if (st != LP_OPTIMAL) { S->aborted = 1; return 0; }
    if (R.obj > cutoff_of(S)) return 1;

    Model *M = S->M;
    int n = M->n;
    int bj = -1;
    double bscore = -1.0;
    for (int j = 0; j < n; j++) {
        if (S->lo[j] >= S->up[j]) continue;
        double v = R.x[j];
        if (v < 1e-7 || v > 1.0 - 1e-7) continue;
        double frac = v < 0.5 ? v : 1.0 - v;
        double sc = frac * (1.0 + fabs(M->c[j]));
        if (sc > bscore) { bscore = sc; bj = j; }
    }
    if (bj < 0) { offer_lp_point(S, R.x); return 1; }

    double v = R.x[bj];
    int first = (v > 0.5) ? 1 : 0;
    double olo = S->lo[bj], oup = S->up[bj];
    for (int t = 0; t < 2; t++) {
        int val = t == 0 ? first : 1 - first;
        S->lo[bj] = S->up[bj] = (double)val;
        lp_set_bounds(S->lp, bj, (double)val, (double)val);
        int r = bb_node(S, depth + 1);
        S->lo[bj] = olo; S->up[bj] = oup;
        lp_set_bounds(S->lp, bj, olo, oup);
        if (!r) return 0;
    }
    return 1;
}

/* Full branch and bound from the current bounds.  Returns 1 when the search
   completed, i.e. the incumbent is proved optimal for those bounds. */
int solver_bb(Solver *S, double tend, long nodelimit) {
    S->tend = tend;
    S->nodelimit = S->nodes + nodelimit;
    S->aborted = 0;
    int done = bb_node(S, 0);
    return done && !S->aborted;
}

/* RINS: fix the variables on which the root LP and the incumbent agree,
   then run a node-limited branch & bound over the rest. */
int solver_rins(Solver *S, double tend, long nodelimit, double frac_extra) {
    if (!S->C->have || !S->rootok) return 0;
    Model *M = S->M;
    int n = M->n;
    double *keeplo = (double *)xmalloc((size_t)(n ? n : 1) * sizeof(double));
    double *keepup = (double *)xmalloc((size_t)(n ? n : 1) * sizeof(double));
    memcpy(keeplo, S->lo, (size_t)n * sizeof(double));
    memcpy(keepup, S->up, (size_t)n * sizeof(double));
    int nfixed = 0;
    for (int j = 0; j < n; j++) {
        if (S->lo[j] >= S->up[j]) { nfixed++; continue; }
        double v = S->rootx[j];
        int inc = S->C->best[j];
        int agree = (v < 1e-6 && inc == 0) || (v > 1.0 - 1e-6 && inc == 1);
        if (agree && rng_double(&S->rng) > frac_extra) {
            S->lo[j] = S->up[j] = (double)inc;
            lp_set_bounds(S->lp, j, (double)inc, (double)inc);
            nfixed++;
        }
    }
    int res = 0;
    if (nfixed < n) {
        S->tend = tend;
        S->nodelimit = S->nodes + nodelimit;
        S->aborted = 0;
        res = bb_node(S, 0) && !S->aborted;
    }
    for (int j = 0; j < n; j++) {
        S->lo[j] = keeplo[j]; S->up[j] = keepup[j];
        lp_set_bounds(S->lp, j, S->lo[j], S->up[j]);
    }
    free(keeplo); free(keepup);
    return res;
}

/* Randomised dive restarts: a cheap, LP-quality primal heuristic. */
void solver_dive_restarts(Solver *S, double tend, int maxrounds) {
    for (int i = 0; i < maxrounds; i++) {
        if (now_sec() > tend) break;
        dive_from_here(S, tend, i > 0);
    }
}
