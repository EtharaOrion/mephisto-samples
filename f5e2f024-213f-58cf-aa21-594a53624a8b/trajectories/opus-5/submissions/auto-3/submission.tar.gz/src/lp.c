/* lp.c - bounded-variable dual simplex on a dense tableau.
 *
 * Solves the continuous relaxation
 *     min c'x   s.t.  lo_j <= x_j <= up_j,  row senses as given
 * by introducing one slack per row (A_r x + s_r = b_r) with
 *     '<=' : s_r in [0, +inf)
 *     '>=' : s_r in (-inf, 0]
 *     '==' : s_r = 0
 * The all-slack basis is dual feasible once every structural variable sits at
 * the bound its objective coefficient prefers, so no phase 1 is required.
 */
#include "ip.h"
#include "lp.h"

#define LP_INF 1e30
#define PIV_TOL 1e-8
#define FEAS_EPS 1e-7
#define DUAL_EPS 1e-8

struct LP {
    Model *M;
    int m, n, N;      /* rows, structural cols, total cols */
    double *T;        /* m x N tableau */
    double *xb;       /* basic values */
    int *basis;       /* row -> variable */
    int *inbas;       /* variable -> row or -1 */
    signed char *atup;/* nonbasic: 1 if resting at upper bound */
    double *lo, *up;  /* bounds per variable */
    double *cost;     /* objective per variable */
    double *d;        /* reduced costs */
    double *b;        /* rhs */
    double *xval;     /* value of every variable (structural + slack) */
    long iters;
    int ok;
};

static inline double *Trow(LP *L, int i) { return L->T + (size_t)i * (size_t)L->N; }

LP *lp_create(Model *M) {
    int m = M->m, n = M->n;
    double cells = (double)m * (double)(n + m);
    if (cells > 6.0e7 || m == 0) return NULL;
    LP *L = (LP *)xcalloc(1, sizeof(LP));
    L->M = M;
    L->m = m; L->n = n; L->N = n + m;
    L->T = (double *)calloc((size_t)m * (size_t)L->N, sizeof(double));
    if (!L->T) { free(L); return NULL; }
    L->xb = (double *)xcalloc((size_t)m, sizeof(double));
    L->basis = (int *)xcalloc((size_t)m, sizeof(int));
    L->inbas = (int *)xmalloc((size_t)L->N * sizeof(int));
    L->atup = (signed char *)xcalloc((size_t)L->N, 1);
    L->lo = (double *)xcalloc((size_t)L->N, sizeof(double));
    L->up = (double *)xcalloc((size_t)L->N, sizeof(double));
    L->cost = (double *)xcalloc((size_t)L->N, sizeof(double));
    L->d = (double *)xcalloc((size_t)L->N, sizeof(double));
    L->b = (double *)xcalloc((size_t)m, sizeof(double));
    L->xval = (double *)xcalloc((size_t)L->N, sizeof(double));
    for (int j = 0; j < n; j++) { L->lo[j] = 0.0; L->up[j] = 1.0; L->cost[j] = M->c[j]; }
    for (int r = 0; r < m; r++) {
        int s = n + r;
        L->b[r] = M->rhs[r];
        if (M->sense[r] == SENSE_LE) { L->lo[s] = 0.0; L->up[s] = LP_INF; }
        else if (M->sense[r] == SENSE_GE) { L->lo[s] = -LP_INF; L->up[s] = 0.0; }
        else { L->lo[s] = 0.0; L->up[s] = 0.0; }
        L->cost[s] = 0.0;
    }
    return L;
}

void lp_free(LP *L) {
    if (!L) return;
    free(L->T); free(L->xb); free(L->basis); free(L->inbas); free(L->atup);
    free(L->lo); free(L->up); free(L->cost); free(L->d); free(L->b); free(L->xval);
    free(L);
}

/* (re)build the tableau from scratch with the all-slack basis */
static void lp_reset(LP *L, const double *lo, const double *up) {
    Model *M = L->M;
    int m = L->m, n = L->n, N = L->N;
    memset(L->T, 0, (size_t)m * (size_t)N * sizeof(double));
    for (int r = 0; r < m; r++) {
        double *tr = Trow(L, r);
        for (int k = M->rs[r]; k < M->rs[r + 1]; k++) tr[M->ri[k]] = M->rv[k];
        tr[n + r] = 1.0;
    }
    if (lo) for (int j = 0; j < n; j++) L->lo[j] = lo[j];
    if (up) for (int j = 0; j < n; j++) L->up[j] = up[j];
    for (int j = 0; j < N; j++) L->inbas[j] = -1;
    for (int r = 0; r < m; r++) { L->basis[r] = n + r; L->inbas[n + r] = r; }
    for (int j = 0; j < n; j++) {
        if (L->cost[j] >= 0.0) { L->atup[j] = 0; L->xval[j] = L->lo[j]; }
        else { L->atup[j] = 1; L->xval[j] = L->up[j]; }
        if (L->lo[j] > L->up[j]) { L->xval[j] = L->lo[j]; }
    }
    for (int j = 0; j < N; j++) L->d[j] = L->cost[j];
    for (int r = 0; r < m; r++) {
        double s = L->b[r];
        for (int k = M->rs[r]; k < M->rs[r + 1]; k++) {
            int j = M->ri[k];
            if (L->xval[j] != 0.0) s -= M->rv[k] * L->xval[j];
        }
        L->xb[r] = s;
        L->xval[n + r] = s;
    }
}

/* recompute basic values from the current basis (T slack block == B^-1) */
static void lp_refresh(LP *L) {
    Model *M = L->M;
    int m = L->m, n = L->n;
    double *rhsN = (double *)xmalloc((size_t)m * sizeof(double));
    for (int r = 0; r < m; r++) rhsN[r] = L->b[r];
    for (int j = 0; j < n; j++) {
        if (L->inbas[j] >= 0) continue;
        double v = L->atup[j] ? L->up[j] : L->lo[j];
        L->xval[j] = v;
        if (v == 0.0) continue;
        for (int k = M->cs[j]; k < M->cs[j + 1]; k++) rhsN[M->ci[k]] -= M->cv[k] * v;
    }
    for (int r = 0; r < m; r++) {
        int s = n + r;
        if (L->inbas[s] >= 0) continue;
        double v = L->atup[s] ? L->up[s] : L->lo[s];
        if (v >= LP_INF || v <= -LP_INF) v = 0.0;
        L->xval[s] = v;
        if (v != 0.0) rhsN[r] -= v;
    }
    for (int i = 0; i < m; i++) {
        double *tr = Trow(L, i);
        double s = 0.0;
        for (int r = 0; r < m; r++) {
            double a = tr[n + r];
            if (a != 0.0) s += a * rhsN[r];
        }
        L->xb[i] = s;
        L->xval[L->basis[i]] = s;
    }
    /* refresh reduced costs from scratch: y = c_B B^-1, d = c - y'A */
    double *y = rhsN;
    for (int r = 0; r < m; r++) y[r] = 0.0;
    for (int i = 0; i < m; i++) {
        double cb = L->cost[L->basis[i]];
        if (cb == 0.0) continue;
        double *tr = Trow(L, i);
        for (int r = 0; r < m; r++) {
            double a = tr[n + r];
            if (a != 0.0) y[r] += cb * a;
        }
    }
    for (int j = 0; j < n; j++) {
        double d = L->cost[j];
        for (int k = M->cs[j]; k < M->cs[j + 1]; k++) d -= y[M->ci[k]] * M->cv[k];
        L->d[j] = d;
    }
    for (int r = 0; r < m; r++) L->d[n + r] = -y[r];
    for (int i = 0; i < m; i++) L->d[L->basis[i]] = 0.0;
    free(rhsN);
}

/* one dual simplex solve; returns LP_OPTIMAL / LP_INFEASIBLE / LP_ITERLIMIT */
static int lp_dual_simplex(LP *L, double tend, long itlimit) {
    int m = L->m, N = L->N;
    long it = 0;
    int refresh_ctr = 0;
    int bland = 0;
    int verified = 0;
    while (1) {
        if (++it > itlimit) return LP_ITERLIMIT;
        if ((it & 63) == 0 && now_sec() > tend) return LP_ITERLIMIT;
        if (++refresh_ctr >= 500) { refresh_ctr = 0; lp_refresh(L); }

        /* --- leaving variable: largest bound violation --- */
        int li = -1;
        double bestv = FEAS_EPS;
        int leave_to_upper = 0;
        for (int i = 0; i < m; i++) {
            int v = L->basis[i];
            double x = L->xb[i];
            double lb = L->lo[v], ub = L->up[v];
            double sc = 1.0 + fabs(x);
            if (x < lb - FEAS_EPS * sc) {
                double viol = (lb - x) / sc;
                if (viol > bestv) { bestv = viol; li = i; leave_to_upper = 0; }
            } else if (x > ub + FEAS_EPS * sc) {
                double viol = (x - ub) / sc;
                if (viol > bestv) { bestv = viol; li = i; leave_to_upper = 1; }
            }
        }
        if (li < 0) {
            if (!verified) { verified = 1; lp_refresh(L); continue; }
            return LP_OPTIMAL;
        }
        verified = 0;

        double *tr = Trow(L, li);
        int lv = L->basis[li];
        double target = leave_to_upper ? L->up[lv] : L->lo[lv];
        /* direction: xb must decrease (leave_to_upper) or increase */
        int want_dec = leave_to_upper;

        int q = -1;
        double bestratio = 1e300;
        double bestpiv = 0.0;
        for (int j = 0; j < N; j++) {
            if (L->inbas[j] >= 0) continue;
            if (L->lo[j] >= L->up[j]) continue;    /* fixed variable */
            double a = tr[j];
            if (fabs(a) < PIV_TOL) continue;
            int atu = L->atup[j];
            int eligible;
            if (want_dec) eligible = atu ? (a < 0.0) : (a > 0.0);
            else eligible = atu ? (a > 0.0) : (a < 0.0);
            if (!eligible) continue;
            double ratio = fabs(L->d[j]) / fabs(a);
            if (bland) {
                q = j; bestpiv = a; break;
            }
            if (ratio < bestratio - 1e-12 ||
                (ratio < bestratio + 1e-12 && fabs(a) > fabs(bestpiv))) {
                bestratio = ratio; q = j; bestpiv = a;
            }
        }
        if (q < 0) return LP_INFEASIBLE;

        /* --- pivot --- */
        double piv = tr[q];
        double t = (L->xb[li] - target) / piv;
        double qval = (L->atup[q] ? L->up[q] : L->lo[q]) + t;

        /* update basic values */
        for (int i = 0; i < m; i++) {
            if (i == li) continue;
            double a = Trow(L, i)[q];
            if (a != 0.0) L->xb[i] -= a * t;
        }
        L->xb[li] = qval;
        L->xval[q] = qval;
        L->xval[lv] = target;
        L->atup[lv] = leave_to_upper ? 1 : 0;
        L->inbas[lv] = -1;
        L->inbas[q] = li;
        L->basis[li] = q;

        /* tableau update */
        double inv = 1.0 / piv;
        for (int j = 0; j < N; j++) tr[j] *= inv;
        tr[q] = 1.0;
        for (int i = 0; i < m; i++) {
            if (i == li) continue;
            double *ti = Trow(L, i);
            double f = ti[q];
            if (f == 0.0) continue;
            for (int j = 0; j < N; j++) ti[j] -= f * tr[j];
            ti[q] = 0.0;
        }
        /* reduced cost update */
        double dq = L->d[q];
        if (dq != 0.0) {
            for (int j = 0; j < N; j++) L->d[j] -= dq * tr[j];
        }
        L->d[q] = 0.0;
        L->iters++;
        if (it > 20L * (m + N) && !bland) bland = 1;
    }
}

int lp_solve(LP *L, const double *lo, const double *up, double tend, LPResult *R) {
    lp_reset(L, lo, up);
    long itlimit = 40L * (long)(L->m + L->N) + 4000L;
    int st = lp_dual_simplex(L, tend, itlimit);
    R->status = st;
    R->obj = 0.0;
    if (st == LP_OPTIMAL) {
        lp_refresh(L);
        double o = 0.0;
        for (int j = 0; j < L->n; j++) o += L->cost[j] * L->xval[j];
        R->obj = o;
    }
    R->x = L->xval;
    R->d = L->d;
    R->iters = L->iters;
    return st;
}

int lp_resolve(LP *L, double tend, LPResult *R) {
    long itlimit = 20L * (long)(L->m + L->N) + 2000L;
    int st = lp_dual_simplex(L, tend, itlimit);
    R->status = st;
    R->obj = 0.0;
    if (st == LP_OPTIMAL) {
        lp_refresh(L);
        double o = 0.0;
        for (int j = 0; j < L->n; j++) o += L->cost[j] * L->xval[j];
        R->obj = o;
    }
    R->x = L->xval;
    R->d = L->d;
    R->iters = L->iters;
    return st;
}

/* Change the bounds of one structural variable while keeping the basis.
 * A nonbasic variable is parked on the bound its reduced cost prefers, which
 * keeps the basis dual feasible even when bounds are *relaxed* (as happens on
 * branch-and-bound backtracking); primal feasibility is then restored by the
 * next dual simplex call. */
void lp_set_bounds(LP *L, int j, double lo, double up) {
    L->lo[j] = lo;
    L->up[j] = up;
    if (L->inbas[j] < 0) {
        int atu;
        if (lo >= up) atu = 0;
        else atu = (L->d[j] < -DUAL_EPS) ? 1 : 0;
        L->atup[j] = (signed char)atu;
        double v = atu ? up : lo;
        double old = L->xval[j];
        if (v != old) {
            double delta = v - old;
            for (int i = 0; i < L->m; i++) {
                double a = Trow(L, i)[j];
                if (a != 0.0) L->xb[i] -= a * delta;
            }
            L->xval[j] = v;
        }
    }
}

void lp_get_bounds(LP *L, int j, double *lo, double *up) { *lo = L->lo[j]; *up = L->up[j]; }

double lp_var(LP *L, int j) { return L->xval[j]; }
double lp_rc(LP *L, int j) { return L->d[j]; }
int lp_nstruct(LP *L) { return L->n; }
