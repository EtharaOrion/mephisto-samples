#define P6Z_NO_OUTPUT 1
/* core.c - exact evaluation, incumbent bookkeeping, progression tokens, rng. */
#include "ip.h"

/* Mirror the judge's summation: sum(c_i * x_i) over indices in ascending order.
   Terms with x_i == 0 contribute exactly 0.0 and never perturb the accumulator,
   so iterating the sparse support in ascending index order is bit-identical. */
double eval_obj_exact(const Model *M, const int *x) {
    double s = 0.0;
    const int *oi = M->objidx;
    int k = M->nobjidx;
    for (int t = 0; t < k; t++) {
        int j = oi[t];
        if (x[j]) s += M->obj[j];
    }
    return s;
}

double eval_int_obj(const Model *M, const int *x) {
    double s = 0.0;
    for (int j = 0; j < M->n; j++) if (x[j]) s += M->c[j];
    return s;
}

int check_feasible_exact(const Model *M, const int *x, double *worst) {
    double w = 0.0;
    int ok = 1;
    for (int r = 0; r < M->m; r++) {
        double s = 0.0;
        int e = M->rs[r + 1];
        for (int k = M->rs[r]; k < e; k++) {
            if (x[M->ri[k]]) s += M->orig_rv[k];
        }
        double b = M->orig_rhs[r];
        double v = 0.0;
        char sn = M->sense[r];
        if (sn == SENSE_LE) { if (s > b + FEAS_TOL) v = s - b; }
        else if (sn == SENSE_GE) { if (s < b - FEAS_TOL) v = b - s; }
        else { if (fabs(s - b) > FEAS_TOL) v = fabs(s - b); }
        if (v > 0.0) { ok = 0; if (v > w) w = v; }
    }
    if (worst) *worst = w;
    return ok;
}

void ctx_init(Ctx *C, Model *M, double tlimit) {
    C->M = M;
    C->best = (int *)xcalloc((size_t)(M->n > 0 ? M->n : 1), sizeof(int));
    C->bestobj = 0.0;
    C->bestint = 0.0;
    C->have = 0;
    C->t0 = now_sec();
    C->tlimit = tlimit;
    C->ntokens = 0;
    C->last_emitted = 0.0;
    C->last_emit_time = -1e9;
    C->emitted_any = 0;
    C->tlast_improve = 0.0;
    C->nimprove = 0;
    C->proved = 0;
    C->tproved = 0.0;
    C->bbnodes = 0;
    C->infeasible = 0;
}

double ctx_elapsed(const Ctx *C) { return now_sec() - C->t0; }
int ctx_out_of_time(const Ctx *C) { return (now_sec() - C->t0) >= C->tlimit; }

/* Progression tokens are rate limited: the judge may read stderr only after
   the process exits, so the total volume is kept well under a pipe buffer. */
#define TOKEN_CAP 400
#define TOKEN_MIN_GAP 0.02

static void emit_token(Ctx *C, double obj) {
#ifdef P6Z_NO_OUTPUT
    (void)obj; return;
#endif
    double ts = ctx_elapsed(C);
    if (ts < 0.0) ts = 0.0;
    fprintf(stderr, "BEST ts=%.4f obj=%.6f\n", ts, obj);
    fflush(stderr);
    C->ntokens++;
    C->last_emitted = obj;
    C->last_emit_time = ts;
    C->emitted_any = 1;
}

int ctx_offer(Ctx *C, const int *x) {
    Model *M = C->M;
    double intobj = eval_int_obj(M, x);
    if (C->have && intobj >= C->bestint - 1e-12) return 0;
    double worst = 0.0;
    if (!check_feasible_exact(M, x, &worst)) return 0;
    double o = eval_obj_exact(M, x);
    C->bestint = intobj;
    C->bestobj = o;
    C->have = 1;
    memcpy(C->best, x, (size_t)M->n * sizeof(int));
    C->nimprove++;
    C->tlast_improve = ctx_elapsed(C);
    guard_publish(C->best, o);
    double ts = C->tlast_improve;
    if (C->ntokens < 2 || (C->ntokens < TOKEN_CAP && ts - C->last_emit_time >= TOKEN_MIN_GAP))
        emit_token(C, o);
    return 1;
}

void ctx_emit_final(Ctx *C) {
    if (!C->have) return;
    if (C->ntokens < 2 || C->last_emitted != C->bestobj) emit_token(C, C->bestobj);
    if (C->ntokens < 2) emit_token(C, C->bestobj);
}

/* ---- xorshift rng ---- */
void rng_seed(Rng *r, unsigned long long seed) {
    r->s = seed ? seed : 0x9E3779B97F4A7C15ULL;
}
unsigned int rng_next(Rng *r) {
    unsigned long long x = r->s;
    x ^= x << 13;
    x ^= x >> 7;
    x ^= x << 17;
    r->s = x;
    return (unsigned int)(x >> 32);
}
int rng_int(Rng *r, int n) {
    if (n <= 1) return 0;
    return (int)(rng_next(r) % (unsigned int)n);
}
double rng_double(Rng *r) {
    return (double)(rng_next(r) & 0xFFFFFF) / (double)0x1000000;
}
