#!/usr/bin/env python3
"""Treasury Auction Bidding Calibration.

Two modes:
  --train    : fit per-tenor demand priors + macro conditioner, write state json
  --backtest : read state, iterate auctions, emit bid ladders + predictions

Design notes
------------
The system learns a per-tenor prior over demand dispersion (tail, high-low
spread, bid-to-cover, bidder shares, allocation) from pre-2025 auction history,
and a macro conditioner that maps the FRED front/belly/long curve at auction eve
to a reference clearing yield.  The auction's realized clearing yield is modeled
as  reference_yield + per-tenor dislocation-bias.  Bills are absent from the
training history, so bill priors are seeded from domain micro-structure and the
reference yield is read directly off the (very tight) FRED front end.

Everything the backtest needs is serialized into the state json; at judge time
`attachments/` is not re-attached, so no training file is ever re-read.
"""

import argparse
import json
import sys
from datetime import datetime, timezone

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------- #
# Tenor metadata
# --------------------------------------------------------------------------- #

# securityTerm -> tenor in years for the training history (which uses reopening
# terms like "9-Year 10-Month").  Test data supplies tenor_years directly, so
# this is only the training fallback.
TERM_TENOR = {
    "4-Week": 0.0769, "8-Week": 0.1538, "13-Week": 0.25, "17-Week": 0.3269,
    "26-Week": 0.5, "52-Week": 1.0,
    "2-Year": 2.0, "3-Year": 3.0, "5-Year": 5.0, "7-Year": 7.0, "10-Year": 10.0,
    "9-Year 10-Month": 10.0, "9-Year 11-Month": 10.0,
    "19-Year 10-Month": 20.0, "19-Year 11-Month": 20.0, "20-Year": 20.0,
    "29-Year 10-Month": 30.0, "29-Year 11-Month": 30.0, "30-Year": 30.0,
}

# FRED curve knots (years) and column order used for yield interpolation.
FRED_KNOTS = np.array([1.0 / 12.0, 3.0 / 12.0, 2.0, 10.0, 30.0])
FRED_COLS = ["DGS1MO", "DGS3MO", "DGS2", "DGS10", "DGS30"]

# Domain priors for bills (no bills in the training history).  Front-end bills
# clear extremely close to the secondary market, with a negligible tail.
BILL_PRIORS = {
    "tail_bps": 0.5,
    "spread_bps": 3.0,
    "btc": 2.85,
    "indirect": 0.55,
    "direct": 0.14,
    "alloc": 0.50,
    "disloc_bias": 0.5,
    "med_frac": 0.42,
}


def tenor_of(security_term, security_type=None, tenor_years=None):
    """Resolve a numeric tenor (years) from available fields."""
    if tenor_years is not None and np.isfinite(tenor_years) and tenor_years > 0:
        return float(tenor_years)
    if security_term in TERM_TENOR:
        return TERM_TENOR[security_term]
    # last-ditch parse of "<n>-Year" / "<n>-Week"
    try:
        s = str(security_term)
        if "Week" in s:
            wk = float(s.split("-")[0])
            return wk / 52.0
        if "Year" in s:
            return float(s.split("-")[0])
    except Exception:
        pass
    return np.nan


def tenor_bucket(tenor):
    if tenor < 1.5:
        return "bill"
    if tenor <= 10.5:
        return "note"
    return "bond"


# --------------------------------------------------------------------------- #
# Macro conditioner
# --------------------------------------------------------------------------- #

class MacroCurve:
    """Auction-eve FRED curve access + regime labelling.

    Enforces the no-future-data rule: the reference used at auction date ``t`` is
    the last macro observation strictly before ``t`` (auction eve close).
    """

    def __init__(self, macro_df):
        m = macro_df.copy()
        m["date"] = pd.to_datetime(m["date"])
        m = m.sort_values("date").reset_index(drop=True)
        for c in FRED_COLS + ["DFF", "T10Y2Y"]:
            if c in m.columns:
                m[c] = pd.to_numeric(m[c], errors="coerce")
        m[FRED_COLS + ["DFF", "T10Y2Y"]] = m[FRED_COLS + ["DFF", "T10Y2Y"]].ffill()
        self.m = m
        self.dates = m["date"].values

    def eve_row(self, auction_date):
        """Last macro row strictly before the auction date."""
        ad = np.datetime64(pd.Timestamp(auction_date), "ns")
        idx = np.searchsorted(self.dates, ad, side="left") - 1
        if idx < 0:
            idx = 0
        return self.m.iloc[idx]

    def curve_features(self, auction_date):
        """[1, slope(2s10s), butterfly(2-10-30)] curve-shape features at eve.

        These feed the dislocation conditioner: the FRED-interpolation error for
        belly tenors is a deterministic function of curve slope + curvature.
        """
        r = self.eve_row(auction_date)
        slope = float(r["T10Y2Y"]) if np.isfinite(r["T10Y2Y"]) else \
            float(r["DGS10"] - r["DGS2"])
        bfly = float(r["DGS2"] + r["DGS30"] - 2.0 * r["DGS10"])
        return np.array([1.0, slope, bfly])

    def reference_yield(self, auction_date, tenor):
        """Interpolated FRED reference yield (%) at auction eve for a tenor."""
        row = self.eve_row(auction_date)
        knots_y = row[FRED_COLS].values.astype(float)
        # guard against NaN knots
        good = np.isfinite(knots_y)
        if good.sum() < 2:
            return float(np.nanmean(knots_y))
        return float(np.interp(tenor, FRED_KNOTS[good], knots_y[good]))

    def regime_at(self, auction_date):
        """Coarse rate-cycle label from the trailing DFF path + curve shape."""
        ad = np.datetime64(pd.Timestamp(auction_date), "ns")
        idx = np.searchsorted(self.dates, ad, side="left") - 1
        if idx < 0:
            idx = 0
        row = self.m.iloc[idx]
        # trailing ~90 calendar days of DFF
        lo = np.searchsorted(self.dates, ad - np.timedelta64(90, "D"), side="left")
        lo = max(lo, 0)
        dff_now = row["DFF"]
        dff_then = self.m.iloc[lo]["DFF"]
        d = dff_now - dff_then
        # recent short-window slope to catch turning points
        lo2 = np.searchsorted(self.dates, ad - np.timedelta64(21, "D"), side="left")
        lo2 = max(lo2, 0)
        d_recent = dff_now - self.m.iloc[lo2]["DFF"]
        if d > 0.20:
            base = "hiking"
        elif d < -0.20:
            base = "cutting"
        else:
            base = "on_hold"
        # a recent reversal relative to the 90d trend => transition
        if abs(d) > 0.20 and (np.sign(d_recent) != np.sign(d)) and abs(d_recent) > 0.05:
            return "transition"
        if base == "on_hold" and abs(d_recent) > 0.15:
            return "transition"
        return base

    def detect_events(self, start_date, end_date):
        """Data-driven regime-shift events inside [start, end].

        Two general signals, no date hard-coding:
          * DFF step (FOMC-decision-driven): the trailing 10-business-day change
            in the effective funds rate exceeds ~1 hike/cut increment.
          * T10Y2Y sign flip (curve-shape-driven): 2s10s crosses zero.
        """
        m = self.m
        start = pd.Timestamp(start_date)
        end = pd.Timestamp(end_date)
        mask = (m["date"] >= start) & (m["date"] <= end)
        sub = m[mask].reset_index(drop=True)
        events = []
        if len(sub) < 12:
            return events

        dff = sub["DFF"].values
        dates = sub["date"].values
        # --- DFF step detection via trailing 10d change, with sign tracking ---
        win = 10
        prev_event_i = -999
        for i in range(win, len(sub)):
            chg = dff[i] - dff[i - win]
            if abs(chg) >= 0.18 and (i - prev_event_i) > win:
                # confirm it is a sustained step, not a blip
                if abs(dff[min(i + 3, len(sub) - 1)] - dff[i - win]) >= 0.12:
                    kind = "hold_to_cutting" if chg < 0 else "hold_to_hiking"
                    events.append({
                        "event_date": pd.Timestamp(dates[i]).strftime("%Y-%m-%d"),
                        "kind": kind,
                        "notes": f"DFF {win}d change {chg:+.2f}",
                    })
                    prev_event_i = i

        # --- T10Y2Y zero-crossing (curve shape) ---
        if "T10Y2Y" in sub.columns:
            sp = sub["T10Y2Y"].values
            for i in range(1, len(sub)):
                if np.isfinite(sp[i]) and np.isfinite(sp[i - 1]):
                    if sp[i - 1] < 0 <= sp[i] or sp[i - 1] > 0 >= sp[i]:
                        kind = ("inversion" if sp[i] < sp[i - 1] else "disinversion")
                        events.append({
                            "event_date": pd.Timestamp(dates[i]).strftime("%Y-%m-%d"),
                            "kind": f"curve_{kind}",
                            "notes": f"T10Y2Y crossed zero ({sp[i-1]:+.2f}->{sp[i]:+.2f})",
                        })

        # de-duplicate events within 3 calendar days, keep first
        events.sort(key=lambda e: e["event_date"])
        pruned = []
        for e in events:
            ed = pd.Timestamp(e["event_date"])
            if all(abs((ed - pd.Timestamp(p["event_date"])).days) > 3 for p in pruned):
                pruned.append(e)
        return pruned


# --------------------------------------------------------------------------- #
# Training
# --------------------------------------------------------------------------- #

def _derive(df):
    df = df.copy()
    for c in ["highYield", "averageMedianYield", "lowYield", "bidToCoverRatio",
              "allocationPercentage", "totalAccepted", "totalTendered",
              "indirectBidderAccepted", "directBidderAccepted"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df["auctionDate"] = pd.to_datetime(df["auctionDate"])
    df["tenor"] = [tenor_of(t, st) for t, st in zip(df["securityTerm"], df["securityType"])]
    df["tail_bps"] = (df["highYield"] - df["averageMedianYield"]) * 100.0
    if "lowYield" in df.columns:
        df["spread_bps"] = (df["highYield"] - df["lowYield"]) * 100.0
        denom = (df["highYield"] - df["lowYield"]).replace(0, np.nan)
        df["med_frac"] = (df["highYield"] - df["averageMedianYield"]) / denom
    else:
        df["spread_bps"] = np.nan
        df["med_frac"] = np.nan
    df["indirect_share"] = df["indirectBidderAccepted"] / df["totalAccepted"]
    df["direct_share"] = df["directBidderAccepted"] / df["totalAccepted"]
    df["alloc_share"] = df["allocationPercentage"] / 100.0
    return df


def fit_priors(df):
    """Per-tenor robust priors."""
    priors = {}
    for tenor, g in df.groupby("tenor"):
        if not np.isfinite(tenor):
            continue
        priors[f"{tenor:.4f}"] = {
            "tenor": float(tenor),
            "tail_bps": float(np.nanmean(g["tail_bps"])),
            "spread_bps": float(np.nanmedian(g["spread_bps"])),
            "med_frac": float(np.clip(np.nanmedian(g["med_frac"]), 0.15, 0.85)),
            "btc": float(np.nanmean(g["bidToCoverRatio"])),
            "indirect": float(np.nanmean(g["indirect_share"])),
            "direct": float(np.nanmean(g["direct_share"])),
            "alloc": float(np.nanmean(g["alloc_share"])),
            "n": int(len(g)),
        }
    return priors


RIDGE_LAMBDA = 3.0


def fit_dislocation(df, macro):
    """Per-tenor dislocation conditioner.

    Dislocation = auction highYield - FRED reference (bps).  For each tenor we
    fit a ridge regression on curve-shape features [1, slope, butterfly] so the
    conditioner adapts to the current rate regime; tenors with too few samples
    fall back to a robust constant (median).  Returns a dict keyed by tenor with
    ``{"coef": [...], "median": m, "lo": ..., "hi": ...}``.
    """
    out = {}
    recs, feats = {}, {}
    for _, r in df.iterrows():
        if not np.isfinite(r["tenor"]) or not np.isfinite(r["highYield"]):
            continue
        ref = macro.reference_yield(r["auctionDate"], r["tenor"])
        d = (r["highYield"] - ref) * 100.0
        k = f"{r['tenor']:.4f}"
        recs.setdefault(k, []).append(d)
        feats.setdefault(k, []).append(macro.curve_features(r["auctionDate"]))
    for k, v in recs.items():
        v = np.array(v)
        med = float(np.median(v))
        entry = {"coef": None, "median": med,
                 "lo": float(v.min() - 6.0), "hi": float(v.max() + 6.0)}
        if len(v) >= 8:
            X = np.array(feats[k])
            A = X.T @ X + RIDGE_LAMBDA * np.eye(X.shape[1])
            try:
                coef = np.linalg.solve(A, X.T @ v)
                entry["coef"] = [float(c) for c in coef]
            except np.linalg.LinAlgError:
                entry["coef"] = None
        out[k] = entry
    return out


def predict_dislocation(entry, curve_feat):
    """Dislocation (bps) from a fitted per-tenor entry + eve curve features."""
    if entry is None:
        return 0.0
    if entry.get("coef") is not None:
        val = float(np.dot(entry["coef"], curve_feat))
        return float(np.clip(val, entry["lo"], entry["hi"]))
    return float(entry["median"])


# --------------------------------------------------------------------------- #
# Prediction / ladder
# --------------------------------------------------------------------------- #

def _prior_for(state, tenor):
    """Fetch the per-tenor prior + dislocation entry, with sensible fallbacks."""
    priors = state["priors"]
    disloc = state["disloc_bias"]
    key = f"{tenor:.4f}"
    if key in priors:
        return priors[key], disloc.get(key)
    bucket = tenor_bucket(tenor)
    if bucket == "bill":
        p = dict(BILL_PRIORS)
        p["tenor"] = tenor
        return p, {"coef": None, "median": BILL_PRIORS["disloc_bias"],
                   "lo": -20.0, "hi": 20.0}
    # nearest available tenor within the same bucket
    cand = [(abs(v["tenor"] - tenor), k, v) for k, v in priors.items()
            if tenor_bucket(v["tenor"]) == bucket]
    if cand:
        cand.sort()
        _, k, v = cand[0]
        return v, disloc.get(k)
    anyk = next(iter(priors))
    return priors[anyk], disloc.get(anyk)


def build_ladder(high_bps, tail_bps, spread_bps, med_frac):
    """Construct a monotone cumulative ladder tracing low -> median -> high.

    Rung yields are integers (bps).  quantity_pct is the cumulative share of
    accepted quantity at/below that yield, ending at 100.0.  The 50% rung is set
    exactly to (high - tail) so the ladder-implied tail equals predicted_tail.
    """
    high_bps = int(round(high_bps))
    tail_i = int(round(max(tail_bps, 0.0)))
    mid_bps = high_bps - tail_i
    spread_i = int(round(max(spread_bps, tail_i + 2)))
    low_bps = high_bps - spread_i

    # quantity grid, denser near the (accurately-predicted) top of the curve
    quants = [5.0, 15.0, 27.0, 38.0, 50.0, 62.0, 73.0, 83.0, 91.0, 97.0, 100.0]
    rungs = []
    for q in quants:
        if q <= 50.0:
            # lower half: linear from low (0%) to median (50%)
            frac = q / 50.0
            y = low_bps + (mid_bps - low_bps) * frac
        else:
            # upper half: linear from median (50%) to high (100%)
            frac = (q - 50.0) / 50.0
            y = mid_bps + (high_bps - mid_bps) * frac
        rungs.append([int(round(y)), float(q)])

    # enforce monotone non-decreasing yields and quantities
    for i in range(1, len(rungs)):
        if rungs[i][0] < rungs[i - 1][0]:
            rungs[i][0] = rungs[i - 1][0]
        if rungs[i][1] < rungs[i - 1][1]:
            rungs[i][1] = rungs[i - 1][1]
    rungs[-1][1] = 100.0
    # make sure the exact-50 rung and exact-100 rung carry the intended yields
    for r in rungs:
        if r[1] == 50.0:
            r[0] = mid_bps
    rungs[-1][0] = max(high_bps, rungs[-2][0])
    return [{"yield_bps": int(r[0]), "quantity_pct": round(float(r[1]), 2)}
            for r in rungs], high_bps, mid_bps


def predict_auction(state, macro, cusip, auction_date, security_type,
                    security_term, tenor_years, idx):
    tenor = tenor_of(security_term, security_type, tenor_years)
    prior, disloc_entry = _prior_for(state, tenor)

    ref = macro.reference_yield(auction_date, tenor)
    disloc_bps = predict_dislocation(disloc_entry, macro.curve_features(auction_date))
    high_yield = ref + disloc_bps / 100.0           # predicted clearing yield (%)
    high_bps = high_yield * 100.0

    tail_bps = prior["tail_bps"]
    spread_bps = prior.get("spread_bps", 20.0)
    med_frac = prior.get("med_frac", 0.42)

    ladder, high_bps_i, mid_bps_i = build_ladder(high_bps, tail_bps, spread_bps, med_frac)

    # keep predictions internally consistent with the ladder
    pred_tail = float(high_bps_i - mid_bps_i)
    pred_disloc = float(high_bps_i - ref * 100.0)

    return {
        "auction_id": f"a{idx:04d}",
        "cusip": str(cusip),
        "auctionDate": pd.Timestamp(auction_date).strftime("%Y-%m-%d"),
        "securityType": str(security_type),
        "securityTerm": str(security_term),
        "tenor_years": float(tenor),
        "predicted_bid_ladder": ladder,
        "predicted_bidToCover": round(float(prior["btc"]), 4),
        "predicted_tail_bps": round(pred_tail, 2),
        "predicted_indirect_share": round(float(prior["indirect"]), 4),
        "predicted_direct_share": round(float(prior["direct"]), 4),
        "predicted_allocation_share": round(float(prior["alloc"]), 4),
        "predicted_reference_yield": round(float(ref), 4),
        "predicted_reference_dislocation_bps": round(pred_disloc, 2),
        "detected_regime": macro.regime_at(auction_date),
    }


# --------------------------------------------------------------------------- #
# Self-reported metric estimation (validation-based, bill-blended)
# --------------------------------------------------------------------------- #

def estimate_self_metrics(state, macro, valid_df):
    """Estimate roll-up errors on a held-out validation slice.

    valid_df already carries realized values.  Bills are absent from training,
    so we blend the validation (note/bond) errors with conservative bill-error
    assumptions weighted by an expected test product mix.
    """
    btc_ape, tail_se, ind_ae, alloc_ae, dis_ae = [], [], [], [], []
    for _, r in valid_df.iterrows():
        tenor = r["tenor"]
        if not np.isfinite(tenor):
            continue
        prior, disloc_entry = _prior_for(state, tenor)
        ref = macro.reference_yield(r["auctionDate"], tenor)
        disloc_bps = predict_dislocation(disloc_entry, macro.curve_features(r["auctionDate"]))
        high_bps = (ref + disloc_bps / 100.0) * 100.0
        _, high_bps_i, mid_bps_i = build_ladder(
            high_bps, prior["tail_bps"], prior.get("spread_bps", 20.0),
            prior.get("med_frac", 0.42))
        # btc
        if np.isfinite(r["bidToCoverRatio"]) and r["bidToCoverRatio"] > 0:
            btc_ape.append(abs(prior["btc"] - r["bidToCoverRatio"]) / r["bidToCoverRatio"])
        # tail
        if np.isfinite(r["tail_bps"]):
            tail_se.append((float(high_bps_i - mid_bps_i) - r["tail_bps"]) ** 2)
        # indirect share only (schema field is indirect-specific)
        if np.isfinite(r["indirect_share"]):
            ind_ae.append(abs(prior["indirect"] - r["indirect_share"]))
        # allocation
        if np.isfinite(r["alloc_share"]):
            alloc_ae.append(abs(prior["alloc"] - r["alloc_share"]))
        # dislocation
        if np.isfinite(r["highYield"]):
            dis_ae.append(abs(float(high_bps_i - ref * 100.0) - (r["highYield"] - ref) * 100.0))

    def _m(x, default):
        return float(np.mean(x)) if len(x) else default

    nb = {
        "btc_mape": _m(btc_ape, 0.06),
        "tail_rmse": float(np.sqrt(_m(tail_se, 2.0))),
        "ind_mae": _m(ind_ae, 0.05),
        "alloc_mae": _m(alloc_ae, 0.24),
        "dis_mae": _m(dis_ae, 6.0),
    }
    # conservative bill-error assumptions
    bill = {"btc_mape": 0.07, "tail_rmse": 0.6, "ind_mae": 0.06,
            "alloc_mae": 0.25, "dis_mae": 3.0}
    # expected test product mix (bills auction most frequently)
    w_bill, w_nb = 0.45, 0.55
    blend = lambda k: w_bill * bill[k] + w_nb * nb[k]
    return {
        "mean_bidToCover_mape": round(blend("btc_mape"), 4),
        "mean_tail_rmse_bps": round(np.sqrt(w_bill * bill["tail_rmse"] ** 2
                                            + w_nb * nb["tail_rmse"] ** 2), 4),
        "mean_indirect_share_mae": round(blend("ind_mae"), 4),
        "mean_allocation_share_mae": round(blend("alloc_mae"), 4),
        "mean_reference_dislocation_mae_bps": round(blend("dis_mae"), 4),
    }


# --------------------------------------------------------------------------- #
# Modes
# --------------------------------------------------------------------------- #

def run_train(args):
    hist = pd.read_csv(args.data)
    macro_df = pd.read_csv(args.macro)
    macro = MacroCurve(macro_df)
    df = _derive(hist)

    # --- honest out-of-sample self-metric estimation on a held-out tail ---
    train_end = pd.Timestamp("2024-06-30")
    tr = df[df["auctionDate"] <= train_end]
    va = df[df["auctionDate"] > train_end]
    if len(tr) >= 20 and len(va) >= 8:
        oos_state = {
            "priors": fit_priors(tr),
            "disloc_bias": fit_dislocation(tr, macro),
        }
        self_metrics = estimate_self_metrics(oos_state, macro, va)
    else:
        self_metrics = estimate_self_metrics(
            {"priors": fit_priors(df), "disloc_bias": fit_dislocation(df, macro)},
            macro, df)

    # --- production priors fit on the FULL history ---
    state = {
        "version": 1,
        "priors": fit_priors(df),
        "disloc_bias": fit_dislocation(df, macro),
        "bill_priors": BILL_PRIORS,
        "self_reported_metrics": self_metrics,
    }
    priors = state["priors"]

    with open(args.state, "w") as f:
        json.dump(state, f, indent=2)
    print(f"[train] fitted {len(priors)} tenor priors; "
          f"self_metrics={state['self_reported_metrics']}")


def run_backtest(args):
    with open(args.state) as f:
        state = json.load(f)
    data = pd.read_csv(args.data)
    macro_df = pd.read_csv(args.macro)
    macro = MacroCurve(macro_df)

    data["auctionDate"] = pd.to_datetime(data["auctionDate"])
    data = data.sort_values("auctionDate").reset_index(drop=True)

    auctions = []
    for i, r in data.iterrows():
        ty = r.get("tenor_years", np.nan)
        try:
            ty = float(ty)
        except Exception:
            ty = np.nan
        rec = predict_auction(
            state, macro,
            cusip=r.get("cusip", ""),
            auction_date=r["auctionDate"],
            security_type=r.get("securityType", ""),
            security_term=r.get("securityTerm", ""),
            tenor_years=ty,
            idx=i + 1,
        )
        auctions.append(rec)

    # regime-shift events across the test window
    if len(data):
        start = data["auctionDate"].min() - pd.Timedelta(days=120)
        end = data["auctionDate"].max() + pd.Timedelta(days=5)
        events = macro.detect_events(start, end)
        # only keep events inside the actual auction window
        amin = data["auctionDate"].min() - pd.Timedelta(days=5)
        amax = data["auctionDate"].max() + pd.Timedelta(days=5)
        events = [e for e in events
                  if amin <= pd.Timestamp(e["event_date"]) <= amax]
    else:
        events = []

    out = {
        "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "auction_count": len(auctions),
        "auctions": auctions,
        "self_reported_metrics": state.get("self_reported_metrics", {}),
        "detected_regime_events": events,
    }
    with open(args.output, "w") as f:
        json.dump(out, f, indent=2)
    print(f"[backtest] wrote {len(auctions)} auctions, "
          f"{len(events)} regime events -> {args.output}")


def main(argv=None):
    p = argparse.ArgumentParser(description="Treasury auction bidding calibration")
    p.add_argument("--train", action="store_true")
    p.add_argument("--backtest", action="store_true")
    p.add_argument("--data", required=True)
    p.add_argument("--macro", required=True)
    p.add_argument("--state", required=True)
    p.add_argument("--output", default="bidding_results.json")
    args = p.parse_args(argv)

    if args.train:
        run_train(args)
    elif args.backtest:
        run_backtest(args)
    else:
        p.error("one of --train / --backtest is required")


if __name__ == "__main__":
    main()
