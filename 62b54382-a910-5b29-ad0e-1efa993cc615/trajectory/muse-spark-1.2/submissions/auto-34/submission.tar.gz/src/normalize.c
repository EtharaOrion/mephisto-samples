#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include "normalize.h"
#include <regex.h>

static int is_word_char(unsigned char c){ return isalnum(c) || c=='_'; }
static void repl_wordbound_regex(char *buf, size_t sz, const char *pat, const char *repl){
 regex_t re;
 if(regcomp(&re, pat, REG_EXTENDED)) return;
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; } i++; continue; }
  regmatch_t m; int rc=regexec(&re, buf+i, 1, &m, 0);
  if(rc==0 && m.rm_so==0){
   size_t j=i+m.rm_eo;
   int after_ok = (j>=n || !is_word_char((unsigned char)buf[j]));
   if(after_ok){
    size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=j; continue;
   }
  }
  if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; } i++;
 }
 regfree(&re);
 strncpy(buf, out, sz-1); buf[sz-1]=0;
}
static void repl_mac(char *buf,size_t sz){ repl_wordbound_regex(buf,sz,"([0-9a-fA-F]{1,2}:){5}[0-9a-fA-F]{1,2}","ETHERHOST"); }
static void repl_hex(char *buf,size_t sz){ repl_wordbound_regex(buf,sz,"0x[0-9a-fA-F]+","HEX"); }
static void repl_ipv4(char *buf,size_t sz){ repl_wordbound_regex(buf,sz,"[0-9]+\\.[0-9]+\\.[0-9]+\\.[0-9]+(/[0-9]+)?","IPV4"); }
static void repl_ipv6_a(char *buf,size_t sz){ repl_wordbound_regex(buf,sz,"[0-9a-fA-F:]*::[0-9a-fA-F:]+","IPV6"); }
static void repl_ipv6_b(char *buf,size_t sz){ repl_wordbound_regex(buf,sz,"([0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F:]*","IPV6"); }
static void repl_num(char *buf,size_t sz){ repl_wordbound_regex(buf,sz,"[0-9]+","NUM"); }
static void repl_hex_inner(char *inner,size_t sz){ repl_wordbound_regex(inner,sz,"0x[0-9a-fA-F]+","HEX"); repl_wordbound_regex(inner,sz,"[0-9]+","NUM"); }
static void repl_brack(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(buf[i]=='['){
   char *close=strchr(buf+i+1,']');
   if(close){ size_t j=close-buf; char inner[4096]; size_t ilen=j-(i+1); if(ilen>=sizeof(inner)) ilen=sizeof(inner)-1; memcpy(inner, buf+i+1, ilen); inner[ilen]=0; repl_hex_inner(inner,sizeof(inner)); if(out_len+1 < sizeof(out)){ out[out_len++]='['; out[out_len]=0; } size_t rl=strlen(inner); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, inner); out_len+=rl; } if(out_len+1 < sizeof(out)){ out[out_len++]=']'; out[out_len]=0; } i=j+1; continue; }
  }
  if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]=0; } i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_host_net(char *buf,size_t sz){
 const char *kwlist[]={"host","net","gateway",NULL};
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  int matched=0;
  for(int k=0;kwlist[k];k++){
   const char *kw=kwlist[k]; size_t kl=strlen(kw);
   if(strncmp(buf+i,kw,kl)==0 && (i+kl>=n || !is_word_char((unsigned char)buf[i+kl]))){
    size_t j=i+kl; size_t kk=j; while(kk<n && (buf[kk]==' '||buf[kk]=='\t')) kk++;
    if(kk>=n){ size_t rl=kl; if(out_len+rl < sizeof(out)){ strncpy(out+out_len, kw, rl); out_len+=rl; out[out_len]=0; } i=j; matched=1; break; }
    size_t l=kk; while(l<n && buf[l]!=' '&&buf[l]!='\t'&&buf[l]!='\n'&&buf[l]!='\r') l++;
    char tok[256]; size_t tlen=l-kk; if(tlen>=sizeof(tok)) tlen=sizeof(tok)-1; memcpy(tok, buf+kk, tlen); tok[tlen]=0;
    const char *repl; char tmp[256];
    if(strcmp(tok,"IPV4")==0||strcmp(tok,"IPV6")==0||strcmp(tok,"NUM")==0||strcmp(tok,"HEX")==0||strcmp(tok,"ETHERHOST")==0){ snprintf(tmp,sizeof(tmp),"%s %s",kw,tok); repl=tmp; } else { snprintf(tmp,sizeof(tmp),"%s HOST",kw); repl=tmp; }
    size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=l; matched=1; break;
   }
  }
  if(matched) continue;
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_ether_host(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"ether",5)==0 && (i+5>=n || !is_word_char((unsigned char)buf[i+5]))){
   size_t j=i+5; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
   const char *subs[]={"host","src","dst",NULL}; int found=0;
   for(int s=0; subs[s]; s++){
    const char *sub=subs[s]; size_t sl=strlen(sub);
    if(strncmp(buf+k, sub, sl)==0 && (k+sl>=n || !is_word_char((unsigned char)buf[k+sl]))){
     size_t l=k+sl; size_t m=l; while(m<n && (buf[m]==' '||buf[m]=='\t')) m++;
     if(m>=n){ size_t rl=l-i; if(out_len+rl < sizeof(out)){ strncpy(out+out_len, buf+i, rl); out_len+=rl; out[out_len]=0; } i=l; found=1; break; }
     size_t p=m; while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++;
     char tok[256]; size_t tlen=p-m; if(tlen>=sizeof(tok)) tlen=sizeof(tok)-1; memcpy(tok, buf+m, tlen); tok[tlen]=0;
     const char *repl; char tmp[256];
     if(strcmp(tok,"IPV4")==0||strcmp(tok,"NUM")==0||strcmp(tok,"HEX")==0||strcmp(tok,"ETHERHOST")==0||strcmp(tok,"IPV6")==0){ snprintf(tmp,sizeof(tmp),"ether %s %s",sub,tok); repl=tmp; } else { snprintf(tmp,sizeof(tmp),"ether %s HOST",sub); repl=tmp; }
     size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=p; found=1; break;
    }
   }
   if(found) continue;
  }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_port(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"port",4)==0 && (i+4>=n || !is_word_char((unsigned char)buf[i+4]))){
   if(i+9<=n && strncmp(buf+i,"portrange",9)==0 && (i+9>=n || !is_word_char((unsigned char)buf[i+9]))){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
   size_t j=i+4; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
   if(k>=n){ size_t rl=4; if(out_len+rl < sizeof(out)){ strncpy(out+out_len, "port", rl); out_len+=rl; out[out_len]=0; } i=j; continue; }
   size_t l=k; while(l<n && buf[l]!=' '&&buf[l]!='\t'&&buf[l]!='\n'&&buf[l]!='\r') l++;
   const char *repl="port PORT"; size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=l; continue;
  }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_portrange(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"portrange",9)==0 && (i+9>=n || !is_word_char((unsigned char)buf[i+9]))){
   size_t j=i+9; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
   if(k<n){ size_t l=k; while(l<n && buf[l]!=' '&&buf[l]!='\t'&&buf[l]!='\n'&&buf[l]!='\r') l++; const char *repl="portrange RANGE"; size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=l; continue; }
  }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_ether_proto(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"ether",5)==0 && (i+5>=n || !is_word_char((unsigned char)buf[i+5]))){ size_t j=i+5; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++; if(k+5<=n && strncmp(buf+k,"proto",5)==0 && (k+5>=n || !is_word_char((unsigned char)buf[k+5]))){ size_t l=k+5; size_t m=l; while(m<n && (buf[m]==' '||buf[m]=='\t')) m++; if(m<n && buf[m]!=' '&&buf[m]!='\t'&&buf[m]!='\n'&&buf[m]!='\r'){ size_t p=m; while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++; const char *repl="ether proto PROTO"; size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=p; continue; } } }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_ip_proto(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"ip",2)==0 && (i+2>=n || !is_word_char((unsigned char)buf[i+2]))){ size_t j=i+2; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++; if(k+5<=n && strncmp(buf+k,"proto",5)==0 && (k+5>=n || !is_word_char((unsigned char)buf[k+5]))){ size_t l=k+5; size_t m=l; while(m<n && (buf[m]==' '||buf[m]=='\t')) m++; if(m<n && buf[m]!=' '&&buf[m]!='\t'&&buf[m]!='\n'&&buf[m]!='\r'){ size_t p=m; while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++; const char *repl="ip proto PROTO"; size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=p; continue; } } }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_ip6_proto(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"ip6",3)==0 && (i+3>=n || !is_word_char((unsigned char)buf[i+3]))){ size_t j=i+3; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++; if(k+5<=n && strncmp(buf+k,"proto",5)==0 && (k+5>=n || !is_word_char((unsigned char)buf[k+5]))){ size_t l=k+5; size_t m=l; while(m<n && (buf[m]==' '||buf[m]=='\t')) m++; if(m<n && buf[m]!=' '&&buf[m]!='\t'&&buf[m]!='\n'&&buf[m]!='\r'){ size_t p=m; while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++; const char *repl="ip6 proto PROTO"; size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=p; continue; } } }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_vlan(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"vlan",4)==0 && (i+4>=n || !is_word_char((unsigned char)buf[i+4]))){ size_t j=i+4; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++; if(k+3<=n && strncmp(buf+k,"NUM",3)==0 && (k+3>=n || !is_word_char((unsigned char)buf[k+3]))){ const char *repl="vlan NUM"; size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=k+3; continue; } }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
static void repl_mpls(char *buf,size_t sz){
 char out[8192]=""; size_t out_len=0; size_t i=0; size_t n=strlen(buf);
 while(i<n){
  if(i>0 && is_word_char((unsigned char)buf[i-1])){ if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++; continue; }
  if(strncmp(buf+i,"mpls",4)==0 && (i+4>=n || !is_word_char((unsigned char)buf[i+4]))){ size_t j=i+4; size_t k=j; while(k<n && (buf[k]==' '||buf[k]=='\t')) k++; if(k+3<=n && strncmp(buf+k,"NUM",3)==0 && (k+3>=n || !is_word_char((unsigned char)buf[k+3]))){ const char *repl="mpls NUM"; size_t rl=strlen(repl); if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; } i=k+3; continue; } }
  if(out_len+1<sizeof(out)){out[out_len++]=buf[i]; out[out_len]=0;} i++;
 }
 strncpy(buf,out,sz-1); buf[sz-1]=0;
}
void normalize_filter(const char *in, char *out, size_t out_sz){
 char buf[8192]; strncpy(buf, in, sizeof(buf)-1); buf[sizeof(buf)-1]=0;
 repl_mac(buf,sizeof(buf));
 repl_hex(buf,sizeof(buf));
 repl_brack(buf,sizeof(buf));
 repl_ipv4(buf,sizeof(buf));
 repl_ipv6_a(buf,sizeof(buf));
 repl_ipv6_b(buf,sizeof(buf));
 repl_num(buf,sizeof(buf));
 repl_host_net(buf,sizeof(buf));
 repl_ether_host(buf,sizeof(buf));
 repl_port(buf,sizeof(buf));
 repl_portrange(buf,sizeof(buf));
 repl_ether_proto(buf,sizeof(buf));
 repl_ip_proto(buf,sizeof(buf));
 repl_ip6_proto(buf,sizeof(buf));
 repl_vlan(buf,sizeof(buf));
 repl_mpls(buf,sizeof(buf));
 char ws[8192]=""; size_t wi=0; int in_space=1; for(size_t i=0; buf[i]; i++){ if(buf[i]==' '||buf[i]=='\t'||buf[i]=='\n'||buf[i]=='\r'){ if(!in_space){ if(wi+1 < sizeof(ws)){ ws[wi++]=' '; ws[wi]=0; } in_space=1; } } else { if(wi+1 < sizeof(ws)){ ws[wi++]=buf[i]; ws[wi]=0; } in_space=0; } }
 size_t start=0; while(ws[start]==' ') start++; size_t end=strlen(ws); while(end>start && ws[end-1]==' ') end--; ws[end]=0;
 strncpy(out, ws+start, out_sz-1); out[out_sz-1]=0;
}
