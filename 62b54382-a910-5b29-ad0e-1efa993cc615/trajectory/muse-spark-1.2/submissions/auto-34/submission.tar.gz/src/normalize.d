src/normalize.o: src/normalize.c include/normalize.h
include/normalize.h:
