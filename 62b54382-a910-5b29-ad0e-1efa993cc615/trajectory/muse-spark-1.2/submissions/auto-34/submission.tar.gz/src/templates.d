src/templates.o: src/templates.c include/templates.h src/bpf_defs.h
include/templates.h:
src/bpf_defs.h:
