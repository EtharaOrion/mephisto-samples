src/extract.o: src/extract.c include/normalize.h
include/normalize.h:
