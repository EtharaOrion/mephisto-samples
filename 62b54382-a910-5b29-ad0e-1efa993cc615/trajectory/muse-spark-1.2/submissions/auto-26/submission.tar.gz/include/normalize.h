#pragma once
#include <stddef.h>
void normalize_filter(const char *in, char *out, size_t out_sz);
int extract_values(const char *filter, unsigned int *vals, int max_vals);
