#pragma once
#include "bpf_defs.h"
#include <stdint.h>
#define TEMPLATE_COUNT 1329
typedef struct {
    uint32_t dlt;
    int optimize;
    const char *norm;
    int ok;
    const char *err;
    int prog_len;
    const bpf_insn_t *prog;
    int var_cnt;
    const int *var_pos;
    const int *var_col;
} template_t;
extern const template_t templates[TEMPLATE_COUNT];
const template_t* template_lookup(const char *norm, int dlt, int optimize);
