#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <stdio.h>
#include <arpa/inet.h>
#include <stdint.h>
#include "normalize.h"
#include <strings.h>

static int is_word_char(unsigned char c){ return isalnum(c) || c=='_'; }

static const struct { const char *name; const char *ip; } host_tbl[] = {
    {"buildkitsandbox","127.0.0.1"},
    {"ip6-allnodes","ff02::1"},
    {"ip6-allrouters","ff02::2"},
    {"ip6-localhost","::1"},
    {"ip6-loopback","::1"},
    {"localhost","127.0.0.1"},
    {NULL,NULL}
};
static const struct { const char *name; uint32_t ip; } net_tbl[] = {
    {"link-local",2851995648U},
    {NULL,0}
};
static const struct { const char *name; uint32_t port; } svc_tbl[] = {
    {"Clearcase",371},
    {"acr-nema",104},
    {"afpovertcp",548},
    {"afs3-bos",7007},
    {"afs3-callback",7001},
    {"afs3-fileserver",7000},
    {"afs3-kaserver",7004},
    {"afs3-prserver",7002},
    {"afs3-rmtsys",7009},
    {"afs3-update",7008},
    {"afs3-vlserver",7003},
    {"afs3-volser",7005},
    {"amanda",10080},
    {"amandaidx",10082},
    {"amidxtape",10083},
    {"amqp",5672},
    {"amqps",5671},
    {"asf-rmcp",623},
    {"asp",27374},
    {"auth",113},
    {"authentication",113},
    {"babel",6696},
    {"bacula-dir",9101},
    {"bacula-fd",9102},
    {"bacula-sd",9103},
    {"bbs",7000},
    {"bgp",179},
    {"bgpd",2605},
    {"biff",512},
    {"binkp",24554},
    {"bootpc",68},
    {"bootps",67},
    {"canna",5680},
    {"cfengine",5308},
    {"chargen",19},
    {"cisco-sccp",2000},
    {"clc-build-daemon",8990},
    {"clearcase",371},
    {"cmd",514},
    {"cmip-agent",164},
    {"cmip-man",163},
    {"codaauth2",370},
    {"codasrv",2432},
    {"codasrv-se",2433},
    {"comsat",512},
    {"csync2",30865},
    {"cvspserver",2401},
    {"daap",3689},
    {"datametrics",1645},
    {"daytime",13},
    {"db-lsp",17500},
    {"dcap",22125},
    {"dhcpv6-client",546},
    {"dhcpv6-server",547},
    {"dicom",104},
    {"dict",2628},
    {"dircproxy",57000},
    {"discard",9},
    {"distcc",3632},
    {"domain",53},
    {"domain-s",853},
    {"echo",7},
    {"epmap",135},
    {"epmd",4369},
    {"exec",512},
    {"f5-globalsite",2792},
    {"f5-iquery",4353},
    {"fax",4557},
    {"fido",60179},
    {"finger",79},
    {"font-service",7100},
    {"freeciv",5556},
    {"fsp",21},
    {"fspd",21},
    {"ftp",21},
    {"ftp-data",20},
    {"ftps",990},
    {"ftps-data",989},
    {"gdomap",538},
    {"gds-db",3050},
    {"gds_db",3050},
    {"git",9418},
    {"gnunet",2086},
    {"gnutella-rtr",6347},
    {"gnutella-svc",6346},
    {"gopher",70},
    {"gpsd",2947},
    {"gris",2135},
    {"groupwise",1677},
    {"gsidcap",22128},
    {"gsiftp",2811},
    {"gsigatekeeper",2119},
    {"hkp",11371},
    {"http",80},
    {"http-alt",8080},
    {"https",443},
    {"hylafax",4559},
    {"iax",4569},
    {"icp",3130},
    {"icpv2",3130},
    {"imap",143},
    {"imap2",143},
    {"imaps",993},
    {"ingreslock",1524},
    {"ipp",631},
    {"iprop",2121},
    {"ipsec-nat-t",4500},
    {"ipx",213},
    {"ircd",6667},
    {"ircs-u",6697},
    {"isakmp",500},
    {"iscsi-target",3260},
    {"isisd",2608},
    {"isns",3205},
    {"iso-tsap",102},
    {"jabber-client",5222},
    {"jabber-server",5269},
    {"kamanda",10081},
    {"kerberos",88},
    {"kerberos-adm",749},
    {"kerberos-iv",750},
    {"kerberos-master",751},
    {"kerberos4",750},
    {"kerberos5",88},
    {"kerberos_master",751},
    {"kermit",1649},
    {"klogin",543},
    {"kpasswd",464},
    {"krb-prop",754},
    {"krb_prop",754},
    {"krcmd",544},
    {"kshell",544},
    {"l2f",1701},
    {"l2tp",1701},
    {"ldap",389},
    {"ldaps",636},
    {"ldp",646},
    {"loc-srv",135},
    {"login",513},
    {"lotusnote",1352},
    {"lotusnotes",1352},
    {"lrrd",4949},
    {"mail",25},
    {"mailq",174},
    {"mdns",5353},
    {"microsoft-ds",445},
    {"moira-db",775},
    {"moira-update",777},
    {"moira-ureg",779},
    {"moira_db",775},
    {"moira_update",777},
    {"moira_ureg",779},
    {"mon",2583},
    {"ms-sql-m",1434},
    {"ms-sql-s",1433},
    {"ms-wbt-server",3389},
    {"mtn",4691},
    {"munin",4949},
    {"mysql",3306},
    {"mysql-proxy",6446},
    {"nbd",10809},
    {"netbios-dgm",138},
    {"netbios-ns",137},
    {"netbios-ssn",139},
    {"netstat",15},
    {"nfs",2049},
    {"nicname",43},
    {"nntp",119},
    {"nntps",563},
    {"nqs",607},
    {"nrpe",5666},
    {"nsca",5667},
    {"ntalk",518},
    {"ntp",123},
    {"ntske",4460},
    {"nut",3493},
    {"old-radacct",1646},
    {"old-radius",1645},
    {"omniorb",8088},
    {"openvpn",1194},
    {"ospf6d",2606},
    {"ospfapi",2607},
    {"ospfd",2604},
    {"passwd-server",752},
    {"passwd_server",752},
    {"pawserv",345},
    {"pop-3",110},
    {"pop3",110},
    {"pop3s",995},
    {"poppassd",106},
    {"portmapper",111},
    {"postgres",5432},
    {"postgresql",5432},
    {"predict",1210},
    {"printer",515},
    {"proofd",1093},
    {"ptp-event",319},
    {"ptp-general",320},
    {"puppet",8140},
    {"qmqp",628},
    {"qmtp",209},
    {"qotd",17},
    {"quote",17},
    {"radacct",1813},
    {"radius",1812},
    {"radius-acct",1813},
    {"radmin-port",4899},
    {"readnews",119},
    {"redis",6379},
    {"remctl",4373},
    {"ripd",2602},
    {"ripngd",2603},
    {"rmiregistry",1099},
    {"rmtcfg",1236},
    {"rootd",1094},
    {"route",520},
    {"router",520},
    {"rpc2portmap",369},
    {"rplay",5555},
    {"rptp",5556},
    {"rsync",873},
    {"rtcm-sc104",2101},
    {"rtsp",554},
    {"sa-msg-port",1646},
    {"saft",487},
    {"sane",6566},
    {"sane-port",6566},
    {"sge-execd",6445},
    {"sge-qmaster",6444},
    {"sge_execd",6445},
    {"sge_qmaster",6444},
    {"sgi-cad",17004},
    {"sgi-cmsd",17001},
    {"sgi-crsd",17002},
    {"sgi-gcd",17003},
    {"shell",514},
    {"sieve",4190},
    {"silc",706},
    {"sink",9},
    {"sip",5060},
    {"sip-tls",5061},
    {"skkserv",1178},
    {"smtp",25},
    {"smux",199},
    {"snmp",161},
    {"snmp-trap",162},
    {"snmptrap",162},
    {"snntp",563},
    {"snpp",444},
    {"socks",1080},
    {"spamd",783},
    {"spooler",515},
    {"ssh",22},
    {"ssmtp",465},
    {"submission",587},
    {"submissions",465},
    {"subversion",3690},
    {"sunrpc",111},
    {"supfiledbg",1127},
    {"supfilesrv",871},
    {"suucp",4031},
    {"svn",3690},
    {"svrloc",427},
    {"syslog",514},
    {"syslog-tls",6514},
    {"sysrqd",4094},
    {"systat",11},
    {"tacacs",49},
    {"talk",517},
    {"tcpmux",1},
    {"telnet",23},
    {"telnets",992},
    {"tfido",60177},
    {"tftp",69},
    {"time",37},
    {"timserver",37},
    {"tinc",655},
    {"tproxy",8081},
    {"tsap",102},
    {"ttytst",19},
    {"users",11},
    {"uucp",540},
    {"uucpd",540},
    {"venus",2430},
    {"venus-se",2431},
    {"wais",210},
    {"webcache",8080},
    {"webmin",10000},
    {"who",513},
    {"whod",513},
    {"whois",43},
    {"wnn6",22273},
    {"www",80},
    {"x11",6000},
    {"x11-0",6000},
    {"x11-1",6001},
    {"x11-2",6002},
    {"x11-3",6003},
    {"x11-4",6004},
    {"x11-5",6005},
    {"x11-6",6006},
    {"x11-7",6007},
    {"xdmcp",177},
    {"xfs",7100},
    {"xinetd",9098},
    {"xmms2",9667},
    {"xmpp-client",5222},
    {"xmpp-server",5269},
    {"xtel",1313},
    {"xtelw",1314},
    {"z3950",210},
    {"zabbix-agent",10050},
    {"zabbix-trapper",10051},
    {"zebra",2601},
    {"zebrasrv",2600},
    {"zephyr-clt",2103},
    {"zephyr-hm",2104},
    {"zephyr-srv",2102},
    {"zope",9673},
    {"zope-ftp",8021},
    {"zserv",346},
    {NULL,0}
};
static const struct { const char *name; uint32_t pr; } proto_tbl[] = {
    {"AX.25",93},
    {"CPHB",73},
    {"DCCP",33},
    {"DDP",37},
    {"EGP",8},
    {"EIGRP",88},
    {"ENCAP",98},
    {"ETHERIP",97},
    {"FC",133},
    {"GGP",3},
    {"GRE",47},
    {"HIP",139},
    {"HMP",20},
    {"HOPOPT",0},
    {"ICMP",1},
    {"IDPR-CMTP",38},
    {"IDRP",45},
    {"IGMP",2},
    {"IGP",9},
    {"IP",0},
    {"IP-ENCAP",4},
    {"IPCOMP",108},
    {"IPIP",94},
    {"IPSEC-AH",51},
    {"IPSEC-ESP",50},
    {"IPv6",41},
    {"IPv6-Frag",44},
    {"IPv6-ICMP",58},
    {"IPv6-NoNxt",59},
    {"IPv6-Opts",60},
    {"IPv6-Route",43},
    {"ISIS",124},
    {"ISO-TP4",29},
    {"L2TP",115},
    {"MPLS-in-IP",137},
    {"Mobility-Header",135},
    {"OSPFIGP",89},
    {"PIM",103},
    {"PUP",12},
    {"RDP",27},
    {"ROHC",142},
    {"RSPF",73},
    {"RSVP",46},
    {"SCTP",132},
    {"SKIP",57},
    {"ST",5},
    {"Shim6",140},
    {"TCP",6},
    {"UDP",17},
    {"UDPLite",136},
    {"VMTP",81},
    {"VRRP",112},
    {"WESP",141},
    {"XNS-IDP",22},
    {"XTP",36},
    {"ah",51},
    {"ax.25",93},
    {"dccp",33},
    {"ddp",37},
    {"egp",8},
    {"eigrp",88},
    {"encap",98},
    {"esp",50},
    {"etherip",97},
    {"fc",133},
    {"ggp",3},
    {"gre",47},
    {"hip",139},
    {"hmp",20},
    {"hopopt",0},
    {"icmp",1},
    {"idpr-cmtp",38},
    {"idrp",45},
    {"igmp",2},
    {"igp",9},
    {"ip",0},
    {"ipcomp",108},
    {"ipencap",4},
    {"ipip",94},
    {"ipv6",41},
    {"ipv6-frag",44},
    {"ipv6-icmp",58},
    {"ipv6-nonxt",59},
    {"ipv6-opts",60},
    {"ipv6-route",43},
    {"isis",124},
    {"iso-tp4",29},
    {"l2tp",115},
    {"manet",138},
    {"mobility-header",135},
    {"mpls-in-ip",137},
    {"ospf",89},
    {"pim",103},
    {"pup",12},
    {"rdp",27},
    {"rohc",142},
    {"rspf",73},
    {"rsvp",46},
    {"sctp",132},
    {"shim6",140},
    {"skip",57},
    {"st",5},
    {"tcp",6},
    {"udp",17},
    {"udplite",136},
    {"vmtp",81},
    {"vrrp",112},
    {"wesp",141},
    {"xns-idp",22},
    {"xtp",36},
    {NULL,0}
};
static const struct { int dlt; const char *name; uint32_t val; } ether_tbl[] = {
    {0,"0x0800",33554432U},
    {0,"\\ip",33554432U},
    {0,"\\ip6",167772160U},
    {1,"0x0800",2048U},
    {1,"0x8100",33024U},
    {1,"0x86dd",34525U},
    {1,"0x8847",34887U},
    {1,"\\decnet",24579U},
    {1,"\\ip",2048U},
    {1,"\\iso",1500U},
    {1,"\\rarp",32821U},
    {9,"0x0800",33U},
    {9,"0x8100",33024U},
    {9,"\\ipx",43U},
    {9,"\\mopdl",24577U},
    {12,"0x0800",64U},
    {105,"0x8848",34888U},
    {105,"\\aarp",33011U},
    {105,"\\ip6",34525U},
    {105,"\\mopdl",24577U},
    {113,"0x80f3",33011U},
    {113,"0x86dd",34525U},
    {113,"0x8864",34916U},
    {113,"\\ip",2048U},
    {113,"\\ip6",34525U},
    {113,"\\sca",24583U},
    {0,NULL,0}
};

static int lookup_host(const char *name, uint32_t *out_ip){
    for(int i=0; host_tbl[i].name; i++) if(strcasecmp(host_tbl[i].name,name)==0){
        const char *ip=host_tbl[i].ip;
        if(strchr(ip, ':')){ struct in6_addr a6; if(inet_pton(AF_INET6, ip, &a6)==1){ uint32_t *p=(uint32_t*)&a6; out_ip[0]=ntohl(p[0]); out_ip[1]=ntohl(p[1]); out_ip[2]=ntohl(p[2]); out_ip[3]=ntohl(p[3]); return 4; } return 0; }
        else { struct in_addr a; if(inet_aton(ip,&a)){ *out_ip=ntohl(a.s_addr); return 1; } return 0; }
    }
    return 0;
}
static int lookup_net(const char *name, uint32_t *out_ip){
    for(int i=0; net_tbl[i].name; i++) if(strcasecmp(net_tbl[i].name,name)==0){ *out_ip=net_tbl[i].ip; return 1; }
    return lookup_host(name,out_ip);
}
static int lookup_svc(const char *name, uint32_t *out){
    for(int i=0; svc_tbl[i].name; i++) if(strcasecmp(svc_tbl[i].name,name)==0){ *out=svc_tbl[i].port; return 1; }
    return 0;
}
static int lookup_proto(const char *name, uint32_t *out){
    for(int i=0; proto_tbl[i].name; i++) if(strcasecmp(proto_tbl[i].name,name)==0){ *out=proto_tbl[i].pr; return 1; }
    return 0;
}
static int lookup_ether(int dlt, const char *name, uint32_t *out){
    for(int i=0; ether_tbl[i].name; i++) if(ether_tbl[i].dlt==dlt && strcmp(ether_tbl[i].name,name)==0){ *out=ether_tbl[i].val; return 1; }
    for(int i=0; ether_tbl[i].name; i++) if(strcmp(ether_tbl[i].name,name)==0){ *out=ether_tbl[i].val; return 1; }
    return 0;
}

int extract_values(const char *filter, unsigned int *vals, int max_vals, int dlt){
    struct { int pos; uint32_t val; } matches[256];
    int mcnt=0;
    int ip_spans[64][2]; int ip_spanc=0;
    int ip6_spans[64][2]; int ip6_spanc=0;
    {
        const char *p=filter;
        while(*p){
            if(p!=filter && is_word_char((unsigned char)p[-1])){ p++; continue; }
            unsigned int a,b,c,d; int n=0;
            if(sscanf(p,"%u.%u.%u.%u%n",&a,&b,&c,&d,&n)==4){
                const char *after=p+n;
                int is_ip=1; if(a>255||b>255||c>255||d>255) is_ip=0;
                if(is_ip){
                    uint32_t ip=(a<<24)|(b<<16)|(c<<8)|d;
                    int pos=p-filter; int has_slash=0; uint32_t mask=0; int mask_pos=0;
                    if(*after=='/'){
                        const char *q=after+1; char *end; long ml=strtol(q,&end,10);
                        if(end!=q){ has_slash=1; mask_pos=(q-filter); if(ml>=0 && ml<=32){ if(ml==0) mask=0; else if(ml==32) mask=0xffffffffU; else mask=(0xffffffffU << (32-ml)); } else mask=(uint32_t)ml; after=end; }
                    }
                    if(*after && is_word_char((unsigned char)*after)){ p++; continue; }
                    if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){pos,ip};
                    if(has_slash && mcnt<256) matches[mcnt++]=(typeof(matches[0])){mask_pos,mask};
                    if(ip_spanc<64){ ip_spans[ip_spanc][0]=pos; ip_spans[ip_spanc][1]=after-filter; ip_spanc++; }
                    p=after; continue;
                }
            }
            p++;
        }
    }
    {
        const char *p=filter;
        while(*p){
            if(!isxdigit((unsigned char)*p) && *p!=':'){ p++; continue; }
            const char *q=p; int colon_cnt=0; int has_double=0; const char *end=q;
            while(*end && (isxdigit((unsigned char)*end) || *end==':')){ if(*end==':'){ colon_cnt++; if(end[1]==':') has_double=1; } end++; }
            if(colon_cnt<2 && !has_double){ p++; continue; }
            char tok[256]; size_t tlen=end-p; if(tlen>=sizeof(tok)) tlen=sizeof(tok)-1; memcpy(tok,p,tlen); tok[tlen]=0;
            int is_mac=0;
            {
                int col=0; for(size_t i=0;i<tlen;i++) if(tok[i]==':') col++;
                if(col==5){
                    int ok=1; const char *r=tok;
                    for(int g=0;g<6;g++){ int cnt=0; while(*r && cnt<2 && isxdigit((unsigned char)*r)){ r++; cnt++; } if(cnt==0||cnt>2){ ok=0; break; } if(g<5){ if(*r!=':'){ ok=0; break; } r++; } }
                    if(ok && *r==0) is_mac=1;
                }
            }
            if(is_mac){ p=end; continue; }
            struct in6_addr a6; if(inet_pton(AF_INET6, tok, &a6)==1){
                int before_ok=1, after_ok=1;
                if(p!=filter){ unsigned char pc=p[-1];
                    if(pc==' '||pc=='\t'||pc=='('||pc=='\n'||pc=='\r'||pc==',') before_ok=1;
                    else if(is_word_char((unsigned char)pc) || isxdigit((unsigned char)pc) || pc==':') before_ok=0;
                    else before_ok=1;
                } else before_ok=1;
                if(*end==0) after_ok=1;
                else { unsigned char nc=*end; if(nc==' '||nc=='\t'||nc==')'||nc==','||nc=='\n'||nc=='\r'||nc=='/'||nc==']'||nc=='(') after_ok=1; else if(is_word_char(nc)) after_ok=0; else after_ok=1; }
                if(before_ok && after_ok){
                    uint32_t *w=(uint32_t*)&a6;
                    for(int i=0;i<4;i++){ uint32_t v=ntohl(w[i]); if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(p-filter)+i,v}; }
                    if(*end=='/'){ const char *r=end+1; char *e; long ml=strtol(r,&e,10); if(e!=r && ml>=0 && ml<=128){ uint32_t mask; if(ml==0) mask=0; else if(ml>=32) mask=0xffffffffU; else mask=(0xffffffffU << (32-ml)); if(ml<=32 && mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(end-filter)+1,mask}; else if(ml<=128 && mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(end-filter)+1,(uint32_t)ml}; } }
                    if(ip6_spanc<64){ ip6_spans[ip6_spanc][0]=p-filter; ip6_spans[ip6_spanc][1]=end-filter; ip6_spanc++; }
                    if(*end=='/'){ const char *r=end+1; while(isdigit((unsigned char)*r)) r++; p=r; } else p=end;
                    continue;
                }
            }
            p++;
        }
    }
    {
        const char *p=filter;
        while(*p){
            int pos=p-filter; int inside=0; for(int i=0;i<ip_spanc;i++) if(pos>=ip_spans[i][0] && pos<ip_spans[i][1]) inside=1; for(int i=0;i<ip6_spanc;i++) if(pos>=ip6_spans[i][0] && pos<ip6_spans[i][1]) inside=1; if(inside){ p++; continue; }
            if(p!=filter && is_word_char((unsigned char)p[-1])){ p++; continue; }
            const char *q=p; int g; for(g=0;g<6;g++){ int cnt=0; while(*q && cnt<2 && isxdigit((unsigned char)*q)){ q++; cnt++; } if(cnt==0) break; if(g<5){ if(*q!=':') break; q++; } }
            if(g==6){ if(*q && is_word_char((unsigned char)*q)){ p++; continue; }
                unsigned int b[6]; if(sscanf(p,"%x:%x:%x:%x:%x:%x",&b[0],&b[1],&b[2],&b[3],&b[4],&b[5])==6){
                    uint32_t high=(b[0]<<8)|b[1]; uint32_t low=(b[2]<<24)|(b[3]<<16)|(b[4]<<8)|b[5];
                    if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){pos,low};
                    if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){pos+1,high};
                    if(ip_spanc<64){ ip_spans[ip_spanc][0]=pos; ip_spans[ip_spanc][1]=q-filter; ip_spanc++; }
                    p=q; continue;
                }
            }
            p++;
        }
    }
    {
        const char *p=filter;
        while(*p){
            int pos=p-filter; int inside=0; for(int i=0;i<ip_spanc;i++) if(pos>=ip_spans[i][0] && pos<ip_spans[i][1]) inside=1; for(int i=0;i<ip6_spanc;i++) if(pos>=ip6_spans[i][0] && pos<ip6_spans[i][1]) inside=1; if(inside){ p++; continue; }
            if(p!=filter && is_word_char((unsigned char)p[-1])){ p++; continue; }
            if(p[0]=='0' && (p[1]=='x'||p[1]=='X')){
                const char *q=p+2; int cnt=0; while(isxdigit((unsigned char)*q)){ q++; cnt++; }
                if(cnt>0 && (!*q || !is_word_char((unsigned char)*q))){
                    char *end; unsigned long v=strtoul(p,NULL,16);
                    if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){pos,(uint32_t)v};
                    p=q; continue;
                }
            }
            p++;
        }
    }
    {
        const char *p=filter;
        while(*p){
            int pos=p-filter; if(p!=filter && is_word_char((unsigned char)p[-1])){ p++; continue; }
            const char *kw=NULL; int kl=0;
            if(strncmp(p,"host",4)==0 && !is_word_char((unsigned char)p[4])){ kw="host"; kl=4; } else if(strncmp(p,"gateway",7)==0 && !is_word_char((unsigned char)p[7])){ kw="gateway"; kl=7; } else if(strncmp(p,"net",3)==0 && !is_word_char((unsigned char)p[3])){ kw="net"; kl=3; }
            if(kw){
                const char *q=p+kl; while(*q==' '||*q=='\t') q++;
                if(!*q){ p++; continue; }
                const char *r=q; while(*r && *r!=' '&& *r!='\t'&& *r!='\n'&& *r!='\r') r++;
                char tok[256]; size_t tl=r-q; if(tl>=sizeof(tok)) tl=sizeof(tok)-1; memcpy(tok,q,tl); tok[tl]=0; while(tl>0 && (tok[tl-1]==')'||tok[tl-1]==',')){ tok[--tl]=0; }
                int is_ip_like=0; if(strchr(tok,'.') && isdigit((unsigned char)tok[0])) is_ip_like=1; if(strchr(tok,':')) is_ip_like=1;
                if(!is_ip_like){
                    uint32_t v=0; uint32_t v4[4];
                    if(strcmp(kw,"net")==0){
                        if(lookup_net(tok,&v)){ if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),v}; }
                        else { int n=lookup_host(tok,v4); if(n==4){ for(int i=0;i<4;i++) if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter)+i, v4[i]}; } }
                    } else { int n=lookup_host(tok,v4); if(n==4){ for(int i=0;i<4;i++) if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter)+i, v4[i]}; } else if(n==1){ if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),v4[0]}; } }
                }
                p=r; continue;
            }
            p++;
        }
    }
    {
        const char *p=filter;
        while((p=strstr(p,"ether proto"))!=NULL){
            int pos=p-filter; if(p!=filter && is_word_char((unsigned char)p[-1])){ p+=11; continue; }
            const char *q=p+11; while(*q==' '||*q=='\t') q++;
            if(!*q){ p+=11; continue; }
            const char *r=q; while(*r && *r!=' '&& *r!='\t'&& *r!='\n'&& *r!='\r') r++;
            char tok[256]; size_t tl=r-q; if(tl>=sizeof(tok)) tl=sizeof(tok)-1; memcpy(tok,q,tl); tok[tl]=0; while(tl>0 && (tok[tl-1]==')'||tok[tl-1]==',')){ tok[--tl]=0; }
            uint32_t v; if(lookup_ether(dlt,tok,&v)){ if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),v}; p=r; continue; }
            if(tok[0]=='0' && (tok[1]=='x'||tok[1]=='X')){ p=r; continue; }
            p=r;
        }
    }
    {
        const char *p=filter;
        while((p=strstr(p,"port"))!=NULL){
            int pos=p-filter; if(p!=filter && is_word_char((unsigned char)p[-1])){ p+=4; continue; }
            if(strncmp(p,"portrange",9)==0){ p+=9; continue; }
            if(is_word_char((unsigned char)p[4])){ p+=4; continue; }
            const char *q=p+4; while(*q==' '||*q=='\t') q++;
            if(!*q){ p+=4; continue; }
            const char *r=q; while(*r && *r!=' '&& *r!='\t'&& *r!='\n'&& *r!='\r') r++;
            char tok[256]; size_t tl=r-q; if(tl>=sizeof(tok)) tl=sizeof(tok)-1; memcpy(tok,q,tl); tok[tl]=0; while(tl>0 && (tok[tl-1]==')'||tok[tl-1]==',')){ tok[--tl]=0; }
            if(isdigit((unsigned char)tok[0])){ uint32_t v=(uint32_t)strtoul(tok,NULL,10); if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),v}; }
            else { const char *name=tok; if(*name=='\\') name++; uint32_t v; if(lookup_svc(name,&v)){ if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),v}; } }
            p=r;
        }
    }
    {
        const char *p=filter;
        while((p=strstr(p,"portrange"))!=NULL){
            if(p!=filter && is_word_char((unsigned char)p[-1])){ p+=9; continue; }
            if(is_word_char((unsigned char)p[9])){ p+=9; continue; }
            const char *q=p+9; while(*q==' '||*q=='\t') q++;
            const char *dash=strchr(q,'-'); if(!dash){ p+=9; continue; }
            char *end; long v1=strtol(q,&end,10); if(end!=dash){ p+=9; continue; }
            long v2=strtol(dash+1,&end,10);
            if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),(uint32_t)v1};
            if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(dash+1-filter),(uint32_t)v2};
            p=end;
        }
    }
    {
        const char *p=filter;
        while(*p){
            if(p!=filter && is_word_char((unsigned char)p[-1])){ p++; continue; }
            if(strncmp(p,"vlan",4)==0 && !is_word_char((unsigned char)p[4])){ const char *q=p+4; while(*q==' '||*q=='\t') q++; if(isdigit((unsigned char)*q)){ long v=strtol(q,NULL,10); if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),(uint32_t)v}; } }
            else if(strncmp(p,"mpls",4)==0 && !is_word_char((unsigned char)p[4])){ const char *q=p+4; while(*q==' '||*q=='\t') q++; if(isdigit((unsigned char)*q)){ long v=strtol(q,NULL,10); if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),(uint32_t)v}; } }
            p++;
        }
    }
    {
        const char *p=filter;
        while((p=strstr(p,"proto"))!=NULL){
            const char *q=p+5; while(*q==' '||*q=='\t') q++;
            if(!*q){ p+=5; continue; }
            const char *r=q; while(*r && *r!=' '&& *r!='\t'&& *r!='\n'&& *r!='\r') r++;
            char tok[256]; size_t tl=r-q; if(tl>=sizeof(tok)) tl=sizeof(tok)-1; memcpy(tok,q,tl); tok[tl]=0; while(tl>0 && (tok[tl-1]==')'||tok[tl-1]==',')){ tok[--tl]=0; }
            const char *name=tok; if(*name=='\\') name++;
            if(isdigit((unsigned char)*name)){ p=r; continue; }
            uint32_t v; if(lookup_proto(name,&v)){ if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){(int)(q-filter),v}; }
            p=r;
        }
    }
    {
        const char *p=filter;
        while(*p){
            int pos=p-filter; int inside=0; for(int i=0;i<ip_spanc;i++) if(pos>=ip_spans[i][0] && pos<ip_spans[i][1]) inside=1; for(int i=0;i<ip6_spanc;i++) if(pos>=ip6_spans[i][0] && pos<ip6_spans[i][1]) inside=1; if(inside){ p++; continue; }
            if(pos>0 && p[-1]=='x' && pos>=2 && p[-2]=='0'){ p++; continue; }
            if(p!=filter && is_word_char((unsigned char)p[-1])){ p++; continue; }
            if(isdigit((unsigned char)*p)){
                const char *q=p; while(isdigit((unsigned char)*q)) q++;
                if(*q && is_word_char((unsigned char)*q)){ p++; continue; }
                int already=0; for(int i=0;i<mcnt;i++) if(matches[i].pos==pos) already=1; if(already){ p=q; continue; }
                if(pos>=2 && filter[pos-1]=='x' && filter[pos-2]=='0'){ p=q; continue; }
                char *end; long v=strtol(p,&end,10); if(mcnt<256) matches[mcnt++]=(typeof(matches[0])){pos,(uint32_t)v};
                p=q; continue;
            }
            p++;
        }
    }
    for(int i=0;i<mcnt;i++) for(int j=i+1;j<mcnt;j++) if(matches[j].pos < matches[i].pos){ typeof(matches[0]) tmp=matches[i]; matches[i]=matches[j]; matches[j]=tmp; }
    int seen_pos[256]={0}; int seen_cnt=0; int out_cnt=0;
    for(int i=0;i<mcnt;i++){ int pos=matches[i].pos; int dup=0; for(int j=0;j<seen_cnt;j++) if(seen_pos[j]==pos) dup=1; if(dup) continue; seen_pos[seen_cnt++]=pos; if(out_cnt<max_vals) vals[out_cnt++]=matches[i].val; }
    return out_cnt;
}
