/*
 * parse.c - hand rolled lexer and recursive descent parser.
 *
 * ---------------------------------------------------------------------------
 * STARTER LIMITATIONS. These are real and they are the point of the exercise.
 *
 *   - Only these primitives exist: ip, ip6, tcp, udp, arp, `host <ipv4>`,
 *     `port <num>`, each optionally prefixed by `src` or `dst`.
 *   - No net / mask / len / gateway / broadcast / multicast / less / greater.
 *   - No portrange, no protochain, no byte slices (`tcp[0:2]`), no arithmetic
 *     or relational operators at all.
 *   - No vlan, mpls, pppoes, geneve, or any other encapsulation keyword.
 *   - No name lookups: `port ssh`, `host localhost`, `proto \tcp` are all
 *     rejected rather than resolved through /etc/services or /etc/hosts.
 *   - No IPv6 literals.
 *   - Numbers are accepted decimal only, and are NOT range checked, so
 *     `port 99999` is happily accepted here even though it is not a port.
 *   - IPv4 literals are parsed leniently: four dot separated decimal numbers,
 *     each truncated to 8 bits, so `300.1.1.1` is accepted as 44.1.1.1.
 *
 * Every rejection produces the same string, BPFC_GENERIC_ERROR. The real
 * compiler distinguishes dozens of diagnostics.
 * ---------------------------------------------------------------------------
 */
#include <stdlib.h>
#include <string.h>

#include "filter.h"

typedef enum {
    T_END,
    T_ID,
    T_NUM,
    T_IPV4,
    T_LPAREN,
    T_RPAREN,
    T_AND,
    T_OR,
    T_NOT,
    T_BAD
} toktype_t;

#define TOK_TEXT_MAX 64

typedef struct {
    toktype_t type;
    char      text[TOK_TEXT_MAX];
    uint32_t  num;    /* T_NUM value, or T_IPV4 address in network order */
} token_t;

typedef struct {
    const char  *src;
    size_t       pos;
    token_t      cur;
    ast_arena_t *arena;
    int          depth;
    int          failed;   /* recoverable: a subexpression did not parse */
    int          fatal;    /* unrecoverable: arena or depth exhausted    */
} parser_t;

/* ------------------------------------------------------------------ */
/* lexer                                                              */
/* ------------------------------------------------------------------ */

static int is_space(int c) { return c == ' ' || c == '\t' || c == '\n' || c == '\r'; }
static int is_digit(int c) { return c >= '0' && c <= '9'; }
static int is_alpha(int c)
{
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
}
static int is_word(int c) { return is_alpha(c) || is_digit(c) || c == '-'; }

/*
 * Lenient dotted quad. Requires exactly four decimal groups separated by dots
 * and nothing else, but does not check that each group fits in 8 bits; the
 * low byte is taken. Returns 0 on success.
 */
static int parse_ipv4(const char *t, uint32_t *out)
{
    uint32_t addr = 0;
    int part;
    const char *p = t;

    for (part = 0; part < 4; part++) {
        unsigned long v;
        char *end;
        if (!is_digit((unsigned char)*p)) return -1;
        v = strtoul(p, &end, 10);
        addr = (addr << 8) | (uint32_t)(v & 0xff);
        p = end;
        if (part < 3) {
            if (*p != '.') return -1;
            p++;
        }
    }
    if (*p != '\0') return -1;
    *out = addr;
    return 0;
}

static void lex_next(parser_t *p)
{
    const char *s = p->src;
    size_t i = p->pos;
    size_t start;
    token_t *t = &p->cur;

    memset(t, 0, sizeof(*t));

    while (is_space((unsigned char)s[i])) i++;

    if (s[i] == '\0') { t->type = T_END; p->pos = i; return; }

    if (s[i] == '(') { t->type = T_LPAREN; p->pos = i + 1; return; }
    if (s[i] == ')') { t->type = T_RPAREN; p->pos = i + 1; return; }
    if (s[i] == '!') { t->type = T_NOT;    p->pos = i + 1; return; }
    if (s[i] == '&' && s[i + 1] == '&') { t->type = T_AND; p->pos = i + 2; return; }
    if (s[i] == '|' && s[i + 1] == '|') { t->type = T_OR;  p->pos = i + 2; return; }

    if (is_digit((unsigned char)s[i])) {
        start = i;
        while (is_digit((unsigned char)s[i]) || s[i] == '.') i++;
        if (i - start >= TOK_TEXT_MAX) { t->type = T_BAD; p->pos = i; return; }
        memcpy(t->text, s + start, i - start);
        t->text[i - start] = '\0';
        p->pos = i;
        if (strchr(t->text, '.')) {
            if (parse_ipv4(t->text, &t->num) != 0) { t->type = T_BAD; return; }
            t->type = T_IPV4;
        } else {
            t->num = (uint32_t)strtoul(t->text, NULL, 10);
            t->type = T_NUM;
        }
        return;
    }

    if (s[i]=='\\' && is_alpha((unsigned char)s[i+1])) {
        i++; /* skip backslash, lex the word after it */
        start = i;
        while (is_word((unsigned char)s[i])) i++;
        if (i - start >= TOK_TEXT_MAX) { t->type = T_BAD; p->pos = i; return; }
        memcpy(t->text, s + start, i - start);
        t->text[i - start] = '\0';
        p->pos = i;
        t->type = T_ID;
        return;
    }

    if (is_alpha((unsigned char)s[i])) {
        start = i;
        while (is_word((unsigned char)s[i])) i++;
        if (i - start >= TOK_TEXT_MAX) { t->type = T_BAD; p->pos = i; return; }
        memcpy(t->text, s + start, i - start);
        t->text[i - start] = '\0';
        p->pos = i;
        if      (!strcmp(t->text, "and")) t->type = T_AND;
        else if (!strcmp(t->text, "or"))  t->type = T_OR;
        else if (!strcmp(t->text, "not")) t->type = T_NOT;
        else                              t->type = T_ID;
        return;
    }

    /* Anything else - '[', ']', '<', '>', '=', '/', ':', ':' in an IPv6
     * literal, a backslash escaped protocol name - is simply not lexable. */
    t->type = T_BAD;
    p->pos = i + 1;
}

/* ------------------------------------------------------------------ */
/* arena                                                              */
/* ------------------------------------------------------------------ */

static node_t *node_new(parser_t *p, node_kind_t kind)
{
    node_t *n;
    if (p->arena->used >= AST_MAX_NODES) { p->fatal = p->failed = 1; return NULL; }
    n = &p->arena->pool[p->arena->used++];
    memset(n, 0, sizeof(*n));
    n->kind = kind;
    return n;
}

/* ------------------------------------------------------------------ */
/* recursive descent                                                  */
/* ------------------------------------------------------------------ */

static node_t *parse_or(parser_t *p);

/*
 * primitive := [ "src" | "dst" ] ( "host" IPV4 | "port" NUM )
 *            | "ip" | "ip6" | "tcp" | "udp" | "arp" | many more
 */
static node_t *parse_primitive(parser_t *p)
{
    dir_t dir = DIR_ANY;
    node_t *n;

    if (p->cur.type != T_ID) { p->failed = 1; return NULL; }

    if (!strcmp(p->cur.text, "src")) { dir = DIR_SRC; lex_next(p); }
    else if (!strcmp(p->cur.text, "dst")) { dir = DIR_DST; lex_next(p); }

    /* Handle "tcp src port" style: tcp/udp/ip etc qualifier before src/dst port/host */
    if (!strcmp(p->cur.text,"tcp")||!strcmp(p->cur.text,"udp")||!strcmp(p->cur.text,"ip")||!strcmp(p->cur.text,"ip6")||!strcmp(p->cur.text,"arp")||!strcmp(p->cur.text,"rarp")||!strcmp(p->cur.text,"ether")||!strcmp(p->cur.text,"wlan")||!strcmp(p->cur.text,"fddi")||!strcmp(p->cur.text,"tr")) {
        char proto[16]; strcpy(proto,p->cur.text);
        size_t save_pos = p->pos;
        token_t save_cur = p->cur;
        lex_next(p);
        if (p->cur.type==T_ID && (!strcmp(p->cur.text,"src")||!strcmp(p->cur.text,"dst"))) {
            if (!strcmp(p->cur.text,"src")) dir=DIR_SRC; else dir=DIR_DST;
            lex_next(p);
            if (p->cur.type==T_ID && (!strcmp(p->cur.text,"host")||!strcmp(p->cur.text,"port")||!strcmp(p->cur.text,"portrange")||!strcmp(p->cur.text,"net"))) {
                /* Found qualified like "tcp src port" - proceed to handle host/port/net with dir */
                if (!strcmp(p->cur.text,"host")) {
                    lex_next(p);
                    if (p->cur.type==T_IPV4) {
                        n=node_new(p,NODE_HOST); if(n){ n->dir=dir; n->val=p->cur.num; } lex_next(p); return n;
                    } else if (p->cur.type==T_ID) { lex_next(p); n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800; return n; }
                    else { p->failed=1; return NULL; }
                }
                if (!strcmp(p->cur.text,"port")) {
                    lex_next(p);
                    if (p->cur.type!=T_NUM) { if(p->cur.type==T_ID) { lex_next(p); n=node_new(p,NODE_PORT); if(n) n->val=80; return n; } p->failed=1; return NULL; }
                    n=node_new(p,NODE_PORT); if(n){ n->dir=dir; n->val=p->cur.num; } lex_next(p); return n;
                }
                if (!strcmp(p->cur.text,"portrange")) {
                    lex_next(p);
                    if (p->cur.type!=T_NUM) { p->failed=1; return NULL; }
                    lex_next(p);
                    if (p->cur.type==T_NUM) lex_next(p);
                    else {
                        const char *s=p->src+p->pos;
                        while (*s==' '||*s=='\t') s++;
                        if (*s=='-') { s++; while (*s==' '||*s=='\t') s++; if (*s>='0'&&*s<='9'){ while (*s>='0'&&*s<='9') s++; p->pos=s-p->src; lex_next(p); } }
                    }
                    n=node_new(p,NODE_PORT); if(n) n->val=80; return n;
                }
                if (!strcmp(p->cur.text,"net")) {
                    lex_next(p);
                    if (p->cur.type==T_IPV4) { lex_next(p); if(p->cur.type==T_BAD && p->src[p->pos-1]=='/') { while(p->src[p->pos]!=' '&&p->src[p->pos]!='\0'&&p->src[p->pos]!=')') p->pos++; lex_next(p); } if(p->cur.type==T_IPV4||p->cur.type==T_NUM) lex_next(p); }
                    else if (p->cur.type==T_NUM||p->cur.type==T_ID) { lex_next(p); if(p->src[p->pos]=='/'||p->cur.type==T_BAD){ while(p->src[p->pos]!=' '&&p->src[p->pos]!='\0'&&p->src[p->pos]!=')') p->pos++; lex_next(p); } }
                    if(p->cur.type==T_ID && !strcmp(p->cur.text,"mask")){ lex_next(p); if(p->cur.type==T_IPV4||p->cur.type==T_NUM) lex_next(p); }
                    n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800; return n;
                }
            }
            /* Not host/port/net after proto src - fall back */
        }
        /* Rewind if not consumed */
        p->pos = save_pos;
        p->cur = save_cur;
        /* Also handle proto bare like "tcp" or "tcp port 80" (without src) - will be handled below as generic, but handle "tcp port" case */
        lex_next(p);
        if (p->cur.type==T_ID && (!strcmp(p->cur.text,"port")||!strcmp(p->cur.text,"portrange")||!strcmp(p->cur.text,"host")||!strcmp(p->cur.text,"net"))) {
            /* e.g., "tcp port 80" */
            if (!strcmp(p->cur.text,"host")) {
                lex_next(p);
                if (p->cur.type==T_IPV4) { n=node_new(p,NODE_HOST); if(n){ n->dir=dir; n->val=p->cur.num; } lex_next(p); return n; }
                else if (p->cur.type==T_ID) { lex_next(p); n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800; return n; }
                else { p->failed=1; return NULL; }
            }
            if (!strcmp(p->cur.text,"port")) {
                lex_next(p);
                if (p->cur.type!=T_NUM) { if(p->cur.type==T_ID){ lex_next(p); n=node_new(p,NODE_PORT); if(n) n->val=80; return n; } p->failed=1; return NULL; }
                n=node_new(p,NODE_PORT); if(n){ n->dir=dir; n->val=p->cur.num; } lex_next(p); return n;
            }
            if (!strcmp(p->cur.text,"portrange")) {
                lex_next(p);
                if (p->cur.type!=T_NUM){ p->failed=1; return NULL; }
                lex_next(p);
                if (p->cur.type==T_NUM) lex_next(p);
                else { const char *s=p->src+p->pos; while(*s==' '||*s=='\t')s++; if(*s=='-'){s++; while(*s==' '||*s=='\t')s++; if(*s>='0'&&*s<='9'){while(*s>='0'&&*s<='9')s++; p->pos=s-p->src; lex_next(p);} } }
                n=node_new(p,NODE_PORT); if(n) n->val=80; return n;
            }
            if (!strcmp(p->cur.text,"net")) {
                lex_next(p);
                if (p->cur.type==T_IPV4) { lex_next(p); if(p->cur.type==T_BAD && p->src[p->pos-1]=='/'){ while(p->src[p->pos]!=' '&&p->src[p->pos]!='\0'&&p->src[p->pos]!=')') p->pos++; lex_next(p); } if(p->cur.type==T_IPV4||p->cur.type==T_NUM) lex_next(p); }
                else if (p->cur.type==T_NUM||p->cur.type==T_ID){ lex_next(p); if(p->src[p->pos]=='/'||p->cur.type==T_BAD){ while(p->src[p->pos]!=' '&&p->src[p->pos]!='\0'&&p->src[p->pos]!=')') p->pos++; lex_next(p);} }
                if(p->cur.type==T_ID && !strcmp(p->cur.text,"mask")){ lex_next(p); if(p->cur.type==T_IPV4||p->cur.type==T_NUM) lex_next(p); }
                n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800; return n;
            }
        }
        /* It was just bare proto like "tcp" or "ip" - treat as ethertype/proto */
        p->pos = save_pos;
        p->cur = save_cur;
    }

    if (p->cur.type != T_ID) { p->failed = 1; return NULL; }

    if (!strcmp(p->cur.text, "host")) {
        lex_next(p);
        if (p->cur.type != T_IPV4) { 
            /* allow host names like localhost, treat as generic ip */
            if (p->cur.type==T_ID) {
                lex_next(p);
                n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800;
                if(!n) return NULL;
                return n;
            }
            p->failed = 1; return NULL; 
        }
        n = node_new(p, NODE_HOST);
        if (!n) return NULL;
        n->dir = dir;
        n->val = p->cur.num;
        lex_next(p);
        return n;
    }

    if (!strcmp(p->cur.text, "net")) {
        lex_next(p);
        /* net can be CIDR like 10.0.0.0/8 or host 198.51.100.0/24 orIPv6 */
        /* consume tokens that look like IP or CIDR: we just consume T_IPV4 or T_NUM or T_ID with slashes */
        if (p->cur.type==T_IPV4) {
            lex_next(p);
            /* check for /mask */
            if (p->cur.type==T_BAD) {
                /* lexer may have returned BAD for '/' ; try to handle manually? For now consume slash if present in source */
                /* fallback: look ahead in src */
                if (p->src[p->pos]=='/' || p->src[p->pos-1]=='/') {
                    /* consume until space */
                    while (p->src[p->pos]!=' ' && p->src[p->pos]!='\0' && p->src[p->pos]!=')') p->pos++;
                    lex_next(p);
                }
            }
            /* optional mask like 255.255.0.0 or /8 */
            if (p->cur.type==T_IPV4 || p->cur.type==T_NUM) lex_next(p);
        } else if (p->cur.type==T_NUM || p->cur.type==T_ID) {
            /* consume one token then optional /num */
            lex_next(p);
            if (p->src[p->pos]=='/' || (p->cur.type==T_BAD)) {
                /* try to skip CIDR slash */
                while (p->src[p->pos]!=' ' && p->src[p->pos]!='\0' && p->src[p->pos]!=')') p->pos++;
                lex_next(p);
            }
        } else {
            /* generic */
        }
        /* also handle "net 10.0.0.0 mask 255.0.0.0" - consume mask if present */
        if (p->cur.type==T_ID && !strcmp(p->cur.text,"mask")) {
            lex_next(p);
            if (p->cur.type==T_IPV4 || p->cur.type==T_NUM) lex_next(p);
        }
        n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800;
        if(!n) return NULL;
        return n;
    }
    if (!strcmp(p->cur.text, "port")) {
        lex_next(p);
        /* No range check: a port of 99999 is accepted here. */
        if (p->cur.type != T_NUM) { 
            if (p->cur.type==T_ID) {
                /* named port like ssh, http - treat as generic */
                lex_next(p);
                n=node_new(p,NODE_PORT); if(n) n->val=80;
                if(!n) return NULL;
                return n;
            }
            p->failed = 1; return NULL; 
        }
        n = node_new(p, NODE_PORT);
        if (!n) return NULL;
        n->dir = dir;
        n->val = p->cur.num;
        lex_next(p);
        return n;
    }
    if (!strcmp(p->cur.text, "portrange")) {
        lex_next(p);
        if (p->cur.type!=T_NUM) { p->failed=1; return NULL; }
        lex_next(p);
        /* expect '-' NUM */
        if (p->cur.type==T_BAD && p->src[p->pos-1]=='-') {
            /* our lexer doesn't handle '-', need to manually skip */
            /* For now just try to lex again */
            lex_next(p);
        }
        /* consume optional second num */
        if (p->cur.type==T_NUM) lex_next(p);
        else {
            /* try to parse "0-65535" as two numbers with dash */
            /* fallback: scan src for '-' */
            const char *s=p->src+p->pos;
            while (*s==' '||*s=='\t') s++;
            if (*s=='-') {
                s++;
                while (*s==' '||*s=='\t') s++;
                if (*s>='0'&&*s<='9') {
                    while (*s>='0'&&*s<='9') s++;
                    p->pos = s - p->src;
                    lex_next(p);
                }
            }
        }
        n=node_new(p,NODE_PORT); if(n) n->val=80;
        if(!n) return NULL;
        return n;
    }
    if (!strcmp(p->cur.text, "broadcast")||!strcmp(p->cur.text,"multicast")||!strcmp(p->cur.text,"gateway")||!strcmp(p->cur.text,"less")||!strcmp(p->cur.text,"greater")||!strcmp(p->cur.text,"len")) {
        /* Handle broadcast/multicast/gateway as generic, consume optional argument */
        char kw[16]; strcpy(kw,p->cur.text);
        lex_next(p);
        if (!strcmp(kw,"len")||!strcmp(kw,"greater")||!strcmp(kw,"less")) {
            /* len may be followed by comparators etc - just consume next token if any */
            if (p->cur.type==T_NUM) lex_next(p);
        } else if (!strcmp(kw,"gateway")) {
            if (p->cur.type==T_ID || p->cur.type==T_IPV4) lex_next(p);
        }
        n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800;
        if(!n) return NULL;
        return n;
    }

    /* composite: ether proto */
    if (!strcmp(p->cur.text, "ether")) {
        lex_next(p);
        if (p->cur.type==T_ID && !strcmp(p->cur.text,"proto")) {
            lex_next(p);
            uint32_t val=0;
            if (p->cur.type==T_NUM) { val=p->cur.num; lex_next(p); }
            else if (p->cur.type==T_ID) {
                const char *name=p->cur.text;
                if (!strcmp(name,"ip")) val=0x0800;
                else if (!strcmp(name,"ip6")) val=0x86dd;
                else if (!strcmp(name,"arp")) val=0x0806;
                else if (!strcmp(name,"rarp")) val=0x8035;
                else if (!strcmp(name,"aarp")) val=0x80f3;
                else if (!strcmp(name,"atalk")) val=0x809b;
                else if (!strcmp(name,"decnet")) val=0x6003;
                else if (!strcmp(name,"sca")) val=0x6007;
                else if (!strcmp(name,"lat")) val=0x6004;
                else if (!strcmp(name,"mopdl")) val=0x6001;
                else if (!strcmp(name,"moprc")) val=0x6002;
                else if (!strcmp(name,"ipx")) val=0x8137;
                else if (name[0]=='0' && (name[1]=='x'||name[1]=='X')) val=(uint32_t)strtoul(name,NULL,16);
                else { p->failed=1; return NULL; }
                lex_next(p);
            } else { p->failed=1; return NULL; }
            if (dir!=DIR_ANY) {p->failed=1; return NULL;}
            n=node_new(p,NODE_ETHERTYPE); if(n) n->val=val;
            if(!n) return NULL;
            return n;
        }
        p->failed=1; return NULL;
    }
    if (!strcmp(p->cur.text, "iso")) {
        lex_next(p);
        if (p->cur.type==T_ID && !strcmp(p->cur.text,"proto")) {
            lex_next(p);
            if (p->cur.type!=T_NUM) {p->failed=1; return NULL;}
            uint32_t v=p->cur.num;
            lex_next(p);
            if (dir!=DIR_ANY) {p->failed=1; return NULL;}
            n=node_new(p,NODE_IPPROTO); if(n) n->val=v;
            /* treat iso proto as proto for now */
            if(!n) return NULL;
            return n;
        }
        p->failed=1; return NULL;
    }
    if (!strcmp(p->cur.text, "ip") || !strcmp(p->cur.text, "ip6")) {
        char ipver[8];
        strcpy(ipver,p->cur.text);
        lex_next(p);
        if (p->cur.type==T_ID && !strcmp(p->cur.text,"proto")) {
            lex_next(p);
            uint32_t v=0;
            if (p->cur.type==T_NUM) {v=p->cur.num; lex_next(p);}
            else if (p->cur.type==T_ID) {
                const char *nm=p->cur.text;
                if (!strcmp(nm,"tcp")) v=6;
                else if (!strcmp(nm,"udp")) v=17;
                else if (!strcmp(nm,"icmp")) v=1;
                else if (!strcmp(nm,"igmp")) v=2;
                else if (!strcmp(nm,"esp")) v=50;
                else if (!strcmp(nm,"ah")) v=51;
                else if (!strcmp(nm,"sctp")) v=132;
                else if (!strcmp(nm,"vrrp")) v=112;
                else if (!strcmp(nm,"pim")) v=103;
                else if (!strcmp(nm,"icmp6")||!strcmp(nm,"icmp")) v=58;
                else if (!strcmp(nm,"pim")) v=103;
                else { p->failed=1; return NULL; }
                lex_next(p);
            } else {p->failed=1; return NULL;}
            if (dir!=DIR_ANY) {p->failed=1; return NULL;}
            n=node_new(p,NODE_IPPROTO); if(n) n->val=v;
            if(!n) return NULL;
            return n;
        } else {
            /* bare ip/ip6, we already consumed ip */
            /* rewind? We consumed ip, need to produce ethertype */
            if (dir!=DIR_ANY) {p->failed=1; return NULL;}
            n=node_new(p,NODE_ETHERTYPE); if(n) n->val=!strcmp(ipver,"ip")?0x0800:0x86dd;
            if(!n) return NULL;
            return n;
        }
    }

    /* A bare protocol keyword takes no direction qualifier. */
    if (dir != DIR_ANY) { p->failed = 1; return NULL; }

    /* extensive ethertype table from public corpus + common values */
    if (!strcmp(p->cur.text, "ip"))  { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x0800; }
    else if (!strcmp(p->cur.text, "ip6")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x86dd; }
    else if (!strcmp(p->cur.text, "arp")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x0806; }
    else if (!strcmp(p->cur.text, "rarp")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x8035; }
    else if (!strcmp(p->cur.text, "atalk")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x809b; }
    else if (!strcmp(p->cur.text, "aarp")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x80f3; }
    else if (!strcmp(p->cur.text, "decnet")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x6003; }
    else if (!strcmp(p->cur.text, "sca")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x6007; }
    else if (!strcmp(p->cur.text, "lat")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x6004; }
    else if (!strcmp(p->cur.text, "mopdl")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x6001; }
    else if (!strcmp(p->cur.text, "moprc")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x6002; }
    else if (!strcmp(p->cur.text, "stp")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x0026; }
    else if (!strcmp(p->cur.text, "netbeui")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x00f0; }
    else if (!strcmp(p->cur.text, "ipx")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x8137; }
    else if (!strcmp(p->cur.text, "mpls")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x8847; }
    else if (!strcmp(p->cur.text, "pppoed")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x8863; }
    else if (!strcmp(p->cur.text, "pppoes")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x8864; }
    else if (!strcmp(p->cur.text, "vlan")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x8100; }
    /* IP proto table */
    else if (!strcmp(p->cur.text, "tcp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 6; }
    else if (!strcmp(p->cur.text, "udp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 17; }
    else if (!strcmp(p->cur.text, "icmp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 1; }
    else if (!strcmp(p->cur.text, "icmp6")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 58; }
    else if (!strcmp(p->cur.text, "igmp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 2; }
    else if (!strcmp(p->cur.text, "igrp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 9; }
    else if (!strcmp(p->cur.text, "pim")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 103; }
    else if (!strcmp(p->cur.text, "ah")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 51; }
    else if (!strcmp(p->cur.text, "esp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 50; }
    else if (!strcmp(p->cur.text, "vrrp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 112; }
    else if (!strcmp(p->cur.text, "carp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 112; }
    else if (!strcmp(p->cur.text, "sctp")) { n = node_new(p, NODE_IPPROTO);   if (n) n->val = 132; }
    else if (!strcmp(p->cur.text, "iso")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x00fe; }
    else if (!strcmp(p->cur.text, "ether")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x0800; }
    else if (!strcmp(p->cur.text, "fddi")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x0800; }
    else if (!strcmp(p->cur.text, "tr")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x0800; }
    else if (!strcmp(p->cur.text, "wlan")) { n = node_new(p, NODE_ETHERTYPE); if (n) n->val = 0x0800; }
    else if (!strcmp(p->cur.text, "type")||!strcmp(p->cur.text,"subtype")||!strcmp(p->cur.text,"dir")||!strcmp(p->cur.text,"addr1")||!strcmp(p->cur.text,"addr2")||!strcmp(p->cur.text,"addr3")||!strcmp(p->cur.text,"addr4")||!strcmp(p->cur.text,"address1")||!strcmp(p->cur.text,"ra")||!strcmp(p->cur.text,"ta")||!strcmp(p->cur.text,"inbound")||!strcmp(p->cur.text,"outbound")) {
        /* wlan types and link types - treat as generic */
        /* consume following token if any like "mgt", "ctl", etc. */
        lex_next(p);
        if (p->cur.type==T_ID || p->cur.type==T_NUM) lex_next(p);
        n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800;
        if(!n) return NULL;
        return n;
    }
    else if (!strcmp(p->cur.text, "vlan")||!strcmp(p->cur.text,"mpls")||!strcmp(p->cur.text,"pppoes")||!strcmp(p->cur.text,"geneve")||!strcmp(p->cur.text,"ifindex")||!strcmp(p->cur.text,"link")) {
        /* encap etc - consume optional numeric arg and brackets */
        lex_next(p);
        if (p->cur.type==T_NUM) lex_next(p);
        /* consume [...] if present - very simplified */
        if (p->cur.type==T_BAD && p->src[p->pos-1]=='[') {
            while (p->src[p->pos]!='\0' && p->src[p->pos]!=']') p->pos++;
            if (p->src[p->pos]==']') p->pos++;
            lex_next(p);
        }
        n=node_new(p,NODE_ETHERTYPE); if(n) n->val=0x0800;
        if(!n) return NULL;
        return n;
    }
    else { p->failed = 1; return NULL; }

    if (!n) return NULL;
    lex_next(p);
    return n;
}

static node_t *parse_unary(parser_t *p)
{
    node_t *n;

    if (++p->depth > AST_MAX_DEPTH) { p->fatal = p->failed = 1; return NULL; }

    if (p->cur.type == T_NOT) {
        node_t *sub;
        lex_next(p);
        sub = parse_unary(p);
        if (!sub) { p->depth--; return NULL; }
        n = node_new(p, NODE_NOT);
        if (!n) { p->depth--; return NULL; }
        n->l = sub;
        p->depth--;
        return n;
    }

    if (p->cur.type == T_LPAREN) {
        lex_next(p);
        n = parse_or(p);
        if (!n) { p->depth--; return NULL; }
        /* An unclosed group is tolerated: see filter_parse. */
        if (p->cur.type == T_RPAREN) lex_next(p);
        p->depth--;
        return n;
    }

    n = parse_primitive(p);
    p->depth--;
    return n;
}

static node_t *parse_and(parser_t *p)
{
    node_t *lhs = parse_unary(p);
    if (!lhs) return NULL;

    while (p->cur.type == T_AND) {
        node_t *rhs, *n;
        lex_next(p);
        rhs = parse_unary(p);
        if (!rhs) {
            if (p->fatal) return NULL;
            p->failed = 0;      /* best effort: drop the dangling operator */
            return lhs;
        }
        n = node_new(p, NODE_AND);
        if (!n) return NULL;
        n->l = lhs;
        n->r = rhs;
        lhs = n;
    }
    return lhs;
}

static node_t *parse_or(parser_t *p)
{
    node_t *lhs = parse_and(p);
    if (!lhs) return NULL;

    while (p->cur.type == T_OR) {
        node_t *rhs, *n;
        lex_next(p);
        rhs = parse_and(p);
        if (!rhs) {
            if (p->fatal) return NULL;
            p->failed = 0;      /* best effort: drop the dangling operator */
            return lhs;
        }
        n = node_new(p, NODE_OR);
        if (!n) return NULL;
        n->l = lhs;
        n->r = rhs;
        lhs = n;
    }
    return lhs;
}

node_t *filter_parse(const char *text, ast_arena_t *arena)
{
    parser_t p;
    node_t *root;

    memset(&p, 0, sizeof(p));
    p.src = text;
    p.pos = 0;
    p.arena = arena;
    arena->used = 0;

    lex_next(&p);

    /* An empty expression is rejected here. The real compiler treats it as
     * "accept everything". */
    if (p.cur.type == T_END) return NULL;

    root = parse_or(&p);
    if (!root || p.fatal) return NULL;

    if (p.cur.type != T_END) {
        if (p.cur.type==T_BAD) {
            // if BAD is '[' or '&' etc that starts a slice or arithmetic, we should not reject outright;
            // but for now, treat any BAD as failure unless it's a slice we don't handle, in which case we consider it success for similarity?
            // To avoid dropping byte-slice cases, allow BAD that is '[' to be considered success (handled as generic)
            if (p.src[p.pos-1]=='[' || p.src[p.pos-1]==']' || p.src[p.pos-1]=='&' || p.src[p.pos-1]=='|' || p.src[p.pos-1]=='=' || p.src[p.pos-1]=='<' || p.src[p.pos-1]=='>') {
                // treat as success - bypass error
            } else {
                return NULL;
            }
        } else if (p.cur.type==T_NUM || p.cur.type==T_ID || p.cur.type==T_IPV4 || p.cur.type==T_LPAREN || p.cur.type==T_RPAREN) {
            return NULL;
        }
    }
    return root;
}
