#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include "normalize.h"
#include <regex.h>

static int is_word_char(unsigned char c){ return isalnum(c) || c=='_'; }

static void repl_mac(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++;
            continue;
        }
        // try match MAC via manual
        size_t j=i;
        int ok=1;
        int groups=0;
        size_t k=i;
        // quick check: need to see if we have pattern of 6 groups
        // Instead use manual: try to parse 6 groups
        size_t temp=i;
        int match=0;
        size_t end_pos=0;
        // Use a helper: check if substring starting at i matches MAC regex
        // We'll attempt to match via scanning
        {
            size_t p=temp;
            int valid=1;
            for(int g=0; g<6; g++){
                size_t cnt=0;
                size_t q=p;
                while(q<n && cnt<2 && ((buf[q]>='0'&&buf[q]<='9')||(buf[q]>='a'&&buf[q]<='f')||(buf[q]>='A'&&buf[q]<='F'))){ q++; cnt++; }
                if(cnt==0){ valid=0; break; }
                if(g<5){
                    if(q>=n || buf[q]!=':'){ valid=0; break; }
                    q++;
                } else {
                    // last group: check after not word
                    if(q<n && is_word_char((unsigned char)buf[q])){ valid=0; break; }
                    // success
                    end_pos=q;
                    match=1;
                    break;
                }
                p=q;
            }
            if(!valid) match=0;
        }
        if(match){
            // check before ok (already) and after ok (already)
            int before_ok = (i==0 || !is_word_char((unsigned char)buf[i-1]));
            int after_ok = (end_pos>=n || !is_word_char((unsigned char)buf[end_pos]));
            if(before_ok && after_ok){
                const char *repl="ETHERHOST";
                size_t rl=strlen(repl);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=end_pos;
                continue;
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_hex(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(buf[i]=='0' && i+1<n && (buf[i+1]=='x' || buf[i+1]=='X')){
            size_t j=i+2;
            size_t cnt=0;
            while(j<n && ((buf[j]>='0'&&buf[j]<='9')||(buf[j]>='a'&&buf[j]<='f')||(buf[j]>='A'&&buf[j]<='F'))){ j++; cnt++; }
            if(cnt>0){
                int before_ok = (i==0 || !is_word_char((unsigned char)buf[i-1]));
                int after_ok = (j>=n || !is_word_char((unsigned char)buf[j]));
                if(before_ok && after_ok){
                    const char *repl="HEX";
                    size_t rl=strlen(repl);
                    if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                    i=j;
                    continue;
                }
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_hex_inner(char *inner, size_t sz){
    repl_hex(inner);
    // then NUM inside
    // Do NUM replacement inside bracket inner
    char out[4096]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(inner);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)inner[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=inner[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(isdigit((unsigned char)inner[i])){
            size_t j=i;
            while(j<n && isdigit((unsigned char)inner[j])) j++;
            int before_ok = (i==0 || !is_word_char((unsigned char)inner[i-1]));
            int after_ok = (j>=n || !is_word_char((unsigned char)inner[j]));
            if(before_ok && after_ok){
                const char *repl="NUM";
                size_t rl=3;
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=j;
                continue;
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=inner[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(inner, out, sz-1);
    inner[sz-1]='\0';
}

static void repl_brack(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(buf[i]=='['){
            char *close = strchr(buf+i+1, ']');
            if(close){
                size_t j = close - buf;
                char inner[4096];
                size_t ilen = j - (i+1);
                if(ilen >= sizeof(inner)) ilen = sizeof(inner)-1;
                memcpy(inner, buf+i+1, ilen);
                inner[ilen]='\0';
                repl_hex_inner(inner, sizeof(inner));
                // copy '[' + inner + ']'
                if(out_len+1 < sizeof(out)){ out[out_len++]='['; out[out_len]='\0'; }
                size_t rl=strlen(inner);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, inner); out_len+=rl; }
                if(out_len+1 < sizeof(out)){ out[out_len++]=']'; out[out_len]='\0'; }
                i=j+1;
                continue;
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_ipv4(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        size_t j=i;
        int ok=1;
        for(int p=0;p<4;p++){
            size_t k=j;
            size_t cnt=0;
            while(k<n && isdigit((unsigned char)buf[k])){ k++; cnt++; }
            if(cnt==0 || cnt>3){ ok=0; break; }
            j=k;
            if(p<3){
                if(j>=n || buf[j]!='.'){ ok=0; break; }
                j++;
            } else {
                if(j<n && buf[j]=='/'){
                    size_t kk=j+1;
                    size_t cnt2=0;
                    while(kk<n && isdigit((unsigned char)buf[kk])){ kk++; cnt2++; }
                    if(cnt2>0) j=kk;
                }
                if(j<n && is_word_char((unsigned char)buf[j])){ ok=0; break; }
                if(ok){
                    const char *repl="IPV4";
                    size_t rl=4;
                    if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                    i=j;
                    break;
                } else {
                    ok=0; break;
                }
            }
        }
        if(ok && out_len>=4 && strncmp(out+out_len-4, "IPV4",4)==0){
            continue;
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_ipv6(char *buf, size_t sz){
    // Use POSIX regex for two patterns
    regex_t re1, re2;
    regcomp(&re1, "[0-9a-fA-F:]*::[0-9a-fA-F:]+", REG_EXTENDED);
    regcomp(&re2, "([0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F:]*", REG_EXTENDED);
    char tmp[8192];
    strncpy(tmp, buf, sizeof(tmp)-1);
    tmp[sizeof(tmp)-1]='\0';
    char out[8192]="";
    size_t out_len=0;
    // first pattern
    {
        const char *p=tmp;
        regmatch_t m;
        char inter[8192]="";
        size_t inter_len=0;
        // We'll process p iteratively
        char cur[8192];
        strncpy(cur, tmp, sizeof(cur)-1);
        cur[sizeof(cur)-1]='\0';
        char next[8192]="";
        // For simplicity, apply regex globally with manual boundary checks
        // First pass for re1
        char stage1[8192]="";
        size_t s1_len=0;
        const char *q=cur;
        while(regexec(&re1, q, 1, &m, 0)==0){
            int so=m.rm_so;
            int eo=m.rm_eo;
            // copy before
            if(so>0){
                if(s1_len+so < sizeof(stage1)){ strncat(stage1, q, so); s1_len+=so; }
            }
            // check boundaries
            char first = q[so];
            char last = q[eo-1];
            char prev = (so>0)? q[so-1]: 0;
            char nxt = q[eo];
            int is_first_word = is_word_char((unsigned char)first);
            int is_last_word = is_word_char((unsigned char)last);
            int is_prev_word = (so>0)? is_word_char((unsigned char)prev):0;
            int is_next_word = (nxt!='\0')? is_word_char((unsigned char)nxt):0;
            int before_ok, after_ok;
            if(so==0) before_ok = is_first_word;
            else before_ok = (is_first_word != is_prev_word);
            if(q[eo]=='\0') after_ok = is_last_word;
            else after_ok = (is_last_word != is_next_word);
            if(before_ok && after_ok){
                const char *repl="IPV6";
                size_t rl=4;
                if(s1_len+rl < sizeof(stage1)){ strcpy(stage1+s1_len, repl); s1_len+=rl; }
            } else {
                if(s1_len+ (eo-so) < sizeof(stage1)){ strncat(stage1, q+so, eo-so); s1_len+=eo-so; }
            }
            q+=eo;
        }
        if(*q){
            if(s1_len+strlen(q) < sizeof(stage1)){ strcpy(stage1+s1_len, q); }
        }
        // second pattern on stage1
        char stage2[8192]="";
        size_t s2_len=0;
        q=stage1;
        while(regexec(&re2, q, 1, &m, 0)==0){
            int so=m.rm_so;
            int eo=m.rm_eo;
            if(so>0){
                if(s2_len+so < sizeof(stage2)){ strncat(stage2, q, so); s2_len+=so; }
            }
            char first = q[so];
            char last = q[eo-1];
            char prev = (so>0)? q[so-1]:0;
            char nxt = q[eo];
            int is_first_word = is_word_char((unsigned char)first);
            int is_last_word = is_word_char((unsigned char)last);
            int is_prev_word = (so>0)? is_word_char((unsigned char)prev):0;
            int is_next_word = (nxt!='\0')? is_word_char((unsigned char)nxt):0;
            int before_ok, after_ok;
            if(so==0) before_ok = is_first_word;
            else before_ok = (is_first_word != is_prev_word);
            if(q[eo]=='\0') after_ok = is_last_word;
            else after_ok = (is_last_word != is_next_word);
            if(before_ok && after_ok){
                const char *repl="IPV6";
                size_t rl=4;
                if(s2_len+rl < sizeof(stage2)){ strcpy(stage2+s2_len, repl); s2_len+=rl; }
            } else {
                if(s2_len+ (eo-so) < sizeof(stage2)){ strncat(stage2, q+so, eo-so); s2_len+=eo-so; }
            }
            q+=eo;
        }
        if(*q){
            if(s2_len+strlen(q) < sizeof(stage2)){ strcpy(stage2+s2_len, q); }
        }
        strncpy(buf, stage2, sz-1);
        buf[sz-1]='\0';
    }
    regfree(&re1);
    regfree(&re2);
}

static void repl_num(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(isdigit((unsigned char)buf[i])){
            size_t j=i;
            while(j<n && isdigit((unsigned char)buf[j])) j++;
            int before_ok = (i==0 || !is_word_char((unsigned char)buf[i-1]));
            int after_ok = (j>=n || !is_word_char((unsigned char)buf[j]));
            if(before_ok && after_ok){
                const char *repl="NUM";
                size_t rl=3;
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=j;
                continue;
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_host_net(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    const char *keywords[]={"host","net","gateway",NULL};
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        int matched=0;
        for(int k=0; keywords[k]; k++){
            const char *kw=keywords[k];
            size_t kl=strlen(kw);
            if(strncmp(buf+i, kw, kl)==0 && (i+kl>=n || !is_word_char((unsigned char)buf[i+kl]))){
                size_t j=i+kl;
                size_t kk=j;
                while(kk<n && (buf[kk]==' '||buf[kk]=='\t')) kk++;
                if(kk>=n){
                    size_t rl=kl;
                    if(out_len+rl < sizeof(out)){ strncpy(out+out_len, kw, rl); out_len+=rl; out[out_len]='\0'; }
                    i=j;
                    matched=1;
                    break;
                }
                size_t l=kk;
                while(l<n && buf[l]!=' '&&buf[l]!='\t'&&buf[l]!='\n'&&buf[l]!='\r') l++;
                char tok[256];
                size_t tlen=l-kk;
                if(tlen>=sizeof(tok)) tlen=sizeof(tok)-1;
                memcpy(tok, buf+kk, tlen);
                tok[tlen]='\0';
                const char *repl;
                char tmp[256];
                if(strcmp(tok,"IPV4")==0||strcmp(tok,"IPV6")==0||strcmp(tok,"NUM")==0||strcmp(tok,"HEX")==0||strcmp(tok,"ETHERHOST")==0){
                    snprintf(tmp,sizeof(tmp),"%s %s",kw,tok);
                    repl=tmp;
                } else {
                    snprintf(tmp,sizeof(tmp),"%s HOST",kw);
                    repl=tmp;
                }
                size_t rl=strlen(repl);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=l;
                matched=1;
                break;
            }
        }
        if(matched) continue;
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_ether_host(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"ether",5)==0 && (i+5>=n || !is_word_char((unsigned char)buf[i+5]))){
            size_t j=i+5;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            const char *subs[]={"host","src","dst",NULL};
            int found=0;
            for(int s=0; subs[s]; s++){
                const char *sub=subs[s];
                size_t sl=strlen(sub);
                if(strncmp(buf+k, sub, sl)==0 && (k+sl>=n || !is_word_char((unsigned char)buf[k+sl]))){
                    size_t l=k+sl;
                    size_t m=l;
                    while(m<n && (buf[m]==' '||buf[m]=='\t')) m++;
                    if(m>=n){
                        size_t rl=l-i;
                        if(out_len+rl < sizeof(out)){ strncpy(out+out_len, buf+i, rl); out_len+=rl; out[out_len]='\0'; }
                        i=l;
                        found=1;
                        break;
                    }
                    size_t p=m;
                    while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++;
                    char tok[256];
                    size_t tlen=p-m;
                    if(tlen>=sizeof(tok)) tlen=sizeof(tok)-1;
                    memcpy(tok, buf+m, tlen);
                    tok[tlen]='\0';
                    char repl[256];
                    if(strcmp(tok,"IPV4")==0||strcmp(tok,"NUM")==0||strcmp(tok,"HEX")==0||strcmp(tok,"ETHERHOST")==0||strcmp(tok,"IPV6")==0){
                        snprintf(repl,sizeof(repl),"ether %s %s",sub,tok);
                    } else {
                        snprintf(repl,sizeof(repl),"ether %s HOST",sub);
                    }
                    size_t rl=strlen(repl);
                    if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                    i=p;
                    found=1;
                    break;
                }
            }
            if(found) continue;
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_port(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"port",4)==0 && (i+4>=n || !is_word_char((unsigned char)buf[i+4]))){
            size_t j=i+4;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            if(k>=n){
                size_t rl=4;
                if(out_len+rl < sizeof(out)){ strncpy(out+out_len,"port",rl); out_len+=rl; out[out_len]='\0'; }
                i=j;
                continue;
            }
            if(k+3<=n && strncmp(buf+k,"NUM",3)==0){
                const char *repl="port PORT";
                size_t rl=strlen(repl);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=k+3;
                continue;
            }
            if(k+4<=n && strncmp(buf+k,"HOST",4)==0){
                const char *repl="port PORT";
                size_t rl=strlen(repl);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=k+4;
                continue;
            }
            size_t l=k;
            while(l<n && buf[l]!=' '&&buf[l]!='\t'&&buf[l]!='\n'&&buf[l]!='\r') l++;
            const char *repl="port PORT";
            size_t rl=strlen(repl);
            if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
            i=l;
            continue;
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_portrange(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"portrange",9)==0 && (i+9>=n || !is_word_char((unsigned char)buf[i+9]))){
            size_t j=i+9;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            size_t l=k;
            while(l<n && (isalnum((unsigned char)buf[l])||buf[l]=='_'||buf[l]=='-'||buf[l]==':')) l++;
            if(l>k){
                const char *repl="portrange RANGE";
                size_t rl=strlen(repl);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=l;
                continue;
            } else {
                size_t rl=9;
                if(out_len+rl < sizeof(out)){ strncpy(out+out_len,"portrange",rl); out_len+=rl; out[out_len]='\0'; }
                i=j;
                continue;
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_ether_proto(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"ether",5)==0 && (i+5>=n || !is_word_char((unsigned char)buf[i+5]))){
            size_t j=i+5;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            if(k+5<=n && strncmp(buf+k,"proto",5)==0 && (k+5>=n || !is_word_char((unsigned char)buf[k+5]))){
                size_t l=k+5;
                size_t m=l;
                while(m<n && (buf[m]==' '||buf[m]=='\t')) m++;
                if(m<n && buf[m]!=' '&&buf[m]!='\t'&&buf[m]!='\n'&&buf[m]!='\r'){
                    size_t p=m;
                    while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++;
                    const char *repl="ether proto PROTO";
                    size_t rl=strlen(repl);
                    if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                    i=p;
                    continue;
                }
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_ip_proto(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"ip",2)==0 && (i+2>=n || !is_word_char((unsigned char)buf[i+2]))){
            // ensure not ip6
            if(i+3<n && buf[i+3]!=' ' && is_word_char((unsigned char)buf[i+3])){ // part of longer word like ip6
                // This check is not needed because we already checked next char not word, so ip6 would be 3 chars, not 2
            }
            size_t j=i+2;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            if(k+5<=n && strncmp(buf+k,"proto",5)==0 && (k+5>=n || !is_word_char((unsigned char)buf[k+5]))){
                size_t l=k+5;
                size_t m=l;
                while(m<n && (buf[m]==' '||buf[m]=='\t')) m++;
                if(m<n && buf[m]!=' '&&buf[m]!='\t'&&buf[m]!='\n'&&buf[m]!='\r'){
                    size_t p=m;
                    while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++;
                    const char *repl="ip proto PROTO";
                    size_t rl=strlen(repl);
                    if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                    i=p;
                    continue;
                }
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_ip6_proto(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"ip6",3)==0 && (i+3>=n || !is_word_char((unsigned char)buf[i+3]))){
            size_t j=i+3;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            if(k+5<=n && strncmp(buf+k,"proto",5)==0 && (k+5>=n || !is_word_char((unsigned char)buf[k+5]))){
                size_t l=k+5;
                size_t m=l;
                while(m<n && (buf[m]==' '||buf[m]=='\t')) m++;
                if(m<n && buf[m]!=' '&&buf[m]!='\t'&&buf[m]!='\n'&&buf[m]!='\r'){
                    size_t p=m;
                    while(p<n && buf[p]!=' '&&buf[p]!='\t'&&buf[p]!='\n'&&buf[p]!='\r') p++;
                    const char *repl="ip6 proto PROTO";
                    size_t rl=strlen(repl);
                    if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                    i=p;
                    continue;
                }
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_vlan(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"vlan",4)==0 && (i+4>=n || !is_word_char((unsigned char)buf[i+4]))){
            size_t j=i+4;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            if(k+3<=n && strncmp(buf+k,"NUM",3)==0 && (k+3>=n || !is_word_char((unsigned char)buf[k+3]))){
                const char *repl="vlan NUM";
                size_t rl=strlen(repl);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=k+3;
                continue;
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

static void repl_mpls(char *buf, size_t sz){
    char out[8192]="";
    size_t out_len=0;
    size_t i=0;
    size_t n=strlen(buf);
    while(i<n){
        if(i>0 && is_word_char((unsigned char)buf[i-1])){
            if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
            i++; continue;
        }
        if(strncmp(buf+i,"mpls",4)==0 && (i+4>=n || !is_word_char((unsigned char)buf[i+4]))){
            size_t j=i+4;
            size_t k=j;
            while(k<n && (buf[k]==' '||buf[k]=='\t')) k++;
            if(k+3<=n && strncmp(buf+k,"NUM",3)==0 && (k+3>=n || !is_word_char((unsigned char)buf[k+3]))){
                const char *repl="mpls NUM";
                size_t rl=strlen(repl);
                if(out_len+rl < sizeof(out)){ strcpy(out+out_len, repl); out_len+=rl; }
                i=k+3;
                continue;
            }
        }
        if(out_len+1 < sizeof(out)){ out[out_len++]=buf[i]; out[out_len]='\0'; }
        i++;
    }
    strncpy(buf, out, sz-1);
    buf[sz-1]='\0';
}

void normalize_filter(const char *in, char *out, size_t out_sz){
    char buf[8192];
    strncpy(buf, in, sizeof(buf)-1);
    buf[sizeof(buf)-1]='\0';
    repl_mac(buf, sizeof(buf));
    repl_hex(buf, sizeof(buf));
    repl_brack(buf, sizeof(buf));
    repl_ipv4(buf, sizeof(buf));
    repl_ipv6(buf, sizeof(buf));
    repl_num(buf, sizeof(buf));
    repl_host_net(buf, sizeof(buf));
    repl_ether_host(buf, sizeof(buf));
    repl_port(buf, sizeof(buf));
    repl_portrange(buf, sizeof(buf));
    repl_ether_proto(buf, sizeof(buf));
    repl_ip_proto(buf, sizeof(buf));
    repl_ip6_proto(buf, sizeof(buf));
    repl_vlan(buf, sizeof(buf));
    repl_mpls(buf, sizeof(buf));
    // whitespace collapse
    char ws[8192]="";
    size_t wi=0;
    int in_space=1;
    for(size_t i=0; buf[i]; i++){
        if(buf[i]==' '||buf[i]=='\t'||buf[i]=='\n'||buf[i]=='\r'){
            if(!in_space){
                if(wi+1 < sizeof(ws)){ ws[wi++]=' '; ws[wi]='\0'; }
                in_space=1;
            }
        } else {
            if(wi+1 < sizeof(ws)){ ws[wi++]=buf[i]; ws[wi]='\0'; }
            in_space=0;
        }
    }
    // trim
    size_t start=0;
    while(ws[start]==' ') start++;
    size_t end=strlen(ws);
    while(end>start && ws[end-1]==' ') end--;
    ws[end]='\0';
    strncpy(out, ws+start, out_sz-1);
    out[out_sz-1]='\0';
}
