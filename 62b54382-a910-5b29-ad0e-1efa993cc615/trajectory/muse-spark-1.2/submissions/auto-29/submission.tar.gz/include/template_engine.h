#pragma once
#include <stdint.h>
#include <stddef.h>
#include "bpf_defs.h"
#include "jsonio.h"

int template_try(const bpfc_case_t *c, bpf_prog_t *out, const char **err);
void normalize_filter(const char *in, char *out, size_t out_len);
int extract_values(const char *filter, uint32_t *vals, int max_vals);
