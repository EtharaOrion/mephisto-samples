/*
 * gen3.c - arithmetic expressions and the remaining primitives.
 */
#include <stdio.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"

extern bexp_t gen_ipfrag(cstate_t *cs);
extern bexp_t gen_proto(cstate_t *cs, uint32_t v, int proto, int dir);

/* ------------------------------------------------------------- utilities */

int parse_ether(const char *s, uint8_t *out)
{
    int i;
    unsigned v;
    const char *p = s;

    for (i = 0; i < 6; i++) {
        v = 0;
        if (!((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') ||
              (*p >= 'A' && *p <= 'F')))
            return 0;
        while ((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') ||
               (*p >= 'A' && *p <= 'F')) {
            unsigned d = (*p <= '9') ? (unsigned)(*p - '0')
                                     : (unsigned)((*p | 0x20) - 'a' + 10);
            v = v * 16 + d;
            p++;
        }
        if (v > 255) return 0;
        out[i] = (uint8_t)v;
        if (i < 5) {
            if (*p != ':' && *p != '.' && *p != '-') return 0;
            p++;
        }
    }
    return *p == '\0';
}

int parse_ip6(const char *s, uint8_t *out)
{
    uint16_t words[8];
    int nw = 0, gap = -1;
    const char *p = s;

    memset(out, 0, 16);
    if (p[0] == ':' && p[1] == ':') { gap = 0; p += 2; }
    while (*p) {
        unsigned v = 0;
        int nd = 0;
        const char *start = p;
        while ((*p >= '0' && *p <= '9') || ((*p | 0x20) >= 'a' && (*p | 0x20) <= 'f')) {
            unsigned d = (*p <= '9') ? (unsigned)(*p - '0')
                                     : (unsigned)((*p | 0x20) - 'a' + 10);
            v = v * 16 + d;
            nd++;
            p++;
            if (nd > 4) return 0;
        }
        if (nd == 0) return 0;
        if (*p == '.') {
            /* embedded IPv4 */
            unsigned b[4];
            int i;
            p = start;
            for (i = 0; i < 4; i++) {
                unsigned x = 0;
                int n2 = 0;
                while (*p >= '0' && *p <= '9') { x = x * 10 + (unsigned)(*p - '0'); p++; n2++; }
                if (n2 == 0 || x > 255) return 0;
                b[i] = x;
                if (i < 3) { if (*p != '.') return 0; p++; }
            }
            if (nw > 6) return 0;
            words[nw++] = (uint16_t)((b[0] << 8) | b[1]);
            words[nw++] = (uint16_t)((b[2] << 8) | b[3]);
            break;
        }
        if (nw >= 8) return 0;
        words[nw++] = (uint16_t)v;
        if (*p == ':') {
            p++;
            if (*p == ':') {
                if (gap >= 0) return 0;
                gap = nw;
                p++;
                if (*p == '\0') break;
            } else if (*p == '\0')
                return 0;
        } else if (*p != '\0')
            return 0;
    }
    if (gap < 0) {
        if (nw != 8) return 0;
    } else {
        int nafter = nw - gap, i;
        if (nw > 8) return 0;
        for (i = 0; i < nafter; i++)
            words[8 - nafter + i] = words[gap + i];
        for (i = gap; i < 8 - nafter; i++)
            words[i] = 0;
        nw = 8;
    }
    {
        int i;
        for (i = 0; i < 8; i++) {
            out[i*2] = (uint8_t)(words[i] >> 8);
            out[i*2+1] = (uint8_t)(words[i] & 0xff);
        }
    }
    return 1;
}

/* ------------------------------------------------------------ arithmetic */

static slist_t *xfer_to_x(cstate_t *cs, arth_t *a)
{
    slist_t *s = new_stmt(cs, BPF_LDX | BPF_MEM);
    s->s.k = (uint32_t)a->regno;
    return s;
}

static slist_t *xfer_to_a(cstate_t *cs, arth_t *a)
{
    slist_t *s = new_stmt(cs, BPF_LD | BPF_MEM);
    s->s.k = (uint32_t)a->regno;
    return s;
}

arth_t *gen_loadi(cstate_t *cs, uint32_t val)
{
    arth_t *a;
    slist_t *s;
    int reg = alloc_reg(cs);

    a = (arth_t *)arena_alloc(cs, sizeof(*a));
    s = new_stmt(cs, BPF_LD | BPF_IMM);
    s->s.k = val;
    s->next = new_stmt(cs, BPF_ST);
    s->next->s.k = (uint32_t)reg;
    a->s = s;
    a->regno = reg;
    a->has_b = 0;
    return a;
}

arth_t *gen_loadlen(cstate_t *cs)
{
    int reg = alloc_reg(cs);
    arth_t *a = (arth_t *)arena_alloc(cs, sizeof(*a));
    slist_t *s;

    s = new_stmt(cs, BPF_LD | BPF_LEN);
    s->next = new_stmt(cs, BPF_ST);
    s->next->s.k = (uint32_t)reg;
    a->s = s;
    a->regno = reg;
    a->has_b = 0;
    return a;
}

arth_t *gen_load(cstate_t *cs, int proto, arth_t *inst, uint32_t size)
{
    slist_t *s, *s2;
    bexp_t b;
    int have_b = 0;
    int regno = alloc_reg(cs);

    free_reg(cs, inst->regno);
    switch (size) {
    default:
        bpf_error(cs, "data size must be 1, 2, or 4");
    case 1: size = BPF_B; break;
    case 2: size = BPF_H; break;
    case 4: size = BPF_W; break;
    }

    switch (proto) {
    default:
        bpf_error(cs, "unsupported index operation");

    case Q_RADIO:
        if (cs->linktype != DLT_IEEE802_11_RADIO_AVS &&
            cs->linktype != DLT_IEEE802_11_RADIO &&
            cs->linktype != DLT_PRISM_HEADER)
            bpf_error(cs, "radio information not present in capture");
        s = xfer_to_x(cs, inst);
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->s.k = 0;
        sappend(s, s2);
        break;

    case Q_LINK:
        s = gen_abs_offset_varpart(cs, &cs->off_linkhdr);
        if (s != NULL) {
            sappend(s, xfer_to_a(cs, inst));
            sappend(s, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
            sappend(s, new_stmt(cs, BPF_MISC | BPF_TAX));
        } else {
            s = xfer_to_x(cs, inst);
        }
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->off_linkhdr.constant_part;
        sappend(s, s2);
        break;

    case Q_IP:
    case Q_ARP:
    case Q_RARP:
    case Q_ATALK:
    case Q_DECNET:
    case Q_SCA:
    case Q_LAT:
    case Q_MOPDL:
    case Q_MOPRC:
    case Q_IPV6:
        s = gen_abs_offset_varpart(cs, &cs->off_linkpl);
        if (s != NULL) {
            sappend(s, xfer_to_a(cs, inst));
            sappend(s, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
            sappend(s, new_stmt(cs, BPF_MISC | BPF_TAX));
        } else {
            s = xfer_to_x(cs, inst);
        }
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->off_linkpl.constant_part + cs->off_nl;
        sappend(s, s2);
        b = gen_proto_abbrev(cs, proto);
        have_b = 1;
        if (inst->has_b) b = bx_and(cs, inst->b, b);
        break;

    case Q_SCTP:
    case Q_TCP:
    case Q_UDP:
    case Q_ICMP:
    case Q_IGMP:
    case Q_IGRP:
    case Q_PIM:
    case Q_VRRP:
    case Q_CARP:
    case Q_ICMPV6:
    case Q_AH:
    case Q_ESP: {
        bexp_t bt, bf;
        s = gen_loadx_iphdrlen_pub(cs);
        sappend(s, xfer_to_a(cs, inst));
        sappend(s, new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X));
        sappend(s, new_stmt(cs, BPF_MISC | BPF_TAX));
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->off_linkpl.constant_part + cs->off_nl;
        sappend(s, s2);

        b = gen_linktype(cs, ETHERTYPE_IP);
        bt = gen_proto_abbrev(cs, proto);
        b = bx_and(cs, b, bt);
        bf = gen_ipfrag(cs);
        b = bx_and(cs, b, bf);
        have_b = 1;
        if (inst->has_b) b = bx_and(cs, inst->b, b);
        break;
    }
    }
    inst->regno = regno;
    s2 = new_stmt(cs, BPF_ST);
    s2->s.k = (uint32_t)regno;
    sappend(s, s2);
    sappend(inst->s, s);
    if (have_b) {
        inst->b = b;
        inst->has_b = 1;
    }
    return inst;
}

arth_t *gen_neg(cstate_t *cs, arth_t *a)
{
    slist_t *s;

    s = xfer_to_a(cs, a);
    sappend(a->s, s);
    s = new_stmt(cs, BPF_ALU | BPF_NEG);
    sappend(a->s, s);
    s = new_stmt(cs, BPF_ST);
    s->s.k = (uint32_t)a->regno;
    sappend(a->s, s);
    return a;
}

arth_t *gen_arth(cstate_t *cs, int code, arth_t *a0, arth_t *a1)
{
    slist_t *s0, *s1, *s2;

    s0 = xfer_to_x(cs, a1);
    s1 = xfer_to_a(cs, a0);
    s2 = new_stmt(cs, (uint16_t)(BPF_ALU | BPF_X | code));
    sappend(s1, s2);
    sappend(s0, s1);
    sappend(a1->s, s0);
    sappend(a0->s, a1->s);

    free_reg(cs, a0->regno);
    free_reg(cs, a1->regno);
    a0->regno = alloc_reg(cs);
    s2 = new_stmt(cs, BPF_ST);
    s2->s.k = (uint32_t)a0->regno;
    sappend(a0->s, s2);

    if (!a0->has_b && a1->has_b) {
        a0->b = a1->b;
        a0->has_b = 1;
    }
    return a0;
}

bexp_t gen_relation(cstate_t *cs, int code, arth_t *a0, arth_t *a1, int reversed)
{
    slist_t *s0, *s1, *s2;
    block_t *b;
    bexp_t e;

    s0 = xfer_to_x(cs, a1);
    s1 = xfer_to_a(cs, a0);
    if (code == BPF_JEQ) {
        s2 = new_stmt(cs, BPF_ALU | BPF_SUB | BPF_X);
        sappend(s1, s2);
        b = new_block(cs, BPF_JMP | BPF_JEQ | BPF_K);
        b->s.k = 0;
    } else {
        b = new_block(cs, (uint16_t)(BPF_JMP | code | BPF_X));
    }
    sappend(s0, s1);
    sappend(a1->s, s0);
    sappend(a0->s, a1->s);
    b->stmts = a0->s;

    free_reg(cs, a0->regno);
    free_reg(cs, a1->regno);

    e = bx_leaf_cs(cs, b);
    if (reversed)
        e = bx_not(e);
    if (a1->has_b)
        e = bx_and(cs, a1->b, e);
    if (a0->has_b)
        e = bx_and(cs, a0->b, e);
    return e;
}

/* --------------------------------------------------------- misc filters */

bexp_t gen_less(cstate_t *cs, uint32_t n)
{
    arth_t *a, *b;
    a = gen_loadlen(cs);
    b = gen_loadi(cs, n);
    return gen_relation(cs, BPF_JGT, a, b, 1);
}

bexp_t gen_greater(cstate_t *cs, uint32_t n)
{
    arth_t *a, *b;
    a = gen_loadlen(cs);
    b = gen_loadi(cs, n);
    return gen_relation(cs, BPF_JGE, a, b, 0);
}

bexp_t gen_byteop(cstate_t *cs, int op, int idx, uint32_t val)
{
    bexp_t b;
    slist_t *s;
    block_t *blk;

    switch (op) {
    default:
        bpf_error(cs, "bogus byte op");
    case '=':
        return gen_cmp(cs, OR_LINKHDR, (uint32_t)idx, BPF_B, val);
    case '<':
        return gen_cmp_lt(cs, OR_LINKHDR, (uint32_t)idx, BPF_B, val);
    case '>':
        return gen_cmp_gt(cs, OR_LINKHDR, (uint32_t)idx, BPF_B, val);
    case '|':
        s = new_stmt(cs, BPF_ALU | BPF_OR | BPF_K);
        break;
    case '&':
        s = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        break;
    }
    s->s.k = val;
    blk = new_block(cs, BPF_JMP | BPF_JEQ | BPF_K);
    blk->stmts = gen_load_a(cs, OR_LINKHDR, (uint32_t)idx, BPF_B);
    sappend(blk->stmts, s);
    blk->s.k = 0;
    b = bx_leaf_cs(cs, blk);
    return bx_not(b);
}

bexp_t gen_broadcast(cstate_t *cs, int proto)
{
    uint32_t hostmask;
    bexp_t b0, b1, b2;
    static const uint8_t ebroadcast[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

    switch (proto) {

    case Q_DEFAULT:
    case Q_LINK:
        switch (cs->linktype) {
        case DLT_EN10MB:
        case DLT_NETANALYZER:
        case DLT_NETANALYZER_TRANSPARENT:
            return gen_bcmp(cs, OR_LINKHDR, 0, 6, ebroadcast);
        case DLT_IEEE802:
            return gen_bcmp(cs, OR_LINKHDR, 2, 6, ebroadcast);
        case DLT_FDDI:
            return gen_bcmp(cs, OR_LINKHDR, 1, 6, ebroadcast);
        default:
            bpf_error(cs, "not a broadcast link");
        }
        break;

    case Q_IP:
        if (cs->netmask == 0xffffffffU)
            bpf_error(cs, "netmask not known, so 'ip broadcast' not supported");
        b0 = gen_linktype(cs, ETHERTYPE_IP);
        hostmask = ~cs->netmask;
        b1 = gen_mcmp(cs, OR_LINKPL, 16, BPF_W, 0, hostmask);
        b2 = gen_mcmp(cs, OR_LINKPL, 16, BPF_W, hostmask, hostmask);
        b1 = bx_or(cs, b1, b2);
        return bx_and(cs, b0, b1);
    }
    bpf_error(cs, "only link-layer/IP broadcast filters supported");
    return gen_false(cs);
}

static bexp_t gen_mac48multicast(cstate_t *cs, uint32_t offset)
{
    slist_t *s;
    block_t *b;

    s = gen_load_a(cs, OR_LINKHDR, offset, BPF_B);
    b = new_block(cs, BPF_JMP | BPF_JSET | BPF_K);
    b->s.k = 1;
    b->stmts = s;
    return bx_leaf_cs(cs, b);
}

bexp_t gen_multicast(cstate_t *cs, int proto)
{
    bexp_t b0, b1;

    switch (proto) {

    case Q_DEFAULT:
    case Q_LINK:
        switch (cs->linktype) {
        case DLT_EN10MB:
        case DLT_NETANALYZER:
        case DLT_NETANALYZER_TRANSPARENT:
            return gen_mac48multicast(cs, 0);
        case DLT_FDDI:
            return gen_mac48multicast(cs, 1);
        case DLT_IEEE802:
            return gen_mac48multicast(cs, 2);
        case DLT_IEEE802_11:
        case DLT_PRISM_HEADER:
        case DLT_IEEE802_11_RADIO_AVS:
        case DLT_IEEE802_11_RADIO:
            return gen_wlanmulticast(cs);
        default:
            bpf_error(cs, "link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel");
        }
        break;

    case Q_IP:
        b0 = gen_linktype(cs, ETHERTYPE_IP);
        b1 = gen_cmp_ge(cs, OR_LINKPL, 16, BPF_B, 224);
        return bx_and(cs, b0, b1);

    case Q_IPV6:
        b0 = gen_linktype(cs, ETHERTYPE_IPV6);
        b1 = gen_cmp(cs, OR_LINKPL, 24, BPF_B, 255);
        return bx_and(cs, b0, b1);
    }
    bpf_error(cs, "only link-layer multicast filters supported");
    return gen_false(cs);
}

bexp_t gen_ifindex(cstate_t *cs, int ifindex)
{
    switch (cs->linktype) {
    case DLT_LINUX_SLL2:
        return gen_cmp(cs, OR_LINKHDR, 4, BPF_W, (uint32_t)ifindex);
    default:
        return gen_cmp(cs, OR_PACKET, (uint32_t)(-4096 + 8), BPF_W,
                       (uint32_t)ifindex);
    }
}

bexp_t gen_inbound(cstate_t *cs, int dir)
{
    bexp_t b0;

    switch (cs->linktype) {
    case DLT_LINUX_SLL:
        b0 = gen_cmp(cs, OR_LINKHDR, 0, BPF_H, 4);
        if (!dir)
            b0 = bx_not(b0);
        break;
    default:
        b0 = gen_cmp(cs, OR_PACKET, (uint32_t)(-4096 + 4), BPF_H, 4);
        if (!dir)
            b0 = bx_not(b0);
        break;
    }
    return b0;
}

/* ---------------------------------------------------------- encapsulation */

static const char *dlt_description(int dlt)
{
    switch (dlt) {
    case DLT_NULL: return "BSD loopback";
    case DLT_EN10MB: return "Ethernet";
    case DLT_IEEE802: return "Token ring";
    case DLT_ARCNET: return "BSD ARCNET";
    case DLT_SLIP: return "SLIP";
    case DLT_PPP: return "PPP";
    case DLT_FDDI: return "FDDI";
    case DLT_ATM_RFC1483: return "RFC 1483 LLC-encapsulated ATM";
    case DLT_RAW: return "Raw IP";
    case DLT_SLIP_BSDOS: return "BSD/OS SLIP";
    case DLT_PPP_BSDOS: return "BSD/OS PPP";
    case DLT_ATM_CLIP: return "Linux Classical IP over ATM";
    case DLT_PPP_SERIAL: return "PPP over serial";
    case DLT_PPP_ETHER: return "PPPoE";
    case DLT_C_HDLC: return "Cisco HDLC";
    case DLT_IEEE802_11: return "802.11";
    case DLT_FRELAY: return "Frame Relay";
    case DLT_LOOP: return "OpenBSD loopback";
    case DLT_ENC: return "OpenBSD encapsulated IP";
    case DLT_LINUX_SLL: return "Linux cooked v1";
    case DLT_LTALK: return "Localtalk";
    case DLT_PFLOG: return "OpenBSD pflog file";
    case DLT_PRISM_HEADER: return "802.11 plus Prism header";
    case DLT_IP_OVER_FC: return "RFC 2625 IP-over-Fibre Channel";
    case DLT_SUNATM: return "Sun raw ATM";
    case DLT_IEEE802_11_RADIO: return "802.11 plus radiotap header";
    case DLT_IEEE802_11_RADIO_AVS: return "802.11 plus AVS radio information header";
    case DLT_IPV4: return "Raw IPv4";
    case DLT_IPV6: return "Raw IPv6";
    case DLT_LINUX_SLL2: return "Linux cooked v2";
    default: return NULL;
    }
}

static void unsupported_encap(cstate_t *cs, const char *what)
{
    const char *d = dlt_description(cs->linktype);
    if (d)
        bpf_error(cs, "no %s support for %s", what, d);
    else
        bpf_error(cs, "no %s support for DLT %d", what, cs->linktype);
}

static bexp_t gen_vlan_tpid_test(cstate_t *cs)
{
    bexp_t b0, b1;

    b0 = gen_linktype(cs, ETHERTYPE_VLAN);
    b1 = gen_linktype(cs, ETHERTYPE_QINQ);
    b0 = bx_or(cs, b0, b1);
    b1 = gen_linktype(cs, ETHERTYPE_VLAN_9100);
    return bx_or(cs, b0, b1);
}

bexp_t gen_vlan(cstate_t *cs, uint32_t vlan_num, int has_vlan_tag)
{
    bexp_t b0, b1;

    if (cs->label_stack_depth > 0)
        bpf_error(cs, "no VLAN match after MPLS");

    switch (cs->linktype) {
    case DLT_EN10MB:
    case DLT_NETANALYZER:
    case DLT_NETANALYZER_TRANSPARENT:
    case DLT_IEEE802_11:
    case DLT_PRISM_HEADER:
    case DLT_IEEE802_11_RADIO_AVS:
    case DLT_IEEE802_11_RADIO:
        break;
    default:
        unsupported_encap(cs, "VLAN");
    }

    b0 = gen_vlan_tpid_test(cs);
    if (has_vlan_tag) {
        if (vlan_num > 0x0fff)
            bpf_error(cs, "VLAN tag %u greater than maximum %u", vlan_num, 0x0fff);
        b1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_H, vlan_num, 0x0fff);
        b0 = bx_and(cs, b0, b1);
    }

    cs->off_linkpl.constant_part += 4;
    cs->off_linktype.constant_part += 4;
    cs->vlan_stack_depth++;
    return b0;
}

bexp_t gen_mpls(cstate_t *cs, uint32_t label, int has_label)
{
    bexp_t b0, b1;

    if (cs->label_stack_depth > 0) {
        b0 = gen_mcmp(cs, OR_PREVMPLSHDR, 0, BPF_B, 0, 0x01);
    } else {
        switch (cs->linktype) {
        case DLT_C_HDLC:
        case DLT_EN10MB:
        case DLT_NETANALYZER:
        case DLT_NETANALYZER_TRANSPARENT:
        case DLT_IEEE802_11:
        case DLT_PRISM_HEADER:
        case DLT_IEEE802_11_RADIO_AVS:
        case DLT_IEEE802_11_RADIO:
            b0 = gen_linktype(cs, ETHERTYPE_MPLS);
            break;
        case DLT_PPP:
        case DLT_PPP_PPPD:
        case DLT_PPP_SERIAL:
        case DLT_PPP_ETHER:
            b0 = gen_linktype(cs, PPP_MPLS_UCAST);
            break;
        default:
            unsupported_encap(cs, "MPLS");
            return gen_false(cs);
        }
    }

    if (has_label) {
        if (label > 0xFFFFF)
            bpf_error(cs, "MPLS label %u greater than maximum %u", label, 0xFFFFF);
        b1 = gen_mcmp(cs, OR_LINKPL, 0, BPF_W, label << 12, 0xfffff000U);
        b0 = bx_and(cs, b0, b1);
    }

    cs->off_nl_nosnap += 4;
    cs->off_nl += 4;
    cs->label_stack_depth++;
    return b0;
}

bexp_t gen_pppoed(cstate_t *cs)
{
    return gen_linktype(cs, ETHERTYPE_PPPOED);
}

bexp_t gen_pppoes(cstate_t *cs, uint32_t sess_num, int has_sess_num)
{
    bexp_t b0, b1;

    b0 = gen_linktype(cs, ETHERTYPE_PPPOES);
    if (has_sess_num) {
        if (sess_num > 0x0000ffff)
            bpf_error(cs, "PPPoE session number %u greater than maximum %u",
                      sess_num, 0xffff);
        b1 = gen_cmp(cs, OR_LINKPL, 2, BPF_H, sess_num);
        b0 = bx_and(cs, b0, b1);
    }

    cs->off_linktype.constant_part = cs->off_linkpl.constant_part + 6;
    cs->off_linkpl.constant_part = cs->off_linkpl.constant_part + 8;
    cs->off_nl = 0;
    cs->off_nl_nosnap = 0;
    return b0;
}
