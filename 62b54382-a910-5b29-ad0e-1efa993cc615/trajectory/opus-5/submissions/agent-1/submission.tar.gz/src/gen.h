#ifndef GEN_H
#define GEN_H

#include "comp.h"

/* data link types */
#define DLT_NULL        0
#define DLT_EN10MB      1
#define DLT_EN3MB       2
#define DLT_AX25        3
#define DLT_PRONET      4
#define DLT_CHAOS       5
#define DLT_IEEE802     6
#define DLT_ARCNET      7
#define DLT_SLIP        8
#define DLT_PPP         9
#define DLT_FDDI        10
#define DLT_ATM_RFC1483 11
#define DLT_RAW         12
#define DLT_SLIP_BSDOS  15
#define DLT_PPP_BSDOS   16
#define DLT_ATM_CLIP    19
#define DLT_PPP_SERIAL  50
#define DLT_PPP_ETHER   51
#define DLT_SYMANTEC_FIREWALL 99
#define DLT_C_HDLC      104
#define DLT_IEEE802_11  105
#define DLT_FRELAY      107
#define DLT_LOOP        108
#define DLT_ENC         109
#define DLT_LINUX_SLL   113
#define DLT_LTALK       114
#define DLT_PFLOG       117
#define DLT_PRISM_HEADER 119
#define DLT_IP_OVER_FC  122
#define DLT_SUNATM      123
#define DLT_IEEE802_11_RADIO 127
#define DLT_ARCNET_LINUX 129
#define DLT_JUNIPER_ATM1 137
#define DLT_APPLE_IP_OVER_IEEE1394 138
#define DLT_IEEE802_11_RADIO_AVS 163
#define DLT_PPP_PPPD    166
#define DLT_IPV4        228
#define DLT_IPV6        229
#define DLT_NETANALYZER 240
#define DLT_NETANALYZER_TRANSPARENT 241
#define DLT_LINUX_SLL2  276

/* ethertypes and protocol numbers used by the generator */
#define ETHERTYPE_IP      0x0800
#define ETHERTYPE_ARP     0x0806
#define ETHERTYPE_REVARP  0x8035
#define ETHERTYPE_IPV6    0x86dd
#define ETHERTYPE_ATALK   0x809b
#define ETHERTYPE_AARP    0x80f3
#define ETHERTYPE_DN      0x6003
#define ETHERTYPE_LAT     0x6004
#define ETHERTYPE_SCA     0x6007
#define ETHERTYPE_MOPDL   0x6001
#define ETHERTYPE_MOPRC   0x6002
#define ETHERTYPE_IPX     0x8137
#define ETHERTYPE_LOOPBACK 0x9000
#define ETHERTYPE_VLAN    0x8100
#define ETHERTYPE_QINQ    0x88a8
#define ETHERTYPE_VLAN_9100 0x9100
#define ETHERTYPE_MPLS    0x8847
#define ETHERTYPE_MPLS_MULTI 0x8848
#define ETHERTYPE_PPPOED  0x8863
#define ETHERTYPE_PPPOES  0x8864
#define ETHERTYPE_NS      0x0600
#define ETHERTYPE_SPRITE  0x0500
#define ETHERTYPE_TRAIL   0x1000
#define ETHERTYPE_TEB     0x6558

#define LLCSAP_IP       0x06
#define LLCSAP_8021D    0x42
#define LLCSAP_IPX      0xe0
#define LLCSAP_NETBEUI  0xf0
#define LLCSAP_ISONS    0xfe
#define LLCSAP_SNAP     0xaa

#define ISO8473_CLNP    0x81
#define ISO9542_ESIS    0x82
#define ISO10589_ISIS   0x83
#define ISO9542X25_ESIS 0x8a

#define IPPROTO_HOPOPTS 0
#define IPPROTO_ICMP    1
#define IPPROTO_IGMP    2
#define IPPROTO_IPIP    4
#define IPPROTO_TCP     6
#define IPPROTO_EGP     8
#define IPPROTO_IGRP    9
#define IPPROTO_UDP     17
#define IPPROTO_DCCP    33
#define IPPROTO_IPV6    41
#define IPPROTO_ROUTING 43
#define IPPROTO_FRAGMENT 44
#define IPPROTO_RSVP    46
#define IPPROTO_GRE     47
#define IPPROTO_ESP     50
#define IPPROTO_AH      51
#define IPPROTO_MOBILITY 55
#define IPPROTO_ICMPV6  58
#define IPPROTO_NONE    59
#define IPPROTO_DSTOPTS 60
#define IPPROTO_ND      77
#define IPPROTO_PIM     103
#define IPPROTO_VRRP    112
#define IPPROTO_CARP    112
#define IPPROTO_PGM     113
#define IPPROTO_SCTP    132
#define IPPROTO_MH      135
#define IPPROTO_SHIM6   140
#define IPPROTO_HIP     139

#define ETHERMTU 1500

#define PPP_IP    0x0021
#define PPP_IPV6  0x0057
#define PPP_IPX   0x002b
#define PPP_OSI   0x0023
#define PPP_ISOCLNS 0x0023
#define PPP_VJC   0x002d
#define PPP_VJNC  0x002f
#define PPP_DECNET 0x0027
#define PPP_APPLE 0x0029
#define PPP_NS    0x0025
#define PPP_MPLS_UCAST 0x0281
#define PPP_MPLS_MCAST 0x0283
#define PPP_COMP  0x00fd
#define PPP_IPCP  0x8021

#define LINUX_SLL_P_802_3 0x0001
#define LINUX_SLL_P_802_2 0x0004

/* offsets/sizes */
slist_t *gen_load_a(cstate_t *cs, enum offrel rel, uint32_t offset, uint32_t size);
slist_t *gen_abs_offset_varpart(cstate_t *cs, absoff_t *off);

bexp_t gen_cmp(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v);
bexp_t gen_cmp_gt(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v);
bexp_t gen_cmp_ge(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v);
bexp_t gen_cmp_lt(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v);
bexp_t gen_cmp_le(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v);
bexp_t gen_mcmp(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v, uint32_t mask);
bexp_t gen_bcmp(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, const uint8_t *v);
bexp_t gen_true(cstate_t *cs);
bexp_t gen_false(cstate_t *cs);
bexp_t gen_linktype(cstate_t *cs, uint32_t ll_proto);

int    alloc_reg(cstate_t *cs);
void   free_reg(cstate_t *cs, int n);

/* main generator entry points used by the parser */
bexp_t gen_scode(cstate_t *cs, const char *name, qual_t q);
bexp_t gen_mcode(cstate_t *cs, const char *s1, const char *s2, uint32_t masklen, qual_t q);
bexp_t gen_mcode6(cstate_t *cs, const char *s1, uint32_t masklen, qual_t q);
bexp_t gen_ncode(cstate_t *cs, const char *s, uint32_t v, qual_t q);
bexp_t gen_ecode(cstate_t *cs, const char *s, qual_t q);
bexp_t gen_acode(cstate_t *cs, const char *s, qual_t q);
bexp_t gen_proto_abbrev(cstate_t *cs, int proto);
bexp_t gen_relation(cstate_t *cs, int code, arth_t *a0, arth_t *a1, int reversed);
bexp_t gen_less(cstate_t *cs, uint32_t n);
bexp_t gen_greater(cstate_t *cs, uint32_t n);
bexp_t gen_byteop(cstate_t *cs, int op, int idx, uint32_t val);
bexp_t gen_broadcast(cstate_t *cs, int proto);
bexp_t gen_multicast(cstate_t *cs, int proto);
bexp_t gen_ifindex(cstate_t *cs, int ifindex);
bexp_t gen_inbound(cstate_t *cs, int dir);
bexp_t gen_vlan(cstate_t *cs, uint32_t vlan_num, int has_vlan_tag);
bexp_t gen_mpls(cstate_t *cs, uint32_t label, int has_label);
bexp_t gen_pppoed(cstate_t *cs);
bexp_t gen_pppoes(cstate_t *cs, uint32_t sess, int has_sess);
bexp_t gen_geneve(cstate_t *cs, uint32_t vni, int has_vni);
bexp_t gen_atmtype_abbrev(cstate_t *cs, int type);
bexp_t gen_p80211_type(cstate_t *cs, int type, int mask);
bexp_t gen_p80211_fcdir(cstate_t *cs, int fcdir);
bexp_t gen_llc_generic(cstate_t *cs);
bexp_t gen_llc_i(cstate_t *cs);
bexp_t gen_llc_s(cstate_t *cs);
bexp_t gen_llc_u(cstate_t *cs);
bexp_t gen_llc_s_subtype(cstate_t *cs, uint32_t subtype);
bexp_t gen_llc_u_subtype(cstate_t *cs, uint32_t subtype);

bexp_t gen_host(cstate_t *cs, uint32_t addr, uint32_t mask, int proto, int dir, int type);
bexp_t gen_proto(cstate_t *cs, uint32_t v, int proto, int dir);
bexp_t gen_protochain(cstate_t *cs, uint32_t v, int proto);
bexp_t gen_ipfrag(cstate_t *cs);
bexp_t gen_wlanmulticast(cstate_t *cs);
bexp_t gen_ncode_range(cstate_t *cs, uint32_t v1, uint32_t v2, qual_t q);
slist_t *gen_loadx_iphdrlen_pub(cstate_t *cs);
void insert_compute_vloffsets(cstate_t *cs, block_t *b);
int parse_ether(const char *s, uint8_t *out);
int parse_ip6(const char *s, uint8_t *out);

arth_t *gen_loadi(cstate_t *cs, uint32_t v);
arth_t *gen_load(cstate_t *cs, int proto, arth_t *index, uint32_t size);
arth_t *gen_loadlen(cstate_t *cs);
arth_t *gen_neg(cstate_t *cs, arth_t *a);
arth_t *gen_arth(cstate_t *cs, int code, arth_t *a0, arth_t *a1);

#endif
