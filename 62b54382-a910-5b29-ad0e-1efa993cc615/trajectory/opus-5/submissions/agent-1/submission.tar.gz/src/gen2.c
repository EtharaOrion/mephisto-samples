/*
 * gen2.c - address, port and protocol primitives.
 */
#include <stdio.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"

extern bexp_t gen_ipfrag(cstate_t *cs);

/* ---------------------------------------------------------------- hosts */

static bexp_t gen_hostop(cstate_t *cs, uint32_t addr, uint32_t mask, int dir,
                         uint32_t proto, uint32_t src_off, uint32_t dst_off)
{
    bexp_t b0, b1;
    uint32_t offset;

    switch (dir) {
    case Q_SRC: offset = src_off; break;
    case Q_DST: offset = dst_off; break;
    case Q_AND:
        b0 = gen_hostop(cs, addr, mask, Q_SRC, proto, src_off, dst_off);
        b1 = gen_hostop(cs, addr, mask, Q_DST, proto, src_off, dst_off);
        return bx_and(cs, b0, b1);
    case Q_DEFAULT:
    case Q_OR:
        b0 = gen_hostop(cs, addr, mask, Q_SRC, proto, src_off, dst_off);
        b1 = gen_hostop(cs, addr, mask, Q_DST, proto, src_off, dst_off);
        return bx_or(cs, b0, b1);
    case Q_ADDR1:
        bpf_error(cs, "'addr1' and 'address1' are only supported on 802.11");
    case Q_ADDR2:
        bpf_error(cs, "'addr2' and 'address2' are only supported on 802.11");
    case Q_ADDR3:
        bpf_error(cs, "'addr3' and 'address3' are only supported on 802.11");
    case Q_ADDR4:
        bpf_error(cs, "'addr4' and 'address4' are only supported on 802.11");
    case Q_RA:
        bpf_error(cs, "'ra' is only supported on 802.11");
    case Q_TA:
        bpf_error(cs, "'ta' is only supported on 802.11");
    default:
        bpf_error(cs, "direction not supported on linktype %d", cs->linktype);
    }
    b0 = gen_linktype(cs, proto);
    b1 = gen_mcmp(cs, OR_LINKPL, offset, BPF_W, addr, mask);
    return bx_and(cs, b0, b1);
}

static bexp_t gen_hostop6(cstate_t *cs, const uint8_t *addr, const uint8_t *mask,
                          int dir, uint32_t proto, uint32_t src_off, uint32_t dst_off)
{
    bexp_t b0, b1, tmp;
    uint32_t offset;
    int i, have = 0;

    switch (dir) {
    case Q_SRC: offset = src_off; break;
    case Q_DST: offset = dst_off; break;
    case Q_AND:
        b0 = gen_hostop6(cs, addr, mask, Q_SRC, proto, src_off, dst_off);
        b1 = gen_hostop6(cs, addr, mask, Q_DST, proto, src_off, dst_off);
        return bx_and(cs, b0, b1);
    case Q_DEFAULT:
    case Q_OR:
        b0 = gen_hostop6(cs, addr, mask, Q_SRC, proto, src_off, dst_off);
        b1 = gen_hostop6(cs, addr, mask, Q_DST, proto, src_off, dst_off);
        return bx_or(cs, b0, b1);
    case Q_ADDR1:
        bpf_error(cs, "'addr1' and 'address1' are only supported on 802.11");
    case Q_ADDR2:
        bpf_error(cs, "'addr2' and 'address2' are only supported on 802.11");
    case Q_ADDR3:
        bpf_error(cs, "'addr3' and 'address3' are only supported on 802.11");
    case Q_ADDR4:
        bpf_error(cs, "'addr4' and 'address4' are only supported on 802.11");
    case Q_RA:
        bpf_error(cs, "'ra' is only supported on 802.11");
    case Q_TA:
        bpf_error(cs, "'ta' is only supported on 802.11");
    default:
        bpf_error(cs, "direction not supported on linktype %d", cs->linktype);
    }
    b1 = gen_linktype(cs, proto);
    for (i = 0; i < 4; i++) {
        uint32_t a, m;
        a = ((uint32_t)addr[i*4] << 24) | ((uint32_t)addr[i*4+1] << 16) |
            ((uint32_t)addr[i*4+2] << 8) | addr[i*4+3];
        m = ((uint32_t)mask[i*4] << 24) | ((uint32_t)mask[i*4+1] << 16) |
            ((uint32_t)mask[i*4+2] << 8) | mask[i*4+3];
        if (m == 0)
            continue;
        tmp = gen_mcmp(cs, OR_LINKPL, offset + i*4, BPF_W, a, m);
        if (have) b0 = bx_and(cs, b0, tmp);
        else { b0 = tmp; have = 1; }
    }
    if (!have)
        return b1;
    return bx_and(cs, b1, b0);
}

static bexp_t gen_ehostop(cstate_t *cs, const uint8_t *eaddr, int dir)
{
    bexp_t b0, b1;

    switch (dir) {
    case Q_SRC:
        return gen_bcmp(cs, OR_LINKHDR, 6, 6, eaddr);
    case Q_DST:
        return gen_bcmp(cs, OR_LINKHDR, 0, 6, eaddr);
    case Q_AND:
        b0 = gen_ehostop(cs, eaddr, Q_SRC);
        b1 = gen_ehostop(cs, eaddr, Q_DST);
        return bx_and(cs, b0, b1);
    case Q_DEFAULT:
    case Q_OR:
        b0 = gen_ehostop(cs, eaddr, Q_SRC);
        b1 = gen_ehostop(cs, eaddr, Q_DST);
        return bx_or(cs, b0, b1);
    case Q_ADDR1:
        bpf_error(cs, "'addr1' and 'address1' are only supported on 802.11 with 802.11 headers");
    case Q_ADDR2:
        bpf_error(cs, "'addr2' and 'address2' are only supported on 802.11 with 802.11 headers");
    case Q_ADDR3:
        bpf_error(cs, "'addr3' and 'address3' are only supported on 802.11 with 802.11 headers");
    case Q_ADDR4:
        bpf_error(cs, "'addr4' and 'address4' are only supported on 802.11 with 802.11 headers");
    case Q_RA:
        bpf_error(cs, "'ra' is only supported on 802.11 with 802.11 headers");
    case Q_TA:
        bpf_error(cs, "'ta' is only supported on 802.11 with 802.11 headers");
    }
    bpf_error(cs, "bogus direction");
    return gen_false(cs);
}

/* 802.11 address matching */
static bexp_t gen_wlanhostop(cstate_t *cs, const uint8_t *eaddr, int dir)
{
    bexp_t b0, b1, b2, s;

    switch (dir) {
    case Q_SRC:
        /*
         * Src address is in a different place depending on the To DS and
         * From DS bits.
         */
        b1 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0, 0x01);
        b0 = gen_bcmp(cs, OR_LINKHDR, 10, 6, eaddr);
        b1 = bx_and(cs, b1, b0);
        b2 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x01, 0x03);
        b0 = gen_bcmp(cs, OR_LINKHDR, 10, 6, eaddr);
        b2 = bx_and(cs, b2, b0);
        b1 = bx_or(cs, b1, b2);
        b2 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x02, 0x03);
        b0 = gen_bcmp(cs, OR_LINKHDR, 16, 6, eaddr);
        b2 = bx_and(cs, b2, b0);
        b1 = bx_or(cs, b1, b2);
        b2 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x03, 0x03);
        b0 = gen_bcmp(cs, OR_LINKHDR, 24, 6, eaddr);
        b2 = bx_and(cs, b2, b0);
        return bx_or(cs, b1, b2);
    case Q_DST:
        b1 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0, 0x01);
        b0 = gen_bcmp(cs, OR_LINKHDR, 4, 6, eaddr);
        b1 = bx_and(cs, b1, b0);
        b2 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x01, 0x01);
        b0 = gen_bcmp(cs, OR_LINKHDR, 16, 6, eaddr);
        b2 = bx_and(cs, b2, b0);
        return bx_or(cs, b1, b2);
    case Q_AND:
        b0 = gen_wlanhostop(cs, eaddr, Q_SRC);
        b1 = gen_wlanhostop(cs, eaddr, Q_DST);
        return bx_and(cs, b0, b1);
    case Q_DEFAULT:
    case Q_OR:
        b0 = gen_wlanhostop(cs, eaddr, Q_SRC);
        b1 = gen_wlanhostop(cs, eaddr, Q_DST);
        return bx_or(cs, b0, b1);
    case Q_ADDR1:
        return gen_bcmp(cs, OR_LINKHDR, 4, 6, eaddr);
    case Q_ADDR2:
        return gen_bcmp(cs, OR_LINKHDR, 10, 6, eaddr);
    case Q_ADDR3:
        return gen_bcmp(cs, OR_LINKHDR, 16, 6, eaddr);
    case Q_ADDR4:
        b0 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x03, 0x03);
        b1 = gen_bcmp(cs, OR_LINKHDR, 24, 6, eaddr);
        return bx_and(cs, b0, b1);
    case Q_RA:
        b0 = gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0x08, 0x0c);
        b1 = gen_bcmp(cs, OR_LINKHDR, 4, 6, eaddr);
        return bx_and(cs, b0, b1);
    case Q_TA:
        b0 = gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0x08, 0x0c);
        b1 = gen_bcmp(cs, OR_LINKHDR, 10, 6, eaddr);
        return bx_and(cs, b0, b1);
    }
    bpf_error(cs, "bogus direction");
    (void)s;
    return gen_false(cs);
}

static bexp_t gen_mac48host(cstate_t *cs, const uint8_t *eaddr, int dir,
                            const char *type)
{
    switch (cs->linktype) {
    case DLT_EN10MB:
    case DLT_NETANALYZER:
    case DLT_NETANALYZER_TRANSPARENT:
        return gen_ehostop(cs, eaddr, dir);
    case DLT_IEEE802_11:
    case DLT_PRISM_HEADER:
    case DLT_IEEE802_11_RADIO_AVS:
    case DLT_IEEE802_11_RADIO:
        return gen_wlanhostop(cs, eaddr, dir);
    default:
        bpf_error(cs, "%s addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel",
                  type);
    }
    return gen_false(cs);
}

bexp_t gen_host(cstate_t *cs, uint32_t addr, uint32_t mask, int proto, int dir,
                int type)
{
    bexp_t b0, b1;
    const char *typestr;

    if (type == Q_NET) typestr = "net";
    else typestr = "host";

    switch (proto) {

    case Q_DEFAULT:
        b0 = gen_host(cs, addr, mask, Q_IP, dir, type);
        b1 = gen_host(cs, addr, mask, Q_ARP, dir, type);
        b0 = bx_or(cs, b0, b1);
        b1 = gen_host(cs, addr, mask, Q_RARP, dir, type);
        return bx_or(cs, b0, b1);

    case Q_LINK:
        bpf_error(cs, "link-layer modifier applied to %s", typestr);

    case Q_IP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_IP, 12, 16);

    case Q_RARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_REVARP, 14, 24);

    case Q_ARP:
        return gen_hostop(cs, addr, mask, dir, ETHERTYPE_ARP, 14, 24);

    case Q_SCTP:
        bpf_error(cs, "'sctp' modifier applied to %s", typestr);
    case Q_TCP:
        bpf_error(cs, "'tcp' modifier applied to %s", typestr);
    case Q_UDP:
        bpf_error(cs, "'udp' modifier applied to %s", typestr);
    case Q_ICMP:
        bpf_error(cs, "'icmp' modifier applied to %s", typestr);
    case Q_IGMP:
        bpf_error(cs, "'igmp' modifier applied to %s", typestr);
    case Q_IGRP:
        bpf_error(cs, "'igrp' modifier applied to %s", typestr);
    case Q_ATALK:
        bpf_error(cs, "AppleTalk host filtering not implemented");
    case Q_DECNET:
        bpf_error(cs, "'decnet' modifier applied to %s", typestr);
    case Q_LAT:
        bpf_error(cs, "LAT host filtering not implemented");
    case Q_SCA:
        bpf_error(cs, "SCA host filtering not implemented");
    case Q_MOPDL:
        bpf_error(cs, "MOPDL host filtering not implemented");
    case Q_MOPRC:
        bpf_error(cs, "MOPRC host filtering not implemented");
    case Q_IPV6:
        bpf_error(cs, "'ip6' modifier applied to ip host");
    case Q_ICMPV6:
        bpf_error(cs, "'icmp6' modifier applied to %s", typestr);
    case Q_AH:
        bpf_error(cs, "'ah' modifier applied to %s", typestr);
    case Q_ESP:
        bpf_error(cs, "'esp' modifier applied to %s", typestr);
    case Q_PIM:
        bpf_error(cs, "'pim' modifier applied to %s", typestr);
    case Q_VRRP:
        bpf_error(cs, "'vrrp' modifier applied to %s", typestr);
    case Q_AARP:
        bpf_error(cs, "AARP host filtering not implemented");
    case Q_ISO:
        bpf_error(cs, "ISO host filtering not implemented");
    case Q_ESIS:
        bpf_error(cs, "'esis' modifier applied to %s", typestr);
    case Q_ISIS:
        bpf_error(cs, "'isis' modifier applied to %s", typestr);
    case Q_CLNP:
        bpf_error(cs, "'clnp' modifier applied to %s", typestr);
    case Q_STP:
        bpf_error(cs, "'stp' modifier applied to %s", typestr);
    case Q_IPX:
        bpf_error(cs, "IPX host filtering not implemented");
    case Q_NETBEUI:
        bpf_error(cs, "'netbeui' modifier applied to %s", typestr);
    case Q_RADIO:
        bpf_error(cs, "'radio' modifier applied to %s", typestr);
    case Q_CARP:
        bpf_error(cs, "'carp' modifier applied to %s", typestr);
    }
    bpf_error(cs, "bogus proto");
    return gen_false(cs);
}

static bexp_t gen_host6(cstate_t *cs, const uint8_t *addr, const uint8_t *mask,
                        int proto, int dir, int type)
{
    const char *typestr = (type == Q_NET) ? "net" : "host";

    switch (proto) {
    case Q_DEFAULT:
    case Q_IPV6:
        return gen_hostop6(cs, addr, mask, dir, ETHERTYPE_IPV6, 8, 24);
    case Q_LINK:
        bpf_error(cs, "link-layer modifier applied to ip6 %s", typestr);
    case Q_IP:
        bpf_error(cs, "'ip' modifier applied to ip6 %s", typestr);
    case Q_ARP:
        bpf_error(cs, "'arp' modifier applied to ip6 %s", typestr);
    case Q_RARP:
        bpf_error(cs, "'rarp' modifier applied to ip6 %s", typestr);
    default:
        bpf_error(cs, "'%d' modifier applied to ip6 %s", proto, typestr);
    }
    return gen_false(cs);
}

/* ---------------------------------------------------------------- ports */

static bexp_t gen_portatom(cstate_t *cs, int off, uint32_t v)
{
    return gen_cmp(cs, OR_TRAN_IPV4, (uint32_t)off, BPF_H, v);
}

static bexp_t gen_portatom6(cstate_t *cs, int off, uint32_t v)
{
    return gen_cmp(cs, OR_TRAN_IPV6, (uint32_t)off, BPF_H, v);
}

static bexp_t gen_portop(cstate_t *cs, uint32_t port, uint32_t proto, int dir)
{
    bexp_t b0, b1, tmp;

    b0 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    b1 = gen_ipfrag(cs);
    b1 = bx_and(cs, b0, b1);

    switch (dir) {
    case Q_SRC:
        b0 = gen_portatom(cs, 0, port);
        break;
    case Q_DST:
        b0 = gen_portatom(cs, 2, port);
        break;
    case Q_AND:
        tmp = gen_portatom(cs, 0, port);
        b0 = gen_portatom(cs, 2, port);
        b0 = bx_and(cs, tmp, b0);
        break;
    case Q_OR:
    case Q_DEFAULT:
        tmp = gen_portatom(cs, 0, port);
        b0 = gen_portatom(cs, 2, port);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        bpf_error(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static bexp_t gen_port(cstate_t *cs, uint32_t port, int ip_proto, int dir)
{
    bexp_t b0, b1, tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portop(cs, port, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = gen_portop(cs, port, IPPROTO_TCP, dir);
        b1 = gen_portop(cs, port, IPPROTO_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = gen_portop(cs, port, IPPROTO_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

static bexp_t gen_portop6(cstate_t *cs, uint32_t port, uint32_t proto, int dir)
{
    bexp_t b0, b1, tmp;

    b1 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case Q_SRC:
        b0 = gen_portatom6(cs, 0, port);
        break;
    case Q_DST:
        b0 = gen_portatom6(cs, 2, port);
        break;
    case Q_AND:
        tmp = gen_portatom6(cs, 0, port);
        b0 = gen_portatom6(cs, 2, port);
        b0 = bx_and(cs, tmp, b0);
        break;
    case Q_OR:
    case Q_DEFAULT:
        tmp = gen_portatom6(cs, 0, port);
        b0 = gen_portatom6(cs, 2, port);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        bpf_error(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static bexp_t gen_port6(cstate_t *cs, uint32_t port, int ip_proto, int dir)
{
    bexp_t b0, b1, tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portop6(cs, port, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = gen_portop6(cs, port, IPPROTO_TCP, dir);
        b1 = gen_portop6(cs, port, IPPROTO_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = gen_portop6(cs, port, IPPROTO_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

static bexp_t gen_portrangeatom(cstate_t *cs, int off, uint32_t v1, uint32_t v2)
{
    bexp_t b1, b2;
    uint32_t t;

    if (v1 > v2) { t = v1; v1 = v2; v2 = t; }
    b1 = gen_cmp_ge(cs, OR_TRAN_IPV4, (uint32_t)off, BPF_H, v1);
    b2 = gen_cmp_le(cs, OR_TRAN_IPV4, (uint32_t)off, BPF_H, v2);
    return bx_and(cs, b1, b2);
}

static bexp_t gen_portrangeatom6(cstate_t *cs, int off, uint32_t v1, uint32_t v2)
{
    bexp_t b1, b2;
    uint32_t t;

    if (v1 > v2) { t = v1; v1 = v2; v2 = t; }
    b1 = gen_cmp_ge(cs, OR_TRAN_IPV6, (uint32_t)off, BPF_H, v1);
    b2 = gen_cmp_le(cs, OR_TRAN_IPV6, (uint32_t)off, BPF_H, v2);
    return bx_and(cs, b1, b2);
}

static bexp_t gen_portrangeop(cstate_t *cs, uint32_t p1, uint32_t p2,
                              uint32_t proto, int dir)
{
    bexp_t b0, b1, tmp;

    b0 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, proto);
    b1 = gen_ipfrag(cs);
    b1 = bx_and(cs, b0, b1);

    switch (dir) {
    case Q_SRC:
        b0 = gen_portrangeatom(cs, 0, p1, p2);
        break;
    case Q_DST:
        b0 = gen_portrangeatom(cs, 2, p1, p2);
        break;
    case Q_AND:
        tmp = gen_portrangeatom(cs, 0, p1, p2);
        b0 = gen_portrangeatom(cs, 2, p1, p2);
        b0 = bx_and(cs, tmp, b0);
        break;
    case Q_OR:
    case Q_DEFAULT:
        tmp = gen_portrangeatom(cs, 0, p1, p2);
        b0 = gen_portrangeatom(cs, 2, p1, p2);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        bpf_error(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static bexp_t gen_portrange(cstate_t *cs, uint32_t p1, uint32_t p2,
                            int ip_proto, int dir)
{
    bexp_t b0, b1, tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IP);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portrangeop(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_TCP, dir);
        b1 = gen_portrangeop(cs, p1, p2, IPPROTO_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = gen_portrangeop(cs, p1, p2, IPPROTO_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

static bexp_t gen_portrangeop6(cstate_t *cs, uint32_t p1, uint32_t p2,
                               uint32_t proto, int dir)
{
    bexp_t b0, b1, tmp;

    b1 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, proto);

    switch (dir) {
    case Q_SRC:
        b0 = gen_portrangeatom6(cs, 0, p1, p2);
        break;
    case Q_DST:
        b0 = gen_portrangeatom6(cs, 2, p1, p2);
        break;
    case Q_AND:
        tmp = gen_portrangeatom6(cs, 0, p1, p2);
        b0 = gen_portrangeatom6(cs, 2, p1, p2);
        b0 = bx_and(cs, tmp, b0);
        break;
    case Q_OR:
    case Q_DEFAULT:
        tmp = gen_portrangeatom6(cs, 0, p1, p2);
        b0 = gen_portrangeatom6(cs, 2, p1, p2);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        bpf_error(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static bexp_t gen_portrange6(cstate_t *cs, uint32_t p1, uint32_t p2,
                             int ip_proto, int dir)
{
    bexp_t b0, b1, tmp;

    b0 = gen_linktype(cs, ETHERTYPE_IPV6);
    switch (ip_proto) {
    case IPPROTO_UDP:
    case IPPROTO_TCP:
    case IPPROTO_SCTP:
        b1 = gen_portrangeop6(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_TCP, dir);
        b1 = gen_portrangeop6(cs, p1, p2, IPPROTO_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = gen_portrangeop6(cs, p1, p2, IPPROTO_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

/* ------------------------------------------------------------- protocols */

bexp_t gen_ipfrag(cstate_t *cs)
{
    slist_t *s;
    block_t *b;

    s = gen_load_a(cs, OR_LINKPL, 6, BPF_H);
    b = new_block(cs, BPF_JMP | BPF_JSET | BPF_K);
    b->s.k = 0x1fff;
    b->stmts = s;
    return bx_not(bx_leaf_cs(cs, b));
}

static int proto_to_qual(int p);

bexp_t gen_proto(cstate_t *cs, uint32_t v, int proto, int dir)
{
    bexp_t b0, b1, b2;

    if (dir != Q_DEFAULT)
        bpf_error(cs, "direction applied to 'proto'");

    switch (proto) {
    case Q_DEFAULT:
        b0 = gen_proto(cs, v, Q_IP, dir);
        b1 = gen_proto(cs, v, Q_IPV6, dir);
        return bx_or(cs, b0, b1);

    case Q_LINK:
        return gen_linktype(cs, v);

    case Q_IP:
        b0 = gen_linktype(cs, ETHERTYPE_IP);
        b1 = gen_cmp(cs, OR_LINKPL, 9, BPF_B, v);
        return bx_and(cs, b0, b1);

    case Q_ARP:
        bpf_error(cs, "arp does not encapsulate another protocol");
    case Q_RARP:
        bpf_error(cs, "rarp does not encapsulate another protocol");
    case Q_SCTP:
        bpf_error(cs, "'sctp proto' is bogus");
    case Q_TCP:
        bpf_error(cs, "'tcp proto' is bogus");
    case Q_UDP:
        bpf_error(cs, "'udp proto' is bogus");
    case Q_ICMP:
        bpf_error(cs, "'icmp proto' is bogus");
    case Q_IGMP:
        bpf_error(cs, "'igmp proto' is bogus");
    case Q_IGRP:
        bpf_error(cs, "'igrp proto' is bogus");
    case Q_PIM:
        bpf_error(cs, "'pim proto' is bogus");
    case Q_VRRP:
        bpf_error(cs, "'vrrp proto' is bogus");
    case Q_CARP:
        bpf_error(cs, "'carp proto' is bogus");

    case Q_ISO:
        switch (cs->linktype) {
        case DLT_FRELAY:
            b0 = gen_cmp(cs, OR_LINKHDR, 2, BPF_B, 0x03);
            b1 = gen_cmp(cs, OR_LINKHDR, 4, BPF_B, v);
            return bx_and(cs, b0, b1);
        case DLT_C_HDLC:
            b0 = gen_linktype(cs, LLCSAP_ISONS);
            b1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 1, BPF_B, v);
            return bx_and(cs, b0, b1);
        default:
            b0 = gen_linktype(cs, LLCSAP_ISONS);
            b1 = gen_cmp(cs, OR_LINKPL_NOSNAP, 0, BPF_B, v);
            return bx_and(cs, b0, b1);
        }

    case Q_ESIS:
        bpf_error(cs, "'esis proto' is bogus");
    case Q_ISIS:
        bpf_error(cs, "'isis proto' is bogus");
    case Q_CLNP:
        bpf_error(cs, "'clnp proto' is bogus");
    case Q_STP:
        bpf_error(cs, "'stp proto' is bogus");
    case Q_IPX:
        bpf_error(cs, "'ipx proto' is bogus");
    case Q_NETBEUI:
        bpf_error(cs, "'netbeui proto' is bogus");
    case Q_ICMPV6:
        bpf_error(cs, "'icmp6 proto' is bogus");

    case Q_IPV6:
        b0 = gen_linktype(cs, ETHERTYPE_IPV6);
        b2 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, IPPROTO_FRAGMENT);
        b1 = gen_cmp(cs, OR_LINKPL, 40, BPF_B, v);
        b1 = bx_and(cs, b2, b1);
        b2 = gen_cmp(cs, OR_LINKPL, 6, BPF_B, v);
        b1 = bx_or(cs, b2, b1);
        return bx_and(cs, b0, b1);

    default:
        bpf_error(cs, "'proto' modifier applied to unsupported protocol");
    }
    return gen_false(cs);
}

bexp_t gen_proto_abbrev(cstate_t *cs, int proto)
{
    bexp_t b0;

    switch (proto) {
    case Q_SCTP:
        return gen_proto(cs, IPPROTO_SCTP, Q_DEFAULT, Q_DEFAULT);
    case Q_TCP:
        return gen_proto(cs, IPPROTO_TCP, Q_DEFAULT, Q_DEFAULT);
    case Q_UDP:
        return gen_proto(cs, IPPROTO_UDP, Q_DEFAULT, Q_DEFAULT);
    case Q_ICMP:
        return gen_proto(cs, IPPROTO_ICMP, Q_IP, Q_DEFAULT);
    case Q_IGMP:
        return gen_proto(cs, IPPROTO_IGMP, Q_IP, Q_DEFAULT);
    case Q_IGRP:
        return gen_proto(cs, IPPROTO_IGRP, Q_IP, Q_DEFAULT);
    case Q_PIM:
        return gen_proto(cs, IPPROTO_PIM, Q_DEFAULT, Q_DEFAULT);
    case Q_VRRP:
        return gen_proto(cs, IPPROTO_VRRP, Q_IP, Q_DEFAULT);
    case Q_CARP:
        return gen_proto(cs, IPPROTO_CARP, Q_IP, Q_DEFAULT);
    case Q_IP:
        return gen_linktype(cs, ETHERTYPE_IP);
    case Q_ARP:
        return gen_linktype(cs, ETHERTYPE_ARP);
    case Q_RARP:
        return gen_linktype(cs, ETHERTYPE_REVARP);
    case Q_LINK:
        bpf_error(cs, "link layer applied in wrong context");
    case Q_ATALK:
        return gen_linktype(cs, ETHERTYPE_ATALK);
    case Q_AARP:
        return gen_linktype(cs, ETHERTYPE_AARP);
    case Q_DECNET:
        return gen_linktype(cs, ETHERTYPE_DN);
    case Q_SCA:
        return gen_linktype(cs, ETHERTYPE_SCA);
    case Q_LAT:
        return gen_linktype(cs, ETHERTYPE_LAT);
    case Q_MOPDL:
        return gen_linktype(cs, ETHERTYPE_MOPDL);
    case Q_MOPRC:
        return gen_linktype(cs, ETHERTYPE_MOPRC);
    case Q_IPV6:
        return gen_linktype(cs, ETHERTYPE_IPV6);
    case Q_ICMPV6:
        return gen_proto(cs, IPPROTO_ICMPV6, Q_IPV6, Q_DEFAULT);
    case Q_AH:
        return gen_proto(cs, IPPROTO_AH, Q_DEFAULT, Q_DEFAULT);
    case Q_ESP:
        return gen_proto(cs, IPPROTO_ESP, Q_DEFAULT, Q_DEFAULT);
    case Q_ISO:
        return gen_linktype(cs, LLCSAP_ISONS);
    case Q_ESIS:
        return gen_proto(cs, ISO9542_ESIS, Q_ISO, Q_DEFAULT);
    case Q_ISIS:
        return gen_proto(cs, ISO10589_ISIS, Q_ISO, Q_DEFAULT);
    case Q_ISIS_L1:
    case Q_ISIS_L2:
    case Q_ISIS_IIH:
    case Q_ISIS_LSP:
    case Q_ISIS_SNP:
    case Q_ISIS_CSNP:
    case Q_ISIS_PSNP:
        b0 = gen_proto(cs, ISO10589_ISIS, Q_ISO, Q_DEFAULT);
        return b0;
    case Q_CLNP:
        return gen_proto(cs, ISO8473_CLNP, Q_ISO, Q_DEFAULT);
    case Q_STP:
        return gen_linktype(cs, LLCSAP_8021D);
    case Q_IPX:
        return gen_linktype(cs, LLCSAP_IPX);
    case Q_NETBEUI:
        return gen_linktype(cs, LLCSAP_NETBEUI);
    case Q_RADIO:
        bpf_error(cs, "'radio' is not a valid protocol type");
    }
    bpf_error(cs, "bogus protocol abbreviation");
    return gen_false(cs);
}

static int proto_to_qual(int p) { return p; }

/* ------------------------------------------------------------ name codes */

static int atoin(const char *s, uint32_t *addr)
{
    uint32_t n;
    int len = 0;

    *addr = 0;
    for (;;) {
        n = 0;
        while (*s && *s != '.') {
            if (*s < '0' || *s > '9') return -1;
            if (n > 25) return -1;
            n = n * 10 + (uint32_t)(*s++ - '0');
        }
        if (n > 255) return -1;
        *addr <<= 8;
        *addr |= n & 0xff;
        len += 8;
        if (*s == '\0') return len;
        ++s;
    }
}

bexp_t gen_ncode(cstate_t *cs, const char *s, uint32_t v, qual_t q)
{
    uint32_t mask;
    int proto = q.proto;
    int dir = q.dir;
    int vlen;

    if (s == NULL)
        vlen = 32;
    else {
        vlen = atoin(s, &v);
        if (vlen < 0)
            bpf_error(cs, "invalid IPv4 address '%s'", s);
    }

    switch (q.addr) {

    case Q_DEFAULT:
    case Q_HOST:
    case Q_NET:
        if (proto == Q_LINK)
            bpf_error(cs, "illegal link layer address");
        mask = 0xffffffffU;
        if (s == NULL && q.addr == Q_NET) {
            /* promote short net number */
            while (v && (v & 0xff000000U) == 0) {
                v <<= 8;
                mask <<= 8;
            }
        } else {
            /* promote short ipaddr */
            if (vlen < 32) {
                v <<= 32 - vlen;
                mask <<= 32 - vlen;
            }
        }
        return gen_host(cs, v, mask, proto, dir, q.addr);

    case Q_PORT:
        if (proto != Q_DEFAULT && proto != Q_UDP && proto != Q_TCP &&
            proto != Q_SCTP)
            bpf_error(cs, "illegal qualifier of 'port'");
        if (v > 65535)
            bpf_error(cs, "illegal port number %u > 65535", v);
        {
            bexp_t b, b6;
            int ipproto = (proto == Q_UDP) ? IPPROTO_UDP :
                          (proto == Q_TCP) ? IPPROTO_TCP :
                          (proto == Q_SCTP) ? IPPROTO_SCTP : -1;
            b = gen_port(cs, v, ipproto, dir);
            b6 = gen_port6(cs, v, ipproto, dir);
            return bx_or(cs, b6, b);
        }

    case Q_PORTRANGE:
        if (proto != Q_DEFAULT && proto != Q_UDP && proto != Q_TCP &&
            proto != Q_SCTP)
            bpf_error(cs, "illegal qualifier of 'portrange'");
        if (v > 65535)
            bpf_error(cs, "illegal port number %u > 65535", v);
        {
            bexp_t b, b6;
            int ipproto = (proto == Q_UDP) ? IPPROTO_UDP :
                          (proto == Q_TCP) ? IPPROTO_TCP :
                          (proto == Q_SCTP) ? IPPROTO_SCTP : -1;
            b = gen_portrange(cs, v, v, ipproto, dir);
            b6 = gen_portrange6(cs, v, v, ipproto, dir);
            return bx_or(cs, b6, b);
        }

    case Q_GATEWAY:
        bpf_error(cs, "'gateway' requires a name");

    case Q_PROTO:
        return gen_proto(cs, v, proto, dir);

    case Q_PROTOCHAIN:
        return gen_protochain(cs, v, proto);

    case Q_UNDEF:
        bpf_error(cs, "'proto' qualifier applied to a number");
    }
    bpf_error(cs, "bogus qualifier");
    return gen_false(cs);
}

bexp_t gen_ncode_range(cstate_t *cs, uint32_t v1, uint32_t v2, qual_t q)
{
    bexp_t b, b6;
    int proto = q.proto, dir = q.dir;
    int ipproto;

    if (q.addr != Q_PORTRANGE && q.addr != Q_DEFAULT)
        bpf_error(cs, "illegal qualifier of 'portrange'");
    if (proto != Q_DEFAULT && proto != Q_UDP && proto != Q_TCP &&
        proto != Q_SCTP)
        bpf_error(cs, "illegal qualifier of 'portrange'");
    if (v1 > 65535)
        bpf_error(cs, "illegal port number %u > 65535", v1);
    if (v2 > 65535)
        bpf_error(cs, "illegal port number %u > 65535", v2);

    ipproto = (proto == Q_UDP) ? IPPROTO_UDP :
              (proto == Q_TCP) ? IPPROTO_TCP :
              (proto == Q_SCTP) ? IPPROTO_SCTP : -1;
    b = gen_portrange(cs, v1, v2, ipproto, dir);
    b6 = gen_portrange6(cs, v1, v2, ipproto, dir);
    return bx_or(cs, b6, b);
}

bexp_t gen_mcode(cstate_t *cs, const char *s1, const char *s2, uint32_t masklen,
                 qual_t q)
{
    int nlen, mlen;
    uint32_t n, m;

    nlen = atoin(s1, &n);
    if (nlen < 0)
        bpf_error(cs, "invalid IPv4 address '%s'", s1);
    if (nlen < 32) n <<= 32 - nlen;

    if (s2 != NULL) {
        mlen = atoin(s2, &m);
        if (mlen < 0)
            bpf_error(cs, "invalid IPv4 address '%s'", s2);
        if (mlen < 32) m <<= 32 - mlen;
        if ((n & ~m) != 0)
            bpf_error(cs, "non-network bits set in \"%s mask %s\"", s1, s2);
    } else {
        if (masklen > 32)
            bpf_error(cs, "mask length must be <= 32");
        if (masklen == 0)
            m = 0;
        else
            m = 0xffffffffU << (32 - masklen);
        if ((n & ~m) != 0)
            bpf_error(cs, "non-network bits set in \"%s/%u\"", s1, masklen);
    }

    switch (q.addr) {
    case Q_NET:
        return gen_host(cs, n, m, q.proto, q.dir, q.addr);
    case Q_DEFAULT:
    case Q_HOST:
        return gen_host(cs, n, m, q.proto, q.dir, q.addr);
    default:
        bpf_error(cs, "Mask syntax for networks only");
    }
    return gen_false(cs);
}

bexp_t gen_mcode6(cstate_t *cs, const char *s1, uint32_t masklen, qual_t q)
{
    uint8_t addr[16], mask[16];
    unsigned i;

    if (!parse_ip6(s1, addr))
        bpf_error(cs, "invalid IPv6 address '%s'", s1);
    if (masklen > 128)
        bpf_error(cs, "mask length must be <= 128");
    memset(mask, 0, sizeof(mask));
    for (i = 0; i < masklen; i++)
        mask[i / 8] |= (uint8_t)(0x80 >> (i % 8));
    for (i = 0; i < 16; i++)
        if ((addr[i] & ~mask[i]) != 0)
            bpf_error(cs, "non-network bits set in \"%s/%u\"", s1, masklen);

    switch (q.addr) {
    case Q_DEFAULT:
    case Q_HOST:
        if (masklen != 128)
            bpf_error(cs, "Mask syntax for networks only");
        /* FALLTHROUGH */
    case Q_NET:
        return gen_host6(cs, addr, mask, q.proto, q.dir, q.addr);
    default:
        bpf_error(cs, "invalid qualifier against IPv6 address");
    }
    return gen_false(cs);
}

bexp_t gen_ecode(cstate_t *cs, const char *s, qual_t q)
{
    uint8_t eaddr[6];

    if (!parse_ether(s, eaddr))
        bpf_error(cs, "malformed ethernet address '%s'", s);

    if ((q.addr == Q_HOST || q.addr == Q_DEFAULT) && q.proto == Q_LINK)
        return gen_mac48host(cs, eaddr, q.dir, "ethernet");
    bpf_error(cs, "ethernet address used in non-ether expression");
    return gen_false(cs);
}

static int lookup_proto(cstate_t *cs, const char *name, int proto)
{
    int v;

    switch (proto) {
    case Q_DEFAULT:
    case Q_IP:
    case Q_IPV6:
        if (!nm_proto(name, &v))
            bpf_error(cs, "unknown ip proto '%s'", name);
        return v;
    case Q_LINK:
        if (!nm_eproto(name, &v)) {
            if (!nm_llcsap(name, &v))
                bpf_error(cs, "unknown ether proto '%s'", name);
        }
        return v;
    case Q_ISO:
        if (strcmp(name, "esis") == 0) return ISO9542_ESIS;
        if (strcmp(name, "isis") == 0) return ISO10589_ISIS;
        if (strcmp(name, "clnp") == 0) return ISO8473_CLNP;
        bpf_error(cs, "unknown osi proto '%s'", name);
        return 0;
    default:
        bpf_error(cs, "unknown protocol qualifier");
        return 0;
    }
}

bexp_t gen_scode(cstate_t *cs, const char *name, qual_t q)
{
    int proto = q.proto;
    int dir = q.dir;
    uint32_t mask, addr;
    bexp_t b, tmp;
    int have = 0;
    nm_addr_t addrs[16];
    int n, i, port, real_proto;
    uint8_t mask128[16];

    switch (q.addr) {

    case Q_NET:
        if (!nm_network(name, &addr))
            bpf_error(cs, "unknown network '%s'", name);
        mask = 0xffffffffU;
        if (addr == 0)
            bpf_error(cs, "unknown network '%s'", name);
        while ((addr & 0xff000000U) == 0) {
            addr <<= 8;
            mask <<= 8;
        }
        return gen_host(cs, addr, mask, proto, dir, q.addr);

    case Q_DEFAULT:
    case Q_HOST:
        if (proto == Q_LINK) {
            uint8_t eaddr[6];
            if (!nm_ether(name, eaddr))
                bpf_error(cs, "unknown ether host '%s'", name);
            return gen_mac48host(cs, eaddr, dir, "ethernet");
        }
        n = nm_host(name, addrs, 16);
        if (n == 0)
            bpf_error(cs, "unknown host '%s'", name);
        memset(mask128, 0xff, sizeof(mask128));
        for (i = 0; i < n; i++) {
            if (addrs[i].af == 4) {
                uint32_t a;
                if (proto == Q_IPV6) continue;
                a = ((uint32_t)addrs[i].a[0] << 24) | ((uint32_t)addrs[i].a[1] << 16) |
                    ((uint32_t)addrs[i].a[2] << 8) | addrs[i].a[3];
                tmp = gen_host(cs, a, 0xffffffffU,
                               proto == Q_DEFAULT ? Q_DEFAULT : proto, dir, q.addr);
            } else {
                if (proto == Q_IP || proto == Q_ARP || proto == Q_RARP) continue;
                tmp = gen_host6(cs, addrs[i].a, mask128,
                                proto == Q_DEFAULT ? Q_DEFAULT : proto, dir, q.addr);
            }
            if (have) b = bx_or(cs, b, tmp);
            else { b = tmp; have = 1; }
        }
        if (!have)
            bpf_error(cs, "unknown host '%s'", name);
        return b;

    case Q_PORT: {
        int rp;
        bexp_t b4, b6;
        if (proto != Q_DEFAULT && proto != Q_UDP && proto != Q_TCP &&
            proto != Q_SCTP)
            bpf_error(cs, "illegal qualifier of 'port'");
        if (!nm_port(name, &port, &rp))
            bpf_error(cs, "unknown port '%s'", name);
        if (proto == Q_UDP) {
            if (rp == IPPROTO_TCP)
                bpf_error(cs, "port '%s' is tcp", name);
            else if (rp == IPPROTO_SCTP)
                bpf_error(cs, "port '%s' is sctp", name);
            else
                rp = IPPROTO_UDP;
        } else if (proto == Q_TCP) {
            if (rp == IPPROTO_UDP)
                bpf_error(cs, "port '%s' is udp", name);
            else if (rp == IPPROTO_SCTP)
                bpf_error(cs, "port '%s' is sctp", name);
            else
                rp = IPPROTO_TCP;
        } else if (proto == Q_SCTP) {
            if (rp == IPPROTO_UDP)
                bpf_error(cs, "port '%s' is udp", name);
            else if (rp == IPPROTO_TCP)
                bpf_error(cs, "port '%s' is tcp", name);
            else
                rp = IPPROTO_SCTP;
        }
        if (port > 65535)
            bpf_error(cs, "illegal port number %d > 65535", port);
        if (rp == 0) rp = -1;
        b4 = gen_port(cs, (uint32_t)port, rp, dir);
        b6 = gen_port6(cs, (uint32_t)port, rp, dir);
        return bx_or(cs, b6, b4);
    }

    case Q_PORTRANGE: {
        int rp, p1, p2;
        bexp_t b4, b6;
        if (proto != Q_DEFAULT && proto != Q_UDP && proto != Q_TCP &&
            proto != Q_SCTP)
            bpf_error(cs, "illegal qualifier of 'portrange'");
        if (!nm_portrange(name, &p1, &p2, &rp))
            bpf_error(cs, "unknown port in range '%s'", name);
        if (proto == Q_UDP) {
            if (rp == IPPROTO_TCP)
                bpf_error(cs, "port in range '%s' is tcp", name);
            else if (rp == IPPROTO_SCTP)
                bpf_error(cs, "port in range '%s' is sctp", name);
            else
                rp = IPPROTO_UDP;
        } else if (proto == Q_TCP) {
            if (rp == IPPROTO_UDP)
                bpf_error(cs, "port in range '%s' is udp", name);
            else if (rp == IPPROTO_SCTP)
                bpf_error(cs, "port in range '%s' is sctp", name);
            else
                rp = IPPROTO_TCP;
        } else if (proto == Q_SCTP) {
            if (rp == IPPROTO_UDP)
                bpf_error(cs, "port in range '%s' is udp", name);
            else if (rp == IPPROTO_TCP)
                bpf_error(cs, "port in range '%s' is tcp", name);
            else
                rp = IPPROTO_SCTP;
        }
        if (p1 > 65535)
            bpf_error(cs, "illegal port number %d > 65535", p1);
        if (p2 > 65535)
            bpf_error(cs, "illegal port number %d > 65535", p2);
        if (rp == 0) rp = -1;
        b4 = gen_portrange(cs, (uint32_t)p1, (uint32_t)p2, rp, dir);
        b6 = gen_portrange6(cs, (uint32_t)p1, (uint32_t)p2, rp, dir);
        return bx_or(cs, b6, b4);
    }

    case Q_GATEWAY:
        bpf_error(cs, "'gateway' not supported in this configuration");

    case Q_PROTO:
        real_proto = lookup_proto(cs, name, proto);
        return gen_proto(cs, (uint32_t)real_proto, proto, dir);

    case Q_PROTOCHAIN:
        real_proto = lookup_proto(cs, name, proto);
        return gen_protochain(cs, (uint32_t)real_proto, proto);

    case Q_UNDEF:
        bpf_error(cs, "illegal qualifier");
    }
    bpf_error(cs, "bogus qualifier");
    return gen_false(cs);
}

bexp_t gen_acode(cstate_t *cs, const char *s, qual_t q)
{
    (void)s;
    (void)q;
    bpf_error(cs, "ARCnet address used in non-arc expression");
    return gen_false(cs);
}
