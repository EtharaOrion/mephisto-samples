/*
 * emit.c - flatten the block graph into a cBPF instruction array, plus the
 * top-level compile driver.
 */
#include <stdio.h>
#include <string.h>

#include "comp.h"
#include "gen.h"

static int slength(slist_t *s)
{
    int n = 0;
    for (; s; s = s->next)
        if (s->s.code != NOP_CODE)
            n++;
    return n;
}

typedef struct {
    bpf_prog_t *prog;
    int         tail;
    int         mark;
} conv_t;

static void count_r(block_t *b, int mark, int *nblk, int *nstmt)
{
    if (!b || b->mark == mark)
        return;
    b->mark = mark;
    (*nblk)++;
    *nstmt += slength(b->stmts);
    if (JT(b)) {
        count_r(JT(b), mark, nblk, nstmt);
        count_r(JF(b), mark, nblk, nstmt);
    }
}

static int convert_r(conv_t *c, block_t *p)
{
    bpf_insn_t *dst;
    slist_t *src;
    int slen, off, i;
    slist_t *offset[256];
    int nsl = 0;

    if (!p || p->mark == c->mark)
        return 1;
    p->mark = c->mark;

    if (JT(p)) {
        if (!convert_r(c, JF(p))) return 0;
        if (!convert_r(c, JT(p))) return 0;
    }

    slen = slength(p->stmts);
    c->tail -= (slen + 1 + p->longjt + p->longjf);
    dst = &c->prog->insns[c->tail];
    p->offset = c->tail;

    if (slen > 0 && slen < 256) {
        for (src = p->stmts; src; src = src->next)
            if (src->s.code != NOP_CODE)
                offset[nsl++] = src;
    }

    i = 0;
    for (src = p->stmts; src; src = src->next) {
        if (src->s.code == NOP_CODE)
            continue;
        dst->code = src->s.code;
        dst->k = src->s.k;
        dst->jt = 0;
        dst->jf = 0;
        if (BPF_CLASS(src->s.code) == BPF_JMP &&
            src->s.code != (BPF_JMP | BPF_JA)) {
            int j;
            int jt = 0, jf = 0;
            for (j = 0; j < nsl; j++) {
                if (src->s.jt && offset[j] == src->s.jt) jt = j - i - 1;
                if (src->s.jf && offset[j] == src->s.jf) jf = j - i - 1;
            }
            if (!src->s.jt) jt = 0;
            if (!src->s.jf) jf = 0;
            dst->jt = (uint8_t)jt;
            dst->jf = (uint8_t)jf;
        }
        ++dst;
        ++i;
    }

    dst->code = p->s.code;
    dst->k = p->s.k;
    dst->jt = 0;
    dst->jf = 0;
    if (BPF_CLASS(p->s.code) == BPF_JMP) {
        int extrajmps = 0;
        off = JT(p)->offset - (p->offset + slen) - 1;
        if (off >= 256) {
            if (p->longjt == 0) { p->longjt++; return 0; }
            dst->jt = (uint8_t)extrajmps;
            extrajmps++;
            dst[extrajmps].code = BPF_JMP | BPF_JA;
            dst[extrajmps].k = (uint32_t)(off - extrajmps);
            dst[extrajmps].jt = 0;
            dst[extrajmps].jf = 0;
        } else
            dst->jt = (uint8_t)off;
        off = JF(p)->offset - (p->offset + slen) - 1;
        if (off >= 256) {
            if (p->longjf == 0) { p->longjf++; return 0; }
            dst->jf = (uint8_t)extrajmps;
            extrajmps++;
            dst[extrajmps].code = BPF_JMP | BPF_JA;
            dst[extrajmps].k = (uint32_t)(off - extrajmps);
            dst[extrajmps].jt = 0;
            dst[extrajmps].jf = 0;
        } else
            dst->jf = (uint8_t)off;
    }
    return 1;
}

void icode_to_fcode(cstate_t *cs, block_t *root, bpf_prog_t *out)
{
    int nblk, nstmt, n;
    conv_t c;
    static int markgen = 1000000;

    for (;;) {
        nblk = 0;
        nstmt = 0;
        markgen++;
        count_r(root, markgen, &nblk, &nstmt);
        n = nblk + nstmt;
        /* room for long jumps */
        n += 2 * nblk;
        if ((size_t)n > out->cap) {
            free(out->insns);
            out->insns = (bpf_insn_t *)malloc(sizeof(bpf_insn_t) * (size_t)n);
            out->cap = (size_t)n;
        }
        c.prog = out;
        c.tail = n;
        markgen++;
        c.mark = markgen;
        if (convert_r(&c, root))
            break;
    }
    /* the program starts at the root block's offset */
    out->len = (size_t)(n - c.tail);
    if (c.tail != 0)
        memmove(out->insns, &out->insns[c.tail],
                out->len * sizeof(bpf_insn_t));
    (void)cs;
}

/* ------------------------------------------------------------- driver */

static block_t *gen_retblk(cstate_t *cs, int v)
{
    block_t *b = new_block(cs, BPF_RET | BPF_K);
    b->s.k = (uint32_t)v;
    return b;
}

int compile_filter(cstate_t *cs, const char *text, int dlt, int snaplen,
                   uint32_t netmask, int optimize, bpf_prog_t *out,
                   const char **err)
{
    bexp_t e;
    block_t *root;
    int i;

    arena_reset(cs);
    cs->linktype = dlt;
    cs->snaplen = snaplen;
    cs->netmask = netmask;
    cs->failed = 0;
    cs->nblocks = 0;
    cs->all_blocks = NULL;
    cs->curreg = 0;
    for (i = 0; i < BPF_MEMWORDS; i++)
        cs->regused[i] = 0;
    out->len = 0;

    if (setjmp(cs->jmp)) {
        *err = cs->errbuf;
        return -1;
    }

    init_linktype(cs);
    e = parse_filter(cs, text);

    if (e.entry == NULL) {
        root = gen_retblk(cs, snaplen);
    } else {
        block_t *rt, *rf;
        insert_compute_vloffsets(cs, e.entry);
        rt = gen_retblk(cs, snaplen);
        bx_patch_t(e, rt);
        rf = gen_retblk(cs, 0);
        bx_patch_f(e, rf);
        root = e.entry;
    }

    if (optimize && !cs->no_optimize) {
        cs->root = root;
        bpf_optimize(cs);
        root = cs->root;
        if (root->s.code == (BPF_RET | BPF_K) && root->s.k == 0) {
            *err = "expression rejects all packets";
            return -1;
        }
    }

    icode_to_fcode(cs, root, out);
    return 0;
}
