/*
 * opt.c - block-graph optimizer (placeholder).
 */
#include "comp.h"

void bpf_optimize(cstate_t *cs)
{
    (void)cs;
}
