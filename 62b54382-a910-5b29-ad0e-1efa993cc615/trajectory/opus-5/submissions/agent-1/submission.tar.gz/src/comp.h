/*
 * comp.h - shared types for the filter compiler.
 *
 * The compiler builds a graph of basic blocks (each a statement list plus a
 * terminating conditional branch), then flattens it into cBPF.
 */
#ifndef COMP_H
#define COMP_H

#include <setjmp.h>
#include <stdint.h>
#include <stddef.h>

#include "bpf_defs.h"

#define OFFSET_NOT_SET 0xffffffffU

#define Q_UNDEF 255

/* qualifier codes: protocol */
enum {
    Q_DEFAULT = 0, Q_LINK, Q_IP, Q_ARP, Q_RARP, Q_SCTP, Q_TCP, Q_UDP,
    Q_ICMP, Q_IGMP, Q_IGRP, Q_ATALK, Q_DECNET, Q_LAT, Q_SCA, Q_MOPRC, Q_MOPDL,
    Q_IPV6, Q_ICMPV6, Q_AH, Q_ESP, Q_PIM, Q_VRRP, Q_AARP, Q_ISO, Q_ESIS,
    Q_ISIS, Q_CLNP, Q_STP, Q_IPX, Q_NETBEUI,
    Q_ISIS_L1, Q_ISIS_L2, Q_ISIS_IIH, Q_ISIS_SNP, Q_ISIS_CSNP, Q_ISIS_PSNP,
    Q_ISIS_LSP, Q_RADIO, Q_CARP
};

/* direction / address qualifiers */
enum {
    Q_HOST = 1, Q_NET, Q_PORT, Q_GATEWAY, Q_PROTO, Q_PROTOCHAIN, Q_PORTRANGE
};
enum {
    Q_SRC = 1, Q_DST, Q_OR, Q_AND, Q_ADDR1, Q_ADDR2, Q_ADDR3, Q_ADDR4,
    Q_RA, Q_TA
};

/* q triple packed */
typedef struct { int proto, dir, addr; } qual_t;

struct slist_s;

typedef struct stmt_s {
    uint16_t        code;
    uint32_t        k;
    struct slist_s *jt, *jf;   /* only for jumps inside a statement list */
} stmt_t;

typedef struct slist_s {
    stmt_t          s;
    struct slist_s *next;
} slist_t;

#define NOP_CODE 0xffff

struct block_s;

typedef struct edge_s {
    int              id;
    int              code;
    uint32_t         pred_val;
    struct block_s  *succ;
    struct block_s  *pred;
    struct edge_s   *next;   /* in-edge chain of succ */
    uint32_t        *edom;
} edge_t;

#define N_ATOMS (BPF_MEMWORDS + 2)

typedef struct block_s {
    int         id;
    slist_t    *stmts;
    stmt_t      s;
    int         mark;
    int         longjt, longjf;
    int         level;
    int         offset;
    edge_t      et, ef;
    struct block_s *link;      /* level chain */
    /* unresolved-exit threading (front end) */
    struct block_s *tnext, *fnext;
    /* optimizer scratch */
    uint32_t   *dom, *closure;
    edge_t     *in_edges;
    uint32_t    val[N_ATOMS];
    uint32_t    oval;
    int         out_use;
    struct block_s *next_free;
} block_t;

#define JT(b) ((b)->et.succ)
#define JF(b) ((b)->ef.succ)

/* A boolean sub-expression under construction: entry block plus the lists of
 * block exits that are still unbound. */
typedef struct exit_s {
    block_t      *b;
    int           isjt;
    struct exit_s *next;
} exit_t;

typedef struct { exit_t *head, *tail; } exlist_t;

typedef struct {
    block_t *entry;
    exlist_t t, f;
} bexp_t;

/* variable-offset register slots */
#define VR_NONE     (-1)
#define VR_LINKHDR  0
#define VR_LINKPL   1
#define VR_COUNT    2

typedef struct {
    int      is_variable;
    uint32_t constant_part;
    int      regid;          /* VR_* slot holding the variable part */
} absoff_t;

/* offset bases */
enum offrel {
    OR_PACKET, OR_LINKHDR, OR_PREVLINKHDR, OR_LLC, OR_PREVMPLSHDR,
    OR_LINKPL, OR_LINKPL_NOSNAP, OR_LINKTYPE, OR_TRAN_IPV4, OR_TRAN_IPV6
};

typedef struct arth_s {
    bexp_t   b;
    int      has_b;
    slist_t *s;
    int      regno;
} arth_t;

#define ARENA_CHUNK (1u << 16)
typedef struct arena_chunk {
    struct arena_chunk *next;
    size_t used, size;
    char  *mem;
} arena_chunk_t;

typedef struct {
    /* input */
    int      linktype;
    int      outermostlinktype;
    int      prevlinktype;
    int      snaplen;
    uint32_t netmask;
    int      no_optimize;

    /* link layer geometry */
    absoff_t off_linkhdr;
    absoff_t off_prevlinkhdr;
    absoff_t off_linktype;
    absoff_t off_linkpl;
    uint32_t off_nl, off_nl_nosnap;
    uint32_t off_outermostlinkhdr_const;
    int      is_encap;          /* inside vlan/mpls/pppoe/geneve */
    int      is_vlan_vloffset;
    int      label_stack_depth;
    int      vlan_stack_depth;
    uint32_t pcap_fddipad;

    /* register allocation */
    int      regused[BPF_MEMWORDS];
    int      curreg;
    int      vreg[VR_COUNT];

    /* error handling */
    jmp_buf  jmp;
    char     errbuf[256];
    int      failed;

    /* arena */
    arena_chunk_t *chunks;
    arena_chunk_t *cur;

    /* block bookkeeping */
    int      nblocks;
    block_t *all_blocks;     /* chain via next_free */

    block_t *root;
    /* filter text cursor for the lexer */
    const char *text;
} cstate_t;

/* ---- arena ---- */
void  arena_init(cstate_t *cs);
void *arena_alloc(cstate_t *cs, size_t n);
void  arena_reset(cstate_t *cs);
void  arena_free(cstate_t *cs);

/* ---- error ---- */
void bpf_error(cstate_t *cs, const char *fmt, ...);

/* ---- codegen primitives ---- */
slist_t *new_stmt(cstate_t *cs, uint16_t code);
block_t *new_block(cstate_t *cs, uint16_t code);
slist_t *sappend(slist_t *s0, slist_t *s1);

bexp_t  bx_leaf_cs(cstate_t *cs, block_t *b);
bexp_t  bx_and(cstate_t *cs, bexp_t a, bexp_t b);
bexp_t  bx_or(cstate_t *cs, bexp_t a, bexp_t b);
bexp_t  bx_not(bexp_t a);
void    bx_patch_t(bexp_t e, block_t *tgt);
void    bx_patch_f(bexp_t e, block_t *tgt);

/* ---- entry points ---- */
int compile_filter(cstate_t *cs, const char *text, int dlt, int snaplen,
                   uint32_t netmask, int optimize, bpf_prog_t *out,
                   const char **err);

/* internal stages */
void     init_linktype(cstate_t *cs);
bexp_t   parse_filter(cstate_t *cs, const char *text);
void     bpf_optimize(cstate_t *cs);
void     icode_to_fcode(cstate_t *cs, block_t *root, bpf_prog_t *out);

#endif /* COMP_H */
