/*
 * gen4.c - 802.11 frame filters, LLC filters and protocol chains.
 */
#include <string.h>

#include "comp.h"
#include "gen.h"

/* multicast on 802.11: the address depends on the To DS / From DS bits */
bexp_t gen_wlanmulticast(cstate_t *cs)
{
    bexp_t b0, b1, b2;
    slist_t *s;
    block_t *blk;

    /* addr1 (RA) is the destination for To-DS = 0 */
    b0 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0, 0x01);
    s = gen_load_a(cs, OR_LINKHDR, 4, BPF_B);
    blk = new_block(cs, BPF_JMP | BPF_JSET | BPF_K);
    blk->s.k = 1;
    blk->stmts = s;
    b1 = bx_and(cs, b0, bx_leaf_cs(cs, blk));

    b0 = gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, 0x01, 0x01);
    s = gen_load_a(cs, OR_LINKHDR, 16, BPF_B);
    blk = new_block(cs, BPF_JMP | BPF_JSET | BPF_K);
    blk->s.k = 1;
    blk->stmts = s;
    b2 = bx_and(cs, b0, bx_leaf_cs(cs, blk));

    return bx_or(cs, b1, b2);
}

static void check_80211(cstate_t *cs)
{
    switch (cs->linktype) {
    case DLT_IEEE802_11:
    case DLT_PRISM_HEADER:
    case DLT_IEEE802_11_RADIO_AVS:
    case DLT_IEEE802_11_RADIO:
        return;
    default:
        bpf_error(cs, "802.11 link-layer types supported only on 802.11");
    }
}

bexp_t gen_p80211_type(cstate_t *cs, int type, int mask)
{
    check_80211(cs);
    return gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, (uint32_t)type, (uint32_t)mask);
}

bexp_t gen_p80211_fcdir(cstate_t *cs, int fcdir)
{
    switch (cs->linktype) {
    case DLT_IEEE802_11:
    case DLT_PRISM_HEADER:
    case DLT_IEEE802_11_RADIO_AVS:
    case DLT_IEEE802_11_RADIO:
        break;
    default:
        bpf_error(cs, "frame direction supported only with 802.11 headers");
    }
    return gen_mcmp(cs, OR_LINKHDR, 1, BPF_B, (uint32_t)fcdir, 0x03);
}

/* ------------------------------------------------------------------ llc */

static void check_llc(cstate_t *cs)
{
    switch (cs->linktype) {
    case DLT_EN10MB:
    case DLT_IEEE802:
    case DLT_IEEE802_11:
    case DLT_PRISM_HEADER:
    case DLT_IEEE802_11_RADIO_AVS:
    case DLT_IEEE802_11_RADIO:
    case DLT_FDDI:
    case DLT_ATM_RFC1483:
    case DLT_SUNATM:
        return;
    default:
        bpf_error(cs, "'llc' not supported for %d", cs->linktype);
    }
}

bexp_t gen_llc_generic(cstate_t *cs)
{
    bexp_t b0, b1;

    check_llc(cs);
    b0 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
    b0 = bx_not(b0);
    b1 = gen_cmp(cs, OR_LLC, 0, BPF_H, 0xFFFF);
    b1 = bx_not(b1);
    return bx_and(cs, b0, b1);
}

bexp_t gen_llc_i(cstate_t *cs)
{
    bexp_t b0, b1;

    b0 = gen_llc_generic(cs);
    b1 = gen_mcmp(cs, OR_LLC, 2, BPF_B, 0, 0x01);
    return bx_and(cs, b0, b1);
}

bexp_t gen_llc_s(cstate_t *cs)
{
    bexp_t b0, b1;

    b0 = gen_llc_generic(cs);
    b1 = gen_mcmp(cs, OR_LLC, 2, BPF_B, 0x01, 0x03);
    return bx_and(cs, b0, b1);
}

bexp_t gen_llc_u(cstate_t *cs)
{
    bexp_t b0, b1;

    b0 = gen_llc_generic(cs);
    b1 = gen_mcmp(cs, OR_LLC, 2, BPF_B, 0x03, 0x03);
    return bx_and(cs, b0, b1);
}

bexp_t gen_llc_s_subtype(cstate_t *cs, uint32_t subtype)
{
    bexp_t b0, b1;

    b0 = gen_llc_generic(cs);
    b1 = gen_mcmp(cs, OR_LLC, 2, BPF_B, subtype, 0x0f);
    return bx_and(cs, b0, b1);
}

bexp_t gen_llc_u_subtype(cstate_t *cs, uint32_t subtype)
{
    bexp_t b0, b1;

    b0 = gen_llc_generic(cs);
    b1 = gen_mcmp(cs, OR_LLC, 2, BPF_B, subtype, 0xef);
    return bx_and(cs, b0, b1);
}

/* ----------------------------------------------------------- protochain */

bexp_t gen_protochain(cstate_t *cs, uint32_t v, int proto)
{
    if (cs->off_linkpl.is_variable)
        bpf_error(cs, "'protochain' not supported with variable length headers");
    /* not yet implemented: fall back to a plain proto match */
    return gen_proto(cs, v, proto, Q_DEFAULT);
}

bexp_t gen_geneve(cstate_t *cs, uint32_t vni, int has_vni)
{
    (void)vni;
    (void)has_vni;
    bpf_error(cs, "geneve not supported");
    return gen_false(cs);
}

bexp_t gen_atmtype_abbrev(cstate_t *cs, int type)
{
    (void)type;
    bpf_error(cs, "ATM type filtering not supported");
    return gen_false(cs);
}
