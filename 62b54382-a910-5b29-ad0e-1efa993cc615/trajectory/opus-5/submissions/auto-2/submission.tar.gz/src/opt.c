/*
 * opt.c - block-graph optimizer (placeholder).
 */
#include "comp.h"

void refine_graph(ctx_t *cs)
{
    (void)cs;
}
