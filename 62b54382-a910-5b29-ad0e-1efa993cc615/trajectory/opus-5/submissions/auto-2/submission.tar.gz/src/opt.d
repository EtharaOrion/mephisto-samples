src/opt.o: src/opt.c src/comp.h src/bpf_defs.h
src/comp.h:
src/bpf_defs.h:
