/*
 * gen4.c - 802.11 frame filters, LLC filters and protocol chains.
 */
#include <string.h>

#include "comp.h"
#include "gen.h"

/* multicast on 802.11: the address depends on the To DS / From DS bits */
test_t wlan_group_test(ctx_t *cs)
{
    test_t b0, b1, b2;
    op_t *s;
    node_t *blk;

    /* addr1 (RA) is the destination for To-DS = 0 */
    b0 = wcmp_mask(cs, B_HDR, 1, BPF_B, 0, 0x01);
    s = fetch_a(cs, B_HDR, 4, BPF_B);
    blk = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    blk->s.k = 1;
    blk->stmts = s;
    b1 = bx_and(cs, b0, bx_leaf_cs(cs, blk));

    b0 = wcmp_mask(cs, B_HDR, 1, BPF_B, 0x01, 0x01);
    s = fetch_a(cs, B_HDR, 16, BPF_B);
    blk = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    blk->s.k = 1;
    blk->stmts = s;
    b2 = bx_and(cs, b0, bx_leaf_cs(cs, blk));

    return bx_or(cs, b1, b2);
}

static void need_w80211(ctx_t *cs)
{
    switch (cs->link) {
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        return;
    default:
        fail(cs, "802.11 link-layer types supported only on 802.11");
    }
}

test_t w80211_type(ctx_t *cs, int type, int mask)
{
    need_w80211(cs);
    return wcmp_mask(cs, B_HDR, 0, BPF_B, (uint32_t)type, (uint32_t)mask);
}

test_t w80211_dir(ctx_t *cs, int fcdir)
{
    switch (cs->link) {
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        break;
    default:
        fail(cs, "frame direction supported only with 802.11 headers");
    }
    return wcmp_mask(cs, B_HDR, 1, BPF_B, (uint32_t)fcdir, 0x03);
}

/* ------------------------------------------------------------------ llc */

static void need_llc(ctx_t *cs)
{
    switch (cs->link) {
    case LNK_EN10MB:
    case LNK_IEEE802:
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
    case LNK_FDDI:
    case LNK_ATM_RFC1483:
    case LNK_SUNATM:
        return;
    default:
        fail(cs, "'llc' not supported for %d", cs->link);
    }
}

test_t llc_any(ctx_t *cs)
{
    test_t b0, b1;

    need_llc(cs);
    b0 = wcmp_gt(cs, B_TYPE, 0, BPF_H, MAX_LEN_FIELD);
    b0 = bx_not(b0);
    b1 = wcmp_eq(cs, B_LLC, 0, BPF_H, 0xFFFF);
    b1 = bx_not(b1);
    return bx_and(cs, b0, b1);
}

test_t llc_info(ctx_t *cs)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, 0, 0x01);
    return bx_and(cs, b0, b1);
}

test_t llc_super(ctx_t *cs)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, 0x01, 0x03);
    return bx_and(cs, b0, b1);
}

test_t llc_unnum(ctx_t *cs)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, 0x03, 0x03);
    return bx_and(cs, b0, b1);
}

test_t llc_super_sub(ctx_t *cs, uint32_t subtype)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, subtype, 0x0f);
    return bx_and(cs, b0, b1);
}

test_t llc_unnum_sub(ctx_t *cs, uint32_t subtype)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, subtype, 0xef);
    return bx_and(cs, b0, b1);
}

/* ----------------------------------------------------------- protochain */

test_t chain_test(ctx_t *cs, uint32_t v, int proto)
{
    if (cs->pay_at.dynamic)
        fail(cs, "'protochain' not supported with variable length headers");
    /* not yet implemented: fall back to a plain proto match */
    return nl_proto_test(cs, v, proto, QU_DEFAULT);
}

test_t geneve_step(ctx_t *cs, uint32_t vni, int has_vni)
{
    (void)vni;
    (void)has_vni;
    fail(cs, "geneve not supported");
    return always_no(cs);
}

test_t atm_abbrev(ctx_t *cs, int type)
{
    (void)type;
    fail(cs, "ATM type filtering not supported");
    return always_no(cs);
}
