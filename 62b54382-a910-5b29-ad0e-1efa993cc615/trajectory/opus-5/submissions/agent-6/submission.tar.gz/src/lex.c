/*
 * lex.c - filter expression tokenizer.
 */
#include <string.h>
#include <stdlib.h>

#include "lex.h"

typedef struct { const char *name; int tok; } kw_t;

static const kw_t keywords[] = {
    {"dst", K_DST}, {"src", K_SRC},
    {"host", K_HOST}, {"gateway", K_GATEWAY},
    {"net", K_NET}, {"netmask", K_NETMASK}, {"mask", K_NETMASK},
    {"port", K_PORT}, {"portrange", K_PORTRANGE},
    {"proto", K_PROTO}, {"protochain", K_PROTOCHAIN},
    {"byte", K_CBYTE},
    {"arp", K_ARP}, {"rarp", K_RARP}, {"ip", K_IP},
    {"sctp", K_SCTP}, {"tcp", K_TCP}, {"udp", K_UDP},
    {"icmp", K_ICMP}, {"igmp", K_IGMP}, {"igrp", K_IGRP},
    {"pim", K_PIM}, {"vrrp", K_VRRP}, {"carp", K_CARP},
    {"atalk", K_ATALK}, {"aarp", K_AARP}, {"decnet", K_DECNET},
    {"lat", K_LAT}, {"sca", K_SCA}, {"moprc", K_MOPRC}, {"mopdl", K_MOPDL},
    {"stp", K_STP}, {"ipx", K_IPX}, {"netbeui", K_NETBEUI},
    {"iso", K_ISO}, {"esis", K_ESIS}, {"es-is", K_ESIS},
    {"isis", K_ISIS}, {"is-is", K_ISIS},
    {"l1", K_L1}, {"l2", K_L2}, {"iih", K_IIH}, {"lsp", K_LSP},
    {"snp", K_SNP}, {"csnp", K_CSNP}, {"psnp", K_PSNP}, {"clnp", K_CLNP},
    {"ip6", K_IPV6}, {"icmp6", K_ICMPV6}, {"ah", K_AH}, {"esp", K_ESP},
    {"link", K_LINK}, {"ether", K_LINK}, {"ppp", K_PPP}, {"slip", K_SLIP},
    {"fddi", K_LINK}, {"tr", K_LINK}, {"wlan", K_LINK},
    {"greater", K_GREATER}, {"less", K_LESS},
    {"broadcast", K_BROADCAST}, {"multicast", K_MULTICAST},
    {"and", K_AND}, {"or", K_OR}, {"not", K_NOT},
    {"len", K_LEN}, {"length", K_LEN},
    {"inbound", K_INBOUND}, {"outbound", K_OUTBOUND},
    {"ifindex", K_IFINDEX},
    {"vlan", K_VLAN}, {"mpls", K_MPLS},
    {"pppoed", K_PPPOED}, {"pppoes", K_PPPOES}, {"geneve", K_GENEVE},
    {"type", K_TYPE}, {"subtype", K_SUBTYPE}, {"dir", K_DIR},
    {"ra", K_RA}, {"ta", K_TA},
    {"addr1", K_ADDR1}, {"address1", K_ADDR1},
    {"addr2", K_ADDR2}, {"address2", K_ADDR2},
    {"addr3", K_ADDR3}, {"address3", K_ADDR3},
    {"addr4", K_ADDR4}, {"address4", K_ADDR4},
    {"radio", K_RADIO}, {"llc", K_LLC},
    {NULL, 0}
};

/* names that lex as plain numbers */
static const kw_t numnames[] = {
    {"icmptype", 0}, {"icmpcode", 1},
    {"icmp-echoreply", 0}, {"icmp-unreach", 3}, {"icmp-sourcequench", 4},
    {"icmp-redirect", 5}, {"icmp-echo", 8}, {"icmp-routeradvert", 9},
    {"icmp-routersolicit", 10}, {"icmp-timxceed", 11}, {"icmp-paramprob", 12},
    {"icmp-tstamp", 13}, {"icmp-tstampreply", 14}, {"icmp-ireq", 15},
    {"icmp-ireqreply", 16}, {"icmp-maskreq", 17}, {"icmp-maskreply", 18},
    {"tcpflags", 13},
    {"tcp-fin", 0x01}, {"tcp-syn", 0x02}, {"tcp-rst", 0x04},
    {"tcp-push", 0x08}, {"tcp-ack", 0x10}, {"tcp-urg", 0x20},
    {"tcp-ece", 0x40}, {"tcp-cwr", 0x80},
    {NULL, 0}
};

static int is_hex(int c)
{
    return (c >= '0' && c <= '9') || ((c | 0x20) >= 'a' && (c | 0x20) <= 'f');
}
static int is_alnum(int c)
{
    return (c >= '0' && c <= '9') || ((c | 0x20) >= 'a' && (c | 0x20) <= 'z');
}
static int is_idchar(int c)
{
    return is_alnum(c) || c == '_' || c == '-' || c == '.';
}

void lex_init(lexer_t *lx, ctx_t *cs, const char *text)
{
    lx->p = text;
    lx->cs = cs;
    lx->have_ahead = 0;
    lex_next(lx);
}

/* try to lex a dotted-quad host id at p; returns length or 0 */
static int try_hid(const char *p)
{
    int dots = 0, digits = 0, n = 0;

    while (1) {
        if (p[n] >= '0' && p[n] <= '9') { digits++; n++; continue; }
        if (p[n] == '.' && digits > 0) { dots++; digits = 0; n++; continue; }
        break;
    }
    if (dots == 3 && digits > 0 && !is_idchar(p[n]))
        return n;
    return 0;
}

/* ethernet address: B:B:B:B:B:B */
static int try_eid(const char *p)
{
    int i, n = 0, d;

    for (i = 0; i < 6; i++) {
        d = 0;
        while (is_hex(p[n]) && d < 2) { n++; d++; }
        if (d == 0) return 0;
        if (i < 5) {
            if (p[n] != ':') return 0;
            n++;
        }
    }
    if (is_idchar(p[n]) || p[n] == ':') return 0;
    return n;
}

/* IPv6 literal */
static int try_hid6(const char *p)
{
    int n = 0, colons = 0, seen_hex = 0, dcolon = 0;

    if (p[0] == ':' && p[1] != ':') return 0;
    while (is_hex(p[n]) || p[n] == ':' || p[n] == '.') {
        if (p[n] == ':') {
            colons++;
            if (n > 0 && p[n-1] == ':') dcolon = 1;
        } else if (p[n] != '.')
            seen_hex = 1;
        n++;
    }
    if (colons < 2 && !(colons == 1 && dcolon)) return 0;
    if (!seen_hex && !dcolon) return 0;
    if (is_alnum(p[n])) return 0;
    (void)seen_hex;
    return n;
}

void lex_next(lexer_t *lx)
{
    const char *p;
    token_t *t = &lx->tok;
    int n, i;

    if (lx->have_ahead) {
        lx->tok = lx->ahead;
        lx->have_ahead = 0;
        return;
    }

    p = lx->p;
    while (*p == ' ' || *p == '\t' || *p == '\n' || *p == '\r')
        p++;
    t->str[0] = '\0';
    t->num = 0;
    if (*p == '\0') {
        t->type = T_EOF;
        lx->p = p;
        return;
    }

    /* escaped identifier: \name */
    if (*p == '\\') {
        p++;
        n = 0;
        while (is_idchar(*p) && n < 120) t->str[n++] = *p++;
        t->str[n] = '\0';
        t->type = n ? T_ID : T_BAD;
        lx->p = p;
        return;
    }

    if (is_hex(*p) || ((*p == ':') && p[1] == ':')) {
        if ((n = try_eid(p)) != 0) {
            memcpy(t->str, p, (size_t)n);
            t->str[n] = '\0';
            t->type = T_EID;
            lx->p = p + n;
            return;
        }
        if ((n = try_hid6(p)) != 0) {
            memcpy(t->str, p, (size_t)n);
            t->str[n] = '\0';
            t->type = T_HID6;
            lx->p = p + n;
            return;
        }
        if ((n = try_hid(p)) != 0) {
            memcpy(t->str, p, (size_t)n);
            t->str[n] = '\0';
            t->type = T_HID;
            lx->p = p + n;
            return;
        }
    }

    if (*p >= '0' && *p <= '9') {
        /* number, unless it is really an identifier */
        const char *q = p;
        uint32_t v = 0;
        if (p[0] == '0' && (p[1] == 'x' || p[1] == 'X') && is_hex(p[2])) {
            q = p + 2;
            while (is_hex(*q)) {
                v = v * 16 + (uint32_t)((*q <= '9') ? *q - '0' : (*q | 0x20) - 'a' + 10);
                q++;
            }
        } else {
            while (*q >= '0' && *q <= '9') { v = v * 10 + (uint32_t)(*q - '0'); q++; }
        }
        if (!is_idchar(*q)) {
            t->type = T_NUM;
            t->num = v;
            lx->p = q;
            return;
        }
        /* falls through to the identifier scanner */
    }

    if (is_alnum(*p) || *p == '_') {
        n = 0;
        while (is_idchar(p[n]) && n < 120) n++;
        /* trailing '-' or '.' is not part of the identifier */
        while (n > 0 && (p[n-1] == '-' || p[n-1] == '.')) n--;
        memcpy(t->str, p, (size_t)n);
        t->str[n] = '\0';
        lx->p = p + n;
        for (i = 0; keywords[i].name; i++)
            if (strcmp(keywords[i].name, t->str) == 0) {
                t->type = keywords[i].tok;
                return;
            }
        for (i = 0; numnames[i].name; i++)
            if (strcmp(numnames[i].name, t->str) == 0) {
                t->type = T_NUM;
                t->num = (uint32_t)numnames[i].tok;
                return;
            }
        t->type = T_ID;
        return;
    }

    lx->p = p + 1;
    switch (*p) {
    case '(': t->type = T_LPAREN; return;
    case ')': t->type = T_RPAREN; return;
    case '[': t->type = T_LBRACK; return;
    case ']': t->type = T_RBRACK; return;
    case ':': t->type = T_COLON; return;
    case '/': t->type = T_SLASH; return;
    case '+': t->type = T_PLUS; return;
    case '-': t->type = T_MINUS; return;
    case '*': t->type = T_STAR; return;
    case '%': t->type = T_MOD; return;
    case '^': t->type = T_CARET; return;
    case '&':
        if (*lx->p == '&') { lx->p++; t->type = K_AND; return; }
        t->type = T_AMP; return;
    case '|':
        if (*lx->p == '|') { lx->p++; t->type = K_OR; return; }
        t->type = T_PIPE; return;
    case '=':
        if (*lx->p == '=') lx->p++;
        t->type = T_EQ; return;
    case '!':
        if (*lx->p == '=') { lx->p++; t->type = T_NE; return; }
        t->type = T_BANG; return;
    case '<':
        if (*lx->p == '=') { lx->p++; t->type = T_LE; return; }
        if (*lx->p == '<') { lx->p++; t->type = T_LSH; return; }
        t->type = T_LT; return;
    case '>':
        if (*lx->p == '=') { lx->p++; t->type = T_GE; return; }
        if (*lx->p == '>') { lx->p++; t->type = T_RSH; return; }
        t->type = T_GT; return;
    default:
        t->type = T_BAD;
        return;
    }
}

token_t *lex_peek(lexer_t *lx)
{
    if (!lx->have_ahead) {
        token_t save = lx->tok;
        lex_next(lx);
        lx->ahead = lx->tok;
        lx->have_ahead = 1;
        lx->tok = save;
    }
    return &lx->ahead;
}
