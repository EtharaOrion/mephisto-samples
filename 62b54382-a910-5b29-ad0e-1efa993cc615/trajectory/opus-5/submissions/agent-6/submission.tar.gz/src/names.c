/*
 * names.c - name resolution against the pinned tables.
 *
 * The tables are compiled in from tables_gen.h, which is generated offline
 * from the files under etc/.
 */
#include <string.h>
#include <strings.h>

#include "names.h"
#include "tables_gen.h"

#define NELEM(a) (sizeof(a) / sizeof((a)[0]))

int nm_proto(const char *name, int *val)
{
    size_t i;
    for (i = 0; i < NELEM(proto_tab); i++) {
        if (strcmp(proto_tab[i].name, name) == 0) {
            *val = proto_tab[i].val;
            return 1;
        }
    }
    return 0;
}

static int lookup_serv(const char *name, const char *proto)
{
    size_t i;
    for (i = 0; i < NELEM(serv_tab); i++)
        if (strcmp(serv_tab[i].name, name) == 0 &&
            strcmp(serv_tab[i].proto, proto) == 0)
            return serv_tab[i].port;
    return -1;
}

static int all_digits(const char *s)
{
    if (!*s) return 0;
    for (; *s; s++)
        if (*s < '0' || *s > '9') return 0;
    return 1;
}

/* mirrors pcap_nametoport(): a numeric string, or a service resolved for
 * TCP and/or UDP. *proto is 0 when the name means the same in both. */
int nm_port(const char *name, int *port, int *proto)
{
    int tcp_port, udp_port;

    if (all_digits(name)) {
        long v = 0;
        const char *s = name;
        for (; *s; s++) {
            v = v * 10 + (*s - '0');
            if (v > 4294967295L) return 0;
        }
        *port = (int)v;
        *proto = 0;
        return 1;
    }
    tcp_port = lookup_serv(name, "tcp");
    udp_port = lookup_serv(name, "udp");
    if (tcp_port >= 0 && udp_port >= 0) {
        if (tcp_port != udp_port)
            return 0;
        *port = tcp_port;
        *proto = 0;
        return 1;
    }
    if (tcp_port >= 0) { *port = tcp_port; *proto = 6; return 1; }
    if (udp_port >= 0) { *port = udp_port; *proto = 17; return 1; }
    return 0;
}

int nm_portrange(const char *name, int *p1, int *p2, int *proto)
{
    char buf[128];
    char *dash;
    int save;

    if (strlen(name) >= sizeof(buf)) return 0;
    strcpy(buf, name);
    dash = strchr(buf, '-');
    if (!dash) return 0;
    *dash = '\0';
    if (!nm_port(buf, p1, proto)) return 0;
    save = *proto;
    if (!nm_port(dash + 1, p2, proto)) return 0;
    if (*proto != save) *proto = 0;
    return 1;
}

typedef struct { const char *s; int v; } sv2_t;

static const sv2_t eproto_db[] = {
    {"pup", 0x0200}, {"xns", 0x0600}, {"ip", 0x0800}, {"ip6", 0x86dd},
    {"arp", 0x0806}, {"rarp", 0x8035}, {"sprite", 0x0500}, {"mopdl", 0x6001},
    {"moprc", 0x6002}, {"decnet", 0x6003}, {"lat", 0x6004}, {"sca", 0x6007},
    {"lanbridge", 0x8038}, {"vexp", 0x805b}, {"vprod", 0x805c},
    {"atalk", 0x809b}, {"atalkarp", 0x80f3}, {"loopback", 0x9000},
    {"decdts", 0x803c}, {"decdns", 0x803e}, {NULL, 0}
};

static const sv2_t llc_db[] = {
    {"iso", 0xfe}, {"stp", 0x42}, {"ipx", 0xe0}, {"netbeui", 0xf0}, {NULL, 0}
};

int nm_eproto(const char *name, int *val)
{
    int i;
    for (i = 0; eproto_db[i].s; i++)
        if (strcmp(eproto_db[i].s, name) == 0) { *val = eproto_db[i].v; return 1; }
    return 0;
}

int nm_llcsap(const char *name, int *val)
{
    int i;
    for (i = 0; llc_db[i].s; i++)
        if (strcmp(llc_db[i].s, name) == 0) { *val = llc_db[i].v; return 1; }
    return 0;
}

int nm_network(const char *name, uint32_t *val)
{
    size_t i;
    for (i = 0; i < NELEM(net_tab); i++) {
        if (strcmp(net_tab[i].name, name) == 0) {
            *val = (uint32_t)net_tab[i].val;
            return 1;
        }
    }
    return 0;
}

int nm_host(const char *name, nm_addr_t *out, int max)
{
    size_t i;
    int n = 0;
    for (i = 0; i < NELEM(host_tab) && n < max; i++) {
        if (strcmp(host_tab[i].name, name) == 0) {
            out[n].af = host_tab[i].af;
            memcpy(out[n].a, host_tab[i].a, 16);
            n++;
        }
    }
    return n;
}

int nm_ether(const char *name, unsigned char *out)
{
    (void)name;
    (void)out;
    return 0;   /* the pinned ethers table is empty */
}
