#ifndef GEN_H
#define GEN_H

#include "comp.h"

/* data link types */
#define LNK_NULL        0
#define LNK_EN10MB      1
#define LNK_EN3MB       2
#define LNK_AX25        3
#define LNK_PRONET      4
#define LNK_CHAOS       5
#define LNK_IEEE802     6
#define LNK_ARCNET      7
#define LNK_SLIP        8
#define LNK_PPP         9
#define LNK_FDDI        10
#define LNK_ATM_RFC1483 11
#define LNK_RAW         12
#define LNK_SLIP_BSDOS  15
#define LNK_PPP_BSDOS   16
#define LNK_ATM_CLIP    19
#define LNK_PPP_SERIAL  50
#define LNK_PPP_ETHER   51
#define LNK_SYMANTEC_FIREWALL 99
#define LNK_C_HDLC      104
#define LNK_IEEE802_11  105
#define LNK_FRELAY      107
#define LNK_LOOP        108
#define LNK_ENC         109
#define LNK_LINUX_SLL   113
#define LNK_LTALK       114
#define LNK_PFLOG       117
#define LNK_PRISM_HEADER 119
#define LNK_IP_OVER_FC  122
#define LNK_SUNATM      123
#define LNK_IEEE802_11_RADIO 127
#define LNK_ARCNET_LINUX 129
#define LNK_JUNIPER_ATM1 137
#define LNK_APPLE_IP_OVER_IEEE1394 138
#define LNK_IEEE802_11_RADIO_AVS 163
#define LNK_PPP_PPPD    166
#define LNK_IPV4        228
#define LNK_IPV6        229
#define LNK_NETANALYZER 240
#define LNK_NETANALYZER_TRANSPARENT 241
#define LNK_LINUX_SLL2  276

/* ethertypes and protocol numbers used by the generator */
#define TY_IP4      0x0800
#define TY_ARP     0x0806
#define TY_RARP  0x8035
#define TY_IP6    0x86dd
#define TY_ATALK   0x809b
#define TY_AARP    0x80f3
#define TY_DECNET      0x6003
#define TY_LAT     0x6004
#define TY_SCA     0x6007
#define TY_MOPDL   0x6001
#define TY_MOPRC   0x6002
#define TY_IPX     0x8137
#define TY_LOOP 0x9000
#define TY_TAG    0x8100
#define TY_TAGAD    0x88a8
#define TY_TAG9100 0x9100
#define TY_LABEL    0x8847
#define TY_LABELM 0x8848
#define TY_PPPOED  0x8863
#define TY_PPPOES  0x8864
#define TY_XNS      0x0600
#define TY_SPRITE  0x0500
#define TY_TRAIL   0x1000
#define TY_TEB     0x6558

#define SAP_IP       0x06
#define SAP_STP    0x42
#define SAP_IPX      0xe0
#define SAP_NB  0xf0
#define SAP_OSI    0xfe
#define SAP_SNAP     0xaa

#define OSI_CLNP    0x81
#define OSI_ESIS    0x82
#define OSI_ISIS   0x83
#define OSI_ESIS25 0x8a

#define NP_HOP 0
#define NP_ICMP    1
#define NP_IGMP    2
#define NP_IPIP    4
#define NP_TCP     6
#define NP_EGP     8
#define NP_IGRP    9
#define NP_UDP     17
#define NP_DCCP    33
#define NP_IP6    41
#define NP_ROUTE 43
#define NP_FRAG 44
#define NP_RSVP    46
#define NP_GRE     47
#define NP_ESP     50
#define NP_AH      51
#define NP_MOB 55
#define NP_ICMP6  58
#define NP_NONE    59
#define NP_DSTOPT 60
#define NP_ND      77
#define NP_PIM     103
#define NP_VRRP    112
#define NP_CARP    112
#define NP_PGM     113
#define NP_SCTP    132
#define NP_MH      135
#define NP_SHIM6   140
#define NP_HIP     139

#define MAX_LEN_FIELD 1500

#define PP_IP4    0x0021
#define PP_IP6  0x0057
#define PP_IPX   0x002b
#define PP_OSI   0x0023
#define PP_CLNS 0x0023
#define PP_VJC   0x002d
#define PP_VJNC  0x002f
#define PP_DECNET 0x0027
#define PP_APPLE 0x0029
#define PP_XNS    0x0025
#define PP_LABEL 0x0281
#define PP_LABELM 0x0283
#define PP_COMP  0x00fd
#define PP_IPCP  0x8021

#define SLL_RAW802 0x0001
#define SLL_LLC 0x0004

/* offsets/sizes */
op_t *fetch_a(ctx_t *cs, enum basekind rel, uint32_t offset, uint32_t size);
op_t *base_to_x(ctx_t *cs, base_t *off);

test_t wcmp_eq(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v);
test_t wcmp_gt(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v);
test_t wcmp_ge(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v);
test_t wcmp_lt(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v);
test_t wcmp_le(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v);
test_t wcmp_mask(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v, uint32_t mask);
test_t wcmp_bytes(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, const uint8_t *v);
test_t always_yes(ctx_t *cs);
test_t always_no(ctx_t *cs);
test_t ll_type_test(ctx_t *cs, uint32_t ll_proto);

int    mem_take(ctx_t *cs);
void   mem_drop(ctx_t *cs, int n);

/* main generator entry points used by the parser */
test_t id_named(ctx_t *cs, const char *name, sel_t q);
test_t id_prefix4(ctx_t *cs, const char *s1, const char *s2, uint32_t masklen, sel_t q);
test_t id_prefix6(ctx_t *cs, const char *s1, uint32_t masklen, sel_t q);
test_t id_numeric(ctx_t *cs, const char *s, uint32_t v, sel_t q);
test_t id_mac(ctx_t *cs, const char *s, sel_t q);
test_t id_arcnet(ctx_t *cs, const char *s, sel_t q);
test_t abbrev_test(ctx_t *cs, int proto);
test_t val_compare(ctx_t *cs, int code, val_t *a0, val_t *a1, int reversed);
test_t len_below(ctx_t *cs, uint32_t n);
test_t len_above(ctx_t *cs, uint32_t n);
test_t raw_byte_test(ctx_t *cs, int op, int idx, uint32_t val);
test_t bcast_test(ctx_t *cs, int proto);
test_t mcast_test(ctx_t *cs, int proto);
test_t ifidx_test(ctx_t *cs, int ifindex);
test_t travel_test(ctx_t *cs, int dir);
test_t vlan_step(ctx_t *cs, uint32_t vlan_num, int has_vlan_tag);
test_t mpls_step(ctx_t *cs, uint32_t label, int has_label);
test_t pppoe_disc(ctx_t *cs);
test_t pppoe_sess(ctx_t *cs, uint32_t sess, int has_sess);
test_t geneve_step(ctx_t *cs, uint32_t vni, int has_vni);
test_t atm_abbrev(ctx_t *cs, int type);
test_t w80211_type(ctx_t *cs, int type, int mask);
test_t w80211_dir(ctx_t *cs, int fcdir);
test_t llc_any(ctx_t *cs);
test_t llc_info(ctx_t *cs);
test_t llc_super(ctx_t *cs);
test_t llc_unnum(ctx_t *cs);
test_t llc_super_sub(ctx_t *cs, uint32_t subtype);
test_t llc_unnum_sub(ctx_t *cs, uint32_t subtype);

test_t addr4_test(ctx_t *cs, uint32_t addr, uint32_t mask, int proto, int dir, int type);
test_t nl_proto_test(ctx_t *cs, uint32_t v, int proto, int dir);
test_t chain_test(ctx_t *cs, uint32_t v, int proto);
test_t unfragmented(ctx_t *cs);
test_t wlan_group_test(ctx_t *cs);
test_t id_range(ctx_t *cs, uint32_t v1, uint32_t v2, sel_t q);
op_t *v4hlen_to_x_ext(ctx_t *cs);
void prefix_offset_code(ctx_t *cs, node_t *b);
int scan_mac(const char *s, uint8_t *out);
int scan_v6(const char *s, uint8_t *out);

val_t *val_const(ctx_t *cs, uint32_t v);
val_t *val_slice(ctx_t *cs, int proto, val_t *index, uint32_t size);
val_t *val_pktlen(ctx_t *cs);
val_t *val_negate(ctx_t *cs, val_t *a);
val_t *val_binop(ctx_t *cs, int code, val_t *a0, val_t *a1);

#endif
