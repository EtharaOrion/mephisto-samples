/*
 * opt.c - graph refinement.
 *
 * Three things happen here, in order:
 *
 *   - a fixed point pass that numbers the values flowing through every
 *     block and drops branches whose outcome is already known on the path
 *     that reaches them;
 *   - a second fixed point pass that is additionally allowed to rewrite and
 *     delete statements;
 *   - a merge of blocks that ended up identical, followed by a tidy-up of
 *     the root.
 */
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"

#define A_SLOT  BPF_MEMWORDS
#define X_SLOT  (BPF_MEMWORDS + 1)
#define AX_SLOT N_ATOMS

#define SLOTBIT(n)     (1UL << (n))
#define HAS_SLOT(s, n) (((s) >> (n)) & 1)

#define VHASH 241

typedef struct vnode_s {
    int              code;
    uint32_t         v0, v1;
    uint32_t         val;
    struct vnode_s  *next;
} vnode_t;

typedef struct {
    ctx_t     *cs;
    node_t   **blocks;
    arc_t    **arcs;
    node_t   **levels;
    unsigned   nblk, narc, nlevels;
    unsigned   words;
    unsigned   awords;
    uint32_t  *domspace, *edomspace;
    vnode_t   *vpool;
    vnode_t   *hash[VHASH];
    unsigned   vused, vcap;
    uint32_t   curval;
    struct { uint32_t cval; int fixed; } *vmap;
    int        stable;
    int        mark;
} opt_t;

/* ------------------------------------------------------------- utilities */

static void walk_number(opt_t *o, node_t *b)
{
    if (!b || b->mark == o->mark)
        return;
    b->mark = o->mark;
    b->id = (int)o->nblk;
    o->blocks[o->nblk++] = b;
    walk_number(o, JT(b));
    walk_number(o, JF(b));
}

static unsigned count_reach(opt_t *o, node_t *b)
{
    unsigned n;
    if (!b || b->mark == o->mark)
        return 0;
    b->mark = o->mark;
    n = 1;
    n += count_reach(o, JT(b));
    n += count_reach(o, JF(b));
    return n;
}

/* ------------------------------------------------------------ value pool */

static void vals_reset(opt_t *o)
{
    o->curval = 0;
    o->vused = 0;
    memset(o->hash, 0, sizeof(o->hash));
    memset(o->vmap, 0, (o->vcap + 2) * sizeof(*o->vmap));
}

static uint32_t vnum(opt_t *o, int code, uint32_t v0, uint32_t v1)
{
    unsigned h = ((unsigned)code ^ (v0 << 4) ^ (v1 << 8)) % VHASH;
    vnode_t *p;

    for (p = o->hash[h]; p; p = p->next)
        if (p->code == code && p->v0 == v0 && p->v1 == v1)
            return p->val;

    if (o->vused >= o->vcap)
        return 0;
    p = &o->vpool[o->vused++];
    p->val = ++o->curval;
    p->code = code;
    p->v0 = v0;
    p->v1 = v1;
    p->next = o->hash[h];
    o->hash[h] = p;
    if (BPF_MODE(code) == BPF_IMM &&
        (BPF_CLASS(code) == BPF_LD || BPF_CLASS(code) == BPF_LDX)) {
        o->vmap[p->val].cval = v0;
        o->vmap[p->val].fixed = 1;
    }
    return p->val;
}

static uint32_t vconst(opt_t *o, uint32_t k)
{
    return vnum(o, BPF_LD | BPF_IMM, k, 0);
}

/* ------------------------------------------------------- use/def analysis */

static int slot_used(ins_t *s)
{
    int c = BPF_CLASS(s->code);

    if (s->code == NOP_CODE)
        return -1;
    switch (c) {
    case BPF_RET:
        if ((s->code & 0x18) == 0x10) return A_SLOT;
        return -1;
    case BPF_LD:
    case BPF_LDX:
        if (BPF_MODE(s->code) == BPF_IND) return X_SLOT;
        if (BPF_MODE(s->code) == BPF_MEM) return (int)s->k;
        return -1;
    case BPF_ST:
        return A_SLOT;
    case BPF_STX:
        return X_SLOT;
    case BPF_JMP:
    case BPF_ALU:
        if (BPF_SRC(s->code) == BPF_X) return AX_SLOT;
        return A_SLOT;
    case BPF_MISC:
        return BPF_MISCOP(s->code) == BPF_TXA ? X_SLOT : A_SLOT;
    }
    return -1;
}

static int slot_set(ins_t *s)
{
    if (s->code == NOP_CODE)
        return -1;
    switch (BPF_CLASS(s->code)) {
    case BPF_LD:
    case BPF_ALU:
        return A_SLOT;
    case BPF_LDX:
        return X_SLOT;
    case BPF_ST:
    case BPF_STX:
        return (int)s->k;
    case BPF_MISC:
        return BPF_MISCOP(s->code) == BPF_TAX ? X_SLOT : A_SLOT;
    }
    return -1;
}

static void local_ud(node_t *b)
{
    op_t *s;
    unsigned long def = 0, use = 0, kill = 0;
    int a;

    for (s = b->stmts; s; s = s->next) {
        if (s->s.code == NOP_CODE)
            continue;
        a = slot_used(&s->s);
        if (a >= 0) {
            if (a == AX_SLOT) {
                if (!HAS_SLOT(def, X_SLOT)) use |= SLOTBIT(X_SLOT);
                if (!HAS_SLOT(def, A_SLOT)) use |= SLOTBIT(A_SLOT);
            } else if (a < N_ATOMS) {
                if (!HAS_SLOT(def, a)) use |= SLOTBIT(a);
            }
        }
        a = slot_set(&s->s);
        if (a >= 0) {
            if (!HAS_SLOT(use, a)) kill |= SLOTBIT(a);
            def |= SLOTBIT(a);
        }
    }
    a = slot_used(&b->s);
    if (a >= 0) {
        if (a == AX_SLOT) {
            if (!HAS_SLOT(def, X_SLOT)) use |= SLOTBIT(X_SLOT);
            if (!HAS_SLOT(def, A_SLOT)) use |= SLOTBIT(A_SLOT);
        } else if (a < N_ATOMS) {
            if (!HAS_SLOT(def, a)) use |= SLOTBIT(a);
        }
    }
    b->def = def;
    b->kill = kill;
    b->in_use = use;
}

/* --------------------------------------------------------- graph walking */

static void level_walk(opt_t *o, node_t *b)
{
    int lv;

    if (b->mark == o->mark)
        return;
    b->mark = o->mark;
    b->link = NULL;

    if (JT(b)) {
        level_walk(o, JT(b));
        level_walk(o, JF(b));
        lv = JT(b)->level;
        if (JF(b)->level > lv) lv = JF(b)->level;
        lv++;
    } else
        lv = 0;
    b->level = lv;
    b->link = o->levels[lv];
    o->levels[lv] = b;
}

static void find_levels(opt_t *o)
{
    unsigned i;
    for (i = 0; i < o->nlevels; i++)
        o->levels[i] = NULL;
    o->mark++;
    level_walk(o, o->cs->root);
}

static void find_dom(opt_t *o)
{
    unsigned i, w;
    int lv;
    node_t *b;

    for (i = 0; i < o->nblk * o->words; i++)
        o->domspace[i] = 0xffffffffU;
    for (w = 0; w < o->words; w++)
        o->cs->root->dom[w] = 0;

    for (lv = o->cs->root->level; lv >= 0; lv--) {
        for (b = o->levels[lv]; b; b = b->link) {
            b->dom[b->id / 32] |= 1u << (b->id % 32);
            if (!JT(b))
                continue;
            for (w = 0; w < o->words; w++) {
                JT(b)->dom[w] &= b->dom[w];
                JF(b)->dom[w] &= b->dom[w];
            }
        }
    }
}

static void find_edom(opt_t *o)
{
    unsigned i, w;
    int lv;
    node_t *b;

    for (i = 0; i < o->narc * o->awords; i++)
        o->edomspace[i] = 0xffffffffU;
    for (w = 0; w < o->awords; w++) {
        o->cs->root->et.edom[w] = 0;
        o->cs->root->ef.edom[w] = 0;
    }
    for (lv = o->cs->root->level; lv >= 0; lv--) {
        for (b = o->levels[lv]; b; b = b->link) {
            b->et.edom[b->et.id / 32] |= 1u << (b->et.id % 32);
            b->ef.edom[b->ef.id / 32] |= 1u << (b->ef.id % 32);
            if (!JT(b))
                continue;
            for (w = 0; w < o->awords; w++) {
                JT(b)->et.edom[w] &= b->et.edom[w];
                JT(b)->ef.edom[w] &= b->et.edom[w];
                JF(b)->et.edom[w] &= b->ef.edom[w];
                JF(b)->ef.edom[w] &= b->ef.edom[w];
            }
        }
    }
}

static void find_ud(opt_t *o)
{
    int lv, top = o->cs->root->level;
    node_t *b;

    for (lv = top; lv >= 0; lv--)
        for (b = o->levels[lv]; b; b = b->link) {
            local_ud(b);
            b->out_use = 0;
        }
    for (lv = 1; lv <= top; lv++)
        for (b = o->levels[lv]; b; b = b->link) {
            b->out_use |= JT(b)->in_use | JF(b)->in_use;
            b->in_use |= b->out_use & ~b->kill;
        }
}

static void find_inedges(opt_t *o)
{
    unsigned i;
    int lv;
    node_t *b;

    for (i = 0; i < o->nblk; i++)
        o->blocks[i]->in_edges = NULL;

    for (lv = o->cs->root->level; lv > 0; lv--)
        for (b = o->levels[lv]; b; b = b->link) {
            b->et.next = JT(b)->in_edges;
            JT(b)->in_edges = &b->et;
            b->ef.next = JF(b)->in_edges;
            JF(b)->in_edges = &b->ef;
        }
}

/* ------------------------------------------------------ statement tuning */

static void store_val(ins_t *s, uint32_t *slot, uint32_t nv, int rewrite)
{
    if (rewrite && *slot == nv)
        s->code = NOP_CODE;
    else
        *slot = nv;
}

static void fold_binop(opt_t *o, ins_t *s, uint32_t v0, uint32_t v1)
{
    uint32_t a = o->vmap[v0].cval;
    uint32_t b = o->vmap[v1].cval;

    switch (BPF_OP(s->code)) {
    case BPF_ADD: a += b; break;
    case BPF_SUB: a -= b; break;
    case BPF_MUL: a *= b; break;
    case BPF_DIV:
        if (b == 0) return;
        a /= b;
        break;
    case BPF_MOD:
        if (b == 0) return;
        a %= b;
        break;
    case BPF_AND: a &= b; break;
    case BPF_OR:  a |= b; break;
    case BPF_XOR: a ^= b; break;
    case BPF_LSH: a = (b > 31) ? 0 : (a << b); break;
    case BPF_RSH: a = (b > 31) ? 0 : (a >> b); break;
    default: return;
    }
    s->k = a;
    s->code = BPF_LD | BPF_IMM;
    o->stable = 0;
}

static void tune_stmt(opt_t *o, ins_t *s, uint32_t *val, int rewrite)
{
    uint32_t v;
    int op;

    switch (s->code) {

    case BPF_LD | BPF_ABS | BPF_W:
    case BPF_LD | BPF_ABS | BPF_H:
    case BPF_LD | BPF_ABS | BPF_B:
        v = vnum(o, s->code, s->k, 0);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LD | BPF_IND | BPF_W:
    case BPF_LD | BPF_IND | BPF_H:
    case BPF_LD | BPF_IND | BPF_B:
        v = val[X_SLOT];
        if (rewrite && o->vmap[v].fixed) {
            s->code = (uint16_t)(BPF_LD | BPF_ABS | (s->code & 0x18));
            s->k += o->vmap[v].cval;
            v = vnum(o, s->code, s->k, 0);
            o->stable = 0;
        } else
            v = vnum(o, s->code, s->k, v);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LD | BPF_LEN:
        v = vnum(o, s->code, 0, 0);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LD | BPF_IMM:
        v = vconst(o, s->k);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LDX | BPF_IMM:
        v = vconst(o, s->k);
        store_val(s, &val[X_SLOT], v, rewrite);
        break;

    case BPF_LDX | BPF_MSH | BPF_B:
        v = vnum(o, s->code, s->k, 0);
        store_val(s, &val[X_SLOT], v, rewrite);
        break;

    case BPF_ALU | BPF_NEG:
        if (rewrite && o->vmap[val[A_SLOT]].fixed) {
            s->code = BPF_LD | BPF_IMM;
            s->k = 0u - o->vmap[val[A_SLOT]].cval;
            val[A_SLOT] = vconst(o, s->k);
            o->stable = 0;
        } else
            val[A_SLOT] = vnum(o, s->code, val[A_SLOT], 0);
        break;

    case BPF_ALU | BPF_ADD | BPF_K:
    case BPF_ALU | BPF_SUB | BPF_K:
    case BPF_ALU | BPF_MUL | BPF_K:
    case BPF_ALU | BPF_DIV | BPF_K:
    case BPF_ALU | BPF_MOD | BPF_K:
    case BPF_ALU | BPF_AND | BPF_K:
    case BPF_ALU | BPF_OR | BPF_K:
    case BPF_ALU | BPF_XOR | BPF_K:
    case BPF_ALU | BPF_LSH | BPF_K:
    case BPF_ALU | BPF_RSH | BPF_K:
        op = BPF_OP(s->code);
        if (rewrite) {
            if (s->k == 0) {
                if (op == BPF_ADD || op == BPF_SUB || op == BPF_OR ||
                    op == BPF_XOR || op == BPF_LSH || op == BPF_RSH) {
                    s->code = NOP_CODE;
                    o->stable = 0;
                    break;
                }
                if (op == BPF_MUL || op == BPF_AND) {
                    s->code = BPF_LD | BPF_IMM;
                    val[A_SLOT] = vconst(o, s->k);
                    o->stable = 0;
                    break;
                }
            }
            if (o->vmap[val[A_SLOT]].fixed) {
                fold_binop(o, s, val[A_SLOT], vconst(o, s->k));
                val[A_SLOT] = vconst(o, s->k);
                break;
            }
        }
        val[A_SLOT] = vnum(o, s->code, val[A_SLOT], vconst(o, s->k));
        break;

    case BPF_ALU | BPF_ADD | BPF_X:
    case BPF_ALU | BPF_SUB | BPF_X:
    case BPF_ALU | BPF_MUL | BPF_X:
    case BPF_ALU | BPF_DIV | BPF_X:
    case BPF_ALU | BPF_MOD | BPF_X:
    case BPF_ALU | BPF_AND | BPF_X:
    case BPF_ALU | BPF_OR | BPF_X:
    case BPF_ALU | BPF_XOR | BPF_X:
    case BPF_ALU | BPF_LSH | BPF_X:
    case BPF_ALU | BPF_RSH | BPF_X:
        op = BPF_OP(s->code);
        if (rewrite && o->vmap[val[X_SLOT]].fixed) {
            if (o->vmap[val[A_SLOT]].fixed) {
                fold_binop(o, s, val[A_SLOT], val[X_SLOT]);
                val[A_SLOT] = vconst(o, s->k);
            } else {
                s->code = (uint16_t)(BPF_ALU | BPF_K | op);
                s->k = o->vmap[val[X_SLOT]].cval;
                o->stable = 0;
                val[A_SLOT] = vnum(o, s->code, val[A_SLOT], vconst(o, s->k));
            }
            break;
        }
        if (rewrite && o->vmap[val[A_SLOT]].fixed &&
            o->vmap[val[A_SLOT]].cval == 0) {
            if (op == BPF_ADD || op == BPF_OR || op == BPF_XOR) {
                s->code = BPF_MISC | BPF_TXA;
                store_val(s, &val[A_SLOT], val[X_SLOT], rewrite);
                o->stable = 0;
                break;
            }
            if (op == BPF_MUL || op == BPF_DIV || op == BPF_MOD ||
                op == BPF_AND || op == BPF_LSH || op == BPF_RSH) {
                s->code = BPF_LD | BPF_IMM;
                s->k = 0;
                store_val(s, &val[A_SLOT], vconst(o, 0), rewrite);
                o->stable = 0;
                break;
            }
        }
        val[A_SLOT] = vnum(o, s->code, val[A_SLOT], val[X_SLOT]);
        break;

    case BPF_MISC | BPF_TXA:
        store_val(s, &val[A_SLOT], val[X_SLOT], rewrite);
        break;

    case BPF_LD | BPF_MEM:
        v = val[s->k];
        if (rewrite && o->vmap[v].fixed) {
            s->code = BPF_LD | BPF_IMM;
            s->k = o->vmap[v].cval;
            o->stable = 0;
        }
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_MISC | BPF_TAX:
        store_val(s, &val[X_SLOT], val[A_SLOT], rewrite);
        break;

    case BPF_LDX | BPF_MEM:
        v = val[s->k];
        if (rewrite && o->vmap[v].fixed) {
            s->code = BPF_LDX | BPF_IMM;
            s->k = o->vmap[v].cval;
            o->stable = 0;
        }
        store_val(s, &val[X_SLOT], v, rewrite);
        break;

    case BPF_ST:
        store_val(s, &val[s->k], val[A_SLOT], rewrite);
        break;

    case BPF_STX:
        store_val(s, &val[s->k], val[X_SLOT], rewrite);
        break;

    default:
        break;
    }
}

static op_t *real_op(op_t *s)
{
    while (s && s->s.code == NOP_CODE)
        s = s->next;
    return s;
}

static void peep(opt_t *o, node_t *b)
{
    op_t *s = b->stmts, *next, *last;

    if (!s)
        return;
    last = s;
    for (;; s = s->next) {
        s = real_op(s);
        if (!s)
            break;
        next = real_op(s->next);
        if (!next)
            break;
        last = next;

        if (s->s.code == BPF_ST && next->s.code == (BPF_LDX | BPF_MEM) &&
            s->s.k == next->s.k) {
            o->stable = 0;
            next->s.code = BPF_MISC | BPF_TAX;
        }
        if (s->s.code == (BPF_LD | BPF_IMM) &&
            next->s.code == (BPF_MISC | BPF_TAX)) {
            s->s.code = BPF_LDX | BPF_IMM;
            next->s.code = BPF_MISC | BPF_TXA;
            o->stable = 0;
        }
        if (s->s.code == (BPF_LD | BPF_IMM)) {
            op_t *add, *tax, *ild;

            if (HAS_SLOT(b->out_use, X_SLOT))
                continue;
            if (next->s.code != (BPF_LDX | BPF_MSH | BPF_B))
                add = next;
            else
                add = real_op(next->next);
            if (!add || add->s.code != (BPF_ALU | BPF_ADD | BPF_X))
                continue;
            tax = real_op(add->next);
            if (!tax || tax->s.code != (BPF_MISC | BPF_TAX))
                continue;
            ild = real_op(tax->next);
            if (!ild || BPF_CLASS(ild->s.code) != BPF_LD ||
                BPF_MODE(ild->s.code) != BPF_IND)
                continue;
            ild->s.k += s->s.k;
            s->s.code = NOP_CODE;
            add->s.code = NOP_CODE;
            tax->s.code = NOP_CODE;
            o->stable = 0;
        }
    }

    if (b->s.code == (BPF_JMP | BPF_JEQ | BPF_K) && b->s.k == 0 &&
        last->s.code == (BPF_ALU | BPF_AND | BPF_K) &&
        !HAS_SLOT(b->out_use, A_SLOT)) {
        node_t *tmp;
        b->s.code = BPF_JMP | BPF_JSET | BPF_K;
        b->s.k = last->s.k;
        last->s.code = NOP_CODE;
        tmp = JT(b);
        JT(b) = JF(b);
        JF(b) = tmp;
        o->stable = 0;
    }
}

static void kill_dead_stores(opt_t *o, node_t *b)
{
    op_t *s;
    ins_t *last[N_ATOMS];
    int a, i;

    memset(last, 0, sizeof(last));
    for (s = b->stmts; s; s = s->next) {
        a = slot_used(&s->s);
        if (a >= 0) {
            if (a == AX_SLOT) { last[X_SLOT] = NULL; last[A_SLOT] = NULL; }
            else if (a < N_ATOMS) last[a] = NULL;
        }
        a = slot_set(&s->s);
        if (a >= 0 && a < N_ATOMS) {
            if (last[a]) { o->stable = 0; last[a]->code = NOP_CODE; }
            last[a] = &s->s;
        }
    }
    a = slot_used(&b->s);
    if (a >= 0) {
        if (a == AX_SLOT) { last[X_SLOT] = NULL; last[A_SLOT] = NULL; }
        else if (a < N_ATOMS) last[a] = NULL;
    }
    for (i = 0; i < N_ATOMS; i++)
        if (last[i] && !HAS_SLOT(b->out_use, i)) {
            last[i]->code = NOP_CODE;
            o->stable = 0;
        }
}

static void tune_block(opt_t *o, node_t *b, int rewrite)
{
    arc_t *p;
    op_t *s;
    int i;
    uint32_t aval, xval;

    p = b->in_edges;
    if (!p)
        memset(b->val, 0, sizeof(b->val));
    else {
        memcpy(b->val, p->pred->val, sizeof(b->val));
        while ((p = p->next) != NULL)
            for (i = 0; i < N_ATOMS; i++)
                if (b->val[i] != p->pred->val[i])
                    b->val[i] = 0;
    }
    aval = b->val[A_SLOT];
    xval = b->val[X_SLOT];
    for (s = b->stmts; s; s = s->next)
        tune_stmt(o, &s->s, b->val, rewrite);

    if (rewrite &&
        ((b->out_use == 0 && aval != 0 && b->val[A_SLOT] == aval &&
          xval != 0 && b->val[X_SLOT] == xval) ||
         BPF_CLASS(b->s.code) == BPF_RET)) {
        if (b->stmts) {
            b->stmts = NULL;
            o->stable = 0;
        }
    } else if (rewrite) {
        peep(o, b);
        kill_dead_stores(o, b);
    }

    if (rewrite && BPF_CLASS(b->s.code) == BPF_JMP &&
        BPF_SRC(b->s.code) == BPF_K && o->vmap[b->val[A_SLOT]].fixed) {
        uint32_t a = o->vmap[b->val[A_SLOT]].cval;
        uint32_t k = b->s.k;
        int taken = -1;
        switch (BPF_OP(b->s.code)) {
        case BPF_JEQ:  taken = (a == k); break;
        case BPF_JGT:  taken = (a > k); break;
        case BPF_JGE:  taken = (a >= k); break;
        case BPF_JSET: taken = ((a & k) != 0); break;
        default: break;
        }
        if (taken >= 0) {
            node_t *t = taken ? JT(b) : JF(b);
            if (JT(b) != t || JF(b) != t) {
                JT(b) = t;
                JF(b) = t;
                o->stable = 0;
            }
        }
    }

    if (BPF_SRC(b->s.code) == BPF_K)
        b->oval = vconst(o, b->s.k);
    else
        b->oval = b->val[X_SLOT];
    b->et.code = (int)b->s.code;
    b->ef.code = -(int)b->s.code;
}

/* ------------------------------------------------------- branch shifting */

static int use_conflict(node_t *b, node_t *succ)
{
    int i;
    unsigned long use = succ->out_use;

    if (use == 0)
        return 0;
    for (i = 0; i < N_ATOMS; i++)
        if (HAS_SLOT(use, i) && b->val[i] != succ->val[i])
            return 1;
    return 0;
}

static node_t *fold_arc(node_t *child, arc_t *ep)
{
    int sense;
    int code = ep->code;

    if (code < 0) { code = -code; sense = 0; }
    else sense = 1;

    if ((int)child->s.code != code)
        return NULL;
    if (child->val[A_SLOT] != ep->pred->val[A_SLOT])
        return NULL;
    if (child->oval == ep->pred->oval)
        return sense ? JT(child) : JF(child);
    if (sense && code == (BPF_JMP | BPF_JEQ | BPF_K))
        return JF(child);
    return NULL;
}

static void shift_arc(opt_t *o, arc_t *ep)
{
    unsigned i;
    uint32_t x;
    int k;
    node_t *target;

    if (!JT(ep->succ))
        return;
    if (JT(ep->succ) == JF(ep->succ)) {
        if (!use_conflict(ep->succ, JT(ep->succ))) {
            o->stable = 0;
            ep->succ = JT(ep->succ);
        }
    }
again:
    for (i = 0; i < o->awords; i++) {
        x = ep->edom[i];
        while (x != 0) {
            k = 0;
            while (((x >> k) & 1) == 0) k++;
            x &= ~(1u << k);
            if ((unsigned)(k + i * 32) >= o->narc)
                continue;
            target = fold_arc(ep->succ, o->arcs[k + i * 32]);
            if (target && !use_conflict(ep->succ, target)) {
                o->stable = 0;
                ep->succ = target;
                if (JT(target))
                    goto again;
                return;
            }
        }
    }
}

/* ------------------------------------------------------------- merging */

static int same_ins(ins_t *a, ins_t *b)
{
    return a->code == b->code && a->k == b->k;
}

static int same_ops(op_t *x, op_t *y)
{
    for (;;) {
        while (x && x->s.code == NOP_CODE) x = x->next;
        while (y && y->s.code == NOP_CODE) y = y->next;
        if (!x || !y)
            return x == y;
        if (!same_ins(&x->s, &y->s))
            return 0;
        x = x->next;
        y = y->next;
    }
}

static int same_block(node_t *a, node_t *b)
{
    return a->s.code == b->s.code && a->s.k == b->s.k &&
           JT(a) == JT(b) && JF(a) == JF(b) && same_ops(a->stmts, b->stmts);
}

/* route around blocks whose two exits ended up identical */
static void bypass_dead(opt_t *o)
{
    unsigned i;
    int changed;

    do {
        changed = 0;
        for (i = 0; i < o->nblk; i++) {
            node_t *b = o->blocks[i];
            if (!JT(b))
                continue;
            while (JT(JT(b)) && JT(JT(b)) == JF(JT(b)) &&
                   !use_conflict(JT(b), JT(JT(b)))) {
                JT(b) = JT(JT(b));
                changed = 1;
            }
            while (JT(JF(b)) && JT(JF(b)) == JF(JF(b)) &&
                   !use_conflict(JF(b), JT(JF(b)))) {
                JF(b) = JT(JF(b));
                changed = 1;
            }
        }
    } while (changed);
}

static void merge_blocks(opt_t *o)
{
    unsigned i, j;
    node_t *p;
    int again;

    do {
        again = 0;
        for (i = 0; i < o->nblk; i++)
            o->blocks[i]->link = NULL;

        o->mark++;
        count_reach(o, o->cs->root);

        for (i = o->nblk; i-- > 0; ) {
            if (o->blocks[i]->mark != o->mark)
                continue;
            for (j = i + 1; j < o->nblk; j++) {
                if (o->blocks[j]->mark != o->mark)
                    continue;
                if (same_block(o->blocks[i], o->blocks[j])) {
                    o->blocks[i]->link = o->blocks[j]->link ?
                        o->blocks[j]->link : o->blocks[j];
                    break;
                }
            }
        }
        for (i = 0; i < o->nblk; i++) {
            p = o->blocks[i];
            if (!JT(p))
                continue;
            if (JT(p)->link) { again = 1; JT(p) = JT(p)->link; }
            if (JF(p)->link) { again = 1; JF(p) = JF(p)->link; }
        }
    } while (again);
}

static void tidy_root(node_t **rp)
{
    op_t *tmp, *s;

    s = (*rp)->stmts;
    (*rp)->stmts = NULL;
    while (BPF_CLASS((*rp)->s.code) == BPF_JMP && JT(*rp) == JF(*rp))
        *rp = JT(*rp);

    tmp = (*rp)->stmts;
    if (tmp)
        op_cat(s, tmp);
    (*rp)->stmts = s;

    if (BPF_CLASS((*rp)->s.code) == BPF_RET)
        (*rp)->stmts = NULL;
}

/* ------------------------------------------------------------- main loop */

static void tune_all(opt_t *o, int rewrite)
{
    int lv, top = o->cs->root->level;
    node_t *b;

    vals_reset(o);
    find_inedges(o);
    for (lv = top; lv >= 0; lv--)
        for (b = o->levels[lv]; b; b = b->link)
            tune_block(o, b, rewrite);

    if (rewrite)
        return;

    for (lv = 1; lv <= top; lv++)
        for (b = o->levels[lv]; b; b = b->link) {
            shift_arc(o, &b->et);
            shift_arc(o, &b->ef);
        }
}

static void run_loop(opt_t *o, int rewrite)
{
    int guard = 0;

    do {
        o->stable = 1;
        find_levels(o);
        find_dom(o);
        find_edom(o);
        find_ud(o);
        tune_all(o, rewrite);
        if (++guard > 100)
            break;
    } while (!o->stable);
}

void refine_graph(ctx_t *cs)
{
    opt_t o;
    unsigned i, n;
    static int markbase = 1;

    memset(&o, 0, sizeof(o));
    o.cs = cs;
    markbase += 4;
    o.mark = markbase;
    n = count_reach(&o, cs->root);
    if (n == 0)
        return;

    o.blocks = (node_t **)arena_alloc(cs, n * sizeof(node_t *));
    o.arcs = (arc_t **)arena_alloc(cs, 2 * n * sizeof(arc_t *));
    o.levels = (node_t **)arena_alloc(cs, (n + 2) * sizeof(node_t *));
    o.nlevels = n + 2;
    markbase += 4;
    o.mark = markbase;
    o.nblk = 0;
    walk_number(&o, cs->root);
    o.narc = 2 * o.nblk;
    o.words = (o.nblk + 31) / 32;
    o.awords = (o.narc + 31) / 32;
    o.domspace = (uint32_t *)arena_alloc(cs, o.nblk * o.words * sizeof(uint32_t));
    o.edomspace = (uint32_t *)arena_alloc(cs, o.narc * o.awords * sizeof(uint32_t));
    o.vcap = 8 * o.nblk + 64;
    o.vpool = (vnode_t *)arena_alloc(cs, o.vcap * sizeof(vnode_t));
    o.vmap = arena_alloc(cs, (o.vcap + 2) * sizeof(*o.vmap));

    for (i = 0; i < o.nblk; i++) {
        node_t *b = o.blocks[i];
        b->dom = &o.domspace[i * o.words];
        b->et.id = (int)i;
        b->ef.id = (int)(o.nblk + i);
        b->et.edom = &o.edomspace[(size_t)b->et.id * o.awords];
        b->ef.edom = &o.edomspace[(size_t)b->ef.id * o.awords];
        b->et.pred = b;
        b->ef.pred = b;
        o.arcs[b->et.id] = &b->et;
        o.arcs[b->ef.id] = &b->ef;
    }

    run_loop(&o, 0);
    run_loop(&o, 1);
    bypass_dead(&o);
    merge_blocks(&o);
    tidy_root(&cs->root);
}
