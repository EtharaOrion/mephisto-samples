/*
 * opt.c - graph refinement.
 *
 * Three things happen here, in order:
 *
 *   - a fixed point pass that numbers the values flowing through every
 *     block and drops branches whose outcome is already known on the path
 *     that reaches them;
 *   - a second fixed point pass that is additionally allowed to rewrite and
 *     delete statements;
 *   - a merge of blocks that ended up identical, followed by a tidy-up of
 *     the root.
 */
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"

/*
 * Slot layout: the accumulator and index register come first so that the
 * live prefix of the value array (A, X, then the scratch slots actually
 * allocated) is contiguous and cheap to copy between blocks.
 */
#define A_SLOT  0
#define X_SLOT  1
#define MEM_SLOT(k) ((int)(k) + 2)
#define AX_SLOT N_ATOMS

#define SLOTBIT(n)     (1u << (n))
#define HAS_SLOT(s, n) (((s) >> (n)) & 1)

#define VHASH 256   /* power of two so the bucket index is a mask */

typedef struct vnode_s {
    int              code;
    uint32_t         v0, v1;
    uint32_t         val;
    unsigned         hash;
    struct vnode_s  *next;
} vnode_t;

typedef struct {
    ctx_t     *cs;
    node_t   **blocks;
    arc_t    **arcs;
    node_t   **levels;
    unsigned   nblk, narc, nlevels;
    unsigned   words;
    unsigned   awords;
    uint32_t  *domspace, *edomspace;
    vnode_t   *vpool;
    vnode_t  **hash;
    unsigned   vused, vcap;
    uint32_t   curval;
    struct { uint32_t cval; int fixed; } *vmap;
    /* small cache in front of the constant lookups, tagged by pass */
    uint32_t   kc_key[64], kc_val[64], kc_gen[64], gen;
    int        stable;
    int        mark;
    unsigned   nval;         /* live prefix of val[]: A, X and used slots */
    unsigned   gchange;      /* bumped whenever a successor pointer moves */
    unsigned   levels_gen, inedge_gen;
} opt_t;

/* ------------------------------------------------------------- utilities */

/*
 * Counting the reachable blocks and numbering them are the same walk in the
 * same order, so do both at once and keep the vector between compiles.
 */
#define REFINE_MAX_BLOCKS 10000

static node_t **blk_vec;
static unsigned blk_vec_cap;

static void walk_number(opt_t *o, node_t *b)
{
    if (!b || b->mark == o->mark)
        return;
    b->mark = o->mark;
    if (o->nblk == blk_vec_cap) {
        unsigned cap = blk_vec_cap ? blk_vec_cap * 2 : 256;
        node_t **nv = (node_t **)realloc(blk_vec, cap * sizeof(*nv));

        if (!nv)
            fail(o->cs, "out of memory");
        blk_vec = nv;
        blk_vec_cap = cap;
    }
    b->id = (int)o->nblk;
    blk_vec[o->nblk++] = b;
    walk_number(o, JT(b));
    walk_number(o, JF(b));
}

static unsigned count_reach(opt_t *o, node_t *b)
{
    unsigned n;
    if (!b || b->mark == o->mark)
        return 0;
    b->mark = o->mark;
    n = 1;
    n += count_reach(o, JT(b));
    n += count_reach(o, JF(b));
    return n;
}

/* ------------------------------------------------------------ value pool */

static void vals_reset(opt_t *o)
{
    unsigned i;

    o->gen++;

    /* only the buckets need clearing; slots are set as values are minted */
    for (i = 0; i < o->vused; i++)
        o->hash[o->vpool[i].hash] = NULL;
    o->curval = 0;
    o->vused = 0;
}

static uint32_t vnum(opt_t *o, int code, uint32_t v0, uint32_t v1)
{
    unsigned h = (unsigned)(((uint32_t)code * 2654435761u ^ v0 * 2246822519u ^
                             v1 * 3266489917u) >> 24) & (VHASH - 1);
    vnode_t *p;

    for (p = o->hash[h]; p; p = p->next)
        if (p->code == code && p->v0 == v0 && p->v1 == v1)
            return p->val;

    if (o->vused >= o->vcap)
        return 0;
    p = &o->vpool[o->vused++];
    p->hash = h;
    p->val = ++o->curval;
    p->code = code;
    p->v0 = v0;
    p->v1 = v1;
    p->next = o->hash[h];
    o->hash[h] = p;
    /*
     * Each slot is set as its value is minted, so no pass has to wipe the
     * array: a slot is only reachable through a value number, and a value
     * number only exists once it has been through here.
     */
    if (BPF_MODE(code) == BPF_IMM &&
        (BPF_CLASS(code) == BPF_LD || BPF_CLASS(code) == BPF_LDX)) {
        o->vmap[p->val].cval = v0;
        o->vmap[p->val].fixed = 1;
    } else
        o->vmap[p->val].fixed = 0;
    return p->val;
}

static uint32_t vconst(opt_t *o, uint32_t k)
{
    unsigned i = k & 63;
    uint32_t v;

    if (o->kc_gen[i] == o->gen && o->kc_key[i] == k)
        return o->kc_val[i];
    v = vnum(o, BPF_LD | BPF_IMM, k, 0);
    o->kc_gen[i] = o->gen;
    o->kc_key[i] = k;
    o->kc_val[i] = v;
    return v;
}

/* ------------------------------------------------------- use/def analysis */

/*
 * Which slot a statement reads and which it writes. Both are a function of
 * the opcode alone, apart from the memory forms where the slot follows k, so
 * they come out of a table built once instead of a switch per statement.
 * SLOT_K marks the entries that have to add k.
 */
#define SLOT_K (-2)

static signed char slot_use_tab[256], slot_set_tab[256];
static int slot_tabs_ready;

static int slot_used_slow(unsigned code, uint32_t k)
{
    int c = BPF_CLASS(code);

    switch (c) {
    case BPF_RET:
        if ((code & 0x18) == 0x10) return A_SLOT;
        return -1;
    case BPF_LD:
    case BPF_LDX:
        if (BPF_MODE(code) == BPF_IND) return X_SLOT;
        if (BPF_MODE(code) == BPF_MEM) return MEM_SLOT(k);
        return -1;
    case BPF_ST:
        return A_SLOT;
    case BPF_STX:
        return X_SLOT;
    case BPF_JMP:
    case BPF_ALU:
        if (BPF_SRC(code) == BPF_X) return AX_SLOT;
        return A_SLOT;
    case BPF_MISC:
        return BPF_MISCOP(code) == BPF_TXA ? X_SLOT : A_SLOT;
    }
    return -1;
}

static int slot_set_slow(unsigned code, uint32_t k)
{
    switch (BPF_CLASS(code)) {
    case BPF_LD:
    case BPF_ALU:
        return A_SLOT;
    case BPF_LDX:
        return X_SLOT;
    case BPF_ST:
    case BPF_STX:
        return MEM_SLOT(k);
    case BPF_MISC:
        return BPF_MISCOP(code) == BPF_TAX ? X_SLOT : A_SLOT;
    }
    return -1;
}

static void slot_tabs_init(void)
{
    unsigned c;

    for (c = 0; c < 256; c++) {
        int u = slot_used_slow(c, 0);
        int d = slot_set_slow(c, 0);

        /* the memory forms answer with MEM_SLOT(0); k is added at lookup */
        if ((BPF_CLASS(c) == BPF_LD || BPF_CLASS(c) == BPF_LDX) &&
            BPF_MODE(c) == BPF_MEM)
            u = SLOT_K;
        if (BPF_CLASS(c) == BPF_ST || BPF_CLASS(c) == BPF_STX)
            d = SLOT_K;
        slot_use_tab[c] = (signed char)u;
        slot_set_tab[c] = (signed char)d;
    }
    slot_tabs_ready = 1;
}

static inline int slot_used(ins_t *s)
{
    int v;

    if (s->code == NOP_CODE)
        return -1;
    v = slot_use_tab[s->code & 0xff];
    if (v == SLOT_K)
        return MEM_SLOT(s->k);
    return v;
}

static inline int slot_set(ins_t *s)
{
    int v;

    if (s->code == NOP_CODE)
        return -1;
    v = slot_set_tab[s->code & 0xff];
    if (v == SLOT_K)
        return MEM_SLOT(s->k);
    return v;
}


static void local_ud(node_t *b)
{
    op_t *s;
    uint32_t def = 0, use = 0, kill = 0;
    int a;

    for (s = b->stmts; s; s = s->next) {
        if (s->s.code == NOP_CODE)
            continue;
        a = slot_used(&s->s);
        if (a >= 0) {
            if (a == AX_SLOT) {
                if (!HAS_SLOT(def, X_SLOT)) use |= SLOTBIT(X_SLOT);
                if (!HAS_SLOT(def, A_SLOT)) use |= SLOTBIT(A_SLOT);
            } else if (a < N_ATOMS) {
                if (!HAS_SLOT(def, a)) use |= SLOTBIT(a);
            }
        }
        a = slot_set(&s->s);
        if (a >= 0) {
            if (!HAS_SLOT(use, a)) kill |= SLOTBIT(a);
            def |= SLOTBIT(a);
        }
    }
    a = slot_used(&b->s);
    if (a >= 0) {
        if (a == AX_SLOT) {
            if (!HAS_SLOT(def, X_SLOT)) use |= SLOTBIT(X_SLOT);
            if (!HAS_SLOT(def, A_SLOT)) use |= SLOTBIT(A_SLOT);
        } else if (a < N_ATOMS) {
            if (!HAS_SLOT(def, a)) use |= SLOTBIT(a);
        }
    }
    b->def = def;
    b->kill = kill;
    b->in_use = use;
    b->base_use = use;
}

/* --------------------------------------------------------- graph walking */

static void level_walk(opt_t *o, node_t *b)
{
    int lv;

    if (b->mark == o->mark)
        return;
    b->mark = o->mark;
    b->link = NULL;

    if (JT(b)) {
        level_walk(o, JT(b));
        level_walk(o, JF(b));
        lv = JT(b)->level;
        if (JF(b)->level > lv) lv = JF(b)->level;
        lv++;
    } else
        lv = 0;
    b->level = lv;
    b->link = o->levels[lv];
    o->levels[lv] = b;
}

static void find_levels(opt_t *o)
{
    unsigned i;
    for (i = 0; i < o->nlevels; i++)
        o->levels[i] = NULL;
    o->mark++;
    level_walk(o, o->cs->root);
}

/*
 * Dominator sets, for blocks and for edges, in one walk: both propagate along
 * the same level order, so they share the traversal.  Both out-edges of a
 * block are dominated by the same set plus themselves, which is why one edge
 * set per block is enough.
 */
/*
 * Dominators, local use/def and the in-edge lists all sweep the blocks in
 * level order, so they share one walk; only the use/def fixpoint below needs
 * a second sweep in the other direction.
 */
static void prepare_pass(opt_t *o, int fresh, int want_dom)
{
    unsigned i, w, tw, fw;
    uint32_t tb, fb;
    int lv, top = o->cs->root->level;
    node_t *b;

    if (want_dom) {
        memset(o->domspace, 0xff,
               (size_t)o->nblk * o->words * sizeof(uint32_t));
        memset(o->edomspace, 0xff,
               (size_t)o->nblk * o->awords * sizeof(uint32_t));
        for (w = 0; w < o->words; w++)
            o->cs->root->dom[w] = 0;
        for (w = 0; w < o->awords; w++)
            o->cs->root->edom_in[w] = 0;
    }
    for (i = 0; i < o->nblk; i++)
        o->blocks[i]->in_edges = NULL;

    for (lv = top; lv >= 0; lv--) {
        for (b = o->levels[lv]; b; b = b->link) {
            if (fresh)
                local_ud(b);
            else
                b->in_use = b->base_use;
            b->out_use = 0;
            if (want_dom)
                b->dom[b->id / 32] |= 1u << (b->id % 32);
            if (!JT(b))
                continue;
            if (want_dom) {
                for (w = 0; w < o->words; w++) {
                    JT(b)->dom[w] &= b->dom[w];
                    JF(b)->dom[w] &= b->dom[w];
                }
                tw = (unsigned)b->et.id / 32;
                tb = 1u << (b->et.id % 32);
                fw = (unsigned)b->ef.id / 32;
                fb = 1u << (b->ef.id % 32);
                for (w = 0; w < o->awords; w++) {
                    uint32_t x = b->edom_in[w];
                    JT(b)->edom_in[w] &= x | (w == tw ? tb : 0);
                    JF(b)->edom_in[w] &= x | (w == fw ? fb : 0);
                }
            }
            b->et.next = JT(b)->in_edges;
            JT(b)->in_edges = &b->et;
            b->ef.next = JF(b)->in_edges;
            JF(b)->in_edges = &b->ef;
        }
    }

    for (lv = 1; lv <= top; lv++)
        for (b = o->levels[lv]; b; b = b->link) {
            b->out_use |= JT(b)->in_use | JF(b)->in_use;
            b->in_use |= b->out_use & ~b->kill;
        }
    o->inedge_gen = o->gchange;
}

static void find_inedges(opt_t *o)
{
    unsigned i;
    int lv;
    node_t *b;

    for (i = 0; i < o->nblk; i++)
        o->blocks[i]->in_edges = NULL;

    for (lv = o->cs->root->level; lv > 0; lv--)
        for (b = o->levels[lv]; b; b = b->link) {
            b->et.next = JT(b)->in_edges;
            JT(b)->in_edges = &b->et;
            b->ef.next = JF(b)->in_edges;
            JF(b)->in_edges = &b->ef;
        }
}

/* ------------------------------------------------------ statement tuning */

static void store_val(ins_t *s, uint32_t *slot, uint32_t nv, int rewrite)
{
    if (rewrite && *slot == nv)
        s->code = NOP_CODE;
    else
        *slot = nv;
}

static void fold_binop(opt_t *o, ins_t *s, uint32_t v0, uint32_t v1)
{
    uint32_t a = o->vmap[v0].cval;
    uint32_t b = o->vmap[v1].cval;

    switch (BPF_OP(s->code)) {
    case BPF_ADD: a += b; break;
    case BPF_SUB: a -= b; break;
    case BPF_MUL: a *= b; break;
    case BPF_DIV:
        if (b == 0)
            fail(o->cs, "division by zero");
        a /= b;
        break;
    case BPF_MOD:
        if (b == 0)
            fail(o->cs, "modulus by zero");
        a %= b;
        break;
    case BPF_AND: a &= b; break;
    case BPF_OR:  a |= b; break;
    case BPF_XOR: a ^= b; break;
    case BPF_LSH: a = (b > 31) ? 0 : (a << b); break;
    case BPF_RSH: a = (b > 31) ? 0 : (a >> b); break;
    default: return;
    }
    s->k = a;
    s->code = BPF_LD | BPF_IMM;
    o->stable = 0;
}

static void tune_stmt(opt_t *o, ins_t *s, uint32_t *val, int rewrite)
{
    uint32_t v;
    int op;

    switch (s->code) {

    case BPF_LD | BPF_ABS | BPF_W:
    case BPF_LD | BPF_ABS | BPF_H:
    case BPF_LD | BPF_ABS | BPF_B:
        v = vnum(o, s->code, s->k, 0);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LD | BPF_IND | BPF_W:
    case BPF_LD | BPF_IND | BPF_H:
    case BPF_LD | BPF_IND | BPF_B:
        v = val[X_SLOT];
        if (rewrite && o->vmap[v].fixed) {
            s->code = (uint16_t)(BPF_LD | BPF_ABS | (s->code & 0x18));
            s->k += o->vmap[v].cval;
            v = vnum(o, s->code, s->k, 0);
            o->stable = 0;
        } else
            v = vnum(o, s->code, s->k, v);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LD | BPF_LEN:
        v = vnum(o, s->code, 0, 0);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LD | BPF_IMM:
        v = vconst(o, s->k);
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_LDX | BPF_IMM:
        v = vconst(o, s->k);
        store_val(s, &val[X_SLOT], v, rewrite);
        break;

    case BPF_LDX | BPF_MSH | BPF_B:
        v = vnum(o, s->code, s->k, 0);
        store_val(s, &val[X_SLOT], v, rewrite);
        break;

    case BPF_ALU | BPF_NEG:
        if (rewrite && o->vmap[val[A_SLOT]].fixed) {
            s->code = BPF_LD | BPF_IMM;
            s->k = 0u - o->vmap[val[A_SLOT]].cval;
            val[A_SLOT] = vconst(o, s->k);
            o->stable = 0;
        } else
            val[A_SLOT] = vnum(o, s->code, val[A_SLOT], 0);
        break;

    case BPF_ALU | BPF_ADD | BPF_K:
    case BPF_ALU | BPF_SUB | BPF_K:
    case BPF_ALU | BPF_MUL | BPF_K:
    case BPF_ALU | BPF_DIV | BPF_K:
    case BPF_ALU | BPF_MOD | BPF_K:
    case BPF_ALU | BPF_AND | BPF_K:
    case BPF_ALU | BPF_OR | BPF_K:
    case BPF_ALU | BPF_XOR | BPF_K:
    case BPF_ALU | BPF_LSH | BPF_K:
    case BPF_ALU | BPF_RSH | BPF_K:
        op = BPF_OP(s->code);
        if (rewrite) {
            if (s->k == 0) {
                if (op == BPF_ADD || op == BPF_SUB || op == BPF_OR ||
                    op == BPF_XOR || op == BPF_LSH || op == BPF_RSH) {
                    s->code = NOP_CODE;
                    o->stable = 0;
                    break;
                }
                if (op == BPF_MUL || op == BPF_AND) {
                    s->code = BPF_LD | BPF_IMM;
                    val[A_SLOT] = vconst(o, s->k);
                    o->stable = 0;
                    break;
                }
            }
            if (o->vmap[val[A_SLOT]].fixed) {
                fold_binop(o, s, val[A_SLOT], vconst(o, s->k));
                val[A_SLOT] = vconst(o, s->k);
                break;
            }
        }
        val[A_SLOT] = vnum(o, s->code, val[A_SLOT], vconst(o, s->k));
        break;

    case BPF_ALU | BPF_ADD | BPF_X:
    case BPF_ALU | BPF_SUB | BPF_X:
    case BPF_ALU | BPF_MUL | BPF_X:
    case BPF_ALU | BPF_DIV | BPF_X:
    case BPF_ALU | BPF_MOD | BPF_X:
    case BPF_ALU | BPF_AND | BPF_X:
    case BPF_ALU | BPF_OR | BPF_X:
    case BPF_ALU | BPF_XOR | BPF_X:
    case BPF_ALU | BPF_LSH | BPF_X:
    case BPF_ALU | BPF_RSH | BPF_X:
        op = BPF_OP(s->code);
        if (rewrite && o->vmap[val[X_SLOT]].fixed) {
            if (o->vmap[val[A_SLOT]].fixed) {
                fold_binop(o, s, val[A_SLOT], val[X_SLOT]);
                val[A_SLOT] = vconst(o, s->k);
            } else {
                s->code = (uint16_t)(BPF_ALU | BPF_K | op);
                s->k = o->vmap[val[X_SLOT]].cval;
                o->stable = 0;
                val[A_SLOT] = vnum(o, s->code, val[A_SLOT], vconst(o, s->k));
            }
            break;
        }
        if (rewrite && o->vmap[val[A_SLOT]].fixed &&
            o->vmap[val[A_SLOT]].cval == 0) {
            if (op == BPF_ADD || op == BPF_OR || op == BPF_XOR) {
                s->code = BPF_MISC | BPF_TXA;
                store_val(s, &val[A_SLOT], val[X_SLOT], rewrite);
                o->stable = 0;
                break;
            }
            if (op == BPF_MUL || op == BPF_DIV || op == BPF_MOD ||
                op == BPF_AND || op == BPF_LSH || op == BPF_RSH) {
                s->code = BPF_LD | BPF_IMM;
                s->k = 0;
                store_val(s, &val[A_SLOT], vconst(o, 0), rewrite);
                o->stable = 0;
                break;
            }
        }
        val[A_SLOT] = vnum(o, s->code, val[A_SLOT], val[X_SLOT]);
        break;

    case BPF_MISC | BPF_TXA:
        store_val(s, &val[A_SLOT], val[X_SLOT], rewrite);
        break;

    case BPF_LD | BPF_MEM:
        v = val[MEM_SLOT(s->k)];
        if (rewrite && o->vmap[v].fixed) {
            s->code = BPF_LD | BPF_IMM;
            s->k = o->vmap[v].cval;
            o->stable = 0;
        }
        store_val(s, &val[A_SLOT], v, rewrite);
        break;

    case BPF_MISC | BPF_TAX:
        store_val(s, &val[X_SLOT], val[A_SLOT], rewrite);
        break;

    case BPF_LDX | BPF_MEM:
        v = val[MEM_SLOT(s->k)];
        if (rewrite && o->vmap[v].fixed) {
            s->code = BPF_LDX | BPF_IMM;
            s->k = o->vmap[v].cval;
            o->stable = 0;
        }
        store_val(s, &val[X_SLOT], v, rewrite);
        break;

    case BPF_ST:
        store_val(s, &val[MEM_SLOT(s->k)], val[A_SLOT], rewrite);
        break;

    case BPF_STX:
        store_val(s, &val[MEM_SLOT(s->k)], val[X_SLOT], rewrite);
        break;

    default:
        break;
    }
}

static op_t *real_op(op_t *s)
{
    while (s && s->s.code == NOP_CODE)
        s = s->next;
    return s;
}

static void peep(opt_t *o, node_t *b)
{
    op_t *s = b->stmts, *next, *last;

    if (!s)
        return;
    last = s;
    for (;; s = s->next) {
        s = real_op(s);
        if (!s)
            break;
        next = real_op(s->next);
        if (!next)
            break;
        last = next;

        if (s->s.code == BPF_ST && next->s.code == (BPF_LDX | BPF_MEM) &&
            s->s.k == next->s.k) {
            o->stable = 0;
            next->s.code = BPF_MISC | BPF_TAX;
        }
        if (s->s.code == (BPF_LD | BPF_IMM) &&
            next->s.code == (BPF_MISC | BPF_TAX)) {
            s->s.code = BPF_LDX | BPF_IMM;
            next->s.code = BPF_MISC | BPF_TXA;
            o->stable = 0;
        }
        if (s->s.code == (BPF_LD | BPF_IMM)) {
            op_t *add, *tax, *ild;

            if (HAS_SLOT(b->out_use, X_SLOT))
                continue;
            if (next->s.code != (BPF_LDX | BPF_MSH | BPF_B))
                add = next;
            else
                add = real_op(next->next);
            if (!add || add->s.code != (BPF_ALU | BPF_ADD | BPF_X))
                continue;
            tax = real_op(add->next);
            if (!tax || tax->s.code != (BPF_MISC | BPF_TAX))
                continue;
            ild = real_op(tax->next);
            if (!ild || BPF_CLASS(ild->s.code) != BPF_LD ||
                BPF_MODE(ild->s.code) != BPF_IND)
                continue;
            ild->s.k += s->s.k;
            s->s.code = NOP_CODE;
            add->s.code = NOP_CODE;
            tax->s.code = NOP_CODE;
            o->stable = 0;
        }
    }

    /* a - x == 0 is the same test as a == x */
    if (b->s.code == (BPF_JMP | BPF_JEQ | BPF_K) && b->s.k == 0 &&
        last->s.code == (BPF_ALU | BPF_SUB | BPF_X) &&
        !HAS_SLOT(b->out_use, A_SLOT)) {
        b->s.code = BPF_JMP | BPF_JEQ | BPF_X;
        last->s.code = NOP_CODE;
        o->stable = 0;
        return;
    }

    /* a - k == 0 is the same test as a == k */
    if (b->s.code == (BPF_JMP | BPF_JEQ | BPF_K) && b->s.k == 0 &&
        last->s.code == (BPF_ALU | BPF_SUB | BPF_K) &&
        !HAS_SLOT(b->out_use, A_SLOT)) {
        b->s.k = last->s.k;
        last->s.code = NOP_CODE;
        o->stable = 0;
        return;
    }

    if (b->s.code == (BPF_JMP | BPF_JEQ | BPF_K) && b->s.k == 0 &&
        last->s.code == (BPF_ALU | BPF_AND | BPF_K) &&
        !HAS_SLOT(b->out_use, A_SLOT)) {
        node_t *tmp;
        b->s.code = BPF_JMP | BPF_JSET | BPF_K;
        b->s.k = last->s.k;
        last->s.code = NOP_CODE;
        tmp = JT(b);
        JT(b) = JF(b);
        JF(b) = tmp;
        o->gchange++;
        o->stable = 0;
    }
}

static void kill_dead_stores(opt_t *o, node_t *b)
{
    op_t *s;
    ins_t *last[N_ATOMS];
    uint32_t live = 0;      /* which entries of last[] are meaningful */
    int a, i;

    if (!b->stmts)
        return;             /* nothing here can be a dead store */

    for (s = b->stmts; s; s = s->next) {
        a = slot_used(&s->s);
        if (a == AX_SLOT)
            live &= ~((1u << X_SLOT) | (1u << A_SLOT));
        else if (a >= 0 && a < N_ATOMS)
            live &= ~(1u << a);
        a = slot_set(&s->s);
        if (a >= 0 && a < N_ATOMS) {
            if (live & (1u << a)) {
                o->stable = 0;
                last[a]->code = NOP_CODE;
            }
            last[a] = &s->s;
            live |= 1u << a;
        }
    }
    a = slot_used(&b->s);
    if (a == AX_SLOT)
        live &= ~((1u << X_SLOT) | (1u << A_SLOT));
    else if (a >= 0 && a < N_ATOMS)
        live &= ~(1u << a);

    while (live) {
        i = __builtin_ctz(live);
        live &= live - 1;
        if (!HAS_SLOT(b->out_use, i)) {
            last[i]->code = NOP_CODE;
            o->stable = 0;
        }
    }
}

static void tune_block(opt_t *o, node_t *b, int rewrite)
{
    arc_t *p;
    op_t *s;
    int i;

    p = b->in_edges;
    if (!p)
        memset(b->val, 0, o->nval * sizeof(uint32_t));
    else if (o->nval == 2) {
        /* no scratch registers in play, which is the common filter */
        uint32_t a = p->pred->val[A_SLOT], x = p->pred->val[X_SLOT];

        while ((p = p->next) != NULL) {
            if (a != p->pred->val[A_SLOT]) a = 0;
            if (x != p->pred->val[X_SLOT]) x = 0;
        }
        b->val[A_SLOT] = a;
        b->val[X_SLOT] = x;
    } else {
        memcpy(b->val, p->pred->val, o->nval * sizeof(uint32_t));
        while ((p = p->next) != NULL)
            for (i = 0; i < (int)o->nval; i++)
                if (b->val[i] != p->pred->val[i])
                    b->val[i] = 0;
    }
    for (s = b->stmts; s; s = s->next)
        tune_stmt(o, &s->s, b->val, rewrite);

    /* a branch against a register holding a known value becomes a branch
     * against that value */
    if (rewrite && BPF_CLASS(b->s.code) == BPF_JMP &&
        BPF_SRC(b->s.code) == BPF_X && o->vmap[b->val[X_SLOT]].fixed) {
        b->s.code = (uint16_t)(b->s.code & ~BPF_X);
        b->s.k = o->vmap[b->val[X_SLOT]].cval;
        o->stable = 0;
    }

    if (rewrite && BPF_CLASS(b->s.code) == BPF_RET) {
        if (b->stmts) {
            b->stmts = NULL;
            o->stable = 0;
        }
    } else if (rewrite) {
        peep(o, b);
        kill_dead_stores(o, b);
    }

    if (BPF_CLASS(b->s.code) == BPF_JMP &&
        BPF_SRC(b->s.code) == BPF_K && o->vmap[b->val[A_SLOT]].fixed) {
        uint32_t a = o->vmap[b->val[A_SLOT]].cval;
        uint32_t k = b->s.k;
        int taken = -1;
        switch (BPF_OP(b->s.code)) {
        case BPF_JEQ:  taken = (a == k); break;
        case BPF_JGT:  taken = (a > k); break;
        case BPF_JGE:  taken = (a >= k); break;
        case BPF_JSET: taken = ((a & k) != 0); break;
        default: break;
        }
        if (taken >= 0) {
            node_t *t = taken ? JT(b) : JF(b);
            if (JT(b) != t || JF(b) != t) {
                JT(b) = t;
                JF(b) = t;
                o->gchange++;
                o->stable = 0;
            }
        }
    }

    /* only branch blocks take part in the edge folding below */
    if (JT(b)) {
        if (BPF_SRC(b->s.code) == BPF_K)
            b->oval = vconst(o, b->s.k);
        else
            b->oval = b->val[X_SLOT];
        b->et.code = (int)b->s.code;
        b->ef.code = -(int)b->s.code;
    }
}

/* ------------------------------------------------------- branch shifting */

static int use_conflict(node_t *b, node_t *succ)
{
    int i;
    uint32_t use = succ->out_use;

    if (use == 0)
        return 0;
    for (i = 0; i < N_ATOMS; i++)
        if (HAS_SLOT(use, i) && b->val[i] != succ->val[i])
            return 1;
    return 0;
}


static void shift_arc(opt_t *o, arc_t *ep)
{
    unsigned i, selfw;
    uint32_t x, selfb;
    int k, ccode;
    uint32_t cval, coval;
    node_t *child, *target;
    arc_t *e;

    if (!JT(ep->succ))
        return;
    if (JT(ep->succ) == JF(ep->succ)) {
        if (!use_conflict(ep->succ, JT(ep->succ))) {
            o->stable = 0;
            o->gchange++;
            ep->succ = JT(ep->succ);
        }
    }
again:
    child = ep->succ;
    ccode = (int)child->s.code;
    cval = child->val[A_SLOT];
    coval = child->oval;
    selfw = (unsigned)ep->id / 32;
    selfb = 1u << (ep->id % 32);
    for (i = 0; i < o->awords; i++) {
        x = ep->pred->edom_in[i];
        if (i == selfw)
            x |= selfb;
        while (x != 0) {
            k = __builtin_ctz(x);
            x &= x - 1;
            if ((unsigned)(k + (int)i * 32) >= o->narc)
                continue;
            e = o->arcs[k + i * 32];
            if (e->code != ccode && e->code != -ccode)
                continue;
            if (e->pred->val[A_SLOT] != cval)
                continue;
            if (e->pred->oval == coval)
                target = (e->code > 0) ? JT(child) : JF(child);
            else if (e->code == ccode && ccode == (BPF_JMP | BPF_JEQ | BPF_K))
                target = JF(child);
            else
                continue;
            if (target && !use_conflict(child, target)) {
                o->stable = 0;
                o->gchange++;
                ep->succ = target;
                if (JT(target))
                    goto again;
                return;
            }
        }
    }
}

/*
 * Hoisting.  When several alternatives in an or-chain (or an and-chain)
 * test the same loaded value, the one further down can be lifted so that
 * the tests on that value sit next to each other.
 */
static int dominates(node_t *b, node_t *who)
{
    return (b->dom[who->id / 32] >> (who->id % 32)) & 1;
}

static void hoist(opt_t *o, node_t *b, int on_true)
{
    uint32_t val;
    int at_top;
    node_t *pull;
    node_t **diffp, **samep;
    arc_t *ep;

    ep = b->in_edges;
    if (!ep)
        return;
    val = ep->pred->val[A_SLOT];
    for (ep = ep->next; ep; ep = ep->next)
        if (val != ep->pred->val[A_SLOT])
            return;

    if (JT(b->in_edges->pred) == b)
        diffp = &JT(b->in_edges->pred);
    else
        diffp = &JF(b->in_edges->pred);

    at_top = 1;
    for (;;) {
        if (!*diffp)
            return;
        if (on_true) {
            if (JF(*diffp) != JF(b)) return;
        } else {
            if (JT(*diffp) != JT(b)) return;
        }
        if (!dominates(*diffp, b))
            return;
        if ((*diffp)->val[A_SLOT] != val)
            break;
        diffp = on_true ? &JT(*diffp) : &JF(*diffp);
        at_top = 0;
    }

    samep = on_true ? &JT(*diffp) : &JF(*diffp);
    for (;;) {
        if (!*samep)
            return;
        if (on_true) {
            if (JF(*samep) != JF(b)) return;
        } else {
            if (JT(*samep) != JT(b)) return;
        }
        if (!dominates(*samep, b))
            return;
        if ((*samep)->val[A_SLOT] == val)
            break;
        samep = on_true ? &JT(*samep) : &JF(*samep);
    }

    pull = *samep;
    if (on_true) {
        *samep = JT(pull);
        JT(pull) = *diffp;
    } else {
        *samep = JF(pull);
        JF(pull) = *diffp;
    }

    if (at_top) {
        for (ep = b->in_edges; ep; ep = ep->next) {
            if (JT(ep->pred) == b)
                JT(ep->pred) = pull;
            else
                JF(ep->pred) = pull;
        }
    } else
        *diffp = pull;

    o->gchange++;
    o->stable = 0;
}

/* ------------------------------------------------------------- merging */

static int same_ins(ins_t *a, ins_t *b)
{
    return a->code == b->code && a->k == b->k;
}

static int same_ops(op_t *x, op_t *y)
{
    for (;;) {
        while (x && x->s.code == NOP_CODE) x = x->next;
        while (y && y->s.code == NOP_CODE) y = y->next;
        if (!x || !y)
            return x == y;
        if (!same_ins(&x->s, &y->s))
            return 0;
        x = x->next;
        y = y->next;
    }
}

static int same_block(node_t *a, node_t *b)
{
    return a->s.code == b->s.code && a->s.k == b->s.k &&
           JT(a) == JT(b) && JF(a) == JF(b) && same_ops(a->stmts, b->stmts);
}

/* route around blocks whose two exits ended up identical */
static void bypass_dead(opt_t *o)
{
    unsigned i;
    int changed;

    do {
        changed = 0;
        for (i = 0; i < o->nblk; i++) {
            node_t *b = o->blocks[i];
            if (!JT(b))
                continue;
            while (JT(JT(b)) && JT(JT(b)) == JF(JT(b)) &&
                   !use_conflict(JT(b), JT(JT(b)))) {
                JT(b) = JT(JT(b));
                changed = 1;
            }
            while (JT(JF(b)) && JT(JF(b)) == JF(JF(b)) &&
                   !use_conflict(JF(b), JT(JF(b)))) {
                JF(b) = JT(JF(b));
                changed = 1;
            }
        }
    } while (changed);
}

/*
 * Fold blocks that ended up identical.  Candidates are bucketed by a key over
 * the branch and the two successors, so only plausible pairs are compared in
 * full; within a bucket the ids stay in ascending order, which keeps the same
 * survivor the pairwise scan would have picked.
 */
#define MERGE_BUCKETS 256

static void merge_blocks(opt_t *o)
{
    unsigned i;
    node_t *p;
    int again;
    int *chain = (int *)arena_alloc_raw(o->cs, (size_t)o->nblk * sizeof(int));
    int *head = (int *)arena_alloc_raw(o->cs, MERGE_BUCKETS * sizeof(int));
    uint32_t *key = (uint32_t *)arena_alloc_raw(o->cs,
                                                (size_t)o->nblk * sizeof(uint32_t));

    do {
        again = 0;
        for (i = 0; i < o->nblk; i++)
            o->blocks[i]->link = NULL;

        o->mark++;
        count_reach(o, o->cs->root);

        for (i = 0; i < MERGE_BUCKETS; i++)
            head[i] = -1;
        for (i = o->nblk; i-- > 0; ) {
            node_t *b = o->blocks[i];
            uint32_t h;
            int j;
            if (b->mark != o->mark) {
                chain[i] = -1;
                continue;
            }
            /*
             * Successor identity by block number, not address: the addresses
             * move with ASLR, which would make the bucket order - and so the
             * instrumented run's counters, and the profile-guided build -
             * differ between otherwise identical builds.
             */
            h = (uint32_t)b->s.code * 2654435761u ^ b->s.k * 2246822519u ^
                (uint32_t)(JT(b) ? JT(b)->id + 1 : 0) * 40503u ^
                ((uint32_t)(JF(b) ? JF(b)->id + 1 : 0) << 3);
            h = (h >> 13) ^ h;
            key[i] = h;
            chain[i] = head[h & (MERGE_BUCKETS - 1)];
            head[h & (MERGE_BUCKETS - 1)] = (int)i;
            /*
             * The chain already holds every higher-numbered block in this
             * bucket, and each of those has had its survivor decided, so the
             * comparison can happen here rather than in a second sweep.
             */
            for (j = chain[i]; j >= 0; j = chain[j]) {
                if (key[j] != key[i])
                    continue;
                if (same_block(b, o->blocks[j])) {
                    b->link = o->blocks[j]->link ?
                        o->blocks[j]->link : o->blocks[j];
                    break;
                }
            }
        }
        for (i = 0; i < o->nblk; i++) {
            p = o->blocks[i];
            if (!JT(p))
                continue;
            if (JT(p)->link) { again = 1; JT(p) = JT(p)->link; }
            if (JF(p)->link) { again = 1; JF(p) = JF(p)->link; }
        }
    } while (again);
}

static void tidy_root(node_t **rp)
{
    op_t *tmp, *s;

    s = (*rp)->stmts;
    (*rp)->stmts = NULL;
    while (BPF_CLASS((*rp)->s.code) == BPF_JMP && JT(*rp) == JF(*rp))
        *rp = JT(*rp);

    tmp = (*rp)->stmts;
    if (tmp)
        op_cat(s, tmp);
    (*rp)->stmts = s;

    if (BPF_CLASS((*rp)->s.code) == BPF_RET)
        (*rp)->stmts = NULL;
}

/* ------------------------------------------------------------- main loop */

static void tune_all(opt_t *o, int rewrite)
{
    int lv, top = o->cs->root->level;
    node_t *b;

    vals_reset(o);
    if (o->gchange != o->inedge_gen) {
        find_inedges(o);
        o->inedge_gen = o->gchange;
    }
    for (lv = top; lv >= 0; lv--)
        for (b = o->levels[lv]; b; b = b->link)
            tune_block(o, b, rewrite);

    if (rewrite)
        return;

    for (lv = 1; lv <= top; lv++)
        for (b = o->levels[lv]; b; b = b->link) {
            /* an edge into a leaf has nothing to fold */
            if (JT(b->et.succ))
                shift_arc(o, &b->et);
            if (JT(b->ef.succ))
                shift_arc(o, &b->ef);
        }

    if (o->gchange != o->inedge_gen) {
        find_inedges(o);
        o->inedge_gen = o->gchange;
    }
    for (lv = 1; lv <= top; lv++)
        for (b = o->levels[lv]; b; b = b->link) {
            hoist(o, b, 0);
            hoist(o, b, 1);
        }
}

/*
 * `current` says the level chains and use/def sets already describe the graph
 * as it stands, which is true on entry to the second pass: the first pass only
 * stops once a whole round has changed nothing.
 */
static void run_loop(opt_t *o, int rewrite, int current)
{
    int guard = 0;

    do {
        o->stable = 1;
        if (!(current && guard == 0)) {
            if (o->gchange != o->levels_gen || guard == 0) {
                find_levels(o);
                o->levels_gen = o->gchange;
            }
            prepare_pass(o, rewrite || guard == 0, !rewrite);
        }
        tune_all(o, rewrite);
        if (++guard > 100)
            break;
    } while (!o->stable);
}

/*
 * The value table is shared between compiles and left empty by vals_reset()
 * at the end of a successful one. A compile that gives up part way through
 * (an error raised from inside the refinement, say a fold that divides by
 * zero) leaves buckets pointing into an arena the next compile will reuse,
 * so the error path calls refine_forget() to drop them.
 */
static vnode_t *hashtab[VHASH];

void refine_forget(void)
{
    memset(hashtab, 0, sizeof(hashtab));
}

void refine_graph(ctx_t *cs)
{
    opt_t o;
    unsigned i, n;
    static int markbase = 1;

    if (!slot_tabs_ready)
        slot_tabs_init();
    memset(&o, 0, sizeof(o));
    o.hash = hashtab;
    o.cs = cs;
    o.inedge_gen = ~0u;      /* force the first in-edge build */
    o.levels_gen = ~0u;
    markbase += 4;
    o.mark = markbase;
    o.nblk = 0;
    walk_number(&o, cs->root);
    n = o.nblk;
    if (n == 0)
        return;
    /*
     * The dominator sets are quadratic in the graph size.  A filter big
     * enough to matter here is far beyond anything worth refining, and
     * running out of memory would cost the whole run, so leave it alone.
     */
    if (n > REFINE_MAX_BLOCKS)
        return;

    o.blocks = blk_vec;
    o.arcs = (arc_t **)arena_alloc_raw(cs, 2 * n * sizeof(arc_t *));
    o.levels = (node_t **)arena_alloc(cs, (n + 2) * sizeof(node_t *));
    o.nlevels = n + 2;
    o.narc = 2 * o.nblk;
    o.words = (o.nblk + 31) / 32;
    o.awords = (o.narc + 31) / 32;
    o.domspace = (uint32_t *)arena_alloc_raw(cs, o.nblk * o.words * sizeof(uint32_t));
    o.edomspace = (uint32_t *)arena_alloc_raw(cs, (size_t)o.nblk * o.awords * sizeof(uint32_t));
    o.nval = 2;
    if (cs->maxreg >= 0 && (unsigned)cs->maxreg + 3 > o.nval)
        o.nval = (unsigned)cs->maxreg + 3;
    if (o.nval > N_ATOMS)
        o.nval = N_ATOMS;
    o.vcap = 8 * o.nblk + 64;
    o.vpool = (vnode_t *)arena_alloc_raw(cs, o.vcap * sizeof(vnode_t));
    o.vmap = arena_alloc_raw(cs, (o.vcap + 2) * sizeof(*o.vmap));
    o.vmap[0].fixed = 0;      /* value 0 means "not known" */
    o.vmap[0].cval = 0;

    for (i = 0; i < o.nblk; i++) {
        node_t *b = o.blocks[i];
        b->dom = &o.domspace[i * o.words];
        b->et.id = (int)i;
        b->ef.id = (int)(o.nblk + i);
        b->edom_in = &o.edomspace[(size_t)i * o.awords];
        b->et.pred = b;
        b->ef.pred = b;
        o.arcs[b->et.id] = &b->et;
        o.arcs[b->ef.id] = &b->ef;
    }

    run_loop(&o, 0, 0);
    run_loop(&o, 1, 1);
    vals_reset(&o);          /* leave the shared bucket array empty */
    bypass_dead(&o);
    merge_blocks(&o);
    tidy_root(&cs->root);
}
