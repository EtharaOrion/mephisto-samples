/*
 * jsonio.c - JSONL reader and writer. Complete and correct; leave it alone.
 *
 * The reader is a real (if small) JSON object scanner rather than a substring
 * search: it walks the object key by key and skips values structurally, so a
 * filter expression containing braces, brackets, colons, commas or escaped
 * quotes cannot be mistaken for record structure.
 */
#include <stdlib.h>
#include <string.h>

#include "jsonio.h"

/* ------------------------------------------------------------------ */
/* scanner                                                            */
/* ------------------------------------------------------------------ */

typedef struct {
    const char *p;
} jscan_t;

static void js_ws(jscan_t *s)
{
    while (*s->p == ' ' || *s->p == '\t' || *s->p == '\n' ||
           *s->p == '\r' || *s->p == '\f' || *s->p == '\v')
        s->p++;
}

/* Append one Unicode scalar to buf as UTF-8. */
static void utf8_put(char *buf, size_t *o, unsigned long cp)
{
    if (cp < 0x80) {
        buf[(*o)++] = (char)cp;
    } else if (cp < 0x800) {
        buf[(*o)++] = (char)(0xc0 | (cp >> 6));
        buf[(*o)++] = (char)(0x80 | (cp & 0x3f));
    } else if (cp < 0x10000) {
        buf[(*o)++] = (char)(0xe0 | (cp >> 12));
        buf[(*o)++] = (char)(0x80 | ((cp >> 6) & 0x3f));
        buf[(*o)++] = (char)(0x80 | (cp & 0x3f));
    } else {
        buf[(*o)++] = (char)(0xf0 | (cp >> 18));
        buf[(*o)++] = (char)(0x80 | ((cp >> 12) & 0x3f));
        buf[(*o)++] = (char)(0x80 | ((cp >> 6) & 0x3f));
        buf[(*o)++] = (char)(0x80 | (cp & 0x3f));
    }
}

static int hex4(const char *p, unsigned long *out)
{
    unsigned long v = 0;
    int i;
    for (i = 0; i < 4; i++) {
        char c = p[i];
        v <<= 4;
        if (c >= '0' && c <= '9')      v |= (unsigned long)(c - '0');
        else if (c >= 'a' && c <= 'f') v |= (unsigned long)(c - 'a' + 10);
        else if (c >= 'A' && c <= 'F') v |= (unsigned long)(c - 'A' + 10);
        else return -1;
    }
    *out = v;
    return 0;
}

/*
 * Parse a JSON string starting at the opening quote. On success *out is a
 * freshly malloc'd, unescaped, NUL-terminated C string.
 *
 * The output can never be longer than the input, because every escape
 * sequence is at least as long as the bytes it produces (\uXXXX is 6 input
 * bytes and yields at most 3 UTF-8 bytes; a surrogate pair is 12 input bytes
 * and yields 4), so one allocation sized to the remaining input is enough.
 */
static int js_string(jscan_t *s, char **out);

/*
 * Read a string value.  When it carries no escapes the text is terminated in
 * place and referenced directly, which is the common case and costs nothing.
 */
static int js_string_ref(jscan_t *s, char **out, int *owned)
{
    char *p = (char *)s->p;
    char *start;

    if (*p != '"') return -1;
    p++;
    start = p;
    while (*p && *p != '"') {
        if (*p == '\\' && p[1]) p++;
        p++;
    }
    if (*p != '"') return -1;
    if (memchr(start, '\\', (size_t)(p - start)) == NULL) {
        *p = '\0';
        *out = start;
        *owned = 0;
        s->p = p + 1;
        return 0;
    }
    *owned = 1;
    return js_string(s, out);
}

static int js_string(jscan_t *s, char **out)
{
    const char *p = s->p;
    char *buf;
    size_t o = 0;

    if (*p != '"') return -1;
    p++;

    buf = malloc(strlen(p) + 1);
    if (!buf) return -1;

    while (*p && *p != '"') {
        if (*p != '\\') {
            buf[o++] = *p++;
            continue;
        }
        p++;
        switch (*p) {
        case '"':  buf[o++] = '"';  p++; break;
        case '\\': buf[o++] = '\\'; p++; break;
        case '/':  buf[o++] = '/';  p++; break;
        case 'b':  buf[o++] = '\b'; p++; break;
        case 'f':  buf[o++] = '\f'; p++; break;
        case 'n':  buf[o++] = '\n'; p++; break;
        case 'r':  buf[o++] = '\r'; p++; break;
        case 't':  buf[o++] = '\t'; p++; break;
        case 'u': {
            unsigned long cp;
            if (hex4(p + 1, &cp) != 0) { free(buf); return -1; }
            p += 5;
            if (cp >= 0xd800 && cp <= 0xdbff && p[0] == '\\' && p[1] == 'u') {
                unsigned long lo;
                if (hex4(p + 2, &lo) == 0 && lo >= 0xdc00 && lo <= 0xdfff) {
                    cp = 0x10000 + ((cp - 0xd800) << 10) + (lo - 0xdc00);
                    p += 6;
                }
            }
            utf8_put(buf, &o, cp);
            break;
        }
        default:
            free(buf);
            return -1;
        }
    }
    if (*p != '"') { free(buf); return -1; }

    buf[o] = '\0';
    s->p = p + 1;
    *out = buf;
    return 0;
}

/* Numbers in this schema are integral. `is_null` reports a JSON null. */
static int js_number(jscan_t *s, long long *sv, unsigned long long *uv,
                     int *is_null)
{
    const char *p = s->p;
    unsigned long long n = 0;
    int neg = 0;

    *is_null = 0;
    if (p[0] == 'n' && p[1] == 'u' && p[2] == 'l' && p[3] == 'l') {
        *is_null = 1;
        s->p = p + 4;
        return 0;
    }
    if (*p == '-') { neg = 1; p++; }
    else if (*p == '+') p++;
    if (*p < '0' || *p > '9')
        return -1;
    while (*p >= '0' && *p <= '9')
        n = n * 10 + (unsigned long long)(*p++ - '0');
    /* tolerate (and discard) a fractional or exponent tail */
    while (*p == '.' || *p == 'e' || *p == 'E' || *p == '+' || *p == '-' ||
           (*p >= '0' && *p <= '9'))
        p++;
    if (neg) {
        *sv = -(long long)n;
        *uv = (unsigned long long)*sv;
    } else {
        *uv = n;
        *sv = (long long)n;
    }
    s->p = p;
    return 0;
}

/*
 * Step over a value we do not care about.  A flat scan is enough: track the
 * container depth, treat strings as opaque, and stop where the value ends.
 */
/* 0: ordinary, 1: quote, 2: open, 3: close, 4: comma, 5: end of text */
static const unsigned char json_class[256] = {
    [0] = 5, ['"'] = 1, ['{'] = 2, ['['] = 2, ['}'] = 3, [']'] = 3, [','] = 4
};

static int js_skip_value(jscan_t *s)
{
    const char *p = s->p;
    int depth = 0;

    for (;;) {
        char ch;

        while (json_class[(unsigned char)*p] == 0)
            p++;
        ch = *p;

        if (ch == '\0')
            return -1;
        if (ch == '"') {
            p++;
            while (*p && *p != '"') {
                if (*p == '\\' && p[1]) p++;
                p++;
            }
            if (*p != '"')
                return -1;
            p++;
            if (depth == 0) break;
            continue;
        }
        if (ch == '{' || ch == '[') { depth++; p++; continue; }
        if (ch == '}' || ch == ']') {
            if (depth == 0) break;          /* the enclosing object ends here */
            if (--depth == 0) { p++; break; }
            p++;
            continue;
        }
        if (depth == 0 && ch == ',')
            break;
        p++;
    }
    s->p = p;
    return 0;
}

/*
 * Read a key without copying it.  Returns 0 for a plain key (no escapes),
 * 1 for an escaped one (which the caller treats as unknown), -1 if the text
 * is not a string at all.
 */
static int js_key(jscan_t *s, const char **kp, size_t *klen)
{
    const char *start;

    if (*s->p != '"') return -1;
    start = ++s->p;
    while (*s->p && *s->p != '"' && *s->p != '\\')
        s->p++;
    if (*s->p == '\\') {
        /* rare; walk to the end of the string the slow way */
        while (*s->p && *s->p != '"') {
            if (*s->p == '\\' && s->p[1]) s->p++;
            s->p++;
        }
        if (*s->p != '"') return -1;
        s->p++;
        return 1;
    }
    if (*s->p != '"') return -1;
    *kp = start;
    *klen = (size_t)(s->p - start);
    s->p++;
    return 0;
}

/* keys are dispatched on length and first letter, which is unambiguous for
 * the six field names the contract defines */
enum { K_OTHER = 0, K_I, K_DLT, K_SNAPLEN, K_OPTIMIZE, K_NETMASK, K_FILTER };

static int key_id(const char *key, size_t klen)
{
    switch (klen) {
    case 1:
        return key[0] == 'i' ? K_I : K_OTHER;
    case 3:
        return (key[0] == 'd' && key[1] == 'l' && key[2] == 't') ? K_DLT : K_OTHER;
    case 6:
        return memcmp(key, "filter", 6) == 0 ? K_FILTER : K_OTHER;
    case 7:
        if (key[0] == 's') return memcmp(key, "snaplen", 7) == 0 ? K_SNAPLEN : K_OTHER;
        if (key[0] == 'n') return memcmp(key, "netmask", 7) == 0 ? K_NETMASK : K_OTHER;
        return K_OTHER;
    case 8:
        return memcmp(key, "optimize", 8) == 0 ? K_OPTIMIZE : K_OTHER;
    default:
        return K_OTHER;
    }
}

int bpfc_case_parse(char *line, bpfc_case_t *c)
{
    jscan_t s;
    int have_i = 0, have_dlt = 0;

    memset(c, 0, sizeof(*c));
    c->snaplen  = 262144;
    c->optimize = 1;
    c->netmask  = NETMASK_UNKNOWN;
    c->filter   = NULL;

    s.p = line;
    js_ws(&s);
    if (*s.p != '{') return -1;
    s.p++;
    js_ws(&s);

    if (*s.p == '}') goto finish;

    for (;;) {
        const char *key = NULL;
        size_t klen = 0;
        long long sv;
        unsigned long long uv;
        int nul, kr;

        js_ws(&s);
        kr = js_key(&s, &key, &klen);
        if (kr < 0) goto fail;
        js_ws(&s);
        if (*s.p != ':') goto fail;
        s.p++;
        js_ws(&s);

        switch (kr != 0 ? K_OTHER : key_id(key, klen)) {
        case K_FILTER: {
            char *val = NULL;
            int owned = 0;
            if (*s.p != '"' || js_string_ref(&s, &val, &owned) != 0) goto fail;
            if (c->filter_owned) free(c->filter);
            c->filter = val;
            c->filter_owned = owned;
            break;
        }
        case K_I:
            if (js_number(&s, &sv, &uv, &nul) != 0) goto fail;
            if (!nul) { c->i = sv; have_i = 1; }
            break;
        case K_DLT:
            if (js_number(&s, &sv, &uv, &nul) != 0) goto fail;
            if (!nul) { c->dlt = (int)sv; have_dlt = 1; }
            break;
        case K_SNAPLEN:
            if (js_number(&s, &sv, &uv, &nul) != 0) goto fail;
            if (!nul) c->snaplen = (int)sv;
            break;
        case K_OPTIMIZE:
            if (js_number(&s, &sv, &uv, &nul) != 0) goto fail;
            if (!nul) c->optimize = (int)sv;
            break;
        case K_NETMASK:
            if (js_number(&s, &sv, &uv, &nul) != 0) goto fail;
            c->netmask = nul ? NETMASK_UNKNOWN : (uint32_t)uv;
            break;
        default:
            if (js_skip_value(&s) != 0) goto fail;
            break;
        }

        js_ws(&s);
        if (*s.p == ',') { s.p++; continue; }
        if (*s.p == '}') { s.p++; break; }
        goto fail;
    }

finish:
    if (!have_i || !have_dlt || c->filter == NULL) goto fail;
    return 0;

fail:
    if (c->filter_owned) free(c->filter);
    c->filter = NULL;
    c->filter_owned = 0;
    return -1;
}

/* ------------------------------------------------------------------ */
/* file loading                                                       */
/* ------------------------------------------------------------------ */

/* Slurp the whole file; the caller splits it into lines in place. */
static char *slurp(FILE *f, size_t *len)
{
    size_t cap = 1 << 16, n = 0;
    char *buf = (char *)malloc(cap);

    if (!buf) return NULL;
    for (;;) {
        size_t got;
        if (n + 4096 > cap) {
            char *nb;
            cap *= 2;
            nb = (char *)realloc(buf, cap);
            if (!nb) { free(buf); return NULL; }
            buf = nb;
        }
        got = fread(buf + n, 1, cap - n - 1, f);
        if (got == 0) break;
        n += got;
    }
    buf[n] = '\0';
    *len = n;
    return buf;
}

void bpfc_cases_load(const char *path, bpfc_caseset_t *out)
{
    FILE *f;
    char *text, *p;
    size_t len;

    out->v = NULL;
    out->n = 0;
    out->cap = 0;

    f = fopen(path, "r");
    if (!f) {
        fprintf(stderr, "bpfc: cannot open %s\n", path);
        exit(2);
    }
    text = slurp(f, &len);
    fclose(f);
    if (!text) { fprintf(stderr, "bpfc: out of memory\n"); exit(2); }

    p = text;
    while (*p) {
        bpfc_case_t c;
        char *nl = strchr(p, '\n');
        if (nl) *nl = '\0';
        if (*p != '\0' && bpfc_case_parse(p, &c) == 0) {
            if (out->n == out->cap) {
                size_t ncap = out->cap ? out->cap * 2 : 1024;
                bpfc_case_t *nv = realloc(out->v, ncap * sizeof(*nv));
                if (!nv) { fprintf(stderr, "bpfc: out of memory\n"); exit(2); }
                out->v = nv;
                out->cap = ncap;
            }
            out->v[out->n++] = c;
        }
        if (!nl) break;
        p = nl + 1;
    }
    out->text = text;      /* filters may point into it */
}

void bpfc_cases_free(bpfc_caseset_t *cs)
{
    size_t i;
    for (i = 0; i < cs->n; i++)
        if (cs->v[i].filter_owned)
            free(cs->v[i].filter);
    free(cs->v);
    free(cs->text);
    cs->v = NULL;
    cs->text = NULL;
    cs->n = cs->cap = 0;
}

/* ------------------------------------------------------------------ */
/* output                                                             */
/* ------------------------------------------------------------------ */

void json_write_string(FILE *f, const char *s)
{
    const unsigned char *p;

    fputc('"', f);
    for (p = (const unsigned char *)s; *p; p++) {
        switch (*p) {
        case '"':  fputs("\\\"", f); break;
        case '\\': fputs("\\\\", f); break;
        case '\n': fputs("\\n", f);  break;
        case '\r': fputs("\\r", f);  break;
        case '\t': fputs("\\t", f);  break;
        case '\b': fputs("\\b", f);  break;
        case '\f': fputs("\\f", f);  break;
        default:
            if (*p < 0x20) fprintf(f, "\\u%04x", *p);
            else fputc((int)*p, f);
        }
    }
    fputc('"', f);
}

void json_write_ok(FILE *f, long long i, const bpf_prog_t *prog)
{
    size_t j;

    fprintf(f, "{\"i\":%lld,\"ok\":true,\"prog\":[", i);
    for (j = 0; j < prog->len; j++) {
        const bpf_insn_t *ins = &prog->insns[j];
        fprintf(f, "%s[%u,%u,%u,%lu]", j ? "," : "",
                (unsigned)ins->code, (unsigned)ins->jt,
                (unsigned)ins->jf, (unsigned long)ins->k);
    }
    fputs("]}\n", f);
}

void json_write_err(FILE *f, long long i, const char *err)
{
    fprintf(f, "{\"i\":%lld,\"ok\":false,\"err\":", i);
    json_write_string(f, err);
    fputs("}\n", f);
}
