/*
 * gen.c - block-graph code generation.
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"

/* ------------------------------------------------------------------ arena */

void arena_init(ctx_t *cs)
{
    cs->chunks = NULL;
    cs->cur = NULL;
}

static arena_chunk_t *arena_newchunk(ctx_t *cs, size_t want)
{
    size_t sz = ARENA_CHUNK;
    arena_chunk_t *c;

    while (sz < want) sz *= 2;
    c = (arena_chunk_t *)malloc(sizeof(*c));
    if (!c) abort();
    c->mem = (char *)malloc(sz);
    if (!c->mem) abort();
    c->size = sz;
    c->used = 0;
    c->next = cs->chunks;
    cs->chunks = c;
    return c;
}

void *arena_alloc(ctx_t *cs, size_t n)
{
    arena_chunk_t *c = cs->cur;
    void *p;

    n = (n + 15u) & ~(size_t)15u;
    if (!c || c->used + n > c->size) {
        /* look for room in an existing chunk before making a new one */
        for (c = cs->chunks; c; c = c->next)
            if (c->used + n <= c->size) break;
        if (!c) c = arena_newchunk(cs, n);
        cs->cur = c;
    }
    p = c->mem + c->used;
    c->used += n;
    memset(p, 0, n);
    return p;
}

void arena_reset(ctx_t *cs)
{
    arena_chunk_t *c;
    for (c = cs->chunks; c; c = c->next)
        c->used = 0;
    cs->cur = cs->chunks;
}

void arena_free(ctx_t *cs)
{
    arena_chunk_t *c = cs->chunks, *n;
    while (c) { n = c->next; free(c->mem); free(c); c = n; }
    cs->chunks = NULL;
    cs->cur = NULL;
}

/* ------------------------------------------------------------------ error */

void fail(ctx_t *cs, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(cs->errbuf, sizeof(cs->errbuf), fmt, ap);
    va_end(ap);
    cs->failed = 1;
    longjmp(cs->jmp, 1);
}

/* ------------------------------------------------------- stmts and blocks */

op_t *op_new(ctx_t *cs, uint16_t code)
{
    op_t *s = (op_t *)arena_alloc(cs, sizeof(*s));
    s->s.code = code;
    return s;
}

node_t *blk_new(ctx_t *cs, uint16_t code)
{
    node_t *b = (node_t *)arena_alloc(cs, sizeof(*b));
    b->s.code = code;
    b->next_free = cs->node_list;
    cs->node_list = b;
    cs->node_count++;
    return b;
}

op_t *op_cat(op_t *s0, op_t *s1)
{
    op_t *p = s0;
    if (!s0) return s1;
    while (p->next) p = p->next;
    p->next = s1;
    return s0;
}

/* ------------------------------------------------ boolean expression glue */

static exlist_t ex_one(ctx_t *cs, node_t *b, int isjt)
{
    exlist_t l;
    exit_t *e = (exit_t *)arena_alloc(cs, sizeof(*e));
    e->b = b;
    e->isjt = isjt;
    e->next = NULL;
    l.head = l.tail = e;
    return l;
}

static exlist_t ex_cat(exlist_t a, exlist_t b)
{
    exlist_t r;
    if (!a.head) return b;
    if (!b.head) return a;
    a.tail->next = b.head;
    r.head = a.head;
    r.tail = b.tail;
    return r;
}

static void ex_patch(exlist_t l, node_t *tgt)
{
    exit_t *e;
    for (e = l.head; e; e = e->next) {
        if (e->isjt) JT(e->b) = tgt;
        else JF(e->b) = tgt;
    }
}

test_t bx_leaf_cs(ctx_t *cs, node_t *b)
{
    test_t e;
    e.entry = b;
    e.t = ex_one(cs, b, 1);
    e.f = ex_one(cs, b, 0);
    return e;
}

void bx_patch_t(test_t e, node_t *tgt) { ex_patch(e.t, tgt); }
void bx_patch_f(test_t e, node_t *tgt) { ex_patch(e.f, tgt); }

test_t bx_and(ctx_t *cs, test_t a, test_t b)
{
    test_t r;
    (void)cs;
    ex_patch(a.t, b.entry);
    r.entry = a.entry;
    r.t = b.t;
    r.f = ex_cat(a.f, b.f);
    return r;
}

test_t bx_or(ctx_t *cs, test_t a, test_t b)
{
    test_t r;
    (void)cs;
    ex_patch(a.f, b.entry);
    r.entry = a.entry;
    r.t = ex_cat(a.t, b.t);
    r.f = b.f;
    return r;
}

test_t bx_not(test_t a)
{
    test_t r;
    r.entry = a.entry;
    r.t = a.f;
    r.f = a.t;
    return r;
}

/* --------------------------------------------------- register allocation */

int mem_take(ctx_t *cs)
{
    int n = cs->memnext;
    int i;

    for (i = 0; i < BPF_MEMWORDS; i++) {
        if (!cs->memused[n]) {
            cs->memnext = n;
            cs->memused[n] = 1;
            return n;
        }
        n = (n + 1) % BPF_MEMWORDS;
    }
    fail(cs, "too many registers needed to evaluate expression");
    return 0;
}

void mem_drop(ctx_t *cs, int n)
{
    if (n >= 0 && n < BPF_MEMWORDS)
        cs->memused[n] = 0;
}

/* ------------------------------------------------------- link layer setup */

static void clear_layout(ctx_t *cs)
{
    cs->hdr_at.dynamic = 0;
    cs->hdr_at.fixed = 0;
    cs->hdr_at.regid = VR_LINKHDR;
    cs->outer_at = cs->hdr_at;
    cs->type_at.dynamic = 0;
    cs->type_at.fixed = OFFSET_NOT_SET;
    cs->type_at.regid = VR_LINKPL;
    cs->pay_at.dynamic = 0;
    cs->pay_at.fixed = 0;
    cs->pay_at.regid = VR_LINKPL;
    cs->nl_skip = OFFSET_NOT_SET;
    cs->raw_skip = OFFSET_NOT_SET;
    cs->vreg[VR_LINKHDR] = -1;
    cs->vreg[VR_LINKPL] = -1;
}

void setup_layout(ctx_t *cs)
{
    clear_layout(cs);
    cs->fddi_pad = 0;
    cs->mpls_depth = 0;
    cs->tag_depth = 0;
    cs->nested = 0;
    cs->tag_dynamic = 0;
    cs->outer_link = cs->link;
    cs->prev_link = cs->link;

    switch (cs->link) {

    case LNK_ARCNET:
        cs->type_at.fixed = 2;
        cs->pay_at.fixed = 6;
        cs->nl_skip = 0;
        cs->raw_skip = 0;
        break;

    case LNK_EN10MB:
        cs->type_at.fixed = 12;
        cs->pay_at.fixed = 14;
        cs->nl_skip = 0;
        cs->raw_skip = 3;
        break;

    case LNK_SLIP:
        cs->type_at.fixed = OFFSET_NOT_SET;
        cs->pay_at.fixed = 16;
        cs->nl_skip = 0;
        cs->raw_skip = 0;
        break;

    case LNK_NULL:
    case LNK_LOOP:
        cs->type_at.fixed = 0;
        cs->pay_at.fixed = 4;
        cs->nl_skip = 0;
        cs->raw_skip = 0;
        break;

    case LNK_PPP:
    case LNK_PPP_PPPD:
    case LNK_PPP_SERIAL:
    case LNK_PPP_ETHER:
        cs->type_at.fixed = 2;
        cs->pay_at.fixed = 4;
        cs->nl_skip = 0;
        cs->raw_skip = 0;
        break;

    case LNK_RAW:
    case LNK_IPV4:
    case LNK_IPV6:
        cs->type_at.fixed = OFFSET_NOT_SET;
        cs->pay_at.fixed = 0;
        cs->nl_skip = 0;
        cs->raw_skip = 0;
        break;

    case LNK_LINUX_SLL:
        cs->type_at.fixed = 14;
        cs->pay_at.fixed = 16;
        cs->nl_skip = 0;
        cs->raw_skip = 0;
        break;

    case LNK_FDDI:
        cs->type_at.fixed = 13;
        cs->type_at.fixed += cs->fddi_pad;
        cs->pay_at.fixed = 13;
        cs->pay_at.fixed += cs->fddi_pad;
        cs->nl_skip = 8;
        cs->raw_skip = 3;
        break;

    case LNK_IEEE802:
        cs->type_at.fixed = 14;
        cs->pay_at.fixed = 14;
        cs->nl_skip = 8;
        cs->raw_skip = 3;
        break;

    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        /*
         * The radio header has no fixed size, so a scratch slot carries the
         * start of the LLC header at run time; the type sits six bytes in.
         */
        if (cs->link != LNK_IEEE802_11)
            cs->hdr_at.dynamic = 1;
        cs->type_at.dynamic = 1;
        cs->type_at.fixed = 6;
        cs->pay_at.dynamic = 1;
        cs->pay_at.fixed = 0;
        cs->nl_skip = 8;
        cs->raw_skip = 3;
        break;

    default:
        fail(cs, "unknown data link type %d", cs->link);
        break;
    }
}

/* ------------------------------------------------------------ load / cmp */

op_t *base_to_x(ctx_t *cs, base_t *off)
{
    op_t *s;

    if (!off->dynamic)
        return NULL;
    if (cs->vreg[off->regid] == -1)
        cs->vreg[off->regid] = mem_take(cs);
    s = op_new(cs, BPF_LDX | BPF_MEM);
    s->s.k = (uint32_t)cs->vreg[off->regid];
    return s;
}

static void need_offset(ctx_t *cs, uint32_t off)
{
    if (off == OFFSET_NOT_SET)
        fail(cs, "unknown data link type %d", cs->link);
}

static op_t *fetch_based(ctx_t *cs, base_t *base, uint32_t offset,
                                uint32_t size)
{
    op_t *s, *s2;

    need_offset(cs, base->fixed);
    s = base_to_x(cs, base);
    if (s) {
        s2 = op_new(cs, BPF_LD | BPF_IND | size);
        s2->s.k = base->fixed + offset;
        op_cat(s, s2);
        return s;
    }
    s = op_new(cs, BPF_LD | BPF_ABS | size);
    s->s.k = base->fixed + offset;
    return s;
}

static op_t *v4hlen_to_x(ctx_t *cs);

op_t *v4hlen_to_x_ext(ctx_t *cs)
{
    return v4hlen_to_x(cs);
}

static op_t *v4hlen_to_x(ctx_t *cs)
{
    op_t *s, *s2;

    s = base_to_x(cs, &cs->pay_at);
    if (s) {
        s2 = op_new(cs, BPF_LD | BPF_IND | BPF_B);
        s2->s.k = cs->pay_at.fixed + cs->nl_skip;
        op_cat(s, s2);
        s2 = op_new(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->s.k = 0xf;
        op_cat(s, s2);
        s2 = op_new(cs, BPF_ALU | BPF_LSH | BPF_K);
        s2->s.k = 2;
        op_cat(s, s2);
        s2 = op_new(cs, BPF_ALU | BPF_ADD | BPF_X);
        op_cat(s, s2);
        s2 = op_new(cs, BPF_MISC | BPF_TAX);
        op_cat(s, s2);
    } else {
        s = op_new(cs, BPF_LDX | BPF_MSH | BPF_B);
        s->s.k = cs->pay_at.fixed + cs->nl_skip;
    }
    return s;
}

op_t *fetch_a(ctx_t *cs, enum basekind rel, uint32_t offset, uint32_t size)
{
    op_t *s, *s2;

    switch (rel) {
    case B_ABS:
        s = op_new(cs, BPF_LD | BPF_ABS | size);
        s->s.k = offset;
        break;

    case B_HDR:
        s = fetch_based(cs, &cs->hdr_at, offset, size);
        break;

    case B_OUTER:
        s = fetch_based(cs, &cs->outer_at, offset, size);
        break;

    case B_LLC:
        s = fetch_based(cs, &cs->pay_at, offset, size);
        break;

    case B_PREVLABEL:
        s = fetch_based(cs, &cs->pay_at, offset - 4, size);
        break;

    case B_PL:
        need_offset(cs, cs->nl_skip);
        s = fetch_based(cs, &cs->pay_at, cs->nl_skip + offset, size);
        break;

    case B_RAWPL:
        need_offset(cs, cs->raw_skip);
        s = fetch_based(cs, &cs->pay_at, cs->raw_skip + offset, size);
        break;

    case B_TYPE:
        s = fetch_based(cs, &cs->type_at, offset, size);
        break;

    case B_TP4:
        need_offset(cs, cs->pay_at.fixed);
        need_offset(cs, cs->nl_skip);
        s = v4hlen_to_x(cs);
        s2 = op_new(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->pay_at.fixed + cs->nl_skip + offset;
        op_cat(s, s2);
        break;

    case B_TP6:
        s = fetch_a(cs, B_PL, offset + 40, size);
        break;

    default:
        s = NULL;
        break;
    }
    return s;
}

static test_t wcmp_any(ctx_t *cs, enum basekind rel, uint32_t offset,
                       uint32_t size, uint32_t mask, int jtype, int reverse,
                       uint32_t v)
{
    op_t *s, *s2;
    node_t *b;

    s = fetch_a(cs, rel, offset, size);
    if (mask != 0xffffffffU) {
        s2 = op_new(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->s.k = mask;
        op_cat(s, s2);
    }
    b = blk_new(cs, (uint16_t)(BPF_JMP | jtype | BPF_K));
    b->stmts = s;
    b->s.k = v;
    if (reverse && (jtype == BPF_JGT || jtype == BPF_JGE))
        return bx_not(bx_leaf_cs(cs, b));
    return bx_leaf_cs(cs, b);
}

test_t wcmp_eq(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v)
{
    return wcmp_any(cs, rel, off, size, 0xffffffffU, BPF_JEQ, 0, v);
}
test_t wcmp_gt(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v)
{
    return wcmp_any(cs, rel, off, size, 0xffffffffU, BPF_JGT, 0, v);
}
test_t wcmp_ge(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v)
{
    return wcmp_any(cs, rel, off, size, 0xffffffffU, BPF_JGE, 0, v);
}
test_t wcmp_lt(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v)
{
    return wcmp_any(cs, rel, off, size, 0xffffffffU, BPF_JGE, 1, v);
}
test_t wcmp_le(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size, uint32_t v)
{
    return wcmp_any(cs, rel, off, size, 0xffffffffU, BPF_JGT, 1, v);
}
test_t wcmp_mask(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size,
                uint32_t v, uint32_t mask)
{
    return wcmp_any(cs, rel, off, size, mask, BPF_JEQ, 0, v);
}

test_t wcmp_bytes(ctx_t *cs, enum basekind rel, uint32_t off, uint32_t size,
                const uint8_t *v)
{
    test_t b, tmp;
    int have = 0;

    b.entry = NULL; b.t.head = b.t.tail = NULL; b.f.head = b.f.tail = NULL;
    while (size >= 4) {
        const uint8_t *p = &v[size - 4];
        uint32_t w = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
                     ((uint32_t)p[2] << 8) | p[3];
        tmp = wcmp_eq(cs, rel, off + size - 4, BPF_W, w);
        if (have) b = bx_and(cs, b, tmp); else { b = tmp; have = 1; }
        size -= 4;
    }
    while (size >= 2) {
        const uint8_t *p = &v[size - 2];
        uint32_t w = ((uint32_t)p[0] << 8) | p[1];
        tmp = wcmp_eq(cs, rel, off + size - 2, BPF_H, w);
        if (have) b = bx_and(cs, b, tmp); else { b = tmp; have = 1; }
        size -= 2;
    }
    if (size > 0) {
        tmp = wcmp_eq(cs, rel, off, BPF_B, (uint32_t)v[0]);
        if (have) b = bx_and(cs, b, tmp); else { b = tmp; have = 1; }
    }
    return b;
}

static test_t fixed_result(ctx_t *cs, int rsense)
{
    node_t *b;
    op_t *s;

    s = op_new(cs, BPF_LD | BPF_IMM);
    s->s.k = (uint32_t)!rsense;
    b = blk_new(cs, BPF_JMP | BPF_JEQ | BPF_K);
    b->stmts = s;
    b->s.k = 0;
    return bx_leaf_cs(cs, b);
}

test_t always_yes(ctx_t *cs)  { return fixed_result(cs, 1); }
test_t always_no(ctx_t *cs) { return fixed_result(cs, 0); }

/* --------------------------------------------------------- ll_type_test */

static test_t snap_match(ctx_t *cs, uint32_t orgcode, uint32_t ptype)
{
    uint8_t snapblock[8];

    snapblock[0] = SAP_SNAP;
    snapblock[1] = SAP_SNAP;
    snapblock[2] = 0x03;
    snapblock[3] = (uint8_t)(orgcode >> 16);
    snapblock[4] = (uint8_t)(orgcode >> 8);
    snapblock[5] = (uint8_t)(orgcode >> 0);
    snapblock[6] = (uint8_t)(ptype >> 8);
    snapblock[7] = (uint8_t)(ptype >> 0);
    return wcmp_bytes(cs, B_LLC, 0, 8, snapblock);
}

static test_t llc_type_test(ctx_t *cs, uint32_t ll_proto)
{
    /*
     * A value at or below the max length field is a SAP; anything larger
     * is an ethertype carried in a SNAP header.
     */
    switch (ll_proto) {

    case SAP_IP:
    case SAP_OSI:
    case SAP_NB:
        return wcmp_eq(cs, B_LLC, 0, BPF_H,
                       (ll_proto << 8) | ll_proto);

    case SAP_IPX:
        return wcmp_eq(cs, B_LLC, 0, BPF_B, SAP_IPX);

    case TY_ATALK:
        return snap_match(cs, 0x080007, TY_ATALK);

    default:
        if (ll_proto <= MAX_LEN_FIELD)
            return wcmp_eq(cs, B_LLC, 0, BPF_B, ll_proto);
        return snap_match(cs, 0x000000, ll_proto);
    }
}

static test_t eth_type_test(ctx_t *cs, uint32_t ll_proto)
{
    test_t b0, b1;

    switch (ll_proto) {

    case SAP_OSI:
    case SAP_IP:
    case SAP_NB:
        /* length-field frame carrying this SAP pair */
        b0 = wcmp_gt(cs, B_TYPE, 0, BPF_H, MAX_LEN_FIELD);
        b0 = bx_not(b0);
        b1 = wcmp_eq(cs, B_TYPE, 2, BPF_H, (ll_proto << 8) | ll_proto);
        return bx_and(cs, b0, b1);

    case SAP_IPX:
        /*
         * Four shapes are accepted here: a plain ethertype, a raw 802.3
         * frame (0xFFFF where the SAPs would be), the IPX SAP, and SNAP.
         */
        b0 = wcmp_eq(cs, B_TYPE, 2, BPF_B, SAP_IPX);
        b1 = wcmp_eq(cs, B_TYPE, 2, BPF_H, 0xFFFF);
        b0 = bx_or(cs, b1, b0);
        b1 = snap_match(cs, 0x000000, TY_IPX);
        b0 = bx_or(cs, b0, b1);
        b1 = wcmp_gt(cs, B_TYPE, 0, BPF_H, MAX_LEN_FIELD);
        b1 = bx_not(b1);
        b0 = bx_and(cs, b1, b0);
        b1 = wcmp_eq(cs, B_TYPE, 0, BPF_H, TY_IPX);
        return bx_or(cs, b1, b0);

    case TY_ATALK:
    case TY_AARP:
        /* the phase 2 form rides on SNAP */
        b0 = wcmp_gt(cs, B_TYPE, 0, BPF_H, MAX_LEN_FIELD);
        b0 = bx_not(b0);
        if (ll_proto == TY_ATALK)
            b1 = snap_match(cs, 0x080007, TY_ATALK);
        else
            b1 = snap_match(cs, 0x000000, TY_AARP);
        b1 = bx_and(cs, b0, b1);
        b0 = wcmp_eq(cs, B_TYPE, 0, BPF_H, ll_proto);
        return bx_or(cs, b0, b1);

    default:
        if (ll_proto <= MAX_LEN_FIELD) {
            b0 = wcmp_gt(cs, B_TYPE, 0, BPF_H, MAX_LEN_FIELD);
            b0 = bx_not(b0);
            b1 = wcmp_eq(cs, B_TYPE, 2, BPF_B, ll_proto);
            return bx_and(cs, b0, b1);
        }
        return wcmp_eq(cs, B_TYPE, 0, BPF_H, ll_proto);
    }
}

static test_t lo_type_test(ctx_t *cs, uint32_t ll_proto)
{
    switch (ll_proto) {

    case TY_IP4:
        return wcmp_eq(cs, B_HDR, 0, BPF_W, 2U << 24);

    case TY_IP6:
        return wcmp_eq(cs, B_HDR, 0, BPF_W, 10U << 24);

    default:
        return always_no(cs);
    }
}

static uint32_t to_ppp_proto(uint32_t proto)
{
    switch (proto) {
    case TY_IP4:    return PP_IP4;
    case TY_IP6:  return PP_IP6;
    case TY_DECNET:    return PP_DECNET;
    case TY_ATALK: return PP_APPLE;
    case TY_XNS:    return PP_XNS;
    case SAP_OSI:    return PP_OSI;
    case TY_IPX:   return PP_IPX;
    case TY_LABEL:  return PP_LABEL;
    case TY_LABELM: return PP_LABELM;
    case SAP_STP:    return PP_IPCP; /* not really; unused */
    default:              return proto;
    }
}

static test_t sll_type_test(ctx_t *cs, uint32_t ll_proto)
{
    test_t b0, b1;

    switch (ll_proto) {

    case SAP_IP:
    case SAP_OSI:
    case SAP_NB:
        b0 = wcmp_eq(cs, B_TYPE, 0, BPF_H, SLL_LLC);
        b1 = wcmp_eq(cs, B_PL, 0, BPF_H, (ll_proto << 8) | ll_proto);
        return bx_and(cs, b0, b1);

    case SAP_IPX:
        b0 = wcmp_eq(cs, B_TYPE, 0, BPF_H, SLL_RAW802);
        b1 = wcmp_eq(cs, B_PL, 0, BPF_B, SAP_IPX);
        b0 = bx_or(cs, b0, b1);
        b1 = snap_match(cs, 0x000000, TY_IPX);
        b0 = bx_or(cs, b0, b1);
        b1 = wcmp_eq(cs, B_TYPE, 0, BPF_H, SLL_LLC);
        b0 = bx_and(cs, b1, b0);
        b1 = wcmp_eq(cs, B_TYPE, 0, BPF_H, TY_IPX);
        return bx_or(cs, b1, b0);

    case TY_ATALK:
    case TY_AARP:
        b0 = wcmp_eq(cs, B_TYPE, 0, BPF_H, SLL_LLC);
        if (ll_proto == TY_ATALK)
            b1 = snap_match(cs, 0x080007, TY_ATALK);
        else
            b1 = snap_match(cs, 0x000000, TY_AARP);
        b1 = bx_and(cs, b0, b1);
        b0 = wcmp_eq(cs, B_TYPE, 0, BPF_H, ll_proto);
        return bx_or(cs, b0, b1);

    default:
        if (ll_proto <= MAX_LEN_FIELD) {
            b0 = wcmp_eq(cs, B_TYPE, 0, BPF_H, SLL_LLC);
            b1 = wcmp_eq(cs, B_PL, 0, BPF_B, ll_proto);
            return bx_and(cs, b0, b1);
        }
        return wcmp_eq(cs, B_TYPE, 0, BPF_H, ll_proto);
    }
}

/* Data frames carry bit 0x08 of the first frame-control byte and clear 0x04. */
static test_t w80211_data_frame(ctx_t *cs)
{
    op_t *s;
    node_t *b0, *b1;
    test_t e0, e1;

    s = fetch_a(cs, B_HDR, 0, BPF_B);
    b0 = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    b0->s.k = 0x04;
    b0->stmts = s;
    e0 = bx_not(bx_leaf_cs(cs, b0));

    s = fetch_a(cs, B_HDR, 0, BPF_B);
    b1 = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    b1->s.k = 0x08;
    b1->stmts = s;
    e1 = bx_leaf_cs(cs, b1);

    return bx_and(cs, e0, e1);
}

/*
 * Build the op list that works out how long the radio header is.  X holds
 * the start of that header when this list runs; the answer lands in the
 * scratch slot reserved for the payload base.
 */
static op_t *w80211_hdrlen_code(ctx_t *cs, op_t *s, op_t *snext)
{
    op_t *s2, *sjset_data, *sjset_not_data, *sjset_qos;

    s2 = op_new(cs, BPF_MISC | BPF_TXA);
    op_cat(s, s2);
    s2 = op_new(cs, BPF_ALU | BPF_ADD | BPF_K);
    s2->s.k = 24;
    op_cat(s, s2);
    s2 = op_new(cs, BPF_ST);
    s2->s.k = (uint32_t)cs->vreg[VR_LINKPL];
    op_cat(s, s2);

    s2 = op_new(cs, BPF_LD | BPF_IND | BPF_B);
    s2->s.k = 0;
    op_cat(s, s2);

    sjset_data = op_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    sjset_data->s.k = 0x08;
    op_cat(s, sjset_data);

    sjset_not_data = op_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    sjset_not_data->s.k = 0x04;
    op_cat(s, sjset_not_data);

    sjset_qos = op_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    sjset_qos->s.k = 0x80;
    op_cat(s, sjset_qos);

    s2 = op_new(cs, BPF_LD | BPF_MEM);
    s2->s.k = (uint32_t)cs->vreg[VR_LINKPL];
    op_cat(s, s2);
    s2 = op_new(cs, BPF_ALU | BPF_ADD | BPF_K);
    s2->s.k = 2;
    op_cat(s, s2);
    s2 = op_new(cs, BPF_ST);
    s2->s.k = (uint32_t)cs->vreg[VR_LINKPL];
    op_cat(s, s2);

    sjset_data->s.jt = sjset_not_data;
    sjset_data->s.jf = snext;
    sjset_not_data->s.jt = snext;
    sjset_not_data->s.jf = sjset_qos;
    sjset_qos->s.jt = NULL;      /* fall through */
    sjset_qos->s.jf = snext;

    return s;
}

void prefix_offset_code(ctx_t *cs, node_t *b)
{
    op_t *s;

    if (cs->vreg[VR_LINKPL] == -1 && cs->vreg[VR_LINKHDR] == -1)
        return;

    if (cs->vreg[VR_LINKPL] != -1) {
        switch (cs->link) {
        case LNK_IEEE802_11:
        case LNK_PRISM_HEADER:
        case LNK_IEEE802_11_RADIO_AVS:
        case LNK_IEEE802_11_RADIO:
            if (cs->hdr_at.dynamic) {
                s = op_new(cs, BPF_LDX | BPF_MEM);
                s->s.k = (uint32_t)cs->vreg[VR_LINKHDR];
            } else {
                s = op_new(cs, BPF_LDX | BPF_IMM);
                s->s.k = cs->hdr_at.fixed;
            }
            s = w80211_hdrlen_code(cs, s, b->stmts);
            op_cat(s, b->stmts);
            b->stmts = s;
            break;
        default:
            break;
        }
    }
}

static test_t outer_hdr_check(ctx_t *cs)
{
    if (cs->nested)
        return wcmp_eq(cs, B_OUTER, 0, BPF_W, 0);
    return always_yes(cs);
}

test_t ll_type_test(ctx_t *cs, uint32_t ll_proto)
{
    test_t b0, b1, b2;


    switch (cs->link) {

    case LNK_EN10MB:
        switch (ll_proto) {
        case SAP_OSI:
        case SAP_IP:
        case SAP_NB:
        case SAP_IPX:
        case TY_ATALK:
        case TY_AARP:
        default:
            break;
        }
        return eth_type_test(cs, ll_proto);

    case LNK_C_HDLC:
        switch (ll_proto) {
        case SAP_OSI:
            ll_proto = (ll_proto << 8 | SAP_OSI);
            /* fall through */
        default:
            return wcmp_eq(cs, B_TYPE, 0, BPF_H, ll_proto);
        }

    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        /*
         * Require a data frame and read the type from the SNAP header we
         * assume follows it.
         */
        b0 = w80211_data_frame(cs);
        b1 = wcmp_eq(cs, B_TYPE, 0, BPF_H, ll_proto);
        return bx_and(cs, b0, b1);

    case LNK_FDDI:
    case LNK_IEEE802:
    case LNK_ATM_RFC1483:
    case LNK_ATM_CLIP:
    case LNK_IP_OVER_FC:
        return llc_type_test(cs, ll_proto);

    case LNK_LINUX_SLL:
        return sll_type_test(cs, ll_proto);

    case LNK_SLIP:
    case LNK_SLIP_BSDOS:
    case LNK_RAW:
        if (ll_proto == TY_IP4)
            return wcmp_mask(cs, B_HDR, 0, BPF_B, 0x40, 0xF0);
        if (ll_proto == TY_IP6)
            return wcmp_mask(cs, B_HDR, 0, BPF_B, 0x60, 0xF0);
        return always_no(cs);

    case LNK_IPV4:
        if (ll_proto == TY_IP4)
            return always_yes(cs);
        return always_no(cs);

    case LNK_IPV6:
        if (ll_proto == TY_IP6)
            return always_yes(cs);
        return always_no(cs);

    case LNK_PPP:
    case LNK_PPP_PPPD:
    case LNK_PPP_SERIAL:
    case LNK_PPP_ETHER:
        return wcmp_eq(cs, B_TYPE, 0, BPF_H,
                       to_ppp_proto(ll_proto));

    case LNK_NULL:
    case LNK_LOOP:
    case LNK_ENC:
        return lo_type_test(cs, ll_proto);

    case LNK_ARCNET:
        return always_no(cs);

    default:
        if (cs->type_at.fixed == OFFSET_NOT_SET)
            fail(cs, "unknown data link type %d", cs->link);
        return wcmp_eq(cs, B_TYPE, 0, BPF_H, ll_proto);
    }
    (void)b0; (void)b1; (void)b2;
}
