src/names.o: src/names.c src/names.h src/tables_gen.h
src/names.h:
src/tables_gen.h:
