src/parse.o: src/parse.c src/comp.h src/bpf_defs.h src/gen.h src/lex.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
src/lex.h:
