/*
 * gen3.c - arithmetic expressions and the remaining primitives.
 */
#include <stdio.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"

extern test_t unfragmented(ctx_t *cs);
extern test_t nl_proto_test(ctx_t *cs, uint32_t v, int proto, int dir);

/* ------------------------------------------------------------- utilities */

int scan_mac(const char *s, uint8_t *out)
{
    int i;
    unsigned v;
    const char *p = s;

    for (i = 0; i < 6; i++) {
        v = 0;
        if (!((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') ||
              (*p >= 'A' && *p <= 'F')))
            return 0;
        while ((*p >= '0' && *p <= '9') || (*p >= 'a' && *p <= 'f') ||
               (*p >= 'A' && *p <= 'F')) {
            unsigned d = (*p <= '9') ? (unsigned)(*p - '0')
                                     : (unsigned)((*p | 0x20) - 'a' + 10);
            v = v * 16 + d;
            p++;
        }
        if (v > 255) return 0;
        out[i] = (uint8_t)v;
        if (i < 5) {
            if (*p != ':' && *p != '.' && *p != '-') return 0;
            p++;
        }
    }
    return *p == '\0';
}

int scan_v6(const char *s, uint8_t *out)
{
    uint16_t words[8];
    int nw = 0, gap = -1;
    const char *p = s;

    memset(out, 0, 16);
    if (p[0] == ':' && p[1] == ':') { gap = 0; p += 2; }
    while (*p) {
        unsigned v = 0;
        int nd = 0;
        const char *start = p;
        while ((*p >= '0' && *p <= '9') || ((*p | 0x20) >= 'a' && (*p | 0x20) <= 'f')) {
            unsigned d = (*p <= '9') ? (unsigned)(*p - '0')
                                     : (unsigned)((*p | 0x20) - 'a' + 10);
            v = v * 16 + d;
            nd++;
            p++;
            if (nd > 4) return 0;
        }
        if (nd == 0) return 0;
        if (*p == '.') {
            /* trailing dotted-quad form */
            unsigned b[4];
            int i;
            p = start;
            for (i = 0; i < 4; i++) {
                unsigned x = 0;
                int n2 = 0;
                while (*p >= '0' && *p <= '9') { x = x * 10 + (unsigned)(*p - '0'); p++; n2++; }
                if (n2 == 0 || x > 255) return 0;
                b[i] = x;
                if (i < 3) { if (*p != '.') return 0; p++; }
            }
            if (nw > 6) return 0;
            words[nw++] = (uint16_t)((b[0] << 8) | b[1]);
            words[nw++] = (uint16_t)((b[2] << 8) | b[3]);
            break;
        }
        if (nw >= 8) return 0;
        words[nw++] = (uint16_t)v;
        if (*p == ':') {
            p++;
            if (*p == ':') {
                if (gap >= 0) return 0;
                gap = nw;
                p++;
                if (*p == '\0') break;
            } else if (*p == '\0')
                return 0;
        } else if (*p != '\0')
            return 0;
    }
    if (gap < 0) {
        if (nw != 8) return 0;
    } else {
        int nafter = nw - gap, i;
        if (nw > 8) return 0;
        for (i = nafter - 1; i >= 0; i--)
            words[8 - nafter + i] = words[gap + i];
        for (i = gap; i < 8 - nafter; i++)
            words[i] = 0;
        nw = 8;
    }
    {
        int i;
        for (i = 0; i < 8; i++) {
            out[i*2] = (uint8_t)(words[i] >> 8);
            out[i*2+1] = (uint8_t)(words[i] & 0xff);
        }
    }
    return 1;
}

/* ------------------------------------------------------------ arithmetic */

static op_t *mem_to_x(ctx_t *cs, val_t *a)
{
    op_t *s = op_new(cs, BPF_LDX | BPF_MEM);
    s->s.k = (uint32_t)a->regno;
    return s;
}

static op_t *mem_to_a(ctx_t *cs, val_t *a)
{
    op_t *s = op_new(cs, BPF_LD | BPF_MEM);
    s->s.k = (uint32_t)a->regno;
    return s;
}

val_t *val_const(ctx_t *cs, uint32_t val)
{
    val_t *a;
    op_t *s;
    int reg = mem_take(cs);

    a = (val_t *)arena_alloc(cs, sizeof(*a));
    s = op_new(cs, BPF_LD | BPF_IMM);
    s->s.k = val;
    s->next = op_new(cs, BPF_ST);
    s->next->s.k = (uint32_t)reg;
    a->s = s;
    a->regno = reg;
    a->has_b = 0;
    return a;
}

val_t *val_pktlen(ctx_t *cs)
{
    int reg = mem_take(cs);
    val_t *a = (val_t *)arena_alloc(cs, sizeof(*a));
    op_t *s;

    s = op_new(cs, BPF_LD | BPF_LEN);
    s->next = op_new(cs, BPF_ST);
    s->next->s.k = (uint32_t)reg;
    a->s = s;
    a->regno = reg;
    a->has_b = 0;
    return a;
}

val_t *val_slice(ctx_t *cs, int proto, val_t *inst, uint32_t size)
{
    op_t *s, *s2;
    test_t b;
    int have_b = 0;
    int regno = mem_take(cs);

    mem_drop(cs, inst->regno);
    switch (size) {
    default:
        fail(cs, "data size must be 1, 2, or 4");
    case 1: size = BPF_B; break;
    case 2: size = BPF_H; break;
    case 4: size = BPF_W; break;
    }

    switch (proto) {
    default:
        fail(cs, "unsupported index operation");

    case QU_RADIO:
        if (cs->link != LNK_IEEE802_11_RADIO_AVS &&
            cs->link != LNK_IEEE802_11_RADIO &&
            cs->link != LNK_PRISM_HEADER)
            fail(cs, "radio information not present in capture");
        s = mem_to_x(cs, inst);
        s2 = op_new(cs, BPF_LD | BPF_IND | size);
        s2->s.k = 0;
        op_cat(s, s2);
        break;

    case QU_LINK:
        s = base_to_x(cs, &cs->hdr_at);
        if (s != NULL) {
            op_cat(s, mem_to_a(cs, inst));
            op_cat(s, op_new(cs, BPF_ALU | BPF_ADD | BPF_X));
            op_cat(s, op_new(cs, BPF_MISC | BPF_TAX));
        } else {
            s = mem_to_x(cs, inst);
        }
        s2 = op_new(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->hdr_at.fixed;
        op_cat(s, s2);
        break;

    case QU_IP:
    case QU_ARP:
    case QU_RARP:
    case QU_ATALK:
    case QU_DECNET:
    case QU_SCA:
    case QU_LAT:
    case QU_MOPDL:
    case QU_MOPRC:
    case QU_IPV6:
        s = base_to_x(cs, &cs->pay_at);
        if (s != NULL) {
            op_cat(s, mem_to_a(cs, inst));
            op_cat(s, op_new(cs, BPF_ALU | BPF_ADD | BPF_X));
            op_cat(s, op_new(cs, BPF_MISC | BPF_TAX));
        } else {
            s = mem_to_x(cs, inst);
        }
        s2 = op_new(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->pay_at.fixed + cs->nl_skip;
        op_cat(s, s2);
        b = abbrev_test(cs, proto);
        have_b = 1;
        if (inst->has_b) b = bx_and(cs, inst->b, b);
        break;

    case QU_SCTP:
    case QU_TCP:
    case QU_UDP:
    case QU_ICMP:
    case QU_IGMP:
    case QU_IGRP:
    case QU_PIM:
    case QU_VRRP:
    case QU_CARP:
    case QU_ICMPV6:
    case QU_AH:
    case QU_ESP: {
        test_t bt, bf;
        s = v4hlen_to_x_ext(cs);
        op_cat(s, mem_to_a(cs, inst));
        op_cat(s, op_new(cs, BPF_ALU | BPF_ADD | BPF_X));
        op_cat(s, op_new(cs, BPF_MISC | BPF_TAX));
        s2 = op_new(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->pay_at.fixed + cs->nl_skip;
        op_cat(s, s2);

        b = ll_type_test(cs, TY_IP4);
        bt = abbrev_test(cs, proto);
        b = bx_and(cs, b, bt);
        bf = unfragmented(cs);
        b = bx_and(cs, b, bf);
        have_b = 1;
        if (inst->has_b) b = bx_and(cs, inst->b, b);
        break;
    }
    }
    inst->regno = regno;
    s2 = op_new(cs, BPF_ST);
    s2->s.k = (uint32_t)regno;
    op_cat(s, s2);
    op_cat(inst->s, s);
    if (have_b) {
        inst->b = b;
        inst->has_b = 1;
    }
    return inst;
}

val_t *val_negate(ctx_t *cs, val_t *a)
{
    op_t *s;

    s = mem_to_a(cs, a);
    op_cat(a->s, s);
    s = op_new(cs, BPF_ALU | BPF_NEG);
    op_cat(a->s, s);
    s = op_new(cs, BPF_ST);
    s->s.k = (uint32_t)a->regno;
    op_cat(a->s, s);
    return a;
}

val_t *val_binop(ctx_t *cs, int code, val_t *a0, val_t *a1)
{
    op_t *s0, *s1, *s2;

    s0 = mem_to_x(cs, a1);
    s1 = mem_to_a(cs, a0);
    s2 = op_new(cs, (uint16_t)(BPF_ALU | BPF_X | code));
    op_cat(s1, s2);
    op_cat(s0, s1);
    op_cat(a1->s, s0);
    op_cat(a0->s, a1->s);

    mem_drop(cs, a0->regno);
    mem_drop(cs, a1->regno);
    a0->regno = mem_take(cs);
    s2 = op_new(cs, BPF_ST);
    s2->s.k = (uint32_t)a0->regno;
    op_cat(a0->s, s2);

    if (!a0->has_b && a1->has_b) {
        a0->b = a1->b;
        a0->has_b = 1;
    }
    return a0;
}

test_t val_compare(ctx_t *cs, int code, val_t *a0, val_t *a1, int reversed)
{
    op_t *s0, *s1, *s2;
    node_t *b;
    test_t e;

    s0 = mem_to_x(cs, a1);
    s1 = mem_to_a(cs, a0);
    if (code == BPF_JEQ) {
        s2 = op_new(cs, BPF_ALU | BPF_SUB | BPF_X);
        op_cat(s1, s2);
        b = blk_new(cs, BPF_JMP | BPF_JEQ | BPF_K);
        b->s.k = 0;
    } else {
        b = blk_new(cs, (uint16_t)(BPF_JMP | code | BPF_X));
    }
    op_cat(s0, s1);
    op_cat(a1->s, s0);
    op_cat(a0->s, a1->s);
    b->stmts = a0->s;

    mem_drop(cs, a0->regno);
    mem_drop(cs, a1->regno);

    e = bx_leaf_cs(cs, b);
    if (reversed)
        e = bx_not(e);
    if (a1->has_b)
        e = bx_and(cs, a1->b, e);
    if (a0->has_b)
        e = bx_and(cs, a0->b, e);
    return e;
}

/* --------------------------------------------------------- misc filters */

static test_t pktlen_test(ctx_t *cs, int jmp, uint32_t n)
{
    node_t *b = blk_new(cs, (uint16_t)(BPF_JMP | jmp | BPF_K));
    b->stmts = op_new(cs, BPF_LD | BPF_LEN);
    b->s.k = n;
    return bx_leaf_cs(cs, b);
}

test_t len_below(ctx_t *cs, uint32_t n)
{
    return bx_not(pktlen_test(cs, BPF_JGT, n));
}

test_t len_above(ctx_t *cs, uint32_t n)
{
    return pktlen_test(cs, BPF_JGE, n);
}

test_t raw_byte_test(ctx_t *cs, int op, int idx, uint32_t val)
{
    test_t b;
    op_t *s;
    node_t *blk;

    switch (op) {
    default:
        fail(cs, "bogus byte op");
    case '=':
        return wcmp_eq(cs, B_HDR, (uint32_t)idx, BPF_B, val);
    case '<':
        return wcmp_lt(cs, B_HDR, (uint32_t)idx, BPF_B, val);
    case '>':
        return wcmp_gt(cs, B_HDR, (uint32_t)idx, BPF_B, val);
    case '|':
        s = op_new(cs, BPF_ALU | BPF_OR | BPF_K);
        break;
    case '&':
        s = op_new(cs, BPF_ALU | BPF_AND | BPF_K);
        break;
    }
    s->s.k = val;
    blk = blk_new(cs, BPF_JMP | BPF_JEQ | BPF_K);
    blk->stmts = fetch_a(cs, B_HDR, (uint32_t)idx, BPF_B);
    op_cat(blk->stmts, s);
    blk->s.k = 0;
    b = bx_leaf_cs(cs, blk);
    return bx_not(b);
}

test_t bcast_test(ctx_t *cs, int proto)
{
    uint32_t hostmask;
    test_t b0, b1, b2;
    static const uint8_t ebroadcast[] = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };

    switch (proto) {

    case QU_DEFAULT:
    case QU_LINK:
        switch (cs->link) {
        case LNK_EN10MB:
        case LNK_NETANALYZER:
        case LNK_NETANALYZER_TRANSPARENT:
            return wcmp_bytes(cs, B_HDR, 0, 6, ebroadcast);
        case LNK_IEEE802:
            return wcmp_bytes(cs, B_HDR, 2, 6, ebroadcast);
        case LNK_FDDI:
            return wcmp_bytes(cs, B_HDR, 1, 6, ebroadcast);
        case LNK_IEEE802_11:
        case LNK_PRISM_HEADER:
        case LNK_IEEE802_11_RADIO_AVS:
        case LNK_IEEE802_11_RADIO:
            return wlan_bcast_test(cs, ebroadcast);
        default:
            fail(cs, "not a broadcast link");
        }
        break;

    case QU_IP:
        if (cs->lmask == 0xffffffffU)
            fail(cs, "netmask not known, so 'ip broadcast' not supported");
        b0 = ll_type_test(cs, TY_IP4);
        hostmask = ~cs->lmask;
        b1 = wcmp_mask(cs, B_PL, 16, BPF_W, 0, hostmask);
        b2 = wcmp_mask(cs, B_PL, 16, BPF_W, hostmask, hostmask);
        b1 = bx_or(cs, b1, b2);
        return bx_and(cs, b0, b1);
    }
    fail(cs, "only link-layer/IP broadcast filters supported");
    return always_no(cs);
}

static test_t group_bit_test(ctx_t *cs, uint32_t offset)
{
    op_t *s;
    node_t *b;

    s = fetch_a(cs, B_HDR, offset, BPF_B);
    b = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    b->s.k = 1;
    b->stmts = s;
    return bx_leaf_cs(cs, b);
}

test_t mcast_test(ctx_t *cs, int proto)
{
    test_t b0, b1;

    switch (proto) {

    case QU_DEFAULT:
    case QU_LINK:
        switch (cs->link) {
        case LNK_EN10MB:
        case LNK_NETANALYZER:
        case LNK_NETANALYZER_TRANSPARENT:
            return group_bit_test(cs, 0);
        case LNK_FDDI:
            return group_bit_test(cs, 1);
        case LNK_IEEE802:
            return group_bit_test(cs, 2);
        case LNK_IEEE802_11:
        case LNK_PRISM_HEADER:
        case LNK_IEEE802_11_RADIO_AVS:
        case LNK_IEEE802_11_RADIO:
            return wlan_group_test(cs);
        default:
            fail(cs, "link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel");
        }
        break;

    case QU_IP:
        b0 = ll_type_test(cs, TY_IP4);
        b1 = wcmp_mask(cs, B_PL, 16, BPF_B, 224, 240);
        return bx_and(cs, b0, b1);

    case QU_IPV6:
        b0 = ll_type_test(cs, TY_IP6);
        b1 = wcmp_eq(cs, B_PL, 24, BPF_B, 255);
        return bx_and(cs, b0, b1);
    }
    fail(cs, "only link-layer multicast filters supported");
    return always_no(cs);
}

test_t ifidx_test(ctx_t *cs, int ifindex)
{
    switch (cs->link) {
    case LNK_LINUX_SLL2:
        return wcmp_eq(cs, B_HDR, 4, BPF_W, (uint32_t)ifindex);
    default:
        return wcmp_eq(cs, B_ABS, (uint32_t)(-4096 + 8), BPF_W,
                       (uint32_t)ifindex);
    }
}

test_t travel_test(ctx_t *cs, int dir)
{
    test_t b0;

    switch (cs->link) {
    case LNK_LINUX_SLL:
        b0 = wcmp_eq(cs, B_HDR, 0, BPF_H, 4);
        if (!dir)
            b0 = bx_not(b0);
        break;
    default:
        b0 = wcmp_eq(cs, B_ABS, (uint32_t)(-4096 + 4), BPF_H, 4);
        if (!dir)
            b0 = bx_not(b0);
        break;
    }
    return b0;
}

/* ---------------------------------------------------------- encapsulation */

const char *link_name(int dlt)
{
    switch (dlt) {
    case LNK_NULL: return "BSD loopback";
    case LNK_EN10MB: return "Ethernet";
    case LNK_IEEE802: return "Token ring";
    case LNK_ARCNET: return "BSD ARCNET";
    case LNK_SLIP: return "SLIP";
    case LNK_PPP: return "PPP";
    case LNK_FDDI: return "FDDI";
    case LNK_ATM_RFC1483: return "RFC 1483 LLC-encapsulated ATM";
    case LNK_RAW: return "Raw IP";
    case LNK_SLIP_BSDOS: return "BSD/OS SLIP";
    case LNK_PPP_BSDOS: return "BSD/OS PPP";
    case LNK_ATM_CLIP: return "Linux Classical IP over ATM";
    case LNK_PPP_SERIAL: return "PPP over serial";
    case LNK_PPP_ETHER: return "PPPoE";
    case LNK_C_HDLC: return "Cisco HDLC";
    case LNK_IEEE802_11: return "802.11";
    case LNK_FRELAY: return "Frame Relay";
    case LNK_LOOP: return "OpenBSD loopback";
    case LNK_ENC: return "OpenBSD encapsulated IP";
    case LNK_LINUX_SLL: return "Linux cooked v1";
    case LNK_LTALK: return "Localtalk";
    case LNK_PFLOG: return "OpenBSD pflog file";
    case LNK_PRISM_HEADER: return "802.11 plus Prism header";
    case LNK_IP_OVER_FC: return "RFC 2625 IP-over-Fibre Channel";
    case LNK_SUNATM: return "Sun raw ATM";
    case LNK_IEEE802_11_RADIO: return "802.11 plus radiotap header";
    case LNK_IEEE802_11_RADIO_AVS: return "802.11 plus AVS radio information header";
    case LNK_IPV4: return "Raw IPv4";
    case LNK_IPV6: return "Raw IPv6";
    case LNK_LINUX_SLL2: return "Linux cooked v2";
    default: return NULL;
    }
}

void no_encap_support(ctx_t *cs, const char *what)
{
    const char *d = link_name(cs->link);
    if (d)
        fail(cs, "no %s support for %s", what, d);
    else
        fail(cs, "no %s support for DLT %d", what, cs->link);
}

static test_t vlan_tag_present(ctx_t *cs)
{
    test_t b0, b1;

    b0 = ll_type_test(cs, TY_TAG);
    b1 = ll_type_test(cs, TY_TAGAD);
    b0 = bx_or(cs, b0, b1);
    b1 = ll_type_test(cs, TY_TAG9100);
    return bx_or(cs, b0, b1);
}

test_t vlan_step(ctx_t *cs, uint32_t vlan_num, int has_vlan_tag)
{
    test_t b0, b1;

    if (cs->mpls_depth > 0)
        fail(cs, "no VLAN match after MPLS");

    switch (cs->link) {
    case LNK_EN10MB:
    case LNK_NETANALYZER:
    case LNK_NETANALYZER_TRANSPARENT:
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        break;
    default:
        no_encap_support(cs, "VLAN");
    }

    b0 = vlan_tag_present(cs);
    if (has_vlan_tag) {
        if (vlan_num > 0x0fff)
            fail(cs, "VLAN tag %u greater than maximum %u", vlan_num, 0x0fff);
        b1 = wcmp_mask(cs, B_PL, 0, BPF_H, vlan_num, 0x0fff);
        b0 = bx_and(cs, b0, b1);
    }

    cs->pay_at.fixed += 4;
    cs->type_at.fixed += 4;
    cs->tag_depth++;
    return b0;
}

test_t mpls_step(ctx_t *cs, uint32_t label, int has_label)
{
    test_t b0, b1;

    if (cs->mpls_depth > 0) {
        b0 = wcmp_mask(cs, B_PREVLABEL, 2, BPF_B, 0, 0x01);
    } else {
        switch (cs->link) {
        case LNK_C_HDLC:
        case LNK_EN10MB:
        case LNK_NETANALYZER:
        case LNK_NETANALYZER_TRANSPARENT:
        case LNK_IEEE802_11:
        case LNK_PRISM_HEADER:
        case LNK_IEEE802_11_RADIO_AVS:
        case LNK_IEEE802_11_RADIO:
            b0 = ll_type_test(cs, TY_LABEL);
            break;
        case LNK_PPP:
        case LNK_PPP_PPPD:
        case LNK_PPP_SERIAL:
        case LNK_PPP_ETHER:
            b0 = ll_type_test(cs, PP_LABEL);
            break;
        default:
            no_encap_support(cs, "MPLS");
            return always_no(cs);
        }
    }

    if (has_label) {
        if (label > 0xFFFFF)
            fail(cs, "MPLS label %u greater than maximum %u", label, 0xFFFFF);
        b1 = wcmp_mask(cs, B_PL, 0, BPF_W, label << 12, 0xfffff000U);
        b0 = bx_and(cs, b0, b1);
    }

    cs->raw_skip += 4;
    cs->nl_skip += 4;
    cs->mpls_depth++;
    return b0;
}

test_t pppoe_disc(ctx_t *cs)
{
    return ll_type_test(cs, TY_PPPOED);
}

test_t pppoe_sess(ctx_t *cs, uint32_t sess_num, int has_sess_num)
{
    test_t b0, b1;

    b0 = ll_type_test(cs, TY_PPPOES);
    if (has_sess_num) {
        if (sess_num > 0x0000ffff)
            fail(cs, "PPPoE session number %u greater than maximum %u",
                      sess_num, 0xffff);
        b1 = wcmp_eq(cs, B_PL, 2, BPF_H, sess_num);
        b0 = bx_and(cs, b0, b1);
    }

    cs->type_at.fixed = cs->pay_at.fixed + cs->nl_skip + 6;
    cs->pay_at.fixed = cs->pay_at.fixed + cs->nl_skip + 8;
    cs->type_at.dynamic = cs->pay_at.dynamic;
    cs->type_at.regid = cs->pay_at.regid;
    cs->nl_skip = 0;
    cs->raw_skip = 0;
    cs->prev_link = cs->link;
    cs->link = LNK_PPP;
    return b0;
}
