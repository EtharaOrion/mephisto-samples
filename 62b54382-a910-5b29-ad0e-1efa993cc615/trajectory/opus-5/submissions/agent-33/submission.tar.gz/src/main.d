src/main.o: src/main.c src/filter.h src/comp.h src/bpf_defs.h \
 src/jsonio.h
src/filter.h:
src/comp.h:
src/bpf_defs.h:
src/jsonio.h:
