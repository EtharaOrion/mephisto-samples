/*
 * parse.c - recursive-descent front end for the filter language.
 */
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "lex.h"

typedef struct {
    test_t b;
    sel_t q;
    int    valid;
} pblk_t;

typedef struct {
    lexer_t  lx;
    ctx_t *cs;
} P;

static const sel_t qdef = { QU_DEFAULT, QU_DEFAULT, QU_DEFAULT };
static const sel_t qerr = { QU_UNDEF, QU_UNDEF, QU_UNDEF };

static void syntax_error(P *p)
{
    fail(p->cs, "can't parse filter expression: syntax error");
}

static int tt(P *p) { return p->lx.tok.type; }
static void advance(P *p) { lex_next(&p->lx); }
static void expect(P *p, int type)
{
    if (tt(p) != type) syntax_error(p);
    advance(p);
}

static pblk_t pr_expr(P *p);
static pblk_t pr_term(P *p);
static val_t *pr_arth(P *p, int minprec);

/* ------------------------------------------------------------ qualifiers */

static int pname_proto(int t)
{
    switch (t) {
    case K_LINK: return QU_LINK;
    case K_IP: return QU_IP;
    case K_ARP: return QU_ARP;
    case K_RARP: return QU_RARP;
    case K_SCTP: return QU_SCTP;
    case K_TCP: return QU_TCP;
    case K_UDP: return QU_UDP;
    case K_ICMP: return QU_ICMP;
    case K_IGMP: return QU_IGMP;
    case K_IGRP: return QU_IGRP;
    case K_PIM: return QU_PIM;
    case K_VRRP: return QU_VRRP;
    case K_CARP: return QU_CARP;
    case K_ATALK: return QU_ATALK;
    case K_AARP: return QU_AARP;
    case K_DECNET: return QU_DECNET;
    case K_LAT: return QU_LAT;
    case K_SCA: return QU_SCA;
    case K_MOPRC: return QU_MOPRC;
    case K_MOPDL: return QU_MOPDL;
    case K_STP: return QU_STP;
    case K_IPX: return QU_IPX;
    case K_NETBEUI: return QU_NETBEUI;
    case K_ISO: return QU_ISO;
    case K_ESIS: return QU_ESIS;
    case K_ISIS: return QU_ISIS;
    case K_L1: return QU_ISIS_L1;
    case K_L2: return QU_ISIS_L2;
    case K_IIH: return QU_ISIS_IIH;
    case K_LSP: return QU_ISIS_LSP;
    case K_SNP: return QU_ISIS_SNP;
    case K_CSNP: return QU_ISIS_CSNP;
    case K_PSNP: return QU_ISIS_PSNP;
    case K_CLNP: return QU_CLNP;
    case K_IPV6: return QU_IPV6;
    case K_ICMPV6: return QU_ICMPV6;
    case K_AH: return QU_AH;
    case K_ESP: return QU_ESP;
    case K_RADIO: return QU_RADIO;
    default: return -1;
    }
}

static int is_aqual(int t)
{
    return t == K_HOST || t == K_NET || t == K_PORT || t == K_PORTRANGE;
}
static int aqual_val(int t)
{
    switch (t) {
    case K_HOST: return QU_HOST;
    case K_NET: return QU_NET;
    case K_PORT: return QU_PORT;
    default: return QU_PORTRANGE;
    }
}
static int is_dqual(int t)
{
    return t == K_SRC || t == K_DST || t == K_ADDR1 || t == K_ADDR2 ||
           t == K_ADDR3 || t == K_ADDR4 || t == K_RA || t == K_TA;
}

/* ------------------------------------------------------------------- ids */

static pblk_t pr_id(P *p, sel_t q);

static pblk_t pr_nid(P *p, sel_t q)
{
    pblk_t r;
    char s1[128];

    r.q = q;
    r.valid = 1;
    switch (tt(p)) {
    case T_ID:
        strcpy(s1, p->lx.tok.str);
        advance(p);
        r.b = id_named(p->cs, s1, q);
        return r;
    case T_HID:
        strcpy(s1, p->lx.tok.str);
        advance(p);
        if (tt(p) == T_SLASH) {
            uint32_t masklen;
            advance(p);
            if (tt(p) != T_NUM) syntax_error(p);
            masklen = p->lx.tok.num;
            advance(p);
            r.b = id_prefix4(p->cs, s1, NULL, masklen, q);
        } else if (tt(p) == K_NETMASK) {
            char s2[128];
            advance(p);
            if (tt(p) != T_HID) syntax_error(p);
            strcpy(s2, p->lx.tok.str);
            advance(p);
            r.b = id_prefix4(p->cs, s1, s2, 0, q);
        } else {
            if (q.addr == QU_PORT)
                fail(p->cs, "'port' modifier applied to ip host");
            else if (q.addr == QU_PORTRANGE)
                fail(p->cs, "'portrange' modifier applied to ip host");
            else if (q.addr == QU_PROTO)
                fail(p->cs, "'proto' modifier applied to ip host");
            else if (q.addr == QU_PROTOCHAIN)
                fail(p->cs, "'protochain' modifier applied to ip host");
            r.b = id_numeric(p->cs, s1, 0, q);
        }
        return r;
    case T_HID6:
        strcpy(s1, p->lx.tok.str);
        advance(p);
        if (tt(p) == T_SLASH) {
            uint32_t masklen;
            advance(p);
            if (tt(p) != T_NUM) syntax_error(p);
            masklen = p->lx.tok.num;
            advance(p);
            r.b = id_prefix6(p->cs, s1, masklen, q);
        } else {
            r.b = id_prefix6(p->cs, s1, 128, q);
        }
        return r;
    case T_EID:
        strcpy(s1, p->lx.tok.str);
        advance(p);
        r.b = id_mac(p->cs, s1, q);
        return r;
    case T_AID:
        strcpy(s1, p->lx.tok.str);
        advance(p);
        r.b = id_arcnet(p->cs, s1, q);
        return r;
    case K_NOT:
    case T_BANG:
        advance(p);
        r = pr_id(p, q);
        r.b = bx_not(r.b);
        return r;
    default:
        syntax_error(p);
    }
    r.valid = 0;
    return r;
}

/* pnum: NUM | '(' pnum ')' */
static int pr_pnum(P *p, uint32_t *out)
{
    if (tt(p) == T_NUM) {
        *out = p->lx.tok.num;
        advance(p);
        return 1;
    }
    if (tt(p) == T_LPAREN) {
        lexer_t save = p->lx;
        advance(p);
        if (pr_pnum(p, out) && tt(p) == T_RPAREN) {
            advance(p);
            return 1;
        }
        p->lx = save;
        return 0;
    }
    return 0;
}

static pblk_t pr_pid(P *p, sel_t q);

static pblk_t pr_id(P *p, sel_t q)
{
    pblk_t r;
    uint32_t v;

    if (tt(p) == T_NUM) {
        v = p->lx.tok.num;
        advance(p);
        if (tt(p) == T_MINUS && q.addr == QU_PORTRANGE) {
            uint32_t v2;
            advance(p);
            if (tt(p) != T_NUM) syntax_error(p);
            v2 = p->lx.tok.num;
            advance(p);
            r.q = q;
            r.valid = 1;
            r.b = id_range(p->cs, v, v2, q);
            return r;
        }
        r.q = q;
        r.valid = 1;
        r.b = id_numeric(p->cs, NULL, v, q);
        return r;
    }
    if (tt(p) == T_LPAREN) {
        advance(p);
        r = pr_pid(p, q);
        expect(p, T_RPAREN);
        return r;
    }
    return pr_nid(p, q);
}

static pblk_t pr_pid(P *p, sel_t q)
{
    pblk_t r, r2;

    r = pr_id(p, q);
    while (tt(p) == K_AND || tt(p) == K_OR) {
        int op = tt(p);
        advance(p);
        r2 = pr_id(p, q);
        if (op == K_AND) r.b = bx_and(p->cs, r.b, r2.b);
        else r.b = bx_or(p->cs, r.b, r2.b);
    }
    return r;
}

/* -------------------------------------------------------- 802.11 tables */

typedef struct { const char *name; int val; } tokval_t;

static const tokval_t ieee80211_types[] = {
    {"mgt", 0x00}, {"ctl", 0x04}, {"data", 0x08}, {NULL, 0}
};
static const tokval_t ieee80211_mgt_subtypes[] = {
    {"assoc-req", 0x00}, {"assoc-resp", 0x10}, {"reassoc-req", 0x20},
    {"reassoc-resp", 0x30}, {"probe-req", 0x40}, {"probe-resp", 0x50},
    {"beacon", 0x80}, {"atim", 0x90}, {"disassoc", 0xa0}, {"auth", 0xb0},
    {"deauth", 0xc0}, {NULL, 0}
};
static const tokval_t ieee80211_ctl_subtypes[] = {
    {"ps-poll", 0xa0}, {"rts", 0xb0}, {"cts", 0xc0}, {"ack", 0xd0},
    {"cf-end", 0xe0}, {"cf-end-ack", 0xf0}, {NULL, 0}
};
static const tokval_t ieee80211_data_subtypes[] = {
    {"data", 0x00}, {"data-cf-ack", 0x10}, {"data-cf-poll", 0x20},
    {"data-cf-ack-poll", 0x30}, {"null", 0x40}, {"cf-ack", 0x50},
    {"cf-poll", 0x60}, {"cf-ack-poll", 0x70}, {"qos-data", 0x80},
    {"qos-data-cf-ack", 0x90}, {"qos-data-cf-poll", 0xa0},
    {"qos-data-cf-ack-poll", 0xb0}, {"qos", 0xc0}, {"qos-cf-poll", 0xe0},
    {"qos-cf-ack-poll", 0xf0}, {NULL, 0}
};
static const tokval_t ieee80211_dirs[] = {
    {"nods", 0x00}, {"tods", 0x01}, {"fromds", 0x02}, {"dstods", 0x03},
    {NULL, 0}
};

static int str2tok(const char *s, const tokval_t *t)
{
    int i;
    for (i = 0; t[i].name; i++)
        if (strcmp(t[i].name, s) == 0)
            return t[i].val;
    return -1;
}

/* ---------------------------------------------------------------- others */

static int tok_is_other(int t)
{
    switch (t) {
    case K_BROADCAST: case K_MULTICAST: case K_LESS: case K_GREATER:
    case K_CBYTE: case K_INBOUND: case K_OUTBOUND: case K_IFINDEX:
    case K_VLAN: case K_MPLS: case K_PPPOED: case K_PPPOES: case K_GENEVE:
    case K_TYPE: case K_SUBTYPE: case K_DIR: case K_LLC:
        return 1;
    default:
        return 0;
    }
}

static test_t pr_other(P *p, int proto)
{
    ctx_t *cs = p->cs;
    uint32_t v, v2;
    int t = tt(p);
    char name[128];

    switch (t) {
    case K_BROADCAST:
        advance(p);
        return bcast_test(cs, proto);
    case K_MULTICAST:
        advance(p);
        return mcast_test(cs, proto);
    case K_LESS:
        advance(p);
        if (tt(p) != T_NUM) syntax_error(p);
        v = p->lx.tok.num;
        advance(p);
        return len_below(cs, v);
    case K_GREATER:
        advance(p);
        if (tt(p) != T_NUM) syntax_error(p);
        v = p->lx.tok.num;
        advance(p);
        return len_above(cs, v);
    case K_CBYTE:
        advance(p);
        if (tt(p) != T_NUM) syntax_error(p);
        v = p->lx.tok.num;
        advance(p);
        {
            int op;
            switch (tt(p)) {
            case T_AMP: op = '&'; break;
            case T_PIPE: op = '|'; break;
            case T_LT: op = '<'; break;
            case T_GT: op = '>'; break;
            case T_EQ: op = '='; break;
            default: syntax_error(p); return always_no(cs);
            }
            advance(p);
            if (tt(p) != T_NUM) syntax_error(p);
            v2 = p->lx.tok.num;
            advance(p);
            return raw_byte_test(cs, op, (int)v, v2);
        }
    case K_INBOUND:
        advance(p);
        return travel_test(cs, 0);
    case K_OUTBOUND:
        advance(p);
        return travel_test(cs, 1);
    case K_IFINDEX:
        advance(p);
        if (tt(p) != T_NUM) syntax_error(p);
        v = p->lx.tok.num;
        advance(p);
        return ifidx_test(cs, (int)v);
    case K_VLAN:
        advance(p);
        if (pr_pnum(p, &v)) return vlan_step(cs, v, 1);
        return vlan_step(cs, 0, 0);
    case K_MPLS:
        advance(p);
        if (pr_pnum(p, &v)) return mpls_step(cs, v, 1);
        return mpls_step(cs, 0, 0);
    case K_PPPOED:
        advance(p);
        return pppoe_disc(cs);
    case K_PPPOES:
        advance(p);
        if (pr_pnum(p, &v)) return pppoe_sess(cs, v, 1);
        return pppoe_sess(cs, 0, 0);
    case K_GENEVE:
        advance(p);
        if (pr_pnum(p, &v)) return geneve_step(cs, v, 1);
        return geneve_step(cs, 0, 0);
    case K_TYPE: {
        int type, sub;
        advance(p);
        if (tt(p) == T_NUM) { type = (int)p->lx.tok.num; advance(p); }
        else if (tt(p) == T_ID) {
            strcpy(name, p->lx.tok.str);
            advance(p);
            type = str2tok(name, ieee80211_types);
            if (type == -1)
                fail(cs, "unknown 802.11 type name \"%s\"", name);
        } else { syntax_error(p); return always_no(cs); }
        if (tt(p) == K_SUBTYPE) {
            advance(p);
            if (tt(p) == T_NUM) { sub = (int)p->lx.tok.num; advance(p); }
            else if (tt(p) == T_ID) {
                const tokval_t *tab;
                strcpy(name, p->lx.tok.str);
                advance(p);
                switch (type) {
                case 0x00: tab = ieee80211_mgt_subtypes; break;
                case 0x04: tab = ieee80211_ctl_subtypes; break;
                default: tab = ieee80211_data_subtypes; break;
                }
                sub = str2tok(name, tab);
                if (sub == -1)
                    fail(cs, "unknown 802.11 subtype name \"%s\"", name);
            } else { syntax_error(p); return always_no(cs); }
            return w80211_type(cs, type | sub, 0x0c | 0xf0);
        }
        return w80211_type(cs, type, 0x0c);
    }
    case K_SUBTYPE: {
        int sub;
        advance(p);
        if (tt(p) == T_NUM) { sub = (int)p->lx.tok.num; advance(p); }
        else if (tt(p) == T_ID) {
            strcpy(name, p->lx.tok.str);
            advance(p);
            sub = str2tok(name, ieee80211_mgt_subtypes);
            if (sub == -1) {
                sub = str2tok(name, ieee80211_ctl_subtypes);
                if (sub != -1) sub |= 0x04;
                else {
                    sub = str2tok(name, ieee80211_data_subtypes);
                    if (sub != -1) sub |= 0x08;
                    else fail(cs, "unknown 802.11 type name");
                }
            }
        } else { syntax_error(p); return always_no(cs); }
        return w80211_type(cs, sub, 0x0c | 0xf0);
    }
    case K_DIR: {
        int d;
        advance(p);
        if (tt(p) == T_NUM) { d = (int)p->lx.tok.num; advance(p); }
        else if (tt(p) == T_ID) {
            strcpy(name, p->lx.tok.str);
            advance(p);
            d = str2tok(name, ieee80211_dirs);
            if (d == -1)
                fail(cs, "unknown 802.11 direction");
        } else { syntax_error(p); return always_no(cs); }
        return w80211_dir(cs, d);
    }
    case K_LLC:
        advance(p);
        if (tt(p) == T_ID) {
            strcpy(name, p->lx.tok.str);
            advance(p);
            if (!strcmp(name, "i")) return llc_info(cs);
            if (!strcmp(name, "s")) return llc_super(cs);
            if (!strcmp(name, "u")) return llc_unnum(cs);
            fail(cs, "unknown LLC type name \"%s\"", name);
        }
        return llc_any(cs);
    }
    syntax_error(p);
    return always_no(cs);
}

/* -------------------------------------------------------------- arth ops */

static int arth_prec(int t)
{
    switch (t) {
    case T_PIPE: case T_CARET: return 1;
    case T_AMP: return 2;
    case T_LSH: case T_RSH: return 3;
    case T_PLUS: case T_MINUS: return 4;
    case T_STAR: case T_DIV: case T_MOD: return 5;
    default: return 0;
    }
}

static int arth_op(int t)
{
    switch (t) {
    case T_PIPE: return BPF_OR;
    case T_CARET: return BPF_XOR;
    case T_AMP: return BPF_AND;
    case T_LSH: return BPF_LSH;
    case T_RSH: return BPF_RSH;
    case T_PLUS: return BPF_ADD;
    case T_MINUS: return BPF_SUB;
    case T_STAR: return BPF_MUL;
    case T_DIV: return BPF_DIV;
    default: return BPF_MOD;
    }
}

/* does a '(' start an arithmetic sub-expression? */
static int paren_is_arth(P *p)
{
    lexer_t save = p->lx;
    int depth = 0;
    int result = 0;

    for (;;) {
        int t = tt(p);
        if (t == T_EOF) break;
        if (t == T_LPAREN) depth++;
        else if (t == T_RPAREN) {
            depth--;
            if (depth == 0) {
                lex_next(&p->lx);
                t = tt(p);
                result = arth_prec(t) != 0 || t == T_EQ || t == T_NE ||
                         t == T_LT || t == T_GT || t == T_LE || t == T_GE;
                break;
            }
        }
        lex_next(&p->lx);
    }
    p->lx = save;
    return result;
}

static val_t *pr_arth_atom(P *p)
{
    ctx_t *cs = p->cs;
    val_t *a;
    int proto;
    uint32_t size;

    switch (tt(p)) {
    case T_NUM:
        a = val_const(cs, p->lx.tok.num);
        advance(p);
        return a;
    case K_LEN:
        advance(p);
        return val_pktlen(cs);
    case T_MINUS:
        advance(p);
        a = pr_arth(p, 6);
        return val_negate(cs, a);
    case T_LPAREN:
        advance(p);
        a = pr_arth(p, 0);
        expect(p, T_RPAREN);
        return a;
    default:
        proto = pname_proto(tt(p));
        if (proto < 0) syntax_error(p);
        advance(p);
        expect(p, T_LBRACK);
        a = pr_arth(p, 0);
        size = 1;
        if (tt(p) == T_COLON) {
            advance(p);
            if (tt(p) != T_NUM) syntax_error(p);
            size = p->lx.tok.num;
            advance(p);
        }
        expect(p, T_RBRACK);
        return val_slice(cs, proto, a, size);
    }
}

static val_t *pr_arth(P *p, int minprec)
{
    val_t *a = pr_arth_atom(p);
    for (;;) {
        int t = tt(p);
        int prec = arth_prec(t);
        if (prec == 0 || prec < minprec) break;
        advance(p);
        {
            val_t *b = pr_arth(p, prec + 1);
            a = val_binop(p->cs, arth_op(t), a, b);
        }
    }
    return a;
}

static int is_relop(int t)
{
    return t == T_EQ || t == T_NE || t == T_LT || t == T_GT ||
           t == T_LE || t == T_GE;
}

static pblk_t pr_arth_rel(P *p)
{
    pblk_t r;
    val_t *a0, *a1;
    int t, code, rev;

    a0 = pr_arth(p, 0);
    t = tt(p);
    if (!is_relop(t)) syntax_error(p);
    advance(p);
    switch (t) {
    case T_GT: code = BPF_JGT; rev = 0; break;
    case T_GE: code = BPF_JGE; rev = 0; break;
    case T_EQ: code = BPF_JEQ; rev = 0; break;
    case T_LE: code = BPF_JGT; rev = 1; break;
    case T_LT: code = BPF_JGE; rev = 1; break;
    default:   code = BPF_JEQ; rev = 1; break;
    }
    a1 = pr_arth(p, 0);
    r.b = val_compare(p->cs, code, a0, a1, rev);
    r.q = qerr;
    r.valid = 1;
    return r;
}

/* ---------------------------------------------------------------- rterm */

static pblk_t pr_rterm(P *p)
{
    ctx_t *cs = p->cs;
    pblk_t r;
    sel_t q;
    int proto = QU_DEFAULT;
    int t = tt(p);

    r.valid = 1;
    r.q = qerr;

    if (t == T_LPAREN) {
        if (paren_is_arth(p))
            return pr_arth_rel(p);
        advance(p);
        r = pr_expr(p);
        expect(p, T_RPAREN);
        return r;
    }

    if (t == T_NUM || t == K_LEN || t == T_MINUS)
        return pr_arth_rel(p);

    if (pname_proto(t) >= 0) {
        lexer_t save = p->lx;
        proto = pname_proto(t);
        advance(p);
        if (tt(p) == T_LBRACK) {
            p->lx = save;
            return pr_arth_rel(p);
        }
        t = tt(p);
    } else {
        proto = QU_DEFAULT;
    }

    if (tok_is_other(t)) {
        r.b = pr_other(p, proto);
        return r;
    }

    q = qdef;
    q.proto = proto;

    if (is_dqual(t)) {
        switch (t) {
        case K_SRC:
            advance(p);
            if (tt(p) == K_OR || tt(p) == K_AND) {
                lexer_t save2 = p->lx;
                int op = tt(p);
                advance(p);
                if (tt(p) == K_DST) {
                    advance(p);
                    q.dir = (op == K_OR) ? QU_OR : QU_AND;
                } else {
                    p->lx = save2;
                    q.dir = QU_SRC;
                }
            } else
                q.dir = QU_SRC;
            break;
        case K_DST:
            advance(p);
            if (tt(p) == K_OR || tt(p) == K_AND) {
                lexer_t save2 = p->lx;
                int op = tt(p);
                advance(p);
                if (tt(p) == K_SRC) {
                    advance(p);
                    q.dir = (op == K_OR) ? QU_OR : QU_AND;
                } else {
                    p->lx = save2;
                    q.dir = QU_DST;
                }
            } else
                q.dir = QU_DST;
            break;
        case K_ADDR1: q.dir = QU_ADDR1; advance(p); break;
        case K_ADDR2: q.dir = QU_ADDR2; advance(p); break;
        case K_ADDR3: q.dir = QU_ADDR3; advance(p); break;
        case K_ADDR4: q.dir = QU_ADDR4; advance(p); break;
        case K_RA: q.dir = QU_RA; advance(p); break;
        default: q.dir = QU_TA; advance(p); break;
        }
        if (is_aqual(tt(p))) {
            q.addr = aqual_val(tt(p));
            advance(p);
        }
        return pr_id(p, q);
    }

    if (is_aqual(t)) {
        q.addr = aqual_val(t);
        advance(p);
        return pr_id(p, q);
    }

    if (t == K_PROTO) {
        q.addr = QU_PROTO;
        advance(p);
        return pr_id(p, q);
    }
    if (t == K_PROTOCHAIN) {
        q.addr = QU_PROTOCHAIN;
        advance(p);
        return pr_id(p, q);
    }
    if (t == K_GATEWAY) {
        q.addr = QU_GATEWAY;
        advance(p);
        return pr_id(p, q);
    }

    if (proto != QU_DEFAULT) {
        r.b = abbrev_test(cs, proto);
        return r;
    }

    syntax_error(p);
    r.valid = 0;
    return r;
}

static pblk_t pr_term(P *p)
{
    pblk_t r;

    if (tt(p) == K_NOT || tt(p) == T_BANG) {
        advance(p);
        r = pr_term(p);
        r.b = bx_not(r.b);
        return r;
    }
    return pr_rterm(p);
}

static pblk_t pr_expr(P *p)
{
    pblk_t r, r2;

    r = pr_term(p);
    for (;;) {
        int t = tt(p);
        if (t == K_AND) {
            advance(p);
            r2 = pr_term(p);
            r.b = bx_and(p->cs, r.b, r2.b);
        } else if (t == K_OR) {
            advance(p);
            r2 = pr_term(p);
            r.b = bx_or(p->cs, r.b, r2.b);
        } else
            break;
        r.q = qerr;
    }
    return r;
}

test_t run_parser(ctx_t *cs, const char *text)
{
    P p;
    pblk_t r;
    test_t none;

    p.cs = cs;
    lex_init(&p.lx, cs, text);

    if (tt(&p) == T_EOF) {
        none.entry = NULL;
        none.t.head = none.t.tail = NULL;
        none.f.head = none.f.tail = NULL;
        return none;
    }
    r = pr_expr(&p);
    if (tt(&p) != T_EOF)
        syntax_error(&p);
    return r.b;
}
