src/lex.o: src/lex.c src/lex.h src/comp.h src/bpf_defs.h
src/lex.h:
src/comp.h:
src/bpf_defs.h:
