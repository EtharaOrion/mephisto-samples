/*
 * driver.c - glue between the JSON case records and the compiler.
 */
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "filter.h"

static ctx_t g_cs;
static int g_init;

int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err)
{
    if (!g_init) {
        arena_init(&g_cs);
        g_init = 1;
    }
    return build_program(&g_cs, c->filter, c->dlt, c->snaplen, c->netmask,
                          c->optimize, out, err);
}

void bpf_prog_init(bpf_prog_t *p)
{
    p->insns = NULL;
    p->len = 0;
    p->cap = 0;
    p->overflow = 0;
}

void bpf_prog_free(bpf_prog_t *p)
{
    free(p->insns);
    p->insns = NULL;
    p->len = p->cap = 0;
}
