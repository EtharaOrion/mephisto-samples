src/driver.o: src/driver.c src/comp.h src/bpf_defs.h src/filter.h \
 src/jsonio.h
src/comp.h:
src/bpf_defs.h:
src/filter.h:
src/jsonio.h:
