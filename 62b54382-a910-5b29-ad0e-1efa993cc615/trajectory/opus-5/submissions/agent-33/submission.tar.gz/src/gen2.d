src/gen2.o: src/gen2.c src/comp.h src/bpf_defs.h src/gen.h src/names.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
src/names.h:
