src/gen3.o: src/gen3.c src/comp.h src/bpf_defs.h src/gen.h src/names.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
src/names.h:
