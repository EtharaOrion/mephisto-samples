src/opt.o: src/opt.c src/comp.h src/bpf_defs.h src/gen.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
