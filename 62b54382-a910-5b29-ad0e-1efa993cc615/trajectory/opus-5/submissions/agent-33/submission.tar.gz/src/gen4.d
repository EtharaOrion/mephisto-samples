src/gen4.o: src/gen4.c src/comp.h src/bpf_defs.h src/gen.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
