src/gen.o: src/gen.c src/comp.h src/bpf_defs.h src/gen.h src/names.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
src/names.h:
