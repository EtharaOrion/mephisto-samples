src/emit.o: src/emit.c src/comp.h src/bpf_defs.h src/gen.h
src/comp.h:
src/bpf_defs.h:
src/gen.h:
