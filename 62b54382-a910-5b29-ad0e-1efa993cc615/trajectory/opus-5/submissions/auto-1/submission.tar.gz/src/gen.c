/*
 * gen.c - block-graph code generation.
 */
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"

/* ------------------------------------------------------------------ arena */

void arena_init(cstate_t *cs)
{
    cs->chunks = NULL;
    cs->cur = NULL;
}

static arena_chunk_t *arena_newchunk(cstate_t *cs, size_t want)
{
    size_t sz = ARENA_CHUNK;
    arena_chunk_t *c;

    while (sz < want) sz *= 2;
    c = (arena_chunk_t *)malloc(sizeof(*c));
    if (!c) abort();
    c->mem = (char *)malloc(sz);
    if (!c->mem) abort();
    c->size = sz;
    c->used = 0;
    c->next = cs->chunks;
    cs->chunks = c;
    return c;
}

void *arena_alloc(cstate_t *cs, size_t n)
{
    arena_chunk_t *c = cs->cur;
    void *p;

    n = (n + 15u) & ~(size_t)15u;
    if (!c || c->used + n > c->size) {
        /* look for room in an existing chunk before making a new one */
        for (c = cs->chunks; c; c = c->next)
            if (c->used + n <= c->size) break;
        if (!c) c = arena_newchunk(cs, n);
        cs->cur = c;
    }
    p = c->mem + c->used;
    c->used += n;
    memset(p, 0, n);
    return p;
}

void arena_reset(cstate_t *cs)
{
    arena_chunk_t *c;
    for (c = cs->chunks; c; c = c->next)
        c->used = 0;
    cs->cur = cs->chunks;
}

void arena_free(cstate_t *cs)
{
    arena_chunk_t *c = cs->chunks, *n;
    while (c) { n = c->next; free(c->mem); free(c); c = n; }
    cs->chunks = NULL;
    cs->cur = NULL;
}

/* ------------------------------------------------------------------ error */

void bpf_error(cstate_t *cs, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(cs->errbuf, sizeof(cs->errbuf), fmt, ap);
    va_end(ap);
    cs->failed = 1;
    longjmp(cs->jmp, 1);
}

/* ------------------------------------------------------- stmts and blocks */

slist_t *new_stmt(cstate_t *cs, uint16_t code)
{
    slist_t *s = (slist_t *)arena_alloc(cs, sizeof(*s));
    s->s.code = code;
    return s;
}

block_t *new_block(cstate_t *cs, uint16_t code)
{
    block_t *b = (block_t *)arena_alloc(cs, sizeof(*b));
    b->s.code = code;
    b->next_free = cs->all_blocks;
    cs->all_blocks = b;
    cs->nblocks++;
    return b;
}

slist_t *sappend(slist_t *s0, slist_t *s1)
{
    slist_t *p = s0;
    if (!s0) return s1;
    while (p->next) p = p->next;
    p->next = s1;
    return s0;
}

/* ------------------------------------------------ boolean expression glue */

bexp_t bx_leaf(block_t *b)
{
    bexp_t e;
    e.entry = b;
    e.tl = b;
    e.fl = b;
    b->tnext = NULL;
    b->fnext = NULL;
    return e;
}

static block_t *tl_concat(block_t *a, block_t *b)
{
    block_t *p;
    if (!a) return b;
    if (!b) return a;
    for (p = a; p->tnext; p = p->tnext) ;
    p->tnext = b;
    return a;
}

static block_t *fl_concat(block_t *a, block_t *b)
{
    block_t *p;
    if (!a) return b;
    if (!b) return a;
    for (p = a; p->fnext; p = p->fnext) ;
    p->fnext = b;
    return a;
}

void bx_patch_t(bexp_t e, block_t *tgt)
{
    block_t *p = e.tl, *n;
    while (p) { n = p->tnext; p->tnext = NULL; JT(p) = tgt; p = n; }
}

void bx_patch_f(bexp_t e, block_t *tgt)
{
    block_t *p = e.fl, *n;
    while (p) { n = p->fnext; p->fnext = NULL; JF(p) = tgt; p = n; }
}

bexp_t bx_and(cstate_t *cs, bexp_t a, bexp_t b)
{
    bexp_t r;
    (void)cs;
    bx_patch_t(a, b.entry);
    r.entry = a.entry;
    r.tl = b.tl;
    r.fl = fl_concat(a.fl, b.fl);
    return r;
}

bexp_t bx_or(cstate_t *cs, bexp_t a, bexp_t b)
{
    bexp_t r;
    (void)cs;
    bx_patch_f(a, b.entry);
    r.entry = a.entry;
    r.tl = tl_concat(a.tl, b.tl);
    r.fl = b.fl;
    return r;
}

bexp_t bx_not(bexp_t a)
{
    bexp_t r;
    r.entry = a.entry;
    r.tl = a.fl;
    r.fl = a.tl;
    return r;
}

/* --------------------------------------------------- register allocation */

int alloc_reg(cstate_t *cs)
{
    int n = cs->curreg;
    int i;

    for (i = 0; i < BPF_MEMWORDS; i++) {
        if (!cs->regused[n]) {
            cs->curreg = n;
            cs->regused[n] = 1;
            return n;
        }
        n = (n + 1) % BPF_MEMWORDS;
    }
    bpf_error(cs, "too many registers needed to evaluate expression");
    return 0;
}

void free_reg(cstate_t *cs, int n)
{
    if (n >= 0 && n < BPF_MEMWORDS)
        cs->regused[n] = 0;
}

/* ------------------------------------------------------- link layer setup */

static void reset_offsets(cstate_t *cs)
{
    cs->off_linkhdr.is_variable = 0;
    cs->off_linkhdr.constant_part = 0;
    cs->off_linkhdr.regid = VR_LINKHDR;
    cs->off_prevlinkhdr = cs->off_linkhdr;
    cs->off_linktype.is_variable = 0;
    cs->off_linktype.constant_part = OFFSET_NOT_SET;
    cs->off_linktype.regid = VR_LINKPL;
    cs->off_linkpl.is_variable = 0;
    cs->off_linkpl.constant_part = 0;
    cs->off_linkpl.regid = VR_LINKPL;
    cs->off_nl = OFFSET_NOT_SET;
    cs->off_nl_nosnap = OFFSET_NOT_SET;
    cs->vreg[VR_LINKHDR] = -1;
    cs->vreg[VR_LINKPL] = -1;
}

void init_linktype(cstate_t *cs)
{
    reset_offsets(cs);
    cs->pcap_fddipad = 0;
    cs->label_stack_depth = 0;
    cs->vlan_stack_depth = 0;
    cs->is_encap = 0;
    cs->is_vlan_vloffset = 0;
    cs->outermostlinktype = cs->linktype;
    cs->prevlinktype = cs->linktype;

    switch (cs->linktype) {

    case DLT_ARCNET:
        cs->off_linktype.constant_part = 2;
        cs->off_linkpl.constant_part = 6;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_EN10MB:
        cs->off_linktype.constant_part = 12;
        cs->off_linkpl.constant_part = 14;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 3;
        break;

    case DLT_SLIP:
        cs->off_linktype.constant_part = OFFSET_NOT_SET;
        cs->off_linkpl.constant_part = 16;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_NULL:
    case DLT_LOOP:
        cs->off_linktype.constant_part = 0;
        cs->off_linkpl.constant_part = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_PPP:
    case DLT_PPP_PPPD:
    case DLT_PPP_SERIAL:
    case DLT_PPP_ETHER:
        cs->off_linktype.constant_part = 2;
        cs->off_linkpl.constant_part = 4;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_RAW:
    case DLT_IPV4:
    case DLT_IPV6:
        cs->off_linktype.constant_part = OFFSET_NOT_SET;
        cs->off_linkpl.constant_part = 0;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_LINUX_SLL:
        cs->off_linktype.constant_part = 14;
        cs->off_linkpl.constant_part = 16;
        cs->off_nl = 0;
        cs->off_nl_nosnap = 0;
        break;

    case DLT_FDDI:
        cs->off_linktype.constant_part = 13;
        cs->off_linktype.constant_part += cs->pcap_fddipad;
        cs->off_linkpl.constant_part = 13;
        cs->off_linkpl.constant_part += cs->pcap_fddipad;
        cs->off_nl = 8;
        cs->off_nl_nosnap = 3;
        break;

    case DLT_IEEE802:
        cs->off_linktype.constant_part = 14;
        cs->off_linkpl.constant_part = 14;
        cs->off_nl = 8;
        cs->off_nl_nosnap = 3;
        break;

    case DLT_IEEE802_11:
    case DLT_PRISM_HEADER:
    case DLT_IEEE802_11_RADIO_AVS:
    case DLT_IEEE802_11_RADIO:
        /*
         * The 802.11 header is variable length; the register slot holds the
         * offset of the LLC header.  The type lives in the SNAP header, six
         * bytes into the LLC header.
         */
        if (cs->linktype != DLT_IEEE802_11)
            cs->off_linkhdr.is_variable = 1;
        cs->off_linktype.is_variable = 1;
        cs->off_linktype.constant_part = 6;
        cs->off_linkpl.is_variable = 1;
        cs->off_linkpl.constant_part = 0;
        cs->off_nl = 8;
        cs->off_nl_nosnap = 3;
        break;

    default:
        cs->off_linktype.constant_part = OFFSET_NOT_SET;
        cs->off_linkpl.constant_part = OFFSET_NOT_SET;
        cs->off_nl = OFFSET_NOT_SET;
        cs->off_nl_nosnap = OFFSET_NOT_SET;
        break;
    }
}

/* ------------------------------------------------------------ load / cmp */

slist_t *gen_abs_offset_varpart(cstate_t *cs, absoff_t *off)
{
    slist_t *s;

    if (!off->is_variable)
        return NULL;
    if (cs->vreg[off->regid] == -1)
        cs->vreg[off->regid] = alloc_reg(cs);
    s = new_stmt(cs, BPF_LDX | BPF_MEM);
    s->s.k = (uint32_t)cs->vreg[off->regid];
    return s;
}

static void check_offset_known(cstate_t *cs, uint32_t off)
{
    if (off == OFFSET_NOT_SET)
        bpf_error(cs, "unknown data link type %d", cs->linktype);
}

static slist_t *gen_load_absoff(cstate_t *cs, absoff_t *base, uint32_t offset,
                                uint32_t size)
{
    slist_t *s, *s2;

    check_offset_known(cs, base->constant_part);
    s = gen_abs_offset_varpart(cs, base);
    if (s) {
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->s.k = base->constant_part + offset;
        sappend(s, s2);
        return s;
    }
    s = new_stmt(cs, BPF_LD | BPF_ABS | size);
    s->s.k = base->constant_part + offset;
    return s;
}

static slist_t *gen_loadx_iphdrlen(cstate_t *cs)
{
    slist_t *s, *s2;

    s = gen_abs_offset_varpart(cs, &cs->off_linkpl);
    if (s) {
        s2 = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
        s2->s.k = cs->off_linkpl.constant_part + cs->off_nl;
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->s.k = 0xf;
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_ALU | BPF_LSH | BPF_K);
        s2->s.k = 2;
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_X);
        sappend(s, s2);
        s2 = new_stmt(cs, BPF_MISC | BPF_TAX);
        sappend(s, s2);
    } else {
        s = new_stmt(cs, BPF_LDX | BPF_MSH | BPF_B);
        s->s.k = cs->off_linkpl.constant_part + cs->off_nl;
    }
    return s;
}

slist_t *gen_load_a(cstate_t *cs, enum offrel rel, uint32_t offset, uint32_t size)
{
    slist_t *s, *s2;

    switch (rel) {
    case OR_PACKET:
        s = new_stmt(cs, BPF_LD | BPF_ABS | size);
        s->s.k = offset;
        break;

    case OR_LINKHDR:
        s = gen_load_absoff(cs, &cs->off_linkhdr, offset, size);
        break;

    case OR_PREVLINKHDR:
        s = gen_load_absoff(cs, &cs->off_prevlinkhdr, offset, size);
        break;

    case OR_LLC:
        s = gen_load_absoff(cs, &cs->off_linkpl, offset, size);
        break;

    case OR_PREVMPLSHDR:
        s = gen_load_absoff(cs, &cs->off_linkpl, offset - 4, size);
        break;

    case OR_LINKPL:
        check_offset_known(cs, cs->off_nl);
        s = gen_load_absoff(cs, &cs->off_linkpl, cs->off_nl + offset, size);
        break;

    case OR_LINKPL_NOSNAP:
        check_offset_known(cs, cs->off_nl_nosnap);
        s = gen_load_absoff(cs, &cs->off_linkpl, cs->off_nl_nosnap + offset, size);
        break;

    case OR_LINKTYPE:
        s = gen_load_absoff(cs, &cs->off_linktype, offset, size);
        break;

    case OR_TRAN_IPV4:
        check_offset_known(cs, cs->off_linkpl.constant_part);
        check_offset_known(cs, cs->off_nl);
        s = gen_loadx_iphdrlen(cs);
        s2 = new_stmt(cs, BPF_LD | BPF_IND | size);
        s2->s.k = cs->off_linkpl.constant_part + cs->off_nl + offset;
        sappend(s, s2);
        break;

    case OR_TRAN_IPV6:
        s = gen_load_a(cs, OR_LINKPL, offset + 40, size);
        break;

    default:
        s = NULL;
        break;
    }
    return s;
}

static bexp_t gen_ncmp(cstate_t *cs, enum offrel rel, uint32_t offset,
                       uint32_t size, uint32_t mask, int jtype, int reverse,
                       uint32_t v)
{
    slist_t *s, *s2;
    block_t *b;

    s = gen_load_a(cs, rel, offset, size);
    if (mask != 0xffffffffU) {
        s2 = new_stmt(cs, BPF_ALU | BPF_AND | BPF_K);
        s2->s.k = mask;
        sappend(s, s2);
    }
    b = new_block(cs, (uint16_t)(BPF_JMP | jtype | BPF_K));
    b->stmts = s;
    b->s.k = v;
    if (reverse && (jtype == BPF_JGT || jtype == BPF_JGE))
        return bx_not(bx_leaf(b));
    return bx_leaf(b);
}

bexp_t gen_cmp(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, rel, off, size, 0xffffffffU, BPF_JEQ, 0, v);
}
bexp_t gen_cmp_gt(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, rel, off, size, 0xffffffffU, BPF_JGT, 0, v);
}
bexp_t gen_cmp_ge(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, rel, off, size, 0xffffffffU, BPF_JGE, 0, v);
}
bexp_t gen_cmp_lt(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, rel, off, size, 0xffffffffU, BPF_JGE, 1, v);
}
bexp_t gen_cmp_le(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size, uint32_t v)
{
    return gen_ncmp(cs, rel, off, size, 0xffffffffU, BPF_JGT, 1, v);
}
bexp_t gen_mcmp(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size,
                uint32_t v, uint32_t mask)
{
    return gen_ncmp(cs, rel, off, size, mask, BPF_JEQ, 0, v);
}

bexp_t gen_bcmp(cstate_t *cs, enum offrel rel, uint32_t off, uint32_t size,
                const uint8_t *v)
{
    bexp_t b, tmp;
    int have = 0;

    b.entry = NULL; b.tl = NULL; b.fl = NULL;
    while (size >= 4) {
        const uint8_t *p = &v[size - 4];
        uint32_t w = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
                     ((uint32_t)p[2] << 8) | p[3];
        tmp = gen_cmp(cs, rel, off + size - 4, BPF_W, w);
        if (have) b = bx_and(cs, b, tmp); else { b = tmp; have = 1; }
        size -= 4;
    }
    while (size >= 2) {
        const uint8_t *p = &v[size - 2];
        uint32_t w = ((uint32_t)p[0] << 8) | p[1];
        tmp = gen_cmp(cs, rel, off + size - 2, BPF_H, w);
        if (have) b = bx_and(cs, b, tmp); else { b = tmp; have = 1; }
        size -= 2;
    }
    if (size > 0) {
        tmp = gen_cmp(cs, rel, off, BPF_B, (uint32_t)v[0]);
        if (have) b = bx_and(cs, b, tmp); else { b = tmp; have = 1; }
    }
    return b;
}

static bexp_t gen_uncond(cstate_t *cs, int rsense)
{
    block_t *b;
    slist_t *s;

    s = new_stmt(cs, BPF_LD | BPF_IMM);
    s->s.k = (uint32_t)!rsense;
    b = new_block(cs, BPF_JMP | BPF_JEQ | BPF_K);
    b->stmts = s;
    b->s.k = 0;
    return bx_leaf(b);
}

bexp_t gen_true(cstate_t *cs)  { return gen_uncond(cs, 1); }
bexp_t gen_false(cstate_t *cs) { return gen_uncond(cs, 0); }

/* --------------------------------------------------------- gen_linktype */

static bexp_t gen_snap(cstate_t *cs, uint32_t orgcode, uint32_t ptype)
{
    uint8_t snapblock[8];

    snapblock[0] = LLCSAP_SNAP;
    snapblock[1] = LLCSAP_SNAP;
    snapblock[2] = 0x03;
    snapblock[3] = (uint8_t)(orgcode >> 16);
    snapblock[4] = (uint8_t)(orgcode >> 8);
    snapblock[5] = (uint8_t)(orgcode >> 0);
    snapblock[6] = (uint8_t)(ptype >> 8);
    snapblock[7] = (uint8_t)(ptype >> 0);
    return gen_bcmp(cs, OR_LLC, 0, 8, snapblock);
}

static bexp_t gen_llc_linktype(cstate_t *cs, uint32_t ll_proto)
{
    /*
     * Are we checking for a SAP value or an ethertype in a SNAP header?
     */
    switch (ll_proto) {

    case LLCSAP_IP:
    case LLCSAP_ISONS:
    case LLCSAP_NETBEUI:
        return gen_cmp(cs, OR_LLC, 0, BPF_H,
                       (ll_proto << 8) | ll_proto);

    case LLCSAP_IPX:
        return gen_cmp(cs, OR_LLC, 0, BPF_B, LLCSAP_IPX);

    case ETHERTYPE_ATALK:
        return gen_snap(cs, 0x080007, ETHERTYPE_ATALK);

    default:
        if (ll_proto <= ETHERMTU)
            return gen_cmp(cs, OR_LLC, 0, BPF_B, ll_proto);
        return gen_snap(cs, 0x000000, ll_proto);
    }
}

static bexp_t gen_ether_linktype(cstate_t *cs, uint32_t ll_proto)
{
    bexp_t b0, b1;

    switch (ll_proto) {

    case LLCSAP_ISONS:
    case LLCSAP_IP:
    case LLCSAP_NETBEUI:
        /* 802.2 encapsulation with a known SAP */
        b0 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
        b0 = bx_not(b0);
        b1 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_H, (ll_proto << 8) | ll_proto);
        return bx_and(cs, b0, b1);

    case LLCSAP_IPX:
        /*
         * Check for the IPX-specific encapsulations: raw 802.3 (0xFFFF),
         * LLC with the IPX SAP, or an Ethernet type of ETHERTYPE_IPX.
         */
        b0 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, LLCSAP_IPX);
        b1 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_H, 0xFFFF);
        b0 = bx_or(cs, b1, b0);
        b1 = gen_snap(cs, 0x000000, ETHERTYPE_IPX);
        b0 = bx_or(cs, b0, b1);
        b1 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
        b1 = bx_not(b1);
        b0 = bx_and(cs, b1, b0);
        b1 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ETHERTYPE_IPX);
        return bx_or(cs, b1, b0);

    case ETHERTYPE_ATALK:
    case ETHERTYPE_AARP:
        /* may be 802.2 SNAP encapsulated */
        b0 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
        b0 = bx_not(b0);
        if (ll_proto == ETHERTYPE_ATALK)
            b1 = gen_snap(cs, 0x080007, ETHERTYPE_ATALK);
        else
            b1 = gen_snap(cs, 0x000000, ETHERTYPE_AARP);
        b1 = bx_and(cs, b0, b1);
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
        return bx_or(cs, b0, b1);

    default:
        if (ll_proto <= ETHERMTU) {
            b0 = gen_cmp_gt(cs, OR_LINKTYPE, 0, BPF_H, ETHERMTU);
            b0 = bx_not(b0);
            b1 = gen_cmp(cs, OR_LINKTYPE, 2, BPF_B, ll_proto);
            return bx_and(cs, b0, b1);
        }
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
    }
}

static bexp_t gen_loopback_linktype(cstate_t *cs, uint32_t ll_proto)
{
    switch (ll_proto) {

    case ETHERTYPE_IP:
        return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, 2);

    case ETHERTYPE_IPV6:
        return gen_cmp(cs, OR_LINKHDR, 0, BPF_W, 10U << 24);

    default:
        return gen_false(cs);
    }
}

static uint32_t ethertype_to_ppptype(uint32_t proto)
{
    switch (proto) {
    case ETHERTYPE_IP:    return PPP_IP;
    case ETHERTYPE_IPV6:  return PPP_IPV6;
    case ETHERTYPE_DN:    return PPP_DECNET;
    case ETHERTYPE_ATALK: return PPP_APPLE;
    case ETHERTYPE_NS:    return PPP_NS;
    case LLCSAP_ISONS:    return PPP_OSI;
    case ETHERTYPE_IPX:   return PPP_IPX;
    case ETHERTYPE_MPLS:  return PPP_MPLS_UCAST;
    case ETHERTYPE_MPLS_MULTI: return PPP_MPLS_MCAST;
    case LLCSAP_8021D:    return PPP_IPCP; /* not really; unused */
    default:              return proto;
    }
}

static bexp_t gen_linux_sll_linktype(cstate_t *cs, uint32_t ll_proto)
{
    bexp_t b0, b1;

    switch (ll_proto) {

    case LLCSAP_IP:
    case LLCSAP_ISONS:
    case LLCSAP_NETBEUI:
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
        b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_H, (ll_proto << 8) | ll_proto);
        return bx_and(cs, b0, b1);

    case LLCSAP_IPX:
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_3);
        b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, LLCSAP_IPX);
        b0 = bx_or(cs, b0, b1);
        b1 = gen_snap(cs, 0x000000, ETHERTYPE_IPX);
        b0 = bx_or(cs, b0, b1);
        b1 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
        b0 = bx_and(cs, b1, b0);
        b1 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ETHERTYPE_IPX);
        return bx_or(cs, b1, b0);

    case ETHERTYPE_ATALK:
    case ETHERTYPE_AARP:
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
        if (ll_proto == ETHERTYPE_ATALK)
            b1 = gen_snap(cs, 0x080007, ETHERTYPE_ATALK);
        else
            b1 = gen_snap(cs, 0x000000, ETHERTYPE_AARP);
        b1 = bx_and(cs, b0, b1);
        b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
        return bx_or(cs, b0, b1);

    default:
        if (ll_proto <= ETHERMTU) {
            b0 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, LINUX_SLL_P_802_2);
            b1 = gen_cmp(cs, OR_LINKPL, 0, BPF_B, ll_proto);
            return bx_and(cs, b0, b1);
        }
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
    }
}

/*
 * Check that this is a data frame: the 0x08 bit of the frame control field
 * set and the 0x04 bit clear.
 */
static bexp_t gen_check_802_11_data_frame(cstate_t *cs)
{
    slist_t *s;
    block_t *b0, *b1;
    bexp_t e0, e1;

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b0 = new_block(cs, BPF_JMP | BPF_JSET | BPF_K);
    b0->s.k = 0x04;
    b0->stmts = s;
    e0 = bx_not(bx_leaf(b0));

    s = gen_load_a(cs, OR_LINKHDR, 0, BPF_B);
    b1 = new_block(cs, BPF_JMP | BPF_JSET | BPF_K);
    b1->s.k = 0x08;
    b1->stmts = s;
    e1 = bx_leaf(b1);

    return bx_and(cs, e0, e1);
}

/*
 * Statement list computing the length of a variable-length 802.11 header.
 * The link-layer header offset is expected in X on entry.
 */
static slist_t *gen_load_802_11_header_len(cstate_t *cs, slist_t *s)
{
    slist_t *s2, *sjset_data, *sjset_not_data, *sjset_qos, *snext;

    s2 = new_stmt(cs, BPF_MISC | BPF_TXA);
    sappend(s, s2);
    s2 = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s2->s.k = 24;
    sappend(s, s2);
    s2 = new_stmt(cs, BPF_ST);
    s2->s.k = (uint32_t)cs->vreg[VR_LINKPL];
    sappend(s, s2);

    s2 = new_stmt(cs, BPF_LD | BPF_IND | BPF_B);
    s2->s.k = 0;
    sappend(s, s2);

    sjset_data = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    sjset_data->s.k = 0x08;
    sappend(s, sjset_data);

    sjset_not_data = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    sjset_not_data->s.k = 0x04;
    sappend(s, sjset_not_data);

    sjset_qos = new_stmt(cs, BPF_JMP | BPF_JSET | BPF_K);
    sjset_qos->s.k = 0x80;
    sappend(s, sjset_qos);

    s2 = new_stmt(cs, BPF_LD | BPF_MEM);
    s2->s.k = (uint32_t)cs->vreg[VR_LINKPL];
    sappend(s, s2);
    s2 = new_stmt(cs, BPF_ALU | BPF_ADD | BPF_K);
    s2->s.k = 2;
    sappend(s, s2);
    s2 = new_stmt(cs, BPF_ST);
    s2->s.k = (uint32_t)cs->vreg[VR_LINKPL];
    sappend(s, s2);

    snext = new_stmt(cs, NOP_CODE);
    sappend(s, snext);

    sjset_data->s.jt = sjset_not_data;
    sjset_data->s.jf = snext;
    sjset_not_data->s.jt = snext;
    sjset_not_data->s.jf = sjset_qos;
    sjset_qos->s.jt = NULL;      /* fall through */
    sjset_qos->s.jf = snext;

    return s;
}

void insert_compute_vloffsets(cstate_t *cs, block_t *b)
{
    slist_t *s;

    if (cs->vreg[VR_LINKPL] == -1 && cs->vreg[VR_LINKHDR] == -1)
        return;

    if (cs->vreg[VR_LINKPL] != -1) {
        switch (cs->linktype) {
        case DLT_IEEE802_11:
        case DLT_PRISM_HEADER:
        case DLT_IEEE802_11_RADIO_AVS:
        case DLT_IEEE802_11_RADIO:
            if (cs->off_linkhdr.is_variable) {
                s = new_stmt(cs, BPF_LDX | BPF_MEM);
                s->s.k = (uint32_t)cs->vreg[VR_LINKHDR];
            } else {
                s = new_stmt(cs, BPF_LDX | BPF_IMM);
                s->s.k = cs->off_linkhdr.constant_part;
            }
            s = gen_load_802_11_header_len(cs, s);
            sappend(s, b->stmts);
            b->stmts = s;
            break;
        default:
            break;
        }
    }
}

static bexp_t gen_prevlinkhdr_check(cstate_t *cs)
{
    if (cs->is_encap)
        return gen_cmp(cs, OR_PREVLINKHDR, 0, BPF_W, 0);
    return gen_true(cs);
}

bexp_t gen_linktype(cstate_t *cs, uint32_t ll_proto)
{
    bexp_t b0, b1, b2;

    /* are we inside an encapsulation? */
    switch (cs->linktype) {

    case DLT_EN10MB:
        switch (ll_proto) {
        case LLCSAP_ISONS:
        case LLCSAP_IP:
        case LLCSAP_NETBEUI:
        case LLCSAP_IPX:
        case ETHERTYPE_ATALK:
        case ETHERTYPE_AARP:
        default:
            break;
        }
        return gen_ether_linktype(cs, ll_proto);

    case DLT_C_HDLC:
        switch (ll_proto) {
        case LLCSAP_ISONS:
            ll_proto = (ll_proto << 8 | LLCSAP_ISONS);
            /* fall through */
        default:
            return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
        }

    case DLT_IEEE802_11:
    case DLT_PRISM_HEADER:
    case DLT_IEEE802_11_RADIO_AVS:
    case DLT_IEEE802_11_RADIO:
        /*
         * Check that we have a data frame, then pull the type out of what
         * we assume is a SNAP header.
         */
        b0 = gen_check_802_11_data_frame(cs);
        b1 = gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
        return bx_and(cs, b0, b1);

    case DLT_FDDI:
    case DLT_IEEE802:
    case DLT_ATM_RFC1483:
    case DLT_ATM_CLIP:
    case DLT_IP_OVER_FC:
        return gen_llc_linktype(cs, ll_proto);

    case DLT_LINUX_SLL:
        return gen_linux_sll_linktype(cs, ll_proto);

    case DLT_SLIP:
    case DLT_SLIP_BSDOS:
    case DLT_RAW:
        if (ll_proto == ETHERTYPE_IP)
            return gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0x40, 0xF0);
        if (ll_proto == ETHERTYPE_IPV6)
            return gen_mcmp(cs, OR_LINKHDR, 0, BPF_B, 0x60, 0xF0);
        return gen_false(cs);

    case DLT_IPV4:
        if (ll_proto == ETHERTYPE_IP)
            return gen_true(cs);
        return gen_false(cs);

    case DLT_IPV6:
        if (ll_proto == ETHERTYPE_IPV6)
            return gen_true(cs);
        return gen_false(cs);

    case DLT_PPP:
    case DLT_PPP_PPPD:
    case DLT_PPP_SERIAL:
    case DLT_PPP_ETHER:
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H,
                       ethertype_to_ppptype(ll_proto));

    case DLT_NULL:
    case DLT_LOOP:
    case DLT_ENC:
        return gen_loopback_linktype(cs, ll_proto);

    case DLT_ARCNET:
        return gen_false(cs);

    default:
        if (cs->off_linktype.constant_part == OFFSET_NOT_SET)
            bpf_error(cs, "unknown data link type %d", cs->linktype);
        return gen_cmp(cs, OR_LINKTYPE, 0, BPF_H, ll_proto);
    }
    (void)b0; (void)b1; (void)b2;
}
