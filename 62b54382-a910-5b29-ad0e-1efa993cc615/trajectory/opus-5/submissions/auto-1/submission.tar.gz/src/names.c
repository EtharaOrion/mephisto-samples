/*
 * names.c - name resolution against the pinned tables.
 *
 * The tables are compiled in from tables_gen.h, which is generated offline
 * from the files under etc/.
 */
#include <string.h>
#include <strings.h>

#include "names.h"
#include "tables_gen.h"

#define NELEM(a) (sizeof(a) / sizeof((a)[0]))

int nm_proto(const char *name, int *val)
{
    size_t i;
    for (i = 0; i < NELEM(proto_tab); i++) {
        if (strcmp(proto_tab[i].name, name) == 0) {
            *val = proto_tab[i].val;
            return 1;
        }
    }
    return 0;
}

int nm_service(const char *name, const char *proto, int *port)
{
    size_t i;
    for (i = 0; i < NELEM(serv_tab); i++) {
        if (strcmp(serv_tab[i].name, name) == 0 &&
            (proto == NULL || strcmp(serv_tab[i].proto, proto) == 0)) {
            *port = serv_tab[i].port;
            return 1;
        }
    }
    return 0;
}

int nm_network(const char *name, uint32_t *val)
{
    size_t i;
    for (i = 0; i < NELEM(net_tab); i++) {
        if (strcmp(net_tab[i].name, name) == 0) {
            *val = (uint32_t)net_tab[i].val;
            return 1;
        }
    }
    return 0;
}

int nm_host(const char *name, nm_addr_t *out, int max)
{
    size_t i;
    int n = 0;
    for (i = 0; i < NELEM(host_tab) && n < max; i++) {
        if (strcmp(host_tab[i].name, name) == 0) {
            out[n].af = host_tab[i].af;
            memcpy(out[n].a, host_tab[i].a, 16);
            n++;
        }
    }
    return n;
}

int nm_ether(const char *name, unsigned char *out)
{
    (void)name;
    (void)out;
    return 0;   /* the pinned ethers table is empty */
}
