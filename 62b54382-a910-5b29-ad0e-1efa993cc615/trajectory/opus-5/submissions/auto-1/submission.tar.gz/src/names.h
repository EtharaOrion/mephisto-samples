#ifndef NAMES_H
#define NAMES_H

#include <stdint.h>

int nm_proto(const char *name, int *val);         /* /etc/protocols */
int nm_service(const char *name, const char *proto, int *port);
int nm_network(const char *name, uint32_t *val);
/* host lookup: fills up to n entries, returns count. af is 4 or 6 */
typedef struct { int af; unsigned char a[16]; } nm_addr_t;
int nm_host(const char *name, nm_addr_t *out, int max);
int nm_ether(const char *name, unsigned char *out);

#endif
