/*
 * gen4.c - 802.11 frame filters, LLC filters and protocol chains.
 */
#include <string.h>

#include "comp.h"
#include "gen.h"

static void need_w80211(ctx_t *cs)
{
    switch (cs->link) {
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        return;
    default:
        fail(cs, "802.11 link-layer types supported only on 802.11");
    }
}

test_t w80211_type(ctx_t *cs, int type, int mask)
{
    need_w80211(cs);
    return wcmp_mask(cs, B_HDR, 0, BPF_B, (uint32_t)type, (uint32_t)mask);
}

test_t w80211_dir(ctx_t *cs, int fcdir)
{
    switch (cs->link) {
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        break;
    default:
        fail(cs, "frame direction supported only with 802.11 headers");
    }
    return wcmp_mask(cs, B_HDR, 1, BPF_B, (uint32_t)fcdir, 0x03);
}

/* ------------------------------------------------------------------ llc */

static void need_llc(ctx_t *cs)
{
    switch (cs->link) {
    case LNK_EN10MB:
    case LNK_IEEE802:
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
    case LNK_FDDI:
    case LNK_ATM_RFC1483:
    case LNK_SUNATM:
        return;
    default:
        fail(cs, "'llc' not supported for %d", cs->link);
    }
}

test_t llc_any(ctx_t *cs)
{
    test_t b0, b1;

    need_llc(cs);
    b0 = wcmp_gt(cs, B_TYPE, 0, BPF_H, MAX_LEN_FIELD);
    b0 = bx_not(b0);
    b1 = wcmp_eq(cs, B_LLC, 0, BPF_H, 0xFFFF);
    b1 = bx_not(b1);
    return bx_and(cs, b0, b1);
}

test_t llc_info(ctx_t *cs)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, 0, 0x01);
    return bx_and(cs, b0, b1);
}

test_t llc_super(ctx_t *cs)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, 0x01, 0x03);
    return bx_and(cs, b0, b1);
}

test_t llc_unnum(ctx_t *cs)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, 0x03, 0x03);
    return bx_and(cs, b0, b1);
}

test_t llc_super_sub(ctx_t *cs, uint32_t subtype)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, subtype, 0x0f);
    return bx_and(cs, b0, b1);
}

test_t llc_unnum_sub(ctx_t *cs, uint32_t subtype)
{
    test_t b0, b1;

    b0 = llc_any(cs);
    b1 = wcmp_mask(cs, B_LLC, 2, BPF_B, subtype, 0xef);
    return bx_and(cs, b0, b1);
}

/* ----------------------------------------------------------- protochain */

test_t chain_test(ctx_t *cs, uint32_t v, int proto)
{
    op_t *st[48];
    node_t *blk;
    test_t b0;
    uint32_t off;
    int n = 0, again, hbh = 0, ahchk, end, i;
    int reg;
    int v6;

    switch (proto) {
    case QU_IP:
        v6 = 0;
        break;
    case QU_IPV6:
        v6 = 1;
        break;
    case QU_DEFAULT: {
        test_t t4 = chain_test(cs, v, QU_IP);
        test_t t6 = chain_test(cs, v, QU_IPV6);
        return bx_or(cs, t4, t6);
    }
    default:
        fail(cs, "bad protocol applied for 'protochain'");
        return always_no(cs);
    }

    if (cs->pay_at.dynamic)
        fail(cs, "'protochain' not supported with variable length headers");

    reg = mem_take(cs);
    off = cs->pay_at.fixed + cs->nl_skip;
    b0 = ll_type_test(cs, v6 ? TY_IP6 : TY_IP4);

    /* the loop below jumps backwards, which the refinement pass cannot
     * follow */
    cs->skip_refine = 1;

#define PUT(c) (st[n] = op_new(cs, (uint16_t)(c)), n++)
    if (v6) {
        PUT(BPF_LD | BPF_ABS | BPF_B); st[n-1]->s.k = off + 6;
        PUT(BPF_LDX | BPF_IMM);        st[n-1]->s.k = 40;
    } else {
        PUT(BPF_LD | BPF_ABS | BPF_B); st[n-1]->s.k = off + 9;
        PUT(BPF_LDX | BPF_MSH | BPF_B); st[n-1]->s.k = off;
    }
    again = n;
    PUT(BPF_JMP | BPF_JEQ | BPF_K); st[n-1]->s.k = v;          /* -> end */
    PUT(BPF_JMP | BPF_JEQ | BPF_K); st[n-1]->s.k = NP_NONE;    /* -> end */
    if (v6) {
        PUT(BPF_JMP | BPF_JEQ | BPF_K); st[n-1]->s.k = NP_HOP;
        PUT(BPF_JMP | BPF_JEQ | BPF_K); st[n-1]->s.k = NP_DSTOPT;
        PUT(BPF_JMP | BPF_JEQ | BPF_K); st[n-1]->s.k = NP_ROUTE;
        PUT(BPF_JMP | BPF_JEQ | BPF_K); st[n-1]->s.k = NP_FRAG;
        hbh = n;
        PUT(BPF_LD | BPF_IND | BPF_B); st[n-1]->s.k = off;
        PUT(BPF_ST);                   st[n-1]->s.k = (uint32_t)reg;
        PUT(BPF_LD | BPF_IND | BPF_B); st[n-1]->s.k = off + 1;
        PUT(BPF_ALU | BPF_ADD | BPF_K); st[n-1]->s.k = 1;
        PUT(BPF_ALU | BPF_MUL | BPF_K); st[n-1]->s.k = 8;
        PUT(BPF_ALU | BPF_ADD | BPF_X);
        PUT(BPF_MISC | BPF_TAX);
        PUT(BPF_LD | BPF_MEM);         st[n-1]->s.k = (uint32_t)reg;
        PUT(BPF_JMP | BPF_JA);         st[n-1]->s.k = (uint32_t)(again - n);
    } else {
        PUT(BPF_ALU | BPF_ADD | BPF_K); st[n-1]->s.k = 0;
    }
    ahchk = n;
    PUT(BPF_JMP | BPF_JEQ | BPF_K); st[n-1]->s.k = NP_AH;      /* fail -> end */
    PUT(BPF_MISC | BPF_TXA);
    PUT(BPF_LD | BPF_IND | BPF_B); st[n-1]->s.k = off;
    PUT(BPF_ST);                   st[n-1]->s.k = (uint32_t)reg;
    PUT(BPF_MISC | BPF_TXA);
    PUT(BPF_ALU | BPF_ADD | BPF_K); st[n-1]->s.k = 1;
    PUT(BPF_MISC | BPF_TAX);
    PUT(BPF_LD | BPF_IND | BPF_B); st[n-1]->s.k = off;
    PUT(BPF_ALU | BPF_ADD | BPF_K); st[n-1]->s.k = 2;
    PUT(BPF_ALU | BPF_MUL | BPF_K); st[n-1]->s.k = 4;
    PUT(BPF_MISC | BPF_TAX);
    PUT(BPF_LD | BPF_MEM);         st[n-1]->s.k = (uint32_t)reg;
    PUT(BPF_JMP | BPF_JA);         st[n-1]->s.k = (uint32_t)(again - n);
    end = n;
    PUT(BPF_ALU | BPF_ADD | BPF_K); st[n-1]->s.k = 0;
#undef PUT

    for (i = 0; i < n - 1; i++)
        st[i]->next = st[i + 1];
    st[n - 1]->next = NULL;

    st[again]->s.jt = st[end];
    st[again + 1]->s.jt = st[end];
    if (v6) {
        st[again + 2]->s.jt = st[hbh];
        st[again + 3]->s.jt = st[hbh];
        st[again + 4]->s.jt = st[hbh];
        st[again + 5]->s.jt = st[hbh];
        st[again + 5]->s.jf = st[ahchk];
    }
    st[ahchk]->s.jf = st[end];

    blk = blk_new(cs, BPF_JMP | BPF_JEQ | BPF_K);
    blk->s.k = v;
    blk->stmts = st[0];
    mem_drop(cs, reg);
    return bx_and(cs, b0, bx_leaf_cs(cs, blk));
}

/*
 * Geneve: a UDP tunnel on port 6081.  Both IP versions are accepted, and
 * the offsets of the encapsulated frame are worked out at run time.
 */
static test_t always_taken(ctx_t *cs, op_t *s)
{
    node_t *b = blk_new(cs, BPF_JMP | BPF_JEQ | BPF_X);
    b->stmts = s;
    b->s.k = 0;
    return bx_leaf_cs(cs, b);
}

test_t geneve_step(ctx_t *cs, uint32_t vni, int has_vni)
{
    test_t b4, b6, t;
    op_t *s, *s2, *first, *jmp, *land;
    node_t *tail;
    uint32_t off;
    int rtype, rtmp, rpl;

    /* IPv4 side */
    b4 = ll_type_test(cs, TY_IP4);
    t = wcmp_eq(cs, B_PL, 9, BPF_B, NP_UDP);
    b4 = bx_and(cs, b4, t);
    t = unfragmented(cs);
    b4 = bx_and(cs, b4, t);
    t = wcmp_eq(cs, B_TP4, 2, BPF_H, 6081);
    b4 = bx_and(cs, b4, t);
    if (has_vni) {
        t = wcmp_mask(cs, B_TP4, 12, BPF_W, vni << 8, 0xffffff00U);
        b4 = bx_and(cs, b4, t);
    }
    t = wcmp_mask(cs, B_TP4, 8, BPF_B, 0, 0xc0);
    b4 = bx_and(cs, b4, t);
    s = v4hlen_to_x_ext(cs);
    op_cat(s, op_new(cs, BPF_MISC | BPF_TXA));
    b4 = bx_and(cs, b4, always_taken(cs, s));

    /* IPv6 side */
    b6 = ll_type_test(cs, TY_IP6);
    t = wcmp_eq(cs, B_PL, 6, BPF_B, NP_UDP);
    b6 = bx_and(cs, b6, t);
    t = wcmp_eq(cs, B_TP6, 2, BPF_H, 6081);
    b6 = bx_and(cs, b6, t);
    if (has_vni) {
        t = wcmp_mask(cs, B_TP6, 12, BPF_W, vni << 8, 0xffffff00U);
        b6 = bx_and(cs, b6, t);
    }
    t = wcmp_mask(cs, B_TP6, 8, BPF_B, 0, 0xc0);
    b6 = bx_and(cs, b6, t);
    s = base_to_x(cs, &cs->pay_at);
    s2 = op_new(cs, BPF_LD | BPF_IMM);
    s2->s.k = 40;
    if (s) {
        op_cat(s, s2);
        op_cat(s, op_new(cs, BPF_ALU | BPF_ADD | BPF_X));
    } else
        s = s2;
    op_cat(s, op_new(cs, BPF_MISC | BPF_TAX));
    b6 = bx_and(cs, b6, always_taken(cs, s));

    b4 = bx_or(cs, b4, b6);

    rtype = mem_take(cs);
    rtmp = mem_take(cs);
    rpl = mem_take(cs);
    off = cs->pay_at.fixed + cs->nl_skip + 8;

    first = op_new(cs, BPF_ALU | BPF_ADD | BPF_K);
    first->s.k = off;
    s = first;
    op_cat(s, op_new(cs, BPF_MISC | BPF_TAX));
    s2 = op_new(cs, BPF_ALU | BPF_ADD | BPF_K); s2->s.k = 2; op_cat(s, s2);
    s2 = op_new(cs, BPF_ST); s2->s.k = (uint32_t)rtype; op_cat(s, s2);
    s2 = op_new(cs, BPF_LD | BPF_IND | BPF_B); s2->s.k = 0; op_cat(s, s2);
    s2 = op_new(cs, BPF_ALU | BPF_AND | BPF_K); s2->s.k = 0x3f; op_cat(s, s2);
    s2 = op_new(cs, BPF_ALU | BPF_MUL | BPF_K); s2->s.k = 4; op_cat(s, s2);
    s2 = op_new(cs, BPF_ALU | BPF_ADD | BPF_K); s2->s.k = 8; op_cat(s, s2);
    op_cat(s, op_new(cs, BPF_ALU | BPF_ADD | BPF_X));
    s2 = op_new(cs, BPF_ST); s2->s.k = (uint32_t)rtmp; op_cat(s, s2);
    s2 = op_new(cs, BPF_LD | BPF_IND | BPF_H); s2->s.k = 2; op_cat(s, s2);
    s2 = op_new(cs, BPF_LDX | BPF_MEM); s2->s.k = (uint32_t)rtmp; op_cat(s, s2);
    jmp = op_new(cs, BPF_JMP | BPF_JEQ | BPF_K);
    jmp->s.k = TY_TEB;
    op_cat(s, jmp);
    op_cat(s, op_new(cs, BPF_MISC | BPF_TXA));
    s2 = op_new(cs, BPF_ALU | BPF_ADD | BPF_K); s2->s.k = 12; op_cat(s, s2);
    s2 = op_new(cs, BPF_ST); s2->s.k = (uint32_t)rtype; op_cat(s, s2);
    s2 = op_new(cs, BPF_ALU | BPF_ADD | BPF_K); s2->s.k = 2; op_cat(s, s2);
    op_cat(s, op_new(cs, BPF_MISC | BPF_TAX));
    land = op_new(cs, BPF_STX); land->s.k = (uint32_t)rpl;
    op_cat(s, land);
    s2 = op_new(cs, BPF_LD | BPF_IMM); s2->s.k = 0; op_cat(s, s2);
    jmp->s.jf = land;

    tail = blk_new(cs, BPF_JMP | BPF_JEQ | BPF_K);
    tail->s.k = 0;
    tail->stmts = first;

    b4 = bx_and(cs, b4, bx_leaf_cs(cs, tail));

    cs->vreg[VR_TYPE] = rtype;
    cs->vreg[VR_LINKPL] = rpl;
    cs->type_at.dynamic = 1;
    cs->type_at.fixed = 0;
    cs->type_at.regid = VR_TYPE;
    cs->pay_at.dynamic = 1;
    cs->pay_at.fixed = 0;
    cs->pay_at.regid = VR_LINKPL;
    cs->nl_skip = 0;
    cs->raw_skip = 0;
    cs->nested = 1;
    cs->skip_refine = 1;
    return b4;
}

test_t atm_abbrev(ctx_t *cs, int type)
{
    (void)type;
    fail(cs, "ATM type filtering not supported");
    return always_no(cs);
}
