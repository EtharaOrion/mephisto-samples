/*
 * comp.h - shared types for the filter compiler.
 *
 * The compiler builds a graph of basic blocks (each a statement list plus a
 * terminating conditional branch), then flattens it into cBPF.
 */
#ifndef COMP_H
#define COMP_H

#include <setjmp.h>
#include <stdint.h>
#include <stddef.h>

#include "bpf_defs.h"

#define OFFSET_NOT_SET 0xffffffffU

#define QU_UNDEF 255

/* qualifier codes: protocol */
enum {
    QU_DEFAULT = 0, QU_LINK, QU_IP, QU_ARP, QU_RARP, QU_SCTP, QU_TCP, QU_UDP,
    QU_ICMP, QU_IGMP, QU_IGRP, QU_ATALK, QU_DECNET, QU_LAT, QU_SCA, QU_MOPRC, QU_MOPDL,
    QU_IPV6, QU_ICMPV6, QU_AH, QU_ESP, QU_PIM, QU_VRRP, QU_AARP, QU_ISO, QU_ESIS,
    QU_ISIS, QU_CLNP, QU_STP, QU_IPX, QU_NETBEUI,
    QU_ISIS_L1, QU_ISIS_L2, QU_ISIS_IIH, QU_ISIS_SNP, QU_ISIS_CSNP, QU_ISIS_PSNP,
    QU_ISIS_LSP, QU_RADIO, QU_CARP
};

/* direction / address qualifiers */
enum {
    QU_HOST = 1, QU_NET, QU_PORT, QU_GATEWAY, QU_PROTO, QU_PROTOCHAIN, QU_PORTRANGE
};
enum {
    QU_SRC = 1, QU_DST, QU_OR, QU_AND, QU_ADDR1, QU_ADDR2, QU_ADDR3, QU_ADDR4,
    QU_RA, QU_TA
};

/* q triple packed */
typedef struct { int proto, dir, addr; } sel_t;

struct slist_s;

typedef struct stmt_s {
    uint16_t        code;
    uint32_t        k;
    struct slist_s *jt, *jf;   /* only for jumps inside a statement list */
} ins_t;

typedef struct slist_s {
    ins_t          s;
    struct slist_s *next;
} op_t;

#define NOP_CODE 0xffff

struct block_s;

typedef struct edge_s {
    int              id;
    int              code;
    uint32_t         pred_val;
    struct block_s  *succ;
    struct block_s  *pred;
    struct edge_s   *next;   /* in-edge chain of succ */
    uint32_t        *edom;
} arc_t;

#define N_ATOMS (BPF_MEMWORDS + 2)

typedef struct block_s {
    int         id;
    op_t    *stmts;
    ins_t      s;
    int         mark;
    int         longjt, longjf;
    int         level;
    int         offset;
    arc_t      et, ef;
    struct block_s *link;      /* level chain */
    /* unresolved-exit threading (front end) */
    struct block_s *tnext, *fnext;
    /* optimizer scratch */
    uint32_t   *dom, *closure;
    arc_t     *in_edges;
    uint32_t    val[N_ATOMS];
    uint32_t    oval;
    unsigned long out_use, in_use, def, kill, base_use;
    struct block_s *next_free;
} node_t;

#define JT(b) ((b)->et.succ)
#define JF(b) ((b)->ef.succ)

/* A boolean sub-expression under construction: entry block plus the lists of
 * block exits that are still unbound. */
typedef struct exit_s {
    node_t      *b;
    int           isjt;
    struct exit_s *next;
} exit_t;

typedef struct { exit_t *head, *tail; } exlist_t;

typedef struct {
    node_t *entry;
    exlist_t t, f;
} test_t;

/* variable-offset register slots */
#define VR_NONE     (-1)
#define VR_LINKHDR  0
#define VR_LINKPL   1
#define VR_TYPE     2
#define VR_COUNT    3

typedef struct {
    int      dynamic;
    uint32_t fixed;
    int      regid;          /* VR_* slot holding the variable part */
} base_t;

/* offset bases */
enum basekind {
    B_ABS, B_HDR, B_OUTER, B_LLC, B_PREVLABEL,
    B_PL, B_RAWPL, B_TYPE, B_TP4, B_TP6
};

typedef struct arth_s {
    test_t   b;
    int      has_b;
    op_t *s;
    int      regno;
} val_t;

#define ARENA_CHUNK (1u << 16)
typedef struct arena_chunk {
    struct arena_chunk *next;
    size_t used, size;
    char  *mem;
} arena_chunk_t;

typedef struct {
    /* input */
    int      link;
    int      outer_link;
    int      prev_link;
    int      caplen;
    uint32_t lmask;
    int      skip_refine;

    /* link layer geometry */
    base_t hdr_at;
    base_t outer_at;
    base_t type_at;
    base_t pay_at;
    uint32_t nl_skip, raw_skip;
    uint32_t off_outermostlinkhdr_const;
    int      nested;          /* inside vlan/mpls/pppoe/geneve */
    int      tag_dynamic;
    int      mpls_depth;
    int      tag_depth;
    uint32_t fddi_pad;

    /* register allocation */
    int      memused[BPF_MEMWORDS];
    int      memnext;
    int      vreg[VR_COUNT];

    /* error handling */
    jmp_buf  jmp;
    char     errbuf[256];
    int      failed;

    /* arena */
    arena_chunk_t *chunks;
    arena_chunk_t *cur;

    /* block bookkeeping */
    int      node_count;
    node_t *node_list;     /* chain via next_free */

    node_t *root;
    /* filter text cursor for the lexer */
    const char *text;
} ctx_t;

/* ---- arena ---- */
void  arena_init(ctx_t *cs);
void *arena_alloc(ctx_t *cs, size_t n);
void  arena_reset(ctx_t *cs);
void  arena_free(ctx_t *cs);

/* ---- error ---- */
void fail(ctx_t *cs, const char *fmt, ...);

/* ---- codegen primitives ---- */
op_t *op_new(ctx_t *cs, uint16_t code);
node_t *blk_new(ctx_t *cs, uint16_t code);
op_t *op_cat(op_t *s0, op_t *s1);

test_t  bx_leaf_cs(ctx_t *cs, node_t *b);
test_t  bx_and(ctx_t *cs, test_t a, test_t b);
test_t  bx_or(ctx_t *cs, test_t a, test_t b);
test_t  bx_not(test_t a);
void    bx_patch_t(test_t e, node_t *tgt);
void    bx_patch_f(test_t e, node_t *tgt);

/* ---- entry points ---- */
int build_program(ctx_t *cs, const char *text, int dlt, int caplen,
                   uint32_t lmask, int optimize, bpf_prog_t *out,
                   const char **err);

/* internal stages */
void     setup_layout(ctx_t *cs);
test_t   run_parser(ctx_t *cs, const char *text);
void     refine_graph(ctx_t *cs);
void     flatten_graph(ctx_t *cs, node_t *root, bpf_prog_t *out);

#endif /* COMP_H */
