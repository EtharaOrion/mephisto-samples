#include <stdlib.h>
#include "filter.h"

void bpf_prog_init(bpf_prog_t *p){p->insns=NULL;p->len=0;p->cap=0;p->overflow=0;}
void bpf_prog_free(bpf_prog_t *p){free(p->insns);p->insns=NULL;p->len=p->cap=0;}

int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err)
{
    (void)c;
    out->len = 0;
    *err = "can't parse filter expression: syntax error";
    return -1;
}
