src/stub.o: src/stub.c src/filter.h src/bpf_defs.h src/jsonio.h
src/filter.h:
src/bpf_defs.h:
src/jsonio.h:
