#ifndef FILTER_H
#define FILTER_H
#include "bpf_defs.h"
#include "jsonio.h"
int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err);
#endif
