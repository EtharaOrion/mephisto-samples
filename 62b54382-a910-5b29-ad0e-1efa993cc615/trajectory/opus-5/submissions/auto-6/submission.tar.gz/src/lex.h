#ifndef LEX_H
#define LEX_H

#include "comp.h"

enum {
    T_EOF = 0, T_ID, T_HID, T_HID6, T_EID, T_AID, T_NUM,
    T_LPAREN, T_RPAREN, T_LBRACK, T_RBRACK, T_COLON, T_SLASH,
    T_PLUS, T_MINUS, T_STAR, T_DIV, T_MOD, T_AMP, T_PIPE, T_CARET,
    T_LSH, T_RSH, T_EQ, T_NE, T_LT, T_GT, T_LE, T_GE, T_BANG,
    T_BAD,
    /* keywords */
    K_DST, K_SRC, K_HOST, K_GATEWAY, K_NET, K_NETMASK, K_PORT, K_PORTRANGE,
    K_PROTO, K_PROTOCHAIN, K_CBYTE, K_ARP, K_RARP, K_IP, K_SCTP, K_TCP, K_UDP,
    K_ICMP, K_IGMP, K_IGRP, K_PIM, K_VRRP, K_CARP, K_ATALK, K_AARP, K_DECNET,
    K_LAT, K_SCA, K_MOPRC, K_MOPDL, K_STP, K_IPX, K_NETBEUI, K_ISO, K_ESIS,
    K_ISIS, K_L1, K_L2, K_IIH, K_LSP, K_SNP, K_CSNP, K_PSNP, K_CLNP,
    K_IPV6, K_ICMPV6, K_AH, K_ESP, K_LINK, K_GREATER, K_LESS, K_BROADCAST,
    K_MULTICAST, K_AND, K_OR, K_NOT, K_LEN, K_INBOUND, K_OUTBOUND, K_IFINDEX,
    K_VLAN, K_MPLS, K_PPPOED, K_PPPOES, K_GENEVE, K_TYPE, K_SUBTYPE, K_DIR,
    K_RA, K_TA, K_ADDR1, K_ADDR2, K_ADDR3, K_ADDR4, K_RADIO,
    K_LLC, K_PPP, K_SLIP, K_FDDI, K_TR, K_WLAN, K_ON, K_ACTION, K_REASON,
    K_RSET, K_RNR, K_SRNR, K_IFNAME
};

typedef struct {
    int      type;
    uint32_t num;
    char     str[128];
} token_t;

typedef struct {
    const char *p;
    ctx_t   *cs;
    token_t     tok;
    token_t     ahead;
    int         have_ahead;
} lexer_t;

void lex_init(lexer_t *lx, ctx_t *cs, const char *text);
void lex_next(lexer_t *lx);

#endif
