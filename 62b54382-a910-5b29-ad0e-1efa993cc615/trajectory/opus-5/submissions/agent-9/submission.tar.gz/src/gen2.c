/*
 * gen2.c - address, port and protocol primitives.
 */
#include <stdio.h>
#include <string.h>

#include "comp.h"
#include "gen.h"
#include "names.h"

extern test_t unfragmented(ctx_t *cs);

/* ---------------------------------------------------------------- hosts */

static test_t addr4_field(ctx_t *cs, uint32_t addr, uint32_t mask, int dir,
                         uint32_t proto, uint32_t src_off, uint32_t dst_off)
{
    test_t b0, b1;
    uint32_t offset;

    switch (dir) {
    case QU_SRC: offset = src_off; break;
    case QU_DST: offset = dst_off; break;
    case QU_AND:
        b0 = addr4_field(cs, addr, mask, QU_SRC, proto, src_off, dst_off);
        b1 = addr4_field(cs, addr, mask, QU_DST, proto, src_off, dst_off);
        return bx_and(cs, b0, b1);
    case QU_DEFAULT:
    case QU_OR:
        b0 = addr4_field(cs, addr, mask, QU_SRC, proto, src_off, dst_off);
        b1 = addr4_field(cs, addr, mask, QU_DST, proto, src_off, dst_off);
        return bx_or(cs, b0, b1);
    case QU_ADDR1:
        fail(cs, "'addr1' and 'address1' are only supported on 802.11");
    case QU_ADDR2:
        fail(cs, "'addr2' and 'address2' are only supported on 802.11");
    case QU_ADDR3:
        fail(cs, "'addr3' and 'address3' are only supported on 802.11");
    case QU_ADDR4:
        fail(cs, "'addr4' and 'address4' are only supported on 802.11");
    case QU_RA:
        fail(cs, "'ra' is only supported on 802.11");
    case QU_TA:
        fail(cs, "'ta' is only supported on 802.11");
    default:
        fail(cs, "direction not supported on link %d", cs->link);
    }
    b0 = ll_type_test(cs, proto);
    b1 = wcmp_mask(cs, B_PL, offset, BPF_W, addr, mask);
    return bx_and(cs, b0, b1);
}

static test_t addr6_field(ctx_t *cs, const uint8_t *addr, const uint8_t *mask,
                          int dir, uint32_t proto, uint32_t src_off, uint32_t dst_off)
{
    test_t b0, b1, tmp;
    uint32_t offset;
    int i, have = 0;

    switch (dir) {
    case QU_SRC: offset = src_off; break;
    case QU_DST: offset = dst_off; break;
    case QU_AND:
        b0 = addr6_field(cs, addr, mask, QU_SRC, proto, src_off, dst_off);
        b1 = addr6_field(cs, addr, mask, QU_DST, proto, src_off, dst_off);
        return bx_and(cs, b0, b1);
    case QU_DEFAULT:
    case QU_OR:
        b0 = addr6_field(cs, addr, mask, QU_SRC, proto, src_off, dst_off);
        b1 = addr6_field(cs, addr, mask, QU_DST, proto, src_off, dst_off);
        return bx_or(cs, b0, b1);
    case QU_ADDR1:
        fail(cs, "'addr1' and 'address1' are only supported on 802.11");
    case QU_ADDR2:
        fail(cs, "'addr2' and 'address2' are only supported on 802.11");
    case QU_ADDR3:
        fail(cs, "'addr3' and 'address3' are only supported on 802.11");
    case QU_ADDR4:
        fail(cs, "'addr4' and 'address4' are only supported on 802.11");
    case QU_RA:
        fail(cs, "'ra' is only supported on 802.11");
    case QU_TA:
        fail(cs, "'ta' is only supported on 802.11");
    default:
        fail(cs, "direction not supported on link %d", cs->link);
    }
    b1 = ll_type_test(cs, proto);
    for (i = 0; i < 4; i++) {
        uint32_t a, m;
        a = ((uint32_t)addr[i*4] << 24) | ((uint32_t)addr[i*4+1] << 16) |
            ((uint32_t)addr[i*4+2] << 8) | addr[i*4+3];
        m = ((uint32_t)mask[i*4] << 24) | ((uint32_t)mask[i*4+1] << 16) |
            ((uint32_t)mask[i*4+2] << 8) | mask[i*4+3];
        tmp = wcmp_mask(cs, B_PL, offset + i*4, BPF_W, a, m);
        if (have) b0 = bx_and(cs, b0, tmp);
        else { b0 = tmp; have = 1; }
    }
    if (!have)
        return b1;
    return bx_and(cs, b1, b0);
}

static test_t mac_eth_field(ctx_t *cs, const uint8_t *eaddr, int dir)
{
    test_t b0, b1;

    switch (dir) {
    case QU_SRC:
        return wcmp_bytes(cs, B_HDR, 6, 6, eaddr);
    case QU_DST:
        return wcmp_bytes(cs, B_HDR, 0, 6, eaddr);
    case QU_AND:
        b0 = mac_eth_field(cs, eaddr, QU_SRC);
        b1 = mac_eth_field(cs, eaddr, QU_DST);
        return bx_and(cs, b0, b1);
    case QU_DEFAULT:
    case QU_OR:
        b0 = mac_eth_field(cs, eaddr, QU_SRC);
        b1 = mac_eth_field(cs, eaddr, QU_DST);
        return bx_or(cs, b0, b1);
    case QU_ADDR1:
        fail(cs, "'addr1' and 'address1' are only supported on 802.11 with 802.11 headers");
    case QU_ADDR2:
        fail(cs, "'addr2' and 'address2' are only supported on 802.11 with 802.11 headers");
    case QU_ADDR3:
        fail(cs, "'addr3' and 'address3' are only supported on 802.11 with 802.11 headers");
    case QU_ADDR4:
        fail(cs, "'addr4' and 'address4' are only supported on 802.11 with 802.11 headers");
    case QU_RA:
        fail(cs, "'ra' is only supported on 802.11 with 802.11 headers");
    case QU_TA:
        fail(cs, "'ta' is only supported on 802.11 with 802.11 headers");
    }
    fail(cs, "bogus direction");
    return always_no(cs);
}


/*
 * On 802.11 the address that plays the part of "source" or "destination"
 * moves around depending on the frame type and the two DS bits, so each
 * case gets its own guarded comparison.
 */
typedef test_t (*addrfn_t)(ctx_t *cs, uint32_t off, const void *arg);

static test_t fc_bit(ctx_t *cs, uint32_t byte, uint32_t bit)
{
    node_t *b = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    b->stmts = fetch_a(cs, B_HDR, byte, BPF_B);
    b->s.k = bit;
    return bx_leaf_cs(cs, b);
}

static test_t addr_bytes(ctx_t *cs, uint32_t off, const void *arg)
{
    return wcmp_bytes(cs, B_HDR, off, 6, (const uint8_t *)arg);
}

static test_t addr_group_bit(ctx_t *cs, uint32_t off, const void *arg)
{
    node_t *b;
    (void)arg;
    b = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    b->stmts = fetch_a(cs, B_HDR, off, BPF_B);
    b->s.k = 1;
    return bx_leaf_cs(cs, b);
}

static test_t wlan_recv_addr(ctx_t *cs, addrfn_t f, const void *arg)
{
    test_t notctl, notdata, isdata, nottods, istods, e1, e2, inner, t;

    notctl = bx_not(fc_bit(cs, 0, 0x04));

    notdata = bx_not(fc_bit(cs, 0, 0x08));
    t = f(cs, 4, arg);
    e1 = bx_and(cs, notdata, t);

    nottods = bx_not(fc_bit(cs, 1, 0x01));
    t = f(cs, 4, arg);
    inner = bx_and(cs, nottods, t);
    istods = fc_bit(cs, 1, 0x01);
    t = f(cs, 16, arg);
    inner = bx_or(cs, inner, bx_and(cs, istods, t));

    isdata = fc_bit(cs, 0, 0x08);
    e2 = bx_and(cs, isdata, inner);

    e1 = bx_or(cs, e1, e2);
    return bx_and(cs, notctl, e1);
}

static test_t wlan_send_addr(ctx_t *cs, addrfn_t f, const void *arg)
{
    test_t notctl, notdata, isdata, notfrom, isfrom, nottods, istods;
    test_t e1, e2, lvl3, lvl2, t;

    notctl = bx_not(fc_bit(cs, 0, 0x04));

    notdata = bx_not(fc_bit(cs, 0, 0x08));
    t = f(cs, 10, arg);
    e1 = bx_and(cs, notdata, t);

    nottods = bx_not(fc_bit(cs, 1, 0x01));
    t = f(cs, 16, arg);
    lvl3 = bx_and(cs, nottods, t);
    istods = fc_bit(cs, 1, 0x01);
    t = f(cs, 24, arg);
    lvl3 = bx_or(cs, lvl3, bx_and(cs, istods, t));

    isfrom = fc_bit(cs, 1, 0x02);
    lvl3 = bx_and(cs, isfrom, lvl3);

    notfrom = bx_not(fc_bit(cs, 1, 0x02));
    t = f(cs, 10, arg);
    lvl2 = bx_and(cs, notfrom, t);
    lvl2 = bx_or(cs, lvl2, lvl3);

    isdata = fc_bit(cs, 0, 0x08);
    e2 = bx_and(cs, isdata, lvl2);

    e1 = bx_or(cs, e1, e2);
    return bx_and(cs, notctl, e1);
}

test_t wlan_group_test(ctx_t *cs)
{
    return wlan_recv_addr(cs, addr_group_bit, NULL);
}

test_t wlan_bcast_test(ctx_t *cs, const uint8_t *eaddr)
{
    return wlan_recv_addr(cs, addr_bytes, eaddr);
}

static test_t mac_wlan_field(ctx_t *cs, const uint8_t *eaddr, int dir)
{
    test_t b0, b1;

    switch (dir) {
    case QU_SRC:
        return wlan_send_addr(cs, addr_bytes, eaddr);
    case QU_DST:
        return wlan_recv_addr(cs, addr_bytes, eaddr);
    case QU_AND:
        b0 = mac_wlan_field(cs, eaddr, QU_SRC);
        b1 = mac_wlan_field(cs, eaddr, QU_DST);
        return bx_and(cs, b0, b1);
    case QU_DEFAULT:
    case QU_OR:
        b0 = mac_wlan_field(cs, eaddr, QU_SRC);
        b1 = mac_wlan_field(cs, eaddr, QU_DST);
        return bx_or(cs, b0, b1);
    case QU_ADDR1:
        return wcmp_bytes(cs, B_HDR, 4, 6, eaddr);
    case QU_ADDR2:
        return wcmp_bytes(cs, B_HDR, 10, 6, eaddr);
    case QU_ADDR3:
        return wcmp_bytes(cs, B_HDR, 16, 6, eaddr);
    case QU_ADDR4:
        b0 = wcmp_mask(cs, B_HDR, 1, BPF_B, 0x03, 0x03);
        b1 = wcmp_bytes(cs, B_HDR, 24, 6, eaddr);
        return bx_and(cs, b0, b1);
    case QU_RA:
        b0 = wcmp_mask(cs, B_HDR, 0, BPF_B, 0x08, 0x0c);
        b1 = wcmp_bytes(cs, B_HDR, 4, 6, eaddr);
        return bx_and(cs, b0, b1);
    case QU_TA:
        b0 = wcmp_mask(cs, B_HDR, 0, BPF_B, 0x08, 0x0c);
        b1 = wcmp_bytes(cs, B_HDR, 10, 6, eaddr);
        return bx_and(cs, b0, b1);
    }
    fail(cs, "bogus direction");
    return always_no(cs);
}

static test_t mac_test(ctx_t *cs, const uint8_t *eaddr, int dir,
                            const char *type)
{
    switch (cs->link) {
    case LNK_EN10MB:
    case LNK_NETANALYZER:
    case LNK_NETANALYZER_TRANSPARENT:
        return mac_eth_field(cs, eaddr, dir);
    case LNK_IEEE802_11:
    case LNK_PRISM_HEADER:
    case LNK_IEEE802_11_RADIO_AVS:
    case LNK_IEEE802_11_RADIO:
        return mac_wlan_field(cs, eaddr, dir);
    default:
        fail(cs, "%s addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel",
                  type);
    }
    return always_no(cs);
}

test_t addr4_test(ctx_t *cs, uint32_t addr, uint32_t mask, int proto, int dir,
                int type)
{
    test_t b0, b1;
    const char *typestr;

    if (type == QU_NET) typestr = "net";
    else typestr = "host";

    switch (proto) {

    case QU_DEFAULT:
        b0 = addr4_test(cs, addr, mask, QU_IP, dir, type);
        b1 = addr4_test(cs, addr, mask, QU_ARP, dir, type);
        b0 = bx_or(cs, b0, b1);
        b1 = addr4_test(cs, addr, mask, QU_RARP, dir, type);
        return bx_or(cs, b0, b1);

    case QU_LINK:
        fail(cs, "link-layer modifier applied to %s", typestr);

    case QU_IP:
        return addr4_field(cs, addr, mask, dir, TY_IP4, 12, 16);

    case QU_RARP:
        return addr4_field(cs, addr, mask, dir, TY_RARP, 14, 24);

    case QU_ARP:
        return addr4_field(cs, addr, mask, dir, TY_ARP, 14, 24);

    default:
        break;
    }

    {
        static const struct { int q; const char *msg; } notaddr[] = {
            { QU_SCTP, "'sctp' modifier applied to %s" },
            { QU_TCP, "'tcp' modifier applied to %s" },
            { QU_UDP, "'udp' modifier applied to %s" },
            { QU_ICMP, "'icmp' modifier applied to %s" },
            { QU_IGMP, "'igmp' modifier applied to %s" },
            { QU_IGRP, "'igrp' modifier applied to %s" },
            { QU_ATALK, "AppleTalk host filtering not implemented" },
            { QU_DECNET, "'decnet' modifier applied to %s" },
            { QU_LAT, "LAT host filtering not implemented" },
            { QU_SCA, "SCA host filtering not implemented" },
            { QU_MOPDL, "MOPDL host filtering not implemented" },
            { QU_MOPRC, "MOPRC host filtering not implemented" },
            { QU_IPV6, "'ip6' modifier applied to ip host" },
            { QU_ICMPV6, "'icmp6' modifier applied to %s" },
            { QU_AH, "'ah' modifier applied to %s" },
            { QU_ESP, "'esp' modifier applied to %s" },
            { QU_PIM, "'pim' modifier applied to %s" },
            { QU_VRRP, "'vrrp' modifier applied to %s" },
            { QU_AARP, "AARP host filtering not implemented" },
            { QU_ISO, "ISO host filtering not implemented" },
            { QU_ESIS, "'esis' modifier applied to %s" },
            { QU_ISIS, "'isis' modifier applied to %s" },
            { QU_CLNP, "'clnp' modifier applied to %s" },
            { QU_STP, "'stp' modifier applied to %s" },
            { QU_IPX, "IPX host filtering not implemented" },
            { QU_NETBEUI, "'netbeui' modifier applied to %s" },
            { QU_RADIO, "'radio' modifier applied to %s" },
            { QU_CARP, "'carp' modifier applied to %s" },
        };
        size_t i;
        for (i = 0; i < sizeof(notaddr) / sizeof(notaddr[0]); i++)
            if (notaddr[i].q == proto)
                fail(cs, notaddr[i].msg, typestr);
    }
    fail(cs, "bogus proto");
    return always_no(cs);
}

static test_t addr6_test(ctx_t *cs, const uint8_t *addr, const uint8_t *mask,
                        int proto, int dir, int type)
{
    const char *typestr = (type == QU_NET) ? "net" : "host";

    switch (proto) {
    case QU_DEFAULT:
    case QU_IPV6:
        return addr6_field(cs, addr, mask, dir, TY_IP6, 8, 24);
    case QU_LINK:
        fail(cs, "link-layer modifier applied to ip6 %s", typestr);
    case QU_IP:
        fail(cs, "'ip' modifier applied to ip6 %s", typestr);
    case QU_ARP:
        fail(cs, "'arp' modifier applied to ip6 %s", typestr);
    case QU_RARP:
        fail(cs, "'rarp' modifier applied to ip6 %s", typestr);
    default:
        fail(cs, "'%d' modifier applied to ip6 %s", proto, typestr);
    }
    return always_no(cs);
}

/* ---------------------------------------------------------------- ports */

static test_t pnum4_at(ctx_t *cs, int off, uint32_t v)
{
    return wcmp_eq(cs, B_TP4, (uint32_t)off, BPF_H, v);
}

static test_t pnum6_at(ctx_t *cs, int off, uint32_t v)
{
    return wcmp_eq(cs, B_TP6, (uint32_t)off, BPF_H, v);
}

static test_t pmatch4(ctx_t *cs, uint32_t port, uint32_t proto, int dir)
{
    test_t b0, b1, tmp;

    b0 = wcmp_eq(cs, B_PL, 9, BPF_B, proto);
    b1 = unfragmented(cs);
    b1 = bx_and(cs, b0, b1);

    switch (dir) {
    case QU_SRC:
        b0 = pnum4_at(cs, 0, port);
        break;
    case QU_DST:
        b0 = pnum4_at(cs, 2, port);
        break;
    case QU_AND:
        tmp = pnum4_at(cs, 0, port);
        b0 = pnum4_at(cs, 2, port);
        b0 = bx_and(cs, tmp, b0);
        break;
    case QU_OR:
    case QU_DEFAULT:
        tmp = pnum4_at(cs, 0, port);
        b0 = pnum4_at(cs, 2, port);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        fail(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static test_t psel4(ctx_t *cs, uint32_t port, int ip_proto, int dir)
{
    test_t b0, b1, tmp;

    b0 = ll_type_test(cs, TY_IP4);
    switch (ip_proto) {
    case NP_UDP:
    case NP_TCP:
    case NP_SCTP:
        b1 = pmatch4(cs, port, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = pmatch4(cs, port, NP_TCP, dir);
        b1 = pmatch4(cs, port, NP_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = pmatch4(cs, port, NP_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

static test_t pmatch6(ctx_t *cs, uint32_t port, uint32_t proto, int dir)
{
    test_t b0, b1, tmp;

    b1 = wcmp_eq(cs, B_PL, 6, BPF_B, proto);

    switch (dir) {
    case QU_SRC:
        b0 = pnum6_at(cs, 0, port);
        break;
    case QU_DST:
        b0 = pnum6_at(cs, 2, port);
        break;
    case QU_AND:
        tmp = pnum6_at(cs, 0, port);
        b0 = pnum6_at(cs, 2, port);
        b0 = bx_and(cs, tmp, b0);
        break;
    case QU_OR:
    case QU_DEFAULT:
        tmp = pnum6_at(cs, 0, port);
        b0 = pnum6_at(cs, 2, port);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        fail(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static test_t psel6(ctx_t *cs, uint32_t port, int ip_proto, int dir)
{
    test_t b0, b1, tmp;

    b0 = ll_type_test(cs, TY_IP6);
    switch (ip_proto) {
    case NP_UDP:
    case NP_TCP:
    case NP_SCTP:
        b1 = pmatch6(cs, port, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = pmatch6(cs, port, NP_TCP, dir);
        b1 = pmatch6(cs, port, NP_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = pmatch6(cs, port, NP_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

static test_t prng4_at(ctx_t *cs, int off, uint32_t v1, uint32_t v2)
{
    test_t b1, b2;
    uint32_t t;

    if (v1 > v2) { t = v1; v1 = v2; v2 = t; }
    b1 = wcmp_ge(cs, B_TP4, (uint32_t)off, BPF_H, v1);
    b2 = wcmp_le(cs, B_TP4, (uint32_t)off, BPF_H, v2);
    return bx_and(cs, b1, b2);
}

static test_t prng6_at(ctx_t *cs, int off, uint32_t v1, uint32_t v2)
{
    test_t b1, b2;
    uint32_t t;

    if (v1 > v2) { t = v1; v1 = v2; v2 = t; }
    b1 = wcmp_ge(cs, B_TP6, (uint32_t)off, BPF_H, v1);
    b2 = wcmp_le(cs, B_TP6, (uint32_t)off, BPF_H, v2);
    return bx_and(cs, b1, b2);
}

static test_t prmatch4(ctx_t *cs, uint32_t p1, uint32_t p2,
                              uint32_t proto, int dir)
{
    test_t b0, b1, tmp;

    b0 = wcmp_eq(cs, B_PL, 9, BPF_B, proto);
    b1 = unfragmented(cs);
    b1 = bx_and(cs, b0, b1);

    switch (dir) {
    case QU_SRC:
        b0 = prng4_at(cs, 0, p1, p2);
        break;
    case QU_DST:
        b0 = prng4_at(cs, 2, p1, p2);
        break;
    case QU_AND:
        tmp = prng4_at(cs, 0, p1, p2);
        b0 = prng4_at(cs, 2, p1, p2);
        b0 = bx_and(cs, tmp, b0);
        break;
    case QU_OR:
    case QU_DEFAULT:
        tmp = prng4_at(cs, 0, p1, p2);
        b0 = prng4_at(cs, 2, p1, p2);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        fail(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static test_t prsel4(ctx_t *cs, uint32_t p1, uint32_t p2,
                            int ip_proto, int dir)
{
    test_t b0, b1, tmp;

    b0 = ll_type_test(cs, TY_IP4);
    switch (ip_proto) {
    case NP_UDP:
    case NP_TCP:
    case NP_SCTP:
        b1 = prmatch4(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = prmatch4(cs, p1, p2, NP_TCP, dir);
        b1 = prmatch4(cs, p1, p2, NP_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = prmatch4(cs, p1, p2, NP_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

static test_t prmatch6(ctx_t *cs, uint32_t p1, uint32_t p2,
                               uint32_t proto, int dir)
{
    test_t b0, b1, tmp;

    b1 = wcmp_eq(cs, B_PL, 6, BPF_B, proto);

    switch (dir) {
    case QU_SRC:
        b0 = prng6_at(cs, 0, p1, p2);
        break;
    case QU_DST:
        b0 = prng6_at(cs, 2, p1, p2);
        break;
    case QU_AND:
        tmp = prng6_at(cs, 0, p1, p2);
        b0 = prng6_at(cs, 2, p1, p2);
        b0 = bx_and(cs, tmp, b0);
        break;
    case QU_OR:
    case QU_DEFAULT:
        tmp = prng6_at(cs, 0, p1, p2);
        b0 = prng6_at(cs, 2, p1, p2);
        b0 = bx_or(cs, tmp, b0);
        break;
    default:
        fail(cs, "bogus direction");
        return b1;
    }
    return bx_and(cs, b1, b0);
}

static test_t prsel6(ctx_t *cs, uint32_t p1, uint32_t p2,
                             int ip_proto, int dir)
{
    test_t b0, b1, tmp;

    b0 = ll_type_test(cs, TY_IP6);
    switch (ip_proto) {
    case NP_UDP:
    case NP_TCP:
    case NP_SCTP:
        b1 = prmatch6(cs, p1, p2, (uint32_t)ip_proto, dir);
        break;
    default:
        tmp = prmatch6(cs, p1, p2, NP_TCP, dir);
        b1 = prmatch6(cs, p1, p2, NP_UDP, dir);
        b1 = bx_or(cs, tmp, b1);
        tmp = prmatch6(cs, p1, p2, NP_SCTP, dir);
        b1 = bx_or(cs, tmp, b1);
        break;
    }
    return bx_and(cs, b0, b1);
}

/* ------------------------------------------------------------- protocols */

test_t unfragmented(ctx_t *cs)
{
    op_t *s;
    node_t *b;

    s = fetch_a(cs, B_PL, 6, BPF_H);
    b = blk_new(cs, BPF_JMP | BPF_JSET | BPF_K);
    b->s.k = 0x1fff;
    b->stmts = s;
    return bx_not(bx_leaf_cs(cs, b));
}

static int qual_ident(int p);

test_t nl_proto_test(ctx_t *cs, uint32_t v, int proto, int dir)
{
    test_t b0, b1, b2;

    if (dir != QU_DEFAULT)
        fail(cs, "direction applied to 'proto'");

    switch (proto) {
    case QU_DEFAULT:
        b0 = nl_proto_test(cs, v, QU_IP, dir);
        b1 = nl_proto_test(cs, v, QU_IPV6, dir);
        return bx_or(cs, b0, b1);

    case QU_LINK:
        return ll_type_test(cs, v);

    case QU_IP:
        b0 = ll_type_test(cs, TY_IP4);
        b1 = wcmp_eq(cs, B_PL, 9, BPF_B, v);
        return bx_and(cs, b0, b1);

    default:
        break;
    }

    {
        static const struct { int q; const char *msg; } nope[] = {
            { QU_ARP, "arp does not encapsulate another protocol" },
            { QU_RARP, "rarp does not encapsulate another protocol" },
            { QU_SCTP, "'sctp proto' is bogus" },
            { QU_TCP, "'tcp proto' is bogus" },
            { QU_UDP, "'udp proto' is bogus" },
            { QU_ICMP, "'icmp proto' is bogus" },
            { QU_IGMP, "'igmp proto' is bogus" },
            { QU_IGRP, "'igrp proto' is bogus" },
            { QU_PIM, "'pim proto' is bogus" },
            { QU_VRRP, "'vrrp proto' is bogus" },
            { QU_CARP, "'carp proto' is bogus" },
            { QU_ESIS, "'esis proto' is bogus" },
            { QU_ISIS, "'isis proto' is bogus" },
            { QU_CLNP, "'clnp proto' is bogus" },
            { QU_STP, "'stp proto' is bogus" },
            { QU_IPX, "'ipx proto' is bogus" },
            { QU_NETBEUI, "'netbeui proto' is bogus" },
            { QU_ICMPV6, "'icmp6 proto' is bogus" },
        };
        size_t i;
        for (i = 0; i < sizeof(nope) / sizeof(nope[0]); i++)
            if (nope[i].q == proto)
                fail(cs, "%s", nope[i].msg);
    }

    switch (proto) {
    case QU_ISO:
        switch (cs->link) {
        case LNK_FRELAY:
            b0 = wcmp_eq(cs, B_HDR, 2, BPF_B, 0x03);
            b1 = wcmp_eq(cs, B_HDR, 4, BPF_B, v);
            return bx_and(cs, b0, b1);
        case LNK_C_HDLC:
            b0 = ll_type_test(cs, SAP_OSI);
            b1 = wcmp_eq(cs, B_RAWPL, 1, BPF_B, v);
            return bx_and(cs, b0, b1);
        default:
            b0 = ll_type_test(cs, SAP_OSI);
            b1 = wcmp_eq(cs, B_RAWPL, 0, BPF_B, v);
            return bx_and(cs, b0, b1);
        }

    case QU_ESIS:
        fail(cs, "'esis proto' is bogus");
    case QU_ISIS:
        fail(cs, "'isis proto' is bogus");
    case QU_CLNP:
        fail(cs, "'clnp proto' is bogus");
    case QU_STP:
        fail(cs, "'stp proto' is bogus");
    case QU_IPX:
        fail(cs, "'ipx proto' is bogus");
    case QU_NETBEUI:
        fail(cs, "'netbeui proto' is bogus");
    case QU_ICMPV6:
        fail(cs, "'icmp6 proto' is bogus");

    case QU_IPV6:
        b0 = ll_type_test(cs, TY_IP6);
        b2 = wcmp_eq(cs, B_PL, 6, BPF_B, NP_FRAG);
        b1 = wcmp_eq(cs, B_PL, 40, BPF_B, v);
        b1 = bx_and(cs, b2, b1);
        b2 = wcmp_eq(cs, B_PL, 6, BPF_B, v);
        b1 = bx_or(cs, b2, b1);
        return bx_and(cs, b0, b1);

    default:
        fail(cs, "'proto' modifier applied to unsupported protocol");
    }
    return always_no(cs);
}

test_t abbrev_test(ctx_t *cs, int proto)
{
    test_t b0;

    switch (proto) {
    case QU_SCTP:
        return nl_proto_test(cs, NP_SCTP, QU_DEFAULT, QU_DEFAULT);
    case QU_TCP:
        return nl_proto_test(cs, NP_TCP, QU_DEFAULT, QU_DEFAULT);
    case QU_UDP:
        return nl_proto_test(cs, NP_UDP, QU_DEFAULT, QU_DEFAULT);
    case QU_ICMP:
        return nl_proto_test(cs, NP_ICMP, QU_IP, QU_DEFAULT);
    case QU_IGMP:
        return nl_proto_test(cs, NP_IGMP, QU_IP, QU_DEFAULT);
    case QU_IGRP:
        return nl_proto_test(cs, NP_IGRP, QU_IP, QU_DEFAULT);
    case QU_PIM:
        return nl_proto_test(cs, NP_PIM, QU_DEFAULT, QU_DEFAULT);
    case QU_VRRP:
        return nl_proto_test(cs, NP_VRRP, QU_IP, QU_DEFAULT);
    case QU_CARP:
        return nl_proto_test(cs, NP_CARP, QU_IP, QU_DEFAULT);
    case QU_IP:
        return ll_type_test(cs, TY_IP4);
    case QU_ARP:
        return ll_type_test(cs, TY_ARP);
    case QU_RARP:
        return ll_type_test(cs, TY_RARP);
    case QU_LINK:
        fail(cs, "link layer applied in wrong context");
    case QU_ATALK:
        return ll_type_test(cs, TY_ATALK);
    case QU_AARP:
        return ll_type_test(cs, TY_AARP);
    case QU_DECNET:
        return ll_type_test(cs, TY_DECNET);
    case QU_SCA:
        return ll_type_test(cs, TY_SCA);
    case QU_LAT:
        return ll_type_test(cs, TY_LAT);
    case QU_MOPDL:
        return ll_type_test(cs, TY_MOPDL);
    case QU_MOPRC:
        return ll_type_test(cs, TY_MOPRC);
    case QU_IPV6:
        return ll_type_test(cs, TY_IP6);
    case QU_ICMPV6:
        return nl_proto_test(cs, NP_ICMP6, QU_IPV6, QU_DEFAULT);
    case QU_AH:
        return nl_proto_test(cs, NP_AH, QU_DEFAULT, QU_DEFAULT);
    case QU_ESP:
        return nl_proto_test(cs, NP_ESP, QU_DEFAULT, QU_DEFAULT);
    case QU_ISO:
        return ll_type_test(cs, SAP_OSI);
    case QU_ESIS:
        return nl_proto_test(cs, OSI_ESIS, QU_ISO, QU_DEFAULT);
    case QU_ISIS:
        return nl_proto_test(cs, OSI_ISIS, QU_ISO, QU_DEFAULT);
    case QU_ISIS_L1:
    case QU_ISIS_L2:
    case QU_ISIS_IIH:
    case QU_ISIS_LSP:
    case QU_ISIS_SNP:
    case QU_ISIS_CSNP:
    case QU_ISIS_PSNP:
        b0 = nl_proto_test(cs, OSI_ISIS, QU_ISO, QU_DEFAULT);
        return b0;
    case QU_CLNP:
        return nl_proto_test(cs, OSI_CLNP, QU_ISO, QU_DEFAULT);
    case QU_STP:
        return ll_type_test(cs, SAP_STP);
    case QU_IPX:
        return ll_type_test(cs, SAP_IPX);
    case QU_NETBEUI:
        return ll_type_test(cs, SAP_NB);
    case QU_RADIO:
        fail(cs, "'radio' is not a valid protocol type");
    }
    fail(cs, "bogus protocol abbreviation");
    return always_no(cs);
}

static int qual_ident(int p) { return p; }

/* ------------------------------------------------------------ name codes */

static int dotted_quad(const char *s, uint32_t *addr)
{
    uint32_t n;
    int len = 0;

    *addr = 0;
    for (;;) {
        n = 0;
        while (*s && *s != '.') {
            if (*s < '0' || *s > '9') return -1;
            if (n > 25) return -1;
            n = n * 10 + (uint32_t)(*s++ - '0');
        }
        if (n > 255) return -1;
        *addr <<= 8;
        *addr |= n & 0xff;
        len += 8;
        if (*s == '\0') return len;
        ++s;
    }
}

test_t id_numeric(ctx_t *cs, const char *s, uint32_t v, sel_t q)
{
    uint32_t mask;
    int proto = q.proto;
    int dir = q.dir;
    int vlen;

    if (s == NULL)
        vlen = 32;
    else {
        vlen = dotted_quad(s, &v);
        if (vlen < 0)
            fail(cs, "invalid IPv4 address '%s'", s);
    }

    switch (q.addr) {

    case QU_DEFAULT:
    case QU_HOST:
    case QU_NET:
        if (proto == QU_LINK)
            fail(cs, "illegal link layer address");
        mask = 0xffffffffU;
        if (s == NULL && q.addr == QU_NET) {
            /* shift a truncated network number up to the top of the word */
            while (v && (v & 0xff000000U) == 0) {
                v <<= 8;
                mask <<= 8;
            }
        } else {
            /* the same shift, driven by how many octets were written */
            if (vlen < 32) {
                v <<= 32 - vlen;
                mask <<= 32 - vlen;
            }
        }
        return addr4_test(cs, v, mask, proto, dir, q.addr);

    case QU_PORT:
        if (proto != QU_DEFAULT && proto != QU_UDP && proto != QU_TCP &&
            proto != QU_SCTP)
            fail(cs, "illegal qualifier of 'port'");
        if (v > 65535)
            fail(cs, "illegal port number %u > 65535", v);
        {
            test_t b, b6;
            int ipproto = (proto == QU_UDP) ? NP_UDP :
                          (proto == QU_TCP) ? NP_TCP :
                          (proto == QU_SCTP) ? NP_SCTP : -1;
            b = psel4(cs, v, ipproto, dir);
            b6 = psel6(cs, v, ipproto, dir);
            return bx_or(cs, b6, b);
        }

    case QU_PORTRANGE:
        if (proto != QU_DEFAULT && proto != QU_UDP && proto != QU_TCP &&
            proto != QU_SCTP)
            fail(cs, "illegal qualifier of 'portrange'");
        if (v > 65535)
            fail(cs, "illegal port number %u > 65535", v);
        {
            test_t b, b6;
            int ipproto = (proto == QU_UDP) ? NP_UDP :
                          (proto == QU_TCP) ? NP_TCP :
                          (proto == QU_SCTP) ? NP_SCTP : -1;
            b = prsel4(cs, v, v, ipproto, dir);
            b6 = prsel6(cs, v, v, ipproto, dir);
            return bx_or(cs, b6, b);
        }

    case QU_GATEWAY:
        fail(cs, "'gateway' requires a name");

    case QU_PROTO:
        return nl_proto_test(cs, v, proto, dir);

    case QU_PROTOCHAIN:
        return chain_test(cs, v, proto);

    case QU_UNDEF:
        fail(cs, "'proto' qualifier applied to a number");
    }
    fail(cs, "bogus qualifier");
    return always_no(cs);
}

test_t id_range(ctx_t *cs, uint32_t v1, uint32_t v2, sel_t q)
{
    test_t b, b6;
    int proto = q.proto, dir = q.dir;
    int ipproto;

    if (q.addr != QU_PORTRANGE && q.addr != QU_DEFAULT)
        fail(cs, "illegal qualifier of 'portrange'");
    if (proto != QU_DEFAULT && proto != QU_UDP && proto != QU_TCP &&
        proto != QU_SCTP)
        fail(cs, "illegal qualifier of 'portrange'");
    if (v1 > 65535)
        fail(cs, "illegal port number %u > 65535", v1);
    if (v2 > 65535)
        fail(cs, "illegal port number %u > 65535", v2);

    ipproto = (proto == QU_UDP) ? NP_UDP :
              (proto == QU_TCP) ? NP_TCP :
              (proto == QU_SCTP) ? NP_SCTP : -1;
    b = prsel4(cs, v1, v2, ipproto, dir);
    b6 = prsel6(cs, v1, v2, ipproto, dir);
    return bx_or(cs, b6, b);
}

test_t id_prefix4(ctx_t *cs, const char *s1, const char *s2, uint32_t masklen,
                 sel_t q)
{
    int nlen, mlen;
    uint32_t n, m;

    nlen = dotted_quad(s1, &n);
    if (nlen < 0)
        fail(cs, "invalid IPv4 address '%s'", s1);
    if (nlen < 32) n <<= 32 - nlen;

    if (s2 != NULL) {
        mlen = dotted_quad(s2, &m);
        if (mlen < 0)
            fail(cs, "invalid IPv4 address '%s'", s2);
        if (mlen < 32) m <<= 32 - mlen;
        if ((n & ~m) != 0)
            fail(cs, "non-network bits set in \"%s mask %s\"", s1, s2);
    } else {
        if (masklen > 32)
            fail(cs, "mask length must be <= 32");
        if (masklen == 0)
            m = 0;
        else
            m = 0xffffffffU << (32 - masklen);
        if ((n & ~m) != 0)
            fail(cs, "non-network bits set in \"%s/%u\"", s1, masklen);
    }

    switch (q.addr) {
    case QU_NET:
        return addr4_test(cs, n, m, q.proto, q.dir, q.addr);
    case QU_DEFAULT:
    case QU_HOST:
        return addr4_test(cs, n, m, q.proto, q.dir, q.addr);
    default:
        fail(cs, "Mask syntax for networks only");
    }
    return always_no(cs);
}

test_t id_prefix6(ctx_t *cs, const char *s1, uint32_t masklen, sel_t q)
{
    uint8_t addr[16], mask[16];
    unsigned i;

    if (!scan_v6(s1, addr))
        fail(cs, "invalid IPv6 address '%s'", s1);
    if (masklen > 128)
        fail(cs, "mask length must be <= 128");
    memset(mask, 0, sizeof(mask));
    for (i = 0; i < masklen; i++)
        mask[i / 8] |= (uint8_t)(0x80 >> (i % 8));
    for (i = 0; i < 16; i++)
        if ((addr[i] & ~mask[i]) != 0)
            fail(cs, "non-network bits set in \"%s/%u\"", s1, masklen);

    switch (q.addr) {
    case QU_DEFAULT:
    case QU_HOST:
        if (masklen != 128)
            fail(cs, "Mask syntax for networks only");
        /* FALLTHROUGH */
    case QU_NET:
        return addr6_test(cs, addr, mask, q.proto, q.dir, q.addr);
    default:
        fail(cs, "invalid qualifier against IPv6 address");
    }
    return always_no(cs);
}

test_t id_mac(ctx_t *cs, const char *s, sel_t q)
{
    uint8_t eaddr[6];

    if (!scan_mac(s, eaddr))
        fail(cs, "malformed ethernet address '%s'", s);

    if ((q.addr == QU_HOST || q.addr == QU_DEFAULT) && q.proto == QU_LINK)
        return mac_test(cs, eaddr, q.dir, "ethernet");
    fail(cs, "ethernet address used in non-ether expression");
    return always_no(cs);
}

static int name_to_protonum(ctx_t *cs, const char *name, int proto)
{
    int v;

    switch (proto) {
    case QU_DEFAULT:
    case QU_IP:
    case QU_IPV6:
        if (!nm_proto(name, &v))
            fail(cs, "unknown ip proto '%s'", name);
        return v;
    case QU_LINK:
        if (!nm_eproto(name, &v)) {
            if (!nm_llcsap(name, &v))
                fail(cs, "unknown ether proto '%s'", name);
        }
        return v;
    case QU_ISO:
        if (strcmp(name, "esis") == 0) return OSI_ESIS;
        if (strcmp(name, "isis") == 0) return OSI_ISIS;
        if (strcmp(name, "clnp") == 0) return OSI_CLNP;
        fail(cs, "unknown osi proto '%s'", name);
        return 0;
    default:
        fail(cs, "unknown protocol qualifier");
        return 0;
    }
}

test_t id_named(ctx_t *cs, const char *name, sel_t q)
{
    int proto = q.proto;
    int dir = q.dir;
    uint32_t mask, addr;
    test_t b, tmp;
    int have = 0;
    nm_addr_t addrs[16];
    int n, i, port, real_proto;
    uint8_t mask128[16];

    switch (q.addr) {

    case QU_NET:
        if (!nm_network(name, &addr))
            fail(cs, "unknown network '%s'", name);
        mask = 0xffffffffU;
        if (addr == 0)
            fail(cs, "unknown network '%s'", name);
        while ((addr & 0xff000000U) == 0) {
            addr <<= 8;
            mask <<= 8;
        }
        return addr4_test(cs, addr, mask, proto, dir, q.addr);

    case QU_DEFAULT:
    case QU_HOST:
        if (proto == QU_LINK) {
            uint8_t eaddr[6];
            if (!nm_ether(name, eaddr))
                fail(cs, "unknown ether host '%s'", name);
            return mac_test(cs, eaddr, dir, "ethernet");
        }
        n = nm_host(name, addrs, 16);
        if (n == 0)
            fail(cs, "unknown host '%s'", name);
        memset(mask128, 0xff, sizeof(mask128));
        for (i = 0; i < n; i++) {
            if (addrs[i].af == 4) {
                uint32_t a;
                if (proto == QU_IPV6) continue;
                a = ((uint32_t)addrs[i].a[0] << 24) | ((uint32_t)addrs[i].a[1] << 16) |
                    ((uint32_t)addrs[i].a[2] << 8) | addrs[i].a[3];
                tmp = addr4_test(cs, a, 0xffffffffU,
                               proto == QU_DEFAULT ? QU_DEFAULT : proto, dir, q.addr);
            } else {
                if (proto == QU_IP || proto == QU_ARP || proto == QU_RARP) continue;
                tmp = addr6_test(cs, addrs[i].a, mask128,
                                proto == QU_DEFAULT ? QU_DEFAULT : proto, dir, q.addr);
            }
            if (have) b = bx_or(cs, b, tmp);
            else { b = tmp; have = 1; }
        }
        if (!have)
            fail(cs, "unknown host '%s'", name);
        return b;

    case QU_PORT: {
        int rp;
        test_t b4, b6;
        if (proto != QU_DEFAULT && proto != QU_UDP && proto != QU_TCP &&
            proto != QU_SCTP)
            fail(cs, "illegal qualifier of 'port'");
        if (!nm_port(name, &port, &rp))
            fail(cs, "unknown port '%s'", name);
        if (proto == QU_UDP) {
            if (rp == NP_TCP)
                fail(cs, "port '%s' is tcp", name);
            else if (rp == NP_SCTP)
                fail(cs, "port '%s' is sctp", name);
            else
                rp = NP_UDP;
        } else if (proto == QU_TCP) {
            if (rp == NP_UDP)
                fail(cs, "port '%s' is udp", name);
            else if (rp == NP_SCTP)
                fail(cs, "port '%s' is sctp", name);
            else
                rp = NP_TCP;
        } else if (proto == QU_SCTP) {
            if (rp == NP_UDP)
                fail(cs, "port '%s' is udp", name);
            else if (rp == NP_TCP)
                fail(cs, "port '%s' is tcp", name);
            else
                rp = NP_SCTP;
        }
        if (port > 65535)
            fail(cs, "illegal port number %d > 65535", port);
        if (rp == 0) rp = -1;
        b4 = psel4(cs, (uint32_t)port, rp, dir);
        b6 = psel6(cs, (uint32_t)port, rp, dir);
        return bx_or(cs, b6, b4);
    }

    case QU_PORTRANGE: {
        int rp, p1, p2;
        test_t b4, b6;
        if (proto != QU_DEFAULT && proto != QU_UDP && proto != QU_TCP &&
            proto != QU_SCTP)
            fail(cs, "illegal qualifier of 'portrange'");
        if (!nm_portrange(name, &p1, &p2, &rp))
            fail(cs, "unknown port in range '%s'", name);
        if (proto == QU_UDP) {
            if (rp == NP_TCP)
                fail(cs, "port in range '%s' is tcp", name);
            else if (rp == NP_SCTP)
                fail(cs, "port in range '%s' is sctp", name);
            else
                rp = NP_UDP;
        } else if (proto == QU_TCP) {
            if (rp == NP_UDP)
                fail(cs, "port in range '%s' is udp", name);
            else if (rp == NP_SCTP)
                fail(cs, "port in range '%s' is sctp", name);
            else
                rp = NP_TCP;
        } else if (proto == QU_SCTP) {
            if (rp == NP_UDP)
                fail(cs, "port in range '%s' is udp", name);
            else if (rp == NP_TCP)
                fail(cs, "port in range '%s' is tcp", name);
            else
                rp = NP_SCTP;
        }
        if (p1 > 65535)
            fail(cs, "illegal port number %d > 65535", p1);
        if (p2 > 65535)
            fail(cs, "illegal port number %d > 65535", p2);
        if (rp == 0) rp = -1;
        b4 = prsel4(cs, (uint32_t)p1, (uint32_t)p2, rp, dir);
        b6 = prsel6(cs, (uint32_t)p1, (uint32_t)p2, rp, dir);
        return bx_or(cs, b6, b4);
    }

    case QU_GATEWAY:
        fail(cs, "'gateway' not supported in this configuration");

    case QU_PROTO:
        real_proto = name_to_protonum(cs, name, proto);
        return nl_proto_test(cs, (uint32_t)real_proto, proto, dir);

    case QU_PROTOCHAIN:
        real_proto = name_to_protonum(cs, name, proto);
        return chain_test(cs, (uint32_t)real_proto, proto);

    case QU_UNDEF:
        fail(cs, "illegal qualifier");
    }
    fail(cs, "bogus qualifier");
    return always_no(cs);
}

test_t id_arcnet(ctx_t *cs, const char *s, sel_t q)
{
    (void)s;
    (void)q;
    fail(cs, "ARCnet address used in non-arc expression");
    return always_no(cs);
}
