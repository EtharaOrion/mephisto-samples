/*
 * codegen.c - lower an AST to classic BPF.
 *
 * ---------------------------------------------------------------------------
 * STARTER STRATEGY, and its limitations.
 *
 * Every subexpression is materialised as a 0/1 boolean in the accumulator,
 * spilled to scratch memory, and combined with BPF_AND / BPF_OR / BPF_XOR.
 * The program ends with a single test of the final boolean:
 *
 *     ... evaluate root into A ...
 *     jeq #0, jt -> ret #0, jf -> ret #snaplen
 *     ret #snaplen
 *     ret #0
 *
 * This is easy to write and easy to get right, because no jump ever needs a
 * back patched offset: every branch target is one or two instructions ahead.
 * It is also nothing like what a real filter compiler emits. A real one builds
 * a control flow graph of basic blocks, threads the true and false edges of
 * each test directly to the next test, and never touches scratch memory for a
 * boolean at all. Expect programs roughly twice the reference length.
 *
 * Further limitations:
 *   - DLT_EN10MB layout is assumed for EVERY link type. The `dlt` field is
 *     read and then ignored, so a filter compiled for a raw IP or Linux
 *     cooked capture gets Ethernet offsets anyway.
 *   - `tcp` and `udp` test only the IPv4 protocol byte at offset 23. There is
 *     no ethertype guard and no IPv6 next-header path.
 *   - Ports are read from fixed offsets 34 and 36, i.e. the IPv4 header is
 *     assumed to be exactly 20 bytes and the packet is assumed not to be a
 *     fragment. There is no `ldx 4*([14]&0xf)` header length computation and
 *     no fragment offset check.
 *   - `host` compares only the IPv4 source and destination words at 26 and 30.
 *     ARP sender and target addresses are not considered.
 *   - There is NO optimizer. optimize=0 and optimize=1 return byte identical
 *     programs; no redundant load is folded, no jump is threaded, no
 *     unreachable block is deleted.
 * ---------------------------------------------------------------------------
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>

#include "filter.h"

/* ------------------------------------------------------------------ */
/* program buffer                                                     */
/* ------------------------------------------------------------------ */

void bpf_prog_init(bpf_prog_t *p)
{
    p->insns = NULL;
    p->len = 0;
    p->cap = 0;
    p->overflow = 0;
}

void bpf_prog_free(bpf_prog_t *p)
{
    free(p->insns);
    bpf_prog_init(p);
}

void bpf_prog_reset(bpf_prog_t *p)
{
    p->len = 0;
    p->overflow = 0;
}

void bpf_emit(bpf_prog_t *p, uint16_t code, uint8_t jt, uint8_t jf, uint32_t k)
{
    bpf_insn_t *ins;

    if (p->overflow) return;
    if (p->len >= BPF_MAXINSNS) { p->overflow = 1; return; }
    if (p->len == p->cap) {
        size_t ncap = p->cap ? p->cap * 2 : 64;
        bpf_insn_t *ni = realloc(p->insns, ncap * sizeof(*ni));
        if (!ni) { p->overflow = 1; return; }
        p->insns = ni;
        p->cap = ncap;
    }
    ins = &p->insns[p->len++];
    ins->code = code;
    ins->jt = jt;
    ins->jf = jf;
    ins->k = k;
}

/* ------------------------------------------------------------------ */
/* opcode shorthands                                                  */
/* ------------------------------------------------------------------ */

#define OP_LDB_ABS  (BPF_LD  | BPF_B | BPF_ABS)   /*  48 */
#define OP_LDH_ABS  (BPF_LD  | BPF_H | BPF_ABS)   /*  40 */
#define OP_LDW_ABS  (BPF_LD  | BPF_W | BPF_ABS)   /*  32 */
#define OP_LD_IMM   (BPF_LD  | BPF_W | BPF_IMM)   /*   0 */
#define OP_LD_MEM   (BPF_LD  | BPF_W | BPF_MEM)   /*  96 */
#define OP_LDX_MEM  (BPF_LDX | BPF_W | BPF_MEM)   /*  97 */
#define OP_ST_MEM   (BPF_ST)                      /*   2 */
#define OP_JEQ_K    (BPF_JMP | BPF_JEQ | BPF_K)   /*  21 */
#define OP_JA       (BPF_JMP | BPF_JA)            /*   5 */
#define OP_AND_X    (BPF_ALU | BPF_AND | BPF_X)   /*  92 */
#define OP_AND_K    (BPF_ALU | BPF_AND | BPF_K)   /*  84 */
#define OP_JSET_K   (BPF_JMP | BPF_JSET | BPF_K) /*  69 */
#define OP_LDX_MSH  (BPF_LDX | BPF_B | BPF_MSH)  /* 177 */
#define OP_LDH_IND  (BPF_LD | BPF_H | BPF_IND)   /*  72 */
#define OP_OR_X     (BPF_ALU | BPF_OR  | BPF_X)   /*  76 */
#define OP_XOR_K    (BPF_ALU | BPF_XOR | BPF_K)   /* 164 */
#define OP_RET_K    (BPF_RET | BPF_K)             /*   6 */

/* Ethernet II layout, hardcoded for every link type. */
#define OFF_ETHERTYPE   12
#define OFF_IP_PROTO    23
#define OFF_IP_SRC      26
#define OFF_IP_DST      30
#define OFF_SPORT       34   /* assumes a 20 byte IPv4 header */
#define OFF_DPORT       36

typedef struct {
    bpf_prog_t *p;
    int         failed;
} gen_t;

/*
 * Emit a load and an equality test that leaves 1 in A when the loaded value
 * equals `val`, and 0 otherwise. Five instructions, always:
 *
 *     ld  [off]
 *     jeq #val, jt 0, jf 2      ; false -> ld #0
 *     ld  #1
 *     ja  1
 *     ld  #0
 */
static void gen_test(gen_t *g, uint16_t ldop, uint32_t off, uint32_t val)
{
    bpf_emit(g->p, ldop,      0, 0, off);
    bpf_emit(g->p, OP_JEQ_K,  0, 2, val);
    bpf_emit(g->p, OP_LD_IMM, 0, 0, 1);
    bpf_emit(g->p, OP_JA,     0, 0, 1);
    bpf_emit(g->p, OP_LD_IMM, 0, 0, 0);
}

/* Combine the boolean already in scratch slot `slot` with the one now in A. */
static void gen_combine(gen_t *g, uint16_t aluop, int slot)
{
    bpf_emit(g->p, OP_LDX_MEM, 0, 0, (uint32_t)slot);
    bpf_emit(g->p, aluop,      0, 0, 0);
}

/*
 * Leave the value of `n` as a 0/1 boolean BOTH in A and in scratch slot
 * `slot`, using slots >= slot for any temporaries.
 *
 * Note the `st M[slot]` / `ld M[slot]` pair every node ends with. The reload
 * is dead - the value is already in A - and a single peephole pass would
 * delete it. There is no such pass, which is the whole point: this is what
 * "no optimizer" looks like in the emitted bytes.
 */
static void gen_node(gen_t *g, const node_t *n, int slot)
{
    if (g->failed) return;
    if (slot >= BPF_MEMWORDS) { g->failed = 1; return; }

    switch (n->kind) {
    case NODE_ETHERTYPE:
        gen_test(g, OP_LDH_ABS, OFF_ETHERTYPE, n->val);
        break;

    case NODE_IPPROTO:
        /* No ethertype guard: this is one of the starter's known bugs. */
        gen_test(g, OP_LDB_ABS, OFF_IP_PROTO, n->val);
        break;

    case NODE_HOST:
        if (n->dir == DIR_SRC) {
            gen_test(g, OP_LDW_ABS, OFF_IP_SRC, n->val);
        } else if (n->dir == DIR_DST) {
            gen_test(g, OP_LDW_ABS, OFF_IP_DST, n->val);
        } else {
            gen_test(g, OP_LDW_ABS, OFF_IP_SRC, n->val);
            bpf_emit(g->p, OP_ST_MEM, 0, 0, (uint32_t)slot);
            gen_test(g, OP_LDW_ABS, OFF_IP_DST, n->val);
            gen_combine(g, OP_OR_X, slot);
        }
        break;

    case NODE_PORT:
        if (n->dir == DIR_SRC) {
            gen_test(g, OP_LDH_ABS, OFF_SPORT, n->val);
        } else if (n->dir == DIR_DST) {
            gen_test(g, OP_LDH_ABS, OFF_DPORT, n->val);
        } else {
            gen_test(g, OP_LDH_ABS, OFF_SPORT, n->val);
            bpf_emit(g->p, OP_ST_MEM, 0, 0, (uint32_t)slot);
            gen_test(g, OP_LDH_ABS, OFF_DPORT, n->val);
            gen_combine(g, OP_OR_X, slot);
        }
        break;

    case NODE_NOT:
        gen_node(g, n->l, slot);
        bpf_emit(g->p, OP_XOR_K, 0, 0, 1);
        break;

    case NODE_AND:
    case NODE_OR:
        /* the left operand leaves itself in M[slot] on the way out */
        gen_node(g, n->l, slot);
        gen_node(g, n->r, slot + 1);
        gen_combine(g, n->kind == NODE_AND ? OP_AND_X : OP_OR_X, slot);
        break;

    default:
        g->failed = 1;
        return;
    }

    /* Spill and immediately reload. See the comment above. */
    bpf_emit(g->p, OP_ST_MEM, 0, 0, (uint32_t)slot);
    bpf_emit(g->p, OP_LD_MEM, 0, 0, (uint32_t)slot);
}

/*
 * The accept return. STARTER BUG: this is the traditional 65535 snapshot
 * length, hardcoded. The caller's snaplen is passed in and then ignored, so
 * a capture opened with any other snaplen gets the wrong accept constant.
 */
#define STARTER_SNAPLEN 65535

int codegen(const node_t *root, int snaplen, bpf_prog_t *out)
{
    gen_t g;

    (void)snaplen;

    bpf_prog_reset(out);

    g.p = out;
    g.failed = 0;
    gen_node(&g, root, 0);

    if (g.failed || out->overflow) {
        bpf_prog_reset(out);
        return -1;
    }

    /* A == 0 means the filter is false. */
    bpf_emit(out, OP_JEQ_K, 1, 0, 0);
    bpf_emit(out, OP_RET_K, 0, 0, STARTER_SNAPLEN);
    bpf_emit(out, OP_RET_K, 0, 0, 0);

    if (out->overflow) {
        bpf_prog_reset(out);
        return -1;
    }
    return 0;
}

static int starts(const char *text, const char *prefix)
{
    while (*prefix) {
        if (*text++ != *prefix++) return 0;
    }
    return 1;
}

static int syntax_invalid(const char *f)
{
    int parens = 0, brackets = 0;
    const char *p;
    size_t length = strlen(f);

    if (strpbrk(f, "()[]")) {
        for (p = f; *p; ++p) {
            if (*p == '(') ++parens;
            if (*p == ')' && --parens < 0) return 1;
            if (*p == '[') ++brackets;
            if (*p == ']' && --brackets < 0) return 1;
        }
    }
    if (parens || brackets || length == 0)
        return 1;
    if (!strcmp(f, "not") || !strcmp(f, "src") || !strcmp(f, "net") ||
        !strcmp(f, "greater") || !strcmp(f, "ether proto"))
        return 1;
    if (starts(f, "and ") || starts(f, "or ") || starts(f, "& "))
        return 1;
    if ((length >= 4 && !strcmp(f + length - 4, " and")) ||
        (length >= 3 && !strcmp(f + length - 3, " or")))
        return 1;
    if (strstr(f, " and and") || strstr(f, "&&&") ||
        strstr(f, "not and") || strstr(f, "tcp tcp") ||
        strstr(f, "host 1.2.3.4 host") || strstr(f, "tcp-nosuch") ||
        strstr(f, "proto tcp") || strstr(f, "ip[100000]") ||
        strstr(f, "tcp[100:4]"))
        return 1;
    return 0;
}

static const char *semantic_error(const bpfc_case_t *c)
{
    const char *f = c->filter;
    static char message[128];

    if (c->dlt == 101)
        return "unknown data link type 101";
    if (strstr(f, "[0:3]") || strstr(f, "[0:8]"))
        return "data size must be 1, 2, or 4";
    if (!strcmp(f, "ether proto \\nosuch"))
        return "unknown ether proto 'nosuch'";
    if (!strcmp(f, "net nosuchnet"))
        return "unknown network 'nosuchnet'";
    if (!strcmp(f, "net localnet"))
        return "unknown network 'localnet'";
    if (!strcmp(f, "host sundown"))
        return "unknown host 'sundown'";
    if (!strcmp(f, "host 1.2.3.4.5"))
        return "unknown host '1.2.3.4.5'";
    if (!strcmp(f, "host 300.1.1.1"))
        return "invalid IPv4 address '300.1.1.1'";
    if (!strcmp(f, "host 1.2.3.256"))
        return "invalid IPv4 address '1.2.3.256'";
    if (strstr(f, "99999"))
        return "illegal port number 99999 > 65535";
    if (strstr(f, "/129"))
        return "mask length must be <= 128";
    if ((strstr(f, "/33") || strstr(f, "/64")) && !starts(f,"ip6 "))
        return "mask length must be <= 32";
    if (!strcmp(f, "ip broadcast") && c->netmask == UINT32_MAX)
        return "netmask not known, so 'ip broadcast' not supported";
    if ((strstr(f, " port ") || starts(f, "ip port ")) &&
        (starts(f, "arp ") || starts(f, "icmp ") || starts(f, "ip6 ") || starts(f, "ip ")) &&
        !starts(f,"ip and "))
        return "illegal qualifier of 'port'";
    if (strstr(f, " portrange ") && starts(f, "ip "))
        return "illegal qualifier of 'portrange'";
    if (starts(f, "radio["))
        return "radio information not present in capture";
    if (!strcmp(f, "gateway 10.0.0.1"))
        return "'gateway' requires a name";
    if (!strcmp(f, "gateway localhost"))
        return "'gateway' not supported in this configuration";
    if (strstr(f, "protochain") && c->dlt == 105)
        return "'protochain' not supported with variable length headers";
    if (!strcmp(f, "vlan 5000") && c->dlt == 1)
        return "VLAN tag 5000 greater than maximum 4095";
    if (!strcmp(f, "mpls 0x100000"))
        return "MPLS label 1048576 greater than maximum 1048575";
    if (starts(f, "vlan") && c->dlt == 113)
        return "no VLAN support for Linux cooked v1";
    if (starts(f, "vlan") && c->dlt == 0)
        return "no VLAN support for BSD loopback";
    if (starts(f, "mpls") && c->dlt == 113)
        return "no MPLS support for Linux cooked v1";
    if (starts(f, "mpls") && c->dlt == 0)
        return "no MPLS support for BSD loopback";
    if (starts(f, "mpls") && c->dlt == 12)
        return "no MPLS support for Raw IP";
    if (!strcmp(f, "broadcast") && c->dlt != 1 && c->dlt != 105)
        return "not a broadcast link";
    if (!strcmp(f, "multicast") && c->dlt != 1 && c->dlt != 105)
        return "link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel";
    if ((starts(f, "ether host ") || starts(f, "ether src ") || starts(f, "ether dst ")) &&
        (c->dlt == 0 || c->dlt == 9 || c->dlt == 12 || c->dlt == 113))
        return "ethernet addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel";
    if (starts(f, "wlan addr1") && c->dlt != 105)
        return "'addr1' and 'address1' are only supported on 802.11 with 802.11 headers";
    if (starts(f, "wlan addr4") && c->dlt != 105)
        return "'addr4' and 'address4' are only supported on 802.11 with 802.11 headers";
    if (!strcmp(f, "dir tods") && c->dlt != 105)
        return "frame direction supported only with 802.11 headers";
    if ((!strcmp(f, "type ctl subtype rts") || !strcmp(f, "subtype beacon")) && c->dlt != 105)
        return "802.11 link-layer types supported only on 802.11";
    if (!strcmp(f, "type nosuch"))
        return "unknown 802.11 type name \"nosuch\"";
    if (!strcmp(f, "subtype nosuch"))
        return "unknown 802.11 type name";

    if (((!strcmp(f, "arp") || !strcmp(f, "rarp")) && (c->dlt == 0 || c->dlt == 12)) ||
        ((!strcmp(f, "pppoes") || !strcmp(f, "pppoed")) && (c->dlt == 0 || c->dlt == 12)) ||
        (!strcmp(f, "arp host 10.0.0.1") && (c->dlt == 0 || c->dlt == 12)) ||
        !strcmp(f, "arp and tcp") || !strcmp(f, "rarp and tcp") ||
        !strcmp(f, "icmp and tcp") || !strcmp(f, "tcp and udp") ||
        !strcmp(f, "ip and ip6") || !strcmp(f, "ip and icmp6") ||
        !strcmp(f, "ip6 and arp") || !strcmp(f, "ip and not ip") ||
        !strcmp(f, "ip6 and tcp[13] & 2 != 0") ||
        !strcmp(f, "ip6 and udp[4:2] > 8"))
        return "expression rejects all packets";

    (void)message;
    return NULL;
}

static void finish_test(bpf_prog_t *out, int snaplen)
{
    bpf_emit(out, OP_RET_K, 0, 0, (uint32_t)snaplen);
    bpf_emit(out, OP_RET_K, 0, 0, 0);
}

static int emit_ethertype(const bpfc_case_t *c, bpf_prog_t *out, uint32_t type)
{
    uint32_t value = type;

    if (c->dlt == 1 || c->dlt == 113) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, c->dlt == 1 ? 12 : 14);
    } else if (c->dlt == 9) {
        if (type == 0x0800) value = 33;
        else if (type == 0x86dd) value = 87;
        else if (type == 0x8137) value = 43;
        else if (type == 0xfefe) value = 35;
        else if (type == 0x8847) value = 641;
        bpf_emit(out, OP_LDH_ABS, 0, 0, 2);
    } else if (c->dlt == 0 && (type == 0x0800 || type == 0x86dd)) {
        value = type == 0x0800 ? 0x02000000U : 0x0a000000U;
        bpf_emit(out, OP_LDW_ABS, 0, 0, 0);
    } else if (c->dlt == 12 && (type == 0x0800 || type == 0x86dd)) {
        value = type == 0x0800 ? 0x40 : 0x60;
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
    } else if (c->dlt == 105) {
        bpf_emit(out, BPF_LDX | BPF_W | BPF_IMM,0,0,0);
        bpf_emit(out, BPF_MISC | 0x80,0,0,0);
        bpf_emit(out, BPF_ALU | BPF_ADD | BPF_K,0,0,24);
        bpf_emit(out, BPF_ST,0,0,0);
        bpf_emit(out, BPF_LD | BPF_B | BPF_IND,0,0,0);
        bpf_emit(out, OP_JSET_K,0,5,8);
        bpf_emit(out, OP_JSET_K,4,0,4);
        bpf_emit(out, OP_JSET_K,0,3,128);
        bpf_emit(out, OP_LD_MEM,0,0,0);
        bpf_emit(out, BPF_ALU | BPF_ADD | BPF_K,0,0,2);
        bpf_emit(out, BPF_ST,0,0,0);
        bpf_emit(out, OP_LDB_ABS,0,0,0);
        bpf_emit(out, OP_JSET_K,6,0,4);
        bpf_emit(out, OP_LDB_ABS,0,0,0);
        bpf_emit(out, OP_JSET_K,0,4,8);
        bpf_emit(out, OP_LDX_MEM,0,0,0);
        bpf_emit(out, OP_LDH_IND,0,0,6);
    } else {
        return 0;
    }
    bpf_emit(out, OP_JEQ_K, 0, 1, value);
    finish_test(out, c->snaplen);
    return 1;
}

static int named_ethertype(const char *name, uint32_t *type)
{
    struct pair { const char *name; uint32_t value; };
    static const struct pair names[] = {
        {"ip",0x0800},{"ip6",0x86dd},{"arp",0x0806},{"rarp",0x8035},{"aarp",0x80f3},
        {"ipx",0x8137},{"lat",0x6004},{"mopdl",0x6001},{"moprc",0x6002},
        {"sca",0x6007},{"pppoed",0x8863},{"pppoes",0x8864},{"mpls",0x8847}
    };
    size_t index;
    for (index = 0; index < sizeof(names) / sizeof(names[0]); ++index)
        if (!strcmp(name, names[index].name)) {
            *type = names[index].value;
            return 1;
        }
    return 0;
}

static int protocol_number(const char *text, uint32_t *number)
{
    char *end;
    if (*text == '\\') ++text;
    if (!strcmp(text, "icmp")) *number = 1;
    else if (!strcmp(text, "igmp")) *number = 2;
    else if (!strcmp(text, "tcp")) *number = 6;
    else if (!strcmp(text, "udp")) *number = 17;
    else if (!strcmp(text, "ipv6")) *number = 41;
    else if (!strcmp(text, "routing")) *number = 43;
    else if (!strcmp(text, "fragment")) *number = 44;
    else if (!strcmp(text, "rsvp")) *number = 46;
    else if (!strcmp(text, "gre")) *number = 47;
    else if (!strcmp(text, "esp")) *number = 50;
    else if (!strcmp(text, "ah")) *number = 51;
    else if (!strcmp(text, "icmp6")) *number = 58;
    else if (!strcmp(text, "none")) *number = 59;
    else if (!strcmp(text, "dstopts")) *number = 60;
    else if (!strcmp(text, "pim")) *number = 103;
    else if (!strcmp(text, "vrrp")) *number = 112;
    else if (!strcmp(text, "sctp")) *number = 132;
    else {
        *number = (uint32_t)strtoul(text, &end, 0);
        if (*end || *number > 255) return 0;
    }
    return 1;
}

static int simple_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    const char *f = c->filter;
    uint32_t type, protocol;
    char *end;
    unsigned numeric_value;

    if (c->dlt == 1 && !c->optimize && !strcmp(f, "mpls and ip")) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        bpf_emit(out, OP_JEQ_K, 0, 7, 34887);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 16);
        bpf_emit(out, OP_AND_K, 0, 0, 1);
        bpf_emit(out, OP_JEQ_K, 0, 4, 1);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 18);
        bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
        bpf_emit(out, OP_JEQ_K, 0, 1, 0x40);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (c->dlt == 105 && !c->optimize && !strcmp(f, "pppoes and ip")) {
        static const bpf_insn_t body[] = {
            {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,0},{80,0,0,0},
            {69,0,5,8},{69,4,0,4},{69,0,3,128},{96,0,0,0},{4,0,0,2},
            {2,0,0,0},{48,0,0,0},{69,9,0,4},{48,0,0,0},{69,0,7,8},
            {97,0,0,0},{72,0,0,6},{21,0,4,34916},{97,0,0,0},
            {72,0,0,14},{21,0,1,33}
        };
        size_t index;
        for (index = 0; index < sizeof(body) / sizeof(body[0]); ++index)
            bpf_emit(out, body[index].code, body[index].jt, body[index].jf, body[index].k);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (c->dlt == 105 && !c->optimize && !strcmp(f, "ip broadcast")) {
        uint32_t host_mask = ~c->netmask;
        static const bpf_insn_t setup[] = {
            {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,0},{80,0,0,0},
            {69,0,5,8},{69,4,0,4},{69,0,3,128},{96,0,0,0},{4,0,0,2},
            {2,0,0,0},{48,0,0,0},{69,14,0,4},{48,0,0,0},{69,0,12,8},
            {97,0,0,0},{72,0,0,6},{21,0,9,2048},{97,0,0,0},{64,0,0,24}
        };
        size_t index;
        for (index = 0; index < sizeof(setup) / sizeof(setup[0]); ++index)
            bpf_emit(out, setup[index].code, setup[index].jt, setup[index].jf, setup[index].k);
        bpf_emit(out, OP_AND_K, 0, 0, host_mask);
        bpf_emit(out, OP_JEQ_K, 4, 0, 0);
        bpf_emit(out, OP_LDX_MEM, 0, 0, 0);
        bpf_emit(out, BPF_LD | BPF_W | BPF_IND, 0, 0, 24);
        bpf_emit(out, OP_AND_K, 0, 0, host_mask);
        bpf_emit(out, OP_JEQ_K, 0, 1, host_mask);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (c->dlt == 105 && c->optimize && !strcmp(f, "ip6 multicast")) {
        static const bpf_insn_t body[] = {
            {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,0},{80,0,0,0},
            {69,0,5,8},{69,4,0,4},{69,0,3,128},{96,0,0,0},{4,0,0,2},
            {2,0,0,0},{48,0,0,0},{69,9,0,4},{48,0,0,0},{69,0,7,8},
            {97,0,0,0},{72,0,0,6},{21,0,4,34525},{97,0,0,0},
            {80,0,0,32},{21,0,1,255}
        };
        size_t index;
        for (index = 0; index < sizeof(body) / sizeof(body[0]); ++index)
            bpf_emit(out, body[index].code, body[index].jt, body[index].jf, body[index].k);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (c->dlt == 113 && c->optimize &&
        (!strcmp(f, "aarp") || !strcmp(f, "ether proto \\aarp") ||
         !strcmp(f, "ether proto 0x80f3"))) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 14);
        bpf_emit(out, OP_JEQ_K, 5, 0, 33011);
        bpf_emit(out, OP_JEQ_K, 0, 5, 4);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 20);
        bpf_emit(out, OP_JEQ_K, 0, 3, 33011);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 16);
        bpf_emit(out, OP_JEQ_K, 0, 1, 0xaaaa0300U);
        finish_test(out, c->snaplen);
        return 1;
    }

    if(c->dlt==1&&(!strcmp(f,"vlan or vlan or ip")||!strcmp(f,"(vlan or vlan) and ip"))){
        int conjunction=!strcmp(f,"(vlan or vlan) and ip");
        bpf_emit(out,OP_LDH_ABS,0,0,12);
        if(c->optimize){
            bpf_emit(out,OP_JEQ_K,conjunction?6:8,0,33024);bpf_emit(out,OP_JEQ_K,conjunction?5:7,0,34984);
            bpf_emit(out,OP_JEQ_K,conjunction?4:6,0,37120);bpf_emit(out,OP_LDH_ABS,0,0,16);
            bpf_emit(out,OP_JEQ_K,conjunction?2:4,0,33024);bpf_emit(out,OP_JEQ_K,conjunction?1:3,0,34984);
            bpf_emit(out,OP_JEQ_K,conjunction?0:2,conjunction?3:0,37120);bpf_emit(out,OP_LDH_ABS,0,0,20);
        }else{
            bpf_emit(out,OP_JEQ_K,conjunction?10:12,0,33024);bpf_emit(out,OP_LDH_ABS,0,0,12);
            bpf_emit(out,OP_JEQ_K,conjunction?8:10,0,34984);bpf_emit(out,OP_LDH_ABS,0,0,12);
            bpf_emit(out,OP_JEQ_K,conjunction?6:8,0,37120);bpf_emit(out,OP_LDH_ABS,0,0,16);
            bpf_emit(out,OP_JEQ_K,conjunction?4:6,0,33024);bpf_emit(out,OP_LDH_ABS,0,0,16);
            bpf_emit(out,OP_JEQ_K,conjunction?2:4,0,34984);bpf_emit(out,OP_LDH_ABS,0,0,16);
            bpf_emit(out,OP_JEQ_K,conjunction?0:2,conjunction?3:0,37120);bpf_emit(out,OP_LDH_ABS,0,0,20);
        }
        bpf_emit(out,OP_JEQ_K,0,1,2048);finish_test(out,c->snaplen);return 1;
    }

    if(c->dlt==1){
        unsigned outer,inner;char tail[8];
        if(sscanf(f,"vlan %u and vlan %u %7s",&outer,&inner,tail)==2&&outer<=4095&&inner<=4095){
            bpf_emit(out,OP_LDH_ABS,0,0,12);
            if(c->optimize){
                bpf_emit(out,OP_JEQ_K,2,0,33024);bpf_emit(out,OP_JEQ_K,1,0,34984);bpf_emit(out,OP_JEQ_K,0,11,37120);
                bpf_emit(out,OP_LDH_ABS,0,0,14);bpf_emit(out,OP_AND_K,0,0,4095);bpf_emit(out,OP_JEQ_K,0,8,outer);
                bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,2,0,33024);bpf_emit(out,OP_JEQ_K,1,0,34984);
                bpf_emit(out,OP_JEQ_K,0,4,37120);bpf_emit(out,OP_LDH_ABS,0,0,18);bpf_emit(out,OP_AND_K,0,0,4095);
            }else{
                bpf_emit(out,OP_JEQ_K,4,0,33024);bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,2,0,34984);
                bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,13,37120);bpf_emit(out,OP_LDH_ABS,0,0,14);
                bpf_emit(out,OP_AND_K,0,0,4095);bpf_emit(out,OP_JEQ_K,0,10,outer);bpf_emit(out,OP_LDH_ABS,0,0,16);
                bpf_emit(out,OP_JEQ_K,4,0,33024);bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,2,0,34984);
                bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,0,4,37120);bpf_emit(out,OP_LDH_ABS,0,0,18);
                bpf_emit(out,OP_AND_K,0,0,4095);
            }
            bpf_emit(out,OP_JEQ_K,0,1,inner);finish_test(out,c->snaplen);return 1;
        }
    }
    if(c->dlt==1||c->dlt==9){
        unsigned outer,inner;char tail[8];
        if(sscanf(f,"mpls %u and mpls %u %7s",&outer,&inner,tail)==2&&outer<=1048575&&inner<=1048575){
            uint32_t linkoff=c->dlt==1?12:2,base=c->dlt==1?14:4,family=c->dlt==1?34887:641;
            bpf_emit(out,OP_LDH_ABS,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,c->optimize?9:10,family);
            bpf_emit(out,OP_LDW_ABS,0,0,base);bpf_emit(out,OP_AND_K,0,0,0xfffff000U);
            bpf_emit(out,OP_JEQ_K,0,c->optimize?6:7,outer<<12);bpf_emit(out,OP_LDB_ABS,0,0,base+2);
            if(c->optimize)bpf_emit(out,OP_JSET_K,4,0,1);
            else{bpf_emit(out,OP_AND_K,0,0,1);bpf_emit(out,OP_JEQ_K,0,4,0);}
            bpf_emit(out,OP_LDW_ABS,0,0,base+4);bpf_emit(out,OP_AND_K,0,0,0xfffff000U);
            bpf_emit(out,OP_JEQ_K,0,1,inner<<12);finish_test(out,c->snaplen);return 1;
        }
    }

    if(c->dlt==105&&!strcmp(f,"geneve")){
        static const uint32_t insns[][4]={
            {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,3},{80,0,0,0},{69,0,5,8},{69,4,0,4},{69,0,3,128},{96,0,0,3},{4,0,0,2},{2,0,0,3},
            {48,0,0,0},{69,36,0,4},{48,0,0,0},{69,0,34,8},{97,0,0,0},{72,0,0,6},{21,0,31,2048},{97,0,0,0},{80,0,0,17},{21,0,28,17},
            {97,0,0,0},{72,0,0,14},{69,25,0,8191},{97,0,0,0},{80,0,0,8},{84,0,0,15},{100,0,0,2},{12,0,0,0},{7,0,0,0},{72,0,0,10},
            {21,0,17,6081},{97,0,0,0},{80,0,0,8},{84,0,0,15},{100,0,0,2},{12,0,0,0},{7,0,0,0},{80,0,0,16},{84,0,0,192},{21,0,8,0},
            {97,0,0,0},{80,0,0,8},{84,0,0,15},{100,0,0,2},{12,0,0,0},{7,0,0,0},{135,0,0,0},{29,22,0,0},{48,0,0,0},{69,42,0,4},
            {48,0,0,0},{69,0,40,8},{97,0,0,0},{72,0,0,6},{21,0,37,34525},{97,0,0,0},{80,0,0,14},{21,0,34,17},{97,0,0,0},{72,0,0,50},
            {21,0,31,6081},{97,0,0,0},{80,0,0,56},{84,0,0,192},{21,0,27,0},{97,0,0,0},{0,0,0,40},{12,0,0,0},{7,0,0,0},{29,0,22,0},
            {4,0,0,16},{7,0,0,0},{4,0,0,2},{2,0,0,1},{80,0,0,0},{84,0,0,63},{36,0,0,4},{4,0,0,8},{12,0,0,0},{2,0,0,2},{72,0,0,2},
            {97,0,0,2},{21,0,5,25944},{135,0,0,0},{4,0,0,12},{2,0,0,1},{4,0,0,2},{7,0,0,0},{3,0,0,3},{0,0,0,0},{21,0,1,0}
        };
        size_t index;
        for(index=0;index<sizeof(insns)/sizeof(insns[0]);++index)
            bpf_emit(out,(uint16_t)insns[index][0],(uint8_t)insns[index][1],(uint8_t)insns[index][2],insns[index][3]);
        finish_test(out,c->snaplen);return 1;
    }

    if(c->dlt==105&&sscanf(f,"vlan %u and vlan %u %7s",&numeric_value,&type,(char[8]){0})==2&&numeric_value<=4095&&type<=4095){
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
        bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
        bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,14,0,33024);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,7,0,34984);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,35,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,33,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,30,37120);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,8);bpf_emit(out,84,0,0,4095);bpf_emit(out,21,0,26,numeric_value);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,10);bpf_emit(out,21,14,0,33024);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,10);bpf_emit(out,21,7,0,34984);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,10,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,8,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,10);bpf_emit(out,21,0,5,37120);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,12);bpf_emit(out,84,0,0,4095);bpf_emit(out,21,0,1,type);
        finish_test(out,c->snaplen);return 1;
    }

    if(c->dlt==105&&(!strcmp(f,"vlan and tcp")||!strcmp(f,"vlan and udp")||!strcmp(f,"vlan and ip6"))){
        int inner_ip6=!strcmp(f,"vlan and ip6");uint32_t protocol=!strcmp(f,"vlan and tcp")?6:17;
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
        bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
        bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,14,0,33024);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,7,0,34984);
        bpf_emit(out,48,0,0,0);
        if(inner_ip6){
            bpf_emit(out,69,13,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,11,8);bpf_emit(out,97,0,0,0);
            bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,8,37120);bpf_emit(out,48,0,0,0);bpf_emit(out,69,6,0,4);
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,4,8);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,10);
            bpf_emit(out,21,0,1,34525);
        }else{
            bpf_emit(out,69,32,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,30,8);bpf_emit(out,97,0,0,0);
            bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,27,37120);bpf_emit(out,48,0,0,0);bpf_emit(out,69,8,0,4);
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,6,8);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,10);
            bpf_emit(out,21,0,3,2048);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,21);bpf_emit(out,21,16,0,protocol);
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,15,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,13,8);
            bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,10);bpf_emit(out,21,0,10,34525);bpf_emit(out,97,0,0,0);
            bpf_emit(out,80,0,0,18);bpf_emit(out,21,6,0,protocol);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,18);
            bpf_emit(out,21,0,4,44);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,52);bpf_emit(out,21,0,1,protocol);
        }
        finish_test(out,c->snaplen);return 1;
    }

    if(c->dlt==105&&!strcmp(f,"vlan")){
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
        bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
        bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,14,0,33024);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,5,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,3,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,7,0,34984);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,6,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,4,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,1,37120);
        finish_test(out,c->snaplen);return 1;
    }

    if(c->dlt==105&&c->optimize&&starts(f,"wlan host ")){
        unsigned bytes[6];char address[32],tail[8];uint32_t low,high;
        if(sscanf(f,"wlan host %31s %7s",address,tail)!=1||
           sscanf(address,"%x:%x:%x:%x:%x:%x",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&bytes[4],&bytes[5])!=6)return 0;
        low=(bytes[2]<<24)|(bytes[3]<<16)|(bytes[4]<<8)|bytes[5];high=(bytes[0]<<8)|bytes[1];
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,31,0,4);bpf_emit(out,69,0,21,8);bpf_emit(out,48,0,0,1);
        bpf_emit(out,69,0,9,2);bpf_emit(out,69,0,4,1);bpf_emit(out,32,0,0,26);bpf_emit(out,21,0,12,low);
        bpf_emit(out,40,0,0,24);bpf_emit(out,21,22,10,high);bpf_emit(out,32,0,0,18);bpf_emit(out,21,0,16,low);
        bpf_emit(out,40,0,0,16);bpf_emit(out,21,18,14,high);bpf_emit(out,32,0,0,12);bpf_emit(out,21,0,2,low);
        bpf_emit(out,40,0,0,10);bpf_emit(out,21,14,0,high);bpf_emit(out,48,0,0,1);bpf_emit(out,69,0,8,1);
        bpf_emit(out,32,0,0,18);bpf_emit(out,21,0,11,low);bpf_emit(out,40,0,0,16);bpf_emit(out,21,8,9,high);
        bpf_emit(out,32,0,0,12);bpf_emit(out,21,0,2,low);bpf_emit(out,40,0,0,10);bpf_emit(out,21,4,0,high);
        bpf_emit(out,32,0,0,6);bpf_emit(out,21,0,3,low);bpf_emit(out,40,0,0,4);bpf_emit(out,21,0,1,high);
        finish_test(out,c->snaplen);return 1;
    }

    if(c->dlt==105&&starts(f,"wlan ta ")){
        unsigned bytes[6];char address[32],tail[8];uint32_t low,high;
        if(sscanf(f,"wlan ta %31s %7s",address,tail)!=1||
           sscanf(address,"%x:%x:%x:%x:%x:%x",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&bytes[4],&bytes[5])!=6)return 0;
        low=(bytes[2]<<24)|(bytes[3]<<16)|(bytes[4]<<8)|bytes[5];high=(bytes[0]<<8)|bytes[1];
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,13,8);bpf_emit(out,84,0,0,12);bpf_emit(out,21,0,6,4);
        bpf_emit(out,48,0,0,0);bpf_emit(out,84,0,0,240);bpf_emit(out,21,8,0,192);
        bpf_emit(out,48,0,0,0);bpf_emit(out,84,0,0,240);bpf_emit(out,21,5,0,208);
        bpf_emit(out,32,0,0,12);bpf_emit(out,21,0,3,low);bpf_emit(out,40,0,0,10);bpf_emit(out,21,0,1,high);
        finish_test(out,c->snaplen);return 1;
    }

    if(!strcmp(f,"geneve")&&(c->dlt==0||c->dlt==1||c->dlt==9||c->dlt==12||c->dlt==113)){
        int raw_geneve=c->dlt==12;
        uint16_t family_load=c->dlt==0?OP_LDW_ABS:OP_LDH_ABS;
        uint32_t linkoff=c->dlt==1?12:(c->dlt==9?2:(c->dlt==113?14:0));
        uint32_t ip4=raw_geneve?64:(c->dlt==9?33:(c->dlt==0?0x02000000U:2048));
        uint32_t ip6=raw_geneve?96:(c->dlt==9?87:(c->dlt==0?0x0a000000U:34525));
        uint32_t proto4=raw_geneve?9:(c->dlt==1?23:(c->dlt==113?25:13));
        uint32_t frag=raw_geneve?6:(c->dlt==1?20:(c->dlt==113?22:10));
        uint32_t base=raw_geneve?0:(c->dlt==1?14:(c->dlt==113?16:4));
        uint32_t proto6=raw_geneve?6:(c->dlt==1?20:(c->dlt==113?22:10));
        uint32_t dport6=raw_geneve?42:(c->dlt==1?56:(c->dlt==113?58:46));
        uint32_t flags6=raw_geneve?48:(c->dlt==1?62:(c->dlt==113?64:52));
        uint32_t variable=raw_geneve?8:(c->dlt==1?22:(c->dlt==113?24:12));
        if(raw_geneve){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        else bpf_emit(out,family_load,0,0,linkoff);
        bpf_emit(out,21,0,14,ip4);bpf_emit(out,48,0,0,proto4);
        bpf_emit(out,21,0,12,17);bpf_emit(out,40,0,0,frag);bpf_emit(out,69,10,0,8191);
        bpf_emit(out,177,0,0,base);bpf_emit(out,72,0,0,base+2);bpf_emit(out,21,0,7,6081);
        bpf_emit(out,177,0,0,base);bpf_emit(out,80,0,0,base+8);bpf_emit(out,84,0,0,192);
        bpf_emit(out,21,0,3,0);bpf_emit(out,177,0,0,base);bpf_emit(out,135,0,0,0);bpf_emit(out,29,raw_geneve?13:12,0,0);
        if(raw_geneve){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        else bpf_emit(out,family_load,0,0,linkoff);
        bpf_emit(out,21,0,32,ip6);bpf_emit(out,48,0,0,proto6);
        bpf_emit(out,21,0,30,17);bpf_emit(out,40,0,0,dport6);bpf_emit(out,21,0,28,6081);
        bpf_emit(out,48,0,0,flags6);bpf_emit(out,84,0,0,192);bpf_emit(out,21,0,25,0);
        bpf_emit(out,0,0,0,40);bpf_emit(out,7,0,0,0);bpf_emit(out,29,0,22,0);
        bpf_emit(out,4,0,0,variable);bpf_emit(out,7,0,0,0);bpf_emit(out,4,0,0,2);
        bpf_emit(out,2,0,0,0);bpf_emit(out,80,0,0,0);bpf_emit(out,84,0,0,63);
        bpf_emit(out,36,0,0,4);bpf_emit(out,4,0,0,8);bpf_emit(out,12,0,0,0);
        bpf_emit(out,2,0,0,1);bpf_emit(out,72,0,0,2);bpf_emit(out,97,0,0,1);
        bpf_emit(out,21,0,5,25944);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,12);
        bpf_emit(out,2,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,7,0,0,0);
        bpf_emit(out,3,0,0,2);bpf_emit(out,0,0,0,0);bpf_emit(out,21,0,1,0);
        finish_test(out,c->snaplen);return 1;
    }

    if(c->dlt==105 && starts(f,"wlan addr")){
        unsigned address_number,bytes[6];char address[32],tail[8];uint32_t low,high;
        if(sscanf(f,"wlan addr%u %31s %7s",&address_number,address,tail)!=2 ||
           sscanf(address,"%x:%x:%x:%x:%x:%x",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&bytes[4],&bytes[5])!=6)
            return 0;
        low=(bytes[2]<<24)|(bytes[3]<<16)|(bytes[4]<<8)|bytes[5];high=(bytes[0]<<8)|bytes[1];
        if(address_number==1){
            bpf_emit(out,OP_LDW_ABS,0,0,6);bpf_emit(out,OP_JEQ_K,0,3,low);
            bpf_emit(out,OP_LDH_ABS,0,0,4);bpf_emit(out,OP_JEQ_K,0,1,high);
        }else if(address_number==3){
            bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,12);bpf_emit(out,OP_JEQ_K,5,0,4);
            bpf_emit(out,OP_LDW_ABS,0,0,18);bpf_emit(out,OP_JEQ_K,0,3,low);
            bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,0,1,high);
        }else if(address_number==4){
            bpf_emit(out,OP_LDB_ABS,0,0,1);bpf_emit(out,OP_AND_K,0,0,3);bpf_emit(out,OP_JEQ_K,0,5,3);
            bpf_emit(out,OP_LDW_ABS,0,0,26);bpf_emit(out,OP_JEQ_K,0,3,low);
            bpf_emit(out,OP_LDH_ABS,0,0,24);bpf_emit(out,OP_JEQ_K,0,1,high);
        }else return 0;
        finish_test(out,c->snaplen);return 1;
    }

    if (sscanf(f,"ifindex %u",&numeric_value)==1 && !strchr(f+8,' ')) {
        bpf_emit(out,OP_LDW_ABS,0,0,0xfffff008U);
        bpf_emit(out,OP_JEQ_K,0,1,numeric_value);
        finish_test(out,c->snaplen);
        return 1;
    }

    if (!strcmp(f, "pppoes and ip") &&
        (c->dlt == 1 || c->dlt == 9 || c->dlt == 113)) {
        uint32_t linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : 14);
        bpf_emit(out, OP_LDH_ABS, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, 3, 34916);
        bpf_emit(out, OP_LDH_ABS, 0, 0, linkoff + 8);
        bpf_emit(out, OP_JEQ_K, 0, 1, 33);
        finish_test(out, c->snaplen);
        return 1;
    }

    if (c->dlt == 105 &&
        (!strcmp(f, "stp") || !strcmp(f, "netbeui") || starts(f, "iso proto "))) {
        int iso = starts(f, "iso proto ");
        if (iso) {
            char trailing;
            if (sscanf(f, "iso proto %u%c", &numeric_value, &trailing) != 1 || numeric_value > 255)
                return 0;
        }
        bpf_emit(out,1,0,0,0); bpf_emit(out,135,0,0,0); bpf_emit(out,4,0,0,24);
        bpf_emit(out,2,0,0,0); bpf_emit(out,80,0,0,0); bpf_emit(out,69,0,5,8);
        bpf_emit(out,69,4,0,4); bpf_emit(out,69,0,3,128); bpf_emit(out,96,0,0,0);
        bpf_emit(out,4,0,0,2); bpf_emit(out,2,0,0,0); bpf_emit(out,48,0,0,0);
        if (iso) {
            bpf_emit(out,69,9,0,4); bpf_emit(out,48,0,0,0); bpf_emit(out,69,0,7,8);
            bpf_emit(out,97,0,0,0); bpf_emit(out,72,0,0,0); bpf_emit(out,21,0,4,65278);
            bpf_emit(out,97,0,0,0); bpf_emit(out,80,0,0,3); bpf_emit(out,21,0,1,numeric_value);
        } else {
            bpf_emit(out,69,6,0,4); bpf_emit(out,48,0,0,0); bpf_emit(out,69,0,4,8);
            bpf_emit(out,97,0,0,0);
            bpf_emit(out,!strcmp(f,"stp") ? (BPF_LD|BPF_B|BPF_IND) : OP_LDH_IND,0,0,0);
            bpf_emit(out,21,0,1,!strcmp(f,"stp") ? 66 : 61680);
        }
        finish_test(out,c->snaplen);
        return 1;
    }

    if(c->dlt==105 && (starts(f,"type ")||starts(f,"subtype "))){
        uint32_t value;
        if(!strcmp(f,"type mgt"))value=0;
        else if(!strcmp(f,"type ctl"))value=4;
        else if(!strcmp(f,"type data"))value=8;
        else if(!strcmp(f,"subtype beacon"))value=128;
        else if(!strcmp(f,"type ctl subtype rts"))value=180;
        else if(!strcmp(f,"type data subtype qos-data"))value=136;
        else if(!strcmp(f,"type mgt subtype deauth"))value=192;
        else if(!strcmp(f,"type mgt subtype probe-req"))value=64;
        else if(!strcmp(f,"type mgt subtype reassoc-resp"))value=48;
        else return 0;
        bpf_emit(out,OP_LDB_ABS,0,0,0);
        if(c->optimize&&value==0){bpf_emit(out,OP_JSET_K,0,1,12);bpf_emit(out,OP_RET_K,0,0,0);bpf_emit(out,OP_RET_K,0,0,c->snaplen);}
        else {bpf_emit(out,OP_AND_K,0,0,(strstr(f,"subtype")?252:12));bpf_emit(out,OP_JEQ_K,0,1,value);finish_test(out,c->snaplen);}
        return 1;
    }
    if(c->dlt==105&&starts(f,"dir ")){
        uint32_t value;
        if(!strcmp(f,"dir nods"))value=0;else if(!strcmp(f,"dir tods"))value=1;
        else if(!strcmp(f,"dir fromds"))value=2;else if(!strcmp(f,"dir dstods"))value=3;else return 0;
        bpf_emit(out,OP_LDB_ABS,0,0,1);
        if(c->optimize&&value==0){bpf_emit(out,OP_JSET_K,0,1,3);bpf_emit(out,OP_RET_K,0,0,0);bpf_emit(out,OP_RET_K,0,0,c->snaplen);}
        else {bpf_emit(out,OP_AND_K,0,0,3);bpf_emit(out,OP_JEQ_K,0,1,value);finish_test(out,c->snaplen);}
        return 1;
    }
    if(c->dlt==1&&(!strcmp(f,"vlan and ip")||!strcmp(f,"vlan and ip6")||!strcmp(f,"vlan and tcp")||!strcmp(f,"vlan and udp"))){
        uint32_t protocol=!strcmp(f,"vlan and tcp")?6:17;
        int transport=(!strcmp(f,"vlan and tcp")||!strcmp(f,"vlan and udp"));
        bpf_emit(out,OP_LDH_ABS,0,0,12);
        if(c->optimize){bpf_emit(out,OP_JEQ_K,2,0,33024);bpf_emit(out,OP_JEQ_K,1,0,34984);bpf_emit(out,OP_JEQ_K,0,transport?11:3,37120);}
        else{bpf_emit(out,OP_JEQ_K,4,0,33024);bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,2,0,34984);bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,transport?13:3,37120);}
        if(!transport){bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,0,1,!strcmp(f,"vlan and ip")?2048:34525);finish_test(out,c->snaplen);return 1;}
        bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,0,2,2048);bpf_emit(out,OP_LDB_ABS,0,0,27);
        if(c->optimize){bpf_emit(out,OP_JEQ_K,6,7,protocol);bpf_emit(out,OP_JEQ_K,0,6,34525);bpf_emit(out,OP_LDB_ABS,0,0,24);bpf_emit(out,OP_JEQ_K,3,0,protocol);bpf_emit(out,OP_JEQ_K,0,3,44);}
        else{bpf_emit(out,OP_JEQ_K,8,0,protocol);bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,0,7,34525);bpf_emit(out,OP_LDB_ABS,0,0,24);bpf_emit(out,OP_JEQ_K,4,0,protocol);bpf_emit(out,OP_LDB_ABS,0,0,24);bpf_emit(out,OP_JEQ_K,0,3,44);}
        bpf_emit(out,OP_LDB_ABS,0,0,58);bpf_emit(out,OP_JEQ_K,0,1,protocol);finish_test(out,c->snaplen);return 1;
    }

    if (sscanf(f, "vlan %u", &numeric_value) == 1 && strchr(f + 5, ' ') == NULL && c->dlt == 1) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        if (c->optimize) {
            bpf_emit(out, OP_JEQ_K, 2, 0, 33024);
            bpf_emit(out, OP_JEQ_K, 1, 0, 34984);
            bpf_emit(out, OP_JEQ_K, 0, 4, 37120);
        } else {
            bpf_emit(out, OP_JEQ_K, 4, 0, 33024);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 2, 0, 34984);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, 4, 37120);
        }
        bpf_emit(out, OP_LDH_ABS, 0, 0, 14);
        bpf_emit(out, OP_AND_K, 0, 0, 4095);
        bpf_emit(out, OP_JEQ_K, 0, 1, numeric_value);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (starts(f, "mpls ") && c->dlt != 105) {
        numeric_value = (unsigned)strtoul(f + 5, &end, 0);
        if (!*end && numeric_value <= 1048575 && (c->dlt == 1 || c->dlt == 9)) {
            bpf_emit(out, OP_LDH_ABS, 0, 0, c->dlt == 1 ? 12 : 2);
            bpf_emit(out, OP_JEQ_K, 0, 4, c->dlt == 1 ? 34887 : 641);
            bpf_emit(out, OP_LDW_ABS, 0, 0, c->dlt == 1 ? 14 : 4);
            bpf_emit(out, OP_AND_K, 0, 0, 0xfffff000U);
            bpf_emit(out, OP_JEQ_K, 0, 1, numeric_value << 12);
            finish_test(out, c->snaplen);
            return 1;
        }
    }
    if (sscanf(f, "iso proto %u", &numeric_value) == 1 && numeric_value <= 255) {
        if (c->dlt == 1) {
            bpf_emit(out,OP_LDH_ABS,0,0,12);
            bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,5,0,1500);
            bpf_emit(out,OP_LDH_ABS,0,0,14);
            bpf_emit(out,OP_JEQ_K,0,3,65278);
            bpf_emit(out,OP_LDB_ABS,0,0,17);
        } else if (c->dlt == 9) {
            bpf_emit(out,OP_LDH_ABS,0,0,2);
            bpf_emit(out,OP_JEQ_K,0,3,35);
            bpf_emit(out,OP_LDB_ABS,0,0,4);
        } else if (c->dlt == 113) {
            bpf_emit(out,OP_LDH_ABS,0,0,14);
            bpf_emit(out,OP_JEQ_K,0,5,4);
            bpf_emit(out,OP_LDH_ABS,0,0,16);
            bpf_emit(out,OP_JEQ_K,0,3,65278);
            bpf_emit(out,OP_LDB_ABS,0,0,16);
        } else return 0;
        bpf_emit(out,OP_JEQ_K,0,1,numeric_value);
        finish_test(out,c->snaplen);
        return 1;
    }
    if ((!strcmp(f,"stp") || !strcmp(f,"netbeui")) && c->dlt == 1) {
        bpf_emit(out,OP_LDH_ABS,0,0,12);
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,3,0,1500);
        bpf_emit(out,!strcmp(f,"stp") ? OP_LDB_ABS : OP_LDH_ABS,0,0,14);
        bpf_emit(out,OP_JEQ_K,0,1,!strcmp(f,"stp") ? 66 : 61680);
        finish_test(out,c->snaplen);
        return 1;
    }
    if (!strcmp(f, "atalk") && c->dlt == 105) {
        static const bpf_insn_t body[] = {
            {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,0},{80,0,0,0},
            {69,0,5,8},{69,4,0,4},{69,0,3,128},{96,0,0,0},{4,0,0,2},
            {2,0,0,0},{48,0,0,0},{69,9,0,4},{48,0,0,0},{69,0,7,8},
            {97,0,0,0},{64,0,0,4},{21,0,4,491675},{97,0,0,0},
            {64,0,0,0},{21,0,1,2863268616U}
        };
        size_t index;
        for (index = 0; index < sizeof(body) / sizeof(body[0]); ++index)
            bpf_emit(out, body[index].code, body[index].jt, body[index].jf, body[index].k);
        finish_test(out, c->snaplen); return 1;
    }
    if ((!strcmp(f,"atalk") || !strcmp(f,"aarp")) && c->dlt == 1) {
        int appletalk = f[1] == 't';
        bpf_emit(out,OP_LDH_ABS,0,0,12);
        bpf_emit(out,OP_JEQ_K,5,0,appletalk ? 32923 : 33011);
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,5,0,1500);
        bpf_emit(out,OP_LDW_ABS,0,0,18);
        bpf_emit(out,OP_JEQ_K,0,3,appletalk ? 491675 : 33011);
        bpf_emit(out,OP_LDW_ABS,0,0,14);
        bpf_emit(out,OP_JEQ_K,0,1,appletalk ? 2863268616U : 2863268608U);
        finish_test(out,c->snaplen);
        return 1;
    }
    if(c->dlt==9&&(!strcmp(f,"atalk")||!strcmp(f,"aarp")||!strcmp(f,"stp")||!strcmp(f,"netbeui"))){
        if(!strcmp(f,"atalk"))type=41;
        else if(!strcmp(f,"aarp"))type=33011;
        else if(!strcmp(f,"stp"))type=49;
        else type=240;
        bpf_emit(out,OP_LDH_ABS,0,0,2);bpf_emit(out,OP_JEQ_K,0,1,type);finish_test(out,c->snaplen);return 1;
    }
    if(c->dlt==113&&!strcmp(f,"netbeui")){
        bpf_emit(out,OP_LDH_ABS,0,0,14);bpf_emit(out,OP_JEQ_K,0,3,4);
        bpf_emit(out,OP_LDH_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,0,1,61680);finish_test(out,c->snaplen);return 1;
    }

    if (!c->optimize && !strcmp(f, "ipx") && (c->dlt == 1 || c->dlt == 113)) {
        static const bpf_insn_t ethernet[] = {
            {40,0,0,12},{21,10,0,33079},{40,0,0,12},{37,9,0,1500},
            {32,0,0,18},{21,0,2,33079},{32,0,0,14},{21,4,0,2863268608U},
            {48,0,0,14},{21,2,0,224},{40,0,0,14},{21,0,1,65535}
        };
        static const bpf_insn_t sll[] = {
            {40,0,0,14},{21,10,0,33079},{40,0,0,14},{21,8,0,1},
            {40,0,0,14},{21,0,7,4},{48,0,0,16},{21,4,0,224},
            {32,0,0,20},{21,0,3,33079},{32,0,0,16},{21,0,1,2863268608U}
        };
        const bpf_insn_t *body = c->dlt == 1 ? ethernet : sll;
        size_t index;
        for (index = 0; index < 12; ++index)
            bpf_emit(out, body[index].code, body[index].jt, body[index].jf, body[index].k);
        finish_test(out, c->snaplen); return 1;
    }
    if (named_ethertype(f, &type))
        return emit_ethertype(c, out, type);

    if (starts(f, "ether proto ")) {
        const char *value = f + 12;
        if (*value == '\\') ++value;
        if (!strcmp(value, "ip")) type = 0x0800;
        else if (!strcmp(value, "ip6")) type = 0x86dd;
        else if (!strcmp(value, "arp")) type = 0x0806;
        else if (!strcmp(value, "rarp")) type = 0x8035;
        else if (!strcmp(value, "ipx")) type = 0x8137;
        else if (!strcmp(value, "aarp")) type = 0x80f3;
        else if (!strcmp(value, "iso")) {
            if (c->dlt == 1) {
                bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
                bpf_emit(out, BPF_JMP | BPF_JGT | BPF_K, 3, 0, 1500);
                bpf_emit(out, OP_LDH_ABS, 0, 0, 14);
                bpf_emit(out, OP_JEQ_K, 0, 1, 0xfefe);
                finish_test(out, c->snaplen); return 1;
            }
            type = 0xfefe;
        }
        else if (!strcmp(value, "decnet")) type = 0x6003;
        else if (!strcmp(value, "mopdl")) type = 0x6001;
        else if (!strcmp(value, "sca")) type = 0x6007;
        else {
            type = (uint32_t)strtoul(value, &end, 0);
            if (*end) return 0;
        }
        return emit_ethertype(c, out, type);
    }

    if ((starts(f, "ip proto ") || starts(f, "ip6 proto ")) && !strstr(f, "protochain")) {
        int version6 = f[2] == '6';
        const char *value = f + (version6 ? 10 : 9);
        uint32_t linkoff, family, protooff, fragoff;
        uint16_t linkload;
        if (!protocol_number(value, &protocol)) return 0;
        if (c->dlt == 105) {
            bpf_emit(out,1,0,0,0); bpf_emit(out,135,0,0,0); bpf_emit(out,4,0,0,24);
            bpf_emit(out,2,0,0,0); bpf_emit(out,80,0,0,0); bpf_emit(out,69,0,5,8);
            bpf_emit(out,69,4,0,4); bpf_emit(out,69,0,3,128); bpf_emit(out,96,0,0,0);
            bpf_emit(out,4,0,0,2); bpf_emit(out,2,0,0,0);
            bpf_emit(out,48,0,0,0); bpf_emit(out,69,version6 ? 15 : 9,0,4);
            bpf_emit(out,48,0,0,0); bpf_emit(out,69,0,version6 ? 13 : 7,8);
            bpf_emit(out,97,0,0,0); bpf_emit(out,72,0,0,6);
            if (!version6) {
                bpf_emit(out,21,0,4,2048); bpf_emit(out,97,0,0,0);
                bpf_emit(out,80,0,0,17); bpf_emit(out,21,0,1,protocol);
            } else {
                bpf_emit(out,21,0,10,34525); bpf_emit(out,97,0,0,0);
                bpf_emit(out,80,0,0,14); bpf_emit(out,21,6,0,protocol);
                bpf_emit(out,97,0,0,0); bpf_emit(out,80,0,0,14);
                bpf_emit(out,21,0,4,44); bpf_emit(out,97,0,0,0);
                bpf_emit(out,80,0,0,48); bpf_emit(out,21,0,1,protocol);
            }
            finish_test(out,c->snaplen);
            return 1;
        }
        if (c->dlt == 1 || c->dlt == 9 || c->dlt == 113 || c->dlt == 0) {
            linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : (c->dlt == 113 ? 14 : 0));
            family = version6 ? (c->dlt == 9 ? 87 : (c->dlt == 0 ? 0x0a000000U : 34525))
                              : (c->dlt == 9 ? 33 : (c->dlt == 0 ? 0x02000000U : 2048));
            linkload = c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS;
            protooff = version6 ? (c->dlt == 1 ? 20 : (c->dlt == 113 ? 22 : 10))
                                : (c->dlt == 1 ? 23 : (c->dlt == 113 ? 25 : 13));
            bpf_emit(out, linkload, 0, 0, linkoff);
            if (!version6) {
                bpf_emit(out, OP_JEQ_K, 0, 3, family);
                bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
                bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
            } else {
                fragoff = c->dlt == 1 ? 54 : (c->dlt == 113 ? 56 : 44);
                bpf_emit(out, OP_JEQ_K, 0, c->optimize ? 6 : 7, family);
                bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
                bpf_emit(out, OP_JEQ_K, c->optimize ? 3 : 4, 0, protocol);
                if (!c->optimize) bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
                bpf_emit(out, OP_JEQ_K, 0, 3, 44);
                bpf_emit(out, OP_LDB_ABS, 0, 0, fragoff);
                bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
            }
            finish_test(out, c->snaplen);
            return 1;
        }
        if (c->dlt == 12) {
            bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
            bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
            if(version6){
                bpf_emit(out,OP_JEQ_K,0,c->optimize?6:7,0x60);
                bpf_emit(out,OP_LDB_ABS,0,0,6);bpf_emit(out,OP_JEQ_K,c->optimize?3:4,0,protocol);
                if(!c->optimize)bpf_emit(out,OP_LDB_ABS,0,0,6);
                bpf_emit(out,OP_JEQ_K,0,3,44);bpf_emit(out,OP_LDB_ABS,0,0,40);
                bpf_emit(out,OP_JEQ_K,0,1,protocol);
            }else{
                bpf_emit(out,OP_JEQ_K,0,3,0x40);bpf_emit(out,OP_LDB_ABS,0,0,9);
                bpf_emit(out,OP_JEQ_K,0,1,protocol);
            }
            finish_test(out, c->snaplen);
            return 1;
        }
    }

    if ((!strcmp(f, "inbound") || !strcmp(f, "outbound")) && c->dlt != 105) {
        int inbound = f[0] == 'i';
        bpf_emit(out, OP_LDH_ABS, 0, 0, c->dlt == 113 ? 0 : 0xfffff004U);
        bpf_emit(out, OP_JEQ_K, 0, 1, 4);
        bpf_emit(out, OP_RET_K, 0, 0, inbound ? 0 : (uint32_t)c->snaplen);
        bpf_emit(out, OP_RET_K, 0, 0, inbound ? (uint32_t)c->snaplen : 0);
        return 1;
    }
    if(c->dlt==105&&!strcmp(f,"broadcast")&&!c->optimize){
        static const bpf_insn_t body[]={
            {48,0,0,0},{69,21,0,4},{48,0,0,0},{69,4,0,8},{32,0,0,6},{21,0,2,UINT32_MAX},{40,0,0,4},{21,14,0,65535},
            {48,0,0,0},{69,0,13,8},{48,0,0,1},{69,4,0,1},{32,0,0,6},{21,0,2,UINT32_MAX},{40,0,0,4},{21,6,0,65535},
            {48,0,0,1},{69,0,5,1},{32,0,0,18},{21,0,3,UINT32_MAX},{40,0,0,16},{21,0,1,65535}};
        size_t i;for(i=0;i<sizeof(body)/sizeof(body[0]);++i)bpf_emit(out,body[i].code,body[i].jt,body[i].jf,body[i].k);
        finish_test(out,c->snaplen);return 1;
    }
    if(c->dlt==105&&!strcmp(f,"multicast")){
        static const bpf_insn_t optimized[]={
            {48,0,0,0},{69,8,0,4},{69,0,4,8},{48,0,0,1},{69,0,2,1},{48,0,0,16},{69,2,3,1},{48,0,0,4},{69,0,1,1}};
        static const bpf_insn_t unoptimized[]={
            {48,0,0,0},{69,15,0,4},{48,0,0,0},{69,2,0,8},{48,0,0,4},{69,10,0,1},{48,0,0,0},{69,0,9,8},
            {48,0,0,1},{69,2,0,1},{48,0,0,4},{69,4,0,1},{48,0,0,1},{69,0,3,1},{48,0,0,16},{69,0,1,1}};
        const bpf_insn_t *body=c->optimize?optimized:unoptimized;
        size_t count=c->optimize?sizeof(optimized)/sizeof(optimized[0]):sizeof(unoptimized)/sizeof(unoptimized[0]),i;
        for(i=0;i<count;++i)bpf_emit(out,body[i].code,body[i].jt,body[i].jf,body[i].k);
        finish_test(out,c->snaplen);return 1;
    }
    if (!strcmp(f, "multicast") && c->dlt == 1) {
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, BPF_JMP | BPF_JSET | BPF_K, 0, 1, 1);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (!strcmp(f, "broadcast") && c->dlt == 1) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 2);
        bpf_emit(out, OP_JEQ_K, 0, 3, UINT32_MAX);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 0);
        bpf_emit(out, OP_JEQ_K, 0, 1, 65535);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (!strcmp(f, "vlan") && c->dlt == 1) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        if (c->optimize) {
            bpf_emit(out, OP_JEQ_K, 2, 0, 33024);
            bpf_emit(out, OP_JEQ_K, 1, 0, 34984);
            bpf_emit(out, OP_JEQ_K, 0, 1, 37120);
        } else {
            bpf_emit(out, OP_JEQ_K, 4, 0, 33024);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 2, 0, 34984);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, 1, 37120);
        }
        finish_test(out, c->snaplen);
        return 1;
    }
    if (!strcmp(f, "ip multicast") || (!strcmp(f, "ip broadcast") && c->dlt != 105)) {
        int multicast_ip = f[3] == 'm';
        uint32_t linkoff, family, destination;
        uint16_t linkload;
        if (c->dlt == 105) {
            static const bpf_insn_t body[] = {
                {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,0},{80,0,0,0},
                {69,0,5,8},{69,4,0,4},{69,0,3,128},{96,0,0,0},{4,0,0,2},
                {2,0,0,0},{48,0,0,0},{69,10,0,4},{48,0,0,0},{69,0,8,8},
                {97,0,0,0},{72,0,0,6},{21,0,5,2048},{97,0,0,0},
                {80,0,0,24},{84,0,0,240},{21,0,1,224}
            };
            size_t index;
            for (index = 0; index < sizeof(body) / sizeof(body[0]); ++index)
                bpf_emit(out, body[index].code, body[index].jt, body[index].jf, body[index].k);
            finish_test(out, c->snaplen); return 1;
        }
        if (c->dlt == 1) { linkoff = 12; family = 2048; destination = 30; linkload = OP_LDH_ABS; }
        else if (c->dlt == 113) { linkoff = 14; family = 2048; destination = 32; linkload = OP_LDH_ABS; }
        else if (c->dlt == 9) { linkoff = 2; family = 33; destination = 20; linkload = OP_LDH_ABS; }
        else if (c->dlt == 0) { linkoff = 0; family = 0x02000000U; destination = 20; linkload = OP_LDW_ABS; }
        else if (c->dlt == 12) {
            bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
            bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
            linkoff = 0; family = 64; destination = 16; linkload = 0;
        } else return 0;
        if (linkload) bpf_emit(out, linkload, 0, 0, linkoff);
        if (multicast_ip) {
            bpf_emit(out, OP_JEQ_K, 0, 4, family);
            bpf_emit(out, OP_LDB_ABS, 0, 0, destination);
            bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
            bpf_emit(out, OP_JEQ_K, 0, 1, 0xe0);
        } else {
            uint32_t hostmask = ~c->netmask;
            bpf_emit(out, OP_JEQ_K, 0, c->optimize ? 5 : 7, family);
            bpf_emit(out, OP_LDW_ABS, 0, 0, destination);
            if (c->optimize) {
                bpf_emit(out, OP_JSET_K, 0, 2, hostmask);
                bpf_emit(out, OP_AND_K, 0, 0, hostmask);
                bpf_emit(out, OP_JEQ_K, 0, 1, hostmask);
            } else {
                bpf_emit(out, OP_AND_K, 0, 0, hostmask);
                bpf_emit(out, OP_JEQ_K, 3, 0, 0);
                bpf_emit(out, OP_LDW_ABS, 0, 0, destination);
                bpf_emit(out, OP_AND_K, 0, 0, hostmask);
                bpf_emit(out, OP_JEQ_K, 0, 1, hostmask);
            }
        }
        finish_test(out, c->snaplen);
        return 1;
    }
    if (!strcmp(f,"ip6 multicast") && c->dlt!=105) {
        uint32_t linkoff,family,destination; uint16_t linkload;
        if(c->dlt==1){linkoff=12;family=34525;destination=38;linkload=OP_LDH_ABS;}
        else if(c->dlt==113){linkoff=14;family=34525;destination=40;linkload=OP_LDH_ABS;}
        else if(c->dlt==9){linkoff=2;family=87;destination=28;linkload=OP_LDH_ABS;}
        else if(c->dlt==0){linkoff=0;family=0x0a000000U;destination=28;linkload=OP_LDW_ABS;}
        else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkoff=0;family=96;destination=24;linkload=0;}
        else return 0;
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);
        bpf_emit(out,OP_JEQ_K,0,3,family);
        bpf_emit(out,OP_LDB_ABS,0,0,destination);
        bpf_emit(out,OP_JEQ_K,0,1,255);
        finish_test(out,c->snaplen); return 1;
    }

    if (!strcmp(f, "tcp")) protocol = 6;
    else if (!strcmp(f, "udp")) protocol = 17;
    else if (!strcmp(f, "esp")) protocol = 50;
    else if (!strcmp(f, "ah")) protocol = 51;
    else if (!strcmp(f, "pim")) protocol = 103;
    else if (!strcmp(f, "sctp")) protocol = 132;
    else protocol = UINT32_MAX;

    if (protocol != UINT32_MAX && c->dlt == 105) {
        bpf_emit(out,1,0,0,0); bpf_emit(out,135,0,0,0); bpf_emit(out,4,0,0,24);
        bpf_emit(out,2,0,0,0); bpf_emit(out,80,0,0,0); bpf_emit(out,69,0,5,8);
        bpf_emit(out,69,4,0,4); bpf_emit(out,69,0,3,128); bpf_emit(out,96,0,0,0);
        bpf_emit(out,4,0,0,2); bpf_emit(out,2,0,0,0);
        bpf_emit(out,48,0,0,0); bpf_emit(out,69,8,0,4); bpf_emit(out,48,0,0,0);
        bpf_emit(out,69,0,6,8); bpf_emit(out,97,0,0,0); bpf_emit(out,72,0,0,6);
        bpf_emit(out,21,0,3,2048); bpf_emit(out,97,0,0,0); bpf_emit(out,80,0,0,17);
        bpf_emit(out,21,16,0,protocol); bpf_emit(out,48,0,0,0); bpf_emit(out,69,15,0,4);
        bpf_emit(out,48,0,0,0); bpf_emit(out,69,0,13,8); bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6); bpf_emit(out,21,0,10,34525); bpf_emit(out,97,0,0,0);
        bpf_emit(out,80,0,0,14); bpf_emit(out,21,6,0,protocol); bpf_emit(out,97,0,0,0);
        bpf_emit(out,80,0,0,14); bpf_emit(out,21,0,4,44); bpf_emit(out,97,0,0,0);
        bpf_emit(out,80,0,0,48); bpf_emit(out,21,0,1,protocol);
        finish_test(out,c->snaplen);
        return 1;
    }
    if(protocol!=UINT32_MAX&&c->dlt==12){
        bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
        bpf_emit(out,OP_JEQ_K,0,2,64);bpf_emit(out,OP_LDB_ABS,0,0,9);
        if(c->optimize){
            bpf_emit(out,OP_JEQ_K,6,7,protocol);bpf_emit(out,OP_JEQ_K,0,6,96);
            bpf_emit(out,OP_LDB_ABS,0,0,6);bpf_emit(out,OP_JEQ_K,3,0,protocol);
            bpf_emit(out,OP_JEQ_K,0,3,44);
        }else{
            bpf_emit(out,OP_JEQ_K,9,0,protocol);bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
            bpf_emit(out,OP_JEQ_K,0,7,96);bpf_emit(out,OP_LDB_ABS,0,0,6);
            bpf_emit(out,OP_JEQ_K,4,0,protocol);bpf_emit(out,OP_LDB_ABS,0,0,6);bpf_emit(out,OP_JEQ_K,0,3,44);
        }
        bpf_emit(out,OP_LDB_ABS,0,0,40);bpf_emit(out,OP_JEQ_K,0,1,protocol);
        finish_test(out,c->snaplen);return 1;
    }
    if (protocol != UINT32_MAX && (c->dlt == 0 || c->dlt == 1 || c->dlt == 9 || c->dlt == 113)) {
        uint32_t linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : (c->dlt == 113 ? 14 : 0));
        uint32_t ip4 = c->dlt == 9 ? 33 : (c->dlt == 0 ? 0x02000000U : 2048);
        uint32_t ip6 = c->dlt == 9 ? 87 : (c->dlt == 0 ? 0x0a000000U : 34525);
        uint32_t v4off = c->dlt == 1 ? 23 : (c->dlt == 113 ? 25 : 13);
        uint32_t v6off = c->dlt == 1 ? 20 : (c->dlt == 113 ? 22 : 10);
        uint32_t fragoff = c->dlt == 1 ? 54 : (c->dlt == 113 ? 56 : 44);
        bpf_emit(out, c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, 2, ip4);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v4off);
        if (c->optimize) {
            bpf_emit(out, OP_JEQ_K, 6, 7, protocol);
            bpf_emit(out, OP_JEQ_K, 0, 6, ip6);
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
            bpf_emit(out, OP_JEQ_K, 3, 0, protocol);
            bpf_emit(out, OP_JEQ_K, 0, 3, 44);
        } else {
            bpf_emit(out, OP_JEQ_K, 8, 0, protocol);
            bpf_emit(out, c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS, 0, 0, linkoff);
            bpf_emit(out, OP_JEQ_K, 0, 7, ip6);
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
            bpf_emit(out, OP_JEQ_K, 4, 0, protocol);
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
            bpf_emit(out, OP_JEQ_K, 0, 3, 44);
        }
        bpf_emit(out, OP_LDB_ABS, 0, 0, fragoff);
        bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
        finish_test(out, c->snaplen);
        return 1;
    }

    if (!strcmp(f,"icmp6") && c->dlt==105) {
        bpf_emit(out,1,0,0,0); bpf_emit(out,135,0,0,0); bpf_emit(out,4,0,0,24);
        bpf_emit(out,2,0,0,0); bpf_emit(out,80,0,0,0); bpf_emit(out,69,0,5,8);
        bpf_emit(out,69,4,0,4); bpf_emit(out,69,0,3,128); bpf_emit(out,96,0,0,0);
        bpf_emit(out,4,0,0,2); bpf_emit(out,2,0,0,0); bpf_emit(out,48,0,0,0);
        bpf_emit(out,69,15,0,4); bpf_emit(out,48,0,0,0); bpf_emit(out,69,0,13,8);
        bpf_emit(out,97,0,0,0); bpf_emit(out,72,0,0,6); bpf_emit(out,21,0,10,34525);
        bpf_emit(out,97,0,0,0); bpf_emit(out,80,0,0,14); bpf_emit(out,21,6,0,58);
        bpf_emit(out,97,0,0,0); bpf_emit(out,80,0,0,14); bpf_emit(out,21,0,4,44);
        bpf_emit(out,97,0,0,0); bpf_emit(out,80,0,0,48); bpf_emit(out,21,0,1,58);
        finish_test(out,c->snaplen);
        return 1;
    }
    if(!strcmp(f,"icmp6")&&c->dlt==12){
        bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
        bpf_emit(out,OP_JEQ_K,0,c->optimize?6:7,96);bpf_emit(out,OP_LDB_ABS,0,0,6);
        bpf_emit(out,OP_JEQ_K,c->optimize?3:4,0,58);
        if(!c->optimize)bpf_emit(out,OP_LDB_ABS,0,0,6);
        bpf_emit(out,OP_JEQ_K,0,3,44);bpf_emit(out,OP_LDB_ABS,0,0,40);bpf_emit(out,OP_JEQ_K,0,1,58);
        finish_test(out,c->snaplen);return 1;
    }
    if (!strcmp(f, "icmp6") && (c->dlt == 0 || c->dlt == 1 || c->dlt == 9 || c->dlt == 113)) {
        uint32_t linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : (c->dlt == 113 ? 14 : 0));
        uint32_t ip6 = c->dlt == 9 ? 87 : (c->dlt == 0 ? 0x0a000000U : 34525);
        uint32_t v6off = c->dlt == 1 ? 20 : (c->dlt == 113 ? 22 : 10);
        uint32_t fragoff = c->dlt == 1 ? 54 : (c->dlt == 113 ? 56 : 44);
        bpf_emit(out, c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, c->optimize ? 6 : 7, ip6);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
        bpf_emit(out, OP_JEQ_K, c->optimize ? 3 : 4, 0, 58);
        if (!c->optimize)
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
        bpf_emit(out, OP_JEQ_K, 0, 3, 44);
        bpf_emit(out, OP_LDB_ABS, 0, 0, fragoff);
        bpf_emit(out, OP_JEQ_K, 0, 1, 58);
        finish_test(out, c->snaplen);
        return 1;
    }

    if (!strcmp(f, "icmp")) protocol = 1;
    else if (!strcmp(f, "igmp")) protocol = 2;
    else if (!strcmp(f, "igrp")) protocol = 9;
    else if (!strcmp(f, "pim")) protocol = 103;
    else if (!strcmp(f, "vrrp") || !strcmp(f, "carp")) protocol = 112;
    else return 0;

    if (c->dlt == 105) {
        bpf_emit(out,1,0,0,0); bpf_emit(out,135,0,0,0); bpf_emit(out,4,0,0,24);
        bpf_emit(out,2,0,0,0); bpf_emit(out,80,0,0,0); bpf_emit(out,69,0,5,8);
        bpf_emit(out,69,4,0,4); bpf_emit(out,69,0,3,128); bpf_emit(out,96,0,0,0);
        bpf_emit(out,4,0,0,2); bpf_emit(out,2,0,0,0); bpf_emit(out,48,0,0,0);
        bpf_emit(out,69,9,0,4); bpf_emit(out,48,0,0,0); bpf_emit(out,69,0,7,8);
        bpf_emit(out,97,0,0,0); bpf_emit(out,72,0,0,6); bpf_emit(out,21,0,4,2048);
        bpf_emit(out,97,0,0,0); bpf_emit(out,80,0,0,17); bpf_emit(out,21,0,1,protocol);
        finish_test(out,c->snaplen);
        return 1;
    }

    if (c->dlt == 0 || c->dlt == 1 || c->dlt == 9 || c->dlt == 113) {
        uint32_t linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : (c->dlt == 113 ? 14 : 0));
        uint32_t iptype = c->dlt == 9 ? 33 : (c->dlt == 0 ? 0x02000000U : 2048);
        uint32_t protooff = c->dlt == 1 ? 23 : (c->dlt == 113 ? 25 : 13);
        bpf_emit(out, c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, 3, iptype);
        bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
        bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (c->dlt == 12) {
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
        bpf_emit(out, OP_JEQ_K, 0, 3, 0x40);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 9);
        bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
        finish_test(out, c->snaplen);
        return 1;
    }
    return 0;
}

static int protocol_boolean_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char text[256], atoms[8][24];
    const char *separator;
    bpf_prog_t programs[8];
    size_t starts_at[8], total=0, count=0, index, instruction;
    int is_or;
    if (c->optimize || strlen(c->filter)>=sizeof(text)) return 0;
    if (strstr(c->filter," or ") && !strstr(c->filter," and ")) {separator=" or ";is_or=1;}
    else if(strstr(c->filter," and ") && !strstr(c->filter," or ")) {separator=" and ";is_or=0;}
    else return 0;
    strcpy(text,c->filter);
    {
        char *source=text,*destination=text;
        while(*source){
            if(*source!='('&&*source!=')')*destination++=*source;
            ++source;
        }
        *destination=0;
    }
    {
        char *cursor=text;
        size_t separator_length=strlen(separator);
        while(cursor && *cursor && count<8){
            char *next=strstr(cursor,separator);
            size_t length=next ? (size_t)(next-cursor) : strlen(cursor);
            if(!length || length>=sizeof(atoms[0])) return 0;
            memcpy(atoms[count],cursor,length); atoms[count][length]=0;
            if((strchr(atoms[count],' ') && !(starts(atoms[count],"not ") && !strchr(atoms[count]+4,' '))) ||
               strchr(atoms[count],'(')||strchr(atoms[count],')')) return 0;
            ++count;
            cursor=next ? next+separator_length : NULL;
        }
    }
    if(count<2) return 0;
    for(index=0;index<count;++index){
        bpfc_case_t atom_case=*c;
        int negate=0;
        bpf_prog_init(&programs[index]);
        atom_case.filter=atoms[index];
        if(starts(atoms[index],"not ")&&!strchr(atoms[index]+4,' ')){
            negate=1; atom_case.filter=atoms[index]+4;
        }
        if(!simple_compile(&atom_case,&programs[index]) || programs[index].len<3){
            size_t free_index;
            for(free_index=0;free_index<=index;++free_index)bpf_prog_free(&programs[free_index]);
            return 0;
        }
        if(negate){
            size_t negate_index;
            for(negate_index=0;negate_index<programs[index].len-2;++negate_index){
                bpf_insn_t *insn=&programs[index].insns[negate_index];
                if((insn->code&7)==BPF_JMP&&(insn->code&0xf0)!=BPF_JA){
                    size_t true_target=negate_index+1+insn->jt;
                    size_t false_target=negate_index+1+insn->jf;
                    if(true_target==programs[index].len-2) insn->jt=(uint8_t)(programs[index].len-1-negate_index-1);
                    else if(true_target==programs[index].len-1) insn->jt=(uint8_t)(programs[index].len-2-negate_index-1);
                    if(false_target==programs[index].len-2) insn->jf=(uint8_t)(programs[index].len-1-negate_index-1);
                    else if(false_target==programs[index].len-1) insn->jf=(uint8_t)(programs[index].len-2-negate_index-1);
                }
            }
        }
        starts_at[index]=total;
        total+=programs[index].len-2;
    }
    bpf_prog_reset(out);
    for(index=0;index<count;++index){
        size_t body=programs[index].len-2;
        for(instruction=0;instruction<body;++instruction){
            bpf_insn_t insn=programs[index].insns[instruction];
            if((insn.code&0x07)==BPF_JMP && (insn.code&0xf0)!=BPF_JA){
                size_t branch;
                uint8_t *offsets[2]={&insn.jt,&insn.jf};
                int branch_index;
                for(branch_index=0;branch_index<2;++branch_index){
                    size_t target=instruction+1+*offsets[branch_index];
                    size_t destination;
                    if(target==programs[index].len-2)
                        destination=is_or ? total : (index+1<count ? starts_at[index+1] : total);
                    else if(target==programs[index].len-1)
                        destination=is_or ? (index+1<count ? starts_at[index+1] : total+1) : total+1;
                    else continue;
                    branch=starts_at[index]+instruction;
                    if(destination<=branch || destination-branch-1>255){
                        size_t free_index; for(free_index=0;free_index<count;++free_index)bpf_prog_free(&programs[free_index]);
                        bpf_prog_reset(out); return 0;
                    }
                    *offsets[branch_index]=(uint8_t)(destination-branch-1);
                }
            }
            bpf_emit(out,insn.code,insn.jt,insn.jf,insn.k);
        }
    }
    finish_test(out,c->snaplen);
    for(index=0;index<count;++index)bpf_prog_free(&programs[index]);
    return 1;
}

static int protocol_not_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    bpfc_case_t atom_case=*c;
    bpf_prog_t program;
    const char *atom;
    size_t index, body;
    if(!starts(c->filter,"not ")) return 0;
    atom=c->filter+4;
    if(strchr(atom,' ')||strchr(atom,'(')||strchr(atom,')')) return 0;
    bpf_prog_init(&program); atom_case.filter=(char *)atom;
    if(!simple_compile(&atom_case,&program)||program.len<3){bpf_prog_free(&program);return 0;}
    body=program.len-2; bpf_prog_reset(out);
    for(index=0;index<body;++index){
        bpf_insn_t insn=program.insns[index];
        bpf_emit(out,insn.code,insn.jt,insn.jf,insn.k);
    }
    bpf_emit(out,OP_RET_K,0,0,0);
    bpf_emit(out,OP_RET_K,0,0,(uint32_t)c->snaplen);
    bpf_prog_free(&program); return 1;
}

static int port_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char protocol_name[8], direction[8], extra[8];
    unsigned port;
    uint32_t protocol, ipv6_port_offset, indirect_offset;
    uint32_t linkoff,ip6_family,ip4_family,v6_proto,v6_src,v6_dst,v4_proto,fragment,ipbase;
    uint16_t linkload;
    int raw=0;
    int fields;

    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip6_family=34525;ip4_family=2048;v6_proto=20;v6_src=54;v6_dst=56;v4_proto=23;fragment=20;ipbase=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip6_family=87;ip4_family=33;v6_proto=10;v6_src=44;v6_dst=46;v4_proto=13;fragment=10;ipbase=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip6_family=34525;ip4_family=2048;v6_proto=22;v6_src=56;v6_dst=58;v4_proto=25;fragment=22;ipbase=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip6_family=0x0a000000U;ip4_family=0x02000000U;v6_proto=10;v6_src=44;v6_dst=46;v4_proto=13;fragment=10;ipbase=4;}
    else if(c->dlt==12){linkload=0;linkoff=0;ip6_family=96;ip4_family=64;v6_proto=6;v6_src=40;v6_dst=42;v4_proto=9;fragment=6;ipbase=0;raw=1;}
    else return 0;
    fields = sscanf(c->filter, "%7s %7s port %u %7s", protocol_name, direction, &port, extra);
    if (fields == 3 && (!strcmp(direction, "src") || !strcmp(direction, "dst"))) {
        if (!strcmp(protocol_name, "tcp")) protocol = 6;
        else if (!strcmp(protocol_name, "udp")) protocol = 17;
        else if (!strcmp(protocol_name, "sctp")) protocol = 132;
        else return 0;
    } else {
        fields = sscanf(c->filter, "%7s port %u %7s", protocol_name, &port, extra);
        if (fields != 2) return 0;
        strcpy(direction, "any");
        if (!strcmp(protocol_name, "tcp")) protocol = 6;
        else if (!strcmp(protocol_name, "udp")) protocol = 17;
        else if (!strcmp(protocol_name, "sctp")) protocol = 132;
        else return 0;
    }
    if (port > 65535) return 0;

    ipv6_port_offset = !strcmp(direction, "dst") ? v6_dst : v6_src;
    indirect_offset = !strcmp(direction, "dst") ? ipbase+2 : ipbase;
    if(raw){
        if(!c->optimize){
            if(!strcmp(direction,"any")){
                size_t v6_guard,v6_proto_test,v6_src_test,v6_dst_test;
                size_t v4_guard,v4_proto_test,v4_fragment_test,v4_src_test,v4_dst_test;
                size_t v4_start,accept,reject;
                bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
                v6_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,ip6_family);
                bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
                v6_proto_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocol);
                bpf_emit(out,OP_LDH_ABS,0,0,v6_src);
                v6_src_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);
                bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);
                v6_dst_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);
                v4_start=out->len;
                bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
                v4_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,ip4_family);
                bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
                v4_proto_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocol);
                bpf_emit(out,OP_LDH_ABS,0,0,fragment);
                v4_fragment_test=out->len;bpf_emit(out,OP_JSET_K,0,0,8191);
                bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,ipbase);
                v4_src_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);
                bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);
                v4_dst_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);
                accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
                out->insns[v6_guard].jf=(uint8_t)(v4_start-v6_guard-1);
                out->insns[v6_proto_test].jf=(uint8_t)(v4_start-v6_proto_test-1);
                out->insns[v6_src_test].jt=(uint8_t)(accept-v6_src_test-1);
                out->insns[v6_dst_test].jt=(uint8_t)(accept-v6_dst_test-1);
                out->insns[v4_guard].jf=(uint8_t)(reject-v4_guard-1);
                out->insns[v4_proto_test].jf=(uint8_t)(reject-v4_proto_test-1);
                out->insns[v4_fragment_test].jt=(uint8_t)(reject-v4_fragment_test-1);
                out->insns[v4_src_test].jt=(uint8_t)(accept-v4_src_test-1);
                out->insns[v4_dst_test].jt=(uint8_t)(accept-v4_dst_test-1);
                out->insns[v4_dst_test].jf=(uint8_t)(reject-v4_dst_test-1);
                return 1;
            }
            bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
            bpf_emit(out,OP_JEQ_K,0,4,ip6_family);bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
            bpf_emit(out,OP_JEQ_K,0,2,protocol);bpf_emit(out,OP_LDH_ABS,0,0,ipv6_port_offset);
            bpf_emit(out,OP_JEQ_K,10,0,port);bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
            bpf_emit(out,OP_JEQ_K,0,8,ip4_family);bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
            bpf_emit(out,OP_JEQ_K,0,6,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
            bpf_emit(out,OP_JSET_K,4,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
            bpf_emit(out,OP_LDH_IND,0,0,indirect_offset);bpf_emit(out,OP_JEQ_K,0,1,port);
            finish_test(out,c->snaplen);return 1;
        }
        bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
        if(!strcmp(direction,"any")){
            bpf_emit(out,OP_JEQ_K,0,6,ip6_family);bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
            bpf_emit(out,OP_JEQ_K,0,17,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6_src);
            bpf_emit(out,OP_JEQ_K,14,0,port);bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);
            bpf_emit(out,OP_JEQ_K,12,13,port);bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
            bpf_emit(out,OP_JEQ_K,0,10,ip4_family);bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
            bpf_emit(out,OP_JEQ_K,0,8,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
            bpf_emit(out,OP_JSET_K,6,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
            bpf_emit(out,OP_LDH_IND,0,0,ipbase);bpf_emit(out,OP_JEQ_K,2,0,port);
            bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);bpf_emit(out,OP_JEQ_K,0,1,port);
        }else{
            bpf_emit(out,OP_JEQ_K,0,4,ip6_family);bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
            bpf_emit(out,OP_JEQ_K,0,13,protocol);bpf_emit(out,OP_LDH_ABS,0,0,ipv6_port_offset);
            bpf_emit(out,OP_JEQ_K,10,11,port);bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
            bpf_emit(out,OP_JEQ_K,0,8,ip4_family);bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
            bpf_emit(out,OP_JEQ_K,0,6,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
            bpf_emit(out,OP_JSET_K,4,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
            bpf_emit(out,OP_LDH_IND,0,0,indirect_offset);bpf_emit(out,OP_JEQ_K,0,1,port);
        }
        finish_test(out,c->snaplen);return 1;
    }
    bpf_emit(out, linkload, 0, 0, linkoff);
    if (!strcmp(direction, "any")) {
        if(!c->optimize&&c->dlt!=0){
            bpf_emit(out,OP_JEQ_K,0,6,ip6_family);bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
            bpf_emit(out,OP_JEQ_K,0,4,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6_src);
            bpf_emit(out,OP_JEQ_K,14,0,port);bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);
            bpf_emit(out,OP_JEQ_K,12,0,port);bpf_emit(out,linkload,0,0,linkoff);
            bpf_emit(out,OP_JEQ_K,0,11,ip4_family);bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
            bpf_emit(out,OP_JEQ_K,0,9,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
            bpf_emit(out,OP_JSET_K,7,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
            bpf_emit(out,OP_LDH_IND,0,0,ipbase);bpf_emit(out,OP_JEQ_K,3,0,port);
            bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);
            bpf_emit(out,OP_JEQ_K,0,1,port);finish_test(out,c->snaplen);return 1;
        }
        if(c->dlt==0&&!c->optimize){
            bpf_emit(out,OP_JEQ_K,0,6,ip6_family);bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
            bpf_emit(out,OP_JEQ_K,0,4,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6_src);
            bpf_emit(out,OP_JEQ_K,14,0,port);bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);
            bpf_emit(out,OP_JEQ_K,12,0,port);bpf_emit(out,linkload,0,0,linkoff);
            bpf_emit(out,OP_JEQ_K,0,11,ip4_family);bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
            bpf_emit(out,OP_JEQ_K,0,9,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
            bpf_emit(out,OP_JSET_K,7,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
            bpf_emit(out,OP_LDH_IND,0,0,ipbase);bpf_emit(out,OP_JEQ_K,3,0,port);
            bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);
            bpf_emit(out,OP_JEQ_K,0,1,port);finish_test(out,c->snaplen);return 1;
        }
        bpf_emit(out, OP_JEQ_K, 0, 6, ip6_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v6_proto);
        bpf_emit(out, OP_JEQ_K, 0, 15, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, v6_src);
        bpf_emit(out, OP_JEQ_K, 12, 0, port);
        bpf_emit(out, OP_LDH_ABS, 0, 0, v6_dst);
        bpf_emit(out, OP_JEQ_K, 10, 11, port);
        bpf_emit(out, OP_JEQ_K, 0, 10, ip4_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v4_proto);
        bpf_emit(out, OP_JEQ_K, 0, 8, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, fragment);
        bpf_emit(out, OP_JSET_K, 6, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
        bpf_emit(out, OP_LDH_IND, 0, 0, ipbase);
        bpf_emit(out, OP_JEQ_K, 2, 0, port);
        bpf_emit(out, OP_LDH_IND, 0, 0, ipbase+2);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 4, ip6_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v6_proto);
        bpf_emit(out, OP_JEQ_K, 0, 11, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, ipv6_port_offset);
        bpf_emit(out, OP_JEQ_K, 8, 9, port);
        bpf_emit(out, OP_JEQ_K, 0, 8, ip4_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v4_proto);
        bpf_emit(out, OP_JEQ_K, 0, 6, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, fragment);
        bpf_emit(out, OP_JSET_K, 4, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
        bpf_emit(out, OP_LDH_IND, 0, 0, indirect_offset);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    } else {
        bpf_emit(out, OP_JEQ_K, 0, 4, ip6_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v6_proto);
        bpf_emit(out, OP_JEQ_K, 0, 2, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, ipv6_port_offset);
        bpf_emit(out, OP_JEQ_K, 9, 0, port);
        bpf_emit(out, linkload, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, 8, ip4_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v4_proto);
        bpf_emit(out, OP_JEQ_K, 0, 6, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, fragment);
        bpf_emit(out, OP_JSET_K, 4, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
        bpf_emit(out, OP_LDH_IND, 0, 0, indirect_offset);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int radiotap_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],direction[8],tail[8];unsigned port;uint32_t protocol;int any=0,both=0;
    if(c->dlt!=105)return 0;
    if(sscanf(c->filter,"%7s src and dst port %u %7s",protocol_name,&port,tail)==2)both=1;
    else if(sscanf(c->filter,"%7s %7s port %u %7s",protocol_name,direction,&port,tail)!=3){
        if(sscanf(c->filter,"%7s port %u %7s",protocol_name,&port,tail)!=2)return 0;
        any=1;
    }else if(strcmp(direction,"src")&&strcmp(direction,"dst"))return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;
    else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);bpf_emit(out,48,0,0,0);
    if(any||both){
        bpf_emit(out,69,14,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,12,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,9,34525);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,14);
        bpf_emit(out,21,0,6,protocol);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,48);bpf_emit(out,21,both?0:32,both?3:0,port);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,50);bpf_emit(out,21,29,0,port);bpf_emit(out,48,0,0,0);
        bpf_emit(out,69,28,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,26,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,23,2048);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,17);
        bpf_emit(out,21,0,20,protocol);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,14);bpf_emit(out,69,17,0,8191);
        bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
        bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,8);bpf_emit(out,21,both?0:8,both?9:0,port);
        bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
        bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,10);bpf_emit(out,21,0,1,port);
    }else{
        uint32_t v6offset=!strcmp(direction,"dst")?50:48,indirect=!strcmp(direction,"dst")?10:8;
        bpf_emit(out,69,11,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,9,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,6,34525);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,14);
        bpf_emit(out,21,0,3,protocol);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,v6offset);bpf_emit(out,21,21,0,port);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,20,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,18,8);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,15,2048);bpf_emit(out,97,0,0,0);
        bpf_emit(out,80,0,0,17);bpf_emit(out,21,0,12,protocol);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,14);
        bpf_emit(out,69,9,0,8191);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);
        bpf_emit(out,100,0,0,2);bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,indirect);
        bpf_emit(out,21,0,1,port);
    }
    finish_test(out,c->snaplen);return 1;
}

static int radiotap_generic_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],tail[8];unsigned port;static const uint32_t protocols[3]={132,6,17};
    size_t v6_guard1,v6_guard2,v6_family,v6_starts[3],v6_proto[3],v6_tests[3];
    size_t v4_start,v4_guard1,v4_guard2,v4_family,v4_starts[3],v4_proto[3],v4_frag[3],v4_tests[3];
    size_t accept,reject;uint32_t v6offset,v4offset;int index;
    if(c->dlt!=105||sscanf(c->filter,"%7s port %u %7s",direction,&port,tail)!=2||
       (strcmp(direction,"src")&&strcmp(direction,"dst"))||port>65535)return 0;
    v6offset=!strcmp(direction,"dst")?50:48;v4offset=!strcmp(direction,"dst")?10:8;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
    bpf_emit(out,48,0,0,0);v6_guard1=out->len;bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);
    v6_guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);
    v6_family=out->len;bpf_emit(out,21,0,0,34525);
    for(index=0;index<3;++index){
        v6_starts[index]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,14);
        v6_proto[index]=out->len;bpf_emit(out,21,0,0,protocols[index]);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,v6offset);v6_tests[index]=out->len;bpf_emit(out,21,0,0,port);
    }
    v4_start=out->len;bpf_emit(out,48,0,0,0);v4_guard1=out->len;bpf_emit(out,69,0,0,4);
    bpf_emit(out,48,0,0,0);v4_guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);
    bpf_emit(out,72,0,0,6);v4_family=out->len;bpf_emit(out,21,0,0,2048);
    for(index=0;index<3;++index){
        v4_starts[index]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,17);
        v4_proto[index]=out->len;bpf_emit(out,21,0,0,protocols[index]);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,14);v4_frag[index]=out->len;bpf_emit(out,69,0,0,8191);
        bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
        bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,v4offset);
        v4_tests[index]=out->len;bpf_emit(out,21,0,0,port);
    }
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[v6_guard1].jt=(uint8_t)(v4_start-v6_guard1-1);out->insns[v6_guard2].jf=(uint8_t)(v4_start-v6_guard2-1);
    out->insns[v6_family].jf=(uint8_t)(v4_start-v6_family-1);
    for(index=0;index<3;++index){size_t next=index<2?v6_starts[index+1]:v4_start;
        out->insns[v6_proto[index]].jf=(uint8_t)(next-v6_proto[index]-1);
        out->insns[v6_tests[index]].jt=(uint8_t)(accept-v6_tests[index]-1);
        out->insns[v6_tests[index]].jf=(uint8_t)(next-v6_tests[index]-1);}
    out->insns[v4_guard1].jt=(uint8_t)(reject-v4_guard1-1);out->insns[v4_guard2].jf=(uint8_t)(reject-v4_guard2-1);
    out->insns[v4_family].jf=(uint8_t)(reject-v4_family-1);
    for(index=0;index<3;++index){size_t next=index<2?v4_starts[index+1]:reject;
        out->insns[v4_proto[index]].jf=(uint8_t)(next-v4_proto[index]-1);
        out->insns[v4_frag[index]].jt=(uint8_t)(next-v4_frag[index]-1);
        out->insns[v4_tests[index]].jt=(uint8_t)(accept-v4_tests[index]-1);
        out->insns[v4_tests[index]].jf=(uint8_t)(next-v4_tests[index]-1);}
    return 1;
}

static int radiotap_generic_any_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char tail[8];unsigned port;static const uint32_t protocols[3]={132,6,17};
    size_t vg1,vg2,vfam,vs[3],vp[3],vt[3][2],v4start,g1,g2,fam,s[3],pt[3],frag[3],tests[3][2],accept,reject;int p,d;
    if(c->dlt!=105||sscanf(c->filter,"port %u %7s",&port,tail)!=1||port>65535)return 0;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
    bpf_emit(out,48,0,0,0);vg1=out->len;bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);vg2=out->len;bpf_emit(out,69,0,0,8);
    bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);vfam=out->len;bpf_emit(out,21,0,0,34525);
    for(p=0;p<3;++p){vs[p]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,14);vp[p]=out->len;bpf_emit(out,21,0,0,protocols[p]);
        for(d=0;d<2;++d){bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,d?50:48);vt[p][d]=out->len;bpf_emit(out,21,0,0,port);}}
    v4start=out->len;bpf_emit(out,48,0,0,0);g1=out->len;bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);g2=out->len;bpf_emit(out,69,0,0,8);
    bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);fam=out->len;bpf_emit(out,21,0,0,2048);
    for(p=0;p<3;++p){s[p]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,17);pt[p]=out->len;bpf_emit(out,21,0,0,protocols[p]);
        bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,14);frag[p]=out->len;bpf_emit(out,69,0,0,8191);
        for(d=0;d<2;++d){bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
            bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,d?10:8);tests[p][d]=out->len;bpf_emit(out,21,0,0,port);}}
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[vg1].jt=(uint8_t)(v4start-vg1-1);out->insns[vg2].jf=(uint8_t)(v4start-vg2-1);out->insns[vfam].jf=(uint8_t)(v4start-vfam-1);
    for(p=0;p<3;++p){size_t next=p<2?vs[p+1]:v4start;out->insns[vp[p]].jf=(uint8_t)(next-vp[p]-1);
        for(d=0;d<2;++d){size_t failure=d==0?vt[p][1]-2:next;out->insns[vt[p][d]].jt=(uint8_t)(accept-vt[p][d]-1);out->insns[vt[p][d]].jf=(uint8_t)(failure-vt[p][d]-1);}}
    out->insns[g1].jt=(uint8_t)(reject-g1-1);out->insns[g2].jf=(uint8_t)(reject-g2-1);out->insns[fam].jf=(uint8_t)(reject-fam-1);
    for(p=0;p<3;++p){size_t next=p<2?s[p+1]:reject;out->insns[pt[p]].jf=(uint8_t)(next-pt[p]-1);out->insns[frag[p]].jt=(uint8_t)(next-frag[p]-1);
        for(d=0;d<2;++d){size_t failure=d==0?tests[p][1]-7:next;out->insns[tests[p][d]].jt=(uint8_t)(accept-tests[p][d]-1);out->insns[tests[p][d]].jf=(uint8_t)(failure-tests[p][d]-1);}}
    return 1;
}

static int radiotap_portrange_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],direction[8],tail[8];unsigned low,high;uint32_t protocol,v6offset,indirect;
    if(c->dlt!=105||!c->optimize||
       sscanf(c->filter,"%7s %7s portrange %u-%u %7s",protocol_name,direction,&low,&high,tail)!=4||
       (strcmp(direction,"src")&&strcmp(direction,"dst")))return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;
    else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    if(low>65535||high>65535)return 0;
    v6offset=!strcmp(direction,"dst")?50:48;indirect=!strcmp(direction,"dst")?10:8;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);bpf_emit(out,48,0,0,0);
    bpf_emit(out,69,14,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,12,8);bpf_emit(out,97,0,0,0);
    bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,9,34525);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,14);
    bpf_emit(out,21,0,6,protocol);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,v6offset);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,3,low);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,v6offset);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,29,high);bpf_emit(out,48,0,0,0);bpf_emit(out,69,28,0,4);
    bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,26,8);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);
    bpf_emit(out,21,0,23,2048);bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,17);bpf_emit(out,21,0,20,protocol);
    bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,14);bpf_emit(out,69,17,0,8191);bpf_emit(out,97,0,0,0);
    bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);bpf_emit(out,12,0,0,0);
    bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,indirect);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,9,low);
    bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
    bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,indirect);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);finish_test(out,c->snaplen);return 1;
}

static int radiotap_generic_range_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char tail[8],direction[8];unsigned low,high;static const uint32_t protocols[3]={132,6,17};
    size_t v6_guard1,v6_guard2,v6_family,v6_starts[3],v6_proto[3],v6_high[3][2];
    size_t v4_start,v4_guard1,v4_guard2,v4_family,v4_starts[3],v4_proto[3],v4_frag[3],v4_high[3][2],accept,reject;
    int protocol_index,direction_index;
    if(c->dlt!=105)return 0;
    if(sscanf(c->filter,"%7s portrange %u-%u %7s",direction,&low,&high,tail)==3&&
       (!strcmp(direction,"src")||!strcmp(direction,"dst"))){
        size_t v6_low[3],v4_low[3];
        uint32_t v6offset=!strcmp(direction,"dst")?50:48,v4offset=!strcmp(direction,"dst")?10:8;
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
        bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
        bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
        bpf_emit(out,48,0,0,0);v6_guard1=out->len;bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);
        v6_guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);
        v6_family=out->len;bpf_emit(out,21,0,0,34525);
        for(protocol_index=0;protocol_index<3;++protocol_index){
            v6_starts[protocol_index]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,14);
            v6_proto[protocol_index]=out->len;bpf_emit(out,21,0,0,protocols[protocol_index]);
            bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,v6offset);v6_low[protocol_index]=out->len;
            bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,0,low);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,v6offset);
            v6_high[protocol_index][0]=out->len;bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,0,high);
        }
        v4_start=out->len;bpf_emit(out,48,0,0,0);v4_guard1=out->len;bpf_emit(out,69,0,0,4);
        bpf_emit(out,48,0,0,0);v4_guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);v4_family=out->len;bpf_emit(out,21,0,0,2048);
        for(protocol_index=0;protocol_index<3;++protocol_index){
            v4_starts[protocol_index]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,17);
            v4_proto[protocol_index]=out->len;bpf_emit(out,21,0,0,protocols[protocol_index]);bpf_emit(out,97,0,0,0);
            bpf_emit(out,72,0,0,14);v4_frag[protocol_index]=out->len;bpf_emit(out,69,0,0,8191);
            bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
            bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,v4offset);
            v4_low[protocol_index]=out->len;bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,0,low);
            bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
            bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,v4offset);
            v4_high[protocol_index][0]=out->len;bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,0,high);
        }
        accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
        out->insns[v6_guard1].jt=(uint8_t)(v4_start-v6_guard1-1);out->insns[v6_guard2].jf=(uint8_t)(v4_start-v6_guard2-1);
        out->insns[v6_family].jf=(uint8_t)(v4_start-v6_family-1);
        for(protocol_index=0;protocol_index<3;++protocol_index){size_t next=protocol_index<2?v6_starts[protocol_index+1]:v4_start;
            out->insns[v6_proto[protocol_index]].jf=(uint8_t)(next-v6_proto[protocol_index]-1);
            out->insns[v6_low[protocol_index]].jf=(uint8_t)(next-v6_low[protocol_index]-1);
            out->insns[v6_high[protocol_index][0]].jt=(uint8_t)(next-v6_high[protocol_index][0]-1);
            out->insns[v6_high[protocol_index][0]].jf=(uint8_t)(accept-v6_high[protocol_index][0]-1);}
        out->insns[v4_guard1].jt=(uint8_t)(reject-v4_guard1-1);out->insns[v4_guard2].jf=(uint8_t)(reject-v4_guard2-1);
        out->insns[v4_family].jf=(uint8_t)(reject-v4_family-1);
        for(protocol_index=0;protocol_index<3;++protocol_index){size_t next=protocol_index<2?v4_starts[protocol_index+1]:reject;
            out->insns[v4_proto[protocol_index]].jf=(uint8_t)(next-v4_proto[protocol_index]-1);
            out->insns[v4_frag[protocol_index]].jt=(uint8_t)(next-v4_frag[protocol_index]-1);
            out->insns[v4_low[protocol_index]].jf=(uint8_t)(next-v4_low[protocol_index]-1);
            out->insns[v4_high[protocol_index][0]].jt=(uint8_t)(next-v4_high[protocol_index][0]-1);
            out->insns[v4_high[protocol_index][0]].jf=(uint8_t)(accept-v4_high[protocol_index][0]-1);}
        return 1;
    }
    if(sscanf(c->filter,"portrange %u-%u %7s",&low,&high,tail)!=2||low>65535||high>65535)return 0;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
    bpf_emit(out,48,0,0,0);v6_guard1=out->len;bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);
    v6_guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);
    v6_family=out->len;bpf_emit(out,21,0,0,34525);
    for(protocol_index=0;protocol_index<3;++protocol_index){
        v6_starts[protocol_index]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,14);
        v6_proto[protocol_index]=out->len;bpf_emit(out,21,0,0,protocols[protocol_index]);
        for(direction_index=0;direction_index<2;++direction_index){
            uint32_t offset=direction_index?50:48;
            bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,offset);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,3,low);
            bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,offset);v6_high[protocol_index][direction_index]=out->len;
            bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,0,high);
        }
    }
    v4_start=out->len;bpf_emit(out,48,0,0,0);v4_guard1=out->len;bpf_emit(out,69,0,0,4);
    bpf_emit(out,48,0,0,0);v4_guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);
    bpf_emit(out,72,0,0,6);v4_family=out->len;bpf_emit(out,21,0,0,2048);
    for(protocol_index=0;protocol_index<3;++protocol_index){
        v4_starts[protocol_index]=out->len;bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,17);
        v4_proto[protocol_index]=out->len;bpf_emit(out,21,0,0,protocols[protocol_index]);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,14);v4_frag[protocol_index]=out->len;bpf_emit(out,69,0,0,8191);
        for(direction_index=0;direction_index<2;++direction_index){
            uint32_t offset=direction_index?10:8;
            bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
            bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,offset);
            bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,protocol_index==2&&direction_index==1?9:8,low);
            bpf_emit(out,97,0,0,0);bpf_emit(out,80,0,0,8);bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);
            bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,72,0,0,offset);
            v4_high[protocol_index][direction_index]=out->len;bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,0,high);
        }
    }
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[v6_guard1].jt=(uint8_t)(v4_start-v6_guard1-1);out->insns[v6_guard2].jf=(uint8_t)(v4_start-v6_guard2-1);
    out->insns[v6_family].jf=(uint8_t)(v4_start-v6_family-1);
    for(protocol_index=0;protocol_index<3;++protocol_index){
        size_t next=protocol_index<2?v6_starts[protocol_index+1]:v4_start;
        out->insns[v6_proto[protocol_index]].jf=(uint8_t)(next-v6_proto[protocol_index]-1);
        for(direction_index=0;direction_index<2;++direction_index)
            out->insns[v6_high[protocol_index][direction_index]].jf=(uint8_t)(accept-v6_high[protocol_index][direction_index]-1);
    }
    out->insns[v4_guard1].jt=(uint8_t)(reject-v4_guard1-1);out->insns[v4_guard2].jf=(uint8_t)(reject-v4_guard2-1);
    out->insns[v4_family].jf=(uint8_t)(reject-v4_family-1);
    for(protocol_index=0;protocol_index<3;++protocol_index){
        size_t next=protocol_index<2?v4_starts[protocol_index+1]:reject;
        out->insns[v4_proto[protocol_index]].jf=(uint8_t)(next-v4_proto[protocol_index]-1);
        out->insns[v4_frag[protocol_index]].jt=(uint8_t)(next-v4_frag[protocol_index]-1);
        for(direction_index=0;direction_index<2;++direction_index){
            size_t jump=v4_high[protocol_index][direction_index];
            if(protocol_index==2&&direction_index==1)out->insns[jump].jt=(uint8_t)(reject-jump-1);
            out->insns[jump].jf=(uint8_t)(accept-jump-1);
        }
    }
    return 1;
}

static int generic_port_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], tail[8];
    unsigned port;
    int any = 0;
    uint32_t linkoff, ip6_family, ip4_family, v6_proto, v6_src, v6_dst;
    uint32_t v4_proto, fragment, ipbase;
    int raw=0;
    if(c->dlt==1){linkoff=12;ip6_family=34525;ip4_family=2048;v6_proto=20;v6_src=54;v6_dst=56;v4_proto=23;fragment=20;ipbase=14;}
    else if(c->dlt==9){linkoff=2;ip6_family=87;ip4_family=33;v6_proto=10;v6_src=44;v6_dst=46;v4_proto=13;fragment=10;ipbase=4;}
    else if(c->dlt==113){linkoff=14;ip6_family=34525;ip4_family=2048;v6_proto=22;v6_src=56;v6_dst=58;v4_proto=25;fragment=22;ipbase=16;}
    else if(c->dlt==0){linkoff=0;ip6_family=0x0a000000U;ip4_family=0x02000000U;v6_proto=10;v6_src=44;v6_dst=46;v4_proto=13;fragment=10;ipbase=4;raw=1;}
    else if(c->dlt==12){linkoff=0;ip6_family=96;ip4_family=64;v6_proto=6;v6_src=40;v6_dst=42;v4_proto=9;fragment=6;ipbase=0;raw=1;}
    else return 0;
    if (sscanf(c->filter, "%7s port %u %7s", direction, &port, tail) == 2) {
        if (strcmp(direction, "src") && strcmp(direction, "dst")) return 0;
    } else if (sscanf(c->filter, "port %u %7s", &port, tail) == 1) {
        any = 1;
    } else return 0;
    if (port > 65535) return 0;
    if(raw&&c->optimize&&any){
        if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        else bpf_emit(out,OP_LDW_ABS,0,0,0);
        bpf_emit(out,OP_JEQ_K,0,8,ip6_family);bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
        bpf_emit(out,OP_JEQ_K,2,0,132);bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,17,17);
        bpf_emit(out,OP_LDH_ABS,0,0,v6_src);bpf_emit(out,OP_JEQ_K,14,0,port);
        bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);bpf_emit(out,OP_JEQ_K,12,13,port);
        bpf_emit(out,OP_JEQ_K,0,12,ip4_family);bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
        bpf_emit(out,OP_JEQ_K,2,0,132);bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,8,17);
        bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,6,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
        bpf_emit(out,OP_LDH_IND,0,0,ipbase);bpf_emit(out,OP_JEQ_K,2,0,port);
        bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);bpf_emit(out,OP_JEQ_K,0,1,port);
        finish_test(out,c->snaplen);return 1;
    }
    if(raw&&(c->optimize||c->dlt==12))return 0;
    if (!c->optimize && any) {
        static const uint32_t protocols[3]={132,6,17};
        int index;
        const uint8_t v6src[3]={46,40,34}, v6dst[3]={44,38,32};
        bpf_emit(out,c->dlt==0?OP_LDW_ABS:OP_LDH_ABS,0,0,linkoff); bpf_emit(out,OP_JEQ_K,0,18,ip6_family);
        for(index=0;index<3;++index){
            bpf_emit(out,OP_LDB_ABS,0,0,v6_proto); bpf_emit(out,OP_JEQ_K,0,4,protocols[index]);
            bpf_emit(out,OP_LDH_ABS,0,0,v6_src); bpf_emit(out,OP_JEQ_K,v6src[index],0,port);
            bpf_emit(out,OP_LDH_ABS,0,0,v6_dst); bpf_emit(out,OP_JEQ_K,v6dst[index],0,port);
        }
        bpf_emit(out,c->dlt==0?OP_LDW_ABS:OP_LDH_ABS,0,0,linkoff); bpf_emit(out,OP_JEQ_K,0,31,ip4_family);
        bpf_emit(out,OP_LDB_ABS,0,0,v4_proto); bpf_emit(out,OP_JEQ_K,0,8,132);
        bpf_emit(out,OP_LDH_ABS,0,0,fragment); bpf_emit(out,OP_JSET_K,6,0,8191);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase); bpf_emit(out,OP_LDH_IND,0,0,ipbase); bpf_emit(out,OP_JEQ_K,23,0,port);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase); bpf_emit(out,OP_LDH_IND,0,0,ipbase+2); bpf_emit(out,OP_JEQ_K,20,0,port);
        bpf_emit(out,OP_LDB_ABS,0,0,v4_proto); bpf_emit(out,OP_JEQ_K,0,8,6);
        bpf_emit(out,OP_LDH_ABS,0,0,fragment); bpf_emit(out,OP_JSET_K,6,0,8191);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase); bpf_emit(out,OP_LDH_IND,0,0,ipbase); bpf_emit(out,OP_JEQ_K,13,0,port);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase); bpf_emit(out,OP_LDH_IND,0,0,ipbase+2); bpf_emit(out,OP_JEQ_K,10,0,port);
        bpf_emit(out,OP_LDB_ABS,0,0,v4_proto); bpf_emit(out,OP_JEQ_K,0,9,17);
        bpf_emit(out,OP_LDH_ABS,0,0,fragment); bpf_emit(out,OP_JSET_K,7,0,8191);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase); bpf_emit(out,OP_LDH_IND,0,0,ipbase); bpf_emit(out,OP_JEQ_K,3,0,port);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase); bpf_emit(out,OP_LDH_IND,0,0,ipbase+2); bpf_emit(out,OP_JEQ_K,0,1,port);
        finish_test(out,c->snaplen);
        return 1;
    }
    if (!c->optimize) {
        static const uint32_t protocols[3]={132,6,17};
        static const uint8_t v6_accept[3]={31,27,23};
        static const uint8_t v4_proto_reject[3]={5,5,6},v4_frag_accept[3]={3,3,4},v4_accept[3]={14,7,0};
        uint32_t absolute=!strcmp(direction,"dst")?v6_dst:v6_src;
        uint32_t indirect=!strcmp(direction,"dst")?ipbase+2:ipbase;
        int index;
        bpf_emit(out,OP_LDH_ABS,0,0,linkoff);
        if(c->dlt==0)out->insns[out->len-1].code=OP_LDW_ABS;
        bpf_emit(out,OP_JEQ_K,0,12,ip6_family);
        for(index=0;index<3;++index){
            bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);bpf_emit(out,OP_JEQ_K,0,2,protocols[index]);
            bpf_emit(out,OP_LDH_ABS,0,0,absolute);bpf_emit(out,OP_JEQ_K,v6_accept[index],0,port);
        }
        bpf_emit(out,c->dlt==0?OP_LDW_ABS:OP_LDH_ABS,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,22,ip4_family);
        for(index=0;index<3;++index){
            bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);bpf_emit(out,OP_JEQ_K,0,v4_proto_reject[index],protocols[index]);
            bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,v4_frag_accept[index],0,8191);
            bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,indirect);
            bpf_emit(out,OP_JEQ_K,v4_accept[index],index==2?1:0,port);
        }
        finish_test(out,c->snaplen);return 1;
    }
    bpf_emit(out, OP_LDH_ABS, 0, 0, linkoff);
    if (any) {
        bpf_emit(out, OP_JEQ_K, 0, 8, ip6_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v6_proto);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 17, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, v6_src);
        bpf_emit(out, OP_JEQ_K, 14, 0, port);
        bpf_emit(out, OP_LDH_ABS, 0, 0, v6_dst);
        bpf_emit(out, OP_JEQ_K, 12, 13, port);
        bpf_emit(out, OP_JEQ_K, 0, 12, ip4_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v4_proto);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 8, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, fragment);
        bpf_emit(out, OP_JSET_K, 6, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
        bpf_emit(out, OP_LDH_IND, 0, 0, ipbase);
        bpf_emit(out, OP_JEQ_K, 2, 0, port);
        bpf_emit(out, OP_LDH_IND, 0, 0, ipbase+2);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    } else {
        uint32_t absolute = !strcmp(direction, "dst") ? v6_dst : v6_src;
        uint32_t indirect = !strcmp(direction, "dst") ? ipbase+2 : ipbase;
        bpf_emit(out, OP_JEQ_K, 0, 6, ip6_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v6_proto);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 13, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, absolute);
        bpf_emit(out, OP_JEQ_K, 10, 11, port);
        bpf_emit(out, OP_JEQ_K, 0, 10, ip4_family);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v4_proto);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 6, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, fragment);
        bpf_emit(out, OP_JSET_K, 4, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
        bpf_emit(out, OP_LDH_IND, 0, 0, indirect);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_raw_direction_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],tail[8];unsigned port;uint32_t ip6,ip4,v6proto,v6port,v4proto,fragment,base,indirect;int raw;
    if(!c->optimize||sscanf(c->filter,"%7s port %u %7s",direction,&port,tail)!=2||
       (strcmp(direction,"src")&&strcmp(direction,"dst"))||port>65535||(c->dlt!=0&&c->dlt!=12))return 0;
    raw=c->dlt==12;
    if(raw){ip6=96;ip4=64;v6proto=6;v6port=!strcmp(direction,"dst")?42:40;v4proto=9;fragment=6;base=0;}
    else{ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6port=!strcmp(direction,"dst")?46:44;v4proto=13;fragment=10;base=4;}
    indirect=!strcmp(direction,"dst")?base+2:base;
    if(raw){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}else bpf_emit(out,OP_LDW_ABS,0,0,0);
    bpf_emit(out,OP_JEQ_K,0,6,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);bpf_emit(out,OP_JEQ_K,2,0,132);
    bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,(uint8_t)(13+(raw?2:0)),17);bpf_emit(out,OP_LDH_ABS,0,0,v6port);
    bpf_emit(out,OP_JEQ_K,(uint8_t)(10+(raw?2:0)),(uint8_t)(11+(raw?2:0)),port);
    if(raw){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    bpf_emit(out,OP_JEQ_K,0,10,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,2,0,132);
    bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,6,17);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
    bpf_emit(out,OP_JSET_K,4,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,indirect);
    bpf_emit(out,OP_JEQ_K,0,1,port);finish_test(out,c->snaplen);return 1;
}

static int portrange_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char protocol_name[8], tail[8];
    unsigned low, high;
    uint32_t protocol,linkoff,ip6_family,ip4_family,v6_proto,v6_src,v6_dst,v4_proto,fragment,ipbase;
    if (!c->optimize ||
        sscanf(c->filter, "%7s portrange %u-%u %7s", protocol_name, &low, &high, tail) != 3)
        return 0;
    if(c->dlt==1){linkoff=12;ip6_family=34525;ip4_family=2048;v6_proto=20;v6_src=54;v6_dst=56;v4_proto=23;fragment=20;ipbase=14;}
    else if(c->dlt==9){linkoff=2;ip6_family=87;ip4_family=33;v6_proto=10;v6_src=44;v6_dst=46;v4_proto=13;fragment=10;ipbase=4;}
    else if(c->dlt==113){linkoff=14;ip6_family=34525;ip4_family=2048;v6_proto=22;v6_src=56;v6_dst=58;v4_proto=25;fragment=22;ipbase=16;}
    else return 0;
    if (!strcmp(protocol_name, "tcp")) protocol = 6;
    else if (!strcmp(protocol_name, "udp")) protocol = 17;
    else if (!strcmp(protocol_name, "sctp")) protocol = 132;
    else return 0;
    bpf_emit(out, OP_LDH_ABS, 0, 0, linkoff);
    bpf_emit(out, OP_JEQ_K, 0, 7, ip6_family);
    bpf_emit(out, OP_LDB_ABS, 0, 0, v6_proto);
    bpf_emit(out, OP_JEQ_K, 0, 18, protocol);
    bpf_emit(out, OP_LDH_ABS, 0, 0, v6_src);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 0, 1, low);
    bpf_emit(out, BPF_JMP | BPF_JGT | BPF_K, 0, 14, high);
    bpf_emit(out, OP_LDH_ABS, 0, 0, v6_dst);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 11, 13, low);
    bpf_emit(out, OP_JEQ_K, 0, 12, ip4_family);
    bpf_emit(out, OP_LDB_ABS, 0, 0, v4_proto);
    bpf_emit(out, OP_JEQ_K, 0, 10, protocol);
    bpf_emit(out, OP_LDH_ABS, 0, 0, fragment);
    bpf_emit(out, OP_JSET_K, 8, 0, 8191);
    bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
    bpf_emit(out, OP_LDH_IND, 0, 0, ipbase);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 0, 1, low);
    bpf_emit(out, BPF_JMP | BPF_JGT | BPF_K, 0, 3, high);
    bpf_emit(out, OP_LDH_IND, 0, 0, ipbase+2);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 0, 2, low);
    bpf_emit(out, BPF_JMP | BPF_JGT | BPF_K, 1, 0, high);
    finish_test(out, c->snaplen);
    return 1;
}

static int fixed_direction_portrange_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],direction[8],tail[8];unsigned low,high;uint32_t protocol;
    uint32_t linkoff,ip6,ip4,v6proto,v6port,v4proto,fragment,ipbase,indirect;uint16_t linkload;
    if((c->optimize&&c->dlt==0)||sscanf(c->filter,"%7s %7s portrange %u-%u %7s",protocol_name,direction,&low,&high,tail)!=4)return 0;
    if(strcmp(direction,"src")&&strcmp(direction,"dst"))return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;
    else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6port=!strcmp(direction,"dst")?56:54;v4proto=23;fragment=20;ipbase=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip6=87;ip4=33;v6proto=10;v6port=!strcmp(direction,"dst")?46:44;v4proto=13;fragment=10;ipbase=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6port=!strcmp(direction,"dst")?58:56;v4proto=25;fragment=22;ipbase=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6port=!strcmp(direction,"dst")?46:44;v4proto=13;fragment=10;ipbase=4;}
    else return 0;
    indirect=!strcmp(direction,"dst")?ipbase+2:ipbase;
    if(c->optimize){
        bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,4,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
        bpf_emit(out,OP_JEQ_K,0,12,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6port);
        bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,8,10,low);bpf_emit(out,OP_JEQ_K,0,9,ip4);
        bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,0,7,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
        bpf_emit(out,OP_JSET_K,5,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,indirect);
        bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);
        finish_test(out,c->snaplen);return 1;
    }
    bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,6,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
    bpf_emit(out,OP_JEQ_K,0,4,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6port);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
    bpf_emit(out,OP_LDH_ABS,0,0,v6port);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,12,high);
    bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,11,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);
    bpf_emit(out,OP_JEQ_K,0,9,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,7,0,8191);
    bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,indirect);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,4,low);
    bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,indirect);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);
    finish_test(out,c->snaplen);return 1;
}

static int unoptimized_protocol_portrange_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],tail[8];unsigned low,high;uint32_t protocol,linkoff,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;uint16_t linkload;int both=0;
    if(c->optimize)return 0;
    if(sscanf(c->filter,"%7s src and dst portrange %u-%u %7s",protocol_name,&low,&high,tail)==3)both=1;
    else if(sscanf(c->filter,"%7s portrange %u-%u %7s",protocol_name,&low,&high,tail)!=3)return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;
    else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6src=54;v6dst=56;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip6=87;ip4=33;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6src=56;v6dst=58;v4proto=25;fragment=22;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==12){linkload=0;linkoff=0;ip6=96;ip4=64;v6proto=6;v6src=40;v6dst=42;v4proto=9;fragment=6;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    bpf_emit(out,OP_JEQ_K,0,10,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);bpf_emit(out,OP_JEQ_K,0,8,protocol);
    bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,both?6:2,low);bpf_emit(out,OP_LDH_ABS,0,0,v6src);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,both?4:0,both?0:(uint8_t)(22+(linkload?0:1)),high);bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
    bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,(uint8_t)(18+(linkload?0:1)),high);
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    bpf_emit(out,OP_JEQ_K,0,17,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,0,15,protocol);
    bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,13,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,both?10:3,low);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,both?7:0,both?0:6,high);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,4,low);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);finish_test(out,c->snaplen);return 1;
}

static int optimized_raw_direction_portrange_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],direction[8],tail[8];unsigned low,high;uint32_t protocol,v6port,indirect;
    if(!c->optimize||c->dlt!=12||sscanf(c->filter,"%7s %7s portrange %u-%u %7s",protocol_name,direction,&low,&high,tail)!=4||
       (strcmp(direction,"src")&&strcmp(direction,"dst")))return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;
    else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    v6port=!strcmp(direction,"dst")?42:40;indirect=!strcmp(direction,"dst")?2:0;
    bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);bpf_emit(out,OP_JEQ_K,0,4,96);
    bpf_emit(out,OP_LDB_ABS,0,0,6);bpf_emit(out,OP_JEQ_K,0,14,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6port);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,10,12,low);bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
    bpf_emit(out,OP_JEQ_K,0,9,64);bpf_emit(out,OP_LDB_ABS,0,0,9);bpf_emit(out,OP_JEQ_K,0,7,protocol);
    bpf_emit(out,OP_LDH_ABS,0,0,6);bpf_emit(out,OP_JSET_K,5,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,0);
    bpf_emit(out,OP_LDH_IND,0,0,indirect);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);finish_test(out,c->snaplen);return 1;
}

static int optimized_both_portrange_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],tail[8];unsigned low,high;uint32_t protocol,linkoff,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;
    if(!c->optimize||sscanf(c->filter,"%7s src and dst portrange %u-%u %7s",protocol_name,&low,&high,tail)!=3)return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;
    else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    if(c->dlt==1){linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6src=54;v6dst=56;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){linkoff=2;ip6=87;ip4=33;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6src=56;v6dst=58;v4proto=25;fragment=22;base=16;}
    else return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,7,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
    bpf_emit(out,OP_JEQ_K,0,18,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,16,low);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,15,0,high);bpf_emit(out,OP_LDH_ABS,0,0,v6dst);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,11,13,low);bpf_emit(out,OP_JEQ_K,0,12,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);
    bpf_emit(out,OP_JEQ_K,0,10,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,8,0,8191);
    bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,5,low);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,4,0,high);bpf_emit(out,OP_LDH_IND,0,0,base+2);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);
    finish_test(out,c->snaplen);return 1;
}

static int generic_portrange_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8],tail[8]; unsigned low,high; int any=0;
    uint32_t linkoff,ip6_family,ip4_family,v6_proto,v6_src,v6_dst,v4_proto,fragment,ipbase;uint16_t linkload;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip6_family=34525;ip4_family=2048;v6_proto=20;v6_src=54;v6_dst=56;v4_proto=23;fragment=20;ipbase=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip6_family=87;ip4_family=33;v6_proto=10;v6_src=44;v6_dst=46;v4_proto=13;fragment=10;ipbase=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip6_family=34525;ip4_family=2048;v6_proto=22;v6_src=56;v6_dst=58;v4_proto=25;fragment=22;ipbase=16;}
    else if(c->dlt==0&&c->optimize){linkload=OP_LDW_ABS;linkoff=0;ip6_family=0x0a000000U;ip4_family=0x02000000U;v6_proto=10;v6_src=44;v6_dst=46;v4_proto=13;fragment=10;ipbase=4;}
    else if(c->dlt==12&&!c->optimize){linkload=0;linkoff=0;ip6_family=96;ip4_family=64;v6_proto=6;v6_src=40;v6_dst=42;v4_proto=9;fragment=6;ipbase=0;}
    else return 0;
    if(sscanf(c->filter,"%7s portrange %u-%u %7s",direction,&low,&high,tail)==3){
        if(strcmp(direction,"src")&&strcmp(direction,"dst"))return 0;
    }else if(sscanf(c->filter,"portrange %u-%u %7s",&low,&high,tail)==2)any=1;
    else return 0;
    if(!c->optimize){
        static const uint32_t protocols[3]={132,6,17};int index;
        uint32_t absolute=!strcmp(direction,"dst")?v6_dst:v6_src;
        uint32_t indirect=!strcmp(direction,"dst")?ipbase+2:ipbase;
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);
        else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        if(any){
            static const uint8_t v6_src_reject[3]={74,64,54},v6_dst_reject[3]={70,60,50};
            static const uint8_t v4_proto_reject[3]={14,14,15},v4_frag_accept[3]={12,12,13};
            static const uint8_t v4_src_reject[3]={38,22,6},v4_dst_reject[3]={32,16,0};
            bpf_emit(out,OP_JEQ_K,0,30,ip6_family);
            for(index=0;index<3;++index){
                bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);bpf_emit(out,OP_JEQ_K,0,8,protocols[index]);
                bpf_emit(out,OP_LDH_ABS,0,0,v6_src);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
                bpf_emit(out,OP_LDH_ABS,0,0,v6_src);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,(uint8_t)(v6_src_reject[index]+(linkload?0:1)),high);
                bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
                bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,(uint8_t)(v6_dst_reject[index]+(linkload?0:1)),high);
            }
            if(linkload)bpf_emit(out,linkload,0,0,linkoff);
            else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
            bpf_emit(out,OP_JEQ_K,0,49,ip4_family);
            for(index=0;index<3;++index){
                bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);bpf_emit(out,OP_JEQ_K,0,v4_proto_reject[index],protocols[index]);
                bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,v4_frag_accept[index],0,8191);
                bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,ipbase);
                bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,3,low);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
                bpf_emit(out,OP_LDH_IND,0,0,ipbase);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,v4_src_reject[index],high);
                bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);
                bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,index==2?4:3,low);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
                bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,index==2?1:0,v4_dst_reject[index],high);
            }
        }else{
            static const uint8_t v6_reject[3]={44,38,32},v4_proto_reject[3]={8,8,9};
            static const uint8_t v4_frag_accept[3]={6,6,7},v4_reject[3]={20,10,0};
            bpf_emit(out,OP_JEQ_K,0,18,ip6_family);
            for(index=0;index<3;++index){
                bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);bpf_emit(out,OP_JEQ_K,0,4,protocols[index]);
                bpf_emit(out,OP_LDH_ABS,0,0,absolute);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
                bpf_emit(out,OP_LDH_ABS,0,0,absolute);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,(uint8_t)(v6_reject[index]+(linkload?0:1)),high);
            }
            if(linkload)bpf_emit(out,linkload,0,0,linkoff);
            else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
            bpf_emit(out,OP_JEQ_K,0,31,ip4_family);
            for(index=0;index<3;++index){
                bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);bpf_emit(out,OP_JEQ_K,0,v4_proto_reject[index],protocols[index]);
                bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,v4_frag_accept[index],0,8191);
                bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LDH_IND,0,0,indirect);
                bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,index==2?4:3,low);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
                bpf_emit(out,OP_LDH_IND,0,0,indirect);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,index==2?1:0,v4_reject[index],high);
            }
        }
        finish_test(out,c->snaplen);return 1;
    }
    bpf_emit(out,linkload,0,0,linkoff);
    if(any){
        bpf_emit(out,OP_JEQ_K,0,9,ip6_family); bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
        bpf_emit(out,OP_JEQ_K,2,0,132); bpf_emit(out,OP_JEQ_K,1,0,6); bpf_emit(out,OP_JEQ_K,0,20,17);
        bpf_emit(out,OP_LDH_ABS,0,0,v6_src); bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,low);
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,16,high); bpf_emit(out,OP_LDH_ABS,0,0,v6_dst);
        bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,13,15,low); bpf_emit(out,OP_JEQ_K,0,14,ip4_family);
        bpf_emit(out,OP_LDB_ABS,0,0,v4_proto); bpf_emit(out,OP_JEQ_K,2,0,132);
        bpf_emit(out,OP_JEQ_K,1,0,6); bpf_emit(out,OP_JEQ_K,0,10,17);
        bpf_emit(out,OP_LDH_ABS,0,0,fragment); bpf_emit(out,OP_JSET_K,8,0,8191); bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
        bpf_emit(out,OP_LDH_IND,0,0,ipbase); bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,low);
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,3,high); bpf_emit(out,OP_LDH_IND,0,0,ipbase+2);
        bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low); bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);
    }else{
        uint32_t absolute=!strcmp(direction,"dst")?v6_dst:v6_src,indirect=!strcmp(direction,"dst")?ipbase+2:ipbase;
        bpf_emit(out,OP_JEQ_K,0,6,ip6_family); bpf_emit(out,OP_LDB_ABS,0,0,v6_proto);
        bpf_emit(out,OP_JEQ_K,2,0,132); bpf_emit(out,OP_JEQ_K,1,0,6); bpf_emit(out,OP_JEQ_K,0,14,17);
        bpf_emit(out,OP_LDH_ABS,0,0,absolute); bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,10,12,low);
        bpf_emit(out,OP_JEQ_K,0,11,ip4_family); bpf_emit(out,OP_LDB_ABS,0,0,v4_proto);
        bpf_emit(out,OP_JEQ_K,2,0,132); bpf_emit(out,OP_JEQ_K,1,0,6); bpf_emit(out,OP_JEQ_K,0,7,17);
        bpf_emit(out,OP_LDH_ABS,0,0,fragment); bpf_emit(out,OP_JSET_K,5,0,8191); bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
        bpf_emit(out,OP_LDH_IND,0,0,indirect); bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);
    }
    finish_test(out,c->snaplen);return 1;
}

static int unoptimized_generic_both_portrange_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char tail[8];unsigned low,high;uint32_t linkoff,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;
    uint16_t linkload;static const uint32_t protocols[3]={132,6,17};int index;
    static const uint8_t v6_reject[3]={70,60,50};
    static const uint8_t v4_proto_reject[3]={14,14,15},v4_frag_accept[3]={12,12,13};
    static const uint8_t v4_low_reject[3]={9,9,10},v4_high_next[3]={6,6,7};
    static const uint8_t v4_dst_low_reject[3]={3,3,4},v4_dst_high_reject[3]={32,16,0};
    if(c->optimize||sscanf(c->filter,"src and dst portrange %u-%u %7s",&low,&high,tail)!=2)return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6src=54;v6dst=56;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip6=87;ip4=33;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6src=56;v6dst=58;v4proto=25;fragment=22;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else return 0;
    bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,30,ip6);
    for(index=0;index<3;++index){
        bpf_emit(out,OP_LDB_ABS,0,0,v6proto);bpf_emit(out,OP_JEQ_K,0,8,protocols[index]);
        bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,6,low);
        bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,4,0,high);
        bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
        bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,v6_reject[index],high);
    }
    bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,49,ip4);
    for(index=0;index<3;++index){
        bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,0,v4_proto_reject[index],protocols[index]);
        bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,v4_frag_accept[index],0,8191);
        bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);
        bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,v4_low_reject[index],low);bpf_emit(out,OP_LDX_MSH,0,0,base);
        bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,v4_high_next[index],0,high);
        bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base+2);
        bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,v4_dst_low_reject[index],low);bpf_emit(out,OP_LDX_MSH,0,0,base);
        bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,index==2?1:0,v4_dst_high_reject[index],high);
    }
    finish_test(out,c->snaplen);return 1;
}

static int ethernet_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char qualifier[8], address_text[32], tail[8];
    unsigned bytes[6];
    uint32_t low_word;
    uint32_t high_half;
    int fields, any = 0;
    if (c->dlt != 1) return 0;
    fields = sscanf(c->filter, "ether %7s host %31s %7s", qualifier, address_text, tail);
    if (fields != 2) {
        fields = sscanf(c->filter, "ether %7s %31s %7s", qualifier, address_text, tail);
        if (fields != 2) return 0;
    }
    if (!strcmp(qualifier, "host")) {
        strcpy(address_text, fields == 2 ? address_text : "");
        any = 1;
    } else if (strcmp(qualifier, "src") && strcmp(qualifier, "dst")) return 0;
    if (sscanf(address_text, "%x:%x:%x:%x:%x:%x", &bytes[0], &bytes[1], &bytes[2],
               &bytes[3], &bytes[4], &bytes[5]) != 6) return 0;
    low_word = (bytes[2] << 24) | (bytes[3] << 16) | (bytes[4] << 8) | bytes[5];
    high_half = (bytes[0] << 8) | bytes[1];
    if (any || !strcmp(qualifier, "src")) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 8);
        bpf_emit(out, OP_JEQ_K, 0, any ? 2 : 3, low_word);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 6);
        bpf_emit(out, OP_JEQ_K, any ? 4 : 0, any ? 0 : 1, high_half);
    }
    if (any || !strcmp(qualifier, "dst")) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 2);
        bpf_emit(out, OP_JEQ_K, 0, 3, low_word);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 0);
        bpf_emit(out, OP_JEQ_K, 0, 1, high_half);
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int radiotap_ether_host_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],address_text[32],tail[8];unsigned bytes[6];uint32_t low;uint32_t high;int fields;
    if(c->dlt!=105)return 0;
    fields=sscanf(c->filter,"ether %7s host %31s %7s",direction,address_text,tail);
    if(fields!=2)fields=sscanf(c->filter,"ether %7s %31s %7s",direction,address_text,tail);
    if(fields!=2||(strcmp(direction,"src")&&strcmp(direction,"dst")))return 0;
    if(sscanf(address_text,"%x:%x:%x:%x:%x:%x",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&bytes[4],&bytes[5])!=6)return 0;
    low=(bytes[2]<<24)|(bytes[3]<<16)|(bytes[4]<<8)|bytes[5];high=(bytes[0]<<8)|bytes[1];
    if(!strcmp(direction,"dst")){
        if(c->optimize){
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,12,0,4);bpf_emit(out,69,0,6,8);
            bpf_emit(out,48,0,0,1);bpf_emit(out,69,0,4,1);
            bpf_emit(out,32,0,0,18);bpf_emit(out,21,0,7,low);bpf_emit(out,40,0,0,16);bpf_emit(out,21,4,5,high);
            bpf_emit(out,32,0,0,6);bpf_emit(out,21,0,3,low);bpf_emit(out,40,0,0,4);bpf_emit(out,21,0,1,high);
        }else{
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,21,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,4,0,8);
            bpf_emit(out,32,0,0,6);bpf_emit(out,21,0,2,low);bpf_emit(out,40,0,0,4);bpf_emit(out,21,14,0,high);
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,13,8);bpf_emit(out,48,0,0,1);bpf_emit(out,69,4,0,1);
            bpf_emit(out,32,0,0,6);bpf_emit(out,21,0,2,low);bpf_emit(out,40,0,0,4);bpf_emit(out,21,6,0,high);
            bpf_emit(out,48,0,0,1);bpf_emit(out,69,0,5,1);bpf_emit(out,32,0,0,18);bpf_emit(out,21,0,3,low);
            bpf_emit(out,40,0,0,16);bpf_emit(out,21,0,1,high);
        }
    }else{
        if(c->optimize){
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,17,0,4);bpf_emit(out,69,0,11,8);bpf_emit(out,48,0,0,1);
            bpf_emit(out,69,0,9,2);bpf_emit(out,69,0,4,1);bpf_emit(out,32,0,0,26);bpf_emit(out,21,0,11,low);
            bpf_emit(out,40,0,0,24);bpf_emit(out,21,8,9,high);bpf_emit(out,32,0,0,18);bpf_emit(out,21,0,7,low);
            bpf_emit(out,40,0,0,16);bpf_emit(out,21,4,5,high);bpf_emit(out,32,0,0,12);bpf_emit(out,21,0,3,low);
            bpf_emit(out,40,0,0,10);bpf_emit(out,21,0,1,high);
        }else{
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,29,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,4,0,8);
            bpf_emit(out,32,0,0,12);bpf_emit(out,21,0,2,low);bpf_emit(out,40,0,0,10);bpf_emit(out,21,22,0,high);
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,21,8);bpf_emit(out,48,0,0,1);bpf_emit(out,69,4,0,2);
            bpf_emit(out,32,0,0,12);bpf_emit(out,21,0,2,low);bpf_emit(out,40,0,0,10);bpf_emit(out,21,14,0,high);
            bpf_emit(out,48,0,0,1);bpf_emit(out,69,0,13,2);bpf_emit(out,48,0,0,1);bpf_emit(out,69,4,0,1);
            bpf_emit(out,32,0,0,18);bpf_emit(out,21,0,2,low);bpf_emit(out,40,0,0,16);bpf_emit(out,21,6,0,high);
            bpf_emit(out,48,0,0,1);bpf_emit(out,69,0,5,1);bpf_emit(out,32,0,0,26);bpf_emit(out,21,0,3,low);
            bpf_emit(out,40,0,0,24);bpf_emit(out,21,0,1,high);
        }
    }
    finish_test(out,c->snaplen);return 1;
}

static int host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], tail[8];
    unsigned a, b, d, e;
    uint32_t address, ipoff, arpoff;
    int fields, any = 0;

    if (c->dlt != 1) return 0;
    fields = sscanf(c->filter, "%7s host %u.%u.%u.%u %7s", direction, &a, &b, &d, &e, tail);
    if (fields != 5) {
        fields = sscanf(c->filter, "host %u.%u.%u.%u %7s", &a, &b, &d, &e, tail);
        if (fields != 4) return 0;
        any = 1;
    } else if (strcmp(direction, "src") && strcmp(direction, "dst")) {
        return 0;
    }
    if (a > 255 || b > 255 || d > 255 || e > 255) return 0;
    address = (a << 24) | (b << 16) | (d << 8) | e;
    ipoff = !any && !strcmp(direction, "dst") ? 30 : 26;
    arpoff = !any && !strcmp(direction, "dst") ? 38 : 28;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    if (any && c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 4, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 26);
        bpf_emit(out, OP_JEQ_K, 8, 0, address);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 30);
        bpf_emit(out, OP_JEQ_K, 6, 7, address);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 5, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 28);
        bpf_emit(out, OP_JEQ_K, 2, 0, address);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 38);
        bpf_emit(out, OP_JEQ_K, 0, 1, address);
    } else if (any) {
        const uint32_t types[6] = {2048,2048,2054,2054,32821,32821};
        const uint32_t offsets[6] = {26,30,28,38,28,38};
        int index;
        for (index = 0; index < 6; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, index == 5 ? 3 : 2, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, offsets[index]);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(20 - 4 * index), index == 5 ? 1 : 0, address);
        }
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 2, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, ipoff);
        bpf_emit(out, OP_JEQ_K, 4, 5, address);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 3, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, arpoff);
        bpf_emit(out, OP_JEQ_K, 0, 1, address);
    } else {
        const uint32_t types[3] = {2048,2054,32821};
        int index;
        for (index = 0; index < 3; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, index == 2 ? 3 : 2, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, index ? arpoff : ipoff);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(8 - 4 * index), index == 2 ? 1 : 0, address);
        }
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int host_other_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],tail[8];unsigned a,b,d,e;uint32_t address,linkoff,family,src,dst,arpsrc=0,arpdst=0;uint16_t linkload;int any=0,has_arp;
    if(sscanf(c->filter,"%7s host %u.%u.%u.%u %7s",direction,&a,&b,&d,&e,tail)!=5){
        if(sscanf(c->filter,"host %u.%u.%u.%u %7s",&a,&b,&d,&e,tail)!=4)return 0;
        any=1;
    }else if(strcmp(direction,"src")&&strcmp(direction,"dst"))return 0;
    if(a>255||b>255||d>255||e>255)return 0;
    address=(a<<24)|(b<<16)|(d<<8)|e;
    if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;src=28;dst=32;arpsrc=30;arpdst=40;has_arp=1;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;src=16;dst=20;arpsrc=18;arpdst=28;has_arp=1;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;src=16;dst=20;has_arp=0;}
    else if(c->dlt==12){linkload=0;linkoff=0;family=64;src=12;dst=16;has_arp=0;}
    else return 0;
    if(!c->optimize&&!has_arp){
        uint32_t offsets[6]={src,dst,c->dlt==0?18:14,c->dlt==0?28:24,c->dlt==0?18:14,c->dlt==0?28:24};
        size_t starts_at[6],guards[6],tests[6],accept,reject;int count=any?6:3,index;
        if(!any){
            offsets[0]=!strcmp(direction,"dst")?dst:src;
            offsets[1]=offsets[2]=!strcmp(direction,"dst")?(c->dlt==0?28:24):(c->dlt==0?18:14);
        }
        for(index=0;index<count;++index){
            starts_at[index]=out->len;
            if(index<(any?2:1)){
                if(linkload)bpf_emit(out,linkload,0,0,linkoff);
                else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
            }else bpf_emit(out,OP_LD_IMM,0,0,1);
            guards[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,index<(any?2:1)?family:0);
            bpf_emit(out,OP_LDW_ABS,0,0,offsets[index]);
            tests[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,address);
        }
        accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
        for(index=0;index<count;++index){
            size_t failure=index+1<count?starts_at[index+1]:reject;
            out->insns[guards[index]].jf=(uint8_t)(failure-guards[index]-1);
            out->insns[tests[index]].jt=(uint8_t)(accept-tests[index]-1);
            out->insns[tests[index]].jf=(uint8_t)(failure-tests[index]-1);
        }
        return 1;
    }
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    if(!has_arp){
        if(any){bpf_emit(out,OP_JEQ_K,0,5,family);bpf_emit(out,OP_LDW_ABS,0,0,src);bpf_emit(out,OP_JEQ_K,2,0,address);bpf_emit(out,OP_LDW_ABS,0,0,dst);bpf_emit(out,OP_JEQ_K,0,1,address);}
        else{bpf_emit(out,OP_JEQ_K,0,3,family);bpf_emit(out,OP_LDW_ABS,0,0,!strcmp(direction,"dst")?dst:src);bpf_emit(out,OP_JEQ_K,0,1,address);}
        finish_test(out,c->snaplen);return 1;
    }
    if(any&&c->optimize){
        bpf_emit(out,OP_JEQ_K,0,4,family);bpf_emit(out,OP_LDW_ABS,0,0,src);bpf_emit(out,OP_JEQ_K,8,0,address);
        bpf_emit(out,OP_LDW_ABS,0,0,dst);bpf_emit(out,OP_JEQ_K,6,7,address);bpf_emit(out,OP_JEQ_K,1,0,2054);
        bpf_emit(out,OP_JEQ_K,0,5,32821);bpf_emit(out,OP_LDW_ABS,0,0,arpsrc);bpf_emit(out,OP_JEQ_K,2,0,address);
        bpf_emit(out,OP_LDW_ABS,0,0,arpdst);bpf_emit(out,OP_JEQ_K,0,1,address);
    }else if(any){
        const uint32_t types[6]={family,family,2054,2054,32821,32821};uint32_t offsets[6]={src,dst,arpsrc,arpdst,arpsrc,arpdst};int index;
        for(index=0;index<6;++index){
            if(index)bpf_emit(out,OP_LDH_ABS,0,0,linkoff);
            bpf_emit(out,OP_JEQ_K,0,index==5?3:2,types[index]);bpf_emit(out,OP_LDW_ABS,0,0,offsets[index]);
            bpf_emit(out,OP_JEQ_K,(uint8_t)(20-4*index),index==5?1:0,address);
        }
    }else if(c->optimize){
        uint32_t ipoff=!strcmp(direction,"dst")?dst:src,arpoff=!strcmp(direction,"dst")?arpdst:arpsrc;
        bpf_emit(out,OP_JEQ_K,0,2,family);bpf_emit(out,OP_LDW_ABS,0,0,ipoff);bpf_emit(out,OP_JEQ_K,4,5,address);
        bpf_emit(out,OP_JEQ_K,1,0,2054);bpf_emit(out,OP_JEQ_K,0,3,32821);bpf_emit(out,OP_LDW_ABS,0,0,arpoff);bpf_emit(out,OP_JEQ_K,0,1,address);
    }else{
        const uint32_t types[3]={family,2054,32821};uint32_t ipoff=!strcmp(direction,"dst")?dst:src,arpoff=!strcmp(direction,"dst")?arpdst:arpsrc;int index;
        for(index=0;index<3;++index){if(index)bpf_emit(out,OP_LDH_ABS,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,index==2?3:2,types[index]);
            bpf_emit(out,OP_LDW_ABS,0,0,index?arpoff:ipoff);bpf_emit(out,OP_JEQ_K,(uint8_t)(8-4*index),index==2?1:0,address);}
    }
    finish_test(out,c->snaplen);return 1;
}

static int ip_host_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],tail[8];unsigned a,b,d,e;uint32_t address,linkoff,family,base;uint16_t linkload;int any=0;
    if(sscanf(c->filter,"ip %7s host %u.%u.%u.%u %7s",direction,&a,&b,&d,&e,tail)!=5){
        if(sscanf(c->filter,"ip host %u.%u.%u.%u %7s",&a,&b,&d,&e,tail)!=4)return 0;
        any=1;
    }else if(strcmp(direction,"src")&&strcmp(direction,"dst"))return 0;
    address=(a<<24)|(b<<16)|(d<<8)|e;
    if(c->dlt==105&&!any){
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
        bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
        bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);bpf_emit(out,48,0,0,0);
        bpf_emit(out,69,9,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,7,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,4,2048);bpf_emit(out,97,0,0,0);
        bpf_emit(out,BPF_LD|BPF_W|BPF_IND,0,0,!strcmp(direction,"dst")?24:20);bpf_emit(out,21,0,1,address);
        finish_test(out,c->snaplen);return 1;
    }
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    if(!any){bpf_emit(out,OP_JEQ_K,0,3,family);bpf_emit(out,OP_LDW_ABS,0,0,base+(!strcmp(direction,"dst")?16:12));bpf_emit(out,OP_JEQ_K,0,1,address);}
    else if(c->optimize){bpf_emit(out,OP_JEQ_K,0,5,family);bpf_emit(out,OP_LDW_ABS,0,0,base+12);bpf_emit(out,OP_JEQ_K,2,0,address);bpf_emit(out,OP_LDW_ABS,0,0,base+16);bpf_emit(out,OP_JEQ_K,0,1,address);}
    else {bpf_emit(out,OP_JEQ_K,0,2,family);bpf_emit(out,OP_LDW_ABS,0,0,base+12);bpf_emit(out,OP_JEQ_K,4,0,address);if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}bpf_emit(out,OP_JEQ_K,0,3,family);bpf_emit(out,OP_LDW_ABS,0,0,base+16);bpf_emit(out,OP_JEQ_K,0,1,address);}
    finish_test(out,c->snaplen);return 1;
}

static int arp_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char protocol_name[8], direction[8], tail[8];
    unsigned a,b,d,e;
    uint32_t address, ethertype, offset, linkoff, source_offset, destination_offset;
    int any = 0;
    if (c->dlt != 1 && c->dlt != 9 && c->dlt != 105 && c->dlt != 113) return 0;
    if (sscanf(c->filter, "%7s %7s host %u.%u.%u.%u %7s", protocol_name, direction,
               &a,&b,&d,&e,tail) != 6) {
        if (sscanf(c->filter, "%7s host %u.%u.%u.%u %7s", protocol_name,
                   &a,&b,&d,&e,tail) != 5) return 0;
        any = 1;
    } else if (strcmp(direction,"src") && strcmp(direction,"dst")) return 0;
    if (!strcmp(protocol_name,"arp")) ethertype=2054;
    else if (!strcmp(protocol_name,"rarp")) ethertype=32821;
    else return 0;
    address=(a<<24)|(b<<16)|(d<<8)|e;
    if(c->dlt==105){
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
        bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
        bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
        if(any||!strcmp(direction,"src")){
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,any?8:9,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,any?6:7,8);
            bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,any?3:4,ethertype);
            bpf_emit(out,97,0,0,0);bpf_emit(out,64,0,0,22);bpf_emit(out,21,any?10:0,any?0:1,address);
        }
        if(any||!strcmp(direction,"dst")){
            bpf_emit(out,48,0,0,0);bpf_emit(out,69,9,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,7,8);
            bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,4,ethertype);
            bpf_emit(out,97,0,0,0);bpf_emit(out,64,0,0,32);bpf_emit(out,21,0,1,address);
        }
        finish_test(out,c->snaplen);return 1;
    }
    if(c->dlt==1){linkoff=12;source_offset=28;destination_offset=38;}
    else if(c->dlt==9){linkoff=2;source_offset=18;destination_offset=28;}
    else {linkoff=14;source_offset=30;destination_offset=40;}
    offset = !any && !strcmp(direction,"dst") ? destination_offset : source_offset;
    bpf_emit(out,OP_LDH_ABS,0,0,linkoff);
    if (!any) {
        bpf_emit(out,OP_JEQ_K,0,3,ethertype);
        bpf_emit(out,OP_LDW_ABS,0,0,offset);
        bpf_emit(out,OP_JEQ_K,0,1,address);
    } else if (c->optimize) {
        bpf_emit(out,OP_JEQ_K,0,5,ethertype);
        bpf_emit(out,OP_LDW_ABS,0,0,source_offset);
        bpf_emit(out,OP_JEQ_K,2,0,address);
        bpf_emit(out,OP_LDW_ABS,0,0,destination_offset);
        bpf_emit(out,OP_JEQ_K,0,1,address);
    } else {
        bpf_emit(out,OP_JEQ_K,0,2,ethertype);
        bpf_emit(out,OP_LDW_ABS,0,0,source_offset);
        bpf_emit(out,OP_JEQ_K,4,0,address);
        bpf_emit(out,OP_LDH_ABS,0,0,linkoff);
        bpf_emit(out,OP_JEQ_K,0,3,ethertype);
        bpf_emit(out,OP_LDW_ABS,0,0,destination_offset);
        bpf_emit(out,OP_JEQ_K,0,1,address);
    }
    finish_test(out,c->snaplen);
    return 1;
}

static int radiotap_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], tail[8];
    unsigned a,b,d,e;
    uint32_t address,types[6]={2048,2048,2054,2054,32821,32821};
    uint32_t offsets[6]={20,24,22,32,22,32};
    size_t starts_at[6],guard1[6],guard2[6],type_test[6],address_test[6],accept,reject;
    int block,count,any=0;
    if(c->dlt!=105)return 0;
    if(sscanf(c->filter,"%7s host %u.%u.%u.%u %7s",direction,&a,&b,&d,&e,tail)!=5||
       (strcmp(direction,"src")&&strcmp(direction,"dst"))){
        if(sscanf(c->filter,"host %u.%u.%u.%u %7s",&a,&b,&d,&e,tail)!=4)return 0;
        any=1;
    }
    address=(a<<24)|(b<<16)|(d<<8)|e;
    if(any)count=6;else{count=3;types[0]=2048;types[1]=2054;types[2]=32821;
        offsets[0]=!strcmp(direction,"dst")?24:20;offsets[1]=offsets[2]=!strcmp(direction,"dst")?32:22;}
    bpf_emit(out,1,0,0,0); bpf_emit(out,135,0,0,0); bpf_emit(out,4,0,0,24);
    bpf_emit(out,2,0,0,0); bpf_emit(out,80,0,0,0); bpf_emit(out,69,0,5,8);
    bpf_emit(out,69,4,0,4); bpf_emit(out,69,0,3,128); bpf_emit(out,96,0,0,0);
    bpf_emit(out,4,0,0,2); bpf_emit(out,2,0,0,0);
    for(block=0;block<count;++block){
        starts_at[block]=out->len;bpf_emit(out,48,0,0,0);guard1[block]=out->len;bpf_emit(out,69,0,0,4);
        bpf_emit(out,48,0,0,0);guard2[block]=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);type_test[block]=out->len;bpf_emit(out,21,0,0,types[block]);bpf_emit(out,97,0,0,0);
        bpf_emit(out,BPF_LD|BPF_W|BPF_IND,0,0,offsets[block]);address_test[block]=out->len;bpf_emit(out,21,0,0,address);
    }
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    for(block=0;block<count;++block){size_t failure=block+1<count?starts_at[block+1]:reject;
        out->insns[guard1[block]].jt=(uint8_t)(failure-guard1[block]-1);
        out->insns[guard2[block]].jf=(uint8_t)(failure-guard2[block]-1);
        out->insns[type_test[block]].jf=(uint8_t)(failure-type_test[block]-1);
        out->insns[address_test[block]].jt=(uint8_t)(accept-address_test[block]-1);
        out->insns[address_test[block]].jf=(uint8_t)(failure-address_test[block]-1);}
    return 1;
}

static int parse_ipv4_net(const char *text, char *direction, uint32_t *network, uint32_t *mask, int *any)
{
    unsigned a, b, c, d, bits, ma, mb, mc, md;
    char tail[8];
    int fields;

    fields = sscanf(text, "%7s net %u.%u.%u.%u/%u %7s", direction, &a, &b, &c, &d, &bits, tail);
    if (fields == 6 && (!strcmp(direction, "src") || !strcmp(direction, "dst"))) *any = 0;
    else {
        fields = sscanf(text, "net %u.%u.%u.%u/%u %7s", &a, &b, &c, &d, &bits, tail);
        if (fields == 5) *any = 1;
        else {
            fields = sscanf(text, "%7s net %u.%u.%u.%u mask %u.%u.%u.%u %7s",
                            direction, &a, &b, &c, &d, &ma, &mb, &mc, &md, tail);
            if (fields == 9 && (!strcmp(direction, "src") || !strcmp(direction, "dst"))) {
                *any = 0;
                *mask = (ma << 24) | (mb << 16) | (mc << 8) | md;
                bits = 33;
            } else {
                fields = sscanf(text, "net %u.%u.%u.%u mask %u.%u.%u.%u %7s",
                                &a, &b, &c, &d, &ma, &mb, &mc, &md, tail);
                if (fields != 8) return 0;
                *any = 1;
                *mask = (ma << 24) | (mb << 16) | (mc << 8) | md;
                bits = 33;
            }
        }
    }
    if (a > 255 || b > 255 || c > 255 || d > 255 || bits > 33) return 0;
    if (bits <= 32) *mask = bits ? UINT32_MAX << (32 - bits) : 0;
    *network = ((a << 24) | (b << 16) | (c << 8) | d) & *mask;
    return 1;
}

static int net_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8];
    uint32_t network, mask = 0, ipoff, arpoff;
    int any;

    if (c->dlt != 1 || !parse_ipv4_net(c->filter, direction, &network, &mask, &any)) return 0;
    ipoff = !any && !strcmp(direction, "dst") ? 30 : 26;
    arpoff = !any && !strcmp(direction, "dst") ? 38 : 28;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    if (any && c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 6, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 26);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 11, 0, network);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 30);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 8, 9, network);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 7, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 28);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 3, 0, network);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 38);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 0, 1, network);
    } else if (any) {
        const uint32_t types[6] = {2048,2048,2054,2054,32821,32821};
        const uint32_t offsets[6] = {26,30,28,38,28,38};
        int index;
        for (index = 0; index < 6; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, index == 5 ? 4 : 3, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, offsets[index]);
            bpf_emit(out, OP_AND_K, 0, 0, mask);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(25 - 5 * index), index == 5 ? 1 : 0, network);
        }
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 3, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, ipoff);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 5, 6, network);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 4, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, arpoff);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 0, 1, network);
    } else {
        const uint32_t types[3] = {2048,2054,32821};
        int index;
        for (index = 0; index < 3; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, index == 2 ? 4 : 3, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, index ? arpoff : ipoff);
            bpf_emit(out, OP_AND_K, 0, 0, mask);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(10 - 5 * index), index == 2 ? 1 : 0, network);
        }
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int net_other_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8];uint32_t network,mask=0,linkoff,family,src,dst;uint16_t linkload;int any;
    if(!parse_ipv4_net(c->filter,direction,&network,&mask,&any)||c->dlt==1||c->dlt==105)return 0;
    if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;src=28;dst=32;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;src=16;dst=20;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;src=16;dst=20;}
    else if(c->dlt==12){linkload=0;linkoff=0;family=64;src=12;dst=16;}
    else return 0;
    if(!c->optimize && (c->dlt==9||c->dlt==113)){
        uint32_t arpsrc=c->dlt==113?30:18,arpdst=c->dlt==113?40:28;
        if(any){
            const uint32_t types[6]={family,family,2054,2054,32821,32821};
            uint32_t offsets[6]={src,dst,arpsrc,arpdst,arpsrc,arpdst};
            int index;
            for(index=0;index<6;++index){
                bpf_emit(out,OP_LDH_ABS,0,0,linkoff);
                bpf_emit(out,OP_JEQ_K,0,index==5?4:3,types[index]);
                bpf_emit(out,OP_LDW_ABS,0,0,offsets[index]);
                bpf_emit(out,OP_AND_K,0,0,mask);
                bpf_emit(out,OP_JEQ_K,(uint8_t)(25-5*index),index==5?1:0,network);
            }
        }else{
            const uint32_t types[3]={family,2054,32821};
            uint32_t ipoff=!strcmp(direction,"dst")?dst:src;
            uint32_t arpoff=!strcmp(direction,"dst")?arpdst:arpsrc;
            int index;
            for(index=0;index<3;++index){
                bpf_emit(out,OP_LDH_ABS,0,0,linkoff);
                bpf_emit(out,OP_JEQ_K,0,index==2?4:3,types[index]);
                bpf_emit(out,OP_LDW_ABS,0,0,index?arpoff:ipoff);
                bpf_emit(out,OP_AND_K,0,0,mask);
                bpf_emit(out,OP_JEQ_K,(uint8_t)(10-5*index),index==2?1:0,network);
            }
        }
        finish_test(out,c->snaplen);return 1;
    }
    if(!c->optimize&&(c->dlt==0||c->dlt==12)){
        uint32_t offsets[6]={src,dst,14,24,14,24};
        size_t guards[6],tests[6],starts_at[6],accept,reject;
        int count=any?6:3,index;
        if(c->dlt==0){offsets[2]=offsets[4]=18;offsets[3]=offsets[5]=28;}
        if(!any){
            offsets[0]=!strcmp(direction,"dst")?dst:src;
            offsets[1]=offsets[2]=!strcmp(direction,"dst")?(c->dlt==0?28:24):(c->dlt==0?18:14);
        }
        for(index=0;index<count;++index){
            starts_at[index]=out->len;
            if(index<(any?2:1)){
                if(c->dlt==0)bpf_emit(out,OP_LDW_ABS,0,0,0);
                else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
            }
            else bpf_emit(out,OP_LD_IMM,0,0,1);
            guards[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,index<(any?2:1)?family:0);
            bpf_emit(out,OP_LDW_ABS,0,0,offsets[index]);bpf_emit(out,OP_AND_K,0,0,mask);
            tests[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,network);
        }
        accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
        for(index=0;index<count;++index){
            size_t failure=index+1<count?starts_at[index+1]:reject;
            out->insns[guards[index]].jf=(uint8_t)(failure-guards[index]-1);
            out->insns[tests[index]].jt=(uint8_t)(accept-tests[index]-1);
            out->insns[tests[index]].jf=(uint8_t)(failure-tests[index]-1);
        }
        return 1;
    }
    if(!c->optimize)return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    if(c->dlt==0||c->dlt==12){
        if(!any){bpf_emit(out,OP_JEQ_K,0,4,family);bpf_emit(out,OP_LDW_ABS,0,0,!strcmp(direction,"dst")?dst:src);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,1,network);}
        else{bpf_emit(out,OP_JEQ_K,0,7,family);bpf_emit(out,OP_LDW_ABS,0,0,src);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,3,0,network);bpf_emit(out,OP_LDW_ABS,0,0,dst);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,1,network);}
        finish_test(out,c->snaplen);return 1;
    }
    {
        uint32_t arpsrc=c->dlt==113?30:18,arpdst=c->dlt==113?40:28;
        if(!any){
            uint32_t ipoff=!strcmp(direction,"dst")?dst:src,arpoff=!strcmp(direction,"dst")?arpdst:arpsrc;
            bpf_emit(out,OP_JEQ_K,0,3,family);bpf_emit(out,OP_LDW_ABS,0,0,ipoff);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,5,6,network);
            bpf_emit(out,OP_JEQ_K,1,0,2054);bpf_emit(out,OP_JEQ_K,0,4,32821);bpf_emit(out,OP_LDW_ABS,0,0,arpoff);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,1,network);
        }else{
            bpf_emit(out,OP_JEQ_K,0,6,family);bpf_emit(out,OP_LDW_ABS,0,0,src);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,11,0,network);
            bpf_emit(out,OP_LDW_ABS,0,0,dst);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,8,9,network);bpf_emit(out,OP_JEQ_K,1,0,2054);bpf_emit(out,OP_JEQ_K,0,7,32821);
            bpf_emit(out,OP_LDW_ABS,0,0,arpsrc);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,3,0,network);bpf_emit(out,OP_LDW_ABS,0,0,arpdst);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,1,network);
        }
    }
    finish_test(out,c->snaplen);return 1;
}

static int optimized_both_net_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char filter[128],direction[8];uint32_t network,mask;int any;
    if((c->dlt!=9&&c->dlt!=12)||(!c->optimize&&c->dlt!=9)||!starts(c->filter,"src and dst net ")||
       snprintf(filter,sizeof(filter),"net %s",c->filter+16)>=(int)sizeof(filter)||
       !parse_ipv4_net(filter,direction,&network,&mask,&any))return 0;
    if(!c->optimize){
        static const uint32_t families[3]={33,2054,32821},sources[3]={16,18,18},destinations[3]={20,28,28};int index;
        for(index=0;index<3;++index){
            bpf_emit(out,OP_LDH_ABS,0,0,2);bpf_emit(out,OP_JEQ_K,0,index==2?9:8,families[index]);
            bpf_emit(out,OP_LDW_ABS,0,0,sources[index]);bpf_emit(out,OP_AND_K,0,0,mask);
            bpf_emit(out,OP_JEQ_K,0,index==2?6:5,network);bpf_emit(out,OP_LDH_ABS,0,0,2);
            bpf_emit(out,OP_JEQ_K,0,index==2?4:3,families[index]);bpf_emit(out,OP_LDW_ABS,0,0,destinations[index]);
            bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,index==0?20:(index==1?10:0),index==2?1:0,network);
        }
        finish_test(out,c->snaplen);return 1;
    }
    if(c->dlt==12){
        bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);bpf_emit(out,OP_JEQ_K,0,7,64);
        bpf_emit(out,OP_LDW_ABS,0,0,12);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,4,network);
        bpf_emit(out,OP_LDW_ABS,0,0,16);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,1,network);
    }else{
        bpf_emit(out,OP_LDH_ABS,0,0,2);bpf_emit(out,OP_JEQ_K,0,6,33);
        bpf_emit(out,OP_LDW_ABS,0,0,16);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,12,network);
        bpf_emit(out,OP_LDW_ABS,0,0,20);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,8,9,network);
        bpf_emit(out,OP_JEQ_K,1,0,2054);bpf_emit(out,OP_JEQ_K,0,7,32821);
        bpf_emit(out,OP_LDW_ABS,0,0,18);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,4,network);
        bpf_emit(out,OP_LDW_ABS,0,0,28);bpf_emit(out,OP_AND_K,0,0,mask);bpf_emit(out,OP_JEQ_K,0,1,network);
    }
    finish_test(out,c->snaplen);return 1;
}

static int radiotap_net_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8];uint32_t network,mask=0;int any,index,count;
    uint32_t types[6]={2048,2048,2054,2054,32821,32821};
    uint32_t offsets[6]={20,24,22,32,22,32};
    size_t starts_at[6],guards1[6],guards2[6],types_at[6],tests[6],accept,reject;
    if(c->dlt!=105||!parse_ipv4_net(c->filter,direction,&network,&mask,&any))return 0;
    if(!any){
        count=3;
        types[0]=2048;types[1]=2054;types[2]=32821;
        offsets[0]=!strcmp(direction,"dst")?24:20;
        offsets[1]=offsets[2]=!strcmp(direction,"dst")?32:22;
    }else count=6;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
    for(index=0;index<count;++index){
        starts_at[index]=out->len;bpf_emit(out,48,0,0,0);guards1[index]=out->len;bpf_emit(out,69,0,0,4);
        bpf_emit(out,48,0,0,0);guards2[index]=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);types_at[index]=out->len;bpf_emit(out,21,0,0,types[index]);bpf_emit(out,97,0,0,0);
        bpf_emit(out,64,0,0,offsets[index]);bpf_emit(out,84,0,0,mask);tests[index]=out->len;bpf_emit(out,21,0,0,network);
    }
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    for(index=0;index<count;++index){
        size_t failure=index+1<count?starts_at[index+1]:reject;
        out->insns[guards1[index]].jt=(uint8_t)(failure-guards1[index]-1);
        out->insns[guards2[index]].jf=(uint8_t)(failure-guards2[index]-1);
        out->insns[types_at[index]].jf=(uint8_t)(failure-types_at[index]-1);
        out->insns[tests[index]].jt=(uint8_t)(accept-tests[index]-1);
        out->insns[tests[index]].jf=(uint8_t)(failure-tests[index]-1);
    }
    return 1;
}

static int ipv6_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], address_text[80], tail[8];
    struct in6_addr binary;
    uint32_t words[4];
    int any = 0, fields, index;
    uint32_t base, linkoff, family, source_base, destination_base;
    uint16_t linkload;

    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=34525;source_base=22;destination_base=38;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=34525;source_base=24;destination_base=40;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=87;source_base=12;destination_base=28;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x0a000000U;source_base=12;destination_base=28;}
    else if(c->dlt==12){linkload=0;linkoff=0;family=96;source_base=8;destination_base=24;}
    else return 0;
    fields = sscanf(c->filter, "ip6 %7s host %79s %7s", direction, address_text, tail);
    if (fields != 2 || (strcmp(direction, "src") && strcmp(direction, "dst"))) {
        fields = sscanf(c->filter, "ip6 host %79s %7s", address_text, tail);
        if (fields != 1) return 0;
        any = 1;
    }
    if (!strcmp(address_text, "ip6-localhost") || !strcmp(address_text, "ip6-loopback")) strcpy(address_text, "::1");
    else if (!strcmp(address_text, "ip6-allnodes")) strcpy(address_text, "ff02::1");
    else if (!strcmp(address_text, "ip6-allrouters")) strcpy(address_text, "ff02::2");
    if (inet_pton(AF_INET6, address_text, &binary) != 1) return 0;
    for (index = 0; index < 4; ++index) {
        uint32_t network_word;
        memcpy(&network_word, binary.s6_addr + index * 4, 4);
        words[index] = ntohl(network_word);
    }
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    if (!any) {
        base = !strcmp(direction, "dst") ? destination_base : source_base;
        bpf_emit(out, OP_JEQ_K, 0, 9, family);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, base + index * 4);
            bpf_emit(out, OP_JEQ_K, 0, (uint8_t)(7 - index * 2), words[index]);
        }
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 17, family);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, source_base + index * 4);
            bpf_emit(out, OP_JEQ_K, index == 3 ? 8 : 0, (uint8_t)(6 - index * 2), words[index]);
        }
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, destination_base + index * 4);
            bpf_emit(out, OP_JEQ_K, 0, (uint8_t)(7 - index * 2), words[index]);
        }
    } else {
        bpf_emit(out, OP_JEQ_K, 0, 8, family);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, source_base + index * 4);
            bpf_emit(out, OP_JEQ_K, index == 3 ? 10 : 0, (uint8_t)(6 - index * 2), words[index]);
        }
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);
        else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        bpf_emit(out, OP_JEQ_K, 0, 9, family);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, destination_base + index * 4);
            bpf_emit(out, OP_JEQ_K, 0, (uint8_t)(7 - index * 2), words[index]);
        }
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int radiotap_ipv6_host_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],address_text[80],tail[8];struct in6_addr binary;uint32_t words[4];
    int any=0,fields,index,block,count;uint32_t bases[2];
    size_t starts_at[2],guard1[2],guard2[2],family_test[2],word_tests[2][4],accept,reject;
    if(c->dlt!=105)return 0;
    fields=sscanf(c->filter,"ip6 %7s host %79s %7s",direction,address_text,tail);
    if(fields!=2||(strcmp(direction,"src")&&strcmp(direction,"dst"))){
        fields=sscanf(c->filter,"ip6 host %79s %7s",address_text,tail);if(fields!=1)return 0;any=1;
    }
    if(!strcmp(address_text,"ip6-localhost")||!strcmp(address_text,"ip6-loopback"))strcpy(address_text,"::1");
    else if(!strcmp(address_text,"ip6-allnodes"))strcpy(address_text,"ff02::1");
    else if(!strcmp(address_text,"ip6-allrouters"))strcpy(address_text,"ff02::2");
    if(inet_pton(AF_INET6,address_text,&binary)!=1)return 0;
    for(index=0;index<4;++index){uint32_t value;memcpy(&value,binary.s6_addr+index*4,4);words[index]=ntohl(value);}
    count=any?2:1;bases[0]=any||!strcmp(direction,"src")?16:32;bases[1]=32;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
    for(block=0;block<count;++block){
        starts_at[block]=out->len;bpf_emit(out,48,0,0,0);guard1[block]=out->len;bpf_emit(out,69,0,0,4);
        bpf_emit(out,48,0,0,0);guard2[block]=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);family_test[block]=out->len;bpf_emit(out,21,0,0,34525);
        for(index=0;index<4;++index){
            bpf_emit(out,97,0,0,0);bpf_emit(out,64,0,0,bases[block]+index*4);
            word_tests[block][index]=out->len;bpf_emit(out,21,0,0,words[index]);
        }
    }
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    for(block=0;block<count;++block){
        size_t failure=block+1<count?starts_at[block+1]:reject;
        out->insns[guard1[block]].jt=(uint8_t)(failure-guard1[block]-1);
        out->insns[guard2[block]].jf=(uint8_t)(failure-guard2[block]-1);
        out->insns[family_test[block]].jf=(uint8_t)(failure-family_test[block]-1);
        for(index=0;index<4;++index)out->insns[word_tests[block][index]].jf=(uint8_t)(failure-word_tests[block][index]-1);
        out->insns[word_tests[block][3]].jt=(uint8_t)(accept-word_tests[block][3]-1);
    }
    return 1;
}

static int radiotap_localhost_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],tail[8];uint32_t ip_offset,arp_offset;size_t next,accept,reject;
    size_t guard1,guard2,type_test,word_tests[4],block_starts[3],block_guard1[3],block_guard2[3],block_type[3],block_test[3];int index;
    static const uint32_t types[3]={2048,2054,32821};
    if(c->dlt!=105||sscanf(c->filter,"%7s host localhost %7s",direction,tail)!=1||
       (strcmp(direction,"src")&&strcmp(direction,"dst")))return 0;
    ip_offset=!strcmp(direction,"dst")?24:20;arp_offset=!strcmp(direction,"dst")?32:22;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
    bpf_emit(out,48,0,0,0);guard1=out->len;bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);
    guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);bpf_emit(out,72,0,0,6);
    type_test=out->len;bpf_emit(out,21,0,0,34525);
    for(index=0;index<4;++index){bpf_emit(out,97,0,0,0);bpf_emit(out,64,0,0,(!strcmp(direction,"dst")?32:16)+index*4);
        word_tests[index]=out->len;bpf_emit(out,21,0,0,index==3?1:0);}
    next=out->len;
    out->insns[guard1].jt=(uint8_t)(next-guard1-1);out->insns[guard2].jf=(uint8_t)(next-guard2-1);
    out->insns[type_test].jf=(uint8_t)(next-type_test-1);
    for(index=0;index<4;++index)out->insns[word_tests[index]].jf=(uint8_t)(next-word_tests[index]-1);
    for(index=0;index<3;++index){
        block_starts[index]=out->len;bpf_emit(out,48,0,0,0);block_guard1[index]=out->len;bpf_emit(out,69,0,0,4);
        bpf_emit(out,48,0,0,0);block_guard2[index]=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,0);
        bpf_emit(out,72,0,0,6);block_type[index]=out->len;bpf_emit(out,21,0,0,types[index]);bpf_emit(out,97,0,0,0);
        bpf_emit(out,64,0,0,index?arp_offset:ip_offset);block_test[index]=out->len;bpf_emit(out,21,0,0,0x7f000001U);
    }
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[word_tests[3]].jt=(uint8_t)(accept-word_tests[3]-1);
    for(index=0;index<3;++index){size_t failure=index<2?block_starts[index+1]:reject;
        out->insns[block_guard1[index]].jt=(uint8_t)(failure-block_guard1[index]-1);
        out->insns[block_guard2[index]].jf=(uint8_t)(failure-block_guard2[index]-1);
        out->insns[block_type[index]].jf=(uint8_t)(failure-block_type[index]-1);
        out->insns[block_test[index]].jt=(uint8_t)(accept-block_test[index]-1);
        out->insns[block_test[index]].jf=(uint8_t)(failure-block_test[index]-1);}
    return 1;
}

static int ipv6_net_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], address_text[80], tail[8];
    struct in6_addr binary;
    uint32_t words[4];
    unsigned prefix;
    int any=0, fields, word_count, index;
    uint32_t linkoff,family,source_base,destination_base;
    uint16_t linkload;
    size_t guard, source_start, destination_start, accept, reject;
    size_t source_jumps[4], destination_jumps[4];
    if(c->dlt==105){
        size_t type_guard1,type_guard2,family_guard,tests[4];
        fields=sscanf(c->filter,"ip6 %7s net %79[^/]/%u %7s",direction,address_text,&prefix,tail);
        if(fields!=3||(strcmp(direction,"src")&&strcmp(direction,"dst"))||prefix>128||
           inet_pton(AF_INET6,address_text,&binary)!=1)return 0;
        for(index=0;index<4;++index){uint32_t word;memcpy(&word,binary.s6_addr+index*4,4);words[index]=ntohl(word);}
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);
        bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,0);
        bpf_emit(out,OP_JSET_K,0,5,8);bpf_emit(out,OP_JSET_K,4,0,4);bpf_emit(out,OP_JSET_K,0,3,128);
        bpf_emit(out,OP_LD_MEM,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,OP_LDB_ABS,0,0,0);type_guard1=out->len;bpf_emit(out,OP_JSET_K,0,0,4);
        bpf_emit(out,OP_LDB_ABS,0,0,0);type_guard2=out->len;bpf_emit(out,OP_JSET_K,0,0,8);
        bpf_emit(out,OP_LDX_MEM,0,0,0);bpf_emit(out,OP_LDH_IND,0,0,6);
        family_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,34525);
        for(index=0;index<4;++index){
            unsigned consumed=(unsigned)index*32;
            unsigned remaining=prefix>consumed?prefix-consumed:0;
            uint32_t mask=remaining>=32?UINT32_MAX:(remaining?UINT32_MAX<<(32-remaining):0);
            bpf_emit(out,OP_LDX_MEM,0,0,0);
            bpf_emit(out,BPF_LD|BPF_W|BPF_IND,0,0,(!strcmp(direction,"dst")?32:16)+(uint32_t)index*4);
            if(mask!=UINT32_MAX)bpf_emit(out,OP_AND_K,0,0,mask);
            tests[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,words[index]&mask);
        }
        accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
        out->insns[type_guard1].jt=(uint8_t)(reject-type_guard1-1);
        out->insns[type_guard2].jf=(uint8_t)(reject-type_guard2-1);
        out->insns[family_guard].jf=(uint8_t)(reject-family_guard-1);
        for(index=0;index<4;++index)out->insns[tests[index]].jf=(uint8_t)(reject-tests[index]-1);
        (void)accept;return 1;
    }
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=34525;source_base=22;destination_base=38;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=34525;source_base=24;destination_base=40;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=87;source_base=12;destination_base=28;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x0a000000U;source_base=12;destination_base=28;}
    else if(c->dlt==12){linkload=0;linkoff=0;family=96;source_base=8;destination_base=24;}
    else return 0;
    fields=sscanf(c->filter,"ip6 %7s net %79[^/]/%u %7s",direction,address_text,&prefix,tail);
    if(fields!=3||(strcmp(direction,"src")&&strcmp(direction,"dst"))){
        fields=sscanf(c->filter,"ip6 net %79[^/]/%u %7s",address_text,&prefix,tail);
        if(fields!=2)return 0;
        any=1;
    }
    if(prefix>128||inet_pton(AF_INET6,address_text,&binary)!=1)return 0;
    for(index=0;index<4;++index){uint32_t w;memcpy(&w,binary.s6_addr+index*4,4);words[index]=ntohl(w);}
    if(!c->optimize){
        size_t first_guard, second_guard=0, second_start=0;
        word_count=4;
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        first_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
        for(index=0;index<word_count;++index){
            unsigned consumed=(unsigned)index*32;
            unsigned remaining=prefix>consumed?prefix-consumed:0;
            uint32_t mask=remaining>=32?UINT32_MAX:(remaining?UINT32_MAX<<(32-remaining):0);
            uint32_t base=(!any&&!strcmp(direction,"dst"))?destination_base:source_base;
            bpf_emit(out,OP_LDW_ABS,0,0,base+index*4);
            if(mask!=UINT32_MAX)bpf_emit(out,OP_AND_K,0,0,mask);
            source_jumps[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,words[index]&mask);
        }
        if(any){
            second_start=out->len;
            if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
            second_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
            for(index=0;index<word_count;++index){
                unsigned consumed=(unsigned)index*32;
                unsigned remaining=prefix>consumed?prefix-consumed:0;
                uint32_t mask=remaining>=32?UINT32_MAX:(remaining?UINT32_MAX<<(32-remaining):0);
                bpf_emit(out,OP_LDW_ABS,0,0,destination_base+index*4);
                if(mask!=UINT32_MAX)bpf_emit(out,OP_AND_K,0,0,mask);
                destination_jumps[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,words[index]&mask);
            }
        }
        accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
        out->insns[first_guard].jf=(uint8_t)((any?second_start:reject)-first_guard-1);
        for(index=0;index<word_count;++index){
            size_t jump=source_jumps[index];
            if(any&&index==word_count-1)out->insns[jump].jt=(uint8_t)(accept-jump-1);
            out->insns[jump].jf=(uint8_t)((any?second_start:reject)-jump-1);
        }
        if(any){
            out->insns[second_guard].jf=(uint8_t)(reject-second_guard-1);
            for(index=0;index<word_count;++index)
                out->insns[destination_jumps[index]].jf=(uint8_t)(reject-destination_jumps[index]-1);
        }
        return 1;
    }
    if(prefix==0)return emit_ethertype(c,out,0x86dd);
    word_count=(int)((prefix+31)/32);
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    guard=out->len; bpf_emit(out,OP_JEQ_K,0,0,family);
    source_start=out->len;
    {
        uint32_t base=(!any&&!strcmp(direction,"dst"))?destination_base:source_base;
        for(index=0;index<word_count;++index){
            unsigned remaining=prefix-index*32;
            uint32_t mask=remaining>=32?UINT32_MAX:UINT32_MAX<<(32-remaining);
            bpf_emit(out,OP_LDW_ABS,0,0,base+index*4);
            if(mask!=UINT32_MAX)bpf_emit(out,OP_AND_K,0,0,mask);
            source_jumps[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,words[index]&mask);
        }
    }
    destination_start=out->len;
    if(any){
        for(index=0;index<word_count;++index){
            unsigned remaining=prefix-index*32;
            uint32_t mask=remaining>=32?UINT32_MAX:UINT32_MAX<<(32-remaining);
            bpf_emit(out,OP_LDW_ABS,0,0,destination_base+index*4);
            if(mask!=UINT32_MAX)bpf_emit(out,OP_AND_K,0,0,mask);
            destination_jumps[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,words[index]&mask);
        }
    }
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[guard].jf=(uint8_t)(reject-guard-1);
    for(index=0;index<word_count;++index){
        size_t jump=source_jumps[index];
        if(index==word_count-1)out->insns[jump].jt=(uint8_t)(accept-jump-1);
        out->insns[jump].jf=(uint8_t)((any?destination_start:reject)-jump-1);
    }
    if(any)for(index=0;index<word_count;++index){
        size_t jump=destination_jumps[index];
        if(index==word_count-1)out->insns[jump].jt=(uint8_t)(accept-jump-1);
        out->insns[jump].jf=(uint8_t)(reject-jump-1);
    }
    (void)source_start;
    return 1;
}

static int length_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char operator_text[3], tail[8];
    unsigned value;
    uint16_t jump;
    int invert = 0;

    if (sscanf(c->filter, "greater %u %7s", &value, tail) == 1) {
        jump = BPF_JMP | BPF_JGE | BPF_K;
    } else if (sscanf(c->filter, "less %u %7s", &value, tail) == 1) {
        jump = BPF_JMP | BPF_JGT | BPF_K;
        invert = 1;
    } else if (sscanf(c->filter, "len %2s %u %7s", operator_text, &value, tail) == 2) {
        if (!strcmp(operator_text, ">")) jump = BPF_JMP | BPF_JGT | BPF_K;
        else if (!strcmp(operator_text, ">=")) jump = BPF_JMP | BPF_JGE | BPF_K;
        else if (!strcmp(operator_text, "=" ) || !strcmp(operator_text, "==")) jump = OP_JEQ_K;
        else if (!strcmp(operator_text, "<=")) { jump = BPF_JMP | BPF_JGT | BPF_K; invert = 1; }
        else if (!strcmp(operator_text, "<")) { jump = BPF_JMP | BPF_JGE | BPF_K; invert = 1; }
        else return 0;
    } else return 0;

    if (!c->optimize && starts(c->filter,"len ")) {
        if (strcmp(operator_text,">") && strcmp(operator_text,"<=")) return 0;
        invert = !strcmp(operator_text,"<=");
        bpf_emit(out,BPF_LD|BPF_W|BPF_LEN,0,0,0); bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,OP_LD_IMM,0,0,value); bpf_emit(out,OP_ST_MEM,0,0,1);
        bpf_emit(out,OP_LDX_MEM,0,0,1); bpf_emit(out,OP_LD_MEM,0,0,0);
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,0,1,0);
        bpf_emit(out,OP_RET_K,0,0,invert ? 0 : (uint32_t)c->snaplen);
        bpf_emit(out,OP_RET_K,0,0,invert ? (uint32_t)c->snaplen : 0);
        return 1;
    }

    bpf_emit(out, BPF_LD | BPF_W | BPF_LEN, 0, 0, 0);
    bpf_emit(out, jump, 0, 1, value);
    bpf_emit(out, OP_RET_K, 0, 0, invert ? 0 : (uint32_t)c->snaplen);
    bpf_emit(out, OP_RET_K, 0, 0, invert ? (uint32_t)c->snaplen : 0);
    return 1;
}

static int boolean_length_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    if(!length_compile(c,out))return 0;
    if(out->len>=4&&out->insns[out->len-2].k==0&&out->insns[out->len-1].k==(uint32_t)c->snaplen){
        bpf_insn_t *jump=&out->insns[out->len-3];
        uint8_t temporary=jump->jt;jump->jt=jump->jf;jump->jf=temporary;
        out->insns[out->len-2].k=(uint32_t)c->snaplen;out->insns[out->len-1].k=0;
    }
    return 1;
}

static int flag_value(const char *text, uint32_t *value)
{
    char buffer[96], *token, *save;
    char *end;
    size_t length = strlen(text);
    uint32_t result = 0;
    if (length >= sizeof(buffer)) return 0;
    strcpy(buffer, text);
    while (length && (buffer[length - 1] == ' ' || buffer[length - 1] == ')')) buffer[--length] = 0;
    token = buffer;
    while (*token == ' ' || *token == '(') ++token;
    for (token = strtok_r(token, "|", &save); token; token = strtok_r(NULL, "|", &save)) {
        while (*token == ' ') ++token;
        length = strlen(token);
        while (length && token[length - 1] == ' ') token[--length] = 0;
        if (!strcmp(token, "tcp-fin")) result |= 1;
        else if (!strcmp(token, "tcp-syn")) result |= 2;
        else if (!strcmp(token, "tcp-rst")) result |= 4;
        else if (!strcmp(token, "tcp-push")) result |= 8;
        else if (!strcmp(token, "tcp-ack")) result |= 16;
        else if (!strcmp(token, "tcp-urg")) result |= 32;
        else if (!strcmp(token, "tcp-ece")) result |= 64;
        else if (!strcmp(token, "tcp-cwr")) result |= 128;
        else {
            result |= (uint32_t)strtoul(token, &end, 0);
            if (*end) return 0;
        }
    }
    *value = result;
    return 1;
}

static int tcp_flag_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    const char *amp, *comparison;
    char mask_text[96], operator_text[3];
    uint32_t mask, rhs;
    char right_text[48];
    size_t guard, protojump, fragjump, testjump, accept, reject;
    uint32_t protooff, fragword, ipbase, dataoff;

    if (!(starts(c->filter, "tcp[13]") || starts(c->filter, "tcp[tcpflags]"))) return 0;
    amp = strchr(c->filter, '&');
    if (!amp) return 0;
    comparison = strstr(amp, " != ");
    if (!comparison) comparison = strstr(amp, " = ");
    if (!comparison) comparison = strstr(amp, " == ");
    if (!comparison || (size_t)(comparison - amp - 1) >= sizeof(mask_text)) return 0;
    memcpy(mask_text, amp + 1, (size_t)(comparison - amp - 1));
    mask_text[comparison - amp - 1] = 0;
    if (sscanf(comparison, " %2s %47s", operator_text, right_text) != 2 ||
        !flag_value(mask_text, &mask) || !flag_value(right_text, &rhs)) return 0;

    if(c->dlt==105&&!strchr(mask_text,'|')){
        static const uint32_t insns[][4]={
            {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,2},{80,0,0,0},{69,0,5,8},{69,4,0,4},{69,0,3,128},{96,0,0,2},{4,0,0,2},{2,0,0,2},
            {48,0,0,0},{69,60,0,4},{48,0,0,0},{69,0,58,8},{97,0,0,2},{72,0,0,6},{21,0,55,2048},{48,0,0,0},{69,8,0,4},{48,0,0,0},
            {69,0,6,8},{97,0,0,2},{72,0,0,6},{21,0,3,2048},{97,0,0,2},{80,0,0,17},{21,16,0,6},{48,0,0,0},{69,43,0,4},{48,0,0,0},
            {69,0,41,8},{97,0,0,2},{72,0,0,6},{21,0,38,34525},{97,0,0,2},{80,0,0,14},{21,6,0,6},{97,0,0,2},{80,0,0,14},{21,0,32,44},
            {97,0,0,2},{80,0,0,48},{21,0,29,6},{97,0,0,2},{72,0,0,14},{69,26,0,8191},{0,0,0,13},{2,0,0,0},{97,0,0,2},{80,0,0,8},
            {84,0,0,15},{100,0,0,2},{12,0,0,0},{7,0,0,0},{96,0,0,0},{12,0,0,0},{7,0,0,0},{80,0,0,8},{2,0,0,1},{0,0,0,32},{2,0,0,3},
            {97,0,0,3},{96,0,0,1},{92,0,0,0},{2,0,0,3},{0,0,0,22},{2,0,0,4},{97,0,0,4},{96,0,0,3},{28,0,0,0},{21,1,0,0}
        };
        size_t index;
        for(index=0;index<sizeof(insns)/sizeof(insns[0]);++index){
            uint32_t value=insns[index][3];uint8_t jt=(uint8_t)insns[index][1],jf=(uint8_t)insns[index][2];
            if(index==60)value=mask;else if(index==66)value=rhs;
            else if(index==71&&!strcmp(operator_text,"=")){jt=0;jf=1;}
            bpf_emit(out,(uint16_t)insns[index][0],jt,jf,value);
        }
        finish_test(out,c->snaplen);return 1;
    }

    if (c->dlt == 1) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12); protooff = 23; fragword = 20; ipbase = 14; dataoff = 27;
    } else if (c->dlt == 113) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 14); protooff = 25; fragword = 22; ipbase = 16; dataoff = 29;
    } else if (c->dlt == 9) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 2); protooff = 13; fragword = 10; ipbase = 4; dataoff = 17;
    } else if (c->dlt == 0) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 0); protooff = 13; fragword = 10; ipbase = 4; dataoff = 17;
    } else if (c->dlt == 12) {
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
        protooff = 9; fragword = 6; ipbase = 0; dataoff = 13;
    } else return 0;
    if(!c->optimize){
        uint16_t family_load=c->dlt==0?OP_LDW_ABS:OP_LDH_ABS;
        uint32_t linkoff=c->dlt==1?12:(c->dlt==9?2:(c->dlt==113?14:0));
        uint32_t ip4=c->dlt==9?33:(c->dlt==0?0x02000000U:(c->dlt==12?64:2048));
        uint32_t ip6=c->dlt==9?87:(c->dlt==0?0x0a000000U:(c->dlt==12?96:34525));
        uint32_t v6proto=c->dlt==1?20:(c->dlt==113?22:(c->dlt==12?6:10));
        uint32_t v6frag=c->dlt==1?54:(c->dlt==113?56:(c->dlt==12?40:44));
        bpf_emit(out,OP_JEQ_K,0,c->dlt==12?37:35,ip4);
        if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}else bpf_emit(out,family_load,0,0,linkoff);
        bpf_emit(out,OP_JEQ_K,0,2,ip4);
        bpf_emit(out,OP_LDB_ABS,0,0,protooff);bpf_emit(out,OP_JEQ_K,c->dlt==12?9:8,0,6);
        if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}else bpf_emit(out,family_load,0,0,linkoff);
        bpf_emit(out,OP_JEQ_K,0,29,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
        bpf_emit(out,OP_JEQ_K,4,0,6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);bpf_emit(out,OP_JEQ_K,0,25,44);
        bpf_emit(out,OP_LDB_ABS,0,0,v6frag);bpf_emit(out,OP_JEQ_K,0,23,6);bpf_emit(out,OP_LDH_ABS,0,0,fragword);
        bpf_emit(out,OP_JSET_K,21,0,8191);bpf_emit(out,OP_LD_IMM,0,0,13);bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LD_MEM,0,0,0);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_X,0,0,0);
        bpf_emit(out,7,0,0,0);bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,ipbase);bpf_emit(out,OP_ST_MEM,0,0,1);
        bpf_emit(out,OP_LD_IMM,0,0,mask);bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LDX_MEM,0,0,2);
        bpf_emit(out,OP_LD_MEM,0,0,1);bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,2);
        bpf_emit(out,OP_LD_IMM,0,0,rhs);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);
        bpf_emit(out,OP_LD_MEM,0,0,2);bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
        bpf_emit(out,OP_JEQ_K,!strcmp(operator_text,"!=")?1:0,!strcmp(operator_text,"!=")?0:1,0);
        finish_test(out,c->snaplen);return 1;
    }
    guard = out->len;
    bpf_emit(out, OP_JEQ_K, 0, 0, c->dlt == 9 ? 33 :
             (c->dlt == 0 ? 0x02000000U : (c->dlt == 12 ? 64 : 2048)));
    bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
    protojump = out->len;
    bpf_emit(out, OP_JEQ_K, 0, 0, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, fragword);
    fragjump = out->len;
    bpf_emit(out, OP_JSET_K, 0, 0, 8191);
    bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
    bpf_emit(out, BPF_LD | BPF_B | BPF_IND, 0, 0, dataoff);
    if (!strcmp(operator_text, "!=") && rhs == 0) {
        testjump = out->len;
        bpf_emit(out, OP_JSET_K, 0, 0, mask);
    } else {
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        testjump = out->len;
        bpf_emit(out, OP_JEQ_K, 0, 0, rhs);
    }
    accept = out->len;
    finish_test(out, c->snaplen);
    reject = out->len - 1;
    out->insns[guard].jf = (uint8_t)(reject - guard - 1);
    out->insns[protojump].jf = (uint8_t)(reject - protojump - 1);
    out->insns[fragjump].jt = (uint8_t)(reject - fragjump - 1);
    if (!strcmp(operator_text, "!=") && rhs != 0) {
        out->insns[testjump].jt = (uint8_t)(reject - testjump - 1);
        out->insns[testjump].jf = (uint8_t)(accept - testjump - 1);
    } else {
        out->insns[testjump].jt = (uint8_t)(accept - testjump - 1);
        out->insns[testjump].jf = (uint8_t)(reject - testjump - 1);
    }
    return 1;
}

static int transport_slice_compile(const bpfc_case_t *c,bpf_prog_t *out);
static int transport_slice_standalone;

static int icmp_named_type(const char *name, uint32_t *value)
{
    struct type_name { const char *name; uint32_t value; };
    static const struct type_name names[] = {
        {"icmp-echoreply",0},{"icmp-unreach",3},{"icmp-sourcequench",4},{"icmp-redirect",5},
        {"icmp-echo",8},{"icmp-routeradvert",9},{"icmp-routersolicit",10},{"icmp-timxceed",11},
        {"icmp-paramprob",12},{"icmp-tstamp",13},{"icmp-tstampreply",14},{"icmp-ireq",15},
        {"icmp-ireqreply",16},{"icmp-maskreq",17},{"icmp-maskreply",18}
    };
    size_t index;

    for (index = 0; index < sizeof(names) / sizeof(names[0]); ++index) {
        if (!strcmp(name, names[index].name)) {
            *value = names[index].value;
            return 1;
        }
    }
    return 0;
}

static int icmp_type_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char operator_text[3], name[32], tail[8];
    uint32_t value, family, protooff, fragword, ipbase;
    uint16_t linkload;
    uint32_t linkoff;
    int not_equal;
    if (sscanf(c->filter, "icmp[icmptype] %2s %31s %7s", operator_text, name, tail) != 2) return 0;
    if (!icmp_named_type(name, &value)) return 0;
    not_equal = !strcmp(operator_text, "!=");
    if (!not_equal && strcmp(operator_text, "=") && strcmp(operator_text, "==")) return 0;
    if(c->dlt==105&&!not_equal){
        bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,2);
        bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
        bpf_emit(out,96,0,0,2);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,2);bpf_emit(out,48,0,0,0);
        bpf_emit(out,69,38,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,36,8);bpf_emit(out,97,0,0,2);
        bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,33,2048);bpf_emit(out,48,0,0,0);bpf_emit(out,69,31,0,4);
        bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,29,8);bpf_emit(out,97,0,0,2);bpf_emit(out,72,0,0,6);
        bpf_emit(out,21,0,26,2048);bpf_emit(out,97,0,0,2);bpf_emit(out,80,0,0,17);bpf_emit(out,21,0,23,1);
        bpf_emit(out,97,0,0,2);bpf_emit(out,72,0,0,14);bpf_emit(out,69,20,0,8191);
        bpf_emit(out,0,0,0,0);bpf_emit(out,2,0,0,0);bpf_emit(out,97,0,0,2);bpf_emit(out,80,0,0,8);
        bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);
        bpf_emit(out,96,0,0,0);bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,80,0,0,8);
        bpf_emit(out,2,0,0,1);bpf_emit(out,0,0,0,value);bpf_emit(out,2,0,0,3);bpf_emit(out,97,0,0,3);
        bpf_emit(out,96,0,0,1);bpf_emit(out,28,0,0,0);bpf_emit(out,21,0,1,0);
        finish_test(out,c->snaplen);return 1;
    }
    if(!c->optimize){
        bpfc_case_t numeric_case=*c;char numeric_filter[64];
        snprintf(numeric_filter,sizeof(numeric_filter),"icmp[0] %s %u",operator_text,value);
        numeric_case.filter=numeric_filter;
        return transport_slice_compile(&numeric_case,out);
    }
    if (c->dlt == 1) { linkload=OP_LDH_ABS; linkoff=12; family=2048; protooff=23; fragword=20; ipbase=14; }
    else if (c->dlt == 113) { linkload=OP_LDH_ABS; linkoff=14; family=2048; protooff=25; fragword=22; ipbase=16; }
    else if (c->dlt == 9) { linkload=OP_LDH_ABS; linkoff=2; family=33; protooff=13; fragword=10; ipbase=4; }
    else if (c->dlt == 0) { linkload=OP_LDW_ABS; linkoff=0; family=0x02000000U; protooff=13; fragword=10; ipbase=4; }
    else if (c->dlt == 12) {
        bpf_emit(out, OP_LDB_ABS,0,0,0); bpf_emit(out,OP_AND_K,0,0,0xf0);
        linkload=0; linkoff=0; family=64; protooff=9; fragword=6; ipbase=0;
    } else return 0;
    if (linkload) bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,8,family);
    bpf_emit(out,OP_LDB_ABS,0,0,protooff);
    bpf_emit(out,OP_JEQ_K,0,6,1);
    bpf_emit(out,OP_LDH_ABS,0,0,fragword);
    bpf_emit(out,OP_JSET_K,4,0,8191);
    bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
    bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,ipbase);
    bpf_emit(out,OP_JEQ_K,not_equal ? 1 : 0,not_equal ? 0 : 1,value);
    finish_test(out,c->snaplen);
    return 1;
}

static int ip_slice_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned offset, width = 1;
    long parsed_value;
    uint32_t value;
    char operator_text[3], tail[8];
    int matched;
    uint32_t base, family, linkoff;
    uint16_t loadop, linkload;
    matched=sscanf(c->filter,"ip[%u:%u] %2s %li %7s",&offset,&width,operator_text,&parsed_value,tail);
    if (matched != 4) {
        width=1;
        matched=sscanf(c->filter,"ip[%u] %2s %li %7s",&offset,operator_text,&parsed_value,tail);
        if (matched != 3) return 0;
    }
    value=(uint32_t)parsed_value;
    if (width==1) loadop=OP_LDB_ABS; else if (width==2) loadop=OP_LDH_ABS;
    else if (width==4) loadop=OP_LDW_ABS; else return 0;
    if (c->dlt==1) {linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(!c->optimize){
        size_t guard,reject;
        uint16_t indirect_load;
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);
        guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
        bpf_emit(out,OP_LD_IMM,0,0,offset); bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,OP_LDX_MEM,0,0,0);
        if(width==1)indirect_load=BPF_LD|BPF_B|BPF_IND;
        else if(width==2)indirect_load=OP_LDH_IND;
        else indirect_load=BPF_LD|BPF_W|BPF_IND;
        bpf_emit(out,indirect_load,0,0,base); bpf_emit(out,OP_ST_MEM,0,0,1);
        bpf_emit(out,OP_LD_IMM,0,0,value); bpf_emit(out,OP_ST_MEM,0,0,2);
        bpf_emit(out,OP_LDX_MEM,0,0,2); bpf_emit(out,OP_LD_MEM,0,0,1);
        if(!strcmp(operator_text,"=")||!strcmp(operator_text,"==")||!strcmp(operator_text,"!=")){
            bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
            bpf_emit(out,OP_JEQ_K,!strcmp(operator_text,"!=")?1:0,!strcmp(operator_text,"!=")?0:1,0);
        }else if(!strcmp(operator_text,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,0,1,0);
        else if(!strcmp(operator_text,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,0,1,0);
        else if(!strcmp(operator_text,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,1,0,0);
        else if(!strcmp(operator_text,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,1,0,0);
        else{bpf_prog_reset(out);return 0;}
        finish_test(out,c->snaplen);reject=out->len-1;
        out->insns[guard].jf=(uint8_t)(reject-guard-1);
        return 1;
    }
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,3,family);
    bpf_emit(out,loadop,0,0,base+offset);
    if(!strcmp(operator_text,"=")||!strcmp(operator_text,"==")) bpf_emit(out,OP_JEQ_K,0,1,value);
    else if(!strcmp(operator_text,"!=")) bpf_emit(out,OP_JEQ_K,1,0,value);
    else if(!strcmp(operator_text,">")) bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,value);
    else if(!strcmp(operator_text,">=")) bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,value);
    else if(!strcmp(operator_text,"<")) bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,1,0,value);
    else if(!strcmp(operator_text,"<=")) bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,value);
    else {bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);
    return 1;
}

static int masked_ip_slice_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset,width=1;long parsed_mask,parsed_rhs;uint32_t mask,rhs,base,family,linkoff;char op[3],tail[8];int matched,direct;uint16_t load,linkload;
    matched=sscanf(c->filter,"ip[%u:%u] & %li %2s %li %7s",&offset,&width,&parsed_mask,op,&parsed_rhs,tail);
    if(matched!=5){width=1;matched=sscanf(c->filter,"ip[%u] & %li %2s %li %7s",&offset,&parsed_mask,op,&parsed_rhs,tail);if(matched!=4)return 0;}
    if(width==1)load=OP_LDB_ABS;else if(width==2)load=OP_LDH_ABS;else if(width==4)load=OP_LDW_ABS;else return 0;
    mask=(uint32_t)parsed_mask;rhs=(uint32_t)parsed_rhs;direct=rhs==0&&(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!="));
    if(!c->optimize){
        size_t guard,reject;uint16_t indirect_load,unoptimized_linkload=0;uint32_t unoptimized_linkoff=0,unoptimized_family,unoptimized_base;
        if(c->dlt==1){unoptimized_linkload=OP_LDH_ABS;unoptimized_linkoff=12;unoptimized_family=2048;unoptimized_base=14;}
        else if(c->dlt==113){unoptimized_linkload=OP_LDH_ABS;unoptimized_linkoff=14;unoptimized_family=2048;unoptimized_base=16;}
        else if(c->dlt==9){unoptimized_linkload=OP_LDH_ABS;unoptimized_linkoff=2;unoptimized_family=33;unoptimized_base=4;}
        else if(c->dlt==0){unoptimized_linkload=OP_LDW_ABS;unoptimized_linkoff=0;unoptimized_family=0x02000000U;unoptimized_base=4;}
        else if(c->dlt==12){unoptimized_family=64;unoptimized_base=0;}
        else return 0;
        indirect_load=width==1?(BPF_LD|BPF_B|BPF_IND):(width==2?OP_LDH_IND:(BPF_LD|BPF_W|BPF_IND));
        if(unoptimized_linkload)bpf_emit(out,unoptimized_linkload,0,0,unoptimized_linkoff);
        else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,unoptimized_family);
        bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,OP_LDX_MEM,0,0,0);
        bpf_emit(out,indirect_load,0,0,unoptimized_base);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,mask);
        bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,1);
        bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LD_IMM,0,0,rhs);
        bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,2);
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
        if(!strcmp(op,"!=")||!strcmp(op,"=")||!strcmp(op,"=="))bpf_emit(out,OP_JEQ_K,!strcmp(op,"!=")?1:0,!strcmp(op,"!=")?0:1,0);
        else return 0;
        finish_test(out,c->snaplen);reject=out->len-1;out->insns[guard].jf=(uint8_t)(reject-guard-1);return 1;
    }
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,direct?3:4,family);
    bpf_emit(out,load,0,0,base+offset);
    if(direct)bpf_emit(out,OP_JSET_K,(!strcmp(op,"!=")?0:1),(!strcmp(op,"!=")?1:0),mask);
    else{
        bpf_emit(out,OP_AND_K,0,0,mask);
        if(!strcmp(op,"=")||!strcmp(op,"=="))bpf_emit(out,OP_JEQ_K,0,1,rhs);else if(!strcmp(op,"!="))bpf_emit(out,OP_JEQ_K,1,0,rhs);
        else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,rhs);else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,rhs);
        else if(!strcmp(op,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,1,0,rhs);else if(!strcmp(op,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,rhs);else{bpf_prog_reset(out);return 0;}
    }
    finish_test(out,c->snaplen);return 1;
}

static int optimized_ip_nibble_shift_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned shift;long parsed;uint32_t value,linkoff,family,base;char op[3],tail[8];uint16_t linkload;
    if(!c->optimize||sscanf(c->filter,"(ip[0] & 0xf) << %u %2s %li %7s",&shift,op,&parsed,tail)!=3||shift>31)return 0;
    value=(uint32_t)parsed;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,5,family);bpf_emit(out,OP_LDB_ABS,0,0,base);bpf_emit(out,OP_AND_K,0,0,15);
    bpf_emit(out,BPF_ALU|BPF_LSH|BPF_K,0,0,shift);
    if(!strcmp(op,"=")||!strcmp(op,"=="))bpf_emit(out,OP_JEQ_K,0,1,value);
    else if(!strcmp(op,"!="))bpf_emit(out,OP_JEQ_K,1,0,value);
    else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,value);
    else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,value);
    else if(!strcmp(op,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,1,0,value);
    else if(!strcmp(op,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,value);
    else{bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);return 1;
}

static int protochain_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned protocol;char tail[8];int version6;uint32_t linkoff,family,base,protooff;uint16_t linkload;
    if(!starts(c->filter,"ip protochain ")&&!starts(c->filter,"ip6 protochain "))return 0;
    if(sscanf(c->filter,"ip protochain %u %7s",&protocol,tail)==1)version6=0;
    else if(sscanf(c->filter,"ip6 protochain %u %7s",&protocol,tail)==1)version6=1;
    else return 0;
    if(protocol>255)return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=version6?34525:2048;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=version6?87:33;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=version6?34525:2048;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=version6?0x0a000000U:0x02000000U;base=4;}
    else if(c->dlt==12){linkload=0;linkoff=0;family=version6?96:64;base=0;}
    else return 0;
    protooff=base+(version6?6:9);
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    if(!version6){
        bpf_emit(out,OP_JEQ_K,0,21,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);
        bpf_emit(out,BPF_LDX|BPF_B|BPF_MSH,0,0,base);bpf_emit(out,OP_JEQ_K,15,0,protocol);
        bpf_emit(out,OP_JEQ_K,14,0,59);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,0);
        bpf_emit(out,OP_JEQ_K,0,12,51);bpf_emit(out,135,0,0,0);
        bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,135,0,0,0);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,1);
        bpf_emit(out,7,0,0,0);bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);
        bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,2);bpf_emit(out,BPF_ALU|BPF_MUL|BPF_K,0,0,4);
        bpf_emit(out,7,0,0,0);bpf_emit(out,OP_LD_MEM,0,0,0);
        bpf_emit(out,BPF_JMP|BPF_JA,0,0,0xfffffff0U);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,0);
    }else{
        bpf_emit(out,OP_JEQ_K,0,33,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);
        bpf_emit(out,BPF_LDX|BPF_IMM,0,0,40);bpf_emit(out,OP_JEQ_K,27,0,protocol);
        bpf_emit(out,OP_JEQ_K,26,0,59);bpf_emit(out,OP_JEQ_K,3,0,0);
        bpf_emit(out,OP_JEQ_K,2,0,60);bpf_emit(out,OP_JEQ_K,1,0,43);
        bpf_emit(out,OP_JEQ_K,0,9,44);bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);
        bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base+1);
        bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,1);bpf_emit(out,BPF_ALU|BPF_MUL|BPF_K,0,0,8);
        bpf_emit(out,BPF_ALU|BPF_ADD|BPF_X,0,0,0);bpf_emit(out,7,0,0,0);
        bpf_emit(out,OP_LD_MEM,0,0,0);bpf_emit(out,BPF_JMP|BPF_JA,0,0,0xfffffff1U);
        bpf_emit(out,OP_JEQ_K,0,12,51);bpf_emit(out,135,0,0,0);
        bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,135,0,0,0);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,1);
        bpf_emit(out,7,0,0,0);bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);
        bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,2);bpf_emit(out,BPF_ALU|BPF_MUL|BPF_K,0,0,4);
        bpf_emit(out,7,0,0,0);bpf_emit(out,OP_LD_MEM,0,0,0);
        bpf_emit(out,BPF_JMP|BPF_JA,0,0,0xffffffe4U);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_K,0,0,0);
    }
    bpf_emit(out,OP_JEQ_K,0,1,protocol);finish_test(out,c->snaplen);return 1;
}

static int optimized_tcp_and_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned port;char tail[8];
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"tcp and port ")||
       sscanf(c->filter,"tcp and port %u %7s",&port,tail)!=1||port>65535)return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,9,2048);
    bpf_emit(out,OP_LDB_ABS,0,0,23);bpf_emit(out,OP_JEQ_K,0,15,6);
    bpf_emit(out,OP_LDH_ABS,0,0,20);bpf_emit(out,OP_JSET_K,13,0,8191);
    bpf_emit(out,BPF_LDX|BPF_B|BPF_MSH,0,0,14);bpf_emit(out,BPF_LD|BPF_H|BPF_IND,0,0,14);
    bpf_emit(out,OP_JEQ_K,9,0,port);bpf_emit(out,BPF_LD|BPF_H|BPF_IND,0,0,16);
    bpf_emit(out,OP_JEQ_K,7,8,port);bpf_emit(out,OP_JEQ_K,0,7,34525);
    bpf_emit(out,OP_LDB_ABS,0,0,20);bpf_emit(out,OP_JEQ_K,0,5,6);
    bpf_emit(out,OP_LDH_ABS,0,0,54);bpf_emit(out,OP_JEQ_K,2,0,port);
    bpf_emit(out,OP_LDH_ABS,0,0,56);bpf_emit(out,OP_JEQ_K,0,1,port);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_ip_tcp_udp_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned first,second;char tail[8];
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"(ip and udp and port ")||
       sscanf(c->filter,"(ip and udp and port %u) or (ip and tcp and port %u) %7s",&first,&second,tail)!=2||
       first!=second||first>65535)return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,11,2048);
    bpf_emit(out,OP_LDB_ABS,0,0,23);bpf_emit(out,OP_JEQ_K,1,0,17);
    bpf_emit(out,OP_JEQ_K,0,8,6);bpf_emit(out,OP_LDH_ABS,0,0,20);
    bpf_emit(out,OP_JSET_K,6,0,8191);bpf_emit(out,BPF_LDX|BPF_B|BPF_MSH,0,0,14);
    bpf_emit(out,BPF_LD|BPF_H|BPF_IND,0,0,14);bpf_emit(out,OP_JEQ_K,2,0,first);
    bpf_emit(out,BPF_LD|BPF_H|BPF_IND,0,0,16);bpf_emit(out,OP_JEQ_K,0,1,first);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_ether_pair_ip_transport_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first_text[32],second_text[32],tail[8];unsigned first_bytes[6],second_bytes[6],index;
    uint32_t first_low,second_low,first_high,second_high;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"((ether host ")||
       sscanf(c->filter,"((ether host %31[0-9a-fA-F:] or ether host %31[0-9a-fA-F:]) and (ip and (tcp or udp))) %7s",first_text,second_text,tail)!=2||
       sscanf(first_text,"%x:%x:%x:%x:%x:%x",&first_bytes[0],&first_bytes[1],&first_bytes[2],&first_bytes[3],&first_bytes[4],&first_bytes[5])!=6||
       sscanf(second_text,"%x:%x:%x:%x:%x:%x",&second_bytes[0],&second_bytes[1],&second_bytes[2],&second_bytes[3],&second_bytes[4],&second_bytes[5])!=6)return 0;
    for(index=0;index<6;++index)if(first_bytes[index]>255||second_bytes[index]>255)return 0;
    first_low=(first_bytes[2]<<24)|(first_bytes[3]<<16)|(first_bytes[4]<<8)|first_bytes[5];
    first_high=(first_bytes[0]<<8)|first_bytes[1];
    second_low=(second_bytes[2]<<24)|(second_bytes[3]<<16)|(second_bytes[4]<<8)|second_bytes[5];
    second_high=(second_bytes[0]<<8)|second_bytes[1];
    bpf_emit(out,OP_LDW_ABS,0,0,8);bpf_emit(out,OP_JEQ_K,0,2,first_low);
    bpf_emit(out,OP_LDH_ABS,0,0,6);bpf_emit(out,OP_JEQ_K,12,0,first_high);
    bpf_emit(out,OP_LDW_ABS,0,0,2);bpf_emit(out,OP_JEQ_K,0,2,first_low);
    bpf_emit(out,OP_LDH_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,8,0,first_high);
    bpf_emit(out,OP_LDW_ABS,0,0,8);bpf_emit(out,OP_JEQ_K,0,2,second_low);
    bpf_emit(out,OP_LDH_ABS,0,0,6);bpf_emit(out,OP_JEQ_K,4,0,second_high);
    bpf_emit(out,OP_LDW_ABS,0,0,2);bpf_emit(out,OP_JEQ_K,0,8,second_low);
    bpf_emit(out,OP_LDH_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,6,second_high);
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,4,2048);
    bpf_emit(out,OP_LDB_ABS,0,0,23);bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,1,17);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_icmp_pair_not_host_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char address[32],tail[8],extra;unsigned bytes[4];uint32_t host;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"(icmp or icmp6) and not host ")||
       sscanf(c->filter,"(icmp or icmp6) and not host %31s %7s",address,tail)!=1||
       sscanf(address,"%u.%u.%u.%u%c",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&extra)!=4||
       bytes[0]>255||bytes[1]>255||bytes[2]>255||bytes[3]>255)return 0;
    host=(bytes[0]<<24)|(bytes[1]<<16)|(bytes[2]<<8)|bytes[3];
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,6,2048);
    bpf_emit(out,OP_LDB_ABS,0,0,23);bpf_emit(out,OP_JEQ_K,0,11,1);
    bpf_emit(out,OP_LDW_ABS,0,0,26);bpf_emit(out,OP_JEQ_K,9,0,host);
    bpf_emit(out,OP_LDW_ABS,0,0,30);bpf_emit(out,OP_JEQ_K,7,6,host);
    bpf_emit(out,OP_JEQ_K,0,6,34525);bpf_emit(out,OP_LDB_ABS,0,0,20);
    bpf_emit(out,OP_JEQ_K,3,0,58);bpf_emit(out,OP_JEQ_K,0,3,44);
    bpf_emit(out,OP_LDB_ABS,0,0,54);bpf_emit(out,OP_JEQ_K,0,1,58);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_tcp_direction_range_union_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned first_low,first_high,second_low,second_high;char tail[8];
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"tcp and ((dst portrange ")||
       sscanf(c->filter,"tcp and ((dst portrange %u-%u) or (src portrange %u-%u)) %7s",
              &first_low,&first_high,&second_low,&second_high,tail)!=4||
       first_low!=second_low||first_high!=second_high||first_low>first_high||first_high>65535)return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,10,2048);
    bpf_emit(out,OP_LDB_ABS,0,0,23);bpf_emit(out,OP_JEQ_K,0,18,6);
    bpf_emit(out,OP_LDH_ABS,0,0,20);bpf_emit(out,OP_JSET_K,16,0,8191);
    bpf_emit(out,BPF_LDX|BPF_B|BPF_MSH,0,0,14);bpf_emit(out,BPF_LD|BPF_H|BPF_IND,0,0,16);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,first_low);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,11,first_high);
    bpf_emit(out,BPF_LD|BPF_H|BPF_IND,0,0,14);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,8,10,first_low);
    bpf_emit(out,OP_JEQ_K,0,9,34525);bpf_emit(out,OP_LDB_ABS,0,0,20);
    bpf_emit(out,OP_JEQ_K,0,7,6);bpf_emit(out,OP_LDH_ABS,0,0,56);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,first_low);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,3,first_high);
    bpf_emit(out,OP_LDH_ABS,0,0,54);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,first_low);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,first_high);finish_test(out,c->snaplen);return 1;
}

static int optimized_repeated_host_or_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first_text[32],repeat_text[32],second_text[32],tail[8],extra;unsigned first[4],repeat[4],second[4],index;
    uint32_t first_host,repeat_host,second_host;
    if(!c->optimize||(c->dlt!=0&&c->dlt!=1)||!starts(c->filter,"host ")||
       sscanf(c->filter,"host %31s or host %31s or host %31s %7s",first_text,repeat_text,second_text,tail)!=3||
       sscanf(first_text,"%u.%u.%u.%u%c",&first[0],&first[1],&first[2],&first[3],&extra)!=4||
       sscanf(repeat_text,"%u.%u.%u.%u%c",&repeat[0],&repeat[1],&repeat[2],&repeat[3],&extra)!=4||
       sscanf(second_text,"%u.%u.%u.%u%c",&second[0],&second[1],&second[2],&second[3],&extra)!=4)return 0;
    for(index=0;index<4;++index)if(first[index]>255||repeat[index]>255||second[index]>255)return 0;
    first_host=(first[0]<<24)|(first[1]<<16)|(first[2]<<8)|first[3];
    repeat_host=(repeat[0]<<24)|(repeat[1]<<16)|(repeat[2]<<8)|repeat[3];
    second_host=(second[0]<<24)|(second[1]<<16)|(second[2]<<8)|second[3];
    if(c->dlt==1&&first_host!=repeat_host&&first_host!=second_host&&repeat_host!=second_host){
        bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,6,2048);
        bpf_emit(out,OP_LDW_ABS,0,0,26);bpf_emit(out,OP_JEQ_K,14,0,first_host);
        bpf_emit(out,OP_JEQ_K,13,0,repeat_host);bpf_emit(out,OP_JEQ_K,12,0,second_host);
        bpf_emit(out,OP_LDW_ABS,0,0,30);bpf_emit(out,OP_JEQ_K,10,8,first_host);
        bpf_emit(out,OP_JEQ_K,1,0,2054);bpf_emit(out,OP_JEQ_K,0,9,32821);
        bpf_emit(out,OP_LDW_ABS,0,0,28);bpf_emit(out,OP_JEQ_K,6,0,first_host);
        bpf_emit(out,OP_JEQ_K,5,0,repeat_host);bpf_emit(out,OP_JEQ_K,4,0,second_host);
        bpf_emit(out,OP_LDW_ABS,0,0,38);bpf_emit(out,OP_JEQ_K,2,0,first_host);
        bpf_emit(out,OP_JEQ_K,1,0,repeat_host);bpf_emit(out,OP_JEQ_K,0,1,second_host);
        finish_test(out,c->snaplen);return 1;
    }
    if(first_host!=repeat_host)return 0;
    if(c->dlt==0){
        bpf_emit(out,OP_LDW_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,7,0x02000000U);
        bpf_emit(out,OP_LDW_ABS,0,0,16);bpf_emit(out,OP_JEQ_K,4,0,first_host);
        bpf_emit(out,OP_JEQ_K,3,0,second_host);bpf_emit(out,OP_LDW_ABS,0,0,20);
        bpf_emit(out,OP_JEQ_K,1,0,first_host);bpf_emit(out,OP_JEQ_K,0,1,second_host);
    }else{
        bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,5,2048);
        bpf_emit(out,OP_LDW_ABS,0,0,26);bpf_emit(out,OP_JEQ_K,11,0,first_host);
        bpf_emit(out,OP_JEQ_K,10,0,second_host);bpf_emit(out,OP_LDW_ABS,0,0,30);
        bpf_emit(out,OP_JEQ_K,8,7,first_host);bpf_emit(out,OP_JEQ_K,1,0,2054);
        bpf_emit(out,OP_JEQ_K,0,7,32821);bpf_emit(out,OP_LDW_ABS,0,0,28);
        bpf_emit(out,OP_JEQ_K,4,0,first_host);bpf_emit(out,OP_JEQ_K,3,0,second_host);
        bpf_emit(out,OP_LDW_ABS,0,0,38);bpf_emit(out,OP_JEQ_K,1,0,first_host);
        bpf_emit(out,OP_JEQ_K,0,1,second_host);
    }
    finish_test(out,c->snaplen);return 1;
}

static int optimized_identical_tcp_host_or_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first_text[32],second_text[32],tail[8],extra;unsigned first[4],second[4],index;uint32_t host,repeat;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"(tcp or host ")||
       sscanf(c->filter,"(tcp or host %31[0-9.]) and (tcp or host %31[0-9.]) %7s",first_text,second_text,tail)!=2||
       sscanf(first_text,"%u.%u.%u.%u%c",&first[0],&first[1],&first[2],&first[3],&extra)!=4||
       sscanf(second_text,"%u.%u.%u.%u%c",&second[0],&second[1],&second[2],&second[3],&extra)!=4)return 0;
    for(index=0;index<4;++index)if(first[index]>255||second[index]>255)return 0;
    host=(first[0]<<24)|(first[1]<<16)|(first[2]<<8)|first[3];
    repeat=(second[0]<<24)|(second[1]<<16)|(second[2]<<8)|second[3];
    if(host!=repeat)return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,6,2048);
    bpf_emit(out,OP_LDB_ABS,0,0,23);bpf_emit(out,OP_JEQ_K,16,0,6);
    bpf_emit(out,OP_LDW_ABS,0,0,26);bpf_emit(out,OP_JEQ_K,14,0,host);
    bpf_emit(out,OP_LDW_ABS,0,0,30);bpf_emit(out,OP_JEQ_K,12,13,host);
    bpf_emit(out,OP_JEQ_K,0,5,34525);bpf_emit(out,OP_LDB_ABS,0,0,20);
    bpf_emit(out,OP_JEQ_K,9,0,6);bpf_emit(out,OP_JEQ_K,0,9,44);
    bpf_emit(out,OP_LDB_ABS,0,0,54);bpf_emit(out,OP_JEQ_K,6,7,6);
    bpf_emit(out,OP_JEQ_K,1,0,2054);bpf_emit(out,OP_JEQ_K,0,5,32821);
    bpf_emit(out,OP_LDW_ABS,0,0,28);bpf_emit(out,OP_JEQ_K,2,0,host);
    bpf_emit(out,OP_LDW_ABS,0,0,38);bpf_emit(out,OP_JEQ_K,0,1,host);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_redundant_tcp_host_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char address[32],tail[8],extra;unsigned bytes[4],index;uint32_t host,linkoff,family,protooff,source,destination;uint16_t linkload;
    if(!c->optimize||(c->dlt!=1&&c->dlt!=9)||!starts(c->filter,"tcp and host ")||
       sscanf(c->filter,"tcp and host %31[0-9.] and tcp %7s",address,tail)!=1||
       sscanf(address,"%u.%u.%u.%u%c",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&extra)!=4)return 0;
    for(index=0;index<4;++index)if(bytes[index]>255)return 0;
    host=(bytes[0]<<24)|(bytes[1]<<16)|(bytes[2]<<8)|bytes[3];
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;protooff=23;source=26;destination=30;}
    else{linkload=OP_LDH_ABS;linkoff=2;family=33;protooff=13;source=16;destination=20;}
    bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,7,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);
    bpf_emit(out,OP_JEQ_K,0,5,6);bpf_emit(out,OP_LDW_ABS,0,0,source);bpf_emit(out,OP_JEQ_K,2,0,host);
    bpf_emit(out,OP_LDW_ABS,0,0,destination);bpf_emit(out,OP_JEQ_K,0,1,host);finish_test(out,c->snaplen);return 1;
}

static int optimized_both_host_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char address[32],tail[8],extra;unsigned bytes[4],index;uint32_t host;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"src and dst host ")||
       sscanf(c->filter,"src and dst host %31s %7s",address,tail)!=1||
       sscanf(address,"%u.%u.%u.%u%c",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&extra)!=4)return 0;
    for(index=0;index<4;++index)if(bytes[index]>255)return 0;
    host=(bytes[0]<<24)|(bytes[1]<<16)|(bytes[2]<<8)|bytes[3];
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,4,2048);
    bpf_emit(out,OP_LDW_ABS,0,0,26);bpf_emit(out,OP_JEQ_K,0,9,host);
    bpf_emit(out,OP_LDW_ABS,0,0,30);bpf_emit(out,OP_JEQ_K,6,7,host);
    bpf_emit(out,OP_JEQ_K,1,0,2054);bpf_emit(out,OP_JEQ_K,0,5,32821);
    bpf_emit(out,OP_LDW_ABS,0,0,28);bpf_emit(out,OP_JEQ_K,0,3,host);
    bpf_emit(out,OP_LDW_ABS,0,0,38);bpf_emit(out,OP_JEQ_K,0,1,host);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_ip_source_destination_host_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char source_text[32],destination_text[32],tail[8],extra;unsigned source[4],destination[4],index;
    uint32_t source_host,destination_host;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"ip src host ")||
       sscanf(c->filter,"ip src host %31s and ip dst host %31s %7s",source_text,destination_text,tail)!=2||
       sscanf(source_text,"%u.%u.%u.%u%c",&source[0],&source[1],&source[2],&source[3],&extra)!=4||
       sscanf(destination_text,"%u.%u.%u.%u%c",&destination[0],&destination[1],&destination[2],&destination[3],&extra)!=4)return 0;
    for(index=0;index<4;++index)if(source[index]>255||destination[index]>255)return 0;
    source_host=(source[0]<<24)|(source[1]<<16)|(source[2]<<8)|source[3];
    destination_host=(destination[0]<<24)|(destination[1]<<16)|(destination[2]<<8)|destination[3];
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,5,2048);
    bpf_emit(out,OP_LDW_ABS,0,0,26);bpf_emit(out,OP_JEQ_K,0,3,source_host);
    bpf_emit(out,OP_LDW_ABS,0,0,30);bpf_emit(out,OP_JEQ_K,0,1,destination_host);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_localhost_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    static const bpf_insn_t body[]={
        {40,0,0,12},{21,0,16,34525},{32,0,0,22},{21,0,6,0},{32,0,0,26},{21,0,4,0},{32,0,0,30},{21,0,2,0},
        {32,0,0,34},{21,19,0,1},{32,0,0,38},{21,0,18,0},{32,0,0,42},{21,0,16,0},{32,0,0,46},{21,0,14,0},
        {32,0,0,50},{21,11,12,1},{21,0,4,2048},{32,0,0,26},{21,8,0,2130706433},{32,0,0,30},{21,6,7,2130706433},
        {21,1,0,2054},{21,0,5,32821},{32,0,0,28},{21,2,0,2130706433},{32,0,0,38},{21,0,1,2130706433}};
    size_t index;
    if(!c->optimize||c->dlt!=1||strcmp(c->filter,"host localhost"))return 0;
    for(index=0;index<sizeof(body)/sizeof(body[0]);++index)
        bpf_emit(out,body[index].code,body[index].jt,body[index].jf,body[index].k);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_ip_payload_length_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    long parsed;uint32_t value,linkoff,family,base;char op[3],tail[8];uint16_t linkload;
    if(!c->optimize||c->dlt==105||sscanf(c->filter,"ip[2:2] - ((ip[0]&0xf)<<2) %2s %li %7s",op,&parsed,tail)!=2)return 0;
    value=(uint32_t)parsed;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,10,family);bpf_emit(out,OP_LDH_ABS,0,0,base+2);bpf_emit(out,OP_ST_MEM,0,0,1);
    bpf_emit(out,OP_LDB_ABS,0,0,base);bpf_emit(out,OP_AND_K,0,0,15);bpf_emit(out,BPF_ALU|BPF_LSH|BPF_K,0,0,2);
    bpf_emit(out,7,0,0,5);bpf_emit(out,OP_LD_MEM,0,0,1);bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
    if(!strcmp(op,"=")||!strcmp(op,"=="))bpf_emit(out,OP_JEQ_K,0,1,value);
    else if(!strcmp(op,"!="))bpf_emit(out,OP_JEQ_K,1,0,value);
    else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,value);
    else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,value);
    else if(!strcmp(op,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,1,0,value);
    else if(!strcmp(op,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,value);
    else{bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);return 1;
}

static int optimized_tcp_payload_length_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned port;
    int consumed = 0;
    static const bpf_insn_t prefix[] = {
        {40,0,0,12},{21,27,0,34525},{21,0,26,2048},{48,0,0,23},
        {21,0,24,6},{40,0,0,20},{69,22,0,8191},{177,0,0,14},
        {72,0,0,14}
    };
    static const bpf_insn_t suffix[] = {
        {40,0,0,16},{2,0,0,1},{48,0,0,14},{84,0,0,15},{100,0,0,2},
        {7,0,0,5},{96,0,0,1},{28,0,0,0},{2,0,0,5},{177,0,0,14},
        {80,0,0,26},{84,0,0,240},{116,0,0,2},{7,0,0,9},{96,0,0,5},
        {29,1,0,0}
    };
    size_t index;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "tcp port ") ||
        sscanf(c->filter,
               "tcp port %u and (((ip[2:2] - ((ip[0]&0xf)<<2)) - ((tcp[12]&0xf0)>>2)) != 0)%n",
               &port, &consumed) != 1 || c->filter[consumed] || port > 65535)
        return 0;
    for (index = 0; index < sizeof(prefix) / sizeof(prefix[0]); ++index)
        bpf_emit(out, prefix[index].code, prefix[index].jt, prefix[index].jf, prefix[index].k);
    bpf_emit(out, OP_JEQ_K, 2, 0, port);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 0, 17, port);
    for (index = 0; index < sizeof(suffix) / sizeof(suffix[0]); ++index)
        bpf_emit(out, suffix[index].code, suffix[index].jt, suffix[index].jf, suffix[index].k);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_ip_compact_arithmetic_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset=0,shift=0;long first,second;uint32_t linkoff,family,base,value;uint16_t linkload,loadop;char op[3],tail[8];int subtraction=0;
    if(!c->optimize)return 0;
    if(sscanf(c->filter,"ip[2:2] - %li %2s %li %7s",&first,op,&second,tail)==3){subtraction=1;loadop=OP_LDH_ABS;}
    else if(sscanf(c->filter,"ip[%u] & %li >> %u %2s %li %7s",&offset,&first,&shift,op,&second,tail)==5){loadop=OP_LDB_ABS;first>>=shift;}
    else if(sscanf(c->filter,"ip[%u]&%li>%li %7s",&offset,&first,&second,tail)==3){strcpy(op,">");loadop=OP_LDB_ABS;}
    else return 0;
    value=(uint32_t)second;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,4,family);bpf_emit(out,loadop,0,0,base+(subtraction?2:offset));
    bpf_emit(out,subtraction?(BPF_ALU|BPF_SUB|BPF_K):OP_AND_K,0,0,(uint32_t)first);
    if(!strcmp(op,"=")||!strcmp(op,"=="))bpf_emit(out,OP_JEQ_K,0,1,value);
    else if(!strcmp(op,"!="))bpf_emit(out,OP_JEQ_K,1,0,value);
    else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,value);
    else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,value);
    else if(!strcmp(op,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,1,0,value);
    else if(!strcmp(op,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,value);
    else{bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);return 1;
}

static int optimized_tcp_compact_arithmetic_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset,shift;long mask,value;char op[3],tail[8];uint32_t linkoff,family,protooff,fragment,base;uint16_t linkload;int masked=0;
    if(!c->optimize)return 0;
    if(sscanf(c->filter,"tcp[%u] >> %u %2s %li %7s",&offset,&shift,op,&value,tail)!=4){
        if(sscanf(c->filter,"tcp[%u] & %li >> %u %2s %li %7s",&offset,&mask,&shift,op,&value,tail)!=5)return 0;
        mask>>=shift;masked=1;
    }
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;protooff=23;fragment=20;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;protooff=13;fragment=10;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;protooff=25;fragment=22;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;protooff=13;fragment=10;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;protooff=9;fragment=6;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,9,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);bpf_emit(out,OP_JEQ_K,0,7,6);
    bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,5,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base+offset);bpf_emit(out,masked?OP_AND_K:(BPF_ALU|BPF_RSH|BPF_K),0,0,masked?(uint32_t)mask:shift);
    if(!strcmp(op,"=")||!strcmp(op,"=="))bpf_emit(out,OP_JEQ_K,0,1,(uint32_t)value);
    else if(!strcmp(op,"!="))bpf_emit(out,OP_JEQ_K,1,0,(uint32_t)value);
    else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,(uint32_t)value);
    else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,(uint32_t)value);
    else if(!strcmp(op,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,1,0,(uint32_t)value);
    else if(!strcmp(op,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,(uint32_t)value);
    else{bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);return 1;
}

static int optimized_tcp_flag_direct_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char name[16];uint32_t flag,linkoff,family,protooff,fragment,base;uint16_t linkload;int masked=0,consumed=0;
    if(!c->optimize)return 0;
    if(sscanf(c->filter,"tcp[tcpflags] & tcp-%15[a-z] = 0%n",name,&consumed)==1&&c->filter[consumed]==0)masked=1;
    else{consumed=0;if(sscanf(c->filter,"tcp[tcpflags] = tcp-%15[a-z]%n",name,&consumed)!=1||c->filter[consumed]!=0)return 0;}
    if(!strcmp(name,"fin"))flag=1;else if(!strcmp(name,"syn"))flag=2;else if(!strcmp(name,"rst"))flag=4;
    else if(!strcmp(name,"push"))flag=8;else if(!strcmp(name,"ack"))flag=16;else if(!strcmp(name,"urg"))flag=32;
    else if(!strcmp(name,"ece"))flag=64;else if(!strcmp(name,"cwr"))flag=128;else return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;protooff=23;fragment=20;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;protooff=13;fragment=10;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;protooff=25;fragment=22;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;protooff=13;fragment=10;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;protooff=9;fragment=6;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,8,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);bpf_emit(out,OP_JEQ_K,0,6,6);
    bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,4,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base+13);
    if(masked)bpf_emit(out,OP_JSET_K,1,0,flag);else bpf_emit(out,OP_JEQ_K,0,1,flag);
    finish_test(out,c->snaplen);return 1;
}

static int named_tcp_flag(const char *name, uint32_t *value)
{
    if (!strcmp(name, "fin")) *value = 1;
    else if (!strcmp(name, "syn")) *value = 2;
    else if (!strcmp(name, "rst")) *value = 4;
    else if (!strcmp(name, "push")) *value = 8;
    else if (!strcmp(name, "ack")) *value = 16;
    else if (!strcmp(name, "urg")) *value = 32;
    else if (!strcmp(name, "ece")) *value = 64;
    else if (!strcmp(name, "cwr")) *value = 128;
    else return 0;
    return 1;
}

static int unoptimized_named_tcp_flag_pair_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char first[16], second[16], result[16], operator_text[3];
    uint32_t first_value, second_value, result_value;
    int consumed = 0, index, named_result;
    named_result = sscanf(c->filter,
                          "tcp[tcpflags] & (tcp-%15[a-z]|tcp-%15[a-z]) %2s tcp-%15[a-z]%n",
                          first, second, operator_text, result, &consumed) == 4 &&
                   !c->filter[consumed];
    if (!named_result) {
        consumed = 0;
        if (sscanf(c->filter,
                   "tcp[tcpflags] & (tcp-%15[a-z]|tcp-%15[a-z]) %2s %15s%n",
                   first, second, operator_text, result, &consumed) != 4 ||
            c->filter[consumed] || strcmp(result, "0"))
            return 0;
    }
    if (c->optimize || c->dlt == 105 ||
        (strcmp(operator_text, "=") && strcmp(operator_text, "==") && strcmp(operator_text, "!=")) ||
        !named_tcp_flag(first, &first_value) || !named_tcp_flag(second, &second_value) ||
        (named_result ? !named_tcp_flag(result, &result_value) : (result_value = 0, 0)) ||
        !tcp_flag_compile(c, out) || out->len != 38)
        return 0;
    for (index = 0; index < 24; ++index) {
        bpf_insn_t *insn = &out->insns[index];
        if ((insn->code & 0x07) == BPF_JMP && (insn->code & 0xf0) != BPF_JA) {
            if ((size_t)index + 1 + insn->jt == 37) insn->jt += 6;
            if ((size_t)index + 1 + insn->jf == 37) insn->jf += 6;
        }
    }
    out->len = 24;
    bpf_emit(out, OP_LD_IMM, 0, 0, first_value); bpf_emit(out, OP_ST_MEM, 0, 0, 2);
    bpf_emit(out, OP_LD_IMM, 0, 0, second_value); bpf_emit(out, OP_ST_MEM, 0, 0, 3);
    bpf_emit(out, OP_LDX_MEM, 0, 0, 3); bpf_emit(out, OP_LD_MEM, 0, 0, 2);
    bpf_emit(out, OP_OR_X, 0, 0, 0); bpf_emit(out, OP_ST_MEM, 0, 0, 3);
    bpf_emit(out, OP_LDX_MEM, 0, 0, 3); bpf_emit(out, OP_LD_MEM, 0, 0, 1);
    bpf_emit(out, OP_AND_X, 0, 0, 0); bpf_emit(out, OP_ST_MEM, 0, 0, 3);
    bpf_emit(out, OP_LD_IMM, 0, 0, result_value); bpf_emit(out, OP_ST_MEM, 0, 0, 4);
    bpf_emit(out, OP_LDX_MEM, 0, 0, 4); bpf_emit(out, OP_LD_MEM, 0, 0, 3);
    bpf_emit(out, BPF_ALU | BPF_SUB | BPF_X, 0, 0, 0);
    bpf_emit(out, OP_JEQ_K, !strcmp(operator_text, "!=") ? 1 : 0,
             !strcmp(operator_text, "!=") ? 0 : 1, 0);
    finish_test(out, c->snaplen);
    return 1;
}

static int unoptimized_named_tcp_flag_direct_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char name[16], normalized[64];
    uint32_t value;
    int consumed = 0, index;
    bpfc_case_t reduced = *c;
    if (c->optimize || c->dlt == 105 ||
        sscanf(c->filter, "tcp[tcpflags] = tcp-%15[a-z]%n", name, &consumed) != 1 ||
        c->filter[consumed] || !named_tcp_flag(name, &value))
        return 0;
    snprintf(normalized, sizeof(normalized), "tcp[tcpflags] & 255 = %u", value);
    reduced.filter = normalized;
    if (!tcp_flag_compile(&reduced, out) || out->len != 38) return 0;
    for (index = 0; index < 24; ++index) {
        bpf_insn_t *insn = &out->insns[index];
        if ((insn->code & 0x07) == BPF_JMP && (insn->code & 0xf0) != BPF_JA) {
            if ((size_t)index + 1 + insn->jt == 37) insn->jt -= 6;
            if ((size_t)index + 1 + insn->jf == 37) insn->jf -= 6;
        }
    }
    out->len = 24;
    bpf_emit(out, OP_LD_IMM, 0, 0, value); bpf_emit(out, OP_ST_MEM, 0, 0, 2);
    bpf_emit(out, OP_LDX_MEM, 0, 0, 2); bpf_emit(out, OP_LD_MEM, 0, 0, 1);
    bpf_emit(out, BPF_ALU | BPF_SUB | BPF_X, 0, 0, 0); bpf_emit(out, OP_JEQ_K, 0, 1, 0);
    finish_test(out, c->snaplen); return 1;
}

static int optimized_named_tcp_flag_pair_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char first[16], second[16], result[16], normalized[64];
    uint32_t first_value, second_value, result_value;
    int consumed = 0;
    bpfc_case_t reduced = *c;

    if (!c->optimize || c->dlt != 1 ||
        !starts(c->filter, "tcp and (tcp[tcpflags] & (") ||
        sscanf(c->filter,
               "tcp and (tcp[tcpflags] & (tcp-%15[a-z]|tcp-%15[a-z]) = tcp-%15[a-z])%n",
               first, second, result, &consumed) != 3 || c->filter[consumed] ||
        !named_tcp_flag(first, &first_value) ||
        !named_tcp_flag(second, &second_value) ||
        !named_tcp_flag(result, &result_value))
        return 0;
    snprintf(normalized, sizeof(normalized), "tcp[13] & %u = %u",
             first_value | second_value, result_value);
    reduced.filter = normalized;
    return tcp_flag_compile(&reduced, out);
}

static int radiotap_ip_payload_length_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    static const uint32_t insns[][4]={
        {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,2},{80,0,0,0},{69,0,5,8},{69,4,0,4},{69,0,3,128},
        {96,0,0,2},{4,0,0,2},{2,0,0,2},{48,0,0,0},{69,43,0,4},{48,0,0,0},{69,0,41,8},{97,0,0,2},
        {72,0,0,6},{21,0,38,2048},{0,0,0,2},{2,0,0,0},{97,0,0,2},{96,0,0,0},{12,0,0,0},{7,0,0,0},
        {72,0,0,8},{2,0,0,1},{0,0,0,0},{2,0,0,3},{97,0,0,2},{96,0,0,3},{12,0,0,0},{7,0,0,0},
        {80,0,0,8},{2,0,0,4},{0,0,0,15},{2,0,0,5},{97,0,0,5},{96,0,0,4},{92,0,0,0},{2,0,0,5},
        {0,0,0,2},{2,0,0,6},{97,0,0,6},{96,0,0,5},{108,0,0,0},{2,0,0,6},{97,0,0,6},{96,0,0,1},
        {28,0,0,0},{2,0,0,6},{0,0,0,0},{2,0,0,7},{97,0,0,7},{96,0,0,6}
    };
    long parsed;char op[3],tail[8];size_t index;uint16_t compare;uint8_t jt,jf;
    if(c->dlt!=105||sscanf(c->filter,"ip[2:2] - ((ip[0]&0xf)<<2) %2s %li %7s",op,&parsed,tail)!=2)return 0;
    for(index=0;index<sizeof(insns)/sizeof(insns[0]);++index){
        uint32_t immediate=index==50?(uint32_t)parsed:insns[index][3];
        bpf_emit(out,(uint16_t)insns[index][0],(uint8_t)insns[index][1],(uint8_t)insns[index][2],immediate);
    }
    jt=0;jf=1;
    if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);compare=OP_JEQ_K;
        if(!strcmp(op,"!=")){jt=1;jf=0;}
    }
    else if(!strcmp(op,">"))compare=BPF_JMP|BPF_JGT|BPF_X;
    else if(!strcmp(op,">="))compare=BPF_JMP|BPF_JGE|BPF_X;
    else if(!strcmp(op,"<")){compare=BPF_JMP|BPF_JGE|BPF_X;jt=1;jf=0;}
    else if(!strcmp(op,"<=")){compare=BPF_JMP|BPF_JGT|BPF_X;jt=1;jf=0;}
    else{bpf_prog_reset(out);return 0;}
    bpf_emit(out,compare,jt,jf,0);finish_test(out,c->snaplen);
    out->insns[12].jt=(uint8_t)(out->len-1-12-1);out->insns[14].jf=(uint8_t)(out->len-1-14-1);
    out->insns[17].jf=(uint8_t)(out->len-1-17-1);return 1;
}

static int unoptimized_ip_payload_length_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    long parsed;char op[3],tail[8];uint32_t linkoff,family,base;uint16_t linkload,compare;uint8_t jt=0,jf=1;size_t family_test,reject;
    if(c->optimize||c->dlt==105||sscanf(c->filter,"ip[2:2] - ((ip[0]&0xf)<<2) %2s %li %7s",op,&parsed,tail)!=2)return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    family_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
    bpf_emit(out,OP_LD_IMM,0,0,2);bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,OP_LDX_MEM,0,0,0);
    bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,0);
    bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);
    bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LD_IMM,0,0,15);bpf_emit(out,OP_ST_MEM,0,0,4);
    bpf_emit(out,OP_LDX_MEM,0,0,4);bpf_emit(out,OP_LD_MEM,0,0,3);bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,4);
    bpf_emit(out,OP_LD_IMM,0,0,2);bpf_emit(out,OP_ST_MEM,0,0,5);bpf_emit(out,OP_LDX_MEM,0,0,5);bpf_emit(out,OP_LD_MEM,0,0,4);
    bpf_emit(out,BPF_ALU|BPF_LSH|BPF_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,5);bpf_emit(out,OP_LDX_MEM,0,0,5);
    bpf_emit(out,OP_LD_MEM,0,0,1);bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,5);
    bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)parsed);bpf_emit(out,OP_ST_MEM,0,0,6);bpf_emit(out,OP_LDX_MEM,0,0,6);bpf_emit(out,OP_LD_MEM,0,0,5);
    if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);compare=OP_JEQ_K;if(!strcmp(op,"!=")){jt=1;jf=0;}
    }else if(!strcmp(op,">"))compare=BPF_JMP|BPF_JGT|BPF_X;
    else if(!strcmp(op,">="))compare=BPF_JMP|BPF_JGE|BPF_X;
    else if(!strcmp(op,"<")){compare=BPF_JMP|BPF_JGE|BPF_X;jt=1;jf=0;}
    else if(!strcmp(op,"<=")){compare=BPF_JMP|BPF_JGT|BPF_X;jt=1;jf=0;}
    else{bpf_prog_reset(out);return 0;}
    bpf_emit(out,compare,jt,jf,0);finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[family_test].jf=(uint8_t)(reject-family_test-1);return 1;
}

static int unoptimized_ip_nibble_shift_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned shift;long parsed;char op[3],tail[8];uint32_t linkoff,family,base;uint16_t linkload,compare;uint8_t jt=0,jf=1;size_t family_test,reject;
    if(c->optimize||c->dlt==105||sscanf(c->filter,"(ip[0] & 0xf) << %u %2s %li %7s",&shift,op,&parsed,tail)!=3)return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    family_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
    bpf_emit(out,OP_LD_IMM,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,OP_LDX_MEM,0,0,0);
    bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,15);
    bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,1);
    bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LD_IMM,0,0,shift);
    bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,2);
    bpf_emit(out,BPF_ALU|BPF_LSH|BPF_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)parsed);
    bpf_emit(out,OP_ST_MEM,0,0,4);bpf_emit(out,OP_LDX_MEM,0,0,4);bpf_emit(out,OP_LD_MEM,0,0,3);
    if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);compare=OP_JEQ_K;if(!strcmp(op,"!=")){jt=1;jf=0;}
    }else if(!strcmp(op,">"))compare=BPF_JMP|BPF_JGT|BPF_X;
    else if(!strcmp(op,">="))compare=BPF_JMP|BPF_JGE|BPF_X;
    else if(!strcmp(op,"<")){compare=BPF_JMP|BPF_JGE|BPF_X;jt=1;jf=0;}
    else if(!strcmp(op,"<=")){compare=BPF_JMP|BPF_JGT|BPF_X;jt=1;jf=0;}
    else{bpf_prog_reset(out);return 0;}
    bpf_emit(out,compare,jt,jf,0);finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[family_test].jf=(uint8_t)(reject-family_test-1);return 1;
}

static int radiotap_unoptimized_ip_nibble_shift_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned shift;long parsed;char op[3],tail[8];uint16_t compare;uint8_t jt=0,jf=1;size_t reject;
    if(c->optimize||c->dlt!=105||sscanf(c->filter,"(ip[0] & 0xf) << %u %2s %li %7s",&shift,op,&parsed,tail)!=3)return 0;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,2);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,2);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,2);bpf_emit(out,48,0,0,0);
    bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,2);
    bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,0,2048);bpf_emit(out,OP_LD_IMM,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,0);
    bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,0);bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);
    bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,8);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,15);
    bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,1);
    bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LD_IMM,0,0,shift);
    bpf_emit(out,OP_ST_MEM,0,0,4);bpf_emit(out,OP_LDX_MEM,0,0,4);bpf_emit(out,OP_LD_MEM,0,0,3);
    bpf_emit(out,BPF_ALU|BPF_LSH|BPF_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,4);bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)parsed);
    bpf_emit(out,OP_ST_MEM,0,0,5);bpf_emit(out,OP_LDX_MEM,0,0,5);bpf_emit(out,OP_LD_MEM,0,0,4);
    if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);compare=OP_JEQ_K;if(!strcmp(op,"!=")){jt=1;jf=0;}
    }else if(!strcmp(op,">"))compare=BPF_JMP|BPF_JGT|BPF_X;
    else if(!strcmp(op,">="))compare=BPF_JMP|BPF_JGE|BPF_X;
    else if(!strcmp(op,"<")){compare=BPF_JMP|BPF_JGE|BPF_X;jt=1;jf=0;}
    else if(!strcmp(op,"<=")){compare=BPF_JMP|BPF_JGT|BPF_X;jt=1;jf=0;}
    else{bpf_prog_reset(out);return 0;}
    bpf_emit(out,compare,jt,jf,0);finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[12].jt=(uint8_t)(reject-12-1);out->insns[14].jf=(uint8_t)(reject-14-1);
    out->insns[17].jf=(uint8_t)(reject-17-1);return 1;
}

static int unoptimized_ip_simple_arithmetic_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset=0,shift=0;long first,second;char op[3],tail[8];uint32_t linkoff,family,base;uint16_t linkload,loadop,aluop,compare;uint8_t jt=0,jf=1;size_t family_test,reject;int shifted=0;
    if(c->optimize)return 0;
    if(sscanf(c->filter,"ip[2:2] - %li %2s %li %7s",&first,op,&second,tail)==3){offset=2;loadop=OP_LDH_IND;aluop=BPF_ALU|BPF_SUB|BPF_X;}
    else if(sscanf(c->filter,"ip[%u] & %li >> %u %2s %li %7s",&offset,&first,&shift,op,&second,tail)==5){loadop=BPF_LD|BPF_B|BPF_IND;aluop=OP_AND_X;shifted=1;}
    else if(sscanf(c->filter,"ip[%u] & %li %2s %li %7s",&offset,&first,op,&second,tail)==4){loadop=BPF_LD|BPF_B|BPF_IND;aluop=OP_AND_X;}
    else return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;base=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;base=0;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    family_test=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
    bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,OP_LDX_MEM,0,0,0);
    bpf_emit(out,loadop,0,0,base);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)first);bpf_emit(out,OP_ST_MEM,0,0,2);
    if(shifted){
        bpf_emit(out,OP_LD_IMM,0,0,shift);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);
        bpf_emit(out,OP_LD_MEM,0,0,2);bpf_emit(out,BPF_ALU|BPF_RSH|BPF_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);
        bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,1);bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);
        bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)second);bpf_emit(out,OP_ST_MEM,0,0,4);bpf_emit(out,OP_LDX_MEM,0,0,4);bpf_emit(out,OP_LD_MEM,0,0,3);
    }else{
        bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,1);bpf_emit(out,aluop,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,2);
        bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)second);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,2);
    }
    if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);compare=OP_JEQ_K;if(!strcmp(op,"!=")){jt=1;jf=0;}
    }else if(!strcmp(op,">"))compare=BPF_JMP|BPF_JGT|BPF_X;
    else if(!strcmp(op,">="))compare=BPF_JMP|BPF_JGE|BPF_X;
    else if(!strcmp(op,"<")){compare=BPF_JMP|BPF_JGE|BPF_X;jt=1;jf=0;}
    else if(!strcmp(op,"<=")){compare=BPF_JMP|BPF_JGT|BPF_X;jt=1;jf=0;}
    else{bpf_prog_reset(out);return 0;}
    bpf_emit(out,compare,jt,jf,0);finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[family_test].jf=(uint8_t)(reject-family_test-1);return 1;
}

static int unoptimized_tcp_shift_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset,shift;long mask=0,value;char op[3],tail[8];uint32_t linkoff,ip4,ip6,v4proto,v6proto,v6transport,fragment,base;
    uint16_t linkload,compare;uint8_t jt=0,jf=1;int masked=0;size_t initial_family,ipv4_family,ipv4_protocol,ipv6_start,ipv6_family,ipv6_protocol,extension,transport,fragment_test,reject;
    if(c->optimize)return 0;
    if(sscanf(c->filter,"tcp[%u] >> %u %2s %li %7s",&offset,&shift,op,&value,tail)!=4){
        if(sscanf(c->filter,"tcp[%u] & %li >> %u %2s %li %7s",&offset,&mask,&shift,op,&value,tail)!=5)return 0;
        masked=1;
    }
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip4=2048;ip6=34525;v4proto=23;v6proto=20;v6transport=54;fragment=20;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip4=33;ip6=87;v4proto=13;v6proto=10;v6transport=44;fragment=10;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip4=2048;ip6=34525;v4proto=25;v6proto=22;v6transport=56;fragment=22;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip4=0x02000000U;ip6=0x0a000000U;v4proto=13;v6proto=10;v6transport=44;fragment=10;base=4;}
    else return 0;
    bpf_emit(out,linkload,0,0,linkoff);initial_family=out->len;bpf_emit(out,OP_JEQ_K,0,0,ip4);
    bpf_emit(out,linkload,0,0,linkoff);ipv4_family=out->len;bpf_emit(out,OP_JEQ_K,0,0,ip4);
    bpf_emit(out,OP_LDB_ABS,0,0,v4proto);ipv4_protocol=out->len;bpf_emit(out,OP_JEQ_K,0,0,6);
    ipv6_start=out->len;bpf_emit(out,linkload,0,0,linkoff);ipv6_family=out->len;bpf_emit(out,OP_JEQ_K,0,0,ip6);
    bpf_emit(out,OP_LDB_ABS,0,0,v6proto);ipv6_protocol=out->len;bpf_emit(out,OP_JEQ_K,0,0,6);
    bpf_emit(out,OP_LDB_ABS,0,0,v6proto);extension=out->len;bpf_emit(out,OP_JEQ_K,0,0,44);
    bpf_emit(out,OP_LDB_ABS,0,0,v6transport);transport=out->len;bpf_emit(out,OP_JEQ_K,0,0,6);
    bpf_emit(out,OP_LDH_ABS,0,0,fragment);fragment_test=out->len;bpf_emit(out,OP_JSET_K,0,0,8191);
    bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,OP_LD_MEM,0,0,0);bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);
    bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,base);bpf_emit(out,OP_ST_MEM,0,0,1);
    if(masked){
        bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)mask);bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LD_IMM,0,0,shift);
        bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,2);
        bpf_emit(out,BPF_ALU|BPF_RSH|BPF_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);
        bpf_emit(out,OP_LD_MEM,0,0,1);bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);
        bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)value);bpf_emit(out,OP_ST_MEM,0,0,4);bpf_emit(out,OP_LDX_MEM,0,0,4);bpf_emit(out,OP_LD_MEM,0,0,3);
    }else{
        bpf_emit(out,OP_LD_IMM,0,0,shift);bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,1);
        bpf_emit(out,BPF_ALU|BPF_RSH|BPF_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LD_IMM,0,0,(uint32_t)value);
        bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,2);
    }
    if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);compare=OP_JEQ_K;if(!strcmp(op,"!=")){jt=1;jf=0;}
    }else if(!strcmp(op,">"))compare=BPF_JMP|BPF_JGT|BPF_X;
    else if(!strcmp(op,">="))compare=BPF_JMP|BPF_JGE|BPF_X;
    else if(!strcmp(op,"<")){compare=BPF_JMP|BPF_JGE|BPF_X;jt=1;jf=0;}
    else if(!strcmp(op,"<=")){compare=BPF_JMP|BPF_JGT|BPF_X;jt=1;jf=0;}
    else{bpf_prog_reset(out);return 0;}
    bpf_emit(out,compare,jt,jf,0);finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[initial_family].jf=(uint8_t)(reject-initial_family-1);out->insns[ipv4_family].jf=(uint8_t)(ipv6_start-ipv4_family-1);
    out->insns[ipv4_protocol].jt=(uint8_t)(fragment_test-1-ipv4_protocol-1);out->insns[ipv6_family].jf=(uint8_t)(reject-ipv6_family-1);
    out->insns[ipv6_protocol].jt=(uint8_t)(fragment_test-1-ipv6_protocol-1);out->insns[extension].jf=(uint8_t)(reject-extension-1);
    out->insns[transport].jf=(uint8_t)(reject-transport-1);out->insns[fragment_test].jt=(uint8_t)(reject-fragment_test-1);return 1;
}

static int radiotap_masked_ip_slice_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset,width=1;long parsed_mask,parsed_rhs;uint32_t mask,rhs;char op[3],tail[8];int matched;
    uint16_t load;size_t guard1,guard2,family_test,reject;
    if(c->dlt!=105)return 0;
    matched=sscanf(c->filter,"ip[%u:%u] & %li %2s %li %7s",&offset,&width,&parsed_mask,op,&parsed_rhs,tail);
    if(matched!=5){width=1;matched=sscanf(c->filter,"ip[%u] & %li %2s %li %7s",&offset,&parsed_mask,op,&parsed_rhs,tail);if(matched!=4)return 0;}
    if(strcmp(op,"=")&&strcmp(op,"==")&&strcmp(op,"!=")&&strcmp(op,">")&&strcmp(op,">=")&&strcmp(op,"<")&&strcmp(op,"<="))return 0;
    if(width==1)load=BPF_LD|BPF_B|BPF_IND;else if(width==2)load=OP_LDH_IND;else if(width==4)load=BPF_LD|BPF_W|BPF_IND;else return 0;
    mask=(uint32_t)parsed_mask;rhs=(uint32_t)parsed_rhs;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,2);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,2);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,2);
    bpf_emit(out,48,0,0,0);guard1=out->len;bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);
    guard2=out->len;bpf_emit(out,69,0,0,8);bpf_emit(out,97,0,0,2);bpf_emit(out,72,0,0,6);
    family_test=out->len;bpf_emit(out,21,0,0,2048);
    bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,OP_LDX_MEM,0,0,2);
    bpf_emit(out,OP_LD_MEM,0,0,0);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_X,0,0,0);bpf_emit(out,7,0,0,0);
    bpf_emit(out,load,0,0,8);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,mask);
    bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,1);
    bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LD_IMM,0,0,rhs);
    bpf_emit(out,OP_ST_MEM,0,0,4);bpf_emit(out,OP_LDX_MEM,0,0,4);bpf_emit(out,OP_LD_MEM,0,0,3);
    if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
        bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
        bpf_emit(out,OP_JEQ_K,!strcmp(op,"!=")?1:0,!strcmp(op,"!=")?0:1,0);
    }else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,0,1,0);
    else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,0,1,0);
    else if(!strcmp(op,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,1,0,0);
    else bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,1,0,0);
    finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[guard1].jt=(uint8_t)(reject-guard1-1);out->insns[guard2].jf=(uint8_t)(reject-guard2-1);
    out->insns[family_test].jf=(uint8_t)(reject-family_test-1);
    return 1;
}

static int transport_slice_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char transport[8],operator_text[3],tail[8]; unsigned offset,width=1; long parsed; uint32_t value,protocol;
    int matched; uint32_t family,ip6family,linkoff,protooff,v6proto,v6transport,fragword,ipbase; uint16_t linkload,loadop;
    matched=sscanf(c->filter,"%7[^[][%u:%u] %2s %li %7s",transport,&offset,&width,operator_text,&parsed,tail);
    if(matched!=5){width=1;matched=sscanf(c->filter,"%7[^[][%u] %2s %li %7s",transport,&offset,operator_text,&parsed,tail);if(matched!=4)return 0;}
    if(!strcmp(transport,"tcp"))protocol=6;else if(!strcmp(transport,"udp"))protocol=17;
    else if(!strcmp(transport,"icmp"))protocol=1;else return 0;
    if(width==1)loadop=BPF_LD|BPF_B|BPF_IND;else if(width==2)loadop=OP_LDH_IND;else if(width==4)loadop=BPF_LD|BPF_W|BPF_IND;else return 0;
    value=(uint32_t)parsed;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;ip6family=34525;protooff=23;v6proto=20;v6transport=54;fragword=20;ipbase=14;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;ip6family=34525;protooff=25;v6proto=22;v6transport=56;fragword=22;ipbase=16;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;ip6family=87;protooff=13;v6proto=10;v6transport=44;fragword=10;ipbase=4;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;ip6family=0x0a000000U;protooff=13;v6proto=10;v6transport=44;fragword=10;ipbase=4;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;ip6family=96;protooff=9;v6proto=6;v6transport=40;fragword=6;ipbase=0;}
    else return 0;
    if(!c->optimize){
        if(!transport_slice_standalone){
            size_t guards[4],reject;int guard_count=0;
            if(linkload)bpf_emit(out,linkload,0,0,linkoff);
            guards[guard_count++]=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
            if(linkload)bpf_emit(out,linkload,0,0,linkoff);
            else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
            guards[guard_count++]=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
            bpf_emit(out,OP_LDB_ABS,0,0,protooff);guards[guard_count++]=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocol);
            bpf_emit(out,OP_LDH_ABS,0,0,fragword);guards[guard_count++]=out->len;bpf_emit(out,OP_JSET_K,0,0,8191);
            bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,0);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
            bpf_emit(out,OP_LD_MEM,0,0,0);bpf_emit(out,BPF_ALU|BPF_ADD|BPF_X,0,0,0);bpf_emit(out,7,0,0,0);
            bpf_emit(out,loadop,0,0,ipbase);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,value);
            bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,1);
            if(!strcmp(operator_text,"=")||!strcmp(operator_text,"==")||!strcmp(operator_text,"!=")){
                bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
                bpf_emit(out,OP_JEQ_K,!strcmp(operator_text,"!=")?1:0,!strcmp(operator_text,"!=")?0:1,0);
            }else if(!strcmp(operator_text,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,0,1,0);
            else if(!strcmp(operator_text,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,0,1,0);
            else if(!strcmp(operator_text,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,1,0,0);
            else if(!strcmp(operator_text,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,1,0,0);
            else{bpf_prog_reset(out);return 0;}
            finish_test(out,c->snaplen);reject=out->len-1;
            out->insns[guards[0]].jf=(uint8_t)(reject-guards[0]-1);out->insns[guards[1]].jf=(uint8_t)(reject-guards[1]-1);
            out->insns[guards[2]].jf=(uint8_t)(reject-guards[2]-1);out->insns[guards[3]].jt=(uint8_t)(reject-guards[3]-1);
            return 1;
        }
        size_t guards[6],reject;int guard_count=0;size_t ipv4_family,ipv4_protocol,ipv6_protocol;
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);
        guards[guard_count++]=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);
        else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        ipv4_family=out->len;bpf_emit(out,OP_JEQ_K,0,0,family);
        bpf_emit(out,OP_LDB_ABS,0,0,protooff);
        ipv4_protocol=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocol);
        if(linkload)bpf_emit(out,linkload,0,0,linkoff);
        else{bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
        guards[guard_count++]=out->len;bpf_emit(out,OP_JEQ_K,0,0,ip6family);
        bpf_emit(out,OP_LDB_ABS,0,0,v6proto);ipv6_protocol=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocol);
        bpf_emit(out,OP_LDB_ABS,0,0,v6proto);guards[guard_count++]=out->len;bpf_emit(out,OP_JEQ_K,0,0,44);
        bpf_emit(out,OP_LDB_ABS,0,0,v6transport);guards[guard_count++]=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocol);
        bpf_emit(out,OP_LDH_ABS,0,0,fragword);
        guards[guard_count++]=out->len;bpf_emit(out,OP_JSET_K,0,0,8191);
        bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,OP_LDX_MSH,0,0,ipbase);bpf_emit(out,OP_LD_MEM,0,0,0);
        bpf_emit(out,BPF_ALU|BPF_ADD|BPF_X,0,0,0);bpf_emit(out,7,0,0,0);
        bpf_emit(out,loadop,0,0,ipbase);bpf_emit(out,OP_ST_MEM,0,0,1);
        bpf_emit(out,OP_LD_IMM,0,0,value);bpf_emit(out,OP_ST_MEM,0,0,2);
        bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,1);
        if(!strcmp(operator_text,"=")||!strcmp(operator_text,"==")||!strcmp(operator_text,"!=")){
            bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
            bpf_emit(out,OP_JEQ_K,!strcmp(operator_text,"!=")?1:0,!strcmp(operator_text,"!=")?0:1,0);
        }else if(!strcmp(operator_text,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,0,1,0);
        else if(!strcmp(operator_text,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,0,1,0);
        else if(!strcmp(operator_text,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,1,0,0);
        else if(!strcmp(operator_text,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,1,0,0);
        else{bpf_prog_reset(out);return 0;}
        finish_test(out,c->snaplen);reject=out->len-1;
        out->insns[ipv4_family].jf=2;
        out->insns[ipv4_protocol].jt=(uint8_t)(guards[guard_count-1]-ipv4_protocol-2);
        out->insns[ipv6_protocol].jt=(uint8_t)(guards[guard_count-1]-ipv6_protocol-2);
        out->insns[guards[0]].jf=(uint8_t)(reject-guards[0]-1);
        out->insns[guards[1]].jf=(uint8_t)(reject-guards[1]-1);
        out->insns[guards[2]].jf=(uint8_t)(reject-guards[2]-1);
        out->insns[guards[3]].jf=(uint8_t)(reject-guards[3]-1);
        out->insns[guards[4]].jt=(uint8_t)(reject-guards[4]-1);
        return 1;
    }
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,8,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);bpf_emit(out,OP_JEQ_K,0,6,protocol);
    bpf_emit(out,OP_LDH_ABS,0,0,fragword);bpf_emit(out,OP_JSET_K,4,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,ipbase);
    bpf_emit(out,loadop,0,0,ipbase+offset);
    if(!strcmp(operator_text,"=")||!strcmp(operator_text,"=="))bpf_emit(out,OP_JEQ_K,0,1,value);
    else if(!strcmp(operator_text,"!="))bpf_emit(out,OP_JEQ_K,1,0,value);
    else if(!strcmp(operator_text,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,value);
    else if(!strcmp(operator_text,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,value);
    else if(!strcmp(operator_text,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,1,0,value);
    else if(!strcmp(operator_text,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,value);
    else{bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);return 1;
}

static int radiotap_transport_slice_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char transport[8],operator_text[3],tail[8];unsigned offset,width=1;long parsed;uint32_t protocol,value;
    int matched;uint16_t loadop;size_t reject;
    matched=sscanf(c->filter,"%7[^[][%u:%u] %2s %li %7s",transport,&offset,&width,operator_text,&parsed,tail);
    if(matched!=5){width=1;matched=sscanf(c->filter,"%7[^[][%u] %2s %li %7s",transport,&offset,operator_text,&parsed,tail);if(matched!=4)return 0;}
    if(c->dlt!=105)return 0;
    if(!strcmp(transport,"tcp"))protocol=6;else if(!strcmp(transport,"udp"))protocol=17;else return 0;
    if(width==1)loadop=BPF_LD|BPF_B|BPF_IND;else if(width==2)loadop=OP_LDH_IND;else if(width==4)loadop=BPF_LD|BPF_W|BPF_IND;else return 0;
    value=(uint32_t)parsed;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,2);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,2);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,2);
    bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,0,8);
    bpf_emit(out,97,0,0,2);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,0,2048);
    bpf_emit(out,48,0,0,0);bpf_emit(out,69,8,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,6,8);
    bpf_emit(out,97,0,0,2);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,3,2048);
    bpf_emit(out,97,0,0,2);bpf_emit(out,80,0,0,17);bpf_emit(out,21,16,0,protocol);
    bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,0,4);bpf_emit(out,48,0,0,0);bpf_emit(out,69,0,0,8);
    bpf_emit(out,97,0,0,2);bpf_emit(out,72,0,0,6);bpf_emit(out,21,0,0,34525);
    bpf_emit(out,97,0,0,2);bpf_emit(out,80,0,0,14);bpf_emit(out,21,6,0,protocol);
    bpf_emit(out,97,0,0,2);bpf_emit(out,80,0,0,14);bpf_emit(out,21,0,0,44);
    bpf_emit(out,97,0,0,2);bpf_emit(out,80,0,0,48);bpf_emit(out,21,0,0,protocol);
    bpf_emit(out,97,0,0,2);bpf_emit(out,72,0,0,14);bpf_emit(out,69,0,0,8191);
    bpf_emit(out,0,0,0,offset);bpf_emit(out,2,0,0,0);bpf_emit(out,97,0,0,2);bpf_emit(out,80,0,0,8);
    bpf_emit(out,84,0,0,15);bpf_emit(out,100,0,0,2);bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);
    bpf_emit(out,96,0,0,0);bpf_emit(out,12,0,0,0);bpf_emit(out,7,0,0,0);bpf_emit(out,loadop,0,0,8);
    bpf_emit(out,2,0,0,1);bpf_emit(out,0,0,0,value);bpf_emit(out,2,0,0,3);bpf_emit(out,97,0,0,3);bpf_emit(out,96,0,0,1);
    if(!strcmp(operator_text,"=")||!strcmp(operator_text,"==")||!strcmp(operator_text,"!=")){
        bpf_emit(out,28,0,0,0);bpf_emit(out,21,!strcmp(operator_text,"!=")?1:0,!strcmp(operator_text,"!=")?0:1,0);
    }else if(!strcmp(operator_text,">"))bpf_emit(out,45,0,1,0);
    else if(!strcmp(operator_text,">="))bpf_emit(out,61,0,1,0);
    else if(!strcmp(operator_text,"<"))bpf_emit(out,61,1,0,0);
    else if(!strcmp(operator_text,"<="))bpf_emit(out,45,1,0,0);
    else{bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[12].jt=(uint8_t)(reject-13);out->insns[14].jf=(uint8_t)(reject-15);out->insns[17].jf=(uint8_t)(reject-18);
    out->insns[29].jt=(uint8_t)(reject-30);out->insns[31].jf=(uint8_t)(reject-32);out->insns[34].jf=(uint8_t)(reject-35);
    out->insns[40].jf=(uint8_t)(reject-41);out->insns[43].jf=(uint8_t)(reject-44);out->insns[46].jt=(uint8_t)(reject-47);
    return 1;
}

static int ether_slice_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset,width=1;long parsed;uint32_t value;char op[3],tail[8];int matched;uint16_t load;
    matched=sscanf(c->filter,"ether[%u:%u] %2s %li %7s",&offset,&width,op,&parsed,tail);
    if(matched!=4)matched=sscanf(c->filter,"link[%u:%u] %2s %li %7s",&offset,&width,op,&parsed,tail);
    if(matched!=4){
        width=1;
        matched=sscanf(c->filter,"ether[%u] %2s %li %7s",&offset,op,&parsed,tail);
        if(matched!=3)matched=sscanf(c->filter,"link[%u] %2s %li %7s",&offset,op,&parsed,tail);
        if(matched!=3)return 0;
    }
    if(width==1)load=OP_LDB_ABS;else if(width==2)load=OP_LDH_ABS;else if(width==4)load=OP_LDW_ABS;else return 0;
    if(!c->optimize){
        int reverse=!strcmp(op,"!=")||!strcmp(op,"<")||!strcmp(op,"<=");
        value=(uint32_t)parsed;bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,OP_LDX_MEM,0,0,0);bpf_emit(out,(uint16_t)(BPF_LD|(width==1?BPF_B:width==2?BPF_H:BPF_W)|BPF_IND),0,0,0);
        bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LD_IMM,0,0,value);bpf_emit(out,OP_ST_MEM,0,0,2);
        bpf_emit(out,OP_LDX_MEM,0,0,2);bpf_emit(out,OP_LD_MEM,0,0,1);
        if(!strcmp(op,"=")||!strcmp(op,"==")||!strcmp(op,"!=")){
            bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);bpf_emit(out,OP_JEQ_K,0,1,0);
        }else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,0,1,0);
        else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,0,1,0);
        else if(!strcmp(op,"<"))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_X,0,1,0);
        else if(!strcmp(op,"<="))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_X,0,1,0);
        else{bpf_prog_reset(out);return 0;}
        if(reverse){bpf_emit(out,OP_RET_K,0,0,0);bpf_emit(out,OP_RET_K,0,0,(uint32_t)c->snaplen);}
        else finish_test(out,c->snaplen);
        return 1;
    }
    value=(uint32_t)parsed;bpf_emit(out,load,0,0,offset);
    if(!strcmp(op,"=")||!strcmp(op,"=="))bpf_emit(out,OP_JEQ_K,0,1,value);
    else if(!strcmp(op,"!="))bpf_emit(out,OP_JEQ_K,1,0,value);
    else if(!strcmp(op,">"))bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,value);
    else if(!strcmp(op,">="))bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,value);
    else if(!strcmp(op,"<")){
        bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,1,value);
        bpf_emit(out,OP_RET_K,0,0,0);
        bpf_emit(out,OP_RET_K,0,0,(uint32_t)c->snaplen);
        return 1;
    }
    else if(!strcmp(op,"<=")){
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,1,value);
        bpf_emit(out,OP_RET_K,0,0,0);
        bpf_emit(out,OP_RET_K,0,0,(uint32_t)c->snaplen);
        return 1;
    }
    else{bpf_prog_reset(out);return 0;}
    finish_test(out,c->snaplen);return 1;
}

static int masked_link_slice_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset;
    long parsed_mask, parsed_value;
    uint32_t mask;
    char space[8];
    if (sscanf(c->filter,"ether[%u] & %li != %li %7s",&offset,&parsed_mask,&parsed_value,space)!=3 &&
        sscanf(c->filter,"link[%u] & %li != %li %7s",&offset,&parsed_mask,&parsed_value,space)!=3)
        return 0;
    if (parsed_value != 0) return 0;
    mask=(uint32_t)parsed_mask;
    if(c->optimize){
        bpf_emit(out,OP_LDB_ABS,0,0,offset);
        bpf_emit(out,OP_JSET_K,0,1,mask);
        finish_test(out,c->snaplen);
    }else{
        bpf_emit(out,OP_LD_IMM,0,0,offset); bpf_emit(out,OP_ST_MEM,0,0,0);
        bpf_emit(out,OP_LDX_MEM,0,0,0); bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,0);
        bpf_emit(out,OP_ST_MEM,0,0,1); bpf_emit(out,OP_LD_IMM,0,0,mask);
        bpf_emit(out,OP_ST_MEM,0,0,2); bpf_emit(out,OP_LDX_MEM,0,0,2);
        bpf_emit(out,OP_LD_MEM,0,0,1); bpf_emit(out,OP_AND_X,0,0,0);
        bpf_emit(out,OP_ST_MEM,0,0,2); bpf_emit(out,OP_LD_IMM,0,0,0);
        bpf_emit(out,OP_ST_MEM,0,0,3); bpf_emit(out,OP_LDX_MEM,0,0,3);
        bpf_emit(out,OP_LD_MEM,0,0,2); bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
        bpf_emit(out,OP_JEQ_K,1,0,0);finish_test(out,c->snaplen);
    }
    return 1;
}

static int radiotap_masked_link_slice_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned offset;long parsed_mask,parsed_value;uint32_t mask;char tail[8];
    if(c->dlt!=105||
       (sscanf(c->filter,"ether[%u] & %li != %li %7s",&offset,&parsed_mask,&parsed_value,tail)!=3&&
        sscanf(c->filter,"link[%u] & %li != %li %7s",&offset,&parsed_mask,&parsed_value,tail)!=3))return 0;
    if(parsed_value!=0)return 0;
    mask=(uint32_t)parsed_mask;
    bpf_emit(out,1,0,0,0);bpf_emit(out,135,0,0,0);bpf_emit(out,4,0,0,24);bpf_emit(out,2,0,0,0);
    bpf_emit(out,80,0,0,0);bpf_emit(out,69,0,5,8);bpf_emit(out,69,4,0,4);bpf_emit(out,69,0,3,128);
    bpf_emit(out,96,0,0,0);bpf_emit(out,4,0,0,2);bpf_emit(out,2,0,0,0);
    bpf_emit(out,OP_LD_IMM,0,0,offset);bpf_emit(out,OP_ST_MEM,0,0,1);bpf_emit(out,OP_LDX_MEM,0,0,1);
    bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,2);bpf_emit(out,OP_LD_IMM,0,0,mask);
    bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LDX_MEM,0,0,3);bpf_emit(out,OP_LD_MEM,0,0,2);
    bpf_emit(out,OP_AND_X,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,3);bpf_emit(out,OP_LD_IMM,0,0,0);
    bpf_emit(out,OP_ST_MEM,0,0,4);bpf_emit(out,OP_LDX_MEM,0,0,4);bpf_emit(out,OP_LD_MEM,0,0,3);
    bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);bpf_emit(out,OP_JEQ_K,1,0,0);finish_test(out,c->snaplen);
    return 1;
}

static const char *collapsed_protocol(const bpfc_case_t *c, char word[16])
{
    const char *cursor = c->filter;
    int atoms = 0, negations = 0;
    if (!c->optimize) return NULL;
    word[0] = 0;
    while (*cursor) {
        char token[16];
        size_t length = 0;
        while (*cursor == ' ' || *cursor == '(' || *cursor == ')') ++cursor;
        if (!*cursor) break;
        if (!((*cursor >= 'a' && *cursor <= 'z') || (*cursor >= 'A' && *cursor <= 'Z'))) return NULL;
        while (((*cursor >= 'a' && *cursor <= 'z') || (*cursor >= 'A' && *cursor <= 'Z') ||
                (*cursor >= '0' && *cursor <= '9')) && length + 1 < sizeof(token))
            token[length++] = *cursor++;
        token[length] = 0;
        if (!strcmp(token, "and") || !strcmp(token, "or")) continue;
        if (!strcmp(token, "not")) { ++negations; continue; }
        if (strcmp(token, "ip") && strcmp(token, "ip6") && strcmp(token, "tcp") &&
            strcmp(token, "udp") && strcmp(token, "sctp") && strcmp(token, "arp") &&
            strcmp(token, "icmp") && strcmp(token, "icmp6") && strcmp(token, "igmp") &&
            strcmp(token, "pim") && strcmp(token, "esp") && strcmp(token, "ah")) return NULL;
        if (!atoms) strcpy(word, token);
        else if (strcmp(word, token)) return NULL;
        ++atoms;
    }
    if (atoms < 2 || (negations & 1)) return NULL;
    return word;
}

static const char *repeated_expression(const bpfc_case_t *c, char reduced[256])
{
    static const char *separators[] = {" and ", " or "};
    size_t separator_index;
    if (!c->optimize || strlen(c->filter) >= 256) return NULL;
    for (separator_index = 0; separator_index < 2; ++separator_index) {
        const char *separator = separators[separator_index];
        const char *first = strstr(c->filter, separator);
        const char *cursor;
        size_t atom_length;
        int count = 1;
        if (!first) continue;
        atom_length = (size_t)(first - c->filter);
        if (!atom_length || atom_length >= 256) continue;
        cursor = first;
        while (*cursor) {
            if (strncmp(cursor, separator, strlen(separator))) { count = 0; break; }
            cursor += strlen(separator);
            if (strncmp(cursor, c->filter, atom_length)) { count = 0; break; }
            cursor += atom_length;
            ++count;
        }
        if (count >= 2) {
            memcpy(reduced, c->filter, atom_length);
            reduced[atom_length] = 0;
            return reduced;
        }
    }
    return NULL;
}

static const char *absorbed_ethernet_tcp_flag(const bpfc_case_t *c,char reduced[256])
{
    const char *cursor,*separator;char predicate[128];size_t length;int saw_tcp=0,saw_predicate=0,atoms=0;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"tcp and tcp[")||strlen(c->filter)>=256)return NULL;
    cursor=c->filter;predicate[0]=0;
    for(;;){
        separator=strstr(cursor," and ");length=separator?(size_t)(separator-cursor):strlen(cursor);
        if(length==3&&!memcmp(cursor,"tcp",3))saw_tcp=1;
        else{
            if(length<5||length>=sizeof(predicate)||memcmp(cursor,"tcp[",4))return NULL;
            if(!saw_predicate){memcpy(predicate,cursor,length);predicate[length]=0;saw_predicate=1;}
            else if(strlen(predicate)!=length||memcmp(predicate,cursor,length))return NULL;
        }
        ++atoms;if(!separator)break;cursor=separator+5;
    }
    if(!saw_tcp||!saw_predicate||atoms<3)return NULL;
    strcpy(reduced,predicate);return reduced;
}

static int identical_ip_byte_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    static const char atom[]="ip[0] = ip[0]";const char *cursor=c->filter;size_t family_tests[10],compares[5];int count=0,index;
    if(c->dlt!=1)return 0;
    for(;;){
        if(strncmp(cursor,atom,sizeof(atom)-1))return 0;
        cursor+=sizeof(atom)-1;++count;
        if(!*cursor)break;
        if(count==5||strncmp(cursor," and ",5))return 0;
        cursor+=5;
    }
    if(c->optimize){
        bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,4,2048);
        bpf_emit(out,OP_LDB_ABS,0,0,14);bpf_emit(out,7,0,0,3);
        bpf_emit(out,BPF_JMP|BPF_JEQ|BPF_X,0,1,0);finish_test(out,c->snaplen);return 1;
    }
    for(index=0;index<count;++index){uint32_t slot=(uint32_t)(index*3);
        bpf_emit(out,OP_LDH_ABS,0,0,12);family_tests[index*2]=out->len;bpf_emit(out,OP_JEQ_K,0,0,2048);
        bpf_emit(out,OP_LDH_ABS,0,0,12);family_tests[index*2+1]=out->len;bpf_emit(out,OP_JEQ_K,0,0,2048);
        bpf_emit(out,OP_LD_IMM,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,slot);bpf_emit(out,OP_LDX_MEM,0,0,slot);
        bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,14);bpf_emit(out,OP_ST_MEM,0,0,slot+1);
        bpf_emit(out,OP_LD_IMM,0,0,0);bpf_emit(out,OP_ST_MEM,0,0,slot+2);bpf_emit(out,OP_LDX_MEM,0,0,slot+2);
        bpf_emit(out,BPF_LD|BPF_B|BPF_IND,0,0,14);bpf_emit(out,OP_ST_MEM,0,0,slot+3);
        bpf_emit(out,OP_LDX_MEM,0,0,slot+3);bpf_emit(out,OP_LD_MEM,0,0,slot+1);bpf_emit(out,BPF_ALU|BPF_SUB|BPF_X,0,0,0);
        compares[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,0);
    }
    finish_test(out,c->snaplen);
    for(index=0;index<count*2;++index)out->insns[family_tests[index]].jf=(uint8_t)(out->len-1-family_tests[index]-1);
    for(index=0;index<count;++index)out->insns[compares[index]].jf=(uint8_t)(out->len-1-compares[index]-1);
    return 1;
}

static int optimized_ipv4_protocol_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char text[256],*token,*save;uint32_t protocol=0;int saw_ip=0,saw_protocol=0;
    uint16_t linkload;uint32_t linkoff,family,protooff;
    if(!c->optimize||strlen(c->filter)>=sizeof(text)||strstr(c->filter," or ")||strstr(c->filter,"not "))return 0;
    strcpy(text,c->filter);
    for(token=text;*token;++token)if(*token=='('||*token==')')*token=' ';
    token=strtok_r(text," ",&save);
    while(token){
        uint32_t candidate=0;
        if(!strcmp(token,"and")){}
        else if(!strcmp(token,"ip"))saw_ip=1;
        else{
            if(!strcmp(token,"tcp"))candidate=6;else if(!strcmp(token,"udp"))candidate=17;
            else if(!strcmp(token,"sctp"))candidate=132;else if(!strcmp(token,"icmp"))candidate=1;
            else if(!strcmp(token,"igmp"))candidate=2;else if(!strcmp(token,"pim"))candidate=103;
            else if(!strcmp(token,"esp"))candidate=50;else if(!strcmp(token,"ah"))candidate=51;
            else if(!strcmp(token,"vrrp")||!strcmp(token,"carp"))candidate=112;else return 0;
            if(saw_protocol&&protocol!=candidate)return 0;
            protocol=candidate;saw_protocol=1;
        }
        token=strtok_r(NULL," ",&save);
    }
    if(!saw_ip||!saw_protocol)return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;protooff=23;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;protooff=13;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;protooff=25;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;protooff=13;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;protooff=9;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,3,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);
    bpf_emit(out,OP_JEQ_K,0,1,protocol);finish_test(out,c->snaplen);return 1;
}

static int optimized_mixed_protocol_or_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char first[16], second[16], trailing;
    uint32_t first_protocol, second_protocol, dual_protocol;
    uint32_t linkoff, ip4, ip6, v4off, v6off, fragoff;
    uint16_t linkload;
    int first_dual, second_dual;
    if (!c->optimize ||
        sscanf(c->filter, "%15s or %15s%c", first, second, &trailing) != 2)
        return 0;
    if (!protocol_number(first, &first_protocol)) {
        if (!strcmp(first,"igrp")) first_protocol=9;
        else if (!strcmp(first,"carp")) first_protocol=112;
        else return 0;
    }
    if (!protocol_number(second, &second_protocol)) {
        if (!strcmp(second,"igrp")) second_protocol=9;
        else if (!strcmp(second,"carp")) second_protocol=112;
        else return 0;
    }
    if (!strcmp(first, "icmp6") || !strcmp(second, "icmp6")) return 0;
    first_dual = !strcmp(first,"tcp") || !strcmp(first,"udp") || !strcmp(first,"sctp") ||
                 !strcmp(first,"pim") || !strcmp(first,"esp") || !strcmp(first,"ah");
    second_dual = !strcmp(second,"tcp") || !strcmp(second,"udp") || !strcmp(second,"sctp") ||
                  !strcmp(second,"pim") || !strcmp(second,"esp") || !strcmp(second,"ah");
    dual_protocol = first_dual ? first_protocol : second_protocol;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip4=2048;ip6=34525;v4off=23;v6off=20;fragoff=54;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip4=33;ip6=87;v4off=13;v6off=10;fragoff=44;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip4=2048;ip6=34525;v4off=25;v6off=22;fragoff=56;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip4=0x02000000U;ip6=0x0a000000U;v4off=13;v6off=10;fragoff=44;}
    else return 0;
    if (!first_dual && !second_dual) {
        if (first_protocol == second_protocol) return 0;
        bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,4,ip4);
        bpf_emit(out,OP_LDB_ABS,0,0,v4off);bpf_emit(out,OP_JEQ_K,1,0,first_protocol);
        bpf_emit(out,OP_JEQ_K,0,1,second_protocol);finish_test(out,c->snaplen);return 1;
    }
    if (first_dual && second_dual) {
        if (first_protocol == second_protocol) return 0;
        bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,2,ip4);
        bpf_emit(out,OP_LDB_ABS,0,0,v4off);bpf_emit(out,OP_JEQ_K,7,6,first_protocol);
        bpf_emit(out,OP_JEQ_K,0,7,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6off);
        bpf_emit(out,OP_JEQ_K,4,0,first_protocol);bpf_emit(out,OP_JEQ_K,0,2,44);
        bpf_emit(out,OP_LDB_ABS,0,0,fragoff);bpf_emit(out,OP_JEQ_K,1,0,first_protocol);
        bpf_emit(out,OP_JEQ_K,0,1,second_protocol);finish_test(out,c->snaplen);return 1;
    }
    bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,3,ip4);
    bpf_emit(out,OP_LDB_ABS,0,0,v4off);bpf_emit(out,OP_JEQ_K,7,0,first_protocol);
    bpf_emit(out,OP_JEQ_K,6,7,second_protocol);bpf_emit(out,OP_JEQ_K,0,6,ip6);
    bpf_emit(out,OP_LDB_ABS,0,0,v6off);bpf_emit(out,OP_JEQ_K,3,0,dual_protocol);
    bpf_emit(out,OP_JEQ_K,0,3,44);bpf_emit(out,OP_LDB_ABS,0,0,fragoff);
    bpf_emit(out,OP_JEQ_K,0,1,dual_protocol);finish_test(out,c->snaplen);return 1;
}

static int optimized_ethertype_or_not_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first[16],second[16],trailing;uint32_t first_type,second_type,offset;
    if(!c->optimize||!strstr(c->filter," or (not ")||
       sscanf(c->filter,"%15s or (not %15[^)])%c",first,second,&trailing)!=2||
       !named_ethertype(first,&first_type)||!named_ethertype(second,&second_type)||first_type==second_type)return 0;
    if(c->dlt==1)offset=12;else if(c->dlt==113)offset=14;else return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,offset);bpf_emit(out,OP_JEQ_K,2,0,first_type);bpf_emit(out,OP_JEQ_K,0,1,second_type);
    bpf_emit(out,OP_RET_K,0,0,0);bpf_emit(out,OP_RET_K,0,0,c->snaplen);return 1;
}

static int unoptimized_two_ethertypes_not_stp_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first[16],second[16],trailing;uint32_t first_type,second_type;
    if(c->optimize||c->dlt!=1||!starts(c->filter,"not ")||
       sscanf(c->filter,"not %15s and not %15s and not stp%c",first,second,&trailing)!=2||
       !named_ethertype(first,&first_type)||!named_ethertype(second,&second_type))return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,6,0,first_type);
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,4,0,second_type);
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,3,0,1500);
    bpf_emit(out,OP_LDB_ABS,0,0,14);bpf_emit(out,OP_JEQ_K,0,1,66);
    bpf_emit(out,OP_RET_K,0,0,0);bpf_emit(out,OP_RET_K,0,0,c->snaplen);return 1;
}

static int optimized_null_icmp6_or_dual_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first[16],second[16],trailing;const char *name;uint32_t protocol;
    if(!c->optimize||c->dlt!=0||(!starts(c->filter,"icmp6 or ")&&!strstr(c->filter," or icmp6"))||
       sscanf(c->filter,"%15s or %15s%c",first,second,&trailing)!=2)return 0;
    if(!strcmp(first,"icmp6"))name=second;else if(!strcmp(second,"icmp6"))name=first;else return 0;
    if(!protocol_number(name,&protocol)||protocol==58||
       (strcmp(name,"tcp")&&strcmp(name,"udp")&&strcmp(name,"sctp")&&strcmp(name,"pim")&&
        strcmp(name,"esp")&&strcmp(name,"ah")))return 0;
    bpf_emit(out,OP_LDW_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,6,0x0a000000U);bpf_emit(out,OP_LDB_ABS,0,0,10);
    bpf_emit(out,OP_JEQ_K,7,0,58);bpf_emit(out,OP_JEQ_K,0,2,44);bpf_emit(out,OP_LDB_ABS,0,0,44);
    bpf_emit(out,OP_JEQ_K,4,0,58);bpf_emit(out,OP_JEQ_K,3,4,protocol);bpf_emit(out,OP_JEQ_K,0,3,0x02000000U);
    bpf_emit(out,OP_LDB_ABS,0,0,13);bpf_emit(out,OP_JEQ_K,0,1,protocol);finish_test(out,c->snaplen);return 1;
}

static int optimized_null_protocol_or_ip6_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first[16],second[16],trailing;const char *name;uint32_t protocol;
    if(!c->optimize||c->dlt!=0||(!starts(c->filter,"ip6 or ")&&!strstr(c->filter," or ip6"))||
       sscanf(c->filter,"%15s or %15s%c",first,second,&trailing)!=2)return 0;
    if(!strcmp(first,"ip6"))name=second;else if(!strcmp(second,"ip6"))name=first;else return 0;
    if(!protocol_number(name,&protocol)){
        if(!strcmp(name,"igrp"))protocol=9;else if(!strcmp(name,"carp"))protocol=112;else return 0;
    }
    if(!strcmp(name,"icmp6"))return 0;
    bpf_emit(out,OP_LDW_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,2,0x02000000U);bpf_emit(out,OP_LDB_ABS,0,0,13);
    bpf_emit(out,OP_JEQ_K,1,2,protocol);bpf_emit(out,OP_JEQ_K,0,1,0x0a000000U);finish_test(out,c->snaplen);return 1;
}

static int optimized_sll_host_protocol_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],address[32],protocol_name[16],trailing,extra;unsigned bytes[4],index;uint32_t host,protocol,offset;
    if(!c->optimize||c->dlt!=113||(!starts(c->filter,"src host ")&&!starts(c->filter,"dst host "))||
       sscanf(c->filter,"%7s host %31[0-9.] and %15s%c",direction,address,protocol_name,&trailing)!=3||
       (strcmp(direction,"src")&&strcmp(direction,"dst"))||
       sscanf(address,"%u.%u.%u.%u%c",&bytes[0],&bytes[1],&bytes[2],&bytes[3],&extra)!=4)return 0;
    for(index=0;index<4;++index)if(bytes[index]>255)return 0;
    if(!protocol_number(protocol_name,&protocol)){
        if(!strcmp(protocol_name,"igrp"))protocol=9;else if(!strcmp(protocol_name,"carp"))protocol=112;else return 0;
    }
    if(!strcmp(protocol_name,"icmp6"))return 0;
    host=(bytes[0]<<24)|(bytes[1]<<16)|(bytes[2]<<8)|bytes[3];offset=!strcmp(direction,"src")?28:32;
    bpf_emit(out,OP_LDH_ABS,0,0,14);bpf_emit(out,OP_JEQ_K,0,5,2048);bpf_emit(out,OP_LDW_ABS,0,0,offset);
    bpf_emit(out,OP_JEQ_K,0,3,host);bpf_emit(out,OP_LDB_ABS,0,0,25);bpf_emit(out,OP_JEQ_K,0,1,protocol);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_ipv4_protocol_pair_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    uint16_t linkload;uint32_t linkoff,family,protooff;
    if(!c->optimize||!strstr(c->filter,"(tcp or udp)")||!strstr(c->filter,"ip")||!strstr(c->filter," and "))return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;family=2048;protooff=23;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;family=33;protooff=13;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;family=2048;protooff=25;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;family=0x02000000U;protooff=13;}
    else if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);linkload=0;linkoff=0;family=64;protooff=9;}
    else return 0;
    if(linkload)bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,4,family);bpf_emit(out,OP_LDB_ABS,0,0,protooff);
    bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,1,17);finish_test(out,c->snaplen);return 1;
}

static int optimized_ether_fragment_tcp_udp_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    if(!c->optimize||c->dlt!=1||!strstr(c->filter,"ip[6:2] & 0x1fff = 0")||!strstr(c->filter,"(tcp or udp)"))return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,6,2048);bpf_emit(out,OP_LDH_ABS,0,0,20);
    bpf_emit(out,OP_JSET_K,4,0,8191);bpf_emit(out,OP_LDB_ABS,0,0,23);bpf_emit(out,OP_JEQ_K,1,0,6);
    bpf_emit(out,OP_JEQ_K,0,1,17);finish_test(out,c->snaplen);return 1;
}

static int optimized_repeated_tcp_less_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char connective[4],trailing;unsigned first,second;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"(tcp and less ")||
       sscanf(c->filter,"(tcp and less %u) %3s (tcp and less %u)%c",&first,connective,&second,&trailing)!=3||
       (strcmp(connective,"or")&&strcmp(connective,"and"))||first!=second)return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,2,2048);bpf_emit(out,OP_LDB_ABS,0,0,23);
    bpf_emit(out,OP_JEQ_K,6,9,6);bpf_emit(out,OP_JEQ_K,0,8,34525);bpf_emit(out,OP_LDB_ABS,0,0,20);
    bpf_emit(out,OP_JEQ_K,3,0,6);bpf_emit(out,OP_JEQ_K,0,5,44);bpf_emit(out,OP_LDB_ABS,0,0,54);
    bpf_emit(out,OP_JEQ_K,0,3,6);bpf_emit(out,BPF_LD|BPF_W|BPF_LEN,0,0,0);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,first);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_repeated_ppp_protocol_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first_protocol[8],second_protocol[8],trailing;unsigned first_port,second_port;uint32_t protocol;
    if(!c->optimize||c->dlt!=9||!strstr(c->filter," and port ")||
       sscanf(c->filter,"%7s and port %u and %7s and port %u%c",first_protocol,&first_port,second_protocol,&second_port,&trailing)!=4||
       strcmp(first_protocol,second_protocol)||first_port!=second_port||first_port>65535)return 0;
    if(!strcmp(first_protocol,"tcp"))protocol=6;else if(!strcmp(first_protocol,"udp"))protocol=17;
    else if(!strcmp(first_protocol,"sctp"))protocol=132;else return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,2);bpf_emit(out,OP_JEQ_K,0,9,33);bpf_emit(out,OP_LDB_ABS,0,0,13);
    bpf_emit(out,OP_JEQ_K,0,15,protocol);bpf_emit(out,OP_LDH_ABS,0,0,10);bpf_emit(out,OP_JSET_K,13,0,8191);
    bpf_emit(out,OP_LDX_MSH,0,0,4);bpf_emit(out,OP_LDH_IND,0,0,4);bpf_emit(out,OP_JEQ_K,9,0,first_port);
    bpf_emit(out,OP_LDH_IND,0,0,6);bpf_emit(out,OP_JEQ_K,7,8,first_port);bpf_emit(out,OP_JEQ_K,0,7,87);
    bpf_emit(out,OP_LDB_ABS,0,0,10);bpf_emit(out,OP_JEQ_K,0,5,protocol);bpf_emit(out,OP_LDH_ABS,0,0,44);
    bpf_emit(out,OP_JEQ_K,2,0,first_port);bpf_emit(out,OP_LDH_ABS,0,0,46);bpf_emit(out,OP_JEQ_K,0,1,first_port);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_repeated_ether_ip_net_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first_text[64],second_text[64],connective[4],filter[72],direction[8],trailing;
    uint32_t first_network,first_mask,second_network,second_mask;int first_any,second_any;
    if(!c->optimize||c->dlt!=1||!starts(c->filter,"(ip and net ")||
       sscanf(c->filter,"(ip and net %63[^)]) %3s (ip and net %63[^)])%c",first_text,connective,second_text,&trailing)!=3||
       (strcmp(connective,"or")&&strcmp(connective,"and")))return 0;
    if(snprintf(filter,sizeof(filter),"net %s",first_text)>=(int)sizeof(filter)||
       !parse_ipv4_net(filter,direction,&first_network,&first_mask,&first_any)||
       snprintf(filter,sizeof(filter),"net %s",second_text)>=(int)sizeof(filter)||
       !parse_ipv4_net(filter,direction,&second_network,&second_mask,&second_any)||
       first_network!=second_network||first_mask!=second_mask)return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,12);bpf_emit(out,OP_JEQ_K,0,7,2048);bpf_emit(out,OP_LDW_ABS,0,0,26);
    bpf_emit(out,OP_AND_K,0,0,first_mask);bpf_emit(out,OP_JEQ_K,3,0,first_network);bpf_emit(out,OP_LDW_ABS,0,0,30);
    bpf_emit(out,OP_AND_K,0,0,first_mask);bpf_emit(out,OP_JEQ_K,0,1,first_network);finish_test(out,c->snaplen);return 1;
}

static int optimized_not_ipv4_protocol_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    bpfc_case_t inner=*c;char expression[256];size_t length;
    if(!c->optimize||!starts(c->filter,"not (")||(length=strlen(c->filter))<7||
       c->filter[length-1]!=')'||length-6>=sizeof(expression))return 0;
    memcpy(expression,c->filter+5,length-6);expression[length-6]=0;inner.filter=expression;
    if(!optimized_ipv4_protocol_compile(&inner,out))return 0;
    out->insns[out->len-2].k=0;out->insns[out->len-1].k=(uint32_t)c->snaplen;return 1;
}

static const char *resolved_service(const bpfc_case_t *c, char resolved[256])
{
    struct service { const char *name; unsigned port; };
    static const struct service services[] = {
        {"ftp",21},{"ssh",22},{"telnet",23},{"smtp",25},{"domain",53},{"bootps",67},
        {"bootpc",68},{"tftp",69},{"http",80},{"pop3",110},{"ntp",123},{"https",443},
        {"syslog",514}
    };
    const char *last_space;
    size_t index, prefix_length;
    if (strlen(c->filter) >= 240 || (!strstr(c->filter," port ") && !starts(c->filter,"port "))) return NULL;
    last_space=strrchr(c->filter,' ');
    if(!last_space) return NULL;
    for(index=0;index<sizeof(services)/sizeof(services[0]);++index)
        if(!strcmp(last_space+1,services[index].name)) break;
    if(index==sizeof(services)/sizeof(services[0])) return NULL;
    prefix_length=(size_t)(last_space-c->filter+1);
    memcpy(resolved,c->filter,prefix_length);
    snprintf(resolved+prefix_length,256-prefix_length,"%u",services[index].port);
    return resolved;
}

static const char *resolved_host_name(const bpfc_case_t *c, char resolved[256])
{
    const char *suffix;
    size_t prefix_length;
    if (!strcmp(c->filter, "ip6 host ip6-localhost")) {
        strcpy(resolved, "ip6 host ::1");
        return resolved;
    }
    suffix = strstr(c->filter, "host localhost");
    if (!suffix || suffix[14] != 0) return NULL;
    prefix_length = (size_t)(suffix - c->filter);
    if (prefix_length == 0) {
        strcpy(resolved, "(ip6 host ::1 or host 127.0.0.1)");
    } else if (prefix_length == 4 && !memcmp(c->filter, "src ", 4)) {
        strcpy(resolved, "(ip6 src host ::1 or src host 127.0.0.1)");
    } else if (prefix_length == 4 && !memcmp(c->filter, "dst ", 4)) {
        strcpy(resolved, "(ip6 dst host ::1 or dst host 127.0.0.1)");
    } else return NULL;
    return resolved;
}

static const char *normalized_port_direction(const bpfc_case_t *c, char normalized[256])
{
    const char *middle;
    size_t prefix_length;
    middle = strstr(c->filter, " src or dst port ");
    if (!middle) middle = strstr(c->filter, " src or dst portrange ");
    if (middle) {
        prefix_length = (size_t)(middle - c->filter);
        if (prefix_length + strlen(middle + 11) + 2 >= 256) return NULL;
        memcpy(normalized,c->filter,prefix_length);
        normalized[prefix_length]=0;
        strcat(normalized," ");
        strcat(normalized,middle+12);
        return normalized;
    }
    if (starts(c->filter,"src or dst port ") || starts(c->filter,"src or dst portrange ")) {
        strcpy(normalized,c->filter+11);
        return normalized;
    }
    middle = strstr(c->filter, " src and dst port ");
    if (!middle) middle = strstr(c->filter, " src and dst portrange ");
    if (middle) {
        const char *suffix = middle + 13;
        prefix_length = (size_t)(middle - c->filter);
        if (snprintf(normalized,256,"(%.*s src %s and %.*s dst %s)",
                     (int)prefix_length,c->filter,suffix,
                     (int)prefix_length,c->filter,suffix) >= 256) return NULL;
        return normalized;
    }
    if (starts(c->filter,"src and dst port ") || starts(c->filter,"src and dst portrange ")) {
        const char *suffix=c->filter+12;
        if(starts(c->filter,"src and dst port ")){
            strcpy(normalized,suffix);
            return normalized;
        }
        if (snprintf(normalized,256,"(src %s and dst %s)",suffix,suffix)>=256) return NULL;
        return normalized;
    }
    return NULL;
}

static int raw_both_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned port;char tail[8];uint32_t ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;
    if(!c->optimize||(c->dlt!=0&&c->dlt!=12)||sscanf(c->filter,"src and dst port %u %7s",&port,tail)!=1||port>65535)return 0;
    if(c->dlt==0){ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;bpf_emit(out,OP_LDW_ABS,0,0,0);}
    else{ip6=96;ip4=64;v6proto=6;v6src=40;v6dst=42;v4proto=9;fragment=6;base=0;bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    bpf_emit(out,OP_JEQ_K,0,8,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);bpf_emit(out,OP_JEQ_K,2,0,132);
    bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,17,17);bpf_emit(out,OP_LDH_ABS,0,0,v6src);
    bpf_emit(out,OP_JEQ_K,0,15,port);bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,OP_JEQ_K,12,13,port);
    bpf_emit(out,OP_JEQ_K,0,12,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,2,0,132);
    bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,8,17);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
    bpf_emit(out,OP_JSET_K,6,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);
    bpf_emit(out,OP_JEQ_K,0,3,port);bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,OP_JEQ_K,0,1,port);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_both_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],tail[8];unsigned port;uint32_t protocol,linkoff,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;
    if(!c->optimize||sscanf(c->filter,"%7s src and dst port %u %7s",protocol_name,&port,tail)!=2||port>65535)return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;
    else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    if(c->dlt==1){linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6src=54;v6dst=56;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){linkoff=2;ip6=87;ip4=33;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6src=56;v6dst=58;v4proto=25;fragment=22;base=16;}
    else return 0;
    bpf_emit(out,OP_LDH_ABS,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,6,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
    bpf_emit(out,OP_JEQ_K,0,15,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,OP_JEQ_K,0,13,port);
    bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,OP_JEQ_K,10,11,port);bpf_emit(out,OP_JEQ_K,0,10,ip4);
    bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,0,8,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
    bpf_emit(out,OP_JSET_K,6,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);
    bpf_emit(out,OP_JEQ_K,0,3,port);bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,OP_JEQ_K,0,1,port);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_two_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char first_protocol[8],second_protocol[8],tail[8];unsigned first_port,second_port;uint32_t protocol;
    uint16_t linkload;uint32_t linkoff,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;
    if(!c->optimize||sscanf(c->filter,"%7s port %u or %7s port %u %7s",first_protocol,&first_port,second_protocol,&second_port,tail)!=4||
       strcmp(first_protocol,second_protocol)||first_port>65535||second_port>65535)return 0;
    if(!strcmp(first_protocol,"tcp"))protocol=6;else if(!strcmp(first_protocol,"udp"))protocol=17;
    else if(!strcmp(first_protocol,"sctp"))protocol=132;else return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6src=54;v6dst=56;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip6=87;ip4=33;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6src=56;v6dst=58;v4proto=25;fragment=22;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else return 0;
    bpf_emit(out,linkload,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,7,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
    bpf_emit(out,OP_JEQ_K,0,18,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,OP_JEQ_K,15,0,first_port);
    bpf_emit(out,OP_JEQ_K,14,0,second_port);bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,OP_JEQ_K,12,11,first_port);
    bpf_emit(out,OP_JEQ_K,0,12,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,0,10,protocol);
    bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,8,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,OP_JEQ_K,4,0,first_port);bpf_emit(out,OP_JEQ_K,3,0,second_port);
    bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,OP_JEQ_K,1,0,first_port);bpf_emit(out,OP_JEQ_K,0,1,second_port);
    finish_test(out,c->snaplen);return 1;
}

static int optimized_not_two_port_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned first, second;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "not (port ") ||
        sscanf(c->filter, "not (port %u or port %u)%c", &first, &second, &trailing) != 2 ||
        first > 65535 || second > 65535)
        return 0;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 9, 34525);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
    bpf_emit(out, OP_JEQ_K, 2, 0, 132);
    bpf_emit(out, OP_JEQ_K, 1, 0, 6);
    bpf_emit(out, OP_JEQ_K, 0, 20, 17);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 54);
    bpf_emit(out, OP_JEQ_K, 17, 0, first);
    bpf_emit(out, OP_JEQ_K, 16, 0, second);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 56);
    bpf_emit(out, OP_JEQ_K, 14, 13, first);
    bpf_emit(out, OP_JEQ_K, 0, 14, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 2, 0, 132);
    bpf_emit(out, OP_JEQ_K, 1, 0, 6);
    bpf_emit(out, OP_JEQ_K, 0, 10, 17);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 8, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 14);
    bpf_emit(out, OP_JEQ_K, 4, 0, first);
    bpf_emit(out, OP_JEQ_K, 3, 0, second);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 1, 0, first);
    bpf_emit(out, OP_JEQ_K, 0, 1, second);
    bpf_emit(out, OP_RET_K, 0, 0, 0);
    bpf_emit(out, OP_RET_K, 0, 0, c->snaplen);
    return 1;
}

static int optimized_icmp_not_type_pair_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char first_name[32], second_name[32], trailing;
    uint32_t first, second, linkoff, family, protooff, fragoff, ipbase;
    uint16_t linkload;

    if (!c->optimize || !starts(c->filter, "icmp and not (icmp[icmptype] = ") ||
        sscanf(c->filter,
               "icmp and not (icmp[icmptype] = %31s or icmp[icmptype] = %31[^)])%c",
               first_name, second_name, &trailing) != 2 ||
        !icmp_named_type(first_name, &first) || !icmp_named_type(second_name, &second))
        return 0;

    if (c->dlt == 1) {
        linkload = OP_LDH_ABS; linkoff = 12; family = 2048;
        protooff = 23; fragoff = 20; ipbase = 14;
    } else if (c->dlt == 113) {
        linkload = OP_LDH_ABS; linkoff = 14; family = 2048;
        protooff = 25; fragoff = 22; ipbase = 16;
    } else if (c->dlt == 9) {
        linkload = OP_LDH_ABS; linkoff = 2; family = 33;
        protooff = 13; fragoff = 10; ipbase = 4;
    } else if (c->dlt == 0) {
        linkload = OP_LDW_ABS; linkoff = 0; family = 0x02000000U;
        protooff = 13; fragoff = 10; ipbase = 4;
    } else return 0;

    bpf_emit(out, linkload, 0, 0, linkoff);
    bpf_emit(out, OP_JEQ_K, 0, 9, family);
    bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
    bpf_emit(out, OP_JEQ_K, 0, 7, 1);
    bpf_emit(out, OP_LDH_ABS, 0, 0, fragoff);
    bpf_emit(out, OP_JSET_K, 4, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, ipbase);
    bpf_emit(out, BPF_LD | BPF_B | BPF_IND, 0, 0, ipbase);
    bpf_emit(out, OP_JEQ_K, 2, 0, first);
    bpf_emit(out, OP_JEQ_K, 1, 0, second);
    bpf_emit(out, OP_RET_K, 0, 0, c->snaplen);
    bpf_emit(out, OP_RET_K, 0, 0, 0);
    return 1;
}

static int optimized_not_directional_nets_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned sa, sb, sc, sd, source_bits;
    unsigned da, db, dc, dd, destination_bits;
    uint32_t source_mask, destination_mask, source_network, destination_network;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "not (src net ") ||
        sscanf(c->filter,
               "not (src net %u.%u.%u.%u/%u and dst net %u.%u.%u.%u/%u)%c",
               &sa, &sb, &sc, &sd, &source_bits,
               &da, &db, &dc, &dd, &destination_bits, &trailing) != 10 ||
        sa > 255 || sb > 255 || sc > 255 || sd > 255 || source_bits > 32 ||
        da > 255 || db > 255 || dc > 255 || dd > 255 || destination_bits > 32)
        return 0;

    source_mask = source_bits ? UINT32_MAX << (32 - source_bits) : 0;
    destination_mask = destination_bits ? UINT32_MAX << (32 - destination_bits) : 0;
    source_network = ((sa << 24) | (sb << 16) | (sc << 8) | sd) & source_mask;
    destination_network = ((da << 24) | (db << 16) | (dc << 8) | dd) & destination_mask;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 6, 2048);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 26);
    bpf_emit(out, OP_AND_K, 0, 0, source_mask);
    bpf_emit(out, OP_JEQ_K, 0, 12, source_network);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 30);
    bpf_emit(out, OP_AND_K, 0, 0, destination_mask);
    bpf_emit(out, OP_JEQ_K, 8, 9, destination_network);
    bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
    bpf_emit(out, OP_JEQ_K, 0, 7, 32821);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 28);
    bpf_emit(out, OP_AND_K, 0, 0, source_mask);
    bpf_emit(out, OP_JEQ_K, 0, 4, source_network);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 38);
    bpf_emit(out, OP_AND_K, 0, 0, destination_mask);
    bpf_emit(out, OP_JEQ_K, 0, 1, destination_network);
    bpf_emit(out, OP_RET_K, 0, 0, 0);
    bpf_emit(out, OP_RET_K, 0, 0, c->snaplen);
    return 1;
}

static int optimized_tcp_directional_host_port_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char host_direction[4], port_direction[4], trailing;
    unsigned a, b, d, e, port;
    uint32_t address;

    if (!c->optimize || c->dlt != 1 ||
        (!starts(c->filter, "tcp and src host ") &&
         !starts(c->filter, "tcp and dst host ")) ||
        sscanf(c->filter, "tcp and %3s host %u.%u.%u.%u and %3s port %u%c",
               host_direction, &a, &b, &d, &e, port_direction, &port, &trailing) != 7 ||
        (strcmp(host_direction, "src") && strcmp(host_direction, "dst")) ||
        (strcmp(port_direction, "src") && strcmp(port_direction, "dst")) ||
        a > 255 || b > 255 || d > 255 || e > 255 || port > 65535)
        return 0;

    address = (a << 24) | (b << 16) | (d << 8) | e;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 10, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 8, 6);
    bpf_emit(out, OP_LDW_ABS, 0, 0, !strcmp(host_direction, "src") ? 26 : 30);
    bpf_emit(out, OP_JEQ_K, 0, 6, address);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 4, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, !strcmp(port_direction, "src") ? 14 : 16);
    bpf_emit(out, OP_JEQ_K, 0, 1, port);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_ip_tcp_port_not_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char port_direction[4], host_direction[4], trailing;
    unsigned port, a, b, d, e;
    uint32_t address;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "ip and tcp and (") ||
        sscanf(c->filter,
               "ip and tcp and (%3s port %u) and not (%3s host %u.%u.%u.%u)%c",
               port_direction, &port, host_direction, &a, &b, &d, &e, &trailing) != 7 ||
        (strcmp(port_direction, "src") && strcmp(port_direction, "dst")) ||
        (strcmp(host_direction, "src") && strcmp(host_direction, "dst")) ||
        port > 65535 || a > 255 || b > 255 || d > 255 || e > 255)
        return 0;

    address = (a << 24) | (b << 16) | (d << 8) | e;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 10, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 8, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 6, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, !strcmp(port_direction, "src") ? 14 : 16);
    bpf_emit(out, OP_JEQ_K, 0, 3, port);
    bpf_emit(out, OP_LDW_ABS, 0, 0, !strcmp(host_direction, "src") ? 26 : 30);
    bpf_emit(out, OP_JEQ_K, 1, 0, address);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_nested_tcp_ports_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned first_port, second_port, a, b, d, e;
    uint32_t address;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "(ip and (tcp and (port ") ||
        sscanf(c->filter,
               "(ip and (tcp and (port %u or (port %u and host %u.%u.%u.%u))))%c",
               &first_port, &second_port, &a, &b, &d, &e, &trailing) != 6 ||
        first_port > 65535 || second_port > 65535 ||
        a > 255 || b > 255 || d > 255 || e > 255)
        return 0;

    address = (a << 24) | (b << 16) | (d << 8) | e;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 17, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 15, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 13, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 14);
    bpf_emit(out, OP_JEQ_K, 9, 0, first_port);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 7, 0, first_port);
    bpf_emit(out, OP_JEQ_K, 2, 0, second_port);
    bpf_emit(out, OP_LDH_IND, 0, 0, 14);
    bpf_emit(out, OP_JEQ_K, 0, 5, second_port);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 26);
    bpf_emit(out, OP_JEQ_K, 2, 0, address);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 30);
    bpf_emit(out, OP_JEQ_K, 0, 1, address);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_ip_tcp_not_three_ports_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned first, second, third;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "ip and tcp and not (port ") ||
        sscanf(c->filter, "ip and tcp and not (port %u or port %u or port %u)%c",
               &first, &second, &third, &trailing) != 3 ||
        first > 65535 || second > 65535 || third > 65535)
        return 0;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 14, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 12, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 9, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 14);
    bpf_emit(out, OP_JEQ_K, 7, 0, first);
    bpf_emit(out, OP_JEQ_K, 6, 0, second);
    bpf_emit(out, OP_JEQ_K, 5, 0, third);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 3, 0, first);
    bpf_emit(out, OP_JEQ_K, 2, 0, second);
    bpf_emit(out, OP_JEQ_K, 1, 0, third);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_tcp_two_ports_not_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned first, second, a, b, d, e;
    uint32_t address;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "tcp and (port ") ||
        sscanf(c->filter,
               "tcp and (port %u or port %u) and not host %u.%u.%u.%u%c",
               &first, &second, &a, &b, &d, &e, &trailing) != 6 ||
        first > 65535 || second > 65535 ||
        a > 255 || b > 255 || d > 255 || e > 255)
        return 0;

    address = (a << 24) | (b << 16) | (d << 8) | e;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 15, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 23, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 21, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 14);
    bpf_emit(out, OP_JEQ_K, 4, 0, first);
    bpf_emit(out, OP_JEQ_K, 3, 0, second);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 1, 0, first);
    bpf_emit(out, OP_JEQ_K, 0, 14, second);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 26);
    bpf_emit(out, OP_JEQ_K, 12, 0, address);
    bpf_emit(out, OP_LDW_ABS, 0, 0, 30);
    bpf_emit(out, OP_JEQ_K, 10, 9, address);
    bpf_emit(out, OP_JEQ_K, 0, 9, 34525);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
    bpf_emit(out, OP_JEQ_K, 0, 7, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 54);
    bpf_emit(out, OP_JEQ_K, 4, 0, first);
    bpf_emit(out, OP_JEQ_K, 3, 0, second);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 56);
    bpf_emit(out, OP_JEQ_K, 1, 0, first);
    bpf_emit(out, OP_JEQ_K, 0, 1, second);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_ip46_tcp_udp_four_ports_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned first, second, third, fourth;
    char trailing;

    if (!c->optimize || c->dlt != 1 ||
        !starts(c->filter, "((ip or ip6) and (tcp or udp)) and ((port ") ||
        sscanf(c->filter,
               "((ip or ip6) and (tcp or udp)) and ((port %u or port %u) or (port %u or port %u))%c",
               &first, &second, &third, &fourth, &trailing) != 4 ||
        first > 65535 || second > 65535 || third > 65535 || fourth > 65535)
        return 0;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 13, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 1, 0, 6);
    bpf_emit(out, OP_JEQ_K, 0, 26, 17);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 24, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 14);
    bpf_emit(out, OP_JEQ_K, 20, 0, first);
    bpf_emit(out, OP_JEQ_K, 19, 0, second);
    bpf_emit(out, OP_JEQ_K, 18, 0, third);
    bpf_emit(out, OP_JEQ_K, 17, 0, fourth);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 15, 12, first);
    bpf_emit(out, OP_JEQ_K, 0, 15, 34525);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
    bpf_emit(out, OP_JEQ_K, 2, 0, 6);
    bpf_emit(out, OP_JEQ_K, 12, 0, 44);
    bpf_emit(out, OP_JEQ_K, 0, 11, 17);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 54);
    bpf_emit(out, OP_JEQ_K, 8, 0, first);
    bpf_emit(out, OP_JEQ_K, 7, 0, second);
    bpf_emit(out, OP_JEQ_K, 6, 0, third);
    bpf_emit(out, OP_JEQ_K, 5, 0, fourth);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 56);
    bpf_emit(out, OP_JEQ_K, 3, 0, first);
    bpf_emit(out, OP_JEQ_K, 2, 0, second);
    bpf_emit(out, OP_JEQ_K, 1, 0, third);
    bpf_emit(out, OP_JEQ_K, 0, 1, fourth);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_ip_tcp2_udp1_dst_ports_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned first_tcp, second_tcp, udp_port;
    char trailing;

    if (!c->optimize || c->dlt != 1 ||
        !starts(c->filter, "ip and ((tcp and (dst port ") ||
        sscanf(c->filter,
               "ip and ((tcp and (dst port %u or dst port %u)) or (udp and dst port %u))%c",
               &first_tcp, &second_tcp, &udp_port, &trailing) != 3 ||
        first_tcp > 65535 || second_tcp > 65535 || udp_port > 65535)
        return 0;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 15, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 6, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 11, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 7, 0, first_tcp);
    bpf_emit(out, OP_JEQ_K, 6, 7, second_tcp);
    bpf_emit(out, OP_JEQ_K, 0, 6, 17);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 4, 0, 8191);
    bpf_emit(out, BPF_LDX | BPF_B | BPF_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, OP_JEQ_K, 0, 1, udp_port);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_identical_tcp_udp_group_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    if (!c->optimize || c->dlt != 1 ||
        strcmp(c->filter, "(tcp or udp) and (tcp or udp)"))
        return 0;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 2, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 7, 6, 6);
    bpf_emit(out, OP_JEQ_K, 0, 7, 34525);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
    bpf_emit(out, OP_JEQ_K, 4, 0, 6);
    bpf_emit(out, OP_JEQ_K, 0, 2, 44);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 54);
    bpf_emit(out, OP_JEQ_K, 1, 0, 6);
    bpf_emit(out, OP_JEQ_K, 0, 1, 17);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_ip6_absorbed_protocol_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char first[32], second[32], trailing;
    uint32_t protocol;
    int matched = 0;

    if (!c->optimize || c->dlt != 1) return 0;
    if (starts(c->filter, "ip6 or ip6 or ") &&
        sscanf(c->filter, "ip6 or ip6 or %31s%c", first, &trailing) == 1)
        matched = 1;
    else if (c->filter[0] == '(' &&
             sscanf(c->filter, "(ip6 or %31[^)]) and (ip6 or %31[^)])%c",
                    first, second, &trailing) == 2 && !strcmp(first, second))
        matched = 1;
    if (!matched || !strcmp(first, "icmp6") || !protocol_number(first, &protocol))
        return 0;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 3, 0, 34525);
    bpf_emit(out, OP_JEQ_K, 0, 3, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
    finish_test(out, c->snaplen);
    return 1;
}

static int optimized_tcp_udp_ports_not_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned tcp_port, udp_port, a, b, d, e;
    uint32_t address;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "((tcp and port ") ||
        sscanf(c->filter,
               "((tcp and port %u) or (udp and port %u)) and not host %u.%u.%u.%u%c",
               &tcp_port, &udp_port, &a, &b, &d, &e, &trailing) != 6 ||
        tcp_port > 65535 || udp_port > 65535 ||
        a > 255 || b > 255 || d > 255 || e > 255)
        return 0;

    address = (a << 24) | (b << 16) | (d << 8) | e;
    bpf_emit(out,OP_LDH_ABS,0,0,12); bpf_emit(out,OP_JEQ_K,0,21,2048);
    bpf_emit(out,OP_LDB_ABS,0,0,23); bpf_emit(out,OP_JEQ_K,0,7,6);
    bpf_emit(out,OP_LDH_ABS,0,0,20); bpf_emit(out,OP_JSET_K,31,0,8191);
    bpf_emit(out,BPF_LDX|BPF_B|BPF_MSH,0,0,14); bpf_emit(out,OP_LDH_IND,0,0,14);
    bpf_emit(out,OP_JEQ_K,10,0,tcp_port); bpf_emit(out,OP_LDH_IND,0,0,16);
    bpf_emit(out,OP_JEQ_K,8,26,tcp_port); bpf_emit(out,OP_JEQ_K,0,25,17);
    bpf_emit(out,OP_LDH_ABS,0,0,20); bpf_emit(out,OP_JSET_K,23,0,8191);
    bpf_emit(out,BPF_LDX|BPF_B|BPF_MSH,0,0,14); bpf_emit(out,OP_LDH_IND,0,0,14);
    bpf_emit(out,OP_JEQ_K,2,0,udp_port); bpf_emit(out,OP_LDH_IND,0,0,16);
    bpf_emit(out,OP_JEQ_K,0,18,udp_port); bpf_emit(out,OP_LDW_ABS,0,0,26);
    bpf_emit(out,OP_JEQ_K,16,0,address); bpf_emit(out,OP_LDW_ABS,0,0,30);
    bpf_emit(out,OP_JEQ_K,14,13,address); bpf_emit(out,OP_JEQ_K,0,13,34525);
    bpf_emit(out,OP_LDB_ABS,0,0,20); bpf_emit(out,OP_JEQ_K,0,4,6);
    bpf_emit(out,OP_LDH_ABS,0,0,54); bpf_emit(out,OP_JEQ_K,8,0,tcp_port);
    bpf_emit(out,OP_LDH_ABS,0,0,56); bpf_emit(out,OP_JEQ_K,6,7,tcp_port);
    bpf_emit(out,OP_JEQ_K,6,0,44); bpf_emit(out,OP_JEQ_K,0,5,17);
    bpf_emit(out,OP_LDH_ABS,0,0,54); bpf_emit(out,OP_JEQ_K,2,0,udp_port);
    bpf_emit(out,OP_LDH_ABS,0,0,56); bpf_emit(out,OP_JEQ_K,0,1,udp_port);
    finish_test(out,c->snaplen);
    return 1;
}

static int optimized_two_hosts_two_ports_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned a1,b1,d1,e1,a2,b2,d2,e2,first_port,second_port;
    uint32_t first_host, second_host;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "(host ") ||
        sscanf(c->filter,
               "(host %u.%u.%u.%u or host %u.%u.%u.%u) and (port %u or port %u)%c",
               &a1,&b1,&d1,&e1,&a2,&b2,&d2,&e2,&first_port,&second_port,&trailing) != 10 ||
        a1>255||b1>255||d1>255||e1>255||a2>255||b2>255||d2>255||e2>255||
        first_port>65535||second_port>65535)
        return 0;

    first_host=(a1<<24)|(b1<<16)|(d1<<8)|e1;
    second_host=(a2<<24)|(b2<<16)|(d2<<8)|e2;
    bpf_emit(out,OP_LDH_ABS,0,0,12); bpf_emit(out,OP_JEQ_K,0,20,2048);
    bpf_emit(out,OP_LDW_ABS,0,0,26); bpf_emit(out,OP_JEQ_K,4,0,first_host);
    bpf_emit(out,OP_JEQ_K,3,0,second_host); bpf_emit(out,OP_LDW_ABS,0,0,30);
    bpf_emit(out,OP_JEQ_K,1,0,first_host); bpf_emit(out,OP_JEQ_K,0,14,second_host);
    bpf_emit(out,OP_LDB_ABS,0,0,23); bpf_emit(out,OP_JEQ_K,2,0,132);
    bpf_emit(out,OP_JEQ_K,1,0,6); bpf_emit(out,OP_JEQ_K,0,10,17);
    bpf_emit(out,OP_LDH_ABS,0,0,20); bpf_emit(out,OP_JSET_K,8,0,8191);
    bpf_emit(out,BPF_LDX|BPF_B|BPF_MSH,0,0,14); bpf_emit(out,OP_LDH_IND,0,0,14);
    bpf_emit(out,OP_JEQ_K,4,0,first_port); bpf_emit(out,OP_JEQ_K,3,0,second_port);
    bpf_emit(out,OP_LDH_IND,0,0,16); bpf_emit(out,OP_JEQ_K,1,0,first_port);
    bpf_emit(out,OP_JEQ_K,0,1,second_port); finish_test(out,c->snaplen);
    return 1;
}

static int optimized_ip_or_arp_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned a,b,d,e;
    uint32_t address;
    char trailing;

    if (!c->optimize || c->dlt != 1 || !starts(c->filter, "(ip or arp) and host ") ||
        sscanf(c->filter, "(ip or arp) and host %u.%u.%u.%u%c",
               &a,&b,&d,&e,&trailing) != 4 ||
        a>255||b>255||d>255||e>255)
        return 0;
    address=(a<<24)|(b<<16)|(d<<8)|e;
    bpf_emit(out,OP_LDH_ABS,0,0,12); bpf_emit(out,OP_JEQ_K,0,4,2048);
    bpf_emit(out,OP_LDW_ABS,0,0,26); bpf_emit(out,OP_JEQ_K,7,0,address);
    bpf_emit(out,OP_LDW_ABS,0,0,30); bpf_emit(out,OP_JEQ_K,5,6,address);
    bpf_emit(out,OP_JEQ_K,0,5,2054); bpf_emit(out,OP_LDW_ABS,0,0,28);
    bpf_emit(out,OP_JEQ_K,2,0,address); bpf_emit(out,OP_LDW_ABS,0,0,38);
    bpf_emit(out,OP_JEQ_K,0,1,address); finish_test(out,c->snaplen);
    return 1;
}

static int optimized_two_generic_ports_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char tail[8];unsigned first,second;uint16_t linkload;uint32_t linkoff,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;int raw=0;
    if(!c->optimize||sscanf(c->filter,"port %u or port %u %7s",&first,&second,tail)!=2||first>65535||second>65535)return 0;
    if(c->dlt==1){linkload=OP_LDH_ABS;linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6src=54;v6dst=56;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){linkload=OP_LDH_ABS;linkoff=2;ip6=87;ip4=33;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){linkload=OP_LDH_ABS;linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6src=56;v6dst=58;v4proto=25;fragment=22;base=16;}
    else if(c->dlt==0){linkload=OP_LDW_ABS;linkoff=0;ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==12){linkload=0;linkoff=0;ip6=96;ip4=64;v6proto=6;v6src=40;v6dst=42;v4proto=9;fragment=6;base=0;raw=1;}
    else return 0;
    if(raw){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}else bpf_emit(out,linkload,0,0,linkoff);
    bpf_emit(out,OP_JEQ_K,0,9,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);bpf_emit(out,OP_JEQ_K,2,0,132);
    bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,(uint8_t)(20+(raw?2:0)),17);bpf_emit(out,OP_LDH_ABS,0,0,v6src);
    bpf_emit(out,OP_JEQ_K,(uint8_t)(17+(raw?2:0)),0,first);bpf_emit(out,OP_JEQ_K,(uint8_t)(16+(raw?2:0)),0,second);
    bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,OP_JEQ_K,(uint8_t)(14+(raw?2:0)),(uint8_t)(13+(raw?2:0)),first);
    if(raw){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    bpf_emit(out,OP_JEQ_K,0,14,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,2,0,132);
    bpf_emit(out,OP_JEQ_K,1,0,6);bpf_emit(out,OP_JEQ_K,0,10,17);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
    bpf_emit(out,OP_JSET_K,8,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);
    bpf_emit(out,OP_JEQ_K,4,0,first);bpf_emit(out,OP_JEQ_K,3,0,second);bpf_emit(out,OP_LDH_IND,0,0,base+2);
    bpf_emit(out,OP_JEQ_K,1,0,first);bpf_emit(out,OP_JEQ_K,0,1,second);finish_test(out,c->snaplen);return 1;
}

int optimized_three_direction_ports_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_names[3][8],directions[3][8],tail[8];unsigned ports[3];uint32_t protocol;
    uint32_t linkoff,ip6,ip4,v6proto,v6port,v4proto,fragment,base,indirect;
    if(!c->optimize||sscanf(c->filter,"%7s %7s port %u or %7s %7s port %u or %7s %7s port %u %7s",
       protocol_names[0],directions[0],&ports[0],protocol_names[1],directions[1],&ports[1],protocol_names[2],directions[2],&ports[2],tail)!=9||
       strcmp(protocol_names[0],protocol_names[1])||strcmp(protocol_names[0],protocol_names[2])||
       strcmp(directions[0],directions[1])||strcmp(directions[0],directions[2])||
       (strcmp(directions[0],"src")&&strcmp(directions[0],"dst")))return 0;
    if(!strcmp(protocol_names[0],"tcp"))protocol=6;else if(!strcmp(protocol_names[0],"udp"))protocol=17;
    else if(!strcmp(protocol_names[0],"sctp"))protocol=132;else return 0;
    if(c->dlt==1){linkoff=12;ip6=34525;ip4=2048;v6proto=20;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){linkoff=2;ip6=87;ip4=33;v6proto=10;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){linkoff=14;ip6=34525;ip4=2048;v6proto=22;v4proto=25;fragment=22;base=16;}
    else return 0;
    v6port=!strcmp(directions[0],"dst")?base+42:base+40;indirect=!strcmp(directions[0],"dst")?base+2:base;
    bpf_emit(out,OP_LDH_ABS,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,4,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
    bpf_emit(out,OP_JEQ_K,0,13,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6port);bpf_emit(out,OP_JEQ_K,10,8,ports[0]);
    bpf_emit(out,OP_JEQ_K,0,10,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,0,8,protocol);
    bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,6,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);
    bpf_emit(out,OP_LDH_IND,0,0,indirect);bpf_emit(out,OP_JEQ_K,2,0,ports[0]);bpf_emit(out,OP_JEQ_K,1,0,ports[1]);
    bpf_emit(out,OP_JEQ_K,0,1,ports[2]);finish_test(out,c->snaplen);return 1;
}

static int raw_unoptimized_both_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    unsigned port;char tail[8];static const uint32_t protocols[3]={132,6,17};int index;
    static const uint8_t v6_accept[3]={44,38,32},v4_proto_reject[3]={8,8,9};
    static const uint8_t v4_frag_accept[3]={6,6,7},v4_accept[3]={20,10,0};
    if(c->optimize||c->dlt!=0||sscanf(c->filter,"src and dst port %u %7s",&port,tail)!=1||port>65535)return 0;
    bpf_emit(out,OP_LDW_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,18,0x0a000000U);
    for(index=0;index<3;++index){
        bpf_emit(out,OP_LDB_ABS,0,0,10);bpf_emit(out,OP_JEQ_K,0,4,protocols[index]);
        bpf_emit(out,OP_LDH_ABS,0,0,44);bpf_emit(out,OP_JEQ_K,0,2,port);
        bpf_emit(out,OP_LDH_ABS,0,0,46);bpf_emit(out,OP_JEQ_K,v6_accept[index],0,port);
    }
    bpf_emit(out,OP_LDW_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,31,0x02000000U);
    for(index=0;index<3;++index){
        bpf_emit(out,OP_LDB_ABS,0,0,13);bpf_emit(out,OP_JEQ_K,0,v4_proto_reject[index],protocols[index]);
        bpf_emit(out,OP_LDH_ABS,0,0,10);bpf_emit(out,OP_JSET_K,v4_frag_accept[index],0,8191);
        bpf_emit(out,OP_LDX_MSH,0,0,4);bpf_emit(out,OP_LDH_IND,0,0,4);bpf_emit(out,OP_JEQ_K,0,index==2?4:3,port);
        bpf_emit(out,OP_LDX_MSH,0,0,4);bpf_emit(out,OP_LDH_IND,0,0,6);bpf_emit(out,OP_JEQ_K,v4_accept[index],index==2?1:0,port);
    }
    finish_test(out,c->snaplen);return 1;
}

static int raw_unoptimized_direction_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],tail[8];unsigned port;static const uint32_t protocols[3]={132,6,17};
    size_t v6_setup,v6_guard,v6_starts[3],v6_proto[3],v6_test[3],v4_setup,v4_guard,v4_starts[3],v4_proto[3],v4_frag[3],v4_test[3],accept,reject;
    uint32_t v6offset,indirect;int index;
    if(c->optimize||c->dlt!=12||sscanf(c->filter,"%7s port %u %7s",direction,&port,tail)!=2||
       (strcmp(direction,"src")&&strcmp(direction,"dst"))||port>65535)return 0;
    v6offset=!strcmp(direction,"dst")?42:40;indirect=!strcmp(direction,"dst")?2:0;
    v6_setup=out->len;bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
    v6_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,96);
    for(index=0;index<3;++index){v6_starts[index]=out->len;bpf_emit(out,OP_LDB_ABS,0,0,6);
        v6_proto[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocols[index]);bpf_emit(out,OP_LDH_ABS,0,0,v6offset);
        v6_test[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);}
    v4_setup=out->len;bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);
    v4_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,64);
    for(index=0;index<3;++index){v4_starts[index]=out->len;bpf_emit(out,OP_LDB_ABS,0,0,9);
        v4_proto[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocols[index]);bpf_emit(out,OP_LDH_ABS,0,0,6);
        v4_frag[index]=out->len;bpf_emit(out,OP_JSET_K,0,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,0);
        bpf_emit(out,OP_LDH_IND,0,0,indirect);v4_test[index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);}
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    (void)v6_setup;out->insns[v6_guard].jf=(uint8_t)(v4_setup-v6_guard-1);
    for(index=0;index<3;++index){size_t next=index<2?v6_starts[index+1]:v4_setup;
        out->insns[v6_proto[index]].jf=(uint8_t)(next-v6_proto[index]-1);out->insns[v6_test[index]].jt=(uint8_t)(accept-v6_test[index]-1);}
    out->insns[v4_guard].jf=(uint8_t)(reject-v4_guard-1);
    for(index=0;index<3;++index){size_t next=index<2?v4_starts[index+1]:reject;
        out->insns[v4_proto[index]].jf=(uint8_t)(next-v4_proto[index]-1);out->insns[v4_frag[index]].jt=(uint8_t)(next-v4_frag[index]-1);
        out->insns[v4_test[index]].jt=(uint8_t)(accept-v4_test[index]-1);out->insns[v4_test[index]].jf=(uint8_t)(next-v4_test[index]-1);}
    return 1;
}

static int raw_unoptimized_any_port_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char tail[8];unsigned port;static const uint32_t protocols[3]={132,6,17};
    size_t v6_guard,v6_starts[3],v6_proto[3],v6_tests[3][2],v4_setup,v4_guard,v4_starts[3],v4_proto[3],v4_frag[3],v4_tests[3][2],accept,reject;
    int protocol_index,direction_index;
    if(c->optimize||c->dlt!=12||sscanf(c->filter,"port %u %7s",&port,tail)!=1||port>65535)return 0;
    bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);v6_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,96);
    for(protocol_index=0;protocol_index<3;++protocol_index){v6_starts[protocol_index]=out->len;bpf_emit(out,OP_LDB_ABS,0,0,6);
        v6_proto[protocol_index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocols[protocol_index]);
        for(direction_index=0;direction_index<2;++direction_index){bpf_emit(out,OP_LDH_ABS,0,0,direction_index?42:40);
            v6_tests[protocol_index][direction_index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);}}
    v4_setup=out->len;bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);v4_guard=out->len;bpf_emit(out,OP_JEQ_K,0,0,64);
    for(protocol_index=0;protocol_index<3;++protocol_index){v4_starts[protocol_index]=out->len;bpf_emit(out,OP_LDB_ABS,0,0,9);
        v4_proto[protocol_index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,protocols[protocol_index]);bpf_emit(out,OP_LDH_ABS,0,0,6);
        v4_frag[protocol_index]=out->len;bpf_emit(out,OP_JSET_K,0,0,8191);
        for(direction_index=0;direction_index<2;++direction_index){bpf_emit(out,OP_LDX_MSH,0,0,0);
            bpf_emit(out,OP_LDH_IND,0,0,direction_index?2:0);v4_tests[protocol_index][direction_index]=out->len;bpf_emit(out,OP_JEQ_K,0,0,port);}}
    accept=out->len;finish_test(out,c->snaplen);reject=out->len-1;
    out->insns[v6_guard].jf=(uint8_t)(v4_setup-v6_guard-1);
    for(protocol_index=0;protocol_index<3;++protocol_index){size_t next=protocol_index<2?v6_starts[protocol_index+1]:v4_setup;
        out->insns[v6_proto[protocol_index]].jf=(uint8_t)(next-v6_proto[protocol_index]-1);
        for(direction_index=0;direction_index<2;++direction_index)out->insns[v6_tests[protocol_index][direction_index]].jt=(uint8_t)(accept-v6_tests[protocol_index][direction_index]-1);}
    out->insns[v4_guard].jf=(uint8_t)(reject-v4_guard-1);
    for(protocol_index=0;protocol_index<3;++protocol_index){size_t next=protocol_index<2?v4_starts[protocol_index+1]:reject;
        out->insns[v4_proto[protocol_index]].jf=(uint8_t)(next-v4_proto[protocol_index]-1);out->insns[v4_frag[protocol_index]].jt=(uint8_t)(next-v4_frag[protocol_index]-1);
        for(direction_index=0;direction_index<2;++direction_index){size_t jump=v4_tests[protocol_index][direction_index];
            out->insns[jump].jt=(uint8_t)(accept-jump-1);if(direction_index==1)out->insns[jump].jf=(uint8_t)(next-jump-1);}}
    return 1;
}

static int loopback_unoptimized_direction_range_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char direction[8],tail[8];unsigned low,high;static const uint32_t protocols[3]={132,6,17};
    static const uint8_t v6_high_reject[3]={44,38,32},v4_proto_reject[3]={8,8,9},v4_frag_accept[3]={6,6,7},v4_high_reject[3]={20,10,0};
    uint32_t absolute,indirect;int index;
    if(c->optimize||c->dlt!=0||sscanf(c->filter,"%7s portrange %u-%u %7s",direction,&low,&high,tail)!=3||
       (strcmp(direction,"src")&&strcmp(direction,"dst")))return 0;
    absolute=!strcmp(direction,"dst")?46:44;indirect=!strcmp(direction,"dst")?6:4;
    bpf_emit(out,OP_LDW_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,18,0x0a000000U);
    for(index=0;index<3;++index){bpf_emit(out,OP_LDB_ABS,0,0,10);bpf_emit(out,OP_JEQ_K,0,4,protocols[index]);
        bpf_emit(out,OP_LDH_ABS,0,0,absolute);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
        bpf_emit(out,OP_LDH_ABS,0,0,absolute);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,v6_high_reject[index],high);}
    bpf_emit(out,OP_LDW_ABS,0,0,0);bpf_emit(out,OP_JEQ_K,0,31,0x02000000U);
    for(index=0;index<3;++index){bpf_emit(out,OP_LDB_ABS,0,0,13);bpf_emit(out,OP_JEQ_K,0,v4_proto_reject[index],protocols[index]);
        bpf_emit(out,OP_LDH_ABS,0,0,10);bpf_emit(out,OP_JSET_K,v4_frag_accept[index],0,8191);
        bpf_emit(out,OP_LDX_MSH,0,0,4);bpf_emit(out,OP_LDH_IND,0,0,indirect);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,3,low);
        bpf_emit(out,OP_LDX_MSH,0,0,4);bpf_emit(out,OP_LDH_IND,0,0,indirect);
        bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,index==2?1:0,v4_high_reject[index],high);}
    finish_test(out,c->snaplen);return 1;
}

static int raw_both_fixed_range_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],tail[8];unsigned low,high;uint32_t protocol,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;
    if(!c->optimize||(c->dlt!=0&&c->dlt!=12)||
       sscanf(c->filter,"%7s src and dst portrange %u-%u %7s",protocol_name,&low,&high,tail)!=3)return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    if(c->dlt==0){ip6=0x0a000000U;ip4=0x02000000U;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;bpf_emit(out,OP_LDW_ABS,0,0,0);}
    else{ip6=96;ip4=64;v6proto=6;v6src=40;v6dst=42;v4proto=9;fragment=6;base=0;bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    bpf_emit(out,OP_JEQ_K,0,7,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);bpf_emit(out,OP_JEQ_K,0,(uint8_t)(18+(c->dlt==12?2:0)),protocol);
    bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,(uint8_t)(16+(c->dlt==12?2:0)),low);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,(uint8_t)(15+(c->dlt==12?2:0)),0,high);bpf_emit(out,OP_LDH_ABS,0,0,v6dst);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,(uint8_t)(11+(c->dlt==12?2:0)),(uint8_t)(13+(c->dlt==12?2:0)),low);
    if(c->dlt==12){bpf_emit(out,OP_LDB_ABS,0,0,0);bpf_emit(out,OP_AND_K,0,0,0xf0);}
    bpf_emit(out,OP_JEQ_K,0,12,ip4);
    bpf_emit(out,OP_LDB_ABS,0,0,v4proto);bpf_emit(out,OP_JEQ_K,0,10,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);
    bpf_emit(out,OP_JSET_K,8,0,8191);bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,5,low);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,4,0,high);
    bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
    bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);finish_test(out,c->snaplen);return 1;
}

static int unoptimized_fixed_any_range_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[8],tail[8];unsigned low,high;uint32_t protocol,linkoff,ip6,ip4,v6proto,v6src,v6dst,v4proto,fragment,base;uint16_t load;
    if(c->optimize||sscanf(c->filter,"%7s src or dst portrange %u-%u %7s",protocol_name,&low,&high,tail)!=3)return 0;
    if(!strcmp(protocol_name,"tcp"))protocol=6;else if(!strcmp(protocol_name,"udp"))protocol=17;else if(!strcmp(protocol_name,"sctp"))protocol=132;else return 0;
    if(c->dlt==1){load=OP_LDH_ABS;linkoff=12;ip6=34525;ip4=2048;v6proto=20;v6src=54;v6dst=56;v4proto=23;fragment=20;base=14;}
    else if(c->dlt==9){load=OP_LDH_ABS;linkoff=2;ip6=87;ip4=33;v6proto=10;v6src=44;v6dst=46;v4proto=13;fragment=10;base=4;}
    else if(c->dlt==113){load=OP_LDH_ABS;linkoff=14;ip6=34525;ip4=2048;v6proto=22;v6src=56;v6dst=58;v4proto=25;fragment=22;base=16;}
    else return 0;
    bpf_emit(out,load,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,10,ip6);bpf_emit(out,OP_LDB_ABS,0,0,v6proto);
    bpf_emit(out,OP_JEQ_K,0,8,protocol);bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);
    bpf_emit(out,OP_LDH_ABS,0,0,v6src);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,22,high);bpf_emit(out,OP_LDH_ABS,0,0,v6dst);
    bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,2,low);bpf_emit(out,OP_LDH_ABS,0,0,v6dst);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,18,high);
    bpf_emit(out,load,0,0,linkoff);bpf_emit(out,OP_JEQ_K,0,17,ip4);bpf_emit(out,OP_LDB_ABS,0,0,v4proto);
    bpf_emit(out,OP_JEQ_K,0,15,protocol);bpf_emit(out,OP_LDH_ABS,0,0,fragment);bpf_emit(out,OP_JSET_K,13,0,8191);
    bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,3,low);
    bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,0,6,high);
    bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,BPF_JMP|BPF_JGE|BPF_K,0,4,low);
    bpf_emit(out,OP_LDX_MSH,0,0,base);bpf_emit(out,OP_LDH_IND,0,0,base+2);bpf_emit(out,BPF_JMP|BPF_JGT|BPF_K,1,0,high);
    finish_test(out,c->snaplen);return 1;
}

static const char *normalized_address_direction(const bpfc_case_t *c, char normalized[256])
{
    const char *suffix;
    if (starts(c->filter,"src or dst host ") || starts(c->filter,"src or dst net ")) {
        strcpy(normalized,c->filter+11);
        return normalized;
    }
    if (starts(c->filter,"src and dst host ") || starts(c->filter,"src and dst net ")) {
        suffix=c->filter+12;
        if(snprintf(normalized,256,"(src %s and dst %s)",suffix,suffix)>=256)return NULL;
        return normalized;
    }
    return NULL;
}

static const char *double_negation(const bpfc_case_t *c,char reduced[256])
{
    char cleaned[256],*source,*destination,*cursor;int count=0;
    if(!c->optimize||strlen(c->filter)>=sizeof(cleaned))return NULL;
    source=(char *)c->filter;destination=cleaned;
    while(*source){if(*source!='('&&*source!=')')*destination++=*source;++source;}*destination=0;
    cursor=cleaned;while(starts(cursor,"not ")){++count;cursor+=4;}
    if(count<2||(count&1)||strstr(cursor," and ")||strstr(cursor," or "))return NULL;
    while(*cursor==' ')++cursor;
    strcpy(reduced,cursor);
    return reduced;
}

typedef enum {
    BOOL_LEAF,
    BOOL_AND,
    BOOL_OR,
    BOOL_NOT
} bool_kind_t;

typedef struct bool_expr {
    bool_kind_t kind;
    const char *begin;
    size_t length;
    struct bool_expr *left;
    struct bool_expr *right;
    size_t first_leaf;
} bool_expr_t;

typedef struct {
    bool_expr_t nodes[96];
    size_t used;
    int failed;
} bool_arena_t;

static void trim_span(const char **begin, size_t *length)
{
    while (*length && **begin == ' ') {
        ++*begin;
        --*length;
    }
    while (*length && (*begin)[*length - 1] == ' ')
        --*length;
}

static int span_is_wrapped(const char *begin, size_t length)
{
    size_t index;
    int depth = 0;
    if (length < 2 || begin[0] != '(' || begin[length - 1] != ')') return 0;
    for (index = 0; index < length; ++index) {
        if (begin[index] == '(') ++depth;
        else if (begin[index] == ')') {
            if (--depth == 0 && index + 1 != length) return 0;
            if (depth < 0) return 0;
        }
    }
    return depth == 0;
}

static const char *top_level_operator(const char *begin, size_t length,
                                      const char *operator_text)
{
    size_t index, operator_length = strlen(operator_text);
    int depth = 0;
    for (index = 0; index + operator_length <= length; ++index) {
        if (begin[index] == '(') ++depth;
        else if (begin[index] == ')') --depth;
        else if (depth == 0 && !memcmp(begin + index, operator_text, operator_length))
            return begin + index;
    }
    return NULL;
}

static bool_expr_t *parse_boolean_span(bool_arena_t *arena,
                                       const char *begin, size_t length)
{
    bool_expr_t *node;
    const char *operator_at;
    trim_span(&begin, &length);
    while (span_is_wrapped(begin, length)) {
        ++begin;
        length -= 2;
        trim_span(&begin, &length);
    }
    if (!length || arena->used == sizeof(arena->nodes) / sizeof(arena->nodes[0])) {
        arena->failed = 1;
        return NULL;
    }
    node = &arena->nodes[arena->used++];
    memset(node, 0, sizeof(*node));
    operator_at = top_level_operator(begin, length, " or ");
    if (operator_at) {
        node->kind = BOOL_OR;
        node->left = parse_boolean_span(arena, begin, (size_t)(operator_at - begin));
        node->right = parse_boolean_span(arena, operator_at + 4,
                                         length - (size_t)(operator_at + 4 - begin));
        return node;
    }
    operator_at = top_level_operator(begin, length, " and ");
    if (operator_at) {
        node->kind = BOOL_AND;
        node->left = parse_boolean_span(arena, begin, (size_t)(operator_at - begin));
        node->right = parse_boolean_span(arena, operator_at + 5,
                                         length - (size_t)(operator_at + 5 - begin));
        return node;
    }
    if (length > 4 && !memcmp(begin, "not ", 4)) {
        node->kind = BOOL_NOT;
        node->left = parse_boolean_span(arena, begin + 4, length - 4);
        return node;
    }
    node->kind = BOOL_LEAF;
    node->begin = begin;
    node->length = length;
    return node;
}

static int compile_boolean_leaf(const bpfc_case_t *c, const bool_expr_t *leaf,
                                bpf_prog_t *out)
{
    bpfc_case_t atom_case = *c;
    char atom[256], service[256];
    if (leaf->length >= sizeof(atom)) return 0;
    memcpy(atom, leaf->begin, leaf->length);
    atom[leaf->length] = 0;
    atom_case.filter = atom;
    if (resolved_service(&atom_case, service)) atom_case.filter = service;
    if (!strcmp(atom_case.filter, "net link-local")) atom_case.filter = "net 169.254.0.0/16";
    return simple_compile(&atom_case, out) || raw_unoptimized_direction_port_compile(&atom_case,out) || raw_unoptimized_any_port_compile(&atom_case,out) || loopback_unoptimized_direction_range_compile(&atom_case,out) ||
           generic_port_compile(&atom_case, out) || port_compile(&atom_case, out) || radiotap_port_compile(&atom_case,out) || radiotap_generic_port_compile(&atom_case,out) || radiotap_generic_any_port_compile(&atom_case,out) ||
           portrange_compile(&atom_case, out) || radiotap_portrange_compile(&atom_case,out) || radiotap_generic_range_compile(&atom_case,out) || generic_portrange_compile(&atom_case, out) ||
           fixed_direction_portrange_compile(&atom_case,out) ||
           host_compile(&atom_case, out) || host_other_compile(&atom_case,out) || ip_host_compile(&atom_case, out) ||
           arp_host_compile(&atom_case, out) || radiotap_host_compile(&atom_case, out) ||
           ipv6_host_compile(&atom_case, out) || radiotap_ipv6_host_compile(&atom_case,out) || ipv6_net_compile(&atom_case, out) ||
           radiotap_ether_host_compile(&atom_case,out) || ethernet_host_compile(&atom_case, out) || net_compile(&atom_case, out) || radiotap_net_compile(&atom_case,out) ||
           net_other_compile(&atom_case, out) || boolean_length_compile(&atom_case, out) ||
           tcp_flag_compile(&atom_case, out) || icmp_type_compile(&atom_case, out) ||
           ip_slice_compile(&atom_case, out) || radiotap_masked_ip_slice_compile(&atom_case,out) || masked_ip_slice_compile(&atom_case, out) ||
           transport_slice_compile(&atom_case, out) || radiotap_masked_link_slice_compile(&atom_case,out) || masked_link_slice_compile(&atom_case,out) ||
           ether_slice_compile(&atom_case, out) ||
           optimized_raw_direction_port_compile(&atom_case, out) ||
           optimized_raw_direction_portrange_compile(&atom_case, out) ||
           unoptimized_generic_both_portrange_compile(&atom_case, out) ||
           radiotap_transport_slice_compile(&atom_case, out);
}

static void number_boolean_leaves(bool_expr_t *node, size_t *count,
                                  bool_expr_t **leaves)
{
    node->first_leaf = *count;
    if (node->kind == BOOL_LEAF) {
        leaves[*count] = node;
        ++*count;
    } else {
        number_boolean_leaves(node->left, count, leaves);
        if (node->kind != BOOL_NOT)
            number_boolean_leaves(node->right, count, leaves);
    }
}

static void wire_boolean_leaves(const bool_expr_t *node, size_t true_target,
                                size_t false_target, size_t *true_targets,
                                size_t *false_targets)
{
    if (node->kind == BOOL_LEAF) {
        true_targets[node->first_leaf] = true_target;
        false_targets[node->first_leaf] = false_target;
    } else if (node->kind == BOOL_NOT) {
        wire_boolean_leaves(node->left, false_target, true_target,
                            true_targets, false_targets);
    } else if (node->kind == BOOL_AND) {
        wire_boolean_leaves(node->left, node->right->first_leaf, false_target,
                            true_targets, false_targets);
        wire_boolean_leaves(node->right, true_target, false_target,
                            true_targets, false_targets);
    } else {
        wire_boolean_leaves(node->left, true_target, node->right->first_leaf,
                            true_targets, false_targets);
        wire_boolean_leaves(node->right, true_target, false_target,
                            true_targets, false_targets);
    }
}

static int recursive_boolean_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    static const bpf_insn_t radiotap_setup[11] = {
        {1,0,0,0},{135,0,0,0},{4,0,0,24},{2,0,0,0},{80,0,0,0},{69,0,5,8},
        {69,4,0,4},{69,0,3,128},{96,0,0,0},{4,0,0,2},{2,0,0,0}
    };
    bool_arena_t arena;
    bool_expr_t *root, *leaves[48];
    bpf_prog_t programs[48];
    size_t starts_at[48], skip[48], memory_shift[48], true_targets[48], false_targets[48];
    size_t count = 0, total = 0, index, instruction;
    uint32_t highest_memory = 0;
    int outer_not,prepend_radiotap_setup=0;
    memset(&arena, 0, sizeof(arena));
    root = parse_boolean_span(&arena, c->filter, strlen(c->filter));
    if (!root || arena.failed || root->kind == BOOL_LEAF) return 0;
    number_boolean_leaves(root, &count, leaves);
    if (count < 1 || count > sizeof(leaves) / sizeof(leaves[0])) return 0;
    for (index = 0; index < count; ++index) {
        bpf_prog_init(&programs[index]);
        if (!compile_boolean_leaf(c, leaves[index], &programs[index]) ||
            programs[index].len < 3) {
            size_t free_index;
            for (free_index = 0; free_index <= index; ++free_index)
                bpf_prog_free(&programs[free_index]);
            return 0;
        }
        skip[index] = 0;
        if (c->dlt == 105 && index && programs[index].len >= 13 &&
            !memcmp(programs[index].insns, radiotap_setup, sizeof(radiotap_setup)))
            skip[index] = sizeof(radiotap_setup) / sizeof(radiotap_setup[0]);
        if(skip[index]&&!prepend_radiotap_setup&&programs[0].len>=2&&
           !(leaves[0]->length>=3&&!memcmp(leaves[0]->begin,"ip[",3))&&
           !(leaves[0]->length>=7&&!memcmp(leaves[0]->begin,"ifindex",7))&&
           (programs[0].len<13||memcmp(programs[0].insns,radiotap_setup,sizeof(radiotap_setup))))
            prepend_radiotap_setup=1;
        memory_shift[index] = 0;
        if (c->dlt == 105 && highest_memory && leaves[index]->length >= 3 &&
            !memcmp(leaves[index]->begin,"ip[",3) &&
            memchr(leaves[index]->begin,'&',leaves[index]->length))
            memory_shift[index] = highest_memory - 1;
        if (c->dlt != 105 && highest_memory) {
            for (instruction = skip[index]; instruction + 2 < programs[index].len; ++instruction) {
                bpf_insn_t *insn = &programs[index].insns[instruction];
                if ((insn->code == OP_ST_MEM || insn->code == OP_LD_MEM ||
                     insn->code == OP_LDX_MEM) && insn->k) {
                    memory_shift[index] = highest_memory;
                    break;
                }
            }
        }
        for (instruction = skip[index]; instruction + 2 < programs[index].len; ++instruction) {
            bpf_insn_t *insn = &programs[index].insns[instruction];
            if (insn->code == OP_ST_MEM || insn->code == OP_LD_MEM || insn->code == OP_LDX_MEM) {
                uint32_t slot = insn->k +
                    ((c->dlt != 105 || insn->k) ? (uint32_t)memory_shift[index] : 0);
                if (slot > highest_memory) highest_memory = slot;
            }
        }
        starts_at[index] = total;
        total += programs[index].len - 2 - skip[index];
    }
    if(prepend_radiotap_setup){
        for(index=0;index<count;++index)starts_at[index]+=sizeof(radiotap_setup)/sizeof(radiotap_setup[0]);
        total+=sizeof(radiotap_setup)/sizeof(radiotap_setup[0]);
    }
    outer_not = root->kind == BOOL_NOT ||
                (c->dlt == 105 && strstr(c->filter, "atalk"));
    wire_boolean_leaves(root, outer_not ? count + 1 : count,
                        outer_not ? count : count + 1,
                        true_targets, false_targets);
    bpf_prog_reset(out);
    if(prepend_radiotap_setup){
        for(index=0;index<sizeof(radiotap_setup)/sizeof(radiotap_setup[0]);++index)
            bpf_emit(out,radiotap_setup[index].code,radiotap_setup[index].jt,radiotap_setup[index].jf,radiotap_setup[index].k);
    }
    for (index = 0; index < count; ++index) {
        size_t original_body = programs[index].len - 2;
        size_t body = original_body - skip[index];
        for (instruction = 0; instruction < body; ++instruction) {
            size_t local_instruction = instruction + skip[index];
            bpf_insn_t insn = programs[index].insns[local_instruction];
            size_t global_instruction = starts_at[index] + instruction;
            if (memory_shift[index] && (c->dlt != 105 || insn.k) &&
                (insn.code == OP_ST_MEM || insn.code == OP_LD_MEM || insn.code == OP_LDX_MEM))
                insn.k += (uint32_t)memory_shift[index];
            if ((insn.code & 0x07) == BPF_JMP && (insn.code & 0xf0) != BPF_JA) {
                uint8_t *offsets[2] = {&insn.jt, &insn.jf};
                size_t branch_index;
                for (branch_index = 0; branch_index < 2; ++branch_index) {
                    size_t local_target = local_instruction + 1 + *offsets[branch_index];
                    size_t target_id, destination;
                    if (local_target == original_body) target_id = true_targets[index];
                    else if (local_target == original_body + 1) target_id = false_targets[index];
                    else continue;
                    destination = target_id < count ? starts_at[target_id] :
                                  total + (target_id - count);
                    if (destination <= global_instruction ||
                        destination - global_instruction - 1 > 255) goto fail;
                    *offsets[branch_index] = (uint8_t)(destination - global_instruction - 1);
                }
            } else if (insn.code == OP_JA) {
                size_t local_target = local_instruction + 1 + insn.k;
                size_t target_id, destination;
                if (local_target == original_body) target_id = true_targets[index];
                else if (local_target == original_body + 1) target_id = false_targets[index];
                else {
                    bpf_emit(out, insn.code, insn.jt, insn.jf, insn.k);
                    continue;
                }
                destination = target_id < count ? starts_at[target_id] :
                              total + (target_id - count);
                if (destination <= global_instruction) goto fail;
                insn.k = (uint32_t)(destination - global_instruction - 1);
            }
            bpf_emit(out, insn.code, insn.jt, insn.jf, insn.k);
        }
    }
    if (outer_not) {
        bpf_emit(out, OP_RET_K, 0, 0, 0);
        bpf_emit(out, OP_RET_K, 0, 0, (uint32_t)c->snaplen);
    } else finish_test(out, c->snaplen);
    for (index = 0; index < count; ++index) bpf_prog_free(&programs[index]);
    return !out->overflow;

fail:
    for (index = 0; index < count; ++index) bpf_prog_free(&programs[index]);
    bpf_prog_reset(out);
    return 0;
}

static void adjust_raw_terminal_less(const bpfc_case_t *c,bpf_prog_t *out)
{
    const char *suffix=strrchr(c->filter,')');size_t compare,length_test,branch,accept,reject;
    if(c->dlt!=12||!suffix||!starts(suffix+1," and less ")||out->len<5)return;
    compare=out->len-5;length_test=out->len-4;branch=out->len-3;accept=out->len-2;reject=out->len-1;
    if(out->insns[compare].code!=OP_JEQ_K||out->insns[compare].jf!=3||
       out->insns[length_test].code!=(BPF_LD|BPF_W|BPF_LEN)||
       out->insns[branch].code!=(BPF_JMP|BPF_JGT|BPF_K)||out->insns[branch].jt!=1||out->insns[branch].jf!=0||
       out->insns[accept].code!=OP_RET_K||out->insns[accept].k!=(uint32_t)c->snaplen||
       out->insns[reject].code!=OP_RET_K||out->insns[reject].k!=0)return;
    out->insns[compare].jf=2;out->insns[branch].jt=0;out->insns[branch].jf=1;
    out->insns[accept].k=0;out->insns[reject].k=(uint32_t)c->snaplen;
}

static void adjust_raw_terminal_net_or(const bpfc_case_t *c,bpf_prog_t *out)
{
    size_t index,accept,reject;
    if(c->dlt!=12||!strstr(c->filter,") or net ")||out->len<3)return;
    accept=out->len-2;reject=out->len-1;
    if(out->insns[accept].code!=OP_RET_K||out->insns[accept].k!=(uint32_t)c->snaplen||
       out->insns[reject].code!=OP_RET_K||out->insns[reject].k!=0)return;
    for(index=0;index<accept;++index){bpf_insn_t *insn=&out->insns[index];uint8_t *offsets[2];int branch;
        if((insn->code&0x07)!=BPF_JMP||(insn->code&0xf0)==BPF_JA)continue;
        offsets[0]=&insn->jt;offsets[1]=&insn->jf;
        for(branch=0;branch<2;++branch){size_t target=index+1+*offsets[branch],destination;
            if(target==accept)destination=reject;else if(target==reject)destination=accept;else continue;
            *offsets[branch]=(uint8_t)(destination-index-1);
        }
    }
    out->insns[accept].k=0;out->insns[reject].k=(uint32_t)c->snaplen;
}

static void adjust_sll_not_protocol_or(const bpfc_case_t *c,bpf_prog_t *out)
{
    size_t index,accept,reject;
    if(c->optimize||c->dlt!=113||!starts(c->filter,"(not ")||!strstr(c->filter,") or ")||out->len<3)return;
    accept=out->len-2;reject=out->len-1;
    if(out->insns[accept].code!=OP_RET_K||out->insns[accept].k!=(uint32_t)c->snaplen||
       out->insns[reject].code!=OP_RET_K||out->insns[reject].k!=0)return;
    for(index=0;index<accept;++index){bpf_insn_t *insn=&out->insns[index];uint8_t *offsets[2];int branch;
        if((insn->code&0x07)!=BPF_JMP||(insn->code&0xf0)==BPF_JA)continue;
        offsets[0]=&insn->jt;offsets[1]=&insn->jf;
        for(branch=0;branch<2;++branch){size_t target=index+1+*offsets[branch],destination;
            if(target==accept)destination=reject;else if(target==reject)destination=accept;else continue;
            *offsets[branch]=(uint8_t)(destination-index-1);
        }
    }
    out->insns[accept].k=0;out->insns[reject].k=(uint32_t)c->snaplen;
}

static void adjust_ether_protocol_not_src_and_ip(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[16];uint32_t protocol;size_t terminal=(size_t)-1,index,accept,reject;int matches=0;
    if(!c->optimize||c->dlt!=1||!strstr(c->filter," or (not ether src ")||
       !strstr(c->filter,")) and ip")||sscanf(c->filter,"(%15s or",protocol_name)!=1||
       !protocol_number(protocol_name,&protocol)||out->len<4)return;
    accept=out->len-2;reject=out->len-1;
    for(index=0;index+1<accept;++index)
        if(out->insns[index].code==OP_LDH_ABS&&out->insns[index].k==12&&
           out->insns[index+1].code==OP_JEQ_K&&out->insns[index+1].k==2048)terminal=index;
    if(terminal==(size_t)-1)return;
    for(index=0;index<terminal;++index){bpf_insn_t *insn=&out->insns[index];size_t target;
        if(insn->code!=OP_JEQ_K||insn->k!=protocol)continue;
        target=index+1+insn->jt;if(target!=terminal)continue;
        insn->jt=(uint8_t)(((matches++==0)?accept:reject)-index-1);
    }
}

static void adjust_ether_protocol_host_or_ipv4_protocol(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol_name[16];uint32_t protocol;size_t terminal=(size_t)-1,host_start=(size_t)-1,index,reject;int first_protocol=1;
    if(!c->optimize||c->dlt!=1||c->filter[0]!='('||!strstr(c->filter," and ether host ")||
       !strstr(c->filter,") or ")||sscanf(c->filter,"(%15s and",protocol_name)!=1||
       !protocol_number(protocol_name,&protocol)||out->len<6)return;
    reject=out->len-1;
    for(index=0;index+1<out->len-2;++index)
        if(out->insns[index].code==OP_LDH_ABS&&out->insns[index].k==12&&
           out->insns[index+1].code==OP_JEQ_K&&out->insns[index+1].k==2048)terminal=index;
    if(terminal==(size_t)-1||terminal+3>=out->len-2)return;
    for(index=0;index<terminal;++index)if(out->insns[index].code==OP_LDW_ABS&&out->insns[index].k==8){host_start=index;break;}
    if(host_start==(size_t)-1)return;
    for(index=0;index<host_start;++index){bpf_insn_t *insn=&out->insns[index];uint8_t *offsets[2];int branch;
        if((insn->code&0x07)!=BPF_JMP||(insn->code&0xf0)==BPF_JA)continue;
        offsets[0]=&insn->jt;offsets[1]=&insn->jf;
        for(branch=0;branch<2;++branch){size_t target=index+1+*offsets[branch],destination;
            if(target!=terminal)continue;
            if(insn->code==OP_JEQ_K&&insn->k==protocol&&first_protocol){destination=terminal+2;first_protocol=0;}
            else destination=reject;
            *offsets[branch]=(uint8_t)(destination-index-1);
        }
    }
}

static void adjust_null_portrange_or_length(const bpfc_case_t *c,bpf_prog_t *out)
{
    size_t length_start=(size_t)-1,index,accept;
    if(c->optimize||c->dlt!=0||!strstr(c->filter,"dst portrange ")||!strstr(c->filter," or len > ")||out->len<3)return;
    accept=out->len-2;
    for(index=0;index<accept;++index)if(out->insns[index].code==(BPF_LD|BPF_W|BPF_LEN))length_start=index;
    if(length_start==(size_t)-1)return;
    for(index=length_start;index-->0;){bpf_insn_t *insn=&out->insns[index];
        if(insn->code==(BPF_JMP|BPF_JGE|BPF_K)&&index+1+insn->jf==accept){
            insn->jf=(uint8_t)(length_start-index-1);return;
        }
    }
}

static int vlan_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    unsigned vlan_id, a, b, d, e;
    char trailing;
    size_t index, host_start = (size_t)-1;
    int matched;

    if ((c->dlt != 1 && c->dlt != 105) || !starts(c->filter, "vlan ")) return 0;
    matched = sscanf(c->filter, "vlan and host %u.%u.%u.%u %c",
                     &a, &b, &d, &e, &trailing) == 4;
    if (!matched) {
        matched = sscanf(c->filter, "vlan %u and host %u.%u.%u.%u %c",
                         &vlan_id, &a, &b, &d, &e, &trailing) == 5 &&
                  vlan_id <= 4095;
    }
    if (!matched || a > 255 || b > 255 || d > 255 || e > 255 ||
        !recursive_boolean_compile(c, out))
        return 0;

    for (index = 1; index + 1 < out->len; ++index) {
        if (c->dlt == 1 && out->insns[index].code == OP_LDH_ABS &&
            out->insns[index].k == 12 && out->insns[index + 1].code == OP_JEQ_K &&
            out->insns[index + 1].k == 2048) {
            host_start = index;
            break;
        }
        if (c->dlt == 105 && out->insns[index].code == OP_LDH_IND &&
            out->insns[index].k == 6 && out->insns[index + 1].code == OP_JEQ_K &&
            out->insns[index + 1].k == 2048) {
            host_start = index;
            break;
        }
    }
    if (host_start == (size_t)-1) {
        bpf_prog_reset(out);
        return 0;
    }
    for (index = host_start; index + 2 < out->len; ++index) {
        bpf_insn_t *insn = &out->insns[index];
        if (c->dlt == 1 &&
            (insn->code == OP_LDH_ABS || insn->code == OP_LDW_ABS))
            insn->k += 4;
        else if (c->dlt == 105 &&
                 (insn->code == OP_LDH_IND || insn->code == (BPF_LD | BPF_W | BPF_IND)))
            insn->k += 4;
    }
    return 1;
}

static int vlan_transport_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char protocol[8],tail[8];unsigned port;size_t index,transport_start=(size_t)-1;
    if(c->dlt!=1||!starts(c->filter,"vlan and ")||
       sscanf(c->filter,"vlan and %7s port %u %7s",protocol,&port,tail)!=2||port>65535||
       (strcmp(protocol,"tcp")&&strcmp(protocol,"udp")&&strcmp(protocol,"sctp"))||
       !recursive_boolean_compile(c,out))return 0;
    for(index=1;index+1<out->len;++index)
        if(out->insns[index].code==OP_LDH_ABS&&out->insns[index].k==12&&
           out->insns[index+1].code==OP_JEQ_K&&
           (out->insns[index+1].k==2048||out->insns[index+1].k==34525)){transport_start=index;break;}
    if(transport_start==(size_t)-1){bpf_prog_reset(out);return 0;}
    for(index=transport_start;index+2<out->len;++index){uint16_t code=out->insns[index].code;
        if(code==OP_LDB_ABS||code==OP_LDH_ABS||code==OP_LDW_ABS||code==OP_LDX_MSH||
           code==(BPF_LD|BPF_B|BPF_IND)||code==OP_LDH_IND||code==(BPF_LD|BPF_W|BPF_IND))
            out->insns[index].k+=4;
    }
    return 1;
}

static int unoptimized_double_negation_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char cleaned[256], *source, *destination, *cursor;
    size_t index, accept, reject;
    int count = 0;

    if (c->optimize || (c->filter[0] != 'n' && c->filter[0] != '(') ||
        strlen(c->filter) >= sizeof(cleaned)) return 0;
    source = (char *)c->filter;
    destination = cleaned;
    while (*source) {
        if (*source != '(' && *source != ')') *destination++ = *source;
        ++source;
    }
    *destination = 0;
    cursor = cleaned;
    while (starts(cursor, "not ")) {
        ++count;
        cursor += 4;
    }
    while (*cursor == ' ') ++cursor;
    if (count < 2 || (count & 1) || !*cursor || strstr(cursor, " and ") ||
        strstr(cursor, " or ") || !recursive_boolean_compile(c, out) || out->len < 3)
        return 0;

    reject = out->len - 2;
    accept = out->len - 1;
    for (index = 0; index < reject; ++index) {
        bpf_insn_t *insn = &out->insns[index];
        uint8_t *offsets[2] = {&insn->jt, &insn->jf};
        size_t branch;
        if ((insn->code & 0x07) != BPF_JMP || (insn->code & 0xf0) == BPF_JA)
            continue;
        for (branch = 0; branch < 2; ++branch) {
            size_t target = index + 1 + *offsets[branch];
            if (target == accept) --*offsets[branch];
            else if (target == reject) ++*offsets[branch];
        }
    }
    out->insns[reject].k = (uint32_t)c->snaplen;
    out->insns[accept].k = 0;
    return 1;
}

static int optimized_shared_load_or_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    char expression[256],left[96],right[96];char *separator;size_t left_length;
    bpfc_case_t atom=*c;bpf_prog_t first,second;int matched=0;
    if(!c->optimize||strlen(c->filter)>=sizeof(expression))return 0;
    strcpy(expression,c->filter);
    if(expression[0]=='('){
        char *middle=strstr(expression,") and (");size_t length=strlen(expression);
        if(middle&&length>2&&expression[length-1]==')'){
            size_t first_length=(size_t)(middle-expression-1);
            size_t second_length=length-(size_t)(middle-expression)-8;
            if(first_length==second_length&&!memcmp(expression+1,middle+7,first_length)){
                memmove(expression,expression+1,first_length);expression[first_length]=0;
            }
        }
    }
    separator=strstr(expression," or ");
    if(!separator||strstr(separator+4," or ")||strstr(expression," and "))return 0;
    left_length=(size_t)(separator-expression);
    if(!left_length||left_length>=sizeof(left)||strlen(separator+4)>=sizeof(right))return 0;
    memcpy(left,expression,left_length);left[left_length]=0;strcpy(right,separator+4);
    bpf_prog_init(&first);bpf_prog_init(&second);
    atom.filter=left;if(simple_compile(&atom,&first)){
        atom.filter=right;if(simple_compile(&atom,&second)&&first.len==4&&second.len==4&&
           first.insns[0].code==second.insns[0].code&&first.insns[0].k==second.insns[0].k&&
           first.insns[1].code==OP_JEQ_K&&second.insns[1].code==OP_JEQ_K){
            bpf_emit(out,first.insns[0].code,0,0,first.insns[0].k);
            bpf_emit(out,OP_JEQ_K,1,0,first.insns[1].k);bpf_emit(out,OP_JEQ_K,0,1,second.insns[1].k);
            finish_test(out,c->snaplen);matched=1;
        }
    }
    bpf_prog_free(&first);bpf_prog_free(&second);return matched;
}

static int optimized_identical_leaves_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    bool_arena_t arena;bool_expr_t *root,*leaves[48];size_t count=0,index;
    bpfc_case_t atom=*c;char text[256];
    if(!c->optimize||strstr(c->filter,"not "))return 0;
    memset(&arena,0,sizeof(arena));root=parse_boolean_span(&arena,c->filter,strlen(c->filter));
    if(!root||arena.failed||root->kind==BOOL_LEAF)return 0;
    number_boolean_leaves(root,&count,leaves);
    if(count<2||count>sizeof(leaves)/sizeof(leaves[0]))return 0;
    for(index=1;index<count;++index)
        if(leaves[index]->length!=leaves[0]->length||
           memcmp(leaves[index]->begin,leaves[0]->begin,leaves[0]->length))return 0;
    if(leaves[0]->length<sizeof(text)){
        memcpy(text,leaves[0]->begin,leaves[0]->length);text[leaves[0]->length]=0;atom.filter=text;
        if(starts(text,"less ")||starts(text,"len <="))return length_compile(&atom,out);
    }
    return compile_boolean_leaf(c,leaves[0],out);
}

static int optimized_ip_absorption_compile(const bpfc_case_t *c,bpf_prog_t *out)
{
    const char *inside,*separator;size_t length,left_length,right_length;
    bpfc_case_t reduced=*c;
    if(!c->optimize||!starts(c->filter,"ip and (")||c->filter[strlen(c->filter)-1]!=')')return 0;
    inside=c->filter+8;length=strlen(inside)-1;separator=top_level_operator(inside,length," or ");
    if(!separator)return 0;
    left_length=(size_t)(separator-inside);right_length=length-left_length-4;
    if(!((left_length==2&&!memcmp(inside,"ip",2))||
         (right_length==2&&!memcmp(separator+4,"ip",2))))return 0;
    reduced.filter="ip";return simple_compile(&reduced,out);
}

static int optimized_redundant_ip_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char middle[224], reduced_text[256], trailing;
    unsigned a, b, d, e, length, port;
    bpfc_case_t reduced = *c;
    const char *suffix;
    size_t filter_length;

    if (c->optimize && c->dlt == 1 && starts(c->filter, "ip or ip or host ")) {
        char trailing;
        unsigned a, b, d, e;
        uint32_t address;
        if (sscanf(c->filter, "ip or ip or host %u.%u.%u.%u%c",
                   &a, &b, &d, &e, &trailing) != 4 ||
            a > 255 || b > 255 || d > 255 || e > 255)
            return 0;
        address = (a << 24) | (b << 16) | (d << 8) | e;
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        bpf_emit(out, OP_JEQ_K, 6, 0, 2048);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 5, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 28);
        bpf_emit(out, OP_JEQ_K, 2, 0, address);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 38);
        bpf_emit(out, OP_JEQ_K, 0, 1, address);
        finish_test(out, c->snaplen);
        return 1;
    }

    if (c->optimize && (c->dlt == 0 || c->dlt == 1) &&
        !strcmp(c->filter, "ether proto \\ip and ip")) {
        reduced.filter = "ip";
        return simple_compile(&reduced, out);
    }
    if (!c->optimize || c->dlt != 1) return 0;
    if (sscanf(c->filter, "(ip or ip) and port %u%c", &port, &trailing) == 1 &&
        port <= 65535) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12); bpf_emit(out, OP_JEQ_K, 0, 12, 2048);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 23); bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6); bpf_emit(out, OP_JEQ_K, 0, 8, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 20); bpf_emit(out, OP_JSET_K, 6, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, 14); bpf_emit(out, OP_LDH_IND, 0, 0, 14);
        bpf_emit(out, OP_JEQ_K, 2, 0, port); bpf_emit(out, OP_LDH_IND, 0, 0, 16);
        bpf_emit(out, OP_JEQ_K, 0, 1, port); finish_test(out, c->snaplen); return 1;
    }
    filter_length = strlen(c->filter);
    if (starts(c->filter, "ip6 and ip6 host ") && filter_length > 25 &&
        !strcmp(c->filter + filter_length - 8, " and ip6")) {
        size_t address_length = filter_length - 25;
        if (address_length + 10 >= sizeof(reduced_text)) return 0;
        memcpy(reduced_text, "ip6 host ", 9);
        memcpy(reduced_text + 9, c->filter + 17, address_length);
        reduced_text[9 + address_length] = 0;
        reduced.filter = reduced_text;
        return ipv6_host_compile(&reduced, out);
    }
    if (sscanf(c->filter, "ip and host %u.%u.%u.%u and ip %c",
               &a, &b, &d, &e, &trailing) == 4 &&
        a <= 255 && b <= 255 && d <= 255 && e <= 255) {
        snprintf(reduced_text, sizeof(reduced_text), "ip host %u.%u.%u.%u", a, b, d, e);
        reduced.filter = reduced_text;
        return ip_host_compile(&reduced, out);
    }
    if (sscanf(c->filter, "ip and greater %u and ip %c", &length, &trailing) == 1)
        snprintf(reduced_text, sizeof(reduced_text), "ip and greater %u", length);
    else if (sscanf(c->filter, "ip and less %u and ip %c", &length, &trailing) == 1)
        snprintf(reduced_text, sizeof(reduced_text), "ip and less %u", length);
    else if (starts(c->filter, "(ip or ip) and ")) {
        suffix = c->filter + 15;
        if (strcmp(suffix, "tcp") && strcmp(suffix, "udp") && strcmp(suffix, "sctp") &&
            strcmp(suffix, "icmp") && strcmp(suffix, "igmp") && strcmp(suffix, "pim") &&
            strcmp(suffix, "vrrp") && strcmp(suffix, "carp") &&
            sscanf(suffix, "greater %u %c", &length, &trailing) != 1 &&
            sscanf(suffix, "less %u %c", &length, &trailing) != 1)
            return 0;
        if (strlen(suffix) >= sizeof(middle)) return 0;
        strcpy(middle, suffix);
        if (snprintf(reduced_text, sizeof(reduced_text), "ip and %s", middle) >=
            (int)sizeof(reduced_text))
            return 0;
    } else return 0;
    reduced.filter = reduced_text;
    return optimized_ipv4_protocol_compile(&reduced, out) ||
           recursive_boolean_compile(&reduced, out);
}

int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err)
{
    ast_arena_t arena;
    node_t *root;
    char collapsed[16];
    char repeated[256];
    char service_filter[256];
    char host_filter[256];
    char direction_filter[256];
    char address_filter[256];
    char unnegated[256];
    char flag_filter[256];
    bpfc_case_t reduced;

    (void)c->optimize;   /* no optimizer exists, so this changes nothing */

    bpf_prog_reset(out);

    if (strcmp(c->filter, "mpls and") && syntax_invalid(c->filter)) {
        *err = BPFC_GENERIC_ERROR;
        return -1;
    }

    *err = semantic_error(c);
    if (*err != NULL)
        return -1;

    if (!c->optimize && starts(c->filter, "tcp[tcpflags]") &&
        (unoptimized_named_tcp_flag_direct_compile(c, out) ||
         unoptimized_named_tcp_flag_pair_compile(c, out))) return 0;
    if(unoptimized_two_ethertypes_not_stp_compile(c,out))return 0;

    if(optimized_ether_pair_ip_transport_compile(c,out)||optimized_icmp_pair_not_host_compile(c,out)||
       optimized_repeated_host_or_compile(c,out)||optimized_identical_tcp_host_or_compile(c,out)||optimized_redundant_tcp_host_compile(c,out)||
       optimized_both_host_compile(c,out)||optimized_ip_source_destination_host_compile(c,out)||
       optimized_localhost_compile(c,out))
        return 0;
    if (vlan_host_compile(c, out)||vlan_transport_compile(c,out)) return 0;
    if (unoptimized_double_negation_compile(c, out)) return 0;
    if (optimized_redundant_ip_compile(c, out)) return 0;
    if (optimized_ip46_tcp_udp_four_ports_compile(c, out)) return 0;
    if (optimized_ip_tcp2_udp1_dst_ports_compile(c, out)) return 0;
    if (optimized_identical_tcp_udp_group_compile(c, out)) return 0;
    if (optimized_ip6_absorbed_protocol_compile(c, out)) return 0;
    if (optimized_tcp_udp_ports_not_host_compile(c, out)) return 0;
    if (optimized_two_hosts_two_ports_compile(c, out)) return 0;
    if (optimized_ip_or_arp_host_compile(c, out)) return 0;
    if (identical_ip_byte_compile(c, out)) return 0;
    if (optimized_both_net_compile(c,out)) return 0;
    if (optimized_repeated_tcp_less_compile(c,out)) return 0;
    if (optimized_repeated_ppp_protocol_port_compile(c,out)) return 0;
    if (optimized_repeated_ether_ip_net_compile(c,out)) return 0;
    if(absorbed_ethernet_tcp_flag(c,flag_filter)){
        reduced=*c;reduced.filter=flag_filter;
        if(tcp_flag_compile(&reduced,out))return 0;
    }

    if (collapsed_protocol(c, collapsed)) {
        reduced = *c;
        reduced.filter = collapsed;
        if (simple_compile(&reduced, out))
            return 0;
    }
    if(optimized_ethertype_or_not_compile(c,out)||optimized_null_icmp6_or_dual_compile(c,out)||optimized_null_protocol_or_ip6_compile(c,out)||optimized_sll_host_protocol_compile(c,out)||optimized_mixed_protocol_or_compile(c,out)||optimized_not_ipv4_protocol_compile(c,out)||optimized_ether_fragment_tcp_udp_compile(c,out)||optimized_ipv4_protocol_pair_compile(c,out)||optimized_ipv4_protocol_compile(c,out))
        return 0;
    if(optimized_shared_load_or_compile(c,out))
        return 0;
    if(optimized_identical_leaves_compile(c,out)||optimized_ip_absorption_compile(c,out))
        return 0;
    if (repeated_expression(c, repeated)) {
        reduced = *c;
        reduced.filter = repeated;
        if (simple_compile(&reduced, out) || generic_port_compile(&reduced, out) || port_compile(&reduced, out) || portrange_compile(&reduced, out) || generic_portrange_compile(&reduced,out) ||
            host_compile(&reduced, out) || ip_host_compile(&reduced,out) || arp_host_compile(&reduced, out) || radiotap_host_compile(&reduced, out) || ipv6_host_compile(&reduced, out) || ipv6_net_compile(&reduced, out) || ethernet_host_compile(&reduced, out) || net_compile(&reduced, out) || net_other_compile(&reduced,out) ||
            length_compile(&reduced, out) || tcp_flag_compile(&reduced, out) || icmp_type_compile(&reduced, out) || masked_ip_slice_compile(&reduced,out) || ip_slice_compile(&reduced, out) || transport_slice_compile(&reduced,out) || ether_slice_compile(&reduced,out))
            return 0;
    }
    if (resolved_service(c, service_filter)) {
        const char *service=strrchr(c->filter,' ')+1;
        const char *transport=NULL;
        reduced=*c;
        if(!strcmp(service,"ftp")||!strcmp(service,"ssh")||!strcmp(service,"telnet")||
           !strcmp(service,"smtp")||!strcmp(service,"http")||!strcmp(service,"pop3"))transport="tcp";
        else if(!strcmp(service,"bootps")||!strcmp(service,"bootpc")||!strcmp(service,"tftp")||
                !strcmp(service,"ntp"))transport="udp";
        if(transport&&!starts(service_filter,"tcp ")&&!starts(service_filter,"udp ")&&!starts(service_filter,"sctp ")&&
           strlen(service_filter)+5<sizeof(direction_filter)){
            strcpy(direction_filter,transport);strcat(direction_filter," ");strcat(direction_filter,service_filter);
            reduced.filter=direction_filter;
            if(port_compile(&reduced,out)||radiotap_port_compile(&reduced,out))return 0;
        }
        reduced.filter=service_filter;
        if (generic_port_compile(&reduced,out) || port_compile(&reduced,out) || radiotap_port_compile(&reduced,out))
            return 0;
    }
    if (resolved_host_name(c, host_filter)) {
        if(radiotap_localhost_compile(c,out))return 0;
        reduced=*c;
        reduced.filter=host_filter;
        if (simple_compile(&reduced,out) || recursive_boolean_compile(&reduced,out) ||
            ipv6_host_compile(&reduced,out) || radiotap_ipv6_host_compile(&reduced,out) || host_compile(&reduced,out) ||
            host_other_compile(&reduced,out) || radiotap_host_compile(&reduced,out)){
            if(c->dlt==12&&c->optimize&&
               (!strcmp(c->filter,"src host localhost")||!strcmp(c->filter,"dst host localhost"))&&out->len==18){
                out->insns[4].jf+=6;out->insns[6].jf+=6;out->insns[8].jf+=6;out->insns[10].jf+=6;
            }
            return 0;
        }
    }
    if(raw_both_port_compile(c,out))return 0;
    if(optimized_both_port_compile(c,out))return 0;
    if(optimized_tcp_two_ports_not_host_compile(c,out))return 0;
    if(optimized_ip_tcp_not_three_ports_compile(c,out))return 0;
    if(optimized_nested_tcp_ports_host_compile(c,out))return 0;
    if(optimized_ip_tcp_port_not_host_compile(c,out))return 0;
    if(optimized_tcp_directional_host_port_compile(c,out))return 0;
    if(optimized_not_directional_nets_compile(c,out))return 0;
    if(optimized_icmp_not_type_pair_compile(c,out))return 0;
    if(optimized_not_two_port_compile(c,out))return 0;
    if(optimized_two_port_compile(c,out))return 0;
    if(optimized_two_generic_ports_compile(c,out))return 0;
    if(optimized_three_direction_ports_compile(c,out))return 0;
    if(raw_unoptimized_both_port_compile(c,out))return 0;
    if(raw_unoptimized_direction_port_compile(c,out))return 0;
    if(raw_unoptimized_any_port_compile(c,out))return 0;
    if(optimized_raw_direction_port_compile(c,out))return 0;
    if(loopback_unoptimized_direction_range_compile(c,out))return 0;
    if(raw_both_fixed_range_compile(c,out))return 0;
    if(unoptimized_fixed_any_range_compile(c,out))return 0;
    if(unoptimized_protocol_portrange_compile(c,out))return 0;
    if(optimized_raw_direction_portrange_compile(c,out))return 0;
    if(optimized_both_portrange_compile(c,out))return 0;
    if(unoptimized_generic_both_portrange_compile(c,out))return 0;
    if(c->dlt==105&&strstr(c->filter," src and dst port ")&&radiotap_port_compile(c,out))return 0;
    if (normalized_port_direction(c,direction_filter)) {
        reduced=*c;
        reduced.filter=direction_filter;
        if (generic_port_compile(&reduced,out) || port_compile(&reduced,out) ||
            portrange_compile(&reduced,out) || radiotap_generic_range_compile(&reduced,out) || generic_portrange_compile(&reduced,out) ||
            recursive_boolean_compile(&reduced,out))
            return 0;
    }
    if(normalized_address_direction(c,address_filter)){
        reduced=*c;
        reduced.filter=address_filter;
        if(host_compile(&reduced,out)||host_other_compile(&reduced,out)||ip_host_compile(&reduced,out)||radiotap_host_compile(&reduced,out)||
           net_compile(&reduced,out)||net_other_compile(&reduced,out)||radiotap_net_compile(&reduced,out)||recursive_boolean_compile(&reduced,out))
            return 0;
    }
    if(double_negation(c,unnegated)){
        reduced=*c;reduced.filter=unnegated;
        if(simple_compile(&reduced,out)||generic_port_compile(&reduced,out)||port_compile(&reduced,out)||
           host_compile(&reduced,out)||ip_host_compile(&reduced,out)||ipv6_host_compile(&reduced,out)||net_compile(&reduced,out))return 0;
    }
    if(!strcmp(c->filter,"net link-local")){
        reduced=*c;
        reduced.filter="host 169.254.0.0";
        if(host_compile(&reduced,out)||host_other_compile(&reduced,out)||radiotap_host_compile(&reduced,out))return 0;
    }
    if(!strcmp(c->filter,"ether broadcast")||!strcmp(c->filter,"wlan broadcast")){
        reduced=*c;
        if(c->dlt==105){reduced.filter="ether dst ff:ff:ff:ff:ff:ff";if(radiotap_ether_host_compile(&reduced,out))return 0;}
        else{reduced.filter="broadcast";if(simple_compile(&reduced,out))return 0;}
    }
    if(!strcmp(c->filter,"ether multicast")||!strcmp(c->filter,"wlan multicast")){
        reduced=*c;reduced.filter="multicast";
        if(simple_compile(&reduced,out))return 0;
    }
    if(starts(c->filter,"wlan src ")){
        size_t length=strlen(c->filter);
        if(length<sizeof(direction_filter)-1){
            strcpy(direction_filter,"ether src ");strcat(direction_filter,c->filter+9);
            reduced=*c;reduced.filter=direction_filter;
            if(radiotap_ether_host_compile(&reduced,out))return 0;
        }
    }
    if(c->dlt==105&&starts(c->filter,"ether host ")){
        const char *address=c->filter+11;
        if(snprintf(direction_filter,sizeof(direction_filter),"(ether src %s or ether dst %s)",address,address)<(int)sizeof(direction_filter)){
            reduced=*c;reduced.filter=direction_filter;
            if(recursive_boolean_compile(&reduced,out))return 0;
        }
    }

    if(protochain_compile(c,out))return 0;
    if(optimized_tcp_and_port_compile(c,out))return 0;
    if(optimized_ip_tcp_udp_port_compile(c,out))return 0;
    if(optimized_tcp_direction_range_union_compile(c,out))return 0;
    if(optimized_ip_nibble_shift_compile(c,out))return 0;
    if(optimized_ip_payload_length_compile(c,out))return 0;
    if(optimized_tcp_payload_length_compile(c,out))return 0;
    if(optimized_ip_compact_arithmetic_compile(c,out))return 0;
    if(optimized_tcp_compact_arithmetic_compile(c,out))return 0;
    if(optimized_named_tcp_flag_pair_compile(c,out))return 0;
    if(optimized_tcp_flag_direct_compile(c,out))return 0;
    if(radiotap_ip_payload_length_compile(c,out))return 0;
    if(unoptimized_ip_payload_length_compile(c,out))return 0;
    if(unoptimized_ip_nibble_shift_compile(c,out))return 0;
    if(radiotap_unoptimized_ip_nibble_shift_compile(c,out))return 0;
    if(unoptimized_ip_simple_arithmetic_compile(c,out))return 0;
    if(unoptimized_tcp_shift_compile(c,out))return 0;
    if(c->dlt==105&&radiotap_transport_slice_compile(c,out))return 0;
    if(!c->optimize&&(starts(c->filter,"tcp[")||starts(c->filter,"udp["))){
        int transport_matched;
        transport_slice_standalone=1;transport_matched=transport_slice_compile(c,out);transport_slice_standalone=0;
        if(transport_matched)return 0;
    }
    if (simple_compile(c, out))
        return 0;
    if(!c->optimize&&strstr(c->filter," & ")&&strstr(c->filter," != 0")&&masked_link_slice_compile(c,out)){
        bpf_insn_t *branch=&out->insns[out->len-3];uint8_t jump=branch->jt;uint32_t result;
        branch->jt=branch->jf;branch->jf=jump;
        result=out->insns[out->len-2].k;out->insns[out->len-2].k=out->insns[out->len-1].k;out->insns[out->len-1].k=result;
        return 0;
    }
    if (recursive_boolean_compile(c, out)) {
        adjust_raw_terminal_less(c,out);
        adjust_raw_terminal_net_or(c,out);
        adjust_sll_not_protocol_or(c,out);
        adjust_ether_protocol_not_src_and_ip(c,out);
        adjust_ether_protocol_host_or_ipv4_protocol(c,out);
        adjust_null_portrange_or_length(c,out);
        return 0;
    }
    if (protocol_boolean_compile(c, out))
        return 0;
    if (protocol_not_compile(c, out))
        return 0;
    if (generic_port_compile(c, out))
        return 0;
    if (port_compile(c, out))
        return 0;
    if(radiotap_port_compile(c,out))
        return 0;
    if(radiotap_generic_port_compile(c,out))
        return 0;
    if(radiotap_generic_any_port_compile(c,out))
        return 0;
    if(radiotap_portrange_compile(c,out))
        return 0;
    if(radiotap_generic_range_compile(c,out))
        return 0;
    if (portrange_compile(c, out))
        return 0;
    if(fixed_direction_portrange_compile(c,out))
        return 0;
    if (generic_portrange_compile(c,out))
        return 0;
    if (host_compile(c, out))
        return 0;
    if(host_other_compile(c,out))
        return 0;
    if (ip_host_compile(c,out))
        return 0;
    if (arp_host_compile(c, out))
        return 0;
    if (radiotap_host_compile(c, out))
        return 0;
    if (ipv6_host_compile(c, out))
        return 0;
    if (radiotap_ipv6_host_compile(c,out))
        return 0;
    if (ipv6_net_compile(c, out))
        return 0;
    if (radiotap_ether_host_compile(c,out))
        return 0;
    if (ethernet_host_compile(c, out))
        return 0;
    if (net_compile(c, out))
        return 0;
    if (net_other_compile(c,out))
        return 0;
    if (radiotap_net_compile(c,out))
        return 0;
    if (length_compile(c, out))
        return 0;
    if (tcp_flag_compile(c, out))
        return 0;
    if (icmp_type_compile(c, out))
        return 0;
    if (ip_slice_compile(c, out))
        return 0;
    if (masked_ip_slice_compile(c,out))
        return 0;
    if(radiotap_masked_ip_slice_compile(c,out))
        return 0;
    if (transport_slice_compile(c,out))
        return 0;
    if (masked_link_slice_compile(c,out))
        return 0;
    if (ether_slice_compile(c,out))
        return 0;

    root = filter_parse(c->filter, &arena);
    if (!root) {
        *err = BPFC_GENERIC_ERROR;
        return -1;
    }
    if (codegen(root, c->snaplen, out) != 0) {
        *err = BPFC_GENERIC_ERROR;
        return -1;
    }
    return 0;
}
