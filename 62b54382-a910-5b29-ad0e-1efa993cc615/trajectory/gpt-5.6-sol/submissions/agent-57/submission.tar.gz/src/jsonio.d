src/jsonio.o: src/jsonio.c src/jsonio.h src/bpf_defs.h
src/jsonio.h:
src/bpf_defs.h:
