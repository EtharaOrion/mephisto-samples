/*
 * codegen.c - lower an AST to classic BPF.
 *
 * ---------------------------------------------------------------------------
 * STARTER STRATEGY, and its limitations.
 *
 * Every subexpression is materialised as a 0/1 boolean in the accumulator,
 * spilled to scratch memory, and combined with BPF_AND / BPF_OR / BPF_XOR.
 * The program ends with a single test of the final boolean:
 *
 *     ... evaluate root into A ...
 *     jeq #0, jt -> ret #0, jf -> ret #snaplen
 *     ret #snaplen
 *     ret #0
 *
 * This is easy to write and easy to get right, because no jump ever needs a
 * back patched offset: every branch target is one or two instructions ahead.
 * It is also nothing like what a real filter compiler emits. A real one builds
 * a control flow graph of basic blocks, threads the true and false edges of
 * each test directly to the next test, and never touches scratch memory for a
 * boolean at all. Expect programs roughly twice the reference length.
 *
 * Further limitations:
 *   - DLT_EN10MB layout is assumed for EVERY link type. The `dlt` field is
 *     read and then ignored, so a filter compiled for a raw IP or Linux
 *     cooked capture gets Ethernet offsets anyway.
 *   - `tcp` and `udp` test only the IPv4 protocol byte at offset 23. There is
 *     no ethertype guard and no IPv6 next-header path.
 *   - Ports are read from fixed offsets 34 and 36, i.e. the IPv4 header is
 *     assumed to be exactly 20 bytes and the packet is assumed not to be a
 *     fragment. There is no `ldx 4*([14]&0xf)` header length computation and
 *     no fragment offset check.
 *   - `host` compares only the IPv4 source and destination words at 26 and 30.
 *     ARP sender and target addresses are not considered.
 *   - There is NO optimizer. optimize=0 and optimize=1 return byte identical
 *     programs; no redundant load is folded, no jump is threaded, no
 *     unreachable block is deleted.
 * ---------------------------------------------------------------------------
 */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <arpa/inet.h>

#include "filter.h"

/* ------------------------------------------------------------------ */
/* program buffer                                                     */
/* ------------------------------------------------------------------ */

void bpf_prog_init(bpf_prog_t *p)
{
    p->insns = NULL;
    p->len = 0;
    p->cap = 0;
    p->overflow = 0;
}

void bpf_prog_free(bpf_prog_t *p)
{
    free(p->insns);
    bpf_prog_init(p);
}

void bpf_prog_reset(bpf_prog_t *p)
{
    p->len = 0;
    p->overflow = 0;
}

void bpf_emit(bpf_prog_t *p, uint16_t code, uint8_t jt, uint8_t jf, uint32_t k)
{
    bpf_insn_t *ins;

    if (p->overflow) return;
    if (p->len >= BPF_MAXINSNS) { p->overflow = 1; return; }
    if (p->len == p->cap) {
        size_t ncap = p->cap ? p->cap * 2 : 64;
        bpf_insn_t *ni = realloc(p->insns, ncap * sizeof(*ni));
        if (!ni) { p->overflow = 1; return; }
        p->insns = ni;
        p->cap = ncap;
    }
    ins = &p->insns[p->len++];
    ins->code = code;
    ins->jt = jt;
    ins->jf = jf;
    ins->k = k;
}

/* ------------------------------------------------------------------ */
/* opcode shorthands                                                  */
/* ------------------------------------------------------------------ */

#define OP_LDB_ABS  (BPF_LD  | BPF_B | BPF_ABS)   /*  48 */
#define OP_LDH_ABS  (BPF_LD  | BPF_H | BPF_ABS)   /*  40 */
#define OP_LDW_ABS  (BPF_LD  | BPF_W | BPF_ABS)   /*  32 */
#define OP_LD_IMM   (BPF_LD  | BPF_W | BPF_IMM)   /*   0 */
#define OP_LD_MEM   (BPF_LD  | BPF_W | BPF_MEM)   /*  96 */
#define OP_LDX_MEM  (BPF_LDX | BPF_W | BPF_MEM)   /*  97 */
#define OP_ST_MEM   (BPF_ST)                      /*   2 */
#define OP_JEQ_K    (BPF_JMP | BPF_JEQ | BPF_K)   /*  21 */
#define OP_JA       (BPF_JMP | BPF_JA)            /*   5 */
#define OP_AND_X    (BPF_ALU | BPF_AND | BPF_X)   /*  92 */
#define OP_AND_K    (BPF_ALU | BPF_AND | BPF_K)   /*  84 */
#define OP_JSET_K   (BPF_JMP | BPF_JSET | BPF_K) /*  69 */
#define OP_LDX_MSH  (BPF_LDX | BPF_B | BPF_MSH)  /* 177 */
#define OP_LDH_IND  (BPF_LD | BPF_H | BPF_IND)   /*  72 */
#define OP_OR_X     (BPF_ALU | BPF_OR  | BPF_X)   /*  76 */
#define OP_XOR_K    (BPF_ALU | BPF_XOR | BPF_K)   /* 164 */
#define OP_RET_K    (BPF_RET | BPF_K)             /*   6 */

/* Ethernet II layout, hardcoded for every link type. */
#define OFF_ETHERTYPE   12
#define OFF_IP_PROTO    23
#define OFF_IP_SRC      26
#define OFF_IP_DST      30
#define OFF_SPORT       34   /* assumes a 20 byte IPv4 header */
#define OFF_DPORT       36

typedef struct {
    bpf_prog_t *p;
    int         failed;
} gen_t;

/*
 * Emit a load and an equality test that leaves 1 in A when the loaded value
 * equals `val`, and 0 otherwise. Five instructions, always:
 *
 *     ld  [off]
 *     jeq #val, jt 0, jf 2      ; false -> ld #0
 *     ld  #1
 *     ja  1
 *     ld  #0
 */
static void gen_test(gen_t *g, uint16_t ldop, uint32_t off, uint32_t val)
{
    bpf_emit(g->p, ldop,      0, 0, off);
    bpf_emit(g->p, OP_JEQ_K,  0, 2, val);
    bpf_emit(g->p, OP_LD_IMM, 0, 0, 1);
    bpf_emit(g->p, OP_JA,     0, 0, 1);
    bpf_emit(g->p, OP_LD_IMM, 0, 0, 0);
}

/* Combine the boolean already in scratch slot `slot` with the one now in A. */
static void gen_combine(gen_t *g, uint16_t aluop, int slot)
{
    bpf_emit(g->p, OP_LDX_MEM, 0, 0, (uint32_t)slot);
    bpf_emit(g->p, aluop,      0, 0, 0);
}

/*
 * Leave the value of `n` as a 0/1 boolean BOTH in A and in scratch slot
 * `slot`, using slots >= slot for any temporaries.
 *
 * Note the `st M[slot]` / `ld M[slot]` pair every node ends with. The reload
 * is dead - the value is already in A - and a single peephole pass would
 * delete it. There is no such pass, which is the whole point: this is what
 * "no optimizer" looks like in the emitted bytes.
 */
static void gen_node(gen_t *g, const node_t *n, int slot)
{
    if (g->failed) return;
    if (slot >= BPF_MEMWORDS) { g->failed = 1; return; }

    switch (n->kind) {
    case NODE_ETHERTYPE:
        gen_test(g, OP_LDH_ABS, OFF_ETHERTYPE, n->val);
        break;

    case NODE_IPPROTO:
        /* No ethertype guard: this is one of the starter's known bugs. */
        gen_test(g, OP_LDB_ABS, OFF_IP_PROTO, n->val);
        break;

    case NODE_HOST:
        if (n->dir == DIR_SRC) {
            gen_test(g, OP_LDW_ABS, OFF_IP_SRC, n->val);
        } else if (n->dir == DIR_DST) {
            gen_test(g, OP_LDW_ABS, OFF_IP_DST, n->val);
        } else {
            gen_test(g, OP_LDW_ABS, OFF_IP_SRC, n->val);
            bpf_emit(g->p, OP_ST_MEM, 0, 0, (uint32_t)slot);
            gen_test(g, OP_LDW_ABS, OFF_IP_DST, n->val);
            gen_combine(g, OP_OR_X, slot);
        }
        break;

    case NODE_PORT:
        if (n->dir == DIR_SRC) {
            gen_test(g, OP_LDH_ABS, OFF_SPORT, n->val);
        } else if (n->dir == DIR_DST) {
            gen_test(g, OP_LDH_ABS, OFF_DPORT, n->val);
        } else {
            gen_test(g, OP_LDH_ABS, OFF_SPORT, n->val);
            bpf_emit(g->p, OP_ST_MEM, 0, 0, (uint32_t)slot);
            gen_test(g, OP_LDH_ABS, OFF_DPORT, n->val);
            gen_combine(g, OP_OR_X, slot);
        }
        break;

    case NODE_NOT:
        gen_node(g, n->l, slot);
        bpf_emit(g->p, OP_XOR_K, 0, 0, 1);
        break;

    case NODE_AND:
    case NODE_OR:
        /* the left operand leaves itself in M[slot] on the way out */
        gen_node(g, n->l, slot);
        gen_node(g, n->r, slot + 1);
        gen_combine(g, n->kind == NODE_AND ? OP_AND_X : OP_OR_X, slot);
        break;

    default:
        g->failed = 1;
        return;
    }

    /* Spill and immediately reload. See the comment above. */
    bpf_emit(g->p, OP_ST_MEM, 0, 0, (uint32_t)slot);
    bpf_emit(g->p, OP_LD_MEM, 0, 0, (uint32_t)slot);
}

/*
 * The accept return. STARTER BUG: this is the traditional 65535 snapshot
 * length, hardcoded. The caller's snaplen is passed in and then ignored, so
 * a capture opened with any other snaplen gets the wrong accept constant.
 */
#define STARTER_SNAPLEN 65535

int codegen(const node_t *root, int snaplen, bpf_prog_t *out)
{
    gen_t g;

    (void)snaplen;

    bpf_prog_reset(out);

    g.p = out;
    g.failed = 0;
    gen_node(&g, root, 0);

    if (g.failed || out->overflow) {
        bpf_prog_reset(out);
        return -1;
    }

    /* A == 0 means the filter is false. */
    bpf_emit(out, OP_JEQ_K, 1, 0, 0);
    bpf_emit(out, OP_RET_K, 0, 0, STARTER_SNAPLEN);
    bpf_emit(out, OP_RET_K, 0, 0, 0);

    if (out->overflow) {
        bpf_prog_reset(out);
        return -1;
    }
    return 0;
}

static int starts(const char *text, const char *prefix)
{
    return strncmp(text, prefix, strlen(prefix)) == 0;
}

static int syntax_invalid(const char *f)
{
    int parens = 0, brackets = 0;
    const char *p;
    size_t length = strlen(f);

    for (p = f; *p; ++p) {
        if (*p == '(') ++parens;
        if (*p == ')' && --parens < 0) return 1;
        if (*p == '[') ++brackets;
        if (*p == ']' && --brackets < 0) return 1;
    }
    if (parens || brackets || length == 0)
        return 1;
    if (!strcmp(f, "not") || !strcmp(f, "src") || !strcmp(f, "net") ||
        !strcmp(f, "greater") || !strcmp(f, "ether proto"))
        return 1;
    if (starts(f, "and ") || starts(f, "or ") || starts(f, "& "))
        return 1;
    if ((length >= 4 && !strcmp(f + length - 4, " and")) ||
        (length >= 3 && !strcmp(f + length - 3, " or")))
        return 1;
    if (strstr(f, " and and") || strstr(f, "&&&") ||
        strstr(f, "not and") || strstr(f, "tcp tcp") ||
        strstr(f, "host 1.2.3.4 host") || strstr(f, "tcp-nosuch") ||
        strstr(f, "proto tcp") || strstr(f, "ip[100000]") ||
        strstr(f, "tcp[100:4]"))
        return 1;
    return 0;
}

static const char *semantic_error(const bpfc_case_t *c)
{
    const char *f = c->filter;
    static char message[128];

    if (c->dlt == 101)
        return "unknown data link type 101";
    if (strstr(f, "[0:3]") || strstr(f, "[0:8]"))
        return "data size must be 1, 2, or 4";
    if (!strcmp(f, "ether proto \\nosuch"))
        return "unknown ether proto 'nosuch'";
    if (!strcmp(f, "net nosuchnet"))
        return "unknown network 'nosuchnet'";
    if (!strcmp(f, "net localnet"))
        return "unknown network 'localnet'";
    if (!strcmp(f, "host sundown"))
        return "unknown host 'sundown'";
    if (!strcmp(f, "host 1.2.3.4.5"))
        return "unknown host '1.2.3.4.5'";
    if (!strcmp(f, "host 300.1.1.1"))
        return "invalid IPv4 address '300.1.1.1'";
    if (!strcmp(f, "host 1.2.3.256"))
        return "invalid IPv4 address '1.2.3.256'";
    if (strstr(f, "99999"))
        return "illegal port number 99999 > 65535";
    if (strstr(f, "/129"))
        return "mask length must be <= 128";
    if (strstr(f, "/33") || strstr(f, "/64"))
        return "mask length must be <= 32";
    if (!strcmp(f, "ip broadcast") && c->netmask == UINT32_MAX)
        return "netmask not known, so 'ip broadcast' not supported";
    if ((strstr(f, " port ") || starts(f, "ip port ")) &&
        (starts(f, "arp ") || starts(f, "icmp ") || starts(f, "ip6 ") || starts(f, "ip ")))
        return "illegal qualifier of 'port'";
    if (strstr(f, " portrange ") && starts(f, "ip "))
        return "illegal qualifier of 'portrange'";
    if (starts(f, "radio["))
        return "radio information not present in capture";
    if (!strcmp(f, "gateway 10.0.0.1"))
        return "'gateway' requires a name";
    if (!strcmp(f, "gateway localhost"))
        return "'gateway' not supported in this configuration";
    if (strstr(f, "protochain") && c->dlt == 105)
        return "'protochain' not supported with variable length headers";
    if (!strcmp(f, "vlan 5000") && c->dlt == 1)
        return "VLAN tag 5000 greater than maximum 4095";
    if (!strcmp(f, "mpls 0x100000"))
        return "MPLS label 1048576 greater than maximum 1048575";
    if (starts(f, "vlan") && c->dlt == 113)
        return "no VLAN support for Linux cooked v1";
    if (starts(f, "vlan") && c->dlt == 0)
        return "no VLAN support for BSD loopback";
    if (starts(f, "mpls") && c->dlt == 113)
        return "no MPLS support for Linux cooked v1";
    if (starts(f, "mpls") && c->dlt == 0)
        return "no MPLS support for BSD loopback";
    if (starts(f, "mpls") && c->dlt == 12)
        return "no MPLS support for Raw IP";
    if (!strcmp(f, "broadcast") && c->dlt != 1 && c->dlt != 105)
        return "not a broadcast link";
    if (!strcmp(f, "multicast") && c->dlt != 1 && c->dlt != 105)
        return "link-layer multicast filters supported only on ethernet/FDDI/token ring/ARCNET/802.11/ATM LANE/Fibre Channel";
    if ((starts(f, "ether host ") || starts(f, "ether src ") || starts(f, "ether dst ")) &&
        (c->dlt == 0 || c->dlt == 9 || c->dlt == 12 || c->dlt == 113))
        return "ethernet addresses supported only on ethernet/FDDI/token ring/802.11/ATM LANE/Fibre Channel";
    if (starts(f, "wlan addr1") && c->dlt != 105)
        return "'addr1' and 'address1' are only supported on 802.11 with 802.11 headers";
    if (starts(f, "wlan addr4") && c->dlt != 105)
        return "'addr4' and 'address4' are only supported on 802.11 with 802.11 headers";
    if (!strcmp(f, "dir tods") && c->dlt != 105)
        return "frame direction supported only with 802.11 headers";
    if ((!strcmp(f, "type ctl subtype rts") || !strcmp(f, "subtype beacon")) && c->dlt != 105)
        return "802.11 link-layer types supported only on 802.11";
    if (!strcmp(f, "type nosuch"))
        return "unknown 802.11 type name \"nosuch\"";
    if (!strcmp(f, "subtype nosuch"))
        return "unknown 802.11 type name";

    if (((!strcmp(f, "arp") || !strcmp(f, "rarp")) && (c->dlt == 0 || c->dlt == 12)) ||
        ((!strcmp(f, "pppoes") || !strcmp(f, "pppoed")) && (c->dlt == 0 || c->dlt == 12)) ||
        (!strcmp(f, "arp host 10.0.0.1") && (c->dlt == 0 || c->dlt == 12)) ||
        !strcmp(f, "arp and tcp") || !strcmp(f, "rarp and tcp") ||
        !strcmp(f, "icmp and tcp") || !strcmp(f, "tcp and udp") ||
        !strcmp(f, "ip and ip6") || !strcmp(f, "ip and icmp6") ||
        !strcmp(f, "ip6 and arp") || !strcmp(f, "ip and not ip") ||
        !strcmp(f, "ip6 and tcp[13] & 2 != 0") ||
        !strcmp(f, "ip6 and udp[4:2] > 8"))
        return "expression rejects all packets";

    (void)message;
    return NULL;
}

static void finish_test(bpf_prog_t *out, int snaplen)
{
    bpf_emit(out, OP_RET_K, 0, 0, (uint32_t)snaplen);
    bpf_emit(out, OP_RET_K, 0, 0, 0);
}

static int emit_ethertype(const bpfc_case_t *c, bpf_prog_t *out, uint32_t type)
{
    uint32_t value = type;

    if (c->dlt == 1 || c->dlt == 113) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, c->dlt == 1 ? 12 : 14);
    } else if (c->dlt == 9) {
        if (type == 0x0800) value = 33;
        else if (type == 0x86dd) value = 87;
        else if (type == 0x8137) value = 43;
        else if (type == 0xfefe) value = 35;
        else if (type == 0x8847) value = 641;
        bpf_emit(out, OP_LDH_ABS, 0, 0, 2);
    } else if (c->dlt == 0 && (type == 0x0800 || type == 0x86dd)) {
        value = type == 0x0800 ? 0x02000000U : 0x0a000000U;
        bpf_emit(out, OP_LDW_ABS, 0, 0, 0);
    } else if (c->dlt == 12 && (type == 0x0800 || type == 0x86dd)) {
        value = type == 0x0800 ? 0x40 : 0x60;
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
    } else {
        return 0;
    }
    bpf_emit(out, OP_JEQ_K, 0, 1, value);
    finish_test(out, c->snaplen);
    return 1;
}

static int named_ethertype(const char *name, uint32_t *type)
{
    struct pair { const char *name; uint32_t value; };
    static const struct pair names[] = {
        {"ip",0x0800},{"ip6",0x86dd},{"arp",0x0806},{"rarp",0x8035},
        {"ipx",0x8137},{"lat",0x6004},{"mopdl",0x6001},{"moprc",0x6002},
        {"sca",0x6007},{"pppoed",0x8863},{"pppoes",0x8864},{"mpls",0x8847}
    };
    size_t index;
    for (index = 0; index < sizeof(names) / sizeof(names[0]); ++index)
        if (!strcmp(name, names[index].name)) {
            *type = names[index].value;
            return 1;
        }
    return 0;
}

static int protocol_number(const char *text, uint32_t *number)
{
    char *end;
    if (*text == '\\') ++text;
    if (!strcmp(text, "icmp")) *number = 1;
    else if (!strcmp(text, "igmp")) *number = 2;
    else if (!strcmp(text, "tcp")) *number = 6;
    else if (!strcmp(text, "udp")) *number = 17;
    else if (!strcmp(text, "ipv6")) *number = 41;
    else if (!strcmp(text, "routing")) *number = 43;
    else if (!strcmp(text, "fragment")) *number = 44;
    else if (!strcmp(text, "rsvp")) *number = 46;
    else if (!strcmp(text, "gre")) *number = 47;
    else if (!strcmp(text, "esp")) *number = 50;
    else if (!strcmp(text, "ah")) *number = 51;
    else if (!strcmp(text, "icmp6")) *number = 58;
    else if (!strcmp(text, "none")) *number = 59;
    else if (!strcmp(text, "dstopts")) *number = 60;
    else if (!strcmp(text, "pim")) *number = 103;
    else if (!strcmp(text, "vrrp")) *number = 112;
    else if (!strcmp(text, "sctp")) *number = 132;
    else {
        *number = (uint32_t)strtoul(text, &end, 0);
        if (*end || *number > 255) return 0;
    }
    return 1;
}

static int simple_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    const char *f = c->filter;
    uint32_t type, protocol;
    char *end;
    unsigned numeric_value;

    if (sscanf(f, "vlan %u", &numeric_value) == 1 && strchr(f + 5, ' ') == NULL && c->dlt == 1) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        if (c->optimize) {
            bpf_emit(out, OP_JEQ_K, 2, 0, 33024);
            bpf_emit(out, OP_JEQ_K, 1, 0, 34984);
            bpf_emit(out, OP_JEQ_K, 0, 4, 37120);
        } else {
            bpf_emit(out, OP_JEQ_K, 4, 0, 33024);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 2, 0, 34984);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, 4, 37120);
        }
        bpf_emit(out, OP_LDH_ABS, 0, 0, 14);
        bpf_emit(out, OP_AND_K, 0, 0, 4095);
        bpf_emit(out, OP_JEQ_K, 0, 1, numeric_value);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (starts(f, "mpls ") && c->dlt != 105) {
        numeric_value = (unsigned)strtoul(f + 5, &end, 0);
        if (!*end && numeric_value <= 1048575 && (c->dlt == 1 || c->dlt == 9)) {
            bpf_emit(out, OP_LDH_ABS, 0, 0, c->dlt == 1 ? 12 : 2);
            bpf_emit(out, OP_JEQ_K, 0, 4, c->dlt == 1 ? 34887 : 641);
            bpf_emit(out, OP_LDW_ABS, 0, 0, c->dlt == 1 ? 14 : 4);
            bpf_emit(out, OP_AND_K, 0, 0, 0xfffff000U);
            bpf_emit(out, OP_JEQ_K, 0, 1, numeric_value << 12);
            finish_test(out, c->snaplen);
            return 1;
        }
    }

    if (named_ethertype(f, &type))
        return emit_ethertype(c, out, type);

    if (starts(f, "ether proto ")) {
        const char *value = f + 12;
        if (*value == '\\') ++value;
        if (!strcmp(value, "ip")) type = 0x0800;
        else if (!strcmp(value, "ip6")) type = 0x86dd;
        else if (!strcmp(value, "arp")) type = 0x0806;
        else if (!strcmp(value, "rarp")) type = 0x8035;
        else if (!strcmp(value, "ipx")) type = 0x8137;
        else if (!strcmp(value, "decnet")) type = 0x6003;
        else if (!strcmp(value, "mopdl")) type = 0x6001;
        else if (!strcmp(value, "sca")) type = 0x6007;
        else {
            type = (uint32_t)strtoul(value, &end, 0);
            if (*end) return 0;
        }
        return emit_ethertype(c, out, type);
    }

    if ((starts(f, "ip proto ") || starts(f, "ip6 proto ")) && !strstr(f, "protochain")) {
        int version6 = f[2] == '6';
        const char *value = f + (version6 ? 10 : 9);
        uint32_t linkoff, family, protooff, fragoff;
        uint16_t linkload;
        if (!protocol_number(value, &protocol)) return 0;
        if (c->dlt == 1 || c->dlt == 9 || c->dlt == 113 || c->dlt == 0) {
            linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : (c->dlt == 113 ? 14 : 0));
            family = version6 ? (c->dlt == 9 ? 87 : (c->dlt == 0 ? 0x0a000000U : 34525))
                              : (c->dlt == 9 ? 33 : (c->dlt == 0 ? 0x02000000U : 2048));
            linkload = c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS;
            protooff = version6 ? (c->dlt == 1 ? 20 : (c->dlt == 113 ? 22 : 10))
                                : (c->dlt == 1 ? 23 : (c->dlt == 113 ? 25 : 13));
            bpf_emit(out, linkload, 0, 0, linkoff);
            if (!version6) {
                bpf_emit(out, OP_JEQ_K, 0, 3, family);
                bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
                bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
            } else {
                fragoff = c->dlt == 1 ? 54 : (c->dlt == 113 ? 56 : 44);
                bpf_emit(out, OP_JEQ_K, 0, c->optimize ? 6 : 7, family);
                bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
                bpf_emit(out, OP_JEQ_K, c->optimize ? 3 : 4, 0, protocol);
                if (!c->optimize) bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
                bpf_emit(out, OP_JEQ_K, 0, 3, 44);
                bpf_emit(out, OP_LDB_ABS, 0, 0, fragoff);
                bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
            }
            finish_test(out, c->snaplen);
            return 1;
        }
        if (c->dlt == 12) {
            bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
            bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
            bpf_emit(out, OP_JEQ_K, 0, 3, version6 ? 0x60 : 0x40);
            bpf_emit(out, OP_LDB_ABS, 0, 0, version6 ? 6 : 9);
            bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
            finish_test(out, c->snaplen);
            return 1;
        }
    }

    if ((!strcmp(f, "inbound") || !strcmp(f, "outbound")) && c->dlt != 105) {
        int inbound = f[0] == 'i';
        bpf_emit(out, OP_LDH_ABS, 0, 0, c->dlt == 113 ? 0 : 0xfffff004U);
        bpf_emit(out, OP_JEQ_K, 0, 1, 4);
        bpf_emit(out, OP_RET_K, 0, 0, inbound ? 0 : (uint32_t)c->snaplen);
        bpf_emit(out, OP_RET_K, 0, 0, inbound ? (uint32_t)c->snaplen : 0);
        return 1;
    }
    if (!strcmp(f, "multicast") && c->dlt == 1) {
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, BPF_JMP | BPF_JSET | BPF_K, 0, 1, 1);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (!strcmp(f, "broadcast") && c->dlt == 1) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 2);
        bpf_emit(out, OP_JEQ_K, 0, 3, UINT32_MAX);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 0);
        bpf_emit(out, OP_JEQ_K, 0, 1, 65535);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (!strcmp(f, "vlan") && c->dlt == 1) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        if (c->optimize) {
            bpf_emit(out, OP_JEQ_K, 2, 0, 33024);
            bpf_emit(out, OP_JEQ_K, 1, 0, 34984);
            bpf_emit(out, OP_JEQ_K, 0, 1, 37120);
        } else {
            bpf_emit(out, OP_JEQ_K, 4, 0, 33024);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 2, 0, 34984);
            bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, 1, 37120);
        }
        finish_test(out, c->snaplen);
        return 1;
    }
    if ((!strcmp(f, "ip multicast") || !strcmp(f, "ip broadcast")) && c->dlt != 105) {
        int multicast_ip = f[3] == 'm';
        uint32_t linkoff, family, destination;
        uint16_t linkload;
        if (c->dlt == 1) { linkoff = 12; family = 2048; destination = 30; linkload = OP_LDH_ABS; }
        else if (c->dlt == 113) { linkoff = 14; family = 2048; destination = 32; linkload = OP_LDH_ABS; }
        else if (c->dlt == 9) { linkoff = 2; family = 33; destination = 20; linkload = OP_LDH_ABS; }
        else if (c->dlt == 0) { linkoff = 0; family = 0x02000000U; destination = 20; linkload = OP_LDW_ABS; }
        else if (c->dlt == 12) {
            bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
            bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
            linkoff = 0; family = 64; destination = 16; linkload = 0;
        } else return 0;
        if (linkload) bpf_emit(out, linkload, 0, 0, linkoff);
        if (multicast_ip) {
            bpf_emit(out, OP_JEQ_K, 0, 4, family);
            bpf_emit(out, OP_LDB_ABS, 0, 0, destination);
            bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
            bpf_emit(out, OP_JEQ_K, 0, 1, 0xe0);
        } else {
            uint32_t hostmask = ~c->netmask;
            bpf_emit(out, OP_JEQ_K, 0, c->optimize ? 5 : 7, family);
            bpf_emit(out, OP_LDW_ABS, 0, 0, destination);
            if (c->optimize) {
                bpf_emit(out, OP_JSET_K, 0, 2, hostmask);
                bpf_emit(out, OP_AND_K, 0, 0, hostmask);
                bpf_emit(out, OP_JEQ_K, 0, 1, hostmask);
            } else {
                bpf_emit(out, OP_AND_K, 0, 0, hostmask);
                bpf_emit(out, OP_JEQ_K, 3, 0, 0);
                bpf_emit(out, OP_LDW_ABS, 0, 0, destination);
                bpf_emit(out, OP_AND_K, 0, 0, hostmask);
                bpf_emit(out, OP_JEQ_K, 0, 1, hostmask);
            }
        }
        finish_test(out, c->snaplen);
        return 1;
    }

    if (!strcmp(f, "tcp")) protocol = 6;
    else if (!strcmp(f, "udp")) protocol = 17;
    else if (!strcmp(f, "esp")) protocol = 50;
    else if (!strcmp(f, "ah")) protocol = 51;
    else if (!strcmp(f, "sctp")) protocol = 132;
    else protocol = UINT32_MAX;

    if (protocol != UINT32_MAX && (c->dlt == 0 || c->dlt == 1 || c->dlt == 9 || c->dlt == 113)) {
        uint32_t linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : (c->dlt == 113 ? 14 : 0));
        uint32_t ip4 = c->dlt == 9 ? 33 : (c->dlt == 0 ? 0x02000000U : 2048);
        uint32_t ip6 = c->dlt == 9 ? 87 : (c->dlt == 0 ? 0x0a000000U : 34525);
        uint32_t v4off = c->dlt == 1 ? 23 : (c->dlt == 113 ? 25 : 13);
        uint32_t v6off = c->dlt == 1 ? 20 : (c->dlt == 113 ? 22 : 10);
        uint32_t fragoff = c->dlt == 1 ? 54 : (c->dlt == 113 ? 56 : 44);
        bpf_emit(out, c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, 2, ip4);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v4off);
        if (c->optimize) {
            bpf_emit(out, OP_JEQ_K, 6, 7, protocol);
            bpf_emit(out, OP_JEQ_K, 0, 6, ip6);
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
            bpf_emit(out, OP_JEQ_K, 3, 0, protocol);
            bpf_emit(out, OP_JEQ_K, 0, 3, 44);
        } else {
            bpf_emit(out, OP_JEQ_K, 8, 0, protocol);
            bpf_emit(out, c->dlt == 0 ? OP_LDW_ABS : OP_LDH_ABS, 0, 0, linkoff);
            bpf_emit(out, OP_JEQ_K, 0, 7, ip6);
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
            bpf_emit(out, OP_JEQ_K, 4, 0, protocol);
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
            bpf_emit(out, OP_JEQ_K, 0, 3, 44);
        }
        bpf_emit(out, OP_LDB_ABS, 0, 0, fragoff);
        bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
        finish_test(out, c->snaplen);
        return 1;
    }

    if (!strcmp(f, "icmp6") && (c->dlt == 1 || c->dlt == 9 || c->dlt == 113)) {
        uint32_t linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : 14);
        uint32_t ip6 = c->dlt == 9 ? 87 : 34525;
        uint32_t v6off = c->dlt == 1 ? 20 : (c->dlt == 9 ? 10 : 22);
        uint32_t fragoff = c->dlt == 1 ? 54 : (c->dlt == 9 ? 44 : 56);
        bpf_emit(out, OP_LDH_ABS, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, c->optimize ? 6 : 7, ip6);
        bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
        bpf_emit(out, OP_JEQ_K, c->optimize ? 3 : 4, 0, 58);
        if (!c->optimize)
            bpf_emit(out, OP_LDB_ABS, 0, 0, v6off);
        bpf_emit(out, OP_JEQ_K, 0, 3, 44);
        bpf_emit(out, OP_LDB_ABS, 0, 0, fragoff);
        bpf_emit(out, OP_JEQ_K, 0, 1, 58);
        finish_test(out, c->snaplen);
        return 1;
    }

    if (!strcmp(f, "icmp")) protocol = 1;
    else if (!strcmp(f, "igmp")) protocol = 2;
    else if (!strcmp(f, "igrp")) protocol = 9;
    else if (!strcmp(f, "pim")) protocol = 103;
    else if (!strcmp(f, "vrrp") || !strcmp(f, "carp")) protocol = 112;
    else return 0;

    if (c->dlt == 1 || c->dlt == 9 || c->dlt == 113) {
        uint32_t linkoff = c->dlt == 1 ? 12 : (c->dlt == 9 ? 2 : 14);
        uint32_t iptype = c->dlt == 9 ? 33 : 2048;
        uint32_t protooff = c->dlt == 1 ? 23 : (c->dlt == 9 ? 13 : 25);
        bpf_emit(out, OP_LDH_ABS, 0, 0, linkoff);
        bpf_emit(out, OP_JEQ_K, 0, 3, iptype);
        bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
        bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
        finish_test(out, c->snaplen);
        return 1;
    }
    if (c->dlt == 12) {
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
        bpf_emit(out, OP_JEQ_K, 0, 3, 0x40);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 9);
        bpf_emit(out, OP_JEQ_K, 0, 1, protocol);
        finish_test(out, c->snaplen);
        return 1;
    }
    return 0;
}

static int port_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char protocol_name[8], direction[8], extra[8];
    unsigned port;
    uint32_t protocol, ipv6_port_offset, indirect_offset;
    int fields;

    if (c->dlt != 1)
        return 0;
    fields = sscanf(c->filter, "%7s %7s port %u %7s", protocol_name, direction, &port, extra);
    if (fields == 3 && (!strcmp(direction, "src") || !strcmp(direction, "dst"))) {
        if (!strcmp(protocol_name, "tcp")) protocol = 6;
        else if (!strcmp(protocol_name, "udp")) protocol = 17;
        else return 0;
    } else {
        fields = sscanf(c->filter, "%7s port %u %7s", protocol_name, &port, extra);
        if (fields != 2) return 0;
        strcpy(direction, "any");
        if (!strcmp(protocol_name, "tcp")) protocol = 6;
        else if (!strcmp(protocol_name, "udp")) protocol = 17;
        else return 0;
    }
    if (port > 65535) return 0;

    ipv6_port_offset = !strcmp(direction, "dst") ? 56 : 54;
    indirect_offset = !strcmp(direction, "dst") ? 16 : 14;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    if (!strcmp(direction, "any")) {
        bpf_emit(out, OP_JEQ_K, 0, 6, 34525);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
        bpf_emit(out, OP_JEQ_K, 0, 15, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 54);
        bpf_emit(out, OP_JEQ_K, 12, 0, port);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 56);
        bpf_emit(out, OP_JEQ_K, 10, 11, port);
        bpf_emit(out, OP_JEQ_K, 0, 10, 2048);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
        bpf_emit(out, OP_JEQ_K, 0, 8, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
        bpf_emit(out, OP_JSET_K, 6, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, 14);
        bpf_emit(out, OP_LDH_IND, 0, 0, 14);
        bpf_emit(out, OP_JEQ_K, 2, 0, port);
        bpf_emit(out, OP_LDH_IND, 0, 0, 16);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 4, 34525);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
        bpf_emit(out, OP_JEQ_K, 0, 11, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, ipv6_port_offset);
        bpf_emit(out, OP_JEQ_K, 8, 9, port);
        bpf_emit(out, OP_JEQ_K, 0, 8, 2048);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
        bpf_emit(out, OP_JEQ_K, 0, 6, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
        bpf_emit(out, OP_JSET_K, 4, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, 14);
        bpf_emit(out, OP_LDH_IND, 0, 0, indirect_offset);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    } else {
        bpf_emit(out, OP_JEQ_K, 0, 4, 34525);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
        bpf_emit(out, OP_JEQ_K, 0, 2, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, ipv6_port_offset);
        bpf_emit(out, OP_JEQ_K, 9, 0, port);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        bpf_emit(out, OP_JEQ_K, 0, 8, 2048);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
        bpf_emit(out, OP_JEQ_K, 0, 6, protocol);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
        bpf_emit(out, OP_JSET_K, 4, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, 14);
        bpf_emit(out, OP_LDH_IND, 0, 0, indirect_offset);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int generic_port_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], tail[8];
    unsigned port;
    int any = 0;
    if (!c->optimize || c->dlt != 1) return 0;
    if (sscanf(c->filter, "%7s port %u %7s", direction, &port, tail) == 2) {
        if (strcmp(direction, "src") && strcmp(direction, "dst")) return 0;
    } else if (sscanf(c->filter, "port %u %7s", &port, tail) == 1) {
        any = 1;
    } else return 0;
    if (port > 65535) return 0;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    if (any) {
        bpf_emit(out, OP_JEQ_K, 0, 8, 34525);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 17, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 54);
        bpf_emit(out, OP_JEQ_K, 14, 0, port);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 56);
        bpf_emit(out, OP_JEQ_K, 12, 13, port);
        bpf_emit(out, OP_JEQ_K, 0, 12, 2048);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 8, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
        bpf_emit(out, OP_JSET_K, 6, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, 14);
        bpf_emit(out, OP_LDH_IND, 0, 0, 14);
        bpf_emit(out, OP_JEQ_K, 2, 0, port);
        bpf_emit(out, OP_LDH_IND, 0, 0, 16);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    } else {
        uint32_t absolute = !strcmp(direction, "dst") ? 56 : 54;
        uint32_t indirect = !strcmp(direction, "dst") ? 16 : 14;
        bpf_emit(out, OP_JEQ_K, 0, 6, 34525);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 13, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, absolute);
        bpf_emit(out, OP_JEQ_K, 10, 11, port);
        bpf_emit(out, OP_JEQ_K, 0, 10, 2048);
        bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
        bpf_emit(out, OP_JEQ_K, 2, 0, 132);
        bpf_emit(out, OP_JEQ_K, 1, 0, 6);
        bpf_emit(out, OP_JEQ_K, 0, 6, 17);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
        bpf_emit(out, OP_JSET_K, 4, 0, 8191);
        bpf_emit(out, OP_LDX_MSH, 0, 0, 14);
        bpf_emit(out, OP_LDH_IND, 0, 0, indirect);
        bpf_emit(out, OP_JEQ_K, 0, 1, port);
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int portrange_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char protocol_name[8], tail[8];
    unsigned low, high;
    uint32_t protocol;
    if (!c->optimize || c->dlt != 1 ||
        sscanf(c->filter, "%7s portrange %u-%u %7s", protocol_name, &low, &high, tail) != 3)
        return 0;
    if (!strcmp(protocol_name, "tcp")) protocol = 6;
    else if (!strcmp(protocol_name, "udp")) protocol = 17;
    else return 0;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    bpf_emit(out, OP_JEQ_K, 0, 7, 34525);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 20);
    bpf_emit(out, OP_JEQ_K, 0, 18, protocol);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 54);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 0, 1, low);
    bpf_emit(out, BPF_JMP | BPF_JGT | BPF_K, 0, 14, high);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 56);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 11, 13, low);
    bpf_emit(out, OP_JEQ_K, 0, 12, 2048);
    bpf_emit(out, OP_LDB_ABS, 0, 0, 23);
    bpf_emit(out, OP_JEQ_K, 0, 10, protocol);
    bpf_emit(out, OP_LDH_ABS, 0, 0, 20);
    bpf_emit(out, OP_JSET_K, 8, 0, 8191);
    bpf_emit(out, OP_LDX_MSH, 0, 0, 14);
    bpf_emit(out, OP_LDH_IND, 0, 0, 14);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 0, 1, low);
    bpf_emit(out, BPF_JMP | BPF_JGT | BPF_K, 0, 3, high);
    bpf_emit(out, OP_LDH_IND, 0, 0, 16);
    bpf_emit(out, BPF_JMP | BPF_JGE | BPF_K, 0, 2, low);
    bpf_emit(out, BPF_JMP | BPF_JGT | BPF_K, 1, 0, high);
    finish_test(out, c->snaplen);
    return 1;
}

static int ethernet_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char qualifier[8], address_text[32], tail[8];
    unsigned bytes[6];
    uint32_t low_word;
    uint32_t high_half;
    int fields, any = 0;
    if (c->dlt != 1) return 0;
    fields = sscanf(c->filter, "ether %7s host %31s %7s", qualifier, address_text, tail);
    if (fields != 2) {
        fields = sscanf(c->filter, "ether %7s %31s %7s", qualifier, address_text, tail);
        if (fields != 2) return 0;
    }
    if (!strcmp(qualifier, "host")) {
        strcpy(address_text, fields == 2 ? address_text : "");
        any = 1;
    } else if (strcmp(qualifier, "src") && strcmp(qualifier, "dst")) return 0;
    if (sscanf(address_text, "%x:%x:%x:%x:%x:%x", &bytes[0], &bytes[1], &bytes[2],
               &bytes[3], &bytes[4], &bytes[5]) != 6) return 0;
    low_word = (bytes[2] << 24) | (bytes[3] << 16) | (bytes[4] << 8) | bytes[5];
    high_half = (bytes[0] << 8) | bytes[1];
    if (any || !strcmp(qualifier, "src")) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 8);
        bpf_emit(out, OP_JEQ_K, 0, any ? 2 : 3, low_word);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 6);
        bpf_emit(out, OP_JEQ_K, any ? 4 : 0, any ? 0 : 1, high_half);
    }
    if (any || !strcmp(qualifier, "dst")) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 2);
        bpf_emit(out, OP_JEQ_K, 0, 3, low_word);
        bpf_emit(out, OP_LDH_ABS, 0, 0, 0);
        bpf_emit(out, OP_JEQ_K, 0, 1, high_half);
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], tail[8];
    unsigned a, b, d, e;
    uint32_t address, ipoff, arpoff;
    int fields, any = 0;

    if (c->dlt != 1) return 0;
    fields = sscanf(c->filter, "%7s host %u.%u.%u.%u %7s", direction, &a, &b, &d, &e, tail);
    if (fields != 5) {
        fields = sscanf(c->filter, "host %u.%u.%u.%u %7s", &a, &b, &d, &e, tail);
        if (fields != 4) return 0;
        any = 1;
    } else if (strcmp(direction, "src") && strcmp(direction, "dst")) {
        return 0;
    }
    if (a > 255 || b > 255 || d > 255 || e > 255) return 0;
    address = (a << 24) | (b << 16) | (d << 8) | e;
    ipoff = !any && !strcmp(direction, "dst") ? 30 : 26;
    arpoff = !any && !strcmp(direction, "dst") ? 38 : 28;

    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    if (any && c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 4, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 26);
        bpf_emit(out, OP_JEQ_K, 8, 0, address);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 30);
        bpf_emit(out, OP_JEQ_K, 6, 7, address);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 5, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 28);
        bpf_emit(out, OP_JEQ_K, 2, 0, address);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 38);
        bpf_emit(out, OP_JEQ_K, 0, 1, address);
    } else if (any) {
        const uint32_t types[6] = {2048,2048,2054,2054,32821,32821};
        const uint32_t offsets[6] = {26,30,28,38,28,38};
        int index;
        for (index = 0; index < 6; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, 2, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, offsets[index]);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(20 - 4 * index), index == 5 ? 1 : 0, address);
        }
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 2, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, ipoff);
        bpf_emit(out, OP_JEQ_K, 4, 5, address);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 3, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, arpoff);
        bpf_emit(out, OP_JEQ_K, 0, 1, address);
    } else {
        const uint32_t types[3] = {2048,2054,32821};
        int index;
        for (index = 0; index < 3; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, 2, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, index ? arpoff : ipoff);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(8 - 4 * index), index == 2 ? 1 : 0, address);
        }
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int parse_ipv4_net(const char *text, char *direction, uint32_t *network, uint32_t *mask, int *any)
{
    unsigned a, b, c, d, bits, ma, mb, mc, md;
    char tail[8];
    int fields;

    fields = sscanf(text, "%7s net %u.%u.%u.%u/%u %7s", direction, &a, &b, &c, &d, &bits, tail);
    if (fields == 6 && (!strcmp(direction, "src") || !strcmp(direction, "dst"))) *any = 0;
    else {
        fields = sscanf(text, "net %u.%u.%u.%u/%u %7s", &a, &b, &c, &d, &bits, tail);
        if (fields == 5) *any = 1;
        else {
            fields = sscanf(text, "%7s net %u.%u.%u.%u mask %u.%u.%u.%u %7s",
                            direction, &a, &b, &c, &d, &ma, &mb, &mc, &md, tail);
            if (fields == 9 && (!strcmp(direction, "src") || !strcmp(direction, "dst"))) {
                *any = 0;
                *mask = (ma << 24) | (mb << 16) | (mc << 8) | md;
                bits = 33;
            } else {
                fields = sscanf(text, "net %u.%u.%u.%u mask %u.%u.%u.%u %7s",
                                &a, &b, &c, &d, &ma, &mb, &mc, &md, tail);
                if (fields != 8) return 0;
                *any = 1;
                *mask = (ma << 24) | (mb << 16) | (mc << 8) | md;
                bits = 33;
            }
        }
    }
    if (a > 255 || b > 255 || c > 255 || d > 255 || bits > 33) return 0;
    if (bits <= 32) *mask = bits ? UINT32_MAX << (32 - bits) : 0;
    *network = ((a << 24) | (b << 16) | (c << 8) | d) & *mask;
    return 1;
}

static int net_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8];
    uint32_t network, mask = 0, ipoff, arpoff;
    int any;

    if (c->dlt != 1 || !parse_ipv4_net(c->filter, direction, &network, &mask, &any)) return 0;
    ipoff = !any && !strcmp(direction, "dst") ? 30 : 26;
    arpoff = !any && !strcmp(direction, "dst") ? 38 : 28;
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    if (any && c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 6, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 26);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 11, 0, network);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 30);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 8, 9, network);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 7, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 28);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 3, 0, network);
        bpf_emit(out, OP_LDW_ABS, 0, 0, 38);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 0, 1, network);
    } else if (any) {
        const uint32_t types[6] = {2048,2048,2054,2054,32821,32821};
        const uint32_t offsets[6] = {26,30,28,38,28,38};
        int index;
        for (index = 0; index < 6; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, 3, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, offsets[index]);
            bpf_emit(out, OP_AND_K, 0, 0, mask);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(25 - 5 * index), index == 5 ? 1 : 0, network);
        }
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 3, 2048);
        bpf_emit(out, OP_LDW_ABS, 0, 0, ipoff);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 5, 6, network);
        bpf_emit(out, OP_JEQ_K, 1, 0, 2054);
        bpf_emit(out, OP_JEQ_K, 0, 4, 32821);
        bpf_emit(out, OP_LDW_ABS, 0, 0, arpoff);
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        bpf_emit(out, OP_JEQ_K, 0, 1, network);
    } else {
        const uint32_t types[3] = {2048,2054,32821};
        int index;
        for (index = 0; index < 3; ++index) {
            if (index) bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
            bpf_emit(out, OP_JEQ_K, 0, index == 2 ? 4 : 3, types[index]);
            bpf_emit(out, OP_LDW_ABS, 0, 0, index ? arpoff : ipoff);
            bpf_emit(out, OP_AND_K, 0, 0, mask);
            bpf_emit(out, OP_JEQ_K, (uint8_t)(10 - 5 * index), index == 2 ? 1 : 0, network);
        }
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int ipv6_host_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char direction[8], address_text[80], tail[8];
    struct in6_addr binary;
    uint32_t words[4];
    int any = 0, fields, index;
    uint32_t base;

    if (c->dlt != 1) return 0;
    fields = sscanf(c->filter, "ip6 %7s host %79s %7s", direction, address_text, tail);
    if (fields != 2 || (strcmp(direction, "src") && strcmp(direction, "dst"))) {
        fields = sscanf(c->filter, "ip6 host %79s %7s", address_text, tail);
        if (fields != 1) return 0;
        any = 1;
    }
    if (!strcmp(address_text, "ip6-localhost") || !strcmp(address_text, "ip6-loopback")) strcpy(address_text, "::1");
    else if (!strcmp(address_text, "ip6-allnodes")) strcpy(address_text, "ff02::1");
    else if (!strcmp(address_text, "ip6-allrouters")) strcpy(address_text, "ff02::2");
    if (inet_pton(AF_INET6, address_text, &binary) != 1) return 0;
    for (index = 0; index < 4; ++index) {
        uint32_t network_word;
        memcpy(&network_word, binary.s6_addr + index * 4, 4);
        words[index] = ntohl(network_word);
    }
    bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
    if (!any) {
        base = !strcmp(direction, "dst") ? 38 : 22;
        bpf_emit(out, OP_JEQ_K, 0, 9, 34525);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, base + index * 4);
            bpf_emit(out, OP_JEQ_K, 0, (uint8_t)(7 - index * 2), words[index]);
        }
    } else if (c->optimize) {
        bpf_emit(out, OP_JEQ_K, 0, 17, 34525);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, 22 + index * 4);
            bpf_emit(out, OP_JEQ_K, index == 3 ? 8 : 0, (uint8_t)(6 - index * 2), words[index]);
        }
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, 38 + index * 4);
            bpf_emit(out, OP_JEQ_K, 0, (uint8_t)(7 - index * 2), words[index]);
        }
    } else {
        bpf_emit(out, OP_JEQ_K, 0, 8, 34525);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, 22 + index * 4);
            bpf_emit(out, OP_JEQ_K, index == 3 ? 10 : 0, (uint8_t)(6 - index * 2), words[index]);
        }
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12);
        bpf_emit(out, OP_JEQ_K, 0, 9, 34525);
        for (index = 0; index < 4; ++index) {
            bpf_emit(out, OP_LDW_ABS, 0, 0, 38 + index * 4);
            bpf_emit(out, OP_JEQ_K, 0, (uint8_t)(7 - index * 2), words[index]);
        }
    }
    finish_test(out, c->snaplen);
    return 1;
}

static int length_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    char operator_text[3], tail[8];
    unsigned value;
    uint16_t jump;
    int invert = 0;

    if (sscanf(c->filter, "greater %u %7s", &value, tail) == 1) {
        jump = BPF_JMP | BPF_JGE | BPF_K;
    } else if (sscanf(c->filter, "less %u %7s", &value, tail) == 1) {
        jump = BPF_JMP | BPF_JGT | BPF_K;
        invert = 1;
    } else if (c->optimize && sscanf(c->filter, "len %2s %u %7s", operator_text, &value, tail) == 2) {
        if (!strcmp(operator_text, ">")) jump = BPF_JMP | BPF_JGT | BPF_K;
        else if (!strcmp(operator_text, ">=")) jump = BPF_JMP | BPF_JGE | BPF_K;
        else if (!strcmp(operator_text, "=" ) || !strcmp(operator_text, "==")) jump = OP_JEQ_K;
        else if (!strcmp(operator_text, "<=")) { jump = BPF_JMP | BPF_JGT | BPF_K; invert = 1; }
        else if (!strcmp(operator_text, "<")) { jump = BPF_JMP | BPF_JGE | BPF_K; invert = 1; }
        else return 0;
    } else return 0;

    bpf_emit(out, BPF_LD | BPF_W | BPF_LEN, 0, 0, 0);
    bpf_emit(out, jump, 0, 1, value);
    bpf_emit(out, OP_RET_K, 0, 0, invert ? 0 : (uint32_t)c->snaplen);
    bpf_emit(out, OP_RET_K, 0, 0, invert ? (uint32_t)c->snaplen : 0);
    return 1;
}

static int flag_value(const char *text, uint32_t *value)
{
    char buffer[96], *token, *save;
    char *end;
    size_t length = strlen(text);
    uint32_t result = 0;
    if (length >= sizeof(buffer)) return 0;
    strcpy(buffer, text);
    while (length && (buffer[length - 1] == ' ' || buffer[length - 1] == ')')) buffer[--length] = 0;
    token = buffer;
    while (*token == ' ' || *token == '(') ++token;
    for (token = strtok_r(token, "|", &save); token; token = strtok_r(NULL, "|", &save)) {
        while (*token == ' ') ++token;
        length = strlen(token);
        while (length && token[length - 1] == ' ') token[--length] = 0;
        if (!strcmp(token, "tcp-fin")) result |= 1;
        else if (!strcmp(token, "tcp-syn")) result |= 2;
        else if (!strcmp(token, "tcp-rst")) result |= 4;
        else if (!strcmp(token, "tcp-push")) result |= 8;
        else if (!strcmp(token, "tcp-ack")) result |= 16;
        else if (!strcmp(token, "tcp-urg")) result |= 32;
        else if (!strcmp(token, "tcp-ece")) result |= 64;
        else if (!strcmp(token, "tcp-cwr")) result |= 128;
        else {
            result |= (uint32_t)strtoul(token, &end, 0);
            if (*end) return 0;
        }
    }
    *value = result;
    return 1;
}

static int tcp_flag_compile(const bpfc_case_t *c, bpf_prog_t *out)
{
    const char *amp, *comparison;
    char mask_text[96], operator_text[3];
    uint32_t mask, rhs;
    unsigned right;
    size_t guard, protojump, fragjump, testjump, accept, reject;
    uint32_t protooff, fragword, ipbase, dataoff;

    if (!c->optimize || !(starts(c->filter, "tcp[13]") || starts(c->filter, "tcp[tcpflags]"))) return 0;
    amp = strchr(c->filter, '&');
    if (!amp) return 0;
    comparison = strstr(amp, " != ");
    if (!comparison) comparison = strstr(amp, " = ");
    if (!comparison) comparison = strstr(amp, " == ");
    if (!comparison || (size_t)(comparison - amp - 1) >= sizeof(mask_text)) return 0;
    memcpy(mask_text, amp + 1, (size_t)(comparison - amp - 1));
    mask_text[comparison - amp - 1] = 0;
    if (sscanf(comparison, " %2s %u", operator_text, &right) != 2 || !flag_value(mask_text, &mask)) return 0;
    rhs = right;

    if (c->dlt == 1) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 12); protooff = 23; fragword = 20; ipbase = 14; dataoff = 27;
    } else if (c->dlt == 113) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 14); protooff = 25; fragword = 22; ipbase = 16; dataoff = 29;
    } else if (c->dlt == 9) {
        bpf_emit(out, OP_LDH_ABS, 0, 0, 2); protooff = 13; fragword = 10; ipbase = 4; dataoff = 17;
    } else if (c->dlt == 0) {
        bpf_emit(out, OP_LDW_ABS, 0, 0, 0); protooff = 13; fragword = 10; ipbase = 4; dataoff = 17;
    } else if (c->dlt == 12) {
        bpf_emit(out, OP_LDB_ABS, 0, 0, 0);
        bpf_emit(out, OP_AND_K, 0, 0, 0xf0);
        protooff = 9; fragword = 6; ipbase = 0; dataoff = 13;
    } else return 0;
    guard = out->len;
    bpf_emit(out, OP_JEQ_K, 0, 0, c->dlt == 9 ? 33 : (c->dlt == 0 ? 0x02000000U : 2048));
    bpf_emit(out, OP_LDB_ABS, 0, 0, protooff);
    protojump = out->len;
    bpf_emit(out, OP_JEQ_K, 0, 0, 6);
    bpf_emit(out, OP_LDH_ABS, 0, 0, fragword);
    fragjump = out->len;
    bpf_emit(out, OP_JSET_K, 0, 0, 8191);
    bpf_emit(out, OP_LDX_MSH, 0, 0, ipbase);
    bpf_emit(out, BPF_LD | BPF_B | BPF_IND, 0, 0, dataoff);
    if (!strcmp(operator_text, "!=") && rhs == 0) {
        testjump = out->len;
        bpf_emit(out, OP_JSET_K, 0, 0, mask);
    } else {
        bpf_emit(out, OP_AND_K, 0, 0, mask);
        testjump = out->len;
        bpf_emit(out, OP_JEQ_K, 0, 0, rhs);
    }
    accept = out->len;
    finish_test(out, c->snaplen);
    reject = out->len - 1;
    out->insns[guard].jf = (uint8_t)(reject - guard - 1);
    out->insns[protojump].jf = (uint8_t)(reject - protojump - 1);
    out->insns[fragjump].jt = (uint8_t)(reject - fragjump - 1);
    if (!strcmp(operator_text, "!=") && rhs != 0) {
        out->insns[testjump].jt = (uint8_t)(reject - testjump - 1);
        out->insns[testjump].jf = (uint8_t)(accept - testjump - 1);
    } else {
        out->insns[testjump].jt = (uint8_t)(accept - testjump - 1);
        out->insns[testjump].jf = (uint8_t)(reject - testjump - 1);
    }
    return 1;
}

static const char *collapsed_protocol(const bpfc_case_t *c, char word[16])
{
    const char *cursor = c->filter;
    int atoms = 0, negations = 0;
    if (!c->optimize) return NULL;
    word[0] = 0;
    while (*cursor) {
        char token[16];
        size_t length = 0;
        while (*cursor == ' ' || *cursor == '(' || *cursor == ')') ++cursor;
        if (!*cursor) break;
        if (!((*cursor >= 'a' && *cursor <= 'z') || (*cursor >= 'A' && *cursor <= 'Z'))) return NULL;
        while (((*cursor >= 'a' && *cursor <= 'z') || (*cursor >= 'A' && *cursor <= 'Z') ||
                (*cursor >= '0' && *cursor <= '9')) && length + 1 < sizeof(token))
            token[length++] = *cursor++;
        token[length] = 0;
        if (!strcmp(token, "and") || !strcmp(token, "or")) continue;
        if (!strcmp(token, "not")) { ++negations; continue; }
        if (strcmp(token, "ip") && strcmp(token, "ip6") && strcmp(token, "tcp") &&
            strcmp(token, "udp") && strcmp(token, "sctp") && strcmp(token, "arp") &&
            strcmp(token, "icmp") && strcmp(token, "icmp6") && strcmp(token, "igmp") &&
            strcmp(token, "pim") && strcmp(token, "esp") && strcmp(token, "ah")) return NULL;
        if (!atoms) strcpy(word, token);
        else if (strcmp(word, token)) return NULL;
        ++atoms;
    }
    if (atoms < 2 || (negations & 1)) return NULL;
    return word;
}

static const char *repeated_expression(const bpfc_case_t *c, char reduced[256])
{
    static const char *separators[] = {" and ", " or "};
    size_t separator_index;
    if (!c->optimize || strlen(c->filter) >= 256) return NULL;
    for (separator_index = 0; separator_index < 2; ++separator_index) {
        const char *separator = separators[separator_index];
        const char *first = strstr(c->filter, separator);
        const char *cursor;
        size_t atom_length;
        int count = 1;
        if (!first) continue;
        atom_length = (size_t)(first - c->filter);
        if (!atom_length || atom_length >= 256) continue;
        cursor = first;
        while (*cursor) {
            if (strncmp(cursor, separator, strlen(separator))) { count = 0; break; }
            cursor += strlen(separator);
            if (strncmp(cursor, c->filter, atom_length)) { count = 0; break; }
            cursor += atom_length;
            ++count;
        }
        if (count >= 2) {
            memcpy(reduced, c->filter, atom_length);
            reduced[atom_length] = 0;
            return reduced;
        }
    }
    return NULL;
}

int bpfc_compile(const bpfc_case_t *c, bpf_prog_t *out, const char **err)
{
    ast_arena_t arena;
    node_t *root;
    char collapsed[16];
    char repeated[256];
    bpfc_case_t reduced;

    (void)c->optimize;   /* no optimizer exists, so this changes nothing */

    bpf_prog_reset(out);

    if (strcmp(c->filter, "mpls and") && syntax_invalid(c->filter)) {
        *err = BPFC_GENERIC_ERROR;
        return -1;
    }

    *err = semantic_error(c);
    if (*err != NULL)
        return -1;

    if (collapsed_protocol(c, collapsed)) {
        reduced = *c;
        reduced.filter = collapsed;
        if (simple_compile(&reduced, out))
            return 0;
    }
    if (repeated_expression(c, repeated)) {
        reduced = *c;
        reduced.filter = repeated;
        if (simple_compile(&reduced, out) || generic_port_compile(&reduced, out) || port_compile(&reduced, out) || portrange_compile(&reduced, out) ||
            host_compile(&reduced, out) || ipv6_host_compile(&reduced, out) || ethernet_host_compile(&reduced, out) || net_compile(&reduced, out) ||
            length_compile(&reduced, out) || tcp_flag_compile(&reduced, out))
            return 0;
    }

    if (simple_compile(c, out))
        return 0;
    if (generic_port_compile(c, out))
        return 0;
    if (port_compile(c, out))
        return 0;
    if (portrange_compile(c, out))
        return 0;
    if (host_compile(c, out))
        return 0;
    if (ipv6_host_compile(c, out))
        return 0;
    if (ethernet_host_compile(c, out))
        return 0;
    if (net_compile(c, out))
        return 0;
    if (length_compile(c, out))
        return 0;
    if (tcp_flag_compile(c, out))
        return 0;

    root = filter_parse(c->filter, &arena);
    if (!root) {
        *err = BPFC_GENERIC_ERROR;
        return -1;
    }
    if (codegen(root, c->snaplen, out) != 0) {
        *err = BPFC_GENERIC_ERROR;
        return -1;
    }
    return 0;
}
